CREATE PROCEDURE [dbo].[SortOutVouchers]
as
declare @SCHEMENO Int,@VoucherNo Int,@Credit float
declare acsr cursor for
select schemeCode from scheme
open acsr 
fetch from acsr into @schemeNo
while @@fetch_Status = 0
begin
  declare bcsr cursor for
  select VoucherNo,Credit from Cashbook
  where SchemeNo = @schemeNo and VoucherNo > 0 and Credit > 0
  open bcsr
  fetch from bcsr into @VoucherNo,@Credit
  while @@fetch_Status = 0
  begin
      update PaymentVoucher
      set CreditAmt = @Credit,ChequeWritten=1 where
      SchemeNo = @schemeNo and VoucherNo = @VoucherNo
  fetch next from bcsr into @VoucherNo,@Credit
  end
  Close bcsr
  Deallocate bcsr
  fetch next from acsr into @schemeNo
end
Close acsr
Deallocate acsr
go

