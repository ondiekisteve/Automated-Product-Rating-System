CREATE PROCEDURE [dbo].[ShowDeductions]
@SCHEMENO Int,
@CurMonth int,
@curYear int
--with Encryption
as
declare @DistrAmount float
declare @InvDate datetime
declare @Amount float
select @DistrAmount = 0
declare DistrCsr cursor for

select Invoicedate, Amount
from feesInvoice 
where SchemeNo = @schemeNo 
and ((datepart(Month, Invoicedate) = @CurMonth)
and (datepart(Year, Invoicedate) = @CurYear))

Open DistrCsr

Fetch from DistrCsr into @InvDate, @Amount

while @@fetch_status = 0
begin
   if @Amount is null select @Amount = 0
   Select @DistrAmount = @DistrAmount + @Amount
Fetch next from DistrCsr into @InvDate, @Amount
end
Close DistrCsr
Deallocate DistrCsr

Select @DistrAmount as DistrAmount
go

