CREATE PROCEDURE [dbo].[repClosingBalances]
@schemeNo varchar(15),
@AcctPeriod int
--with Encryption
as
if object_id('tempdb..##ClosingBal') is null
  create table ##ClosingBal
  (
    schemeNo varchar (15) NOT NULL ,
    schemeName varchar (100) not null,
    memberNo int NOT NULL ,
    fullName varchar (100) not null, 
    cEmpBal float not null,
    cEmprBal float not null,
    empOpening float null,
    emprOpening float null,
    empCont float null,
    emprCont float null,
    empInt float null,
    emprInt float null,
    grandTotal float not null,
    endingPeriod Varchar (30) null,
    Exits float null,
    Total float null
    constraint pk_ClosingBal primary key (schemeNo, memberNo)
  ) 

declare @schemeName varchar(100)
declare @memberNo int
declare @fullName varchar(100) 
declare @cEmpBal float
declare @cEmprBal float,@cVolBal float
declare @empOpening float
declare @emprOpening float,@VolOpening float
declare @empCont float
declare @emprCont float
declare @empInt float
declare @emprInt float
declare @empVol float, @VolInt float
declare @grandTotal float
declare @Transfer float
declare @monthName varchar(15)
declare @schemeYear int
declare @curPeriod varchar(30), @EmprVol float,@MinYear int,@CalcMonth int,@CalcYear int

Delete from ##ClosingBal

Select @CalcMonth = DatePart(Month,EndDate),@CalcYear = datepart(Year, EndDate) from schemeYears where schemeNo like @schemeNo
and AcctPeriod = @AcctPeriod

select @monthName = monthName from monthTable where monthNumber = @calcMonth
select @schemeName = schemeName from Scheme where schemeCode like @schemeNo

exec GetEndingPeriod @calcMonth, @curPeriod out
select @curPeriod = @curPeriod +' '+ cast(@CalcYear as varchar(4))
exec GetAccountingPeriodInAYear @schemeNo, @CalcMonth, @calcYear, @AcctPeriod out

declare benCsr cursor for 
select b.schemeNo, b.memberNo, b.empCont + b.EmpVolCont + b.PreEmpCont + b.PreAvc , 
       b.emprCont +  b.EmprVolCont + b.PreEmprCont, 
      (b.empCont + b.emprCont + b.EmpVolCont + b.EmprVolCont + b.PreEmpCont + b.PreEmprCont + b.PreAvc) as TotalBalance,
(upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname 
from MemberOpeningBalances b 
     inner join Members m on b.schemeNo like m.schemeNo and b.memberNo = m.memberNo  
where b.schemeNo like @schemeNo and AcctPeriod = @AcctPeriod
order by b.memberNo

open benCsr
fetch from benCsr into @schemeNo, @MemberNo, @cEmpBal, @cEmprBal, @GrandTotal, @fullname

while @@fetch_status = 0
begin
  if @grandTotal is null select @grandTotal = 0

  select @empOpening = empCont + empVolCont + preEmpCont + PreAvc, @emprOpening = emprCont + emprVolCont + PreEmprCont
  from memberOpeningBalances where schemeNo like @schemeNo and memberNo = @memberNo and acctPeriod = @acctPeriod - 1

  Exec RepMemberCertificateContributions @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @EmpCont out, 
  @EmprCont out, @EmpVol out, @EmprVol out

  if @emprOpening is null select @emprOpening = 0

  select @Transfer = EmpTransfer + EmprTransfer 
  from memberTransfer where schemeNo like @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod

  if @empOpening is null select @empOpening = 0
  if @emprOpening is null select @emprOpening = 0
  if @empCont is null select @empcont = 0
  if @emprCont is null select @emprCont = 0
  if @empVol is null select @empVol = 0
  if @Transfer is null select @Transfer = 0

  select @empInt = @cEmpBal - (@empOpening + @empCont + @EmpVol)
  if @empInt is null select @empInt = 0
  if @emprOpening is null select @emprOpening = 0
  select @emprInt = @cEmprBal - (@emprOpening + @emprCont + @EmprVol )
  if @emprInt is null select @empInt = 0
  
  insert into ##ClosingBal (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening, 
                              empCont,emprCont, empInt, emprInt, grandTotal,EndingPeriod,Exits,Total)
  values (@schemeNo, @schemeName, @memberNo,@fullName, @cEmpBal, @cEmprBal, @EmpOpening, @EmprOpening, 
                             @empCont + @EmpVol, @EmprCont + @EmprVol, @EmpInt, @EmprInt, @GrandTotal, @CurPeriod,0,@GrandTotal)
    
  select @empOpening = 0, @emprOpening = 0, @empCont = 0, @empVol = 0, @emprCont = 0, @Transfer = 0, @cEmpBal = 0, @cEmprBal = 0, @Transfer = 0

 fetch next from bencsr into @schemeNo, @MemberNo, @cEmpBal, @cEmprBal, @GrandTotal, @fullname
end

close benCsr
deallocate benCsr  


select * from ##ClosingBal order By MemberNo
go

