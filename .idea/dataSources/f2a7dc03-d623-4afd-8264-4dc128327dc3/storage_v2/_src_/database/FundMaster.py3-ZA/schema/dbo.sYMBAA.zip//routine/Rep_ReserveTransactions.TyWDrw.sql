CREATE PROCEDURE [dbo].[Rep_ReserveTransactions]      
@SCHEMENO Int,      
@StartDate Datetime,      
@EndDate Datetime,      
@Registered Int,    
@AdminFees Int, /* 10 - All, 0 - Other, 1 - Admin Fees, 2 - Expense, 3 - Contribution, 4 - UnReg Tax */  
@SponsorCode Int     
as      
      
declare @schemeName Varchar(100),@ReportSub varchar(50),@Sponsorname varchar(100),
@Debit decimal(20,6),@Credit decimal(20,6) 

if @SponsorCode > 0
   select @Sponsorname = SponsorName from sponsor where schemeno = @schemeNo and SponsorCode = @SponsorCode
else
   select @Sponsorname =''    
    
if @AdminFees = 10    
   select @ReportSub = 'ALL TYPES'    
Else if @AdminFees = 0    
   select @ReportSub = 'OTHERS'     
Else if @AdminFees = 1    
   select @ReportSub = 'ADMINISTRATION FEES ON WITHDRAWAL'        
Else if @AdminFees = 2    
   select @ReportSub = 'SCHEME EXPENSES'      
Else if @AdminFees = 3    
   select @ReportSub = 'CONTRIBUTIONS'     
Else if @AdminFees = 4    
   select @ReportSub = 'CORPORATE TAX ON UNREGISTERED'      
      
      
select @schemeName = SchemeName from scheme where schemeCode = @schemeNo      
  
IF @SponsorCode = 0  
BEGIN    
if @AdminFees = 10    
begin    
if @Registered = 0 /* Registered */ 
   begin
   select @debit = sum(Surplus),@Credit = sum(Credit)
   from Surplus where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate
     
   Select SurplusDate,SurplusDesc,Surplus as Debit,Credit,@schemeName as SchemeName,      
   @StartDate as StartDate,@EndDate as EndDate,'REGISTERED RESERVE' as ReportDesc,    
   @ReportSub AS ReportSub,@SponsorName as sponsorname,@debit - @Credit as Balance      
   from Surplus where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate      
   Order by SurplusDate
   end      
else if @Registered = 1 /* UnRegistered */
   begin 
   select @debit = sum(Surplus),@Credit = sum(Credit)
   from Surplus_UnReg where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate
     
   Select SurplusDate,SurplusDesc,Surplus as Debit,Credit,@schemeName as SchemeName,      
   @StartDate as StartDate,@EndDate as EndDate,'UN-REGISTERED RESERVE' as ReportDesc,    
   @ReportSub AS ReportSub,@SponsorName as sponsorname,@debit - @Credit as Balance      
   from Surplus_UnReg where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate      
   order by SurplusDate 
   end     
end    
else    
begin    
if @Registered = 0 /* Registered */ 
   begin

   select @debit = sum(Surplus),@Credit = sum(Credit)
   from Surplus where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate
   and AdminFees = @AdminFees
     
   Select SurplusDate,SurplusDesc,Surplus as Debit,Credit,@schemeName as SchemeName,      
   @StartDate as StartDate,@EndDate as EndDate,'REGISTERED RESERVE' as ReportDesc,    
   @ReportSub AS ReportSub,@SponsorName as sponsorname,@debit - @Credit as Balance      
   from Surplus where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate    
   and AdminFees = @AdminFees      
   Order by SurplusDate
   end      
else if @Registered = 1 /* UnRegistered */ 
   begin
   select @debit = sum(Surplus),@Credit = sum(Credit)
   from Surplus_UnReg where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate
   and AdminFees = @AdminFees
          
   Select SurplusDate,SurplusDesc,Surplus as Debit,Credit,@schemeName as SchemeName,      
   @StartDate as StartDate,@EndDate as EndDate,'UN-REGISTERED RESERVE' as ReportDesc,    
   @ReportSub AS ReportSub,@SponsorName as sponsorname,@debit - @Credit as Balance      
   from Surplus_UnReg where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate      
   and AdminFees = @AdminFees    
   order by SurplusDate
   end      
end   
END   
ELSE /* Umbrella */  

BEGIN    
if @AdminFees = 10    
begin    
if @Registered = 0 /* Registered */
   begin 
   select @debit = sum(Surplus),@Credit = sum(Credit)
   from Surplus where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate
   and SponsorCode = @SponsorCode
     
   Select SurplusDate,SurplusDesc,Surplus as Debit,Credit,@schemeName as SchemeName,      
   @StartDate as StartDate,@EndDate as EndDate,'REGISTERED RESERVE' as ReportDesc,    
   @ReportSub AS ReportSub,@SponsorName as sponsorname,@debit - @Credit as Balance       
   from Surplus where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate   
   and SponsorCode = @SponsorCode     
   Order by SurplusDate 
   end     
else if @Registered = 1 /* UnRegistered */
   begin   
   select @debit = sum(Surplus),@Credit = sum(Credit)
   from Surplus_UnReg where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate
   and SponsorCode = @SponsorCode
   
   Select SurplusDate,SurplusDesc,Surplus as Debit,Credit,@schemeName as SchemeName,      
   @StartDate as StartDate,@EndDate as EndDate,'UN-REGISTERED RESERVE' as ReportDesc,    
   @ReportSub AS ReportSub,@SponsorName as sponsorname,@debit - @Credit as Balance       
   from Surplus_UnReg where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate   
   and SponsorCode = @SponsorCode     
   order by SurplusDate
   end      
end    
else    
begin    
if @Registered = 0 /* Registered */ 
   begin   
   select @debit = sum(Surplus),@Credit = sum(Credit)
   from Surplus where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate
   and SponsorCode = @SponsorCode and AdminFees = @AdminFees
  
   Select SurplusDate,SurplusDesc,Surplus as Debit,Credit,@schemeName as SchemeName,      
   @StartDate as StartDate,@EndDate as EndDate,'REGISTERED RESERVE' as ReportDesc,    
   @ReportSub AS ReportSub,@SponsorName as sponsorname,@debit - @Credit as Balance      
   from Surplus where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate    
   and AdminFees = @AdminFees and SponsorCode = @SponsorCode     
   Order by SurplusDate  
   end     
else if @Registered = 1 /* UnRegistered */ 
   begin

   select @debit = sum(Surplus),@Credit = sum(Credit)
   from Surplus_UnReg where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate
   and SponsorCode = @SponsorCode and AdminFees = @AdminFees
     
   Select SurplusDate,SurplusDesc,Surplus as Debit,Credit,@schemeName as SchemeName,      
   @StartDate as StartDate,@EndDate as EndDate,'UN-REGISTERED RESERVE' as ReportDesc,    
   @ReportSub AS ReportSub,@SponsorName as sponsorname,@debit - @Credit as Balance       
   from Surplus_UnReg where schemeNo = @schemeNo and @StartDate <= SurplusDate and @EndDate >= SurplusDate      
   and AdminFees = @AdminFees and SponsorCode = @SponsorCode   
   order by SurplusDate 
   end     
end   
END
go

