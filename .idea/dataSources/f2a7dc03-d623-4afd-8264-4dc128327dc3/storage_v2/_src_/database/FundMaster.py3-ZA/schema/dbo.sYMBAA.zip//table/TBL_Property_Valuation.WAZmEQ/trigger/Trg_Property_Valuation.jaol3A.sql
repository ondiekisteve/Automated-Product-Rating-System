CREATE TRIGGER [dbo].[Trg_Property_Valuation] ON [dbo].[TBL_Property_Valuation] 
FOR INSERT 
AS

declare @SchemeNo Int,@PropCode Int,@ValuationNo Int,@UserName varchar(60)

select @UserName = user

select @schemeNo = SchemeNo,@PropCode = PropertyCode,@ValuationNo = ValuationNo from Inserted

Exec Proc_Auto_Insert_InvPosting @schemeNo,@PropCode,1,194,@ValuationNo,2,@UserName
go

