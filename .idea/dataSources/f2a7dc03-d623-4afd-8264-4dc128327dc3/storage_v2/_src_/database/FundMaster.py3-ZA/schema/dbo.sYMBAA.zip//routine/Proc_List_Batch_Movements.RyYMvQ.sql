CREATE PROCEDURE [dbo].[Proc_List_Batch_Movements]
@schemeNo Int,
@StartDate Datetime,
@EndDate Datetime
--with Encryption
as

select BATCH_ID,SchemeNo,BatchDate,BatchDesc 
from TBL_BATCH_MOVEMENTS
where schemeNo = @schemeNo and BatchDate >= @StartDate and BatchDate <= @EndDate
go

