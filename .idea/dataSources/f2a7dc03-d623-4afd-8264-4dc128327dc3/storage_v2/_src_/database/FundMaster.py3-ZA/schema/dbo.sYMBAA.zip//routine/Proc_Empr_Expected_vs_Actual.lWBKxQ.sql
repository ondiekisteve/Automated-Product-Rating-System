CREATE PROCEDURE [dbo].[Proc_Empr_Expected_vs_Actual]
@SCHEMENO Int,
@StartDate Datetime,
@EndDate Datetime,
@ReportMode Int /* 0 - Single month, 1 - all the periods */
--with Encryption 
as



if object_id('tempdb..#Empr_Expected_vs_Actual') is null

begin
create table #Empr_Expected_vs_Actual
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[SchemeName] [varchar](100) NOT NULL ,
	[MemberNo] [Int],
        [PayrollNo][varchar](15),
        [FullName][varchar](100),
        [ContrMonth][Int],
        [ContrYear][Int],
        [MonthName][varchar](40),
        [StartDate][Datetime],
        [Salary][float],
        [EmpCont][float],
        [ExEmprCont][float],
        [EmprCont][float],
        [ExVariance][float],
        [EmprRate][float],
        [Pensionable][Int],
        [EndDate][Datetime] 
) 

ALTER TABLE #Empr_Expected_vs_Actual WITH NOCHECK ADD 

            
	CONSTRAINT [PK_Empr_Expected_vs_Actual] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end

declare @SchemeName varchar(100),@PayrollNo varchar(20),@FullName varchar(100),
@MonthName varchar(40),@djScheme Datetime,@MissMonth Int,@MissYear Int,@MissDate Datetime,@MissStartDate Datetime,
@AcctPeriod Int,@MemberNo Int,@Salary float,@EmpCont float,@EmprCont float,
@NumYears Int,@NumMonths Int,@NumDays Int,@ExEmprCont float,@EmprRate float,
@ContrMonth Int,@ContrYear Int

select @schemeName = SchemeName from scheme where schemeCode = @schemeNo


if @ReportMode = 0
begin
   select @ContrMonth = DatePart(Month,@StartDate),@ContrYear = DatePart(Year,@StartDate)
   declare ExCsr Cursor for
   Select c.MemberNo,c.salary,c.EmpCont,c.EmprCont,c.DatePaid,DatePart(Month,c.DatePaid),
          DatePart(Year,c.DatePaid),
          m.PayrollNo,m.djpens,Upper(m.sName)+', '+m.fName+' '+m.Onames
   from Contributionssummary c
        inner Join Members m on c.schemeNo = m.schemeNo and c.MemberNo = m.MemberNo
   where c.schemeNo = @schemeNo and c.ContrMonth = @ContrMonth and c.ContrYear = @ContrYear

   Open ExCsr
   Fetch from ExCsr into @MemberNo,@Salary,@EmpCont,@EmprCont,@MissDate,@ContrMonth,@ContrYear,@PayrollNo,@djScheme,@FullName
   while @@fetch_Status = 0
   begin

     Exec GetServiceTime @djScheme,@MissDate,@NumYears Out,@NumMonths Out,@NumDays Out

     Exec GetMonthName @ContrMonth,@MonthName Out

     Select @MonthName = @MonthName+', '+cast(@ContrYear as varchar(4))

     if @NumYears < 10
        begin
        select @ExEmprCont = @EmpCont,@EmprRate = 7.50
        end
     else if @NumYears >= 10 and @NumYears < 20
        begin
        select @ExEmprCont = @Salary * (11.25/100.00),@EmprRate = 11.25
        end
     else if @NumYears >= 20
        begin
        select @ExEmprCont = @Salary * (15.00/100.00),@EmprRate = 15.00  
        end

     if (@ExEmprCont - @EmprCont) <> 0
        Insert Into #Empr_Expected_vs_Actual(SchemeName,MemberNo,PayrollNo,
                                          FullName,ContrMonth,ContrYear,
                                          MonthName,StartDate,Salary,EmpCont,
                                          ExEmprCont,EmprCont,ExVariance,
                                          EmprRate,Pensionable,EndDate)
                                  Values(@SchemeName,@MemberNo,@PayrollNo,
                                         @FullName,@ContrMonth,@ContrYear,
                                         @MonthName,@StartDate,@Salary,@EmpCont,
                                         @ExEmprCont,@EmprCont,@ExEmprCont - @EmprCont,
                                         @EmprRate,@NumYears,@EndDate) 

     Select @MemberNo =0,@Salary=0,@EmpCont=0,@EmprCont=0,@ContrMonth=0,@ContrYear=0,@PayrollNo='',@FullName='',@ExEmprCont=0,
     @EmprRate = 0,@NumYears = 0

     Fetch next from ExCsr into @MemberNo,@Salary,@EmpCont,@EmprCont,@MissDate,@ContrMonth,@ContrYear,@PayrollNo,@djScheme,@FullName
   end
   Close ExCsr
   Deallocate Excsr



end
else if @ReportMode = 1
begin
   declare ExCsr Cursor for
   Select c.MemberNo,c.salary,c.EmpCont,c.EmprCont,c.DatePaid,DatePart(Month,c.DatePaid),
          DatePart(Year,c.DatePaid),
          m.PayrollNo,m.djpens,Upper(m.sName)+', '+m.fName+' '+m.Onames
   from Contributionssummary c
        inner Join Members m on c.schemeNo = m.schemeNo and c.MemberNo = m.MemberNo
   where c.schemeNo = @schemeNo AND c.DatePaid >= @StartDate and c.DatePaid <= @EndDate
   order by c.DatePaid

   Open ExCsr
   Fetch from ExCsr into @MemberNo,@Salary,@EmpCont,@EmprCont,@MissDate,@ContrMonth,@ContrYear,@PayrollNo,@djScheme,@FullName
   while @@fetch_Status = 0
   begin

     Exec GetServiceTime @djScheme,@MissDate,@NumYears Out,@NumMonths Out,@NumDays Out

     Exec GetMonthName @ContrMonth,@MonthName Out

     Select @MonthName = @MonthName+', '+cast(@ContrYear as varchar(4))

     if @NumYears < 10
        begin
        select @ExEmprCont = @EmpCont,@EmprRate = 7.50
        end
     else if @NumYears >= 10 and @NumYears < 20
        begin
        select @ExEmprCont = @Salary * (11.25/100.00),@EmprRate = 11.25
        end
     else if @NumYears >= 20
        begin
        select @ExEmprCont = @Salary * (15.00/100.00),@EmprRate = 15.00  
        end

     if (@ExEmprCont - @EmprCont) <> 0
        Insert Into #Empr_Expected_vs_Actual(SchemeName,MemberNo,PayrollNo,
                                          FullName,ContrMonth,ContrYear,
                                          MonthName,StartDate,Salary,EmpCont,
                                          ExEmprCont,EmprCont,ExVariance,
                                          EmprRate,Pensionable,EndDate)
                                  Values(@SchemeName,@MemberNo,@PayrollNo,
                                         @FullName,@ContrMonth,@ContrYear,
                                         @MonthName,@StartDate,@Salary,@EmpCont,
                                         @ExEmprCont,@EmprCont,@ExEmprCont - @EmprCont,
                                         @EmprRate,@NumYears,@EndDate) 

     Select @MemberNo =0,@Salary=0,@EmpCont=0,@EmprCont=0,@ContrMonth=0,@ContrYear=0,@PayrollNo='',@FullName='',@ExEmprCont=0,
     @EmprRate = 0,@NumYears = 0

     Fetch next from ExCsr into @MemberNo,@Salary,@EmpCont,@EmprCont,@MissDate,@ContrMonth,@ContrYear,@PayrollNo,@djScheme,@FullName
   end
   Close ExCsr
   Deallocate Excsr

end

Select * from #Empr_Expected_vs_Actual
go

