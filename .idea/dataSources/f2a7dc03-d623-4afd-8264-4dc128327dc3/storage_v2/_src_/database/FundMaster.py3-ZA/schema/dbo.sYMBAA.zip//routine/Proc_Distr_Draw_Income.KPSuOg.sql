CREATE PROCEDURE [dbo].[Proc_Distr_Draw_Income]  /* [Proc_Distr_Draw_Income] 1325,9 */       
@schemeNo Int,            
@AcctPeriod Int            
--with Encryption            
as            
declare @DrawDown float,@TotalBal float,@BalanceBf float,@MemberNo int,@NumMonths int,@DrawInt float,@MonInstal float,@TransDate datetime            
      
/* TransDate added to pick drawdown income at Year End */       
select @TransDate = Enddate from schemeYears where schemeNo = @schemeNo and AcctPeriod  = @AcctPeriod       
            
select @DrawDown = DrawDown from DistributionBalances where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod       
and TransDate  = @TransDate           
           
if @DrawDown is null select @DrawDown = 0            
                  
select @TotalBal = sum(BalanceBF - DrawInt) from TBL_Draw_Down where schemeNo = @SchemeNo and AcctPeriod = @AcctPeriod            
and CloseBal = 1 and BalanceBF > 0 and DrawInt >= 0 and EndDate >= @TransDate          
            
if @TotalBal is null select @TotalBal = 0       
      
print @TotalBal           
            
if @TotalBal > 0          
BEGIN            
declare dcsr cursor for            
select memberNo,BalanceBF - DrawInt from TBL_Draw_Down where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and CloseBal = 1            
and BalanceBF > 0 and DrawInt >= 0 and EndDate >= @TransDate           
            
open dcsr            
fetch from dcsr into @MemberNo,@BalanceBf            
while @@fetch_Status = 0            
begin            
   /* Allocate Income */            
   select @DrawInt = (@BalanceBf/@TotalBal)* @DrawDown            
            
   /* Get Number of Instalments remaining */            
   select @NumMonths = NumMonths from TBL_Draw_Down where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod + 1 and CloseBal = 0            
            
   select @MonInstal  = (@BalanceBf + @DrawInt)/cast(@NumMonths as float)            
            
   /* Update Closing Balance for Prior Year */            
   update TBL_Draw_Down set DrawInt = @DrawInt,BalanceBF = (BalanceBF - DrawInt) + @DrawInt,MonInstal = @MonInstal            
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod and CloseBal = 1             
            
   /* Update Closing Balance for Current Year */            
   update TBL_Draw_Down set DrawInt = @DrawInt,BalanceBF = (BalanceBF - DrawInt) + @DrawInt,MonInstal = @MonInstal            
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod + 1 and CloseBal = 0            
            
   /* Update Monthly Pension */            
   --Update Pensioner set MonPension = @MonInstal where schemeNo = @schemeNo and MemberNo = @MemberNo            
            
   select @MemberNo=0,@BalanceBf=0            
   fetch next from dcsr into @MemberNo,@BalanceBf            
end            
close dcsr            
deallocate dcsr           
END 

Update TBL_Draw_Down set DrawInt = 0,BalanceBF = 0 where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and CloseBal = 1            
and BalanceBF < 0 and DrawInt < 0
go

