CREATE PROCEDURE [dbo].[Import_Bond_Prices]          
@schemeNo int,       
@InvestNo int,         
@ValuationDate datetime,          
@Term int,          
@YieldRate float,          
@bidPrice float,    
@DirtyPrice float,        
@GovComm int          
--with Encryption          
as          
          
delete from TBL_Bond_Valuation_Rates where schemeNo = @schemeNo and ValuationDate = @ValuationDate and Term = @Term         
and GovComm = @GovComm and InvestNo = @InvestNo         
          
Insert into TBL_Bond_Valuation_Rates(schemeNo,InvestNo,ValuationDate,Term,YieldRate,BidPrice,DirtyPrice,Status,GovComm)          
                           Values(@schemeNo,@InvestNo,@ValuationDate,@Term,@YieldRate,@BidPrice,@DirtyPrice,0,@GovComm)
go

