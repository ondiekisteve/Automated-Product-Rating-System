CREATE PROCEDURE [dbo].[Proc_Calc_IPP_Penalty_Def]
@SCHEMENO Int,  
@MemberNo Int,
@Reg Int,  
@Penalty float Out  
--with Encryption  
as  
  
declare @NumYears Int,@NumMonths Int,@NumDays Int,@djpens datetime,@DoExit Datetime,@Benefit float,  
@PenaltyRate float  
select @djpens = djpens,@DoExit = DoExit from Members where schemeNo = @schemeNo and MemberNo = @MemberNo  
Exec GetServiceTime @djpens,@doExit,@NumYears Out,@NumMonths Out,@NumDays Out  
if @Reg = 0 /* Registered */
   select @Benefit = DeferredCBal from Benefits where schemeNo = @schemeNo and MemberNo = @MemberNo
else
   select @Benefit = DeferredCBal from UnRegisteredBenefits where schemeNo = @schemeNo and MemberNo = @MemberNo  

if @Benefit is null select @Benefit = 0
  
select @PenaltyRate = PenaltyRate from TBL_IPP_Penalty  
where schemeNo = @schemeNo and StartYear <= @NumYears and EndYear > @NumYears  
  
if @PenaltyRate is null select @PenaltyRate = 0.0  
  
if @PenaltyRate = 0  
   select @Penalty = 0  
else  
   select @Penalty = @Benefit * (@PenaltyRate/100.00)
go

