CREATE PROCEDURE [dbo].[calcTransfers]
@SCHEMENO Int,
@CurMonth int,
@curyear int
--with Encryption
as
declare @memberNo int
declare @totEmp float
declare @totEmpr float
declare @totVol float
declare @totSpecial float
declare @CalculationMode int
declare @hasBal bit
declare @PretotEmp float
declare @PretotEmpr float

begin tran

declare @funcResult int, @currYear int, @yearClosed bit, @retCode int, @AcctPeriod int, @PeriodToUse int,
@PercLocked float,@UnLockDate Datetime,@TransferValue float,@LockedValue float,@LastDate Datetime,
@Transfer float,@LockedIn float,@CTransfer float,@CLockedIn float

exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out

Exec GetLastDate @CurMonth,@CurYear,@LastDate Out

Select @PeriodToUse = @AcctPeriod - 1

select @CalculationMode = CalculationMode from Scheme where schemeCode = @schemeNo

declare membersCsr cursor for
select m.MemberNo,t.Transfer,t.LockedIn,t.UnLockDate 
from Members m
     Inner Join MemberOpeningBalances t on m.schemeNo = t.schemeNo and m.MemberNo = t.MemberNo
     and t.AcctPeriod = @PeriodToUse
where
(m.SchemeNo = @SchemeNo) and
((m.ReasonForExit = 0) or ((m.ReasonforExit > 0) and (DatePart(Year,m.DoExit) > @CurYear)))

order by m.MemberNo

open membersCsr

fetch next from membersCsr
into @memberNo,@Transfer,@LockedIn,@UnLockDate
while (@@fetch_status = 0)
begin
     if @Transfer is null select @Transfer = 0
     if @LockedIn is null select @LockedIn = 0

     exec [dbo].[Proc_CalcMonthlyInterest_BalTransfer] @schemeNo,@memberNo,@CurMonth,@currYear,1,@Transfer,@LockedIn,
     @CTransfer output,@CLockedIn output
     
     if @LastDate > @UnlockDate
        select @TransferValue = @CTransfer,@LockedValue = @CLockedIn 
     else
        select @TransferValue = @CTransfer + @CLockedIn,@LockedValue = 0 
     
   if Not Exists (Select * from Benefits where SchemeNo = @schemeNo and MemberNo = @MemberNo)
      Insert Into Benefits (SchemeNo,MemberNo,TransferValue,LockedInValue)
              Values (@SchemeNo,@MemberNo,@TransferValue,@LockedValue)
   else
      update Benefits set TransferValue = @TransferValue,LockedInValue= @LockedValue
      where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)            
  
  select @hasBal = 0, @totEmp= 0, @totEmpr= 0, @totVol=0, @totSpecial=0,@PercLocked= 0,@TransferValue=0
                
  fetch next from membersCsr
  into @memberNo,@Transfer,@LockedIn,@UnLockDate
end
close membersCsr
deallocate membersCsr


commit Tran
go

