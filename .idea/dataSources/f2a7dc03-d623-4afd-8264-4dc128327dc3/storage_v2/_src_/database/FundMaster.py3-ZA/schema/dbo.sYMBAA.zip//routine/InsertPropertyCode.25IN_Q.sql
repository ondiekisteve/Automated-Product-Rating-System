CREATE PROCEDURE [dbo].[InsertPropertyCode]  
@SCHEMENO Int,  
@InvCode int,  
@PropertyName Varchar(100),  
@PropertyType Int,  
@OriginalCost Decimal(20,6),  
@PropDescription varchar(100)  
--with Encryption  
as 

Declare @CurrCode Int
select @CurrCode = CurrCode from Scheme where SchemeCode = @SCHEMENO
 
insert into property (SchemeNo, PropertyCode,PropertyName,PropertyType,OriginalCost,PropDescription,CurrencyType)  
            Values (@schemeNo,@InvCode,@PropertyName,@PropertyType,@OriginalCost,@PropDescription,@CurrCode)  
  
  
Insert into Assets (schemeNo,AssetNo,AssetRefNo,AssetClass,AssetName,AssetDesc,OriginalCost,AssetDate)  
            Values(@schemeNo,@InvCode,@InvCode,0,@PropertyName,@PropDescription,0,GetDate())
go

