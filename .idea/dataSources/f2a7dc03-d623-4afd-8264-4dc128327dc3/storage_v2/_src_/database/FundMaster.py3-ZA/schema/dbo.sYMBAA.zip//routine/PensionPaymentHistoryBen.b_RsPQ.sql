CREATE PROCEDURE [dbo].[PensionPaymentHistoryBen]
@SCHEMENO Int,
@memberNo int,
@DepCode int
--with Encryption
as

select s.SchemeName, p.schemeNo, p.PenNo as memberNo,
p.payMonth, p.payYear, p.gross, p.tax, p.net,
(upper(mm.sname) +' ,'+mm.fname +'  '+mm.oname) as fullname,  m.monthname
from pensionpayrollBen p
inner join Dependants mm on p.schemeNo = mm.schemeNo and p.memberNo = mm.memberNo
and p.DependantCode = mm.DependantCode
inner join MonthTable m on p.payMonth = m.monthNumber
inner Join Scheme s on p.SchemeNo = s.schemeCode
Where p.SchemeNo = @schemeNo and p.memberNo = @memberNo and p.DependantCode = @DepCode
order by p.payYear, p.payMonth
go

