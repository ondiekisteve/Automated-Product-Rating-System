CREATE PROCEDURE [dbo].[benefDetails] 
--with Encryption 
as select
Dependants.SchemeNo, Dependants.MemberNo, Dependants.Sex,
Dependants.FName, Dependants.SName, Dependants.OName, Dependants.IDNumber,
Dependants.Address, Dependants.Location, Dependants.Town, Dependants.Country,
Dependants.DOB, Dependants.DepStatus, Dependants.NFComplete, Dependants.PcntBenefit,
Dependants.MStatus, Dependants.NBeneficiary, Dependants.DoApmt, Dependants.DoCancellation,
DependantType.TypeDesc
from Dependants
inner join DependantType on Dependants.DependantType = DependantType.TypeCode
go

