CREATE PROCEDURE [dbo].[InsertPenBatchRevision]        
@SCHEMENO Int,        
@RevDate Datetime,        
@BackDateTO Datetime,        
@RevCriteria Integer,/* Criteria to use e.g All,between 2 given dates e.t.c */        
@RevMode Integer, /* Revision Mode i.e By Factor,by Value,to a Fixed Value */        
@StartDate datetime,        
@EndDate datetime,        
@MinPension float,        
@MaxPension float,        
@RevFactor float,        
@BatchMode int,        
@PenBeneficiary int /* Pensioner(0),MemBeneficiary(1), PenBeneficiary(2) */        
--with Encryption        
as        
   declare @Factor varchar(20),@sDate varchar(20),@eDate varchar(20),        
   @aPension varchar(20),@zPension varchar(20)        
                          
   select @Factor = cast(@RevFactor as Varchar(20)),@sDate = cast(@StartDate as varchar(20)),        
          @eDate = cast(@EndDate as varchar(20)),@aPension = cast(@MinPension as varchar(20)),        
          @zPension = cast(@MaxPension as Varchar(20))        
        
   if @RevMode = 0        
      select @Factor = 'By '+@Factor        
   else if @RevMode = 1        
      select @Factor = 'By '+@Factor+' %'        
   else if @RevMode = 2        
      select @Factor = 'To '+@Factor        
        
   If @PenBeneficiary = 0 /* Pensioners */        
   begin        
       if @RevCriteria = 0        
          begin        
             if Exists(select * from PenBatchRevision         
                where SchemeNo = @schemeNo and         
                RevDate = @RevDate and BackDateTo = @BackDateTO and RevCriteria = @RevCriteria         
                and RevMode = @RevMode and PenBeneficiary = @PenBeneficiary and RevFactor = @RevFactor)        
                begin        
                     raiserror('Pension Batch Revision at %s has already been processed',16,1,@Factor)        
                     return        
                end        
             else        
                insert into PenBatchRevision (schemeNo, RevDate,BackDateTo,RevCriteria,        
                              RevMode,StartDate,EndDate, MinPension,MaxPension,RevFactor,BatchMode,PenBeneficiary)        
                   Values(@schemeNo, @RevDate,@BackDateTo,@RevCriteria,        
                          @RevMode,@StartDate,@EndDate, @MinPension,@MaxPension,@RevFactor,@BatchMode,@PenBeneficiary)        
         end        
       else if @RevCriteria = 1 /*Retirements between 2 given dates */        
         begin        
            if Exists(select * from PenBatchRevision         
                where SchemeNo = @schemeNo and         
                RevDate = @RevDate and BackDateTo = @BackDateTO and RevCriteria = @RevCriteria         
                and RevMode = @RevMode and PenBeneficiary = @PenBeneficiary        
                and StartDate = @StartDate and EndDate = @EndDate)        
                begin        
                     raiserror('Pension Batch Revision %s for Retirements between %s and %s has already been processed',16,1,@Factor,@sDate,@eDate)        
                     return        
                end        
             else        
                insert into PenBatchRevision (schemeNo, RevDate,BackDateTo,RevCriteria,        
                              RevMode,StartDate,EndDate, MinPension,MaxPension,RevFactor,BatchMode,PenBeneficiary)        
                   Values(@schemeNo, @RevDate,@BackDateTo,@RevCriteria,        
                          @RevMode,@StartDate,@EndDate, @MinPension,@MaxPension,@RevFactor,@BatchMode,@PenBeneficiary)        
         end        
      else if @RevCriteria = 2 /*Pension with a given Bracket */        
         begin        
            if Exists(select * from PenBatchRevision         
                where SchemeNo = @schemeNo and         
                RevDate = @RevDate and BackDateTo = @BackDateTO and RevCriteria = @RevCriteria         
                and RevMode = @RevMode and PenBeneficiary = @PenBeneficiary        
                and MinPension = @MinPension and MaxPension = @MaxPension)        
                begin        
                     raiserror('Pension Batch Revision %s for Pension between %s and %s has already been processed',16,1,@Factor,@aPension,@zPension)        
                     return        
                end        
             else        
                insert into PenBatchRevision (schemeNo, RevDate,BackDateTo,RevCriteria,        
                              RevMode,StartDate,EndDate, MinPension,MaxPension,RevFactor,BatchMode,PenBeneficiary)        
                   Values(@schemeNo, @RevDate,@BackDateTo,@RevCriteria,        
                          @RevMode,@StartDate,@EndDate, @MinPension,@MaxPension,@RevFactor,@BatchMode,@PenBeneficiary)        
         end        
     else if @RevCriteria = 3 /*Retirements between 2 given dates Pension with a given Bracket */        
         begin        
            if Exists(select * from PenBatchRevision         
                where SchemeNo = @schemeNo and         
                RevDate = @RevDate and BackDateTo = @BackDateTO and RevCriteria = @RevCriteria         
                and RevMode = @RevMode and PenBeneficiary = @PenBeneficiary        
                and MinPension = @MinPension and MaxPension = @MaxPension and StartDate = @StartDate and EndDate = @EndDate)        
                begin        
                     raiserror('Pension Batch Revision %s for Retirements between %s and %s and Pension between %s and %s has already been processed',16,1,@Factor,@SDate,@eDate,@aPension,@zPension)        
                     return        
                end        
             else        
                insert into PenBatchRevision (schemeNo, RevDate,BackDateTo,RevCriteria,        
                              RevMode,StartDate,EndDate, MinPension,MaxPension,RevFactor,BatchMode,PenBeneficiary)        
                   Values(@schemeNo, @RevDate,@BackDateTo,@RevCriteria,        
                          @RevMode,@StartDate,@EndDate, @MinPension,@MaxPension,@RevFactor,@BatchMode,@PenBeneficiary)        
         end        
   end        
else if @PenBeneficiary = 1 /* Beneficiaries Revision */        
   begin        
        if Exists(select * from PenBatchRevision         
                where SchemeNo = @schemeNo and         
                RevDate = @RevDate and BackDateTo = @BackDateTO and RevCriteria = @RevCriteria         
                and RevMode = @RevMode and PenBeneficiary = @PenBeneficiary and RevFactor = @RevFactor)        
                begin        
                     raiserror('Pension Batch Revision %s has already been processed',16,1,@Factor)        
                     return        
                end        
             else        
                insert into PenBatchRevision (schemeNo, RevDate,BackDateTo,RevCriteria,        
                              RevMode,StartDate,EndDate, MinPension,MaxPension,RevFactor,BatchMode,PenBeneficiary)        
                   Values(@schemeNo, @RevDate,@BackDateTo,@RevCriteria,        
                          @RevMode,@StartDate,@EndDate, @MinPension,@MaxPension,@RevFactor,@BatchMode,@PenBeneficiary)        
        
          
   end
go

