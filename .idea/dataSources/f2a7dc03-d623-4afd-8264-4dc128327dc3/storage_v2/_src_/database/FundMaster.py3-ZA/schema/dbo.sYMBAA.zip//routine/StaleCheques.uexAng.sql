CREATE PROCEDURE [dbo].[StaleCheques](@SCHEMENO Int,@BankCode int,@BankMonth Int,@BankYear Int)              
as        
if object_id('tempdb..#tbl_var') is null                                                                       
begin                                        
create table #tbl_var        
             (Counter Int Identity(1,1) primary Key,        
              SchemeName Varchar(100),          
                       BankName varchar(100),          
                       TransDate Datetime,          
                       VoucherNo Int,          
                       ChequeNo varchar(20),          
                       Description varchar(150),          
                       Credit float,          
                       Months Int,          
                       AsAtDate Datetime          
                       )         
end         
            
 declare @EndDate Datetime            
            
 Exec GetLastDate @BankMonth,@BankYear,@EndDate Out            
        
 /* Cashbook Cheques */        
 Insert into #tbl_var           
      select s.SchemeName, b.BankName, c.TransDate,c.VoucherNo,c.ChequeNo,c.Description,c.Credit,            
       DateDiff(Month,c.TransDate,@EndDate) as Months,@EndDate as AsAtDate            
      from cashBook c            
         inner Join Scheme s on c.schemeCode = s.schemeCode             
         inner join SchemeBankBranch b on c.schemeCode = b.schemeNo and c.BankCode = b.BankCode            
      where c.schemeCode = @SchemeNo and c.BankCode = @BankCode             
     and c.Credit > 0 and Len(lTrim(c.ChequeNo)) > 0 and c.Cleared = 0            
     and DateDiff(Month,c.TransDate,@EndDate) >= 6 AND C.Tran_Status = 0 AND C.Posted = 1      
     order by c.ChequeNo         
 /* Unpresented Cheques */        
 Insert into #tbl_var           
      select s.SchemeName, b.BankName, c.TransDate,0,c.ChequeNo,c.Particulars,c.Credit,            
       DateDiff(Month,c.TransDate,@EndDate) as Months,@EndDate as AsAtDate            
      from UnPresentedCheques c            
         inner Join Scheme s on c.schemeCode = s.schemeCode             
         inner join SchemeBankBranch b on c.schemeCode = b.schemeNo and c.BankCode = b.BankCode            
      where c.schemeCode = @SchemeNo and c.BankCode = @BankCode             
     and c.Credit > 0 and Len(lTrim(c.ChequeNo)) > 0 and c.Cleared = 0            
     and DateDiff(Month,c.TransDate,@EndDate) >= 6              
     order by c.ChequeNo         
        
select * from #tbl_var Order by ChequeNo
go

