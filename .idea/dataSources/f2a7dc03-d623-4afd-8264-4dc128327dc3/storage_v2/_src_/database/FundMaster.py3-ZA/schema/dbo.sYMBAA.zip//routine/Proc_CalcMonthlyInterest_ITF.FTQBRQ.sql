CREATE PROCEDURE [dbo].[Proc_CalcMonthlyInterest_ITF]        
@SCHEMENO Int,        
@memberNo int,        
@Proc_Date datetime,   
@totEmpCont float output,        
@totEmprCont float output,        
@totVolContr float output,        
@totSpecialContr float output,       
@totEmpTransfer float output,        
@totEmprTransfer float output,        
@totPreEmpCont float output,        
@totPreEmprCont float output,        
@totPreAVC float output        
--with Encryption        
as        
        
set nocount on        
        
if object_id('tempdb..#Balances') is null          
          
begin          
create table #Balances          
(          
        [EmpCode][Int] Identity(1,1) PRIMARY KEY,          
        [DatePaid] [Datetime] not null,           
        [EmpCont] [float] not  NULL default 0.0,          
        [EmprCont] [Float] null default 0.0,          
        [EmprVolCont][float] not null default 0.0,          
        [EmpVolCont][float] not null default 0.0,            
        [InterestRate][float] null         
)                      
end          
          
Declare @AcctPeriod int,@PeriodtoUse int, @eDate datetime, @sDate datetime,           
@FiscalType Int,@startMonth int,@empCont float,@emprCont float,@specialContr float,@volContr float,          
@CempCont Decimal(20,6),@CemprCont Decimal(20,6),@CspecialContr Decimal(20,6),@CvolContr Decimal(20,6),                   
@TempEmp float,@TempEmpr float, @TempVol float, @TempSpecial float, @TempEmp1 float,          
@TempEmpr1 float, @TempVol1 float, @TempSpecial1 float,@xMonth int,@xYear int,          
@TotInt float,@UseBalances bit,          
@EmpInt float,@EmprInt float,@VolInt float,@SpecInt float,
@ArEmpCont float,@ArEmprCont float,@ArVolCont float,@ArSpecial float,@ArDate Datetime,          
@trEmpCont float,@trEmprCont float,@trDate Datetime,@InTerest float,@NewPower float,          
@EmpOpening float,@EmprOpening float,@Taxtype Int,@FiscalMode smallInt,          
@sumEmp float,@sumEmpr float, @sumVol float,@sumSpec float, @ChekiInt float,          
@SMonthDate Datetime,@EMonthDate Datetime,@fMonth Int,@fYear Int,@FirstDate Datetime,@OptionToUse Int,          
@NumYearsIn Int,@NumMonthsIn Int,@NumDaysIn Int,@Month Int,@Year Int,@InterestRate float,          
@LastMonthDate Datetime,@StartMonthDate Datetime,@EmpFeesPre float,@EmprFeesPre float,          
@EmpFeesPost float,@EmprFeesPost float,@IntMode Int,@EndDate datetime,@AdminFees float,          
@AdminEmp float,@AdminEmpr Float,@AdminVol float,          
@AdminSpec float,@EmpArrears float,@EmprArrears float,@FeesReg float,@FeesUnReg float,          
@DistrEmp float,@DistrEmpr float,@DistrAVC float,@DistrSpec float /* Reserve Distribution */,          
@CalcAdminFees Int,@YaMwisho Datetime,@ShowAdmin smallInt,@OpeningBal float,@StatusCode Int,        
@CalcYear Int,@CalcMonth Int,  
@Income_Id int,@cempTransfer float, @cEmprTransfer float,@OpeningBalR float,@SponsorCode Int,@SchemeMode smallInt 

select @CalcMonth = DatePart(Month,@Proc_Date),@CalcYear = DatePart(Year,@Proc_Date) 

select @SchemeMode = schemeMode from scheme where schemeCode = @schemeNo

if @schemeMode is null select @schemeMode = 0

if @SchemeMode = 0
   begin
   select @Income_Id = Max(Income_Id) from tbl_itf_income where schemeNo = @schemeNo and TransDate <= @Proc_Date

   select @SponsorCode = 0
   end  
else if @SchemeMode = 1
   begin

   select @sponsorCode = SponsorCode from members where schemeNo = @schemeNo and MemberNo = @MemberNo

   select @Income_Id = Max(Income_Id) from tbl_itf_income where schemeNo = @schemeNo and TransDate <= @Proc_Date  
   AND SPONSORCODE = @SPONSORCODE 

   end       


if @StatusCode is null select @StatusCode = 0        
          
/* For Britak Prior to 2004 use 1/12 other than root 12 */          
        
          
select @CalcAdminFees = Calc_Admin_Fees from ConfigYearEnd where schemeNo = @schemeNo          
          
if @CalcAdminFees is null select @CalcAdminFees = 0 
         
select @sumEmp = 0,@sumEmpr = 0, @sumVol = 0,@sumSpec = 0,@ChekiInt = 0          
 
Exec GetLastDate @CalcMonth,@CalcYear,@EndDate Out
          
if @AdminFees is null select @AdminFees = 0          
          
exec GetAccountingPeriodInAYear @schemeNo, @CalcMonth, @calcYear, @AcctPeriod out          
          
Select @sDate = StartDate,@YaMwisho = EndDate, @FiscalMode = FiscalMode           
from SchemeYears where SchemeNo = @schemeNo  and AcctPeriod = @AcctPeriod          
          
Select @PeriodToUse = @AcctPeriod - 1          
          
select @EMonthDate = @EndDate           
          
if exists(select * from MemberOpeningBalances where SchemeNo = @schemeNo and memberNo = @memberNo 
and AcctPeriod = @PeriodToUse)          
begin          
   Select @UseBalances = 1          
end          
          
Select @UseBalances = 1          
          
if @useBalances = 1          
   begin          
     Select @SMonthDate = @sDate          
   end          
else          
   begin          
     Select @sDate = Min(DatePaid) from Contributionssummary          
     where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod          
          
     select @fMonth = DatePart(Month,@sDate),@fYear = DatePart(Year,@sDate)          
          
     Exec GetFirstDate @fMonth,@fYear,@FirstDate Out          
          
     Select @SMonthDate = @FirstDate          
   end          
/* Initialize all variables to Zero */          
Select @CempCont  = 0          
Select @CemprCont = 0          
Select @CspecialContr = 0          
Select @CvolContr = 0     
Select @CEmpTransfer = 0,@CEmprTransfer = 0       
Select @CvolContr = 0         
Select @TempEmp  = 0          
Select @TempEmpr = 0          
Select @TempSpecial= 0          
Select @TempVol = 0          
select @TempEmp1 = 0          
select @TempEmpr1 = 0          
select @TempVol1 = 0           
select @TempSpecial1 = 0          
                   
if @useBalances = 1          
   begin          
       
         select @totEmpCont = EmpCont + Transfer, @totEmprCont = EmprCont + LockedIn,          
         @totVolContr = EmpVolCont,           
         @totSpecialContr = EmprVolCont,    
         @AdminEmp = EmpFees,@AdminEmpr = EmprFees,          
         @AdminVol = VolFees,@AdminSpec = SpecFees          
         from MemberOpeningBalances          
         where SchemeNo = @schemeNo           
         and memberNo = @memberNo          
         and AcctPeriod = @PeriodToUse      
  
         IF @DistrEmp is null select @DistrEmp = 0          
         IF @DistrEmpr is null select @DistrEmpr = 0          
         IF @DistrAVC is null select @DistrAVC = 0          
         IF @DistrSpec is null select @DistrSpec = 0          
   end          
else          
  select @totEmpCont = 0, @totEmprCont = 0,          
  @totVolContr = 0, @totSpecialContr = 0,@totEmpTransfer = 0, @totEmprTransfer = 0          
          
  if @totEmpCont is null select @totEmpCont = 0          
  if @totEmprCont is null select @totEmprCont = 0          
  if @totVolContr is null select @totVolContr = 0          
  if @totSpecialContr is null select @totSpecialContr = 0     
  if @totEmpTransfer is null select @totEmpTransfer = 0          
  if @totEmprTransfer is null select @totEmprTransfer = 0        
          
  if @AdminEmp is null  select @AdminEmp = 0.0          
  if @AdminEmpr is null  select @AdminEmpr = 0.0          
  if @AdminVol is null  select @AdminVol = 0.0          
  if @AdminSpec is null  select @AdminSpec = 0.0          
          
  IF @DistrEmp is null select @DistrEmp = 0          
   IF @DistrEmpr is null select @DistrEmpr = 0          
   IF @DistrAVC is null select @DistrAVC = 0          
   IF @DistrSpec is null select @DistrSpec = 0          
          
  select @totEmpCont = (@totEmpCont + @DistrEmp)- @AdminEmp,          
  @totEmprCont = ( @totEmprCont + @DistrEmpR )- @AdminEmpr,          
  @totVolContr = (@totVolContr + @DistrAVC) - @AdminVol,          
  @totSpecialContr = (@totSpecialContr + @DistrSpec) - @AdminSpec          
          
select @EmpOpening = @totEmpCont + @totVolContr,          
@EmprOpening = @totEmprCont + @totSpecialContr    
     
select @OpeningBal = @EmpOpening, @OpeningBalR = @EmprOpening  
  
  /*Initialize the Opening Balances */          
  select @cEmpCont = @totEmpCont          
  select @cEmprCont = @totEmprCont          
  select @cSpecialContr = @totSpecialContr          
  select @cVolContr = @totVolContr    
  select @cEmpTransfer = @totEmpTransfer          
  select @cEmprTransfer = @totEmprTransfer                           
/* Contributions */   
   Insert Into #Balances select Distinct(c.DatePaid), sum(c.EmpCont) , sum(c.EmprCont) , sum(c.SpecialContr)          
                              , sum(VolContr), 0.0          
   from ContributionsSummary c               
   WHERE  c.SchemeNo = @SchemeNo and c.MemberNo = @MemberNo           
   and c.DatePaid >= @sDate  and c.DatePaid <= @EndDate and c.AcctPeriod = @acctPeriod          
   Group by c.DatePaid          
   order by c.DatePaid             
        
          
/* add Any Contribution Arrears */          
     Insert into #Balances Select distinct(c.DatePaid),sum(c.ArEmpCont),Sum(c.ArEmprCont),sum(c.ArSpecial),sum(c.ArVolContr),          
     0.0          
     from ContributionArrears c                
     where c.SchemeNo = @SchemeNo and c.MemberNo = @MemberNo          
     and c.DatePaid >= @sDate  and c.DatePaid <= @EndDate and c.AcctPeriod = @acctPeriod          
     Group by c.DatePaid          
     order by c.DatePaid                 
       
/*End of Contributions Arrears */          
          
/* add Any Transfers*/          
          
     Insert into #Balances Select distinct(c.TransferDate),sum(c.EmpTransfer),Sum(c.EmprTransfer),sum(c.avcerTransfer),Sum(c.AVCTransfer),          
     0.0           
     from MemberTransfer c          
              
     where c.SchemeNo = @SchemeNo and c.MemberNo = @MemberNo          
     and c.TransferDate >= @sDate  and c.TransferDate <= @EndDate and c.AcctPeriod = @acctPeriod          
     Group by c.TransferDate         
     order by c.TransferDate                 
/* for a Member without  Contributions */
           
            
   declare @MwanzoDate datetime,@MwishoDate datetime            
   select @MwanzoDate = @sDate,@MwishoDate = @eDate            
   while @Mwanzodate<= @MwishoDate            
   begin            
        Select @xMonth = DatePart(Month,@MwanzoDate)            
        Select @xYear = DatePart(Year,@MwanzoDate)                          
        Exec GetLastDate @xMonth,@xYear,@LastMonthDate Out            
                    
        if Not Exists (Select * from #Balances where DatePaid >= @MwanzoDate and DatePaid <= @LastMonthDate)            
           begin            
               Insert Into #Balances             
               select @MwanzoDate, 0,0,0,0,0.0            
                              
           end            
        select @MwanzoDate = DateAdd(Month,1,@MwanzoDate)            
   end            
                  
          
         
        while @SMonthDate <= @EMonthDate          
        begin          
       
          
               /* Pick all the Contributions in a given Month */          
                        Select @xMonth = DatePart(Month,@SMonthDate)          
                        Select @xYear = DatePart(Year,@SMonthDate)          
          
                        Exec GetFirstDate @xMonth,@xYear,@StartMonthDate Out          
                        Exec GetLastDate @xMonth,@xYear,@LastMonthDate Out   
  
                        if @SponsorCode = 0
                           select @Income_Id = Max(Income_Id) from tbl_itf_income where schemeNo = @schemeNo    
                           and TransDate >= @StartMonthDate and TransDate <= @LastMonthDate  
                        else 
                           select @Income_Id = Max(Income_Id) from tbl_itf_income where schemeNo = @schemeNo    
                           and TransDate >= @StartMonthDate and TransDate <= @LastMonthDate  
                           AND SPONSORCODE = @SPONSORCODE        
                        /* Contributions for the Month */          
                        select @empCont = sum(EmpCont), @emprCont = sum(EmprCont), @specialContr = sum(EmprVolCont),           
                               @volContr = sum(EmpVolCont)          
                        from #Balances           
                        where DatePaid  >= @StartMonthDate and DatePaid <= @LastMonthDate          
          
                   
                                       
                        if @empCont is null select @empCont = 0          
                        if @emprCont is null select @emprCont = 0          
                        if @specialContr is null select @specialContr = 0          
                        if @volContr is null select @volContr = 0          
          
                        select @cEmpCont = (@cEmpCont + @empCont)          
                        select @cEmprCont = (@cEmprCont + @emprCont)          
                        select @cSpecialContr = (@cSpecialContr + @specialContr)          
                        select @cVolContr = (@cVolContr + @volContr)             
          
                          
                                
                        Select @EmpInt = sum(EmpInt + eeTransferInt),@EmprInt = sum(EmprInt + ErTransferInt),  
                        @VolInt = sum(AVCInt),@SpecInt = sum(AVCERInt)  
                        from TBL_Itf_Distribution where schemeNo = @schemeNo and MemberNo = @MemberNo  
                        and Income_Id = @Income_Id  

                        
                        if @EmpInt is null select @EmpInt = 0  
                        if @EmprInt is null select @EmprInt = 0  
                        if @VolInt is null select @VolInt = 0  
                        if @SpecInt is null select @SpecInt = 0  
                                 
                        /* Add Contributions paid after 15 th Less Expenses paid after 15 th */          
                        select @cEmpCont = (@cEmpCont + @EmpInt)          
                        select @cEmprCont = (@cEmprCont + @EmprInt)          
                        select @cVolContr = @cVolContr + @VolInt          
                        select @cSpecialContr = @cSpecialContr + @SpecInt          
                        select @OpeningBal = @cEmpCont +  @cVolContr ,@OpeningBalR = @cEmprCont + @cSpecialContr  

                        select @EmpFeesPost = 0.0,@EmprFeesPost = 0.0,@TempEmp = 0,@TempEmpr=0.0,@TempVol=0.0,          
                        @TempSpecial = 0.0,@NewPower = 0.0,@EmpInt = 0.0,@EmprInt = 0.0,@VolInt = 0.0,@SpecInt = 0.0,          
                        @EmpFeesPre = 0.0,@EmprFeesPre = 0.0,@EmpArrears = 0,@EmprArrears = 0          
                                    
         
                        Select @SMonthDate = DateAdd(Month,1,@SMonthDate)           
                end          
                          
       
if @totEmpTransfer is null select @totEmpTransfer = 0
if @totEmprTransfer is null select @totEmprTransfer = 0
if @totPreEmpCont is null select @totPreEmpCont = 0
if @totPreEmprCont is null select @totPreEmprCont = 0    
if @totPreAVC is null select @totPreAVC = 0      
       
select @totEmpCont  = @cEmpCont, @totEmprCont = @cEmprCont,@totVolContr = @cVolContr,@totSpecialContr= @cSpecialContr
go

