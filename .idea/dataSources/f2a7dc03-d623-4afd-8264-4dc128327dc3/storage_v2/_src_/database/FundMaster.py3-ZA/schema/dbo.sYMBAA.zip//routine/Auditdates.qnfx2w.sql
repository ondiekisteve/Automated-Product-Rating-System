CREATE PROCEDURE [dbo].[Auditdates]
@schemeNo  varchar(15)
--with Encryption
as
declare @auditdate datetime

/*if (select count(*) from auditHistory where SchemeNo = @schemeNo) = 0 return*/
select @auditDate = max(auditDate) from AuditHistory where SchemeNo = @schemeNo

select @auditdate
go

