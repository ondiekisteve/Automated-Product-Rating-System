CREATE TRIGGER [dbo].[Trg_ContributionArrears] ON [dbo].[ContributionArrears] 
--with encryption
for insert
as

declare @schemeNo Int,@MemberNo Int,@BatchId Int,@Counter bigInt,@UserName varchar(60) 

select @schemeNo  = SchemeNo,@MemberNo = MemberNo,@BatchId = BatchId,@Counter = Counter from Inserted

select @UserName = user  

if @BatchId is null select @BatchId = 0

if @BatchId = 0
   Exec Proc_Auto_Insert_InvPosting @schemeNo,@MemberNo,21,311,@Counter,0,@UserName
go

