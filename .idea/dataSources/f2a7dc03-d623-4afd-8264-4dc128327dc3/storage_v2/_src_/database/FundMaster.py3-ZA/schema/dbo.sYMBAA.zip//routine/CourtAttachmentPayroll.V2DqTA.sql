CREATE PROCEDURE [dbo].[CourtAttachmentPayroll]
@SCHEMENO Int,
@PayMonth int,
@PayYear int
--with Encryption
as

if object_id('tempdb..#CourtPayroll') is null

begin
create table #CourtPayroll
(
	[SchemeName] [varchar] (100) NOT NULL ,
	[AttacheeNo] [int] NOT NULL ,
	[Attachee] [varchar](70) NOT NULL ,
	[Address] [varchar](50) null ,
             [Town] [varchar](50)NULL,
	[PayPoint] [varchar] (50) NULL ,
	[PayPointAddress] [varchar](50)  NULL,
             [PayPointTown][Varchar](50) null,
             [Attachment][float]null,
             [MonthName][varchar](25) null          
) 

ALTER TABLE #CourtPayroll WITH NOCHECK ADD 

            
	CONSTRAINT [PK_CourtPayroll] PRIMARY KEY  NONCLUSTERED 
	(
		
		[AttacheeNo]      
	) 
end

declare @schemeName varchar(100), @Attachee varchar(70), @Address varchar(50),@town varchar(50),
@Attachment float, @MonthName varchar(25), @payType int, @MemberNo int, @PayPointName varchar(50),
@PayPointAddress varchar(70), @BankCode varchar(15), @BranchCode varchar(25), @AttachNo int, @AttacheeNo int



declare CourtCsr Cursor for
select s.schemeName,c.MemberNo, c.AttachNo, c.AttacheeNo, c.Attachee, c.Address+', '+ c.Town AS Address, 
       cp.Attachment, cp.PayType, mt.MonthName +', '+ cast(cp.PayYear as varchar(4)) as MonthName
from AttachmentPayroll cp
     inner Join CourtAttachees c on cp.SchemeNo = c.schemeNo and cp.MemberNo = c.MemberNo and
                cp.AttachNo = c.AttachNo and cp.AttacheeNo = c.AttacheeNo
     inner Join Scheme s on cp.SchemeNo = s.schemeCode
     inner Join MonthTable mt on cp.PayMonth = mt.MonthNumber
where cp.SchemeNo = @schemeNo and cp.PayMonth = @PayMonth and cp.PayYear = @PayYear

Open CourtCsr 

fetch from CourtCsr into @schemeName, @MemberNo, @AttachNo, @AttacheeNo, @Attachee, @address, @Attachment, @PayType, @MonthName

while @@fetch_Status = 0
begin
   if @PayType = 1
      begin
         select @BankCode = BankCode, @BranchCode = @BranchCode from AttachmentPayroll
         where SchemeNo = @schemeNo and MemberNo  = @MemberNo and AttachNo = @AttachNo and
               @AttacheeNo = @AttacheeNo and PayMonth = @PayMonth and PayYear = @PayYear

         select @PayPointName = BranchName, @PayPointAddress = Address+', '+town
         from Bank_Branch where BankCode = @BankCode and BranchCode = @BranchCode 
      end
   if @PayType = 2
      begin
         select @BankCode = finCode, @BranchCode = finBrCode from AttachmentPayroll
         where SchemeNo = @schemeNo and MemberNo  = @MemberNo and AttachNo = @AttachNo and
               @AttacheeNo = @AttacheeNo and PayMonth = @PayMonth and PayYear = @PayYear

         select @PayPointName = finBrName, @PayPointAddress = finBrAddress+', '+finBrtown
         from finInstitutionsBranch where finBrCode = @BankCode and finBrCode = @BranchCode 
      end 
   
   if @PayType = 4
      begin
        
         select @BankCode = PaypointCode, @BranchCode = PayCode from AttachmentPayroll
         where SchemeNo = @schemeNo and MemberNo  = @MemberNo and AttachNo = @AttachNo and
               AttacheeNo = @AttacheeNo and PayMonth = @PayMonth and PayYear = @PayYear

         select @PayPointName = PayPointName
         from Paypoints where PayPointCode = @BankCode 

         select   @PayPointAddress = Address+', '+town
         from PaypointsBranch  where PayPointCode = @BankCode and BranchCode = @BranchCode

      end
   
   Insert Into #CourtPayroll(SchemeName,AttacheeNo,Attachee, Address, PayPoint,
                             PayPointAddress,
                             Attachment, MonthName)
                Values (@SchemeName, @AttacheeNo, @Attachee, @Address, @PayPointName, @PayPointAddress, @Attachment, @MonthName)           

   fetch NEXT from CourtCsr into @schemeName,@MemberNo, @AttachNo, @AttacheeNo, @Attachee, @address, @Attachment, @PayType, @MonthName
end
Close CourtCsr

Deallocate CourtCSR


select * from #CourtPayroll
go

