CREATE PROCEDURE [dbo].[DefineGLOPBalances]                      
@SCHEMENO Int,                      
@AccountCode Varchar(15),                      
@DrCr Int,                      
@Amount Float,                      
@TransMode Int, 
@CurrCode int,
@SpotRate float,                 
@PeriodEnding Datetime                      
--with Encryption                      
as                      
                      
declare @Account varchar(40), @sYear varchar(5),@StartDate datetime,                      
@AcctPeriod Int,@Description varchar(50), @FiscalYear int,@MonthName varchar(30),@Month Int,@Year Int,          
@FirstLevel Int,@Parent_Level_Code Int,@Child_Level_Code Int,@Parent_Level_Code1 Int,@Child_Level_Code1 Int,  
@GSchemeNo Int                      
  
Exec Proc_Parent_Scheme @GSchemeNo Out   
                      
Select @StartDate = @PeriodEnding + 1                
                
select @Month = DatePart(Month,@StartDate),@Year = DatePart(Year,@StartDate)                
Exec GetMonthName @Month,@MonthName Out                 
                
select @MonthName = @MonthName+', '+cast(@Year as varchar(4))                   
                    
select @AcctPeriod = AcctPeriod from AccountingPeriods where SchemeNo = @schemeNo                      
and StartDate <= @StartDate and EndDate >= @StartDate                      
                      
Select @sYear = @Year                      
                      
select @FirstLevel = FirstLevel,@Parent_Level_Code = Parent_Level_Code,          
@Child_Level_Code = Child_Level_Code,@Parent_Level_Code1 = Parent_Level_Code1,          
@Child_Level_Code1 = Child_Level_Code1 from GlAccountCodes                      
where AccountCode = @AccountCode and SchemeNo = @GSchemeNo                     
                      
Select @Description = 'Opening Balance for '+@MonthName                      
                      
Delete from TBL_GL_Balances where schemeCode = @schemeNo and AccountCode=@AccountCode                 
                                 and PeriodEnding = @PeriodEnding                
      if @DrCr = 0                      
         begin                      
              Insert Into TBL_GL_Balances (schemeNo,AccountCode,PeriodEnding,DebitBalance,CreditBalance,          
                                           FirstLevel,Parent_Level_Code,Child_Level_Code,      
                                           Parent_Level_Code1,Child_Level_Code1,SchemeCode,CurrCode,SpotRate)                  
                                 Values(@GschemeNo,@AccountCode,@PeriodEnding,@Amount,0,          
                                        @FirstLevel,@Parent_Level_Code,@Child_Level_Code,      
                                                    @Parent_Level_Code1,@Child_Level_Code1,@SchemeNo,@CurrCode,@SpotRate)                     
         end                       
      else                      
         begin                
                       
              Insert Into TBL_GL_Balances (schemeNo,AccountCode,PeriodEnding,DebitBalance,CreditBalance,          
                                           FirstLevel,Parent_Level_Code,Child_Level_Code,      
                                           Parent_Level_Code1,Child_Level_Code1,SchemeCode,CurrCode,SpotRate)                  
                                 Values(@GschemeNo,@AccountCode,@PeriodEnding,0,@Amount,          
                                        @FirstLevel,@Parent_Level_Code,@Child_Level_Code,      
                                        @Parent_Level_Code1,@Child_Level_Code1,@SchemeNo,@CurrCode,@SpotRate)                
         end
go

