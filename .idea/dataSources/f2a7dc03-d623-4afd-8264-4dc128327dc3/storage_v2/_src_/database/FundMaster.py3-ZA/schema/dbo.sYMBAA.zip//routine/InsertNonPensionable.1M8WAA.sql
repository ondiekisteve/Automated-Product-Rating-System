CREATE PROCEDURE [dbo].[InsertNonPensionable]  
@SCHEMENO Int,  
@MemberNo int,  
@StartDate Datetime,  
@EndDate Datetime = null,  
@Remarks varchar(100),  
@Recovered Int,  
@MonthsRecovered Int,  
@RateCode int,  
@Salary float,  
@Contribution float,  
@LeaveStatus Int,  
@Balance float,  
@AsAt Datetime,  
@OldSalary float,  
@OldContribution float,  
@SalaryDiff Int,  
@ChangeDate Datetime,  
@PrevEmployer float,  
@Employer float  
--with Encryption  
as  
  
declare @AcctPeriod Int  
  
IF @AsAt is null  
   select @AsAt = @StartDate  
  
if @Balance is null  
   select @Balance = 0  
  
select @AcctPeriod = AcctPeriod from schemeYears where SchemeNo = @schemeNo  
and StartDate <= @AsAt and EndDate >= @AsAt  
  
if Exists (Select * from NonPensionable where  
           SchemeNo = @SchemeNo and MemberNo = @MemberNo and StartDate = @StartDate)  
   begin  
      update NonPensionable set EndDate = @EndDate,Reason = @Remarks,Recovered = @Recovered,  
                                MonthsRecovered = @MonthsRecovered,RateCode = @RateCode,  
                                Salary = @Salary,Contribution = @Contribution,  
                                LeaveStatus = @LeaveStatus,OldSalary = @OldSalary,  
                                OldContribution = @OldContribution,  
                                SalaryDiff = @SalaryDiff,  
                                SalaryChangeDate = @ChangeDate,  
                                PrevEmployer = @PrevEmployer,
                                Employer = @Employer  
      where SchemeNo = @SchemeNo and MemberNo = @MemberNo and StartDate = @StartDate   
   end  
else  
   Insert Into NonPensionable ( SchemeNo,MemberNo,StartDate,EndDate,Reason,Recovered,MonthsRecovered,RateCode,  
                                Salary,Contribution,LeaveStatus,OldSalary,OldContribution,SalaryDiff,SalaryChangeDate,  
                                Employer,PrevEmployer)  
                 Values(@SchemeNo,@MemberNo,@StartDate,@EndDate,@Remarks,@Recovered,@MonthsRecovered,@RateCode,  
                        @Salary,@Contribution,@LeaveStatus,@OldSalary,@OldContribution,@SalaryDiff,@ChangeDate,  
                        @Employer,@PrevEmployer)  
  
  
           
if Exists (Select * from MembersUnpaidLeaveBalance where SchemeNo = @schemeNo and MemberNo = @MemberNo  
           and AcctPeriod = @AcctPeriod)  
     Update MembersUnpaidLeaveBalance set Balance = @Balance where SchemeNo = @schemeNo and MemberNo = @MemberNo  
           and AcctPeriod = @AcctPeriod  
else  
    Insert Into MembersUnpaidLeaveBalance (SchemeNo,MemberNo,AcctPeriod,Balance)  
                             Values(@SchemeNo,@MemberNo,@AcctPeriod,@Balance)  
  
  
UPDATE Members set ActiveStatus = 4 where schemeNo = @schemeNo and MemberNo = @MemberNo
go

