CREATE PROCEDURE [dbo].[Import_Posting_Journals]
@schemeNo Int,
@BatchNo Int,
@BatchNoImp varchar(30),
@TransNo Int,
@TransNoImp varchar(30),
@TransDate datetime,
@SourceDoc varchar(50),
@VoucherNo Int,
@ReceiptNo Int,
@ChequeNo varchar(20),
@Particulars varchar(255),
@AccountCode varchar(30),
@Debit Decimal(20,6),
@Credit Decimal(20,6),
@BankCode Int
--with Encryption
as

declare @MaxTransNo Int,@GSchemeNo Int,@AcctPeriod Int,@CurrCode Int
Exec Proc_Parent_Scheme @GSchemeNo Out 


select @AcctPeriod = Acctperiod from AccountingPeriods where SchemeNo = @schemeNo  
and StartDate <= @TransDate and EndDate >= @TransDate   

if left(@SourceDoc,1) = 'C'
   begin
   Select @TransNo = Max(CashTransNo) from cashbook where schemeCode = @schemeNo
   if @TransNo is null select @TransNo = 0
   select @TransNo = @TransNo + 1

   select @SourceDoc = 'CB-AP-'+Cast(@TransNo as varchar(10))

   select @CurrCode = currCode from schemeBankBranch where schemeNo = @schemeNo and BankCode = @BankCode 

   insert into SchemeGeneralLedger
   (schemeNo, AccountCode, VoucherNo, Debit, Credit, glDate, glMonth, glYear,     
    Description, Balance, AcctPeriod,CashTransNo,ChequeNo,BalanceType,          
    VoucherInc,ImprestNo,SchemeCode,CurrCode,SourceDoc)          
   Values (@GSchemeNo, @AccountCode, @VoucherNo, @Debit,@Credit, @TransDate, datepart(Month,@TransDate)
           ,datepart(Year,@TransDate),           
           @Particulars, 0.0, @AcctPeriod,@TransNo,@ChequeNo,1,    
           0,0,@SchemeNo,@CurrCode,@SourceDoc)

   end
else if left(@SourceDoc,1) = 'A'
   begin
   Select @TransNo = Max(GLTransNo) from SchemeGeneralLedger where schemeCode = @schemeNo
   if @TransNo is null select @TransNo = 0
   select @TransNo = @TransNo + 1

   select @SourceDoc = 'AP-'+Cast(@TransNo as varchar(10))

   select @CurrCode = 0 

   insert into SchemeGeneralLedger
   (schemeNo, AccountCode, VoucherNo, Debit, Credit, glDate, glMonth, glYear,     
    Description, Balance, AcctPeriod,glTransNo,ChequeNo,BalanceType,          
    VoucherInc,ImprestNo,SchemeCode,CurrCode,SourceDoc)          
   Values (@GSchemeNo, @AccountCode, @VoucherNo, @Debit,@Credit, @TransDate, datepart(Month,@TransDate)
           ,datepart(Year,@TransDate),           
           @Particulars, 0.0, @AcctPeriod,@TransNo,@ChequeNo,1,    
           0,0,@SchemeNo,@CurrCode,@SourceDoc)
   end
else if left(@SourceDoc,1) = 'G'
   begin
   Select @TransNo = Max(JvTransNo) from SchemeGeneralLedger where schemeCode = @schemeNo
   if @TransNo is null select @TransNo = 0
   select @TransNo = @TransNo + 1

   select @SourceDoc = 'GL-JE'+Cast(@TransNo as varchar(10))

   select @CurrCode = 0 

   insert into SchemeGeneralLedger
   (schemeNo, AccountCode, VoucherNo, Debit, Credit, glDate, glMonth, glYear,     
    Description, Balance, AcctPeriod,JVTransNo,ChequeNo,BalanceType,          
    VoucherInc,ImprestNo,SchemeCode,CurrCode,SourceDoc)          
   Values (@GSchemeNo, @AccountCode, @VoucherNo, @Debit,@Credit, @TransDate, datepart(Month,@TransDate)
           ,datepart(Year,@TransDate),           
           @Particulars, 0.0, @AcctPeriod,@TransNo,@ChequeNo,1,    
           0,0,@SchemeNo,@CurrCode,@SourceDoc)

   end
go

