CREATE PROCEDURE [dbo].[get_Actives_Pen]      
@schemeNo Int,      
@SponsorCode Int,      
@AsAtDate datetime,      
@NumRecs Int Out      
--with Encryption      
as      
  
declare @Def int  
      
if @SponsorCode = 0      
   begin      
      select @NumRecs = Count(*) from Pensioner p              
            inner join members m on p.schemeNo = m.schemeNo             
                       and p.memberNo = m.memberNo             
                       and m.ReasonforExit > 0 and m.DoCalc <= @AsAtDate                       
      where p.Alive = 1 and p.SchemeNo = @SchemeNo    
  
      select @Def = Count(*) from DeferredPensioner p            
            inner join members m on p.schemeNo = m.schemeNo             
                       and p.memberNo = m.memberNo             
                       and m.ReasonforExit > 0and m.DoCalc <= @AsAtDate                         
      where ((p.Pensioner = 0) or (p.Pensioner = 1 and p.AppDate > @AsAtDate))   
     and p.SchemeNo = @SchemeNo    
  
     if @NumRecs is null select @NumRecs = 0  
     if @Def is null select @Def = 0            
   end        
else if @SponsorCode > 0      
   begin      
      select @NumRecs = Count(*) from Pensioner p              
            inner join members m on p.schemeNo = m.schemeNo             
                       and p.memberNo = m.memberNo             
                       and m.ReasonforExit > 0 and m.DoCalc <= @AsAtDate and m.SponsorCode = @SponsorCode                       
      where p.Alive = 1 and p.SchemeNo = @SchemeNo   
  
      select @Def = Count(*) from DeferredPensioner p            
            inner join members m on p.schemeNo = m.schemeNo             
                       and p.memberNo = m.memberNo             
                       and m.ReasonforExit > 0and m.DoCalc <= @AsAtDate and m.SponsorCode = @SponsorCode                        
      where ((p.Pensioner = 0) or (p.Pensioner = 1 and p.AppDate > @AsAtDate))   
     and p.SchemeNo = @SchemeNo   
  
     if @NumRecs is null select @NumRecs = 0  
     if @Def is null select @Def = 0  
                       
   end   
  
select @NumRecs = @NumRecs + @def
go

