CREATE TRIGGER [dbo].[T_InvestValue_Loans_Edit] ON [dbo].[TBL_Loans]   
FOR UPDATE
AS  
  
declare @SchemeNo int,@MortgageNo Int,@TiedToGl smallint
  
select @schemeNo = schemeNo,@MortgageNo = MortgageNo from Inserted  

Exec Proc_Update_Tied @schemeNo,@MortgageNo,@TiedToGl out

if @TiedToGl > 1 select @TiedToGl = 1


update TBL_Loans set TiedToGl = @TiedToGl
where SchemeNo = @schemeNo and MortgageNo = @MortgageNo
go

