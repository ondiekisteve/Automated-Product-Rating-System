/*We Kimondo - After executing this Procedure, open a new window in
  Query Analyser and execute the following statement, to give u a list
  of the new pensioners/Beneficiaries in the Banks 



  Exec ShowNewBank
*/

CREATE PROCEDURE [dbo].[ShowNewBank]
as

declare @CurMonth Int,@CurYear Int,@LastMonth Int,@SCHEMENO Int,@PayMode Int

Select @CurMonth = 6,@CurYear = 2003,@LastMonth = 5,
@SchemeNo = '1202', @PayMode = 1

if object_id('tempdb..#LastBank') is null
begin
create table #LastBank
(
        [MemberNo][Int] Identity(1,1),
	[PenNo] [varchar](100) NOT NULL ,
	[Net] [float] not  NULL default 0.0,
        
) 

ALTER TABLE #LastBank WITH NOCHECK ADD 

            
	CONSTRAINT [PK_#LastBank] PRIMARY KEY  NONCLUSTERED 
	(
	  [MemberNo]      
	) 
end

if object_id('tempdb..#NewBank') is null
begin
create table #NewBank
(
        [MemberNo][Int] Identity(1,1),
	[PenNo] [varchar](100) NOT NULL ,
	[Net] [float] not  NULL default 0.0,
        
) 

ALTER TABLE #NewBank WITH NOCHECK ADD 

            
	CONSTRAINT [PK_#NewBank] PRIMARY KEY  NONCLUSTERED 
	(
	  [MemberNo]      
	) 
end

Insert Into #LastBank select PenNo,Net from PensionPayroll
where SchemeNo= @SchemeNo and PayMonth = @LastMonth and PayYear = @CurYear
and PayType = @PayMode and Hold = 1

Insert Into #LastBank select PenNo,Net from PensionPayrollBen
where SchemeNo= @SchemeNo and PayMonth = @LastMonth and PayYear = @CurYear
and PayType = @PayMode and Hold = 1

Insert Into #NewBank select PenNo,Net from PensionPayroll
where SchemeNo= @SchemeNo and PayMonth = @CurMonth and PayYear = @CurYear
and PayType = @PayMode and Hold = 1


Insert Into #NewBank select PenNo,Net from PensionPayrollBen
where SchemeNo= @SchemeNo and PayMonth = @CurMonth and PayYear = @CurYear
and PayType = @PayMode and Hold = 1

select * from #NewBank where PenNo Not in (Select PenNo from #LastBank)
go

