CREATE PROCEDURE [dbo].[Proc_Fund_Listing]                  
@SCHEMENO Int,                                        
@AsAtDate datetime                                       
--with Encryption                    
as                    
                    
if object_id('tempdb..#FundValue') is null                    
                    
begin                    
create table #FundValue                    
(                    
  [SchemeNo] [int] NOT NULL ,                    
  [SchemeName][varchar](120),
  [MemberBalances][float],
  [Reserve][float],
  [Combined][float],
  [AsAtDate][datetime],
  [PoolName][varchar](100)                    
)                     
                   
end                    
                                     
declare @SchemeName varchar(120),@MemberBalances float,
        @Reserve float,@AcctPeriod Int,@PoolName varchar(100),@FundType Int,@SchemeCode Int                  
                   
            
select  @PoolName = schemeName,@FundType = FundTypeCode from scheme where schemeCode = @schemeNo            
                                     
if @FundType = 8              
BEGIN              
Declare MovementCsr cursor for              
select schemeCode,schemeName from Scheme              
where PooledInvestment = 1 and InvestmentScheme = @schemeNo             
             
Open MovementCsr              
Fetch from MovementCsr into @schemeCode,@schemeName             
while @@fetch_Status = 0              
begin
  select @AcctPeriod = AcctPeriod from schemeYears where schemeNo = @schemeCode
  and StartDate <= @AsAtDate and EndDate >= @AsAtDate

  select @MemberBalances = sum(empcont + emprCont + empVolCont + emprVolCont + PreAvc + PreEmpCont + PreEmprCont)                     
  from MemberOpeningBalances where                     
  SchemeNo = @schemeCode and AcctPeriod = @AcctPeriod       
      
                                       
  select @Reserve = ReserveBalance                     
  from ReserveOpeningBalance where                     
  SchemeNo = @schemeCode and AcctPeriod = @AcctPeriod

  Insert Into #FundValue (SchemeNo,SchemeName,MemberBalances,Reserve,Combined,
                          AsAtDate,PoolName)
               Values(@schemeCode,@SchemeName,@MemberBalances,@Reserve,@MemberBalances + @Reserve,
                      @AsAtDate,@PoolName)                    


  select @schemeCode=0,@schemeName='',@AcctPeriod = 0,@MemberBalances = 0,@Reserve = 0
  Fetch next from MovementCsr into @schemeCode,@schemeName 
end
close MovementCsr
deallocate MovementCsr  
END

select * from #FundValue order by left(SchemeName,10)
go

