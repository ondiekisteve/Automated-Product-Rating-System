CREATE PROCEDURE [dbo].[IsLeapYear]  
@CurrYear int,  
@isLeap Int Out  
--with Encryption  
as  
  
declare @Result float  
  
select @Result = @CurrYear/4.00  
  
if len(ltrim(rtrim(@Result))) > 3  
   select @isLeap = 0  
else if len(ltrim(rtrim(@Result))) = 3  
   select @isLeap = 1
go

