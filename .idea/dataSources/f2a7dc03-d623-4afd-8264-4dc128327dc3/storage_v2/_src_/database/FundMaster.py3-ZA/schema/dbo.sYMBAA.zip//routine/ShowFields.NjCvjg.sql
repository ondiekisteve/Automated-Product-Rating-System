CREATE PROCEDURE [dbo].[ShowFields]
@Tablename varchar(50)
--with Encryption
as
Select * from fldDataDictionary
where TableName = @TableName
Order by FieldName
go

