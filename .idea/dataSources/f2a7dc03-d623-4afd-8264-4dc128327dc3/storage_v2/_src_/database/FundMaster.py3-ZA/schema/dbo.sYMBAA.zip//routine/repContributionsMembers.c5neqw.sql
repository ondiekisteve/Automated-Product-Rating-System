CREATE PROCEDURE [dbo].[repContributionsMembers]                                    
@SCHEMENO Int,                                    
@memberno int                                    
--with Encryption                                   
as                                  
if object_id('tempdb..#RepContrHistory') is null                                  
 begin                                  
  CREATE TABLE [#RepContrHistory]                                  
   ([SchemeNo][varchar] (15) not null,                                  
    [memberNo][int] not null,                                  
    [DatePaid][datetime] null,                                  
    [contrMonth][int] null,                                  
    [contrYear][int] null,                                  
    [salary][float] null default (0.00),                                  
    [EmpCont][float] null default(0.00),                                  
    [EmprCont][float] null default(0.00),                                  
    [SpecialContr][float] null default(0.00),                                  
    [VolContr][float]  null default(0.00),                                  
    [Excess][float] null default(0.00),                                  
    [DeferredAmt][float] null default (0.00),                                
    [Nssf][float]  null default(0.00),                                  
    [AugCont][float] null default(0.00),                                  
    [TotalContr][float] null default(0.00),                                  
    [AcctPeriod][int],                                  
    [monthname][varchar](50),                                  
    [FullName][varchar](120) null,                                  
    [schemeName][varchar](120)null,                                  
    [Arrears][int]null default(0.00),                                  
    [Descr][varchar](20) null,                  
    [Sponsor][varchar](120),                
    [PayrollNo][varchar](20),                
    [IDNumber][varchar](20),                
    [PoolName][varchar](120),
    [SchemeYear][int]                                  
   )                                  
 end                   
                  
declare @SponsorCode Int,@Sponsor varchar(120),@PoolName varchar(120),@InvestmentScheme int,@PooledInvestment smallInt,        
@Mukuba smallint        
        
select @Mukuba = Mukuba from Scheme where SchemeCode = @schemeNo        
        
if @Mukuba is null select @Mukuba = 0                 
                  
Select @SponsorCode = SPONSORCODE from members where schemeNo = @schemeNo and MemberNo = @MemberNo                  
                  
if @SponsorCode is not null                  
   select @Sponsor = sponsorName from sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode                  
                  
if @Sponsor is null select @Sponsor = ''                  
            
select @InvestmentScheme = InvestmentScheme,@PooledInvestment = PooledInvestment from scheme             
       where schemecode = @SchemeNo            
If @PooledInvestment = 1            
   select @PoolName = SchemeName from scheme where SchemeCode = @InvestmentScheme            
If @PooledInvestment = 0            
   select @PoolName = ' '            
                               
delete #RepContrHistory         
        
IF @Mukuba = 0       
BEGIN                                
insert into #RepContrHistory                                  
SELECT                                    
c.SchemeNo,                                    
c.MemberNo,                                    
c.DatePaid,                                    
c.contrMonth,                                    
c.contrYear,                                    
c.salary,                                    
c.EmpCont,                                    
c.EmprCont,                                    
c.SpecialContr,                                    
c.VolContr,                                    
(c.ExcessEmprCont + c.ExcessEmpcont + c.ExcessVolContr + c.ExcessSpecial) as Excess,                                    
0,                                
(c.NssfE + c.nssf ) AS Nssf,c.AugCont,                
(c.empcont + c.emprcont + c.specialContr + c.volContr + c.nssf + c.nssfe + c.excessEmpcont + c.excessEmprcont + c.ExcessVolContr + c.ExcessSpecial                                    
 + c.AugCont) as TotalContr,C.AcctPeriod,                                    
LEFT(m.monthname,3),                                    
upper(memb.sName+', '+memb.fName+' '+memb.Onames) as FullName,                                    
s.schemeName,0,' ',@Sponsor,memb.PayrollNo,memb.IDNumber,@PoolName, c.schemeYear                                   
FROM Contributionssummary c                                    
inner join MonthTable M ON C.contrMonth = m.monthNumber                                    
inner Join Members memb on c.schemeNo = memb.schemeNo and c.MemberNo = Memb.MemberNo                                    
inner Join Scheme s on c.schemeNo = s.schemeCode                                    
WHERE (c.MemberNo = @memberno)  and                                    
               (c.schemeNo = @schemeNo)                                      
order by  C.AcctPeriod,c.contrYear,c.contrMonth       
END        
else IF @Mukuba = 1      
BEGIN                               
insert into #RepContrHistory                                  
SELECT                                    
c.SchemeNo,                                    
c.MemberNo,                                    
c.DatePaid,                                    
c.contrMonth,                                    
c.contrYear,                                    
c.salary,                                    
c.EmpCont - c.augCont,                                    
c.EmprCont,                                    
c.SpecialContr,                                    
c.VolContr,                                    
(c.ExcessEmprCont + c.ExcessEmpcont + c.ExcessVolContr + c.ExcessSpecial) as Excess,                                    
0,                                
(c.NssfE + c.nssf ) AS Nssf,c.AugCont,                                    
(c.empcont + c.emprcont + c.specialContr + c.volContr + c.nssf + c.nssfe + c.excessEmpcont + c.excessEmprcont + c.ExcessVolContr + c.ExcessSpecial                                    
 - c.AugCont) as TotalContr,C.AcctPeriod,                                    
LEFT(m.monthname,3),                                    
upper(memb.sName+', '+memb.fName+' '+memb.Onames) as FullName,                                    
s.schemeName,0,' ',@Sponsor,memb.PayrollNo,memb.IDNumber,@PoolName, c.schemeYear               
FROM Contributionssummary c                                    
inner join MonthTable M ON C.contrMonth = m.monthNumber                                    
inner Join Members memb on c.schemeNo = memb.schemeNo and c.MemberNo = Memb.MemberNo                                    
inner Join Scheme s on c.schemeNo = s.schemeCode                                    
WHERE (c.MemberNo = @memberno)  and                                    
               (c.schemeNo = @schemeNo)                                      
order by  C.AcctPeriod,c.contrYear,c.contrMonth       
      
    
END                                
                                  
/**Insert arrears for the report*/                                  
insert into #RepContrHistory                                  
SELECT                                    
c.SchemeNo,                                    
c.MemberNo,                                    
c.DatePaid,                                    
c.contrMonth,                       
c.contrYear,                                    
c.salary,                                    
c.ArEmpCont,                                    
c.ArEmprCont,                                    
c.ArSpecial,                               
c.ArVolContr,                                    
(c.ArEmprcont_un + c.ArEmpcont_un ) as Excess,                                  
0,                                  
0 AS Nssf,0,                                    
(c.Arempcont + c.Aremprcont + c.Arspecial + c.ArvolContr + c.ArEmprcont_un + c.ArEmpcont_un) as TotalContr,                                  
C.AcctPeriod,                                    
LEFT(m.monthname,3),                        
upper(memb.sName+', '+memb.fName+' '+memb.Onames) as FullName,                                    
s.schemeName,1,' [Arrears]',@Sponsor,memb.PayrollNo,memb.IDNumber,@PoolName, 
(select schemeYear from schemeYears where SchemeNo = @SCHEMENO and c.datePaid between startDate and endDate) schemeyear                                
FROM ContributionArrears c                                    
inner join MonthTable M ON C.contrMonth = m.monthNumber                                    
inner Join Members memb on c.schemeNo = memb.schemeNo and c.MemberNo = Memb.MemberNo                                    
inner Join Scheme s on c.schemeNo = s.schemeCode                                    
WHERE (c.MemberNo = @memberno)  and                                    
               (c.schemeNo = @schemeNo)                                      
order by  C.AcctPeriod,c.contrYear,c.contrMonth                                  
                         
/**Transfars*/                                  
insert into #RepContrHistory                                  
SELECT                                    
c.SchemeNo,                                    
c.MemberNo,                                    
c.TransferDate,                                    
datepart(month,c.TransferDate),                                  
datepart(year ,c.TransferDate),                                    
0,--salary                                    
c.EmpTransfer,                                    
c.EmprTransfer, --+ c.DeferredAmt,                                  
c.AVCERTransfer,                                    
c.AVCTransfer,                                
0,-- Excess,                                 
c.DeferredAmt,                                   
0 AS Nssf,0,                                    
(c.EmpTransfer + c.EmprTransfer + c.AVCTransfer + c.AVCERTransfer + c.DeferredAmt) as TotalContr,                                  
C.AcctPeriod,                                    
LEFT(m.monthname,3),                                    
upper(memb.sName+', '+memb.fName+' '+memb.Onames) as FullName,                                    
s.schemeName,2,' [Transfer]',@Sponsor,memb.PayrollNo,memb.IDNumber,@PoolName, 
(select schemeYear from schemeYears where SchemeNo = @SCHEMENO and c.TransferDate between startDate and endDate) schemeyear                                  
FROM MemberTransfer c                                    
inner join MonthTable M ON datepart(month,c.TransferDate) = m.monthNumber                                    
inner Join Members memb on c.schemeNo = memb.schemeNo and c.MemberNo = Memb.MemberNo                                    
inner Join Scheme s on c.schemeNo = s.schemeCode                                    
WHERE (c.MemberNo = @memberno)  and                                    
               (c.schemeNo = @schemeno)                                 
order by TransferDate                       
                    
/** Un-Registered Transfer **/                    
insert into #RepContrHistory                                  
SELECT                                    
c.SchemeNo,                                    
c.MemberNo,                                    
c.TransferDate,                                    
datepart(month,c.TransferDate),                           
datepart(year ,c.TransferDate),                                    
0,--salary                                    
c.EmpTransfer,                                    
c.EmprTransfer, --+ c.DeferredAmt,                                  
c.AVCERTransfer,                                    
c.AVCTransfer,                                
0,-- Excess,                              
c.DeferredAmt,                                   
0 AS Nssf,0,                                    
(c.EmpTransfer + c.EmprTransfer + c.AVCTransfer + c.AVCERTransfer + c.DeferredAmt) as TotalContr,                                  
C.AcctPeriod,                                    
LEFT(m.monthname,3),       
upper(memb.sName+', '+memb.fName+' '+memb.Onames) as FullName,                                    
s.schemeName,2,' [Transfer Un]',@Sponsor,memb.PayrollNo,memb.IDNumber,@PoolName, 
(select schemeYear from schemeYears where SchemeNo = @SCHEMENO and c.TransferDate between startDate and endDate) schemeyear                                  
FROM MemberTransferUn c                                    
inner join MonthTable M ON datepart(month,c.TransferDate) = m.monthNumber        
inner Join Members memb on c.schemeNo = memb.schemeNo and c.MemberNo = Memb.MemberNo                       
inner Join Scheme s on c.schemeNo = s.schemeCode                                    
WHERE (c.MemberNo = @memberno)  and                                    
               (c.schemeNo = @schemeno)                                 
order by TransferDate                      
                               
/*finalize totals n execess*/                                  
update #RepContrHistory set TotalContr = 0,Excess = 0 where excess is null                        
update #RepContrHistory set  DeferredAmt = 0 where DeferredAmt  is null                                   
update #RepContrHistory set TotalContr = (empcont + emprcont + specialContr + volContr + Excess+DeferredAmt),             
        emprcont = (emprcont + DeferredAmt)                 
select * from  #RepContrHistory  order by ContrYear,ContrMonth, arrears
go

