CREATE PROCEDURE [dbo].[UpdateBenefits]      
@SCHEMENO Int,      
@MemberNo Int,      
@EmpCBal float,      
@EmprCBal float,      
@VolCBal float,      
@SpecCBal float,      
@PreEmpCBal float,      
@PreEmprCBal float,      
@Tax float,       
@eEmpCBal float,      
@eEmprCBal float,      
@EVolCBal float,      
@ESpecCBal float,      
@vesting float,    
@OutCont float,    
@OutContInt float,  
@CashEquivalent float,    
@CashLumpsum float,

@EmpFees float,      
@EmprFees float,      
@UnEmpFees float,      
@UnEmprFees float,    
@EmpTax float,    
@EmprTax float,  
@VolTax float,    
@SpecTax float
  
  
--WITH ENCRYPTION      
as      
Update Benefits set EmpCBal = @EmpCBal,EmprCBal = @EmprCBal,      
                    VolCBal = @VolCBal,SpecialCBal = @SpecCBal,      
                    PreEmpCBal = @PreEmpCBal, PreEmprCBal = @PreEmprCBal,      
                    WithholdingTax = @Tax,Vesting = @vesting,    
                    OutCont = @OutCont,OutContInt = @OutContInt,  
                    CashCommLumpsum =@CashLumpsum,CashTax=@Tax,CashEquivalent = @CashEquivalent,
                    EmpFees = @EmpFees,EmprFees = @EmprFees      
where SchemeNo = @SchemeNo and MemberNo = @MemberNo      
      
Update UnRegisteredBenefits set EEmpCBal = @EEmpCBal,eEmprCBal = @EEmprCBal,      
                    EVolCBal = @EVolCBal,ESpecialCBal = @ESpecCBal,
                    EmpFees_Un = @UnEmpFees,EmprFees_Un = @UnEmprFees,
                    cEmpTax =@EmpTax,cEmprTax=@EmprTax,cVolTax=@VolTax,cSpecTax =@SpecTax        
where SchemeNo = @SchemeNo and MemberNo = @MemberNo
go

