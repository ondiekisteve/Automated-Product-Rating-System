/*
  Maintenance reports
*/
CREATE PROCEDURE [dbo].[Proc_Expenditure]
@schemeNo Int,
@StartDate datetime,
@EndDate datetime
--with Encryption

as

if object_id('tempdb..#Property_Perform') is null

begin
create table #Property_Perform
(
 MainCounter int identity(1,1) primary key,
 PropCode Int,
 PropName varchar(120),
 ExpenseName varchar(100),
 ExpenseDate datetime,
 Particulars varchar(150),
 PlannedMain decimal(20,6),
             
)  
end

declare @PropCode Int,@PropName varchar(120),@ExpenseDate datetime,@Particulars varchar(150),
@PlannedMain decimal(20,6),@ExpenseName varchar(100)

declare pcsr cursor for
select propertyCode,propertyName
from property where schemeNo = @schemeNo
open pcsr
fetch from pcsr into @PropCode,@PropName
while @@fetch_Status = 0
begin
      declare mcsr cursor for
      select t.Expense as ExpenseName,e.ExpenseDate,e.Particulars,e.Expense 
      from EstateExpenditure e
           inner join expenditureTypes t on e.ExpenseType = t.ExpenseCode
      where e.schemeNo = @schemeNo and e.PropertyCode = @propCode and e.ExpenseType <> 3 
      and @StartDate <= e.ExpenseDate and @EndDate >= e.ExpenseDate and e.expense > 0
      
      open mcsr
      fetch from mcsr into @ExpenseName,@ExpenseDate,@Particulars,@PlannedMain
      while @@fetch_status = 0
      begin      

         Insert into #Property_Perform (PropCode,PropName,ExpenseDate,Particulars,PlannedMain,ExpenseName)
                            Values(@PropCode,@PropName,@ExpenseDate,@Particulars,@PlannedMain,@ExpenseName)
      
         select @Particulars='',@PlannedMain=0,@ExpenseName = ''
         fetch next from mcsr into @ExpenseName,@ExpenseDate,@Particulars,@PlannedMain
      end
      close mcsr
      deallocate mcsr
      
      select @PropCode=0,@PropName=''

  fetch next from pcsr into @PropCode,@PropName
end
close pcsr
deallocate pcsr

SELECT * FROM #Property_Perform
ORDER BY PROPCODE,ExpenseName,ExpenseDate
go

