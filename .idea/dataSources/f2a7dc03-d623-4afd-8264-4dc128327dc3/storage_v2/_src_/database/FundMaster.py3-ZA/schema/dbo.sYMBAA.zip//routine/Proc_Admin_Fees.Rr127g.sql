CREATE PROCEDURE [dbo].[Proc_Admin_Fees]                    
@schemeNo int,                    
@PeriodEnding datetime,                    
@RepMode Int                    
as                    
DECLARE @EmpCreditAcc VARCHAR(30),@EmprCreditAcc VARCHAR(30),@avcCreditAcc VARCHAR(30),                  
@BatchNo int,@MaxTransNo int,@PayMonth int,@PayYear int,@Fees float,@vat float,@total float,                  
@schemeCode Int,@CurrCode Int,@TransParticulars varchar(100),@StartDate datetime,                
@PrevFees float,@Prevvat float,@Prevtotal float,@sDate datetime,@yEnd datetime,@FundType Int           
          
/* Update any New Scheme with the Management Fees */          
update scheme set AdminFees = 4.5,InvestFees  = 2.5,PerformFees = 0.1          
where (AdminFees + InvestFees + PerformFees)  = 0                  
                  
select @TransParticulars = 'Administration Fees'                  
                  
select @CurrCode = CurrCode,@FundType = FundTypeCode  from scheme where schemeCode = @schemeNo                  
                    
Select @EmpCreditAcc = EmpCreditAcc,@EmprCreditAcc=EmprCreditAcc,@avcCreditAcc=avcCreditAcc                    
from Pension_setup where schemeNo = @SCHEMENO                  
                  
select @StartDate = StartDate from schemeYears where schemeNo = @schemeNo and StartDate <= @PeriodEnding                
and EndDate >= @PeriodEnding              
              
select @sDate = StartDate from AccountingPeriods where schemeNo = @schemeNo and EndDate = @PeriodEnding      
      
select @yEnd  = EndDate from AccountingPeriods where schemeNo = @schemeNo and StartDate = @sDate                
     
if @FundType = 8 /* Pooled Fund */                   
select s.schemeCode,s.SchemeName,(sum(t.Credit * t.Spotrate) - sum(t.debit * t.SpotRate)) as Contributions,               
(sum(t.Credit * t.Spotrate) - sum(t.debit * t.SpotRate)) * (s.AdminFees/100.00) as fees,                    
s.AdminFees as FeesRate, ((sum(t.Credit * t.Spotrate) - sum(t.debit * t.SpotRate)) * (s.AdminFees/100.00)) * .16 as VAT,                    
((sum(t.Credit * t.Spotrate) - sum(t.debit * t.SpotRate)) * (s.AdminFees/100.00)) * 1.16 as TotalFees,@PeriodEnding as PeriodEnding                    
from SchemeGeneralLedger t                    
     inner join Scheme s on t.schemeCode = s.schemecode                    
where t.schemeCode  in (select schemeCode from Scheme                                                              
                          where PooledInvestment = 1 and InvestmentScheme = @SCHEMENO AND ActiveStatus = 1)                    
and t.AccountCode in (@EmpCreditAcc,@EmprCreditAcc,@avcCreditAcc)                     
and t.glDate >= @sDate and t.glDate <= @PeriodEnding and t.Posted = 1 and t.Tran_Status = 0              
Group by s.schemeCode,s.schemeName,s.AdminFees      
else if @FundType <> 8 /* Pooled Fund */                   
select s.schemeCode,s.SchemeName,(sum(t.Credit * t.Spotrate) - sum(t.debit * t.SpotRate)) as Contributions,               
(sum(t.Credit * t.Spotrate) - sum(t.debit * t.SpotRate)) * (s.AdminFees/100.00) as fees,                    
s.AdminFees as FeesRate, ((sum(t.Credit * t.Spotrate) - sum(t.debit * t.SpotRate)) * (s.AdminFees/100.00)) * .16 as VAT,                    
((sum(t.Credit * t.Spotrate) - sum(t.debit * t.SpotRate)) * (s.AdminFees/100.00)) * 1.16 as TotalFees,@PeriodEnding as PeriodEnding                    
from SchemeGeneralLedger t                    
     inner join Scheme s on t.schemeCode = s.schemecode                    
where t.schemeCode  = @schemeNo                   
and t.AccountCode in (@EmpCreditAcc,@EmprCreditAcc,@avcCreditAcc)                     
and t.glDate >= @sDate and t.glDate <= @PeriodEnding and t.Posted = 1 and t.Tran_Status = 0              
Group by s.schemeCode,s.schemeName,s.AdminFees                  
                  
if @RepMode = 1                  
begin                  
                                                                    
  select @PayMonth = DatePart(Month,@PeriodEnding),@PayYear = DatePart(Year,@PeriodEnding)            
      
  if @FundType = 8                   
  declare adminCsr cursor for                  
  select s.schemeCode,sum(((t.Credit * t.Spotrate) - (t.debit * t.spotrate)) * (s.AdminFees/100.00)),                    
                      sum((((t.Credit * spotrate) - (t.debit*t.spotrate)) * (s.AdminFees/100.00)) * .16),                  
                      sum(((t.Credit * spotrate) - (t.debit*t.spotrate)) * (s.AdminFees/100.00)) +                    
                      sum((((t.Credit * t.spotrate) - (t.debit * t.spotrate)) * (s.AdminFees/100.00)) * .16)                
  from SchemeGeneralLedger t                    
     inner join Scheme s on t.schemeCode = s.schemecode                    
  where t.schemeCode  in (select schemeCode from Scheme                                                              
                          where PooledInvestment = 1 and InvestmentScheme = @SCHEMENO AND ActiveStatus = 1)                    
  and t.AccountCode in (@EmpCreditAcc,@EmprCreditAcc,@avcCreditAcc)                     
  and t.glDate >= @sDate and t.glDate <= @PeriodEnding and t.Posted = 1 and t.Tran_Status = 0              
  Group by s.schemeCode     
  else if @FundType <> 8                    
  declare adminCsr cursor for                  
  select s.schemeCode,sum(((t.Credit * t.Spotrate) - (t.debit * t.spotrate)) * (s.AdminFees/100.00)),                    
                      sum((((t.Credit * spotrate) - (t.debit*t.spotrate)) * (s.AdminFees/100.00)) * .16),                  
                      sum(((t.Credit * spotrate) - (t.debit*t.spotrate)) * (s.AdminFees/100.00)) +                    
                      sum((((t.Credit * t.spotrate) - (t.debit * t.spotrate)) * (s.AdminFees/100.00)) * .16)                
  from SchemeGeneralLedger t                    
     inner join Scheme s on t.schemeCode = s.schemecode                    
  where t.schemeCode = @schemeNo                    
  and t.AccountCode in (@EmpCreditAcc,@EmprCreditAcc,@avcCreditAcc)                     
  and t.glDate >= @sDate and t.glDate <= @PeriodEnding and t.Posted = 1 and t.Tran_Status = 0              
  Group by s.schemeCode                           
                  
  open admincsr                  
  fetch from admincsr into @schemeCode,@Fees,@vat,@Total                  
  while @@fetch_status = 0                  
  begin                 
      Update AccountingPeriods set PeriodClosed = 0 where SchemeNo = @schemeCode  AND EndDate = @PeriodEnding             
      /* select Fees from Prior Periods */       
            
      if @yEnd = @PeriodEnding       
         begin      
         select @PrevFees = 0,@PrevVat=0,@PrevTotal=0      
         end      
      else      
         begin              
         select @PrevFees = sum(((t.Credit * t.SpotRate) - (t.debit * t.Spotrate)) * (s.AdminFees/100.00)),                    
             @PrevVat = sum((((t.Credit * t.spotrate) - (t.debit * t.spotrate)) * (s.AdminFees/100.00)) * .16),                  
             @PrevTotal = sum(((t.Credit * t.spotrate) - (t.debit * t.spotrate)) * (s.AdminFees/100.00)) +                    
               sum((((t.Credit * t.spotrate) - (t.debit * t.Spotrate)) * (s.AdminFees/100.00)) * .16)                                    
    from SchemeGeneralLedger t                    
   inner join Scheme s on t.schemeCode = s.schemecode                    
   where t.schemeCode  = @schemeCode                     
    and t.AccountCode in (@EmpCreditAcc,@EmprCreditAcc,@avcCreditAcc)                     
    and t.glDate < @PeriodEnding and t.glDate >= @StartDate      
  end             
                       
      if @PrevFees is null select @PrevFees = 0                 
      if @PrevVat is null select @PrevVat = 0                 
      if @PrevTotal is null select @PrevTotal = 0                
                 
      Update schemeGeneralLedger set Tran_Status  = -1 where schemeCode = @schemeCode and Description = @TransParticulars                  
      and GLDate = @PeriodEnding                  
                  
      select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeCode       
      if @BatchNo is null select @BatchNo = 0                                   
      select @BatchNo = @BatchNo + 1                                     
                                                                                                    
      select @MaxTransNo = Max(glTransNo) from SchemeGeneralLedger where schemeCode = @schemeCode                                                                                                    
      if @MaxTransNo is null select @MaxTransNo = 0                                                                                                    
      select @MaxTransNo = @MaxTransNo + 1                
                
      select @Total = @Total - @PrevTotal,@Fees = @Fees - @PrevFees,@vat = @vat - @PrevVat                   
                  
      /* Total Admin Fees Accrual */              
      if @Total < 0              
         begin              
         select @Total = 0 - @Total              
              
         Exec PostLedgerDebits_RecPay @schemeCode,'2005',0,@Total,@PayMonth,@PayYear,@TransParticulars,0,@PeriodEnding,                                                                                                      
         @MaxTransNo,@BatchNo,@CurrCode,1.000,0,2500,8              
         end              
      else                 
         Exec PostLedgerCredits_RecPay @schemeCode,'2005',0,@Total,@PayMonth,@PayYear,@TransParticulars,0,@PeriodEnding,                                                                                                      
         @MaxTransNo,@BatchNo,@CurrCode,1.000,0,2500,8                   
                  
      /* Fees Expense */              
      if @Fees < 0              
         begin                   
         select @Fees = 0 - @Fees              
              
         Exec PostLedgerCredits_RecPay @schemeCode,'6100',0,@Fees,@PayMonth,@PayYear,@TransParticulars,0,@PeriodEnding,                                                                                                      
         @MaxTransNo,@BatchNo,@CurrCode,1.000,0,2500,8               
         end               
      else              
         Exec PostLedgerDebits_RecPay @schemeCode,'6100',0,@Fees,@PayMonth,@PayYear,@TransParticulars,0,@PeriodEnding,                                    
         @MaxTransNo,@BatchNo,@CurrCode,1.000,0,2500,8                                                                                     
                                                                                           
                                                                                                    
      /* Vat Expense */              
      if @vat < 0              
         begin              
         select @vat = 0 - @vat         
              
         Exec PostLedgerCredits_RecPay @schemeCode,'6117',0,@vat,@PayMonth,@PayYear,@TransParticulars,0,@PeriodEnding,                                                                                                      
         @MaxTransNo,@BatchNo,@CurrCode,1.000,0,2500,8                  
              
         end              
      else                                                                                                                                          
         Exec PostLedgerDebits_RecPay @schemeCode,'6117',0,@vat,@PayMonth,@PayYear,@TransParticulars,0,@PeriodEnding,                                                                                                      
      @MaxTransNo,@BatchNo,@CurrCode,1.000,0,2500,8                  
                       
                  
      select @schemeCode=0,@Fees=0,@vat=0,@Total=0,@PrevFees = 0,@Prevvat = 0,@Prevtotal= 0                  
      fetch next from admincsr into @schemeCode,@Fees,@vat,@Total                  
  end                  
  close admincsr                  
  deallocate admincsr                           
end
go

