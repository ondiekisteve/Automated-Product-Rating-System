CREATE PROCEDURE [dbo].[Proc_Users_Per_Group]            
@grpName sysname,        
@Users varchar(5000) out            
--with Encryption            
as            
            
set nocount on         
        
declare @FullName varchar(150),@User varchar(100),@Fname varchar(100),@Oname varchar(100),@SName varchar(100),      
        @Count int,@SQL VARCHAR(5000)        
        
select @users ='',@Count = 0           

if object_id('tempdb..#userTable') is not null drop table #userTable        
        
create table #userTable        
(        
grpName sysname not null,        
userName sysname not null,        
primary key (grpName, userName)        
)        
        
select @sql = 'insert #userTable            
select dbUsers1.name as workGroup, dbUsers2.name as userName            
from       
['+db_name()+'].dbo.sysusers dbUsers1,            
['+db_name()+'].dbo.sysusers dbUsers2,            
['+db_name()+'].dbo.sysmembers dbMembers1            
where            
(dbUsers1.uid = dbMembers1.groupuid) and            
(dbMembers1.memberuid = dbUsers2.uid) '           

exec(@sql) 

set nocount off            
      
declare ucsr cursor for            
select userName from #userTable where grpName = @grpName          
order by UserName        
        
open ucsr        
fetch from ucsr into @User        
while @@fetch_status = 0        
begin        
   select @Fname = fname, @Oname = Oname,@SName = Sname from users        
   where username = @user        
        
   if @Fname is null select @Fname = ' '        
   if @Oname is null select @Oname = ' '        
   if @SName is null select @SName = ' '        
         
   select @FullName = '['+@fname+' '+@Oname+' '+@sname+']'        
        
   if @Count = 0      
      select @users = @FullName       
   else       
      select @users = @users+', '+ @FullName       
      
   select @User = '',@FullName='',@Fname ='',@Oname='',@SName='',@Count = @Count + 1        
   fetch next from ucsr into @User        
end        
close ucsr        
deallocate ucsr        
                     
if object_id('tempdb..#userTable') is not null drop table #userTable
go

