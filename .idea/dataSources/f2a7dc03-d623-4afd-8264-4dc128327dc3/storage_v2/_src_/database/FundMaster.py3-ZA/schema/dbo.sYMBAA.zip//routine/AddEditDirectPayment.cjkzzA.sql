CREATE PROCEDURE [dbo].[AddEditDirectPayment]          
@SCHEMENO Int,          
@PaymentNo Int,          
@ReceiptPayment Int,          
@PaymentDate Datetime,          
@Payee Varchar(120),          
@Address Varchar(120),          
@PaymentDesc Varchar(120),          
@Posted Int,          
@AddEdit Int,          
@ChequeNo Varchar(20),          
@ReceiptNo Varchar(20),          
@VAT float,          
@Withholding float,          
@DeductionMode Int,    
@Claim_No Int          
as          
declare @MaxPaymentNo bigint,@Vat1 Decimal(20,6),@Withholding1 Decimal(20,6)          
          
select @MaxPaymentNo = 0          
          
if @Vat is null select @Vat = 0          
if @Withholding is null select @Withholding = 0          
if @DeductionMode is null select @DeductionMode = 0          
          
select @Vat1 = cast(@Vat as Decimal(20,6)),@Withholding1 = cast(@Withholding as Decimal(20,6))          
          
          
if @AddEdit = 0 /* Insert */          
   begin          
   select @MaxPaymentNo = Max(PaymentNo) from DirectPayment where SchemeNo = @schemeNo        
   if @MaxPaymentNo is null select @MaxPaymentNo =  0          
          
   select @MaxPaymentNo = @MaxPaymentNo + 1          
          
   Insert into DirectPayment (SchemeNo,PaymentNo,ReceiptPayment,Payee,Address,PaymentDesc,Posted,PaymentDate,ChequeNo,ReceiptNo,          
                              VAT,Withholding,DeductionMode,Claim_No,PostNo)          
            Values(@SchemeNo,@MaxPaymentNo,@ReceiptPayment,@Payee,@Address,@PaymentDesc,0,@PaymentDate,@ChequeNo,@ReceiptNo,          
                              @VAT1,@Withholding1,@DeductionMode,@Claim_No,@PaymentNo)        
          
   end          
else          
   Update DirectPayment set Payee = @Payee,Address = @Address,PaymentDesc = @PaymentDesc,          
   ChequeNo = @ChequeNo,ReceiptNo = @ReceiptNo,VAT = @VAT1,Withholding=@Withholding1,DeductionMode=@DeductionMode          
   where SchemeNo = @schemeNo and PaymentNo = @PaymentNo          
          
select @MaxPaymentNo as MaxPaymentNo
go

