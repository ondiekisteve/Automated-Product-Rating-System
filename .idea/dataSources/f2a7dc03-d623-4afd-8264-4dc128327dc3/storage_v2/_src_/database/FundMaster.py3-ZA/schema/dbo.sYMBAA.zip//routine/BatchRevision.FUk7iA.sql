CREATE PROCEDURE [dbo].[BatchRevision]                  
@SCHEMENO Int,                  
@RevDate Datetime,                  
@BackDateTO Datetime,                  
@RevCriteria Integer,                  
@RevMode Integer,                  
@StartDate datetime,                  
@EndDate datetime,                  
@MinPension float,                  
@MaxPension float,                  
@RevFactor float                  
--with Encryption                  
as                  
                  
                  
Exec InsertPenBatchRevision                   
     @schemeNo, @RevDate, @BackDateTO, @RevCriteria, @RevMode,@StartDate,@EndDate,                  
     @MinPension,@MaxPension,@RevFactor,1,0                  
                  
                  
declare @MemberNo int,@Pension Decimal(20,6),@Retdate datetime,@Increment float,@BatchArrPaid Bit,                  
@YaConversion Varchar(25),@Chapaa Decimal(20,6),@NumYears Int,@NumMonths Int,@NumDays Int,@tps smallint         
          
select @tps = telposta from scheme where schemeCode = @schemeNo          
if @tps is null select @tps = 0                 
                  
/* Pensioners */                  
if @RevCriteria = 0 /* All Categories */                  
declare Acsr cursor for                  
select p.MemberNo,p.MonPension, m.DoExit                  
from Pensioner p                  
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo                  
where p.SchemeNo = @SchemeNo and p.Alive = 1 and p.Foreigner <> 1 and p.Stopped = 0                  
Order by p.MemberNo                  
                  
else if @RevCriteria = 1 /* Retirement between 2 cut dates */          
begin            
if @tps = 0                
  declare Acsr cursor for                  
  select p.MemberNo,p.MonPension, m.DoExit                  
  from Pensioner p                  
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo                  
     and m.DoExit >= @StartDate and m.DoExit <= @EndDate                  
  where p.SchemeNo = @SchemeNo and p.Alive = 1 and p.Foreigner <> 1                  
  and p.FromDeferred = 0 and p.Stopped = 0                
  Order by p.MemberNo          
else if @tps = 1          
  declare Acsr cursor for                  
  select p.MemberNo,p.MonPension, p.PensionStartDate                  
  from Pensioner p                           
  where p.SchemeNo = @SchemeNo and p.Alive = 1 and p.Foreigner <> 1  and           
  p.PensionStartDate >= @StartDate and p.PensionStartDate <= @EndDate and p.FromDeferred = 0 and p.Stopped = 0                
  Order by p.MemberNo  
           
end                  
else if @RevCriteria = 2 /* Pension between 2 Values */                  
declare Acsr cursor for                  
select p.MemberNo,p.MonPension, m.DoExit                  
from Pensioner p                  
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo                  
where p.SchemeNo = @SchemeNo and p.Alive = 1                  
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension and p.Foreigner <> 1 and p.Stopped = 0                  
Order by p.MemberNo                  
                  
else if @RevCriteria = 3 /* Retirement between 2 cut dates AND Pension between 2 Values */                  
declare Acsr cursor for                  
select p.MemberNo,p.MonPension, m.DoExit                  
from Pensioner p                  
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo                  
     and m.DoExit >= @StartDate and m.DoExit <= @EndDate                  
where p.SchemeNo = @SchemeNo and p.Alive = 1                  
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension                  
and p.FromDeferred = 0 and p.Foreigner <> 1 and p.Stopped = 0                
Order by p.MemberNo                  
Open Acsr                  
                  
fetch from Acsr into @MemberNo,@Pension,@RetDate                  
        
while @@fetch_Status = 0                  
begin                  
   if @RevMode = 0 /* Add a fixed amount  */                  
      BEGIN        
      select @Pension = @Pension + @RevFactor                  
      END                  
                     
   else if @RevMode = 1 /* Add by a factor */                  
      BEGIN                  
      Exec GetServiceTime @ReVDATE,@BackDateTo,@NumYears Out,@NumMonths Out,@NumDays Out                  
                  
      if ((@NumYears = 0) and (@NumMonths > 0))                  
         Select @Pension = @Pension + ((@Pension * (@RevFactor/100.000000000)) * (Cast(@NumMonths as float)/12.000))                   
      else if ((@NumYears = 0) and (@NumMonths = 0))                  
         Select @Pension = @Pension                  
      else                  
         Select @Pension = @Pension + (@Pension * (@RevFactor/100.000000000))                  
      END                             
   else if @RevMode = 2 /* Adjust to a fixed amount  */                  
      BEGIN                  
         Select @Pension = @RevFactor                  
      END                  
                        
      Exec InsertRevision @schemeNo, @MemberNo, @RevDate, @BackDateTo, 1,@BatchArrPaid out                  
                  
   if @BatchArrPaid = 0                  
      begin                  
          /* rounding  gross*/                  
          select @YaConversion = cast(@Pension as Varchar(25))                  
          Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out                  
          select @Pension = @Chapaa                  
          select @Chapaa = 0                  
                  
          update Pensioner set MonPension = @Pension                  
          where SchemeNo = @schemeNo and MemberNo = @MemberNo       
      
          update Pen_Revise set RevisedPension = @Pension                  
          where SchemeNo = @schemeNo and MemberNo = @MemberNo and RevDate = @RevDate                  
      end                  
              
   select @Pension = 0                  
   fetch next from Acsr into @MemberNo,@Pension,@RetDate                  
end                  
                  
Close Acsr                  
Deallocate Acsr                  
                  
                  
/* Pensioners from Deferred Pensioners */                  
if @RevCriteria = 1 /* Retirement between 2 cut dates */                  
declare Acsr cursor for                  
select p.MemberNo,p.MonPension, m.DoCalc                  
from Pensioner p                  
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo                   
     and m.DoCalc >= @StartDate and m.DoCalc <= @EndDate                  
where p.SchemeNo = @SchemeNo and p.Alive = 1 and p.FromDeferred = 1 and p.Stopped = 0                  
Order by p.MemberNo                  
                  
else if @RevCriteria = 3 /* Retirement between 2 cut dates AND Pension between 2 Values */                  
declare Acsr cursor for                  
select p.MemberNo,p.MonPension, m.DoCalc                  
from Pensioner p                  
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo                  
  and m.DoCalc >= @StartDate and m.DoCalc <= @EndDate                  
where p.SchemeNo = @SchemeNo and p.Alive = 1 and p.FromDeferred = 1 and p.Stopped = 0                  
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension                  
Order by p.MemberNo                  
Open Acsr                  
                  
fetch from Acsr into @MemberNo,@Pension,@RetDate                  
                  
while @@fetch_Status = 0                  
begin                  
                     
   if @RevMode = 0 /* Add a fixed amount  */                  
      BEGIN                   
      select @Pension = @Pension + @RevFactor                  
      END                  
                     
   else if @RevMode = 1 /* Add by a factor */                  
      BEGIN                  
      Select @Pension = @Pension + (@Pension * (@RevFactor/100.000000000))                  
      END                             
   else if @RevMode = 2 /* Adjust to a fixed amount  */                  
      BEGIN                  
         Select @Pension = @RevFactor                  
      END                  
                        
      Exec InsertRevision @schemeNo, @MemberNo, @RevDate, @BackDateTo, 1,@BatchArrPaid out                  
                  
   if @BatchArrPaid = 0                  
      begin                  
          /* rounding  gross*/                  
          select @YaConversion = cast(@Pension as Varchar(25))                  
          Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out                  
          select @Pension = @Chapaa                  
          select @Chapaa = 0                  
                  
          update Pensioner set MonPension = @Pension                  
          where SchemeNo = @schemeNo and MemberNo = @MemberNo      
      
          update Pen_Revise set RevisedPension = @Pension                  
          where SchemeNo = @schemeNo and MemberNo = @MemberNo and RevDate = @RevDate                  
      end                  
   select @Pension = 0                  
   fetch next from Acsr into @MemberNo,@Pension,@RetDate                  
end         
                  
Close Acsr                  
Deallocate Acsr
go

