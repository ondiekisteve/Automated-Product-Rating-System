CREATE PROCEDURE [dbo].[CancelRecPayables]        
@SCHEMENO Int,        
@LPONo Varchar(120),        
@TransDate Datetime,        
@DebtorCreditor Int        
as        
declare @Debit float,@Credit float,@DoYote float,@sawa Int,@Pending_Counter Int        
        
select @sawa = 0        
        
if @DebtorCreditor = 0 /* Receivables */        
begin        
   select @DoYote = sum(round(Quantity * UnitPrice,0))         
   from ReceiptsInvoice where SchemeNo = @schemeNo and ReceiptNo = @LPONo        
        
   Select @Debit = sum(round(Debit,0)),@Credit = sum(round(Credit,0))         
   from schemeGeneralLedger where SchemeCode = @SchemeNo        
   and ReceiptNo = @LPOno and glDate = @TransDate        
           
   if @Debit is null select @Debit = 0        
   if @Credit is null select @Credit = 0       
      
       
   if ((@Debit = 0) and (@Credit = 0)) select @Sawa = 1       
        
   if (@Debit - @Credit) > 1        
   begin        
      Update SchemeGeneralLedger set Tran_Status  = -1 where SchemeCode = @schemeNo and glDate = @TransDate        
      and ReceiptNo = @LPOno        
        
      select @sawa = 1        
        
      raiserror ('The Posted Debits and Credits do not Tally, The Posting has been Cancelled',16,1)        
      return        
   end        
        
   if (@Credit - @Debit) > 1        
   begin        
      Update SchemeGeneralLedger set Tran_Status  = -1 where SchemeCode = @schemeNo and glDate = @TransDate        
      and ReceiptNo = @LPOno        
        
      select @sawa = 1        
        
      raiserror ('The Posted Debits and Credits do not Tally, The Posting has been Cancelled',16,1)        
      return        
   end        
end        
        
if @DebtorCreditor = 1 /* Payables */        
begin        
   Select @Debit = sum(round(Debit,0)),@Credit = sum(round(Credit,0))         
   from schemeGeneralLedger where SchemeCode = @SchemeNo        
   and LPONo = @LPOno and glDate = @TransDate        
           
   select @DoYote = sum(round(Quantity * UnitPrice,0))         
   from PayablesInvoice where SchemeNo = @schemeNo and LPONo = @LPONo        
        
   if @Debit is null select @Debit = 0        
   if @Credit is null select @Credit = 0        
        
   if ((@Debit = 0) and (@Credit = 0)) select @Sawa = 1      
      
   if (@Debit - @Credit) > 1        
   begin        
      Update SchemeGeneralLedger set Tran_Status = -1 where SchemeCode = @schemeNo and glDate = @TransDate        
      and LPONo = @LPOno        
        
      select @sawa = 1        
        
      raiserror ('The Posted Debits and Credits do not Tally, The Posting has been Cancelled',16,1)        
      return        
   end        
        
   if (@Credit - @Debit) > 1        
   begin        
      Update SchemeGeneralLedger set Tran_Status = -1 where SchemeCode = @schemeNo and glDate = @TransDate        
      and LPONo = @LPOno        
              
      select @sawa = 1        
        
      raiserror ('The Posted Debits and Credits do not Tally, The Posting has been Cancelled',16,1)        
      return        
   end        
end        
        
IF @SAWA = 0 and @DebtorCreditor = 1         
   begin        
   UPDATE Payables set Posted = 1 where schemeNo = @schemeNo and LPONO = @LPoNo        
           
   select @Pending_Counter = Pending_Counter from Payables where schemeNo = @schemeNo and LPONO = @LPoNo        
        
   if @Pending_Counter is null select @Pending_Counter = 0        
        
   if @Pending_Counter > 0        
      UPDATE TBL_Pending_Posting set Posted = 1 where Pending_Counter = @Pending_Counter        
        
   end        
else IF @SAWA = 1 and @DebtorCreditor = 1         
   UPDATE Payables set Posted = 0 where schemeNo = @schemeNo and LPONO = @LPoNo       
      
ELSE IF @SAWA = 0 and @DebtorCreditor = 0         
   begin        
     UPDATE Receipts set Posted = 1 where schemeNo = @schemeNo and Receipt = @LPoNo        
   end        
else IF @SAWA = 1 and @DebtorCreditor = 0         
   UPDATE Receipts set Posted = 0 where schemeNo = @schemeNo and Receipt = @LPoNo         
        
select @sawa as Sawa
go

