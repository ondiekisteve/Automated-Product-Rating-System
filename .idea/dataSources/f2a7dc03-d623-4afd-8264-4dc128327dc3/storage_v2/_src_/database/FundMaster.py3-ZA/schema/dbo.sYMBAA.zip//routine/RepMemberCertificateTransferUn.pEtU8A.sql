----> Last Modified on 08 Jan 2002          
          
/*          
Return a Members Transfer Value into the Scheme for a given accounting Period          
*/          
          
CREATE PROCEDURE [dbo].[RepMemberCertificateTransferUn]          
@SCHEMENO Int,          
@MemberNo int,          
@AcctPeriod int,          
@EmpTransfer float out,          
@EmprTransfer float out,
@AVCTransfer float out,          
@AVCErTransfer float out          
--with Encryption          
as          
    
declare @DeferredAmt float         
select @EmpTransfer = sum(EmpTransfer), @AVCTransfer = sum(AVCTransfer),          
@EmprTransfer = sum(EmprTransfer), @AVCErTransfer = sum(AVCerTransfer),@DeferredAmt = SUM(DeferredAmt)          
from MemberTransferUn where SchemeNo = @schemeNo and MemberNo = @MemberNo          
and AcctPeriod = @AcctPeriod           
     
IF @DeferredAmt IS null select @DeferredAmt = 0.0     
IF @EmpTransfer IS NULL select @EmpTransfer = 0.0      
IF @EmprTransfer IS NULL select @EmprTransfer = 0.0  
IF @AVCTransfer IS NULL select @AVCTransfer = 0.0      
IF @AVCErTransfer IS NULL select @AVCErTransfer = 0.0     
    
select @EmprTransfer = @EmprTransfer + @DeferredAmt
go

