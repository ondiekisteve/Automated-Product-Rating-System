CREATE PROCEDURE [dbo].[AddEditDirectPaymentInvoice]                
@SCHEMENO Int,                
@PaymentNo Int,                
@InvoiceNo Int,                
@InvoiceDesc Varchar(120),                
@InvoiceAmount float,                
@AddEdit Int,              
@AccountCode varchar(30)                
as                
            
declare @ExpCode Int,@ReceiptOrPayment smallInt,@bankCode Int,@ImprestNo Int,@Balance Decimal(20,6),            
@Amount Decimal(20,6),@Diff Decimal(20,6),@diffStr varchar(20),@PettyCash smallint,@PayDate datetime,  
@Gratuity float,@TotalPaid float,@MemberNo int,@DependantCode Int,@CurrCode Int,@SpotRate Decimal(20,6),
@dCurrCode Int
        
               
if @AddEdit = 0 /* Insert Record */            
   begin            
   select @ExpCode = ExpenditureCode,@ReceiptOrPayment = ReceiptPayment,            
   @bankCode = bankCode,@PettyCash = PettyCash,@PayDate = PaymentDate from            
   DirectPayment where schemeNo = @schemeNo and PaymentNo = @PaymentNo

   --Exec Proc_Get_Forex_Rate @schemeNo,@CurrCode,@PayDate,@SpotRate out             
          
   if ((@PettyCash = 1) and (@ReceiptOrPayment = 1))             
      begin            
        Exec Proc_Get_ImprestNo @schemeNo,@bankCode,@PayDate,@ImprestNo Out,@Balance Out              
                    
        select @Amount = sum(InvoiceAmount) from DirectPaymentInvoice            
        where schemeNo = @schemeNo and PaymentNo = @PaymentNo            
            
        if @Amount is null select @Amount = 0            
            
        if ((@Amount + @InvoiceAmount) > @Balance)            
           begin            
             select @Diff = (@Amount + @InvoiceAmount) - @Balance            
            
             select @DiffStr = cast(@Diff as varchar(20))            
             
             raiserror('The Amount to be expended is greater than the balance in the Imprest account by %s',16,1,@DiffStr)            
             return            
           end            
        else            
           begin            
              Insert Into DirectPaymentInvoice (SchemeNo,PaymentNo,InvoiceDesc,InvoiceAmount,AccountCode)                
                            Values(@SchemeNo,@PaymentNo,@InvoiceDesc,@InvoiceAmount,@AccountCode)            
           end             
      end            
   else            
      Insert Into DirectPaymentInvoice (SchemeNo,PaymentNo,InvoiceDesc,InvoiceAmount,AccountCode)                
                            Values(@SchemeNo,@PaymentNo,@InvoiceDesc,@InvoiceAmount,@AccountCode)            
            
   end                
else if @AddEdit = 1    
   begin                
   Update DirectPaymentInvoice set InvoiceDesc = @InvoiceDesc,InvoiceAmount = @InvoiceAmount,              
   AccountCode = @AccountCode                
   where SchemeNo = @schemeNo and PaymentNo = @PaymentNo and InvoiceNo = @InvoiceNo    
   end      
else if @AddEdit = 2 /* Add Records in TBL_Dep_Pay_Det_Lines */    
   begin   
     select @MemberNo = MemberNo,@DependantCode = DependantCode from DependantPaymentDet  
     where SchemeNo = @SchemeNo and PayCounter = @PaymentNo  
  
     select @Gratuity = Amount from DependantPayment where schemeNo = @schemeNo and MemberNo = @MemberNo            
     and DependantCode = @DependantCode            
            
     select @TotalPaid = sum(Amount) from DependantPaymentDet where schemeNo = @schemeNo and MemberNo = @MemberNo            
     and DependantCode = @DependantCode            
            
     if @Gratuity is null select @Gratuity = 0            
     if @TotalPaid is null select @TotalPaid = 0            
            
           
     if @Gratuity < (@TotalPaid + @InvoiceAmount)            
        begin            
        raiserror('The Total Lumpsum apportionment has been exceeded',16,1)            
        return            
        end  
     else  
        begin         
   
        Insert Into TBL_Dep_Pay_Det_Lines (SchemeNo,PayCounter,Particulars,Amount,AccountCode)                
                                Values(@SchemeNo,@PaymentNo,@InvoiceDesc,@InvoiceAmount,@AccountCode)    
    
        select @InvoiceAmount =  0  
        select @InvoiceAmount = sum(Amount) from TBL_Dep_Pay_Det_Lines where schemeNo = @schemeNo  
        and PayCounter = @PaymentNo  
       
        update DependantPaymentDet set Amount = @InvoiceAmount where schemeNo = @schemeNo  
        and PayCounter = @PaymentNo  
       end  
   end    
else if @AddEdit = 3 /* Edit Records in TBL_Dep_Pay_Det_Lines */    
   begin   
     select @MemberNo = MemberNo,@DependantCode = DependantCode from DependantPaymentDet  
     where SchemeNo = @SchemeNo and PayCounter = @PaymentNo  
  
     select @Gratuity = Amount from DependantPayment where schemeNo = @schemeNo and MemberNo = @MemberNo            
     and DependantCode = @DependantCode            
            
     select @TotalPaid = sum(Amount) from DependantPaymentDet where schemeNo = @schemeNo and MemberNo = @MemberNo            
     and DependantCode = @DependantCode            
       
     select @TotalPaid = @TotalPaid - @InvoiceAmount   
       
     if @Gratuity is null select @Gratuity = 0            
     if @TotalPaid is null select @TotalPaid = 0            
            
           
     if @Gratuity < (@TotalPaid + @InvoiceAmount)            
        begin            
        raiserror('The Total Lumpsum apportionment has been exceeded',16,1)            
        return            
        end  
     else  
        begin    
   
         Update TBL_Dep_Pay_Det_Lines set Particulars = @InvoiceDesc,Amount = @InvoiceAmount,              
         AccountCode = @AccountCode                
         where SchemeNo = @schemeNo and PayCounter = @PaymentNo and PayCode = @InvoiceNo   
  
         select @InvoiceAmount =  0  
         select @InvoiceAmount = sum(Amount) from TBL_Dep_Pay_Det_Lines where schemeNo = @schemeNo  
         and PayCounter = @PaymentNo  
       
         update DependantPaymentDet set Amount = @InvoiceAmount where schemeNo = @schemeNo  
         and PayCounter = @PaymentNo  
       end  
   end
go

