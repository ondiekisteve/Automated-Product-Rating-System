CREATE PROCEDURE [dbo].[BatchRevisionBen]    
@SCHEMENO Int,    
@RevDate Datetime,    
@BackDateTO Datetime,    
@RevCriteria Integer,    
@RevMode Integer,    
@StartDate datetime,    
@EndDate datetime,    
@MinPension float,    
@MaxPension float,    
@RevFactor float,    
@BenMode Int,    
@DecDate Datetime,    
@DecDateEnd Datetime    
--with Encryption    
as    
       
declare @MemberNo int,@DepCode int, @Pension Decimal(20,6),@Retdate datetime,@Increment float,    
@mPension float,@pcntBenefit float,@YaConversion Varchar(25),@Chapaa Decimal(20,6),    
@NewMPension float    
    
if @BenMode = 0 /* Beneficiaries of Deceased Members */    
begin   
     Exec InsertPenBatchRevision     
     @schemeNo, @RevDate, @BackDateTO, @RevCriteria, @RevMode,@StartDate,@EndDate,    
     @MinPension,@MaxPension,@RevFactor,1,1    
   
if @RevCriteria = 0 /* All Categories */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, m.DoExit,p.mPension,d.pcntBenefit    
from MemBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
 and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))  
Order by p.DependantCode    
    
else if @RevCriteria = 1 /* Retirement between 2 cut dates */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, m.DoExit,p.mPension,d.pcntBenefit    
from MemBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))    
Order by p.DependantCode    
    
else if @RevCriteria = 2 /* Pension between 2 Values */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, m.DoExit,p.mPension,d.pcntBenefit    
from MemBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))  
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension    
Order by p.DependantCode    
    
else if @RevCriteria = 3 /* Retirement between 2 cut dates AND Pension between 2 Values */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, m.DoExit,p.mPension,d.pcntBenefit    
from MemBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))   
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension    
Order by p.DependantCode    
end /* Beneficiaries of Deceased Members */    
    
    
if @BenMode = 1 /* Beneficiaries of Deceased Pensioners based on Retirement Dates */    
begin   
     Exec InsertPenBatchRevision     
     @schemeNo, @RevDate, @BackDateTO, @RevCriteria, @RevMode,@StartDate,@EndDate,    
     @MinPension,@MaxPension,@RevFactor,1,2    
   
if @RevCriteria = 0 /* All Categories */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, m.DoExit,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))    
Order by p.DependantCode    
    
else if @RevCriteria = 1 /* Retirement between 2 cut dates */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, m.DoExit,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
    
      and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))  
Order by p.DependantCode    
    
else if @RevCriteria = 2 /* Pension between 2 Values */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, m.DoExit,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))   
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension    
Order by p.DependantCode    
    
else if @RevCriteria = 3 /* Retirement between 2 cut dates AND Pension between 2 Values */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, m.DoExit,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))    
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension    
Order by p.DependantCode    
end /* Beneficiaries of Deceased Pensioners based on Retirement Dates */    
    
if @BenMode = 2 /* Beneficiaries of Deceased Pensioners based on Date Deceased */    
begin   
     Exec InsertPenBatchRevision     
     @schemeNo, @RevDate, @BackDateTO, @RevCriteria, @RevMode,@StartDate,@EndDate,    
     @MinPension,@MaxPension,@RevFactor,1,2  
   
if @RevCriteria = 0 /* All Categories */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, x.DoDeath,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     inner join PenDeathClaim x on p.SchemeNo = x.schemeNo and p.MemberNo = x.MemberNo    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))    
Order by p.DependantCode    
    
else if @RevCriteria = 1 /* Retirement between 2 cut dates */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, x.DoDeath,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     inner join PenDeathClaim x on p.SchemeNo = x.schemeNo and p.MemberNo = x.MemberNo    
     and x.DoDeath >= @StartDate and x.DoDeath <= @EndDate    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))   
Order by p.DependantCode    
    
else if @RevCriteria = 2 /* Pension between 2 Values */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, x.DoDeath,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     inner join PenDeathClaim x on p.SchemeNo = x.schemeNo and p.MemberNo = x.MemberNo    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))  
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension    
Order by p.DependantCode    
    
else if @RevCriteria = 3 /* Retirement between 2 cut dates AND Pension between 2 Values */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, x.DoDeath,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
     and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join PenDeathClaim x on p.SchemeNo = x.schemeNo and p.MemberNo = x.MemberNo    
     and x.DoDeath >= @StartDate and x.DoDeath <= @EndDate    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))   
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension    
Order by p.DependantCode    
end /* Beneficiaries of Deceased Pensioners based on Date Deceased */    
    
/* Beneficiaries of Deceased Pensioners based on Date Deceased */    
    
if @BenMode = 3 /* Beneficiaries of Deceased Pensioners based on Date of Retirement and Date Deceased */    
begin  
Exec InsertPenBatchRevision     
     @schemeNo, @RevDate, @BackDateTO, @RevCriteria, @RevMode,@StartDate,@EndDate,    
     @MinPension,@MaxPension,@RevFactor,1,2    
if @RevCriteria = 0 /* All Categories */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, x.DoDeath,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
                and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join PenDeathClaim x on p.SchemeNo = x.schemeNo and p.MemberNo = x.MemberNo    
     and x.DoDeath >= @DecDate and x.DoDeath <= @DecDateEnd    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))    
Order by p.DependantCode    
    
else if @RevCriteria = 1 /* Retirement between 2 cut dates */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, x.DoDeath,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
                and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join PenDeathClaim x on p.SchemeNo = x.schemeNo and p.MemberNo = x.MemberNo    
     and x.DoDeath >= @DecDate and x.DoDeath <= @DecDateEnd    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))  
Order by p.DependantCode    
    
else if @RevCriteria = 2 /* Pension between 2 Values */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, x.DoDeath,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
                and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join PenDeathClaim x on p.SchemeNo = x.schemeNo and p.MemberNo = x.MemberNo    
     and x.DoDeath >= @DecDate and x.DoDeath <= @DecDateEnd    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))    
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension    
Order by p.DependantCode    
    
else if @RevCriteria = 3 /* Retirement between 2 cut dates AND Pension between 2 Values */    
declare Acsr cursor for    
select p.MemberNo,p.DependantCode,p.MonPension, x.DoDeath,p.mPension,d.pcntBenefit    
from PenBeneficiary p    
     inner join Members m on p.SchemeNo = m.schemeNo and p.MemberNo = m.MemberNo    
                and m.DoExit >= @StartDate and m.DoExit <= @EndDate    
     inner join PenDeathClaim x on p.SchemeNo = x.schemeNo and p.MemberNo = x.MemberNo    
     and x.DoDeath >= @DecDate and x.DoDeath <= @DecDateEnd    
     inner join Dependants d on p.SchemeNo = d.schemeNo and p.MemberNo = d.MemberNo    
           and p.DependantCode = d.DependantCode    
where p.SchemeNo = @SchemeNo and ((p.Alive = 1) and (p.Enddate > @RevDate) and (p.stop = 0))   
     and p.MonPension >= @MinPension and p.MonPension <= @MaxPension    
Order by p.DependantCode    
end /* Beneficiaries of Deceased Pensioners based on Date Deceased */    
    
/* Beneficiaries of Deceased Pensioners based on Date Deceased */    
Open Acsr    
    
fetch from Acsr into @MemberNo,@DepCode,@Pension,@RetDate,@mPension,@pcntBenefit    
    
while @@fetch_Status = 0    
begin    
   /*    
   if @RevMode = 0  -- Add a fixed amount     
      select @Pension = (@mPension + @RevFactor)*(@pcntBenefit/100.0000),    
      @NewMPension = (@mPension + @RevFactor)     
   else if @RevMode = 1  --Add by a factor     
      Select @Pension = (@mPension + (@mPension * (@RevFactor/100.000000000)))*(@pcntBenefit/100.0000),    
      @NewMPension = (@mPension + (@mPension * (@RevFactor/100.000000000)))    
   else if @RevMode = 2  -- Adjust to a fixed amount     
      Select @Pension = @RevFactor *(@pcntBenefit/100.0000),@NewMPension = @RevFactor   
   */   
  
       
   if @RevMode = 0  -- Add a fixed amount     
      select @Pension = (@Pension + @RevFactor),@NewMPension = (@RevFactor + @RevFactor)     
   else if @RevMode = 1  --Add by a factor     
      Select @Pension = (@Pension + (@Pension * (@RevFactor/100.000000000))),    
                         @NewMPension = (@Pension + (@Pension * (@RevFactor/100.000000000)))    
   else if @RevMode = 2  -- Adjust to a fixed amount     
      Select @Pension = @RevFactor,@NewMPension = @RevFactor   
     
    
   Exec InsertRevisionBen @schemeNo, @MemberNo, @DepCode, @RevDate, @BackDateTo,1,@BenMode    
    
   if @BenMode = 0    
   begin    
   /* rounding  gross*/    
   select @YaConversion = cast(@Pension as Varchar(25))    
   Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out    
   select @Pension = @Chapaa    
   select @Chapaa = 0    
    
   update MemBeneficiary set MonPension = @Pension,mPension = @NewMPension    
   where SchemeNo = @schemeNo and MemberNo = @MemberNo    
   and DependantCode = @DepCode    
   end    
  ELSE if @BenMode = 1    
   begin    
   /* rounding  gross*/    
   select @YaConversion = cast(@Pension as Varchar(25))    
   Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out    
   select @Pension = @Chapaa    
   select @Chapaa = 0    
    
   update Penbeneficiary set MonPension = @Pension,mPension = @NewMPension    
   where SchemeNo = @schemeNo and MemberNo = @MemberNo    
   and DependantCode = @DepCode    
   end    
    
   select @Pension = 0,@mPension = 0,@pcntBenefit = 0,@NewMPension = 0    
   fetch next from Acsr into @MemberNo,@DepCode,@Pension,@RetDate,@mPension,@pcntBenefit    
end    
    
Close Acsr    
Deallocate Acsr
go

