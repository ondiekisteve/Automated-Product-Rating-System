CREATE PROCEDURE [dbo].[Proc_Ret_Int_Monthly]                      
@SCHEMENO Int,                      
@memberNo int,                      
@CalcDate datetime,                                  
@IntMode Int,                      
@oEmpCont float,                      
@oEmprCont float,                      
@oVolContr float,                      
@oSpecialContr float,                      
@oEmpTransfer float,                      
@oEmprTransfer float,                      
@oPreEmpCont float,                      
@oPreEmprCont float,                      
@oPreAVC float,            
@oDeferred float,         
/* Output Params */                     
@totEmpCont float output,                      
@totEmprCont float output,                      
@totVolContr float output,                      
@totSpecialContr float output,                      
@totEmpTransfer float output,                      
@totEmprTransfer float output,                      
@totPreEmpCont float output,                      
@totPreEmprCont float output,                      
@totPreAVC float output,            
@totDeferred float output                      
--with Encryption                      
as                      
                      
set nocount on                      
                      
if object_id('tempdb..#Balances') is null                      
                      
begin                      
create table #Balances                      
(                      
        [EmpCode][Int] Identity(1,1) Primary Key,                      
        ContrMonth Int,      
        ContrYear Int,                       
        [EmpCont] [float] not  NULL default 0.0,                      
        [EmprCont] [Float] null default 0.0,                      
        [EmprVolCont][float] not null default 0.0,                      
        [EmpVolCont][float] not null default 0.0,                      
        [EmpTransfer][float] not null default 0.0,                      
        [EmprTransfer][float] not null default 0.0,            
        [Deferred][float] null default 0.0                           
)                       
                            
end                      
                      
Declare @AcctPeriod int,@PeriodtoUse int, @sDate datetime, @TopDate datetime, @Loops int,                       
@FiscalType Int,@startMonth int,@empCont float,@emprCont float,@specialContr float,@volContr float,                      
@CempCont float,@CemprCont float,@CspecialContr float,@CvolContr float, @monthPower float,@currMonth int,                      
@currInterest float,@oneHundred float,@newPower float, @curdate varchar(25), @MidDate datetime,                      
@TempEmp float,@TempEmpr float, @TempVol float, @TempSpecial float,@TempEmpTransfer float,@TempEmprTransfer float,                      
@TempEmp1 float,@TempEmpr1 float, @TempVol1 float, @TempSpecial1 float,@TempEmpTransfer1 float,@TempEmprTransfer1 float,                      
@xMonth int,@xYear int,@DatePaid Datetime,@Reason Int,@DoCalc Datetime,                      
@ArEmpCont float,@ArEmprCont float,@ArVolCont float,@ArSpecial float,@ArDate Datetime,                      
@trEmpCont float,@trEmprCont float,@trDate Datetime,                      
@SMonthDate Datetime,@EMonthDate Datetime,@fMonth Int,@fYear Int,@FirstDate Datetime,                      
@EndDate Datetime,@ctrEmpCont float,@ctrEmprCont float,@cPreEmpCont float,@cPreEmprCont float ,@cPreAvc float,                      
@TransferSeparate Int,@trMonth Int,@trYear Int,@EmpTransfer float,@EmprTransfer float,                      
@Fraction float,@MinArrearsDate Datetime,@MinTransferDate Datetime,@counter int, @DistrEmp float,                
@DistrEmpr float,@DistrAVC float,@DistrSpec float, @activestatus int,@IntDays Int,@DateYaLast Datetime,            
@Deferred float,@CDeferred float,@CurMonth int,@currYear int,@ContrMonth Int,@ContrYear Int                     
                      
select @TransferSeparate = TransferSeparate from ConfigWithdrawal where SchemeNo = @schemeNo                      
if @TransferSeparate is null select @TransferSeparate = 0             
select @Deferred = 0                
               
/* Interest starts after how many days to allow for clearance of Cheques */                
                
select @IntDays = intDays from Scheme where schemeCode = @schemeNo                
                
if @IntDays is null select @IntDays = 0                     
        
select @CurMonth  = datepart(Month,@CalcDate),@CurrYear = datepart(Year,@CalcDate)                      
                    
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @currYear, @AcctPeriod out                      
                      
Select @sDate = StartDate,@DateYaLast = EndDate                      
from SchemeYears where SchemeNo = @schemeNo  and AcctPeriod = @AcctPeriod                      
                     
Select @FiscalType = 0                      
                      
select @activestatus = activestatus from members where schemeno = @schemeno and memberno = @memberno                
               
exec getFirstDate @CurMonth,@CurrYear,@sMonthDate out                      
                      
Select @PeriodToUse = @AcctPeriod - 1                      
                               
/* Initialize all variables to Zero */                      
Select @CempCont  = 0                      
Select @CemprCont = 0                      
Select @CspecialContr = 0                      
Select @CvolContr = 0                      
select @ctrEmpCont = 0.0                      
select @ctrEmprCont = 0.0                       
select @cPreEmpCont = 0.0                      
select @cPreEmprCont = 0.0                      
select @cPreAvc = 0.0                      
Select @TempEmp  = 0                      
Select @TempEmpr = 0                      
Select @TempSpecial= 0                      
Select @TempVol = 0                      
Select @TempEmpTransfer= 0                      
Select @TempEmprTransfer = 0                      
select @TempEmp1 = 0                      
select @TempEmpr1 = 0                      
select @TempVol1 = 0                       
select @TempSpecial1 = 0                      
Select @TempEmpTransfer1= 0                      
Select @TempEmprTransfer1 = 0,@cDeferred  = 0                     
                      
EXEC Proc_Get_Int_Rate @schemeNo,@CalcDate,@IntMode,@currInterest Out             
if @currInterest is null select @currInterest = 0                      
                      
                
select @totEmpCont = @oEmpCont, @totEmprCont = @oEmprCont,                      
@totVolContr = @oVolContr, @totSpecialContr = @oSpecialContr,@totEmpTransfer = @oEmpTransfer,                      
@totEmprTransfer=@oEmprTransfer,@TotPreEmpCont=@oPreEmpCont,@totPreEmprCont=@oPreEmprCont,                      
@totPreAvc=@oPreAVC,@totDeferred = @oDeferred                      
        
        
  select @newPower = power((1.0000000000 + (@currInterest/100.000)), ((datediff(day,@SMonthDate,@CalcDate)+1)/365.00))                      
  select @totEmpCont = @totEmpCont * @newPower                      
  select @totEmprCont = @totEmprCont * @newPower                      
  select @totSpecialContr = @totSpecialContr * @newPower                      
  select @totVolContr = @totVolContr  * @newPower                       
  select @totEmpTransfer = @totEmpTransfer * @newPower                      
  select @totEmprTransfer = @totEmprTransfer * @newPower                       
  select @TotPreEmpCont = @TotPreEmpCont * @newPower                      
  select @totPreEmprCont = @totPreEmprCont * @newPower                      
  select @totPreAvc = @totPreAvc * @newPower               
  select @totDeferred = @totDeferred * @newPower          
        
  /*Initialize the Opening Balances */                      
                      
Insert Into #Balances(ContrMonth,ContrYear,EmpCont,EmprCont,EmpVolCont,EmprVolCont,      
                                       EmpTransfer,EmprTransfer,Deferred)    
select ContrMonth,ContrYear, sum(EmpCont) , sum(EmprCont), sum(VolContr) , sum(SpecialContr)                      
                              ,0,0,0                      
from ContributionsSummary                       
WHERE  SchemeNo = @SchemeNo and MemberNo = @MemberNo                       
and ContrMonth = datepart(Month,@SMonthDate)  and ContrYear = datepart(Year,@CalcDate) and AcctPeriod = @acctPeriod and                       
(EmpCont + EmprCont + SpecialContr + VolContr) > 0                      
Group by DatePaid,ContrMonth,ContrYear                      
order by DatePaid                      
                      
/* add Any Contribution Arrears */                                  
     declare ArrCsr cursor for                      
     Select ContrMonth,ContrYear,sum(ArEmpCont),Sum(ArEmprCont),sum(ArVolContr),sum(ArSpecial)                       
     from ContributionArrears where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                       
     AcctPeriod = @AcctPeriod and ContrMonth = datepart(Month,@SMonthDate)  and ContrYear = datepart(Year,@CalcDate)                      
     Group By ContrMonth,ContrYear       
     Order By ContrYear,ContrMonth                                    
          
     Open ArrCsr                       
                      
     Fetch from ArrCsr into @ContrMonth,@ContrYear,@ArEmpCont,@ArEmprCont,@ArVolCont,@ArSpecial                      
                      
     while @@fetch_Status = 0                      
     begin                       
        Insert Into #Balances (ContrMonth,ContrYear,EmpCont,EmprCont,EmpVolCont,EmprVolCont,EmpTransfer,EmprTransfer,Deferred)                      
                     Values(@ContrMonth,@ContrYear,@ArEmpCont,@ArEmprCont,@ArVolCont,@ArSpecial,0,0,0)                      
                                                   
        Select @ArEmpCont = 0,@ArEmprCont = 0,@ArVolCont = 0,@ArSpecial = 0,@ContrMonth=0,@ContrYear=0                      
                      
        Fetch next from ArrCsr into @ContrMonth,@ContrYear,@ArEmpCont,@ArEmprCont,@ArVolCont,@ArSpecial                      
     end                      
     Close ArrCsr                      
     Deallocate ArrCsr                                   
/*End of Contributions Arrears */                      
                                
/* add Any Transfers*/                      
                      
if @TransferSeparate = 0                      
begin                                 
     declare transfercsr cursor for                    
                Select datepart(month,TransferDate),datepart(Year,TransferDate),                      
                sum(EmpTransfer), sum(EmprTransfer),sum(DeferredAmt)                      
                from MemberTransfer where SchemeNo = @SchemeNo and MemberNo =@MemberNo and                       
                AcctPeriod = @AcctPeriod and TransferDate >= @SMonthDate and TransferDate <= @CalcDate                    
                group by TransferDate                    
  open transfercsr                    
                    
  fetch from transfercsr into @ContrMonth,@ContrYear,@TrEmpCont,@TrEmprCont,@Deferred                    
  while @@fetch_status = 0                    
  begin                    
                          
                Insert Into #Balances (ContrMonth,ContrYear,EmpCont,EmprCont,EmpVolCont,EmprVolCont,      
                                       EmpTransfer,EmprTransfer,Deferred)                      
                     Values(@ContrMonth,@ContrYear,@trEmpCont,@trEmprCont,0,0,0,0,@Deferred)                       
                                                   
                Select @trEmpCont = 0,@trEmprCont = 0,@Deferred = 0,@ContrMonth=0,@ContrYear=0                      
  fetch next from transfercsr into @ContrMonth,@ContrYear,@TrEmpCont,@TrEmprCont,@Deferred                  
  end                    
  close transfercsr                    
  deallocate transfercsr                                
end                      
else if @TransferSeparate = 1                      
begin               
  declare transfercsr cursor for                    
                Select datepart(month,TransferDate),datepart(Year,TransferDate),                       
                 sum(EmpTransfer), sum(EmprTransfer ),sum(DeferredAmt)                      
                from MemberTransfer where SchemeNo = @SchemeNo and MemberNo =@MemberNo and                       
                AcctPeriod = @AcctPeriod and TransferDate >= @SMonthDate and TransferDate <= @CalcDate                    
  group by TransferDate                    
  open transfercsr                    
                    
  fetch from transfercsr into @ContrMonth,@ContrYear, @TrEmpCont,@TrEmprCont,@Deferred                    
  while @@fetch_status = 0                    
  begin                    
                          
                Insert Into #Balances (ContrMonth,ContrYear,EmpCont,EmprCont,EmpVolCont,EmprVolCont,EmpTransfer,EmprTransfer,Deferred)                      
                     Values(@ContrMonth,@ContrYear,0,0,0,0,@trEmpCont,@trEmprCont,@Deferred)                      
                                                   
                Select @trEmpCont = 0,@trEmprCont = 0,@Deferred = 0,@ContrMonth=0,@ContrYear=0                      
            fetch next from transfercsr into @ContrMonth,@ContrYear, @TrEmpCont,@TrEmprCont,@Deferred                    
            end                    
            close transfercsr                    
            deallocate transfercsr                    
end                      
                    
/*End of Transfers */                          
/* Calculate the Interest */                     
                
                
          declare Acsr cursor for                      
          select ContrMonth,ContrYear,EmpCont, EmprCont, EmprVolCont, EmpVolCont,EmpTransfer,EmprTransfer,Deferred                      
          from #Balances                       
          order by ContrYear,ContrMonth               
          open Acsr                      
                                               
          fetch from Acsr                      
          into @ContrMonth,@ContrYear,@empCont, @emprCont, @specialContr, @volContr,@EmpTransfer,@EmprTransfer,@Deferred                      
                      
          while @@fetch_Status = 0                      
          begin                 
        
                        Exec GetLastDate @ContrMonth,@ContrYear,@TopDate Out      
      
                        Exec GetTenthDate @TopDate,@MidDate Out         
         
                        if @Deferred is null select @Deferred = 0.0        
           
                        if @MidDate > @CalcDate select @MidDate = @CalcDate                
                
                        select @newPower = power((1.0000000000 + (@currInterest/100.000)), (datediff(day,@MidDate,@CalcDate)/365.00))                      
                      
                        select @cEmpCont = (@cEmpCont + @empCont) * @newPower                      
                        select @cEmprCont = (@cEmprCont + @emprCont) * @newPower                      
                        select @cSpecialContr = (@cSpecialContr + @specialContr) * @newPower                      
                        select @cVolContr = (@cVolContr + @volContr)  * @newPower                       
                        select @ctrEmpCont = (@ctrEmpCont + @EmpTransfer) * @newPower                      
                        select @ctrEmprCont = (@ctrEmprCont + @EmprTransfer) * @newPower                     
                        select @cPreEmpCont = @cPreEmpCont * @newPower                      
                        select @cPreEmprCont = @cPreEmprCont * @newPower                      
                        select @cPreAvc = @cPreAvc * @newPower                      
                        select @cDeferred = (@cDeferred + @Deferred) * @newPower             
                      
                        /* Add Contributions + Interest to the Grand Total */                 
                        Select @totEmpCont  = @cEmpCont + @totEmpCont                      
                        Select @totEmprCont  = @cEmprCont + @totEmprCont                      
                        Select @totVolContr  = @cVolContr + @totVolContr                       
                        Select @totSpecialContr = @cSpecialContr + @totSpecialContr                      
                        select @totEmpTransfer  = @ctrEmpCont + @totEmpTransfer                      
                        select @totEmprTransfer = @ctrEmprCont + @totEmprTransfer                      
                        select @totPreEmpCont = @cPreEmpCont + @totPreEmpCont                      
                        select @totPreEmprCont = @cPreEmprCont + @totPreEmprCont                      
                        select @totPreAVC  = @cPreAvc + @totPreAVC              
                        select @totDeferred  = @cDeferred + @totDeferred                     
                      
                        select @cEmpCont = 0.0                      
                        select @cEmprCont = 0.0                      
                        select @cSpecialContr = 0.0                      
                        select @cVolContr = 0.0                       
                        select @ctrEmpCont = 0.0                      
                        select @ctrEmprCont = 0.0                       
                        select @cPreEmpCont = 0.0                      
                        select @cPreEmprCont = 0.0                      
                        select @cPreAvc = 0.0,@newPower = 0.0,@cDeferred = 0                      
                                             
                        select @empCont=0.0, @emprCont=0.0, @specialContr=0.0, @volContr=0.0,@EmpTransfer=0.0,      
                               @EmprTransfer=0.0,@Deferred = 0,@ContrMonth=0,@ContrYear=0                    
              fetch next from Acsr                      
              into @ContrMonth,@ContrYear,@empCont, @emprCont, @specialContr, @volContr,@EmpTransfer,@EmprTransfer,@Deferred                      
              end                      
              Close Acsr                      
              Deallocate Acsr
go

