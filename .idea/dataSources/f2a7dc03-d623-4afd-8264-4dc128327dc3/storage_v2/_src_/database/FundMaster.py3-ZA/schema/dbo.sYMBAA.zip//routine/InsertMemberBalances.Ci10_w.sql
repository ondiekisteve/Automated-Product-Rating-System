CREATE PROCEDURE [dbo].[InsertMemberBalances]
--with Encryption
as
declare @MemberNo int,@EmpCont float,@EmprCont float

declare acsr cursor for
Select MemberNo,EmpCont1,EmprCont1
from Balances
order by MemberNo

Open acsr

fetch from acsr into @MemberNo,@EmpCont,@EmprCont

while @@fetch_Status = 0
begin
   if @EmpCont is null select @EmpCont = 0
   if @EmprCont is null select @EmprCont = 0

   Insert Into MemberOpeningBalances
   (SchemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,EmpCont,EmprCont)
   Values
   ('1205',@MemberNo,2001,12,2,@EmpCont,@EmprCont)

   Select @EmpCont = 0,@EmprCont = 0
   fetch next from acsr into @MemberNo,@EmpCont,@EmprCont
end
Close Acsr
Deallocate Acsr
go

