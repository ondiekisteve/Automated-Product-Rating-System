CREATE PROCEDURE [dbo].[InsertOffshore]      
@SCHEMENO Int,      
@OffshoreNo int,      
@InvestDate datetime,      
@Manager varchar(20),      
@OffshoreFoRex Int      
--with Encryption      
as      
      
insert into Offshore(SchemeNo, OffshoreNo,UnitsBought,CostPerUnit,      
                     DateInvested,Manager,CountryCode,OffshoreFoRex,SpotRate)      
            Values (@SchemeNo, @OffshoreNo, 0,0,@InvestDate,@Manager,0,@OffshoreFoRex,1.00000)
go

