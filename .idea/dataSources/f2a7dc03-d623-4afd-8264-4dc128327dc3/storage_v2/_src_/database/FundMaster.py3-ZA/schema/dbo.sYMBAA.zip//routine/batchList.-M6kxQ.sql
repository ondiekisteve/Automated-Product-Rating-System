CREATE PROCEDURE [dbo].[batchList]    
@SCHEMENO Int,    
@SponsorNo Int, /*Oracle*/   
@StartDate datetime,  
@EndDate datetime   
--with Encryption    
as    
    
declare @SchemeMode1 Int    
    
select @schemeMode1 = schemeMode from scheme where SchemeCode = @schemeNo    
    
if @schemeMode1 is null select @schemeMode1 = 0    
    
if @schemeMode1 = 0    
   select BatchYear, BatchMonth, BatchDesc,CompanyId,BatchDate,    
   case Posted     
     when 0 then 'Not Posted'    
     when 1 then 'Posted'    
   end as BatchStatus,BatchId,  
   case BatchStatus     
     when 0 then 'No'    
     when 1 then 'Yes'    
   end as StatusDesc    
   from Batches    
   where SchemeNo = @SchemeNo and BatchDate >= @StartDate and BatchDate <= @EndDate      
   order By BatchYear Desc,BatchMonth desc    
else    
   select BatchYear, BatchMonth, BatchDesc,CompanyId,BatchDate,    
   case Posted     
     when 0 then 'Not Posted'    
     when 1 then 'Posted'    
   end as BatchStatus,BatchId,  
   case BatchStatus     
     when 0 then 'No'    
     when 1 then 'Yes'    
   end as StatusDesc     
   from Batches    
   where SchemeNo = @SchemeNo and SponsorCode = @SponsorNo   
   and BatchDate >= @StartDate and BatchDate <= @EndDate   
   order By BatchYear Desc,BatchMonth desc
go

