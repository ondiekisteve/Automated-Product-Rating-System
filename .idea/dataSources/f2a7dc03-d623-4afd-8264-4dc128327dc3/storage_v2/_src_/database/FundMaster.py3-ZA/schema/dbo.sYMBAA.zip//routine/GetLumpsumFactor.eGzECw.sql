CREATE PROCEDURE [dbo].[GetLumpsumFactor]
@SCHEMENO Int,
@TransDate Datetime,
@LumpFactor float out
--With Encryption
as

declare @MinDate Datetime
select @MinDate = Min(StartDate) from LumpsumFactor
where SchemeNo = @schemeNo

if @Transdate < @MinDate
   Select @LumpFactor = LumpFactor
   from LumpsumFactor where SchemeNo = @schemeNo
   and StartDate = @MinDate
else
   Select @LumpFactor = LumpFactor
   from LumpsumFactor
   where SchemeNo = @SchemeNo and StartDate <= @TransDate and EndDate >= @TransDate
go

