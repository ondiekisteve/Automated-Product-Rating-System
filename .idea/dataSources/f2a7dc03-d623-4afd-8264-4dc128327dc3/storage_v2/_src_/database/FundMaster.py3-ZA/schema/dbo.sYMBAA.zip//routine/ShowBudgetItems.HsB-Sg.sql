CREATE PROCEDURE [dbo].[ShowBudgetItems]      
@schemeNo Int,            
@Mode Integer,        
@CashflowCode Int            
--with Encryption            
as            
if object_id('tempdb..#BudgetItems') is null            
            
begin            
create table #BudgetItems            
(            
        [ItemCode][Int] primary key,            
        [ItemDesc] [varchar](50) NOT NULL,            
        [cashflowCode]Int,  
        [HeaderCode] Int            
)                
end            
            
if @Mode = 0            
   Insert Into #BudgetItems select IncomeCode,IncomeDesc,cashflowCode,HeaderCode            
                            from IncomeItems where cashflowCode = @CashflowCode            
else            
   Insert Into #BudgetItems select ExpenditureCode,ExpenditureDesc,cashflowCode,HeaderCode            
                            from ExpenditureItems where cashflowCode = @CashflowCode                 

Select * from #BudgetItems order by HeaderCode
go

