CREATE PROCEDURE [dbo].[Proc_Claims_Per_Reason_Group]      
@SCHEMENO Int,      
@ClaimYear int      
--with Encryption      
as      
      
if object_id('tempdb..#Claims_Per_Reason') is null      
      
begin      
create table #Claims_Per_Reason      
(      
        [ClaimCounter][Int] identity(1,1),  
 [SchemeNo] [Int] NOT NULL,      
 [SchemeName] [varchar] (120) NOT NULL,      
 [Claim] [float] not NULL,       
        [NumMembers] [Int]  not NULL,      
 [ClaimDesc] [Varchar](100)  not NULL,      
        [SponsorName][varchar](100),      
        [STARTDate][Datetime],      
        [EndDate][Datetime],  
 [PoolName][varchar](120)              
)       
      
ALTER TABLE #Claims_Per_Reason WITH NOCHECK ADD                   
 CONSTRAINT [PK_ClaimsToDate] PRIMARY KEY  NONCLUSTERED       
 (      
  [ClaimCounter]      
 )       
end      
      
      
Declare @SchemeName varchar(120), @Claim float, @NumMembers int,       
        @ClaimDesc Varchar(100), @TotalClaim float,@ClaimUn float,      
@StartDate Datetime,@EndDate Datetime,@AcctPeriod Int,@SchemeMode smallInt,@FundCategory varchar(30),      
@SponsorCode Int,@SponsorName varchar(100),@ReasonCode smallInt,      
  @PooledInvestment smallInt,@SchemeCode Int,        
  @PoolName varchar(120),@FundType varchar(2)               
  
select @PoolName = schemeName,@SchemeMode = schemeMode,@PooledInvestment = PooledInvestment,@FundType = FundType        
  from scheme where schemeCode = @schemeNo   
      
select @StartDate = StartDate,@EndDate = EndDate from schemeYears where schemeNo = @schemeNo      
and DatePart(Year,EndDate) = @ClaimYear      
  
if @FundType = 'PF'        
BEGIN        
Declare ContSummaryCsr cursor for        
select schemeCode,schemeName from Scheme        
where PooledInvestment = 1 and InvestmentScheme = @schemeNo      
        
Open ContSummaryCsr        
Fetch from ContSummaryCsr into @schemeCode,@schemeName        
while @@fetch_Status = 0        
begin    
    
select @StartDate = StartDate,@EndDate = EndDate from schemeYears where schemeNo = @schemeCode        
and DatePart(Year,EndDate) = @ClaimYear      
      
  declare ReasonCsr Cursor for      
  Select ReasonCode,ReasonDesc from      
  ReasonforExit where ReasonCode > 0 and ReasonCode <> 7      
  open ReasonCsr      
  Fetch from ReasonCsr into @ReasonCode,@ClaimDesc      
  while @@fetch_Status = 0      
  begin      
   Declare ClaimCsr cursor for       
   Select Count(*) as NumMembers,      
   sum(b.EmpcBal + b.VestedCont + b.VolCBal + b.SpecialCBal)      
   from Members m      
     inner Join Benefits b on m.schemeNo = b.schemeNo and m.MemberNo = b.MemberNo      
     Inner join LumpAuthorization l  on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo      
     and l.DatePrepared >= @StartDate and l.DatePrepared <= @EndDate      
   where m.SchemeNo = @schemeCode and m.ReasonforExit= @reasonCode      
   Open ClaimCsr      
      
   fetch from ClaimCsr into @NumMembers,@Claim      
      
   while @@fetch_status = 0      
   begin      
      if @Claim is null select @Claim = 0      
            
      
   IF @Claim > 0.0      
      insert into #Claims_Per_Reason(SchemeNo,schemeName,Claim,NumMembers,ClaimDesc,      
                                     StartDate,EndDate,PoolName)      
               Values(@schemeCode,@schemeName,@Claim, @NumMembers, @ClaimDesc,      
                      @StartDate,@EndDate,@PoolName)      
      
   select @Claim = 0.0,@NumMembers = 0.0      
   fetch next from ClaimCsr into @NumMembers,@Claim      
   end      
   Close ClaimCsr      
   Deallocate ClaimCsr      
   select @ReasonCode = 0,@ClaimDesc = ''      
  Fetch next from ReasonCsr into @ReasonCode,@ClaimDesc      
  end      
  Close ReasonCsr      
  Deallocate ReasonCsr      
  Select * from #Claims_Per_Reason ORDER BY CLAIMDESC      
   
select @schemeCode=0,@schemeName=''        
Fetch next from ContSummaryCsr into @schemeCode,@schemeName        
end        
Close ContSummaryCsr        
Deallocate ContSummaryCsr    
        
END    
        
Else if @FundType <> 'PF'    
        
BEGIN        
select @schemeName = @PoolName   
  
declare ReasonCsr Cursor for      
  Select ReasonCode,ReasonDesc from      
  ReasonforExit where ReasonCode > 0 and ReasonCode <> 7      
  open ReasonCsr      
  Fetch from ReasonCsr into @ReasonCode,@ClaimDesc      
  while @@fetch_Status = 0      
  begin      
   Declare ClaimCsr cursor for       
   Select Count(*) as NumMembers,      
   sum(b.EmpcBal + b.VestedCont + b.VolCBal + b.SpecialCBal)      
   from Members m      
     inner Join Benefits b on m.schemeNo = b.schemeNo and m.MemberNo = b.MemberNo      
     Inner join LumpAuthorization l  on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo      
     and l.DatePrepared >= @StartDate and l.DatePrepared <= @EndDate      
   where m.SchemeNo = @SchemeNo and m.ReasonforExit= @reasonCode      
   Open ClaimCsr      
      
   fetch from ClaimCsr into @NumMembers,@Claim      
      
   while @@fetch_status = 0      
   begin      
      if @Claim is null select @Claim = 0      
            
      
   IF @Claim > 0.0      
      insert into #Claims_Per_Reason(SchemeNo,schemeName,Claim,NumMembers,ClaimDesc,      
                                     StartDate,EndDate)      
               Values(@SchemeNo,@schemeName,@Claim, @NumMembers, @ClaimDesc,      
                      @StartDate,@EndDate)      
      
   select @Claim = 0.0,@NumMembers = 0.0      
   fetch next from ClaimCsr into @NumMembers,@Claim      
   end      
   Close ClaimCsr      
   Deallocate ClaimCsr      
   select @ReasonCode = 0,@ClaimDesc = ''      
  Fetch next from ReasonCsr into @ReasonCode,@ClaimDesc      
  end      
  Close ReasonCsr      
  Deallocate ReasonCsr      
  Select * from #Claims_Per_Reason ORDER BY CLAIMDESC  
  
END
go

