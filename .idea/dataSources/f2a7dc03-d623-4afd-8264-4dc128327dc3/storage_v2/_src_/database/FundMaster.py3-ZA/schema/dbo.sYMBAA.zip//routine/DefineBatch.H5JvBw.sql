CREATE PROCEDURE [dbo].[DefineBatch]                      
@SCHEMENO Int,                      
@BatchMonth Int,                      
@BatchYear Int,                      
@CompanyId Int,                      
@BatchDate datetime,                      
@ChequeNo varchar(15),                      
@ReceiptNo varchar(15),                      
@ChequeAmount float,                      
@SponsorCode Int,                      
@SponsorOrGeneral Int,                    
@CostCenter Int                      
--with encryption                      
as                      
                      
DECLARE  @BatchDef Varchar(50),@CompanyName varchar(100),@ContributionMode Int,@batchId Int,                    
@PrevBatch Int,@EmpRate float,@EmprRate float,@ContrYear Int,@PrevMonth Int,@PrevYear Int  
  
if @BatchMonth = 1  
   begin  
      select @PrevMonth = 12,@PrevYear = @BatchYear - 1  
   end  
else  
   begin  
   select @PrevMonth = @BatchMonth - 1,@PrevYear = @BatchYear    
   end    
    
IF @CompanyId is null select @CompanyId =  1                      
            
if @Costcenter = 1 select @CompanyId = min(CompanyId) from SchemeCompanies                
   where SchemeNo = @SchemeNo            
                
select @ContrYear = Max(ContrYear) from ContributionRates where schemeNo = @schemeNo                
                
if @ContrYear > 0                
   begin                
     select @EmpRate = Max(EmpContRate),@EmprRate = Max(EmprContRate) from ContributionRates                
     where schemeNo = @schemeNo and ContrYear = @ContrYear                
   end                
else                
   begin                
     select @EmpRate = 0.0,@EmprRate = 0.0                
   end                
                      
select @batchId = Max(BatchId) from Batches /* 24/5/2006 */                      
                      
if @batchId is null select @batchId = 0                      
                      
select @batchId = @batchId + 1                      
                      
select @ContributionMode = ContributionMode from Scheme where SchemeCode = @SchemeNo                      
                      
if @ChequeNo is null select @ChequeNo = '0'                      
if @ReceiptNo is null select @ReceiptNo = '0'                      
if @ChequeAmount is null select @ChequeAmount = 0.0                      
                      
select @CompanyName = CompanyName from SchemeCompanies                      
where SchemeNo = @schemeNo and CompanyId = @CompanyId                      
                      
select @BatchDef = MonthName from MonthTable where MonthNumber = @BatchMonth                      
                      
select @BatchDef = @CompanyName+' - '+@BatchDef +', '+ cast(@BatchYear as Varchar(4))+' Batch'                      
                      
if @ContributionMode > 4                      
   select @BatchDef = cast(@BatchDate as Varchar(15))+' : '+@BatchDef                      
                      
Insert Into Batches (SchemeNo,BatchYear,BatchMonth,SchemeYear,BatchDesc,BatchDate,CompanyId,                      
                     ChequeNo,ReceiptNo,ChequeAmount,BatchTotal,SponsorCode,BatchId,ImportMode,        
                     ReceiptDate,PostingAnalysis)                      
Values(@SchemeNo,@BatchYear,@BatchMonth,@BatchYear,@BatchDef,@BatchDate,@CompanyId,                      
       @ChequeNo,@ReceiptNo,@ChequeAmount,0,@SponsorCode,@BatchId,@SponsorOrGeneral,@BatchDate,'BATCH NOT AUTHORISED FOR POSTING')                      
      
if @SponsorCode > 0      
   select @PrevBatch = Max(BatchId) from Batches where schemeNo = @SchemeNo and BatchId < @batchId      
   and SponsorCode = @SponsorCode and CompanyID = @CompanyId and BatchMonth = @PrevMonth and BatchYear = @PrevYear    
else                    
   select @PrevBatch = Max(BatchId) from Batches where schemeNo = @SchemeNo and BatchId < @batchId        
   and CompanyID = @CompanyId and BatchMonth = @PrevMonth and BatchYear = @PrevYear                 
                    
if @PrevBatch is null select @PrevBatch = @batchId                   
            
select @batchId as BatchId,@PrevBatch as PrevBatch,@EmpRate as EmpRate,@EmprRate as EmprRate
go

