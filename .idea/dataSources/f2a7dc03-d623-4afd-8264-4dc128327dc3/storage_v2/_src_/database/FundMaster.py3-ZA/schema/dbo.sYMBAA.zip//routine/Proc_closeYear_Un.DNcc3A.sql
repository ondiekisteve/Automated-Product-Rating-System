--> CHECKED AND VERIFIED ON 22ND JANUARY 2002 by the SysTech Development Team                              
                              
/*                              
This PROCEDURE DBO.is used to close the current scheme year and enter opening balances                              
for the current year into the opening balances table                              
                              
APRIL 11,2006                               
=================                              
inner join Benefits ba on m.schemeNo = ba.schemeNo and m.MemberNo = ba.MemberNo                              
     and ba.ProcessDate = @EndDate and ba.DeferredBenefit <> 1                              
*/                              
                              
CREATE PROCEDURE [dbo].[Proc_closeYear_Un]                             
@SCHEMENO Int,                              
@StartDate Datetime,                              
@EndDate datetime                              
--with Encryption                              
as                              
                              
set nocount on                              
                              
begin tran                              
                              
declare @EmpCont float,@EmprCont float,@Special float,                              
@AVC float,@memberNo int,@yearClosed bit,@SoftClosed smallint, @AcctPeriod int,                              
@BalanceOfInt SmallInt,@EmpTax float,@EmprTax float,@VolTax float,@SpecTax float,                              
@UnregInterest Int,@DoCalc Datetime,@ActiveStatus Int,@EmpInterest float,@EmprInterest float,                              
@VolInterest float,@SpecInterest float,@EmpFees_Un float,@EmprFees_Un float,                            
@DeferredAmt float,@DefInterest float,@DefTax float,@xMonth Int,@xYear Int,@InitialDoCalc datetime,@DeferredPaid smallint                  
                  
select @xMonth = datepart(Month,@EndDate),@xYear = datepart(Year,@EndDate)                             
                              
Select @BalanceofInt = CalcBalanceofInterest,@UnregInterest = UnregInterest                               
from ConfigYearEnd where SchemeNo = @schemeNo                              
                              
if @BalanceofInt is null select @BalanceofInt = 0                              
if @UnregInterest is null select @UnregInterest = 0                              
                              
Select @AcctPeriod = AcctPeriod,@SoftClosed = SoftClosed                              
from schemeYears                               
where SchemeNo = @schemeNo and StartDate = @StartDate and EndDate = @EndDate                              
                              
                              
declare csr_Memb cursor for                              
select Distinct(m.MemberNo),m.DoCalc,m.ActiveStatus,m.InitialDoCalc,m.DeferredPaid                              
from Members  m                              
     inner join UnRegisteredBenefits b on m.schemeNo = b.schemeNo and m.MemberNo = b.MemberNo                              
     and b.ProcessDate = @EndDate AND b.IncludeRec = 1                                                  
where m.SchemeNo = @SchemeNo and m.UnRegistered = 1 and ((m.activestatus <> 6)                
OR ((M.ActiveStatus = 6) and (m.DeferredPaid = 0))                
or ((m.Activestatus = 6) and (m.DeferredPaid = 1) and (m.DoCalc > @EndDate)))                              
Order by m.MemberNo                              
                              
open csr_Memb                              
fetch next from csr_Memb into @memberNo,@DoCalc,@ActiveStatus,@InitialDoCalc,@DeferredPaid                              
                              
while @@fetch_status = 0                              
begin    
  
      if @DeferredPaid is null select @DeferredPaid = 0  
                            
         select @EmpCont = ExcessEmpCont,@EmprCont = ExcessEmprCont,                              
         @Avc = ExcessVolContr,@Special =  ExcessSpecial,                              
         @EmpTax = EmpTax,@EmprTax = EmprTax,@VolTax  = VolTax,@SpecTax = SpecTax,                              
         @EmpInterest = EmpInt,@EmprInterest = EmprInt,                              
         @VolInterest = VolInt,@SpecInterest = SpecInt,                              
         @EmpFees_Un = EmpFees_Un,@EmprFees_Un = EmprFees_Un,                    
         @DeferredAmt = DeferredAmt,@DefInterest = DefInterest  from                              
         UnRegisteredBenefits where SchemeNo = @schemeNo and MemberNo = @MemberNo                              
         and ProcessDate = @EndDate                              
                             
         if @EmpCont is null select  @EmpCont = 0                              
         if @EmprCont is null select @EmprCont =  0                     
         if @Avc is null select @Avc = 0                              
         if @Special is null select @Special = 0                              
         if @EmpTax is null select  @EmpTax = 0                              
         if @EmprTax is null select @EmprTax =  0                              
         if @VolTax is null select @VolTax = 0                              
         if @SpecTax is null select @SpecTax = 0                              
         if @EmpFees_Un is null select @EmpFees_Un = 0                              
         if @EmprFees_Un is null select @EmprFees_Un = 0                              
                              
         if @EmpInterest is null select  @EmpInterest = 0                              
         if @EmprInterest is null select @EmprInterest =  0                              
         if @VolInterest is null select @VolInterest = 0                              
         if @SpecInterest is null select @SpecInterest = 0                              
         if @DeferredAmt is null select @DeferredAmt = 0                              
         if @DefInterest is null select @DefInterest = 0                             
                            
 if  @DefInterest > 0                            
     select @DefTax = @DefInterest *.30                            
 else                            
     select @DefTax = 0                            
                              
                       
   IF (@ActiveStatus = 6)  
     begin  
         if ((@DeferredPaid = 0) AND ((@InitialDoCalc < @EndDate) AND (@InitialDoCalc >= @StartDate)))  
            select @EmpFees_Un = 0,@EmpCont=0,@Avc=0,@EmpTax=0,@VolTax=0,@EmpInterest=0,@VolInterest = 0  
         else if ((@DeferredPaid = 0) AND (@InitialDoCalc < @StartDate))  
            select @EmpFees_Un = 0,@EmprFees_Un = 0,@EmpCont=0,@Avc=0,@EmpTax=0,@VolTax=0,@EmpInterest=0,@VolInterest = 0    
     end                        
                            
 IF (@EmpCont + @EmprCont + @Avc + @Special + @DeferredAmt ) <> 0                              
    BEGIN                              
         Insert Into UnRegisteredBalances                              
         (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,                              
         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,                              
         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,DeferredAmt,DefInterest,DefTax,ProvOrFinal)                              
         Values                              
         (@schemeNo,@MemberNo,DatePart(Year,@EndDate),DatePart(Month,@EndDate),@AcctPeriod,                              
         @EmpCont,@EmprCont,@Avc,@Special,@EmpTax,@EmprTax,@VolTax,@SpecTax,                              
         @EmpInterest,@EmprInterest,@VolInterest,@SpecInterest,@EmpFees_Un,@EmprFees_Un,                            
         @DeferredAmt,@DefInterest,@DefTax,1)                              
    END                              
    select @EmpCont = 0,@EmprCont=0,@Avc=0,@Special=0,@EmpTax = 0, @EmprTax = 0, @VolTax = 0, @SpecTax = 0,      
    @EmpInterest=0.0,@EmprInterest=0.0,@VolInterest=0.0,@SpecInterest=0.0,@EmpFees_Un =0,@EmprFees_Un=0,@DeferredPaid=0                              
  fetch next from csr_Memb into @memberNo,@DoCalc,@ActiveStatus,@InitialDoCalc,@DeferredPaid                              
end                              
Close Csr_Memb                              
Deallocate Csr_Memb                              
                              
/* DEFERRED BENEFIT */                   
     
/* MEMBERS with Unregistered but without registered Balances */                  
                  
declare hacsr cursor for                  
select memberNo from UnRegisteredBalances                  
where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and MemberNo not in                   
(select MemberNo from MemberOpeningBalances where AcctPeriod = @AcctPeriod and SchemeNo = @schemeNo)                  
                  
open hacsr                  
fetch from hacsr into @MemberNo                  
while @@fetch_status = 0                  
begin                  
  Exec [dbo].[insertOpeningBalance] @schemeNo,@MemberNo,0,0,0,0,@xYear,@xMonth,0,0,0,0,0,0,@EndDate                   
                  
  select @MemberNo = 0                  
  fetch next from hacsr into @MemberNo                  
end                  
close hacsr                  
deallocate hacsr                             
commit tran
go

