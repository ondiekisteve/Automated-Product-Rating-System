CREATE PROCEDURE [dbo].[Proc_Insert_Edit_Reserve_Balance]      
@SCHEMENO Int,      
@AcctPeriod Int,      
@ReserveBalance float,      
@Registered Int,      
@AddEdit Int,    
@SponsorCode Int      
as      
DECLARE @MaxPeriod Int,@YearClosed smallInt,@SchemeMode smallint      
select @MaxPeriod = Max(AcctPeriod) from SchemeYears where schemeNo = @schemeNo

select @SchemeMode = SchemeMode from scheme where schemeCode = @SCHEMENO 

if @SchemeMode is null select @SchemeMode = 0 

if @SchemeMode  = 0
   select @SponsorCode = 0   
  
  
select @YearClosed = YearClosed from schemeYears where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod  
     
if @MaxPeriod = @AcctPeriod      
   begin      
     Raiserror('You Cannot Define the Reserve Balance for the Current Period',16,1)      
     rollback tran      
   end   
else if @YearClosed = 1  
   begin  
     Raiserror('You Cannot Add/Edit/Delete the balances for a Closed Period',16,1)      
     rollback tran      
   end     
else      
   begin       
      if @Registered = 0      
         begin      
            if @AddEdit = 0      
               Insert Into ReserveOpeningBalance (SchemeNo,AcctPeriod,ReserveBalance,SponsorCode)      
                                  Values(@SchemeNo,@AcctPeriod,@ReserveBalance,@SponsorCode)      
            else if @AddEdit = 1      
               Update ReserveOpeningBalance set ReserveBalance = @ReserveBalance,SponsorCode = @SponsorCode      
               where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and Sponsorcode = @SponsorCode      
         end      
     else if @Registered = 1      
         begin      
             if @AddEdit = 0      
                Insert Into Un_ReserveOpeningBalance (SchemeNo,AcctPeriod,ReserveBalance,SponsorCode)      
                                  Values(@SchemeNo,@AcctPeriod,@ReserveBalance,@SponsorCode)      
             else if @AddEdit = 1      
                Update Un_ReserveOpeningBalance set ReserveBalance = @ReserveBalance,SponsorCode = @SponsorCode      
                where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and Sponsorcode = @SponsorCode      
   end      
end
go

