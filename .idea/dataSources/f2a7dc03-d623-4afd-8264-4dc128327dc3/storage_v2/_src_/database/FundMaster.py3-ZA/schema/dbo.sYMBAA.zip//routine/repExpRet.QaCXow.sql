CREATE PROCEDURE [dbo].[repExpRet]            
@SCHEMENO Int,            
@StartYear datetime,            
@EndYear datetime,            
@EscalFactor float,            
@SalFactor float,            
@CutOffAge Int,            
@AgeMode Int, /* 0 - Between, 1 - Above */            
@CashOrLumpsum Int /* 0 - Lumpsum, 1 -  Cash Equivalent */            
--with Encryption            
as            
            
if object_id('tempdb..#expectedRet') is null            
            
begin            
create table #ExpectedRet            
(            
             [RetNo][Int] identity(1,1),          
             [SchemeNo][int] not null,            
             [SchemeName] [varchar] (120) NOT NULL ,            
             [memberNo][varchar](20) not null,      
             [IDNumber][varchar](20) null,      
             [PayrollNo][varchar](20) null,            
             [fullname][varchar] (90) null,            
             [dob][datetime] not null,             
             [djpens][datetime] null,            
             [RetDate][datetime] not null,            
             [Age][int] not null,            
             [sex][varchar](6) null,                
             [Lumpsum][float] null,            
             [Annual][float] null,            
             [Monthly][float] null,            
             [Salary][float] null,            
             [YearsToRet][int] not null ,             
             [EscalFactor][float] null,            
             [SalFactor][float] null,            
             [StartYear][datetime] null,            
             [EndYear][datetime] null,            
             [FundType][varchar](2),            
             [Currency][Varchar](20),            
             [SponsorName][varchar](100),          
             [PoolName][varchar](120)          
                    
)                    
            
ALTER TABLE #ExpectedRet WITH NOCHECK ADD                         
 CONSTRAINT [PK_ExpectedRet] PRIMARY KEY  NONCLUSTERED             
 (            
  [SchemeName] ,[RetNo]                                 
 )             
end            
            
declare @memberNo varchar(20)       
declare @IDNumber varchar(20)           
declare @curYear int            
declare @curMonth int            
declare @dob datetime            
declare @fullname varchar(90)            
declare @djpens datetime            
declare @RetDate datetime            
declare @Sex varchar(6)            
declare @cEmpBal float            
declare @cEmprBal float            
declare @grandTotal float            
declare @Salary float            
declare @Age int            
declare @NumYears int            
declare @YearsToRet int            
declare @SalFactor1 float            
declare @EscalFactor1 float            
declare @avc float            
declare @MemberClass varchar(3)            
declare @Erate float            
declare @erRate float            
declare @totrate float,            
            
@FundType varchar(2), @PenFactor float, @CalcYears float, @Comm float,            
@LFactor int, @MaxLum float, @Total float,@Lumpsum float,@Annual float,@Monthly float,            
@Cash float,@Pension float,@SchemeName varchar(120),@Curr varchar(15),@Currency varchar(20),            
@Gratuity float,@Reduced float,@ActMode int,@FundCategory Varchar(30),@PayrollNo Varchar(20),          
@PooledInvestment smallInt,@SchemeCode Int,@PoolName varchar(120)
           
            
Select  @PoolName = schemeName,@Curr = Currency,@ActMode = ActMode,@FundType  = FundType,            
 @FundCategory = FundCategory,@PooledInvestment = PooledInvestment          
 from scheme where schemeCode = @schemeNo            
            
Select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @Curr            
            
declare @OneHundred float            
select @oneHundred = 100.0000000000            
            
select @SalFactor1 = @SalFactor/@OneHundred            
select @EscalFactor1 = @EscalFactor/@OneHundred            
            
select @NumYears = 0,@YearsToRet =0            
          
if @FundType = 'PF'            
BEGIN            
Declare ExpRetCsr cursor for            
select schemeCode,schemeName from Scheme            
where PooledInvestment = 1 and InvestmentScheme = @schemeNo          
            
Open ExpRetCsr            
Fetch from ExpRetCsr into @schemeCode,@schemeName            
while @@fetch_Status = 0            
begin          
            
select @FundType  = FundType, @PenFactor = PensionFactor from scheme where SchemeCode = @schemeCode            
            
select @Comm = CommRate, @LFactor = LFactor, @MaxLum = MaxLumpPay from Pension_setup             
where SchemeNo = @schemeCode            
               
select @curYear = Max(AcctPeriod) from schemeYears where SchemeNo = @schemeCode            
            
IF @CashOrLumpsum = 1          
   BEGIN            
       if @AgeMode = 0 /* Between */            
        declare ExpectCsr cursor for            
        select            
        distinct(Members.MemberNo),Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
     case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
        else            
             'Unknown'            
        end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),Members.Avc, Members.Avc,            
        Members.PayrollNo,Members.IDNumber            
        from Members            
                    /*inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/            
        where Members.SchemeNo = @schemeCode and Members.ReasonforExit = 0             
        and DateAdd(Year,@CutOffAge,members.dob) >= @StartYear            
        and DateAdd(Year,@CutOffAge,members.dob) <= @EndYear            
        and DateDiff(Day,Members.dob,@StartYear)/365 < 50             
        order by Members.SchemeNo,Members.memberNo             
     else if @AgeMode = 1 /* Above */            
        declare ExpectCsr cursor for            
        select            
        distinct(Members.MemberNo),Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
        case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
        else            
             'Unknown'            
        end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
        Members.Avc, Members.Avc,            
        Members.PayrollNo,Members.IDNumber            
        from Members            
                    /*inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/            
        where Members.SchemeNo = @schemeCode and Members.ReasonforExit = 0             
        and DateDiff(Day,Members.dob,@StartYear)/365 >= @CutOffAge            
        and DateDiff(Day,Members.dob,@StartYear)/365 < 50            
        order by Members.SchemeNo,Members.memberNo            
            
   END            
ELSE            
   BEGIN            
if @FundType = 'DB'             
  Begin            
     if @AgeMode = 0 /* Between */            
        declare ExpectCsr cursor for            
        select            
        distinct(Members.MemberNo),Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
        case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
        else            
             'Unknown'            
        end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
        Members.Avc, Members.Avc,            
        Members.PayrollNo,Members.IDNumber            
        from Members            
                    /*inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/             
        where Members.SchemeNo = @schemeCode and Members.ReasonforExit = 0             
        and DateAdd(Year,@CutOffAge,members.dob) >= @StartYear            
        and DateAdd(Year,@CutOffAge,members.dob) <= @EndYear            
        order by Members.SchemeNo,Members.memberNo            
     else if @AgeMode = 1 /* Above */            
        declare ExpectCsr cursor for            
    
        select            
        distinct(Members.MemberNo),Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
        case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
        else            
             'Unknown'            
        end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
        Members.Avc, Members.Avc,            
        Members.PayrollNo,Members.IDNumber           
        from Members            
                    /*inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/             
        where Members.SchemeNo = @schemeCode and Members.ReasonforExit = 0             
        and DateDiff(Day,Members.dob,@StartYear)/365 >= @CutOffAge            
        order by Members.SchemeNo,Members.memberNo            
    end            
else            
   begin            
    if @AgeMode = 0 /* Between */            
     BEGIN            
       declare ExpectCsr cursor for            
       select            
       Members.MemberNo,Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
       case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
       else            
             'Unknown'            
       end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/ 
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
       (c.Empcont + c.EmpVolcont) as Employee,            
       (c.Emprcont + c.EmprVolcont)as Employer,Members.PayrollNo,Members.IDNumber            
       from Members            
                    /*inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/            
                   inner join MemberOpeningBalances c on Members.SchemeNo = c.schemeNo             
                         and Members.memberNo = c.memberNo and c.AcctPeriod = @curYear - 1 and c.ProvOrFinal = 1            
       where Members.SchemeNo = @schemeCode and Members.ReasonforExit = 0             
       and DateAdd(Year,@CutOffAge,members.dob) >= @StartYear            
       and DateAdd(Year,@CutOffAge,members.dob) <= @EndYear            
       order by Members.schemeNo,Members.memberNo            
     END            
   else if @AgeMode = 1 /* Above */            
     BEGIN            
      declare ExpectCsr cursor for            
       select            
       Members.MemberNo,Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
       case Members.Sex            
    when 'M' then 'M'            
             when 'F' then 'F'            
       else            
             'Unknown'            
       end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge *365),members.dob),
       (c.Empcont + c.EmpVolcont) as Employee,            
       (c.Emprcont + c.EmprVolcont)as Employer,Members.PayrollNo,Members.IDNumber            
       from Members            
                   /* inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/            
                   inner join MemberOpeningBalances c on Members.SchemeNo = c.schemeNo             
                         and Members.memberNo = c.memberNo and c.AcctPeriod = @curYear - 1 and c.ProvOrFinal = 1           
       where Members.SchemeNo = @schemeCode and Members.ReasonforExit = 0             
       and DateDiff(Day,Members.dob,@StartYear)/365 >= @CutOffAge            
       order by Members.schemeNo,Members.memberNo            
    END            
  end            
END            
            
Open ExpectCsr            
            
fetch from ExpectCsr into @MemberNo,@schemeCode,@dob, @djpens, @avc, @MemberClass, @sex, @fullname, @Retdate, @cEmpBal, @cEmprBal,            
@PayrollNo,@IDNumber            
            
while @@fetch_status = 0            
begin            
            
select @eRate = empContrate, @erRate = emprContrate             
from Contributionrates where SchemeNo = @schemeCode and ClassID = @memberClass            
            
select  @eRate = @eRate + @avc                      
    
select @NumYears = dateDiff(Day,@StartYear,@retDate)/365 
           
select @Age = DateDiff(Day,@dob,@StartYear)/365            
            
exec repMemberCertificateAnnualSalary @schemeCode, @MemberNo,2001, @Salary out            
                  
     if @FundType = 'DB'            
        Begin            
          select @YearsToRet = 0            
          while @YearsToRet < @NumYears            
          begin              
               select @Salary = @Salary + (@Salary * @SalFactor1)            
            
               select @YearsToRet = @YearsToRet + 1            
          end            
            
          select @YearsToRet = 0            
            
          select @CalcYears = cast(datediff(Day, @djpens, @RetDate) as float)/30.00            
             
          if @ActMode = 0            
             begin            
               if @CashOrLumpsum = 0            
                begin            
                  if @AgeMode = 0 /* Expected Retirements at Normal Retirement Age */            
                  Exec [dbo].[Proc_Pension_Project] @schemeCode,@MemberNo,@RetDate,@RetDate,2,@Lumpsum  Out,            
                  @Annual  Out            
                  else if @AgeMode = 1 /* Expected Retirements above a certain age */            
                  Exec [dbo].[Proc_Pension_Project] @schemeCode,@MemberNo,@StartYear,@StartYear,3,@Lumpsum  Out,            
                  @Annual  Out             
            
                  select @Monthly = @Annual / 12.00000000            
                end            
              else            
                begin            
                   Exec [dbo].[Proc_Cash_Project] @schemeCode,@memberNo,@StartYear,@StartYear,6,@Lumpsum Out            
            
                   select @Annual = 0.0,@Monthly = 0.0            
                end            
            end            
         else            
             begin            
                 Select @Gratuity = Gratuity ,@Reduced = Reduced            
                 from PercentageFactors where SchemeNo = @schemeCode            
                 and ServiceYears = @CalcYears/12            
               
                 Select @Annual = @Salary*(@Reduced/@OneHundred)            
              
                 select @Lumpsum = @Salary * (@Gratuity/@OneHundRed)            
            
                 select @Monthly = @Annual / 12.00000000            
             end             
        end            
     else            
        begin 
            select @YearsToRet = 0            
            while @YearsToRet < @NumYears            
            begin            
                   
               select @Salary = @Salary + (@Salary * @SalFactor1)            
            
               select @YearsToRet = @YearsToRet + 1            
            
               select @cEmpBal = (@cEmpBal + ((@Salary * @eRate)/@OneHundRed))*(1 + (@EscalFactor/@OneHundRed))            
               select @cEmprBal = (@cEmprBal + ((@Salary * @erRate)/@OneHundRed))*(1 + (@EscalFactor/@OneHundRed))            
            end            
                        
            select @YearsToRet = 0            
            
            select @Total = @cEmpBal + @cEmprBal            
            
            if @FundCategory ='Provident Fund'            
               select @Lumpsum = @Total            
            else  
               Select @Lumpsum = @Total           
               --Select @Lumpsum = @Total/@lFactor            
            
            if @FundCategory ='Provident Fund'            
               begin            
                 select @Annual = 0,@Monthly = 0            
               end            
            else            
            begin 
                 select @Annual = 0,@Monthly = 0 
                 /*           
                 Select @Annual = (@Total - @Lumpsum)* (114.90/1000.000) --- Confirm Annuity Rates            
            
                 Select @Monthly = @Annual/12.00000000
                 */            
              end            
       end            
            
            
          insert Into #ExpectedRet (SchemeNo,schemeName, MemberNo,PayrollNo,IDNumber, fullname, dob, djpens,Retdate, Age,Sex,Lumpsum, Annual,            
                          Monthly, Salary, yearsToRet, EscalFactor, SalFactor, startYear, EndYear, FundType, Currency,PoolName)            
             values(@schemeCode,@schemeName, @MemberNo,@PayrollNo,@IDNumber, @fullname, @dob, @djpens, @Retdate, @Age, @sex, @Lumpsum, @Annual,            
                    @Monthly, @Salary, @NumYears, @EscalFactor, @SalFactor, @startYear, @endYear, @FundType,@Currency,@PoolName)            
                    
select @NumYears = 0            
Select @Salary =0            
            
select @eRaTE =0            
SELECT @erRate = 0,@PayrollNo = '0',@cEmpBal = 0,@cEmprBal = 0,@Annual = 0,@Monthly = 0,@IDNumber=''            
            
fetch next from ExpectCsr into @MemberNo,@schemeCode, @dob, @djpens, @avc, @MemberClass, @sex, @fullname, @Retdate, @cEmpBal, @cEmprBal,            
@PayrollNo,@IDNumber       
end            
            
close ExpectCsr            
Deallocate ExpectCsr            
          
          
select @schemeCode=0,@schemeName=''            
Fetch next from ExpRetCsr into @schemeCode,@schemeName            
end            
Close ExpRetCsr            
Deallocate ExpRetCsr            
                
END            
ELSE if @FundType <> 'PF'            
BEGIN            
select @schemeName = @PoolName          
select @PoolName = ' '          
          
select @FundType  = FundType, @PenFactor = PensionFactor from scheme where SchemeCode = @SchemeNo            
            
select @Comm = CommRate, @LFactor = LFactor, @MaxLum = MaxLumpPay from Pension_setup             
where SchemeNo = @SchemeNo            
               
select @curYear = Max(AcctPeriod) from schemeYears where SchemeNo = @schemeNo            
            
IF @CashOrLumpsum = 1            
   BEGIN            
       if @AgeMode = 0 /* Between */            
        declare ExpectCsr cursor for            
        select            
        distinct(Members.MemberNo),Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
        case Members.Sex            
     when 'M' then 'M'            
             when 'F' then 'F'            
        else            
             'Unknown'            
        end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
        Members.Avc, Members.Avc,            
        Members.PayrollNo,Members.IDNumber            
        from Members            
                    /*inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/             
        where Members.SchemeNo = @schemeNo and Members.ReasonforExit = 0             
        and DateAdd(Year,@CutOffAge,members.dob) >= @StartYear            
        and DateAdd(Year,@CutOffAge,members.dob) <= @EndYear            
        and DateDiff(Day,Members.dob,@StartYear)/365 < 50             
        order by Members.memberNo             
     else if @AgeMode = 1 /* Above */            
        declare ExpectCsr cursor for            
        select            
        distinct(Members.MemberNo),Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
        case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
        else            
             'Unknown'            
        end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
        Members.Avc, Members.Avc,            
        Members.PayrollNo,Members.IDNumber            
        from Members            
                   /* inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/            
        where Members.SchemeNo = @schemeNo and Members.ReasonforExit = 0             
        and DateDiff(Day,Members.dob,@StartYear)/365 >= @CutOffAge            
        and DateDiff(Day,Members.dob,@StartYear)/365 < 50            
        order by Members.memberNo            
            
   END            
ELSE            
   BEGIN            
if @FundType = 'DB'             
  Begin            
     if @AgeMode = 0 /* Between */            
        declare ExpectCsr cursor for            
        select            
        distinct(Members.MemberNo),Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
        case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
        else            
             'Unknown'            
        end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/ 
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
        Members.Avc, Members.Avc,            
        Members.PayrollNo,Members.IDNumber            
        from Members            
                    /*inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/             
        where Members.SchemeNo = @schemeNo and Members.ReasonforExit = 0             
        and DateAdd(Year,@CutOffAge,members.dob) >= @StartYear            
        and DateAdd(Year,@CutOffAge,members.dob) <= @EndYear            
        order by Members.memberNo            
     else if @AgeMode = 1 /* Above */            
        declare ExpectCsr cursor for            
        select            
        distinct(Members.MemberNo),Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
        case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
        else            
             'Unknown'            
        end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
        Members.Avc, Members.Avc,            
        Members.PayrollNo,Members.IDNumber            
        from Members            
                    /*inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)*/            
        where Members.SchemeNo = @schemeNo and Members.ReasonforExit = 0             
        and DateDiff(Day,Members.dob,@StartYear)/365 >= @CutOffAge            
        order by Members.memberNo            
    end            
else            
   begin            
    if @AgeMode = 0 /* Between */            
      BEGIN            
       declare ExpectCsr cursor for            
       select            
       Members.MemberNo,Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
       case Members.Sex            
             when 'M' then 'M'            
             when 'F' then 'F'            
       else            
             'Unknown'            
       end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
       (c.Empcont + c.EmpVolcont) as Employee,            
       (c.Emprcont + c.EmprVolcont)as Employer,Members.PayrollNo,Members.IDNumber            
       from Members            
                   /* inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo) */           
                   inner join MemberOpeningBalances c on Members.SchemeNo = c.schemeNo             
                         and Members.memberNo = c.memberNo and c.AcctPeriod = @curYear - 1  and c.ProvOrFinal = 1           
       where Members.SchemeNo = @schemeNo and Members.ReasonforExit = 0             
       and DateAdd(Year,@CutOffAge,members.dob) >= @StartYear            
       and DateAdd(Year,@CutOffAge,members.dob) <= @EndYear            
       order by Members.memberNo            
     END            
   else if @AgeMode = 1 /* Above */            
     BEGIN            
      declare ExpectCsr cursor for            
       select            
       Members.MemberNo,Members.schemeNo,Members.DOB,Members.DJPenS, Members.avc, Members.MemberClass,            
       case Members.Sex            
    when 'M' then 'M'            
             when 'F' then 'F'            
       else            
             'Unknown'            
       end as MembSex,/*expectRet.FullName,expectRet.ExpectRet,*/
        Members.sname+', '+members.fname+' '+members.onames,dateAdd(day,(@CutOffAge*365),members.dob),
       (c.Empcont + c.EmpVolcont) as Employee,            
       (c.Emprcont + c.EmprVolcont)as Employer,Members.PayrollNo,Members.IDNumber            
       from Members            
                    inner join expectRet on (expectRet.SchemeNo = Members.SchemeNo) and            
                        (expectRet.MemberNo = Members.MemberNo)            
                   inner join MemberOpeningBalances c on Members.SchemeNo = c.schemeNo             
    
                         and Members.memberNo = c.memberNo and c.AcctPeriod = @curYear - 1  and c.ProvOrFinal = 1           
       where Members.SchemeNo = @schemeNo and Members.ReasonforExit = 0             
       and DateDiff(Day,Members.dob,@StartYear)/365 >= @CutOffAge            
       order by Members.memberNo            
    END            
  end            
END            
            
Open ExpectCsr            
            
fetch from ExpectCsr into @MemberNo,@schemeno,  @dob, @djpens, @avc, @MemberClass, @sex, @fullname, @Retdate, @cEmpBal, @cEmprBal,            
@PayrollNo,@IDNumber            
            
while @@fetch_status = 0            
begin            
            
select @eRate = empContrate, @erRate = emprContrate             
from Contributionrates where SchemeNo = @schemeNo and ClassID = @memberClass            
            
select  @eRate = @eRate + @avc            
            
            
select @Age = DateDiff(Day,@dob,@StartYear)/365            
            
exec repMemberCertificateAnnualSalary @schemeNo, @MemberNo,2001, @Salary out            
            
select @NumYears = dateDiff(Day,@StartYear,@retDate)/365          
            
     if @FundType = 'DB'            
        Begin            
          select @YearsToRet = 0             
          while @YearsToRet < @NumYears            
          begin            
                   
               select @Salary = @Salary + (@Salary * @SalFactor1)            
            
               select @YearsToRet = @YearsToRet + 1            
          end            
            
          select @YearsToRet = 0            
            
          select @CalcYears = cast(datediff(Day, @djpens, @RetDate) as float)/30.00            
             
          if @ActMode = 0            
             begin            
               if @CashOrLumpsum = 0            
                begin            
                  if @AgeMode = 0 /* Expected Retirements at Normal Retirement Age */            
                  Exec [dbo].[Proc_Pension_Project] @SchemeNo,@MemberNo,@RetDate,@RetDate,2,@Lumpsum  Out,            
                  @Annual  Out            
                  else if @AgeMode = 1 /* Expected Retirements above a certain age */            
                  Exec [dbo].[Proc_Pension_Project] @SchemeNo,@MemberNo,@StartYear,@StartYear,3,@Lumpsum  Out,            
                  @Annual  Out             
            
                  select @Monthly = @Annual / 12.00000000            
                end            
              else            
                begin            
                   Exec [dbo].[Proc_Cash_Project] @schemeNo,@memberNo,@StartYear,@StartYear,6,@Lumpsum Out            
            
                   select @Annual = 0.0,@Monthly = 0.0            
                end            
            end            
   else            
             begin            
                 Select @Gratuity = Gratuity ,@Reduced = Reduced            
                 from PercentageFactors where SchemeNo = @schemeNo            
                 and ServiceYears = @CalcYears/12            
               
                 Select @Annual = @Salary*(@Reduced/@OneHundred)            
              
                 select @Lumpsum = @Salary * (@Gratuity/@OneHundRed)            
            
                 select @Monthly = @Annual / 12.00000000            
             end             
        end            
     else            
        begin 
            select @YearsToRet = 0            
            while @YearsToRet < @NumYears            
            begin            
                   
               select @Salary = @Salary + (@Salary * @SalFactor1)            
            
               select @YearsToRet = @YearsToRet + 1            
            
               select @cEmpBal = (@cEmpBal + ((@Salary * @eRate)/@OneHundRed))*(1 + (@EscalFactor/@OneHundRed))            
               select @cEmprBal = (@cEmprBal + ((@Salary * @erRate)/@OneHundRed))*(1 + (@EscalFactor/@OneHundRed))            
            end            
                        
            select @YearsToRet = 0            
            
            select @Total = @cEmpBal + @cEmprBal            
            
            if @FundCategory ='Provident Fund'            
               select @Lumpsum = @Total           
            else
               Select @Lumpsum = @Total              
               --Select @Lumpsum = @Total/@lFactor            
            
            if @FundCategory ='Provident Fund'            
               begin            
                 select @Annual = 0,@Monthly = 0            
               end            
            else            
            begin  
                 select @Annual = 0,@Monthly = 0
                 /*          
                 Select @Annual = (@Total - @Lumpsum)* (114.90/1000.000) --- Confirm Annuity Rates            
            
                 Select @Monthly = @Annual/12.00000000
                 */            
              end            
       end            
            
          delete from #ExpectedRet where SchemeNo = @SCHEMENO and MemberNo = @memberNo
           
          insert Into #ExpectedRet (SchemeNo,schemeName, MemberNo,PayrollNo,IDNumber, fullname, dob, djpens,Retdate, Age,Sex,Lumpsum, Annual,            
                          Monthly, Salary, yearsToRet, EscalFactor, SalFactor, startYear, EndYear, FundType, Currency,PoolName)            
             values(@SchemeNo,@schemeName, @MemberNo,@PayrollNo,@IDNumber, @fullname, @dob, @djpens, @Retdate, @Age, @sex, @Lumpsum, @Annual,            
                    @Monthly, @Salary, @NumYears, @EscalFactor, @SalFactor, @startYear, @endYear, @FundType,@Currency,@PoolName)            
                    
select @NumYears = 0            
Select @Salary =0            
            
select @eRaTE =0            
SELECT @erRate = 0,@PayrollNo = '0',@cEmpBal = 0,@cEmprBal = 0,@Annual = 0,@Monthly = 0,@IDNumber =''          
            
fetch next from ExpectCsr into @MemberNo,@schemeno, @dob, @djpens, @avc, @MemberClass, @sex, @fullname, @Retdate, @cEmpBal, @cEmprBal,            
@PayrollNo,@IDNumber           
end            
            
close ExpectCsr            
Deallocate ExpectCsr          
          
          
END            
select distinct * from #ExpectedRet order by memberNo
go

