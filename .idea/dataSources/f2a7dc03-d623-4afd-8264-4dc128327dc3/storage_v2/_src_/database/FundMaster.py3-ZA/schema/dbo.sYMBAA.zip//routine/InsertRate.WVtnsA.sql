CREATE PROCEDURE [dbo].[InsertRate] 
@schemeNo  varchar(15),
@startMonth int,
@startYear int,
@intrate float
--with Encryption
as

while (@startYear <= datepart(Year, getdate()))
begin
      insert into interestrates_Monthly (schemeNo, intrMonth, IntrYear, interestrate)
      values(@schemeNo, @startMonth, @startYear, @intrate)

     select @startMonth = @startMonth + 1
     select @startYear = @startYear + 1
     select @intrate = @intrate + 0.23

     if @startMonth = 13 
        begin
            select @startMonth = 1
            select @startYear = @startYear + 1
       end


end
go

