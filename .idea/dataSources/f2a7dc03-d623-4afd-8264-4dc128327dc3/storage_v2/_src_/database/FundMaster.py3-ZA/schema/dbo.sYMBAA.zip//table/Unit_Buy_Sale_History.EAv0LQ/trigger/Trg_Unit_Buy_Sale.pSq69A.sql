CREATE TRIGGER [dbo].[Trg_Unit_Buy_Sale] ON [dbo].[Unit_Buy_Sale_History] 
FOR INSERT
AS


declare @SchemeNo Int,@TransNo Int,@UserName varchar(60),@BankAcc varchar(30),
@ChildSchemeNo Int,@TransType Int,@UnitType Int

select @UserName = user

select @schemeNo = SchemeNo,@TransNo = TransNo,@ChildSchemeNo = ChildSchemeNo,
@TransType = TransType,@UnitType = UnitType  from Inserted

if @UnitType = 1 /* Equity */
   begin
         if @TransType = 0
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,25,350,@TransNo,@TransType,@UserName
         else
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,25,351,@TransNo,@TransType,@UserName
   end
else if @UnitType = 2 /* Government Paper */
   begin
         if @TransType = 0
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,26,360,@TransNo,@TransType,@UserName
         else
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,26,361,@TransNo,@TransType,@UserName
   end
else if @UnitType = 3 /* Property */
   begin
         if @TransType = 0
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,27,370,@TransNo,@TransType,@UserName
         else
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,27,371,@TransNo,@TransType,@UserName
   end
else if @UnitType = 4 /* Fixed Term */
   begin
         if @TransType = 0
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,28,380,@TransNo,@TransType,@UserName
         else
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,28,381,@TransNo,@TransType,@UserName
   end
else if @UnitType = 5 /* Commercial Paper */
   begin
         if @TransType = 0
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,29,390,@TransNo,@TransType,@UserName
         else
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,29,391,@TransNo,@TransType,@UserName
   end
else if @UnitType = 6 /* Offshore */
   begin
         if @TransType = 0
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,30,400,@TransNo,@TransType,@UserName
         else
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,30,401,@TransNo,@TransType,@UserName
   end
else if @UnitType = 7 /* Cash and Call Deposits */
   begin
         if @TransType = 0
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,31,410,@TransNo,@TransType,@UserName
         else
             Exec Proc_Auto_Insert_InvPosting @schemeNo ,@ChildSchemeNo,31,411,@TransNo,@TransType,@UserName
   end
go

