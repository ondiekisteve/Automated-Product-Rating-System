CREATE FUNCTION [dbo].[fn_vReceipt](@SCHEMENO Int,@ReceiptNo int,@ReceiptMode Int)                          
returns @tbl_var table(SchemeNo Int not null,                               
                       ReceiptNo BigInt,                          
                       Rec_Date Datetime,                          
                       Remarks Varchar(120),                          
                       Amount float,                          
                       ChequeNo Varchar(20),                          
                       Debtor Varchar(120),                          
                       TotalPaid Decimal(20,6),                
                       PreparedBy varchar(120),              
                       CurrCode varchar(100),            
                       fCurrCode Integer,    
                       EstateName varchar(120),    
                       PayMode Int,    
                       PayDesc varchar(50)                         
                       )                          
as                          
 begin                          
 declare @Amount Decimal(20,6)                          
                          
 if @ReceiptMode = 0                          
    begin                          
     Insert Into @tbl_Var                          
        Select r.SchemeNo,r.RecTransNo,r.TransDate,rci.Particulars,rci.Amount,rc.ChequeNo,                          
               r.ReceivedFrom,0,r.PreparedBy,F.CurrencyDesc,r.CurrCode,' ',0,''                          
        from TBL_Receipts_Register r                          
            inner Join ReceiptsRec rc on r.schemeNo = rc.SchemeNo and r.TransNo_FK = rc.TransNo                               
            inner Join ReceiptsRecInvoice rci on r.schemeNo = rci.SchemeNo and r.TransNo_FK = rci.TransNo_FK                
            inner Join CurrencyType f on r.CurrCode = f.CurrCode                              
        where r.SchemeNo = @schemeNo and r.RecTransNo = @ReceiptNo                          
     end                          
  else if @ReceiptMode = 1                          
     begin                          
        Insert Into @tbl_Var                          
        Select tr.SchemeNo,tr.RecTransNo,tr.TransDate,rc.InvoiceDesc,rc.InvoiceAmount,r.ChequeNo,                          
         r.Payee,0,tr.PreparedBy,F.CurrencyDesc,tr.CurrCode,' ',0,' '                            
        from TBL_Receipts_Register tr                    
            inner Join DirectPayment r on tr.schemeNo = r.SchemeNo and tr.TransNo_FK = r.PaymentNo                          
            inner Join DirectPaymentInvoice rc on tr.schemeNo = rc.SchemeNo and tr.TransNo_FK = rc.PaymentNo               
            inner Join CurrencyType f on tr.CurrCode = f.CurrCode                         
        where r.SchemeNo = @SchemeNo and tr.RecTransNo = @ReceiptNo          
     end            
   else if @ReceiptMode = 2                          
     begin                          
        Insert Into @tbl_Var                          
        Select tr.SchemeNo,r.Receiptno,tr.TransDate,r.Comments,          
        r.Amount + r.ServiceCharge + r.Parking + r.Other + r.Deposit + r.LegalFees + r.Penalty,r.ChequeNo,                          
        r.TenantName,0,r.PreparedBy,F.CurrencyDesc,tr.CurrCode,p.PropertyName,r.PaymentMode,    
        case r.PaymentMode     
             when 1 then 'CASH'    
             When 2 then 'CHEQUE'    
             when 3 then 'BANK TRANFER'    
             when 4 then 'CREDIT CARD'    
        end as PAYDESC                           
        from RentReceipts r                    
            inner Join TBL_Receipts_Register tr on r.schemeNo = tr.SchemeNo and r.RecTransNo = tr.RecTransNo                               
            inner Join CurrencyType f on r.CurrCode = f.CurrCode    
            inner Join Property p on r.schemeNo = p.SchemeNo and r.PropertyCode = p.PropertyCode                          
        where r.SchemeNo = @SchemeNo and r.RecTransNo = @ReceiptNo                     
     end   
   else if @ReceiptMode = 3 /* Contribution Receipts */                          
     begin                          
        Insert Into @tbl_Var                          
        Select r.SchemeNo,r.Receiptno,r.TransDate,r.Particulars,          
        r.Receipt + r.UnReceipt,r.ChequeNo,                          
        r.Payee,0,r.PreparedBy,F.CurrencyDesc,r.CurrCode,r.Payee,r.PaymentType,    
        case r.Paymethod     
             when 0 then 'CHEQUE'    
             When 1 then 'RTGS'    
             when 2 then 'EFT'    
             when 3 then 'CASH'    
        end as PAYDESC                           
        from TBL_FundAdministration r                                            
            inner Join CurrencyType f on r.CurrCode = f.CurrCode               
        where r.SchemeNo = @SchemeNo and r.TransCode = @ReceiptNo    
                  
     end                               
    select @Amount = sum(Amount) from @tbl_Var                          
                          
    update @tbl_Var set TotalPaid = @Amount                          
    update @tbl_Var set ChequeNo = ' ' where PayMode = 1                     
  return                          
 end
go

