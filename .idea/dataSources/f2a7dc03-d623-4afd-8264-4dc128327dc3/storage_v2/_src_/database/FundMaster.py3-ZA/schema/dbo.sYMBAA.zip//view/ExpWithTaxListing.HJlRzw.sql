CREATE VIEW [dbo].[ExpWithTaxListing]
--with Encryption 
as
Select w.*,wt.TaxDesc
from ExpWithholdingTax w
     inner Join WithholdingTypes wt on w.TaxCode = wt.TaxCode
go

