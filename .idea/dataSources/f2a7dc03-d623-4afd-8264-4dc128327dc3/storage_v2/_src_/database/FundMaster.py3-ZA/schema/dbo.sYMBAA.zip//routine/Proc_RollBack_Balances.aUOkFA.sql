CREATE PROCEDURE [dbo].[Proc_RollBack_Balances]        
@SCHEMENO Int,        
@BatchId Int        
--with Encryption        
as        
        
declare @AcctPeriod Int,@EndDate Datetime,@YearClosed smallint        
        
select @AcctPeriod = Max(AcctPeriod) from RegBalances where BatchId = @BatchId        
        
select @EndDate = EndDate from TBL_UpdateBatches where BatchId = @BatchId      
    
select @YearClosed = YearClosed from schemeYears where schemeNo = @SchemeNo and AcctPeriod = @AcctPeriod      
        
/* Back up Balances */        
Exec dbo.Proc_Back_It_Up @schemeNo,@AcctPeriod,@EndDate     
    
Update DBO.schemeYears set YearClosed = 0 where schemeNo = @SchemeNo and AcctPeriod = @AcctPeriod        
         
Delete from MemberOpeningBalances where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod        
      --and memberno in (select memberno from RegBalances where batchId=@batchid)        
Delete from UnRegisteredBalances where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod        
      --and memberno in (select memberno from UnRegBalances where batchId=@batchid)        
        
/* Restore Opening Balances (Registered)*/        
Insert Into MemberOpeningBalances (schemeNo,MemberNo,schemeYear,SchemeMonth,AcctPeriod,        
              EmpCont,EmprCont,EmpVolCont,EmprVolCont,PreEmpCont,PreEmprCont,PreAVC,Transfer,LockedIn,        
              EmpInt,EmprInt,VolInt,SpecInt,EmpFees,EmprFees,VolFees,SpecFees,Deferred,DeferredAmt,  
              DefInterest,ProvOrFinal)        
select schemeNo,MemberNo,schemeYear,SchemeMonth,AcctPeriod,        
              EmpCont,EmprCont,EmpVolCont,EmprVolCont,PreEmpCont,PreEmprCont,PreAVC,Transfer,LockedIn,        
              EmpInt,EmprInt,VolInt,SpecInt,EmpFees,EmprFees,VolFees,SpecFees,Deferred,DeferredAmt,  
              DefInterest,ProvOrFinal from RegBalances         
where BatchId = @BatchId and ProvOrFinal = 1       
        
        
/* Restore Opening Balances (Un Registered)*/        
Insert Into UnRegisteredBalances        
         (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,        
         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,        
         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,VolFees_Un,SpecFees_Un,Deferred,DeferredAmt,DefInterest,        
         DefTax,ProvOrFinal)        
         select schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,        
         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,        
         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,VolFees_Un,SpecFees_Un,Deferred,DeferredAmt,DefInterest,        
         DefTax,ProvOrFinal from UnRegBalances        
         where BatchId = @BatchId  and ProvOrFinal = 1        
        
Update DBO.schemeYears set YearClosed = @YearClosed where schemeNo = @SchemeNo and AcctPeriod = @AcctPeriod
go

