create Procedure dbo.MoveMember2NewScheme
@schemeno int,
@oldSchemeno int,
@memberno int
as

update memberOpeningBalances set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update UnregisteredBalances set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update Benefits set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update UnregisteredBalances set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update PartialPayment set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update TBL_Benefits_DC set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update LumpAuthorization set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno

update Dependants set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno

update ContributionsSummary set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update UnregisteredContributionsSummary set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update ContributionArrears set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update MemberTransfer set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno
update MemberTransferUn set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno

update members set SchemeNo = @schemeno where SchemeNo = @oldschemeno and MemberNo = @memberno

go

