CREATE PROCEDURE [dbo].[PensionCheques_Branch]
@SCHEMENO Int,
@CurMonth int,
@CurYear int
--with Encryption
as

Select sum(p.Net) as NET,B.BankCode,  b.BankName,br.BranchCode, br.BranchName, Br.Address, br.Town, br.Country 
from PensionPayroll p
     inner join bank_Setup b on p.Bank = b.BankCode
     inner join bank_Branch br on p.Branch = br.BranchCode
where p.schemeNo = @SchemeNo and p.PayMonth = @curMonth and p.PayYear = @CurYear
Group by b.BankName,b.BankCode, br.BranchCode, br.BranchName, Br.Address, br.Town, br.Country
go

