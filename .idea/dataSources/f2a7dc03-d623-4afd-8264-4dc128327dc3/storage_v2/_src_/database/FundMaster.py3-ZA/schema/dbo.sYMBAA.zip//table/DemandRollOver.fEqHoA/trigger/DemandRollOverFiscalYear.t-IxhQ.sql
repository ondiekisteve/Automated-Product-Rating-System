CREATE TRIGGER [dbo].[DemandRollOverFiscalYear] ON [dbo].[DemandRollOver]   
--with encryption  
FOR INSERT   
AS  
declare @TransDate datetime,@startDate datetime,@EndDate datetime, @AcctPeriod int,@FiscalYear int,@fiscalQuarter int,@SchemeNo varchar(15),  
@PayMonth int,@PayYear int,@VoucherNo int,@Closed bit,@UserName varchar(60),@DepositNo Int,@IntOrWith int,@DemandOrEquity smallint  
  
Select @TransDate = RollOverDate,@schemeNo = SchemeNo,@VoucherNo = PayCode,@DepositNo = DepositNo,@IntOrWith = IntOrWith,  
       @DemandOrEquity = DemandOrEquity from Inserted  
  
Select @StartDate = StartDate,@EndDate = EndDate,@Closed = PeriodClosed from AccountingPeriods where schemeNo = @schemeNo  
and @TransDate >=  Startdate and @TransDate <= EndDate  
  
if (@EndDate is null)  
  begin  
         raiserror('Error!! Invalid Accounting period - Please define a new Accounting period',16,1)   
         rollback transaction  
 end  
  
if (@Closed = 1)  
  begin  
         raiserror('Error!! You cannot process a transaction in a closed Accounting period',16,1)   
         rollback transaction  
 end  
  
if (@EndDate < @TransDate)  
  begin  
         raiserror('Error!! Invalid Accounting period - Please define a new Accounting period',16,1)   
         rollback transaction  
 end  
  
       Select @AcctPeriod = AcctPeriod,@FiscalYear = FiscalYear,@FiscalQuarter = FiscalQuarter from accountingperiods  
       where schemeNo = @schemeNo and StartDate = @StartDate and EndDate = @EndDate  
  
       update DemandRollOver set AcctPeriod =@AcctPeriod,FiscalYear = @FiscalYear,FiscalQuarter = @FiscalQuarter  
       where schemeNo = @schemeNo and  PayCode = @VoucherNo and RollOverDate = @TransDate  
  
if @DemandOrEquity = 0  
   begin  
   if @IntOrWith = 0 /* Interest */  
      Exec Proc_Auto_Insert_InvPosting @schemeNo ,@DepositNo,8,162,@VoucherNo,0,@UserName  
   else if @IntOrWith = 1 /* Withdrawal */  
      Exec Proc_Auto_Insert_InvPosting @schemeNo ,@DepositNo,8,163,@VoucherNo,2,@UserName  
   else if @IntOrWith = 2 /* Deposits */  
      Exec Proc_Auto_Insert_InvPosting @schemeNo ,@DepositNo,8,164,@VoucherNo,0,@UserName  
   end  
else  
   begin  
      Exec Proc_Auto_Insert_InvPosting @schemeNo ,@DepositNo,2,169,@VoucherNo,0,@UserName  
   end
go

