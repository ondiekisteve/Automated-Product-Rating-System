CREATE PROCEDURE [dbo].[repMembListing]            
@SCHEMENO Int           
--with Encryption            
as            
        
if object_id('tempdb..#repMembListing') is null                                          
                                          
begin                                          
create table #repMembListing                                          
(                                          
 [glcode] [int] IDENTITY(1,1) PRIMARY KEY ,                                          
 [schemeName] [varchar](120) NOT NULL ,                                          
 [MemberNo] [Int],        
 [CheckNo][varchar](15),                                          
 [FullName] [varchar](100),      
 [PayrollNo] [varchar](20),                                          
 [dob][Datetime],        
 [dje][Datetime],         
 [djpens][Datetime],         
 [IDNumber] [varchar](20),         
 [Sex][varchar](6),        
 [AnnSal][decimal](12,2),        
 [SponsorName][varchar](100),        
 [PoolName][varchar](120)                                            
)                                                                         
end        
           
declare @SCHEMEMODE INT,@SponsorName varchar(100),@PooledInvestment smallInt,@schemeName varchar(120),        
@FundType varchar(2),@SchemeCode Int,@PoolName varchar(120)           
               
select @PoolName = schemeName,@SCHEMEMODE = schemeMode,@PooledInvestment = PooledInvestment,@FundType = FundType        
from scheme where schemeCode = @schemeNo            
        
if @SCHEMEMODE is null select @SCHEMEMODE = 0            
        
if @FundType = 'PF'        
BEGIN         
Declare MembListCsr cursor for        
select schemeCode,schemeName,SchemeMode from Scheme        
where PooledInvestment = 1 and InvestmentScheme = @schemeNo        
        
Open MembListCsr        
Fetch from MembListCsr into @schemeCode,@schemeName,@SchemeMode        
while @@fetch_Status = 0        
begin        
if @SCHEMEMODE is null select @SCHEMEMODE = 0          
         
if @SCHEMEMODE = 0            
Insert Into #repMembListing select @schemeName as schemeName,memberNo, CheckNo, upper(sName) + ', ' + fName + ' ' + oNames as fullName,            
 PayrollNo,DOB, DJE, DJPenS, IDNumber, case Sex when 'M' then 'Male' when 'F' then 'Female' end as Sex, CAPenSal as annSal,            
' ' as sponsorName,@PoolName            
from Members 
where (SchemeNo =  @schemeCode)  and ((ReasonForExit = 0)                           
OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 0))                        
OR ((ReasonForExit > 0) AND (ActiveStatus = 7))) and Post_Status = 2           
order by memberNo            
else if @SCHEMEMODE = 1            
Insert Into #repMembListing select @schemeName as schemeName, m.memberNo, m.CheckNo, upper(m.sName) + ', ' + m.fName + ' ' + m.oNames as fullName,            
 m.PayrollNo,m.DOB, m.DJE, m.DJPenS, m.IDNumber, case m.Sex when 'M' then 'Male' when 'F' then 'Female' end as Sex, m.CAPenSal as annSal,            
s.SponsorName,@PoolName            
from Members m             
     Inner join Sponsor s on m.schemeNo = s.schemeNo and m.sponsorCode = s.sponsorCode            
where (m.SchemeNo =  @schemeCode)  and ((m.ReasonForExit = 0)                           
OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 0))                        
OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 7))) and Post_Status = 2                                
order by s.SponsorName,m.memberNo         
        
select @schemeCode=0,@schemeName='',@SchemeMode=0        
Fetch next from MembListCsr into @schemeCode,@schemeName,@SchemeMode        
end        
Close MembListCsr        
Deallocate MembListCsr        
        
END        
ELSE if @FundType <> 'PF'        
BEGIN         
select @schemeName = @PoolName          
if @SCHEMEMODE = 0            
Insert Into #repMembListing select '' as schemeName,memberNo, CheckNo, upper(sName) + ', ' + fName + ' ' + oNames as fullName,            
 PayrollNo,DOB, DJE, DJPenS, IDNumber, case Sex when 'M' then 'Male' when 'F' then 'Female' end as Sex, CAPenSal as annSal,            
' ' as sponsorName,@PoolName            
from Members where (SchemeNo =  @schemeNo)  and ((ReasonForExit = 0)                           
OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 0))                        
OR ((ReasonForExit > 0) AND (ActiveStatus = 7))) and Post_Status = 2           
order by memberNo 
else if @SCHEMEMODE = 1            
Insert Into #repMembListing select '' as schemeName, m.memberNo, m.CheckNo, upper(m.sName) + ', ' + m.fName + ' ' + m.oNames as fullName,            
 m.PayrollNo,m.DOB, m.DJE, m.DJPenS, m.IDNumber, case m.Sex when 'M' then 'Male' when 'F' then 'Female' end as Sex, m.CAPenSal as annSal,            
    
s.SponsorName,@PoolName            
from Members m             
     Inner join Sponsor s on m.schemeNo = s.schemeNo and m.sponsorCode = s.sponsorCode            
where (m.SchemeNo =  @schemeNo)  and ((m.ReasonForExit = 0)                           
OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 0))                        
OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 7))) and Post_Status = 2                                
order by s.SponsorName,m.memberNo            
END        
        
Select * from #repMembListing order by SchemeName,SponsorName,memberNo
go

