CREATE PROCEDURE [dbo].[addServerTrack]  
@serverStation as varchar(15)  
--with Encryption  
as  
insert into serverTrack  
(ServerStation)  
values  
(@serverStation)  
select @@identity as sessionID
go

