CREATE PROCEDURE [dbo].[AssetsDepreciation]            
@SCHEMENO Int,            
@StartDate Datetime,          
@EndDate Datetime            
--with encryption            
as            
            
if object_id('tempdb..#AssetReg') is null            
            
begin            
create table #AssetReg            
(            
        [AssetCode][Int] identity(1,1) Primary Key,            
        [AssetNo] [int] NOT NULL ,            
        [AssetClass] [int] NOT NULL ,            
        [SchemeName] [varchar](120) not  NULL,            
        [AssetName] [varchar](80),            
        [AssetDesc][varchar](80),            
        [AssetCost][float],            
        [AssetDate][Datetime],            
        [CurrValue][float],            
        [Percentage][float],            
        [StartDate][Datetime],          
        [EndDate][Datetime],            
        [BookValue][float],            
        [CummDep][float],            
        [Depreciation][float],    
        [AssetClassName][varchar](50),    
        [DepFactor][float],    
        [DepMethod][varchar](50)                
)                     
end            
            
            
declare @AssetNo int,@AssetClass int,@SchemeName varchar(120),            
        @AssetName Varchar(80),@AssetDesc varchar(80),@AssetCost float,@AssetDate Datetime,            
        @CurrValue float,@Percentage float,@CummDep float,@Depreciation float,            
        @ValueDate datetime,@ClassName varchar(100),@DepFactor float,@DepMethod smallInt,    
        @MethodDesc varchar(100)    
    
select @schemeName = SchemeName from scheme where schemeCode = @schemeNo           
         
declare Acsr cursor for            
Select a.AssetNo,a.AssetClass,a.AssetName,a.AssetDesc,a.AssetCost,a.AssetDate,            
       sum(d.DepValue),t.ClassName,t.DepFactor,t.DepMethod           
from Assets a                   
     inner join Depreciation d on a.schemeNo = d.schemeNo and a.AssetNo = d.PropertyCode            
           and a.AssetClass = d.AssetClass            
           and d.ValueDate >= @startDate and d.ValueDate <= @EndDate     
     inner Join TBL_Asset_Classes t on a.schemeNo = t.schemeNo and a.ClassCode = t.ClassCode           
where a.SchemeNo = @schemeNo    
Group by a.AssetNo,a.AssetClass,a.AssetName,a.AssetDesc,a.AssetCost,a.AssetDate,    
t.ClassName,t.DepFactor,t.DepMethod            
            
open acsr            
            
fetch from acsr into @AssetNo,@AssetClass,@AssetName,@AssetDesc,@AssetCost,@AssetDate,            
                     @Depreciation,@ClassName,@DepFactor,@DepMethod            
            
while @@fetch_Status = 0            
begin    
   select @MethodDesc = DepreciationDesc from DepreciationMethod    
   where DepCode = @DepMethod    
            
   Select @Percentage = 0.0            
            
   select @CummDep = sum(DepValue) from Depreciation            
   where SchemeNo = @SchemeNo and PropertyCode = @AssetNo            
   and AssetClass = @AssetClass and ValueDate < @StartDate         
        
   if @CummDep is null select @CummDep = 0         
        
   SELECT @CurrValue = @AssetCost - @CummDep             
            
   insert into #AssetReg (AssetNo,AssetClass,SchemeName, AssetName,AssetDesc,AssetCost,AssetDate,CurrValue,Percentage,          
                          StartDate,EndDate,            
                          CummDep,BookValue,Depreciation,AssetClassName,DepFactor,DepMethod)            
               Values(@AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate,@CurrValue,          
                      @Percentage,@StartDate,@EndDate,            
                      @CummDep,@AssetCost-(@CummDep + @Depreciation),@Depreciation,@ClassName,@DepFactor,@MethodDesc)              
            
     Select @CurrValue = 0,@CummDep = 0,@Depreciation = 0,@ClassName='',@DepFactor=0,@MethodDesc='',@DepMethod=0            
            
   fetch next from acsr into @AssetNo,@AssetClass,@AssetName,@AssetDesc,@AssetCost,@AssetDate,            
                             @Depreciation,@ClassName,@DepFactor,@DepMethod             
end            
Close Acsr            
Deallocate Acsr            
            
            
Select * from #AssetReg order by AssetClassName,AssetNo
go

