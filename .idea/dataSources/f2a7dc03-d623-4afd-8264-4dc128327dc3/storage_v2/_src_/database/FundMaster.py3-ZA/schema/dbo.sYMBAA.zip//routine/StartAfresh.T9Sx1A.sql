CREATE PROCEDURE [dbo].[StartAfresh]
@SCHEMENO Int,
@userName varchar(30)
--with Encryption
as
Delete from BatchesRun
where SchemeNo = @schemeNo and UserName = user

Delete from MemberBands
where SchemeNo = @schemeNo and UserName = user
go

