CREATE PROCEDURE [dbo].[TransferSchemes]
@schemeName Varchar(100)
as
Insert into PersonalRetSchemes select @schemeName
go

