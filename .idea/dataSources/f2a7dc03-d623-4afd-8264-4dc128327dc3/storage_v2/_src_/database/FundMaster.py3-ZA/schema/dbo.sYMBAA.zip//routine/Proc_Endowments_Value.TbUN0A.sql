CREATE PROCEDURE [dbo].[Proc_Endowments_Value]                                                                                                                               
@schemeNo int,                                                                                                                          
@StartDate Datetime,                                                                                                                                
@AsAtDate Datetime,                                                                                                                                                                                                                        
@RepMode Int, /* 0 - AsAt, 1 - Cutdates */                           
@Ammortise int, /* 0 - No, 1 - Yes */ 
@CarryValue float out                                                                                                                              
--with Encryption                                                                                                                                
as                                                                                                                                
                                                                                                                                
if object_id('tempdb..#tt_Endow_Listing') is null                                                                                                                                    
begin                                                                                                                                    
create table #tt_Endow_Listing                                                                                                                                    
(                                                                                                                                    
 [glcode] [int] IDENTITY(1,1) Primary Key,                                                                                                                                    
 InvName varchar(100) NOT NULL ,                                                                                                                                    
 Insurance varchar(100) not  NULL default 0.0,                                                                                                                                    
 dateBought datetime,                                  
 MaturityDate datetime,                                                                                                                                
 SumAssured float,                                  
 AmountPaid float,                                  
 AnnPremium float,                                  
 Premiums float,                                  
 AccruedBonus float,                                  
 Bonus float,                                  
 EndowValue float,                                  
 Currency varchar(20),                                  
 ExRate float,                                                                                                                               
 CarryingValue float,                          
 AmmortPremium float,                        
 PremDate datetime,                        
 NumDays int,                        
 Premium float                                                                                          
)                                                                                                          
end                                                                                                         
                                  
declare @InvName varchar(100),@OffshoreNo Int,@SumAssured float,@datebought datetime,@AmountPaid float,                                  
@AnnPremium float,@Currency varchar(100),@Insurance varchar(100),@CurrCode int,@Bonus float,@AccrBonus float,                   
@Premiums float,@EndowValue float,@xRate float,@MaturityDate datetime,@CarryingValue float,                                  
@exRate float,@AmmortPremium float,@NumDays int,@Rep_Inv_Class int,@PremDate datetime,@Premium float,                      
@PremiumDueDate datetime,@PremRemain float  
  
if @Ammortise = 0 /* As At Date */                      
declare eCsr cursor for                                  
SELECT c.OffshoreNo, c.SumAssured, c.DateBought,                                                     
    c.AmountPaid, c.AnnPremium,c.MaturityDate,t.InvestName,F.CurrencyCode as CurrCode,                                                                    
    si.Invname,si.Rep_Inv_Class,C.CurrCode,c.PremiumDueDate                                                                     
FROM TBL_Endowments c                                                                          
    inner Join Investments si on c.schemeNo = si.schemeNo and c.OffshoreNo = si.InvCode                                                   
    inner Join TBL_Invest_Names t on c.InsureCode = t.InvestNo and t.InvestCode = 12                                          
    inner Join CurrencyType F on c.CurrCode = F.CurrCode                             
Where c.schemeNo = @schemeNo and c.OffshoreNo not in (select OffshoreNo from TBL_Endowment_Encash                            
where schemeNo = @schemeNo and EncashDate <= @AsAtDate)               
else if @Ammortise = 1 /* Between Cut Dates - Leave out encashments before start Date */                                  
declare eCsr cursor for                                  
SELECT c.OffshoreNo, c.SumAssured, c.DateBought,                                                     
    c.AmountPaid, c.AnnPremium,c.MaturityDate,t.InvestName,F.CurrencyCode as CurrCode,                                                                    
    si.Invname,si.Rep_Inv_Class,C.CurrCode,c.PremiumDueDate                                                                     
FROM TBL_Endowments c                                                                          
    inner Join Investments si on c.schemeNo = si.schemeNo and c.OffshoreNo = si.InvCode                                                   
    inner Join TBL_Invest_Names t on c.InsureCode = t.InvestNo and t.InvestCode = 12                                          
    inner Join CurrencyType F on c.CurrCode = F.CurrCode                             
Where c.schemeNo = @schemeNo and c.OffshoreNo not in (select OffshoreNo from TBL_Endowment_Encash                            
where schemeNo = @schemeNo and EncashDate < @StartDate)                
                          
                                     
open eCsr                                  
fetch from eCsr into @OffshoreNo,@SumAssured,@DateBought,@amountPaid,@AnnPremium,@MaturityDate,@Insurance,@Currency,@InvName,                          
                     @Rep_Inv_Class,@CurrCode,@PremiumDueDate                                  
                                  
while @@fetch_status = 0                                  
begin                          
                          
  /* Ammortised Premiums */                   
  if @Ammortise =  1                  
     begin                  
        select @RepMode = 1                  
     end                  
                   
  Exec Proc_Ammort_Premium @schemeNo,@OffshoreNo,@StartDate,@AsAtDate,@RepMode,@Premium out,@AmmortPremium out,@NumDays out,@PremDate out                          
                  
  if ((@RepMode = 0) and (@MaturityDate < @AsAtDate))        
     select @Premiums = 0        
  else                            
     select @Premiums = sum(Amount/CrossRate) from TBL_Endowment_Prem where SchemeNo = @schemeNo and OffshoreNo = @OffshoreNo                                  
     and BonusOrPremium = 1 and TransDate <= @AsAtDate                                  
                                    
  if @RepMode = 0                                  
select @AccrBonus = sum(Amount/CrossRate),@Bonus = 0 from TBL_Endowment_Prem where SchemeNo = @schemeNo and OffshoreNo = @OffshoreNo                                  
     and BonusOrPremium = 0 and TransDate <= @AsAtDate                                  
  else if @RepMode = 1                                  
     begin                                  
     select @AccrBonus = sum(Amount/CrossRate) from TBL_Endowment_Prem where SchemeNo = @schemeNo and OffshoreNo = @OffshoreNo                   
     and BonusOrPremium = 0 and TransDate < @StartDate                                  
                                  
     select @Bonus = sum(Amount/CrossRate) from TBL_Endowment_Prem where SchemeNo = @schemeNo and OffshoreNo = @OffshoreNo                                  
     and BonusOrPremium = 0 and TransDate >= @StartDate and TransDate <= @AsAtDate                                  
     end                               
                              
     if @Premiums is null select @Premiums = 0                              
     if @AccrBonus is null select @AccrBonus = 0                              
     if @Bonus is null select @Bonus = 0                 
                
     if @Premiums > 0                
        begin                
          select @PremRemain = @Premiums - @AmmortPremium                
                
          if @PremRemain < 0                
             select @PremRemain = 0                
        end                
     else select @PremRemain = 0                
                                  
                                   
     if @CurrCode > 0                               
     begin                                                        
        Exec Proc_Get_Forex_Rate @schemeNo,@CurrCode,@AsAtDate,@exRate out                              
     end                              
     select @xRate = @ExRate                              
                              
     select @EndowValue = @SumAssured + @AccrBonus + @Bonus + @PremRemain                                 
     select @CarryingValue = @EndowValue * @xRate                                                                    
                                                                  
     Insert Into #tt_Endow_Listing (InvName,Insurance,dateBought,MaturityDate,SumAssured,AmountPaid,Premiums,                                   
                                    AccruedBonus,Bonus,EndowValue,Currency,ExRate,CarryingValue,AnnPremium,                        
                                    AmmortPremium,PremDate,NumDays,Premium)                                   
                           Values(@InvName,@Insurance,@DateBought,@MaturityDate,@SumAssured,@amountPaid,@Premiums,                                  
                                  @AccrBonus,@Bonus,@EndowValue,@Currency,@xRate,@CarryingValue,@AnnPremium,                        
                                  @AmmortPremium,@PremiumDueDate,@NumDays,@Premium)                                                                                                                                  
                               
                          
     if ((@Ammortise = 1) and (@AmmortPremium > 0) and (@Premium > 0))                          
        begin                          
           if not exists (select InvCode from TBL_INVEST_RECEIVABLE where schemeNo = @schemeNo and InvCode = @OffshoreNo                          
                          and TransDate = @AsAtDate)                          
              begin                          
                 Insert into TBL_INVEST_RECEIVABLE(SchemeNo,InvCode,TransDate,Income,WithTax,MedLevy,Discount,InvestCode,Status,                                                          
                                    PostedBy,DatePosted,ExRate,Rep_Inv_Class,CapRepayment,                                      
                 IncomePrev,WithholdingPrev,MedicalPrev,AccruedDiscPrev,CapRepaymentPrev,NumDays,DaysToEnd)                                                                 
                            Values(@schemeNo,@OffshoreNo,@AsAtDate,@AmmortPremium,0,0,                                                          
                 0,12,0,'',getdate(),@xRate,@Rep_Inv_Class,0,                                      
                                   @AmmortPremium,0,0,0,0,@NumDays,@NumDays)                          
              end                            
                          
        end                     
     select @OffshoreNo=0,@SumAssured=0,@amountPaid=0,@AnnPremium=0,@Insurance='',@Currency='',@InvName='',@CurrCode = 0,                                  
     @EndowValue = 0,@CarryingValue=0,@xRate=0,@AccrBonus = 0,@Bonus = 0,@Premiums = 0,@AmmortPremium = 0,@Premium = 0                                 
                                  
  fetch next from eCsr into @OffshoreNo,@SumAssured,@DateBought,@amountPaid,@AnnPremium,@MaturityDate,@Insurance,                          
                            @Currency,@InvName,@Rep_Inv_Class,@CurrCode,@PremiumDueDate                                  
end                                  
close eCsr                                  
deallocate eCsr                           
                                                                                                                     
select @CarryValue = sum(CarryingValue) from #tt_Endow_Listing
go

