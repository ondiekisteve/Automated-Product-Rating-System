CREATE PROCEDURE [dbo].[repMemName] 
@SCHEMENO Int
--with Encryption
 AS
select memberno,(UPPER(SName) + ', ' + FName + ' '+ ONames) as FullName
from Members
where schemeno=@schemeNo
order by memberno
go

