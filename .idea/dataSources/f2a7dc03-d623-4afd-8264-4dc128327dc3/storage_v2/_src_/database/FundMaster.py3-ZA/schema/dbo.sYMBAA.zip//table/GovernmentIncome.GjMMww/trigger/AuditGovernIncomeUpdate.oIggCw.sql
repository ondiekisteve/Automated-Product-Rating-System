CREATE TRIGGER [dbo].[AuditGovernIncomeUpdate] on [dbo].[GovernmentIncome]
--WITH ENCRYPTION
for update
as 


declare @SchemeNo varchar(15),@PaperNo int, @PrimaryKey varchar(100),@SqlStr varchar(1000),
        @oPaperDate Datetime, @OInterest decimal(20,2),@oInterestRate decimal(20,2),
        @PaperDate Datetime, @Interest decimal(20,2),@InterestRate decimal(20,2)


select @schemeNo = schemeNo, @PaperNo = SecurityNo, @oPaperDate= SecurityDate,
       @oInterest = Interest, @oInterestRate = InterestRate from deleted

select  @PrimaryKey = @SchemeNo + ' - ' + cast(@PaperNo as varchar(15)) +' - '+cast(@oPaperDate as varchar(15))

select @schemeNo = schemeNo, @PaperNo = SecurityNo, @PaperDate= SecurityDate,
          @Interest = Interest, @InterestRate = InterestRate from Inserted

if @PaperDate <> @OPaperDate
begin
select @SqlStr =('update GovernmentIncome set securityDate = ''' + cast(@OPaperDate as varchar(30)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)) + ' and SecurityDate = ''' + cast(@PaperDate as varchar(30))+ '''')

insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values('Government Paper Income','SecurityDate', @OPaperDate,@PaperDate,@PrimaryKey,getdate(),user,' Transaction Date',@SqlStr)

end


if @Interest <> @OInterest
begin                                                                                                                                                                                                              
select @SqlStr =('update GovernmentIncome set Interest = ''' + cast(@OInterest as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)) + ' and SecurityDate = ''' + cast(@PaperDate as varchar(30))+ '''')

insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values('Government Paper Income','Interest', @OInterest,@Interest,@PrimaryKey,getdate(),user,' Interest',@SqlStr)

end



if @InterestRate <> @OInterestRate
begin
select @SqlStr =('update GovernmentIncome set InterestRate = ''' + cast(@OInterestRate as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)) + ' and SecurityDate = ''' + cast(@PaperDate as varchar(30))+ '''')

insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values('Government Paper Income','InterestRate', @OInterestRate,@InterestRate,@PrimaryKey,getdate(),user,' Interest Rate',@SqlStr)

end
go

