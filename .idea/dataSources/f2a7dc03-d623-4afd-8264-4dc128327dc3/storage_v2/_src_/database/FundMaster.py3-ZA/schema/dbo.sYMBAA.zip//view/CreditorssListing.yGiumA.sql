CREATE VIEW [dbo].[CreditorssListing]
--with Encryption
as
select d.SchemeNo,d.debtorCode as RefNo,d.debtor as FullName,t.debtorDesc as RefType
from CreditorsRegister d
     Inner Join CreditorType t on d.debtorType = t.debtorType
where d.Onekana = 0
go

