CREATE PROCEDURE [dbo].[CourtPayroll]
@SCHEMENO Int,
@PayMonth int,
@PayYear int
--with Encryption
as

declare @MemberNo int, @MonPension Decimal(20,6), @AttachType bit, @AttachPcnt Decimal(20,6),@AttachAmt Decimal(20,6),
            @Deduction Decimal(20,6), @AttachNo int, @NumBen int, @BenAttach Decimal(20,6), @MonthName varchar(25),
            @AttacheeNo int,@PayType int, @BankCode varchar(15), @BranchCode varchar(15), @AcctNo varchar(15)
          , @finCode varchar(15), @finBrCode varchar(15), @finAcctNo varchar(15),@PayPointCode varchar(15),
            @YaConversion Varchar(25),@chapaa Decimal(20,6)

Exec GetMonthName @PayMonth, @MonthName out

select @MonthName = @MonthName +', '+ cast(@PayYear as Varchar(4))

if Exists (select * from AttachmentPayroll where SchemeNo = @schemeNo  and PayMonth = @PayMonth and PayYear = @PayYear)
  begin
        raiserror('The Court Attachments Payroll for %s has already been Generated', 16,1, @MonthName)
        return
  end
else
  begin
declare CourtCsr cursor for
select p.MemberNo, p.MonPension
from Pensioner p
where p.Attached = 1 and Alive = 1 and SchemeNo = @SchemeNo

Open CourtCsr

fetch from CourtCsr into @MemberNo, @MonPension
while @@fetch_Status = 0
begin
   select @attachType = Percentage, @Attachpcnt = AttachPercent, @AttachAmt = AttachAmount,
          @AttachNo = AttachNo
   from CourtAttachments where SchemeNo = @SchemeNo 
   and MemberNo = @MemberNo and Attached = 1 
   and AttachType = 0

   if @AttachType = 0
      select @Deduction = ((@AttachPcnt/100.0000000000)* @MonPension)
   else
      select @Deduction = @AttachAmt
   
   select @NumBen = Count(*) 
   from CourtAttachees 
   where SchemeNo = @SchemeNo and MemberNo = @MemberNo
   and AttachNo = @AttachNo

       declare BenCsr cursor for
       select AttacheeNo,PayType, BankCode, BranchCode, AcctNo, finCode, finBrCode, finAcctNo,
          PayPointCode 
       from CourtAttachees 
       where SchemeNo = @schemeNo and MemberNo = @MemberNo and AttachNo = @AttachNo

       Open BenCsr
       
       fetch from BenCsr into @AttacheeNo,@PayType, @BankCode, @BranchCode, @AcctNo, @finCode, @finBrCode, @finAcctNo,
                              @PayPointCode

       while @@fetch_Status = 0
       begin
            select @BenAttach = (@Deduction / @NumBen)
            
             /* rounding  gross*/
              select @YaConversion = cast(@BenAttach as Varchar(25))
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
              select @BenAttach = @Chapaa
              select @Chapaa = 0
        if @PayType is null select @PayType = 1
    
            insert Into AttachmentPayroll (schemeNo, MemberNo, AttachNo, AttacheeNo, PayMonth, PayYear, PayType, BankCode, BranchCode, AcctNo,
   finCode, finBrCode, finAcctNo, PaypointCode, Attachment,Refund,Paid)
   Values (@SchemeNo, @MemberNo, @AttachNo, @AttacheeNo,@PayMonth, @PayYear, @PayType, @BankCode, @BranchCode, @AcctNo, @finCode, @finBrCode, @finAcctNo,
  @PayPointCode, @BenAttach,0,0)

            select @PayType = 1

            fetch next from BenCsr into @AttacheeNo,@PayType, @BankCode, @BranchCode, @AcctNo, @finCode, @finBrCode, @finAcctNo,
   @PayPointCode
       end
       Close BenCsr
       Deallocate BenCsr
       
      
     
     
      select @Deduction = 0

 fetch next from CourtCsr into @MemberNo, @MonPension
end
Close CourtCsr
Deallocate CourtCsr

end
go

