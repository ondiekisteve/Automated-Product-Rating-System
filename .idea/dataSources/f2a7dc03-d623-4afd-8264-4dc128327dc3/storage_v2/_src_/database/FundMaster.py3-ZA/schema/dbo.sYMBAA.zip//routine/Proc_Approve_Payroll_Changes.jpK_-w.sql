CREATE PROCEDURE [dbo].[Proc_Approve_Payroll_Changes]                  
@schemeNo Int,          
@memberNo Int,          
@DepCode Int,                   
@PayMonth Int,                  
@PayYear Int,          
@RepCode Int,          
@Approve Int,/* 0 - Rollback, 1,2 - Cerifify and Authorize */        
@PayType int                       
as                     
declare @ChangeDate Datetime,@User varchar(50),@dateApp datetime        
        
select @User = user,@dateApp = getdate()                 
                  
Exec GetFirstDate @PayMonth,@PayYear,@ChangeDate Out                  
              
if @RepCode = 0 /* Payroll Changes */          
   Begin  
  
   if @Approve = 0  
      begin        
        Delete from TBL_Payroll_Changes          
        where schemeNo = @schemeNo and MemberNo = @MemberNo and DepCode = @DepCode          
        and ChangeDate = @ChangeDate and ChangeType = @RepCode  
      end  
   else  
      begin  
      update TBL_Payroll_Changes set Approved = @Approve,ApprovedBy = @User,DateApproved = @dateApp          
      where schemeNo = @schemeNo and MemberNo = @MemberNo and DepCode = @DepCode          
      and ChangeDate = @ChangeDate and ChangeType = @RepCode        
       
      if @Approve = 2     
         Exec Proc_Matagaro @schemeNo,@MemberNo,@DepCode,@RepCode,@PayType,@ChangeDate,1   
  
      end       
   end        
else if @RepCode = 1 /* New Entrants */         
   begin         
         
   update TBL_Payroll_Changes set Approved = @Approve,ApprovedBy = @User,DateApproved = @dateApp          
   where schemeNo = @schemeNo and MemberNo = @MemberNo and DepCode = @DepCode          
   and ChangeDate = @ChangeDate and ChangeType = @RepCode    
    
   if @Approve = 2    
      begin    
      update Pensioner set Approved = 1,stopped = 0,Hold = 1          
      where schemeNo = @schemeNo and MemberNo = @MemberNo    
    
      update MemBeneficiary set Approved = 1,stop = 0,Hold = 1          
      where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
    
      update PenBeneficiary set Approved = 1,stop = 0,Hold = 1          
      where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
    
      end    
   else if @Approve = 0 /* Rollback changes */    
      begin    
      update Pensioner set Approved = 0,stopped = 1          
      where schemeNo = @schemeNo and MemberNo = @MemberNo    
    
      update MemBeneficiary set Approved = 0,stop = 1         
      where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
    
      update PenBeneficiary set Approved = 0,stop = 1          
      where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
      end          
   end         
else if @RepCode = 2 /* Suspensions */          
   begin        
    
   update TBL_Payroll_Changes set Approved = @Approve,ApprovedBy = @User,DateApproved = @dateApp          
   where schemeNo = @schemeNo and MemberNo = @MemberNo and DepCode = @DepCode          
   and ChangeDate = @ChangeDate and ChangeType = @RepCode       
    
   if @Approve = 2    
   begin    
       update Pensionstoppage set Approved = 1        
       where schemeNo = @schemeNo and MemberNo = @MemberNo and StoppageDate = @ChangeDate          
          
       update PensionstoppageBen set Approved = 1         
       where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode and StoppageDate = @ChangeDate        
         
       update Pensioner set stopped = 0,Hold = 0          
       where schemeNo = @schemeNo and MemberNo = @MemberNo

       update MemBeneficiary set stop = 0,Hold = 0         
       where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
    
       update PenBeneficiary set stop = 0,Hold = 0          
       where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode      
   end     
   else if @Approve = 0 /* Rollback Changes */    
   begin    
       update Pensionstoppage set Approved = 0         
       where schemeNo = @schemeNo and MemberNo = @MemberNo and StoppageDate = @ChangeDate          
          
       update PensionstoppageBen set Approved = 0          
       where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode and StoppageDate = @ChangeDate        
         
      update Pensioner set Approved = 0,Hold = 1, stopped = 0          
      where schemeNo = @schemeNo and MemberNo = @MemberNo    
    
      update MemBeneficiary set Approved = 0,Hold = 1, stop = 0         
      where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
    
      update PenBeneficiary set Approved = 0,Hold = 1,stop = 0          
      where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
   end     
          
   end          
else if @RepCode = 3 /* Permanent Deletions */          
   begin     
    
   update TBL_Payroll_Changes set Approved = @Approve,ApprovedBy = @User,DateApproved = @dateApp          
   where schemeNo = @schemeNo and MemberNo = @MemberNo and DepCode = @DepCode          
   and ChangeDate = @ChangeDate and ChangeType = @RepCode        
    
   if @Approve = 2    
   begin         
   update Pensioner set Approved = 1,stopped =  1          
   where schemeNo = @schemeNo and MemberNo = @MemberNo          
          
   update PenBeneficiary set Approved = 1,stop = 1          
   where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode          
          
   update MemBeneficiary set Approved = 1,stop = 1         
   where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
   end    
   else if @Approve = 0    
   begin         
   update Pensioner set Approved = 0,stopped =  0,Hold = 1          
   where schemeNo = @schemeNo and MemberNo = @MemberNo          
          
   update PenBeneficiary set Approved = 0,stop = 0,Hold = 1          
   where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode          
          
   update MemBeneficiary set Approved = 0,stop = 0,Hold = 1         
   where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode    
   end         
   end
go

