CREATE PROCEDURE [dbo].[InsertMemberTransfer_New]
@SCHEMENO Int,
@memberNo int,
@EmpTransfer float,
@EmprTransfer float,
@TransferDate datetime,
@Scheme varchar(120)
--with Encryption
as

declare @AcctPeriod int
Select @AcctPeriod = Max(AcctPeriod) from SchemeYears where SchemeNo = @SchemeNo

if (select count(*) from MemberTransfer where SchemeNo = @schemeNo and MemberNo = @MemberNo) > 0
   begin
         raiserror ('A value has already been entered for this Date',16,1)
         return
  end
else
insert into MemberTransfer (schemeNo, MemberNo, EmpTransfer, EmprTransfer, TransferDate, AcctPeriod, Scheme)
           values(@schemeNo, @MemberNo, @EmpTransfer,@EmprTransfer, @TransferDate, @AcctPeriod, @Scheme)
go

