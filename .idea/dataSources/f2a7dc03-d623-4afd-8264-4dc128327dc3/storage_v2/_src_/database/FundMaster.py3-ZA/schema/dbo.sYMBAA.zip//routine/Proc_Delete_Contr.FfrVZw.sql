CREATE PROCEDURE [dbo].[Proc_Delete_Contr]      
@SCHEMENO Int,      
@MemberNo Int,      
@DatePaid Datetime,      
@ContrMonth Int,      
@ContrYear Int,    
@Mode Int      
--with Encryption      
as   
  
declare @TransCode Int     
if @Mode = 0    
begin   
select @TransCode = TransCode from Contributionssummary   
where schemeNo = @schemeNo and MemberNo = @MemberNo and      
ContrMonth = @ContrMonth and ContrYear = @ContrYear and DatePaid = @DatePaid  
  
if @TransCode is null select @TransCode = 0  
  
if @TransCode > 0  
   update TBL_FundAdministration set M_Level_Posted = 0   
   where schemeNo = @schemeNo and TransCode = @TransCode  
   
Delete from Contributionssummary where schemeNo = @schemeNo and MemberNo = @MemberNo and      
ContrMonth = @ContrMonth and ContrYear = @ContrYear and DatePaid = @DatePaid      
--AND BatchId = 0      
      
Delete from UnRegisteredContributionssummary where schemeNo = @schemeNo and MemberNo = @MemberNo and      
ContrMonth = @ContrMonth and ContrYear = @ContrYear and DatePaid = @DatePaid    
end    
else if @Mode = 1 /* Arrears */    
begin 

select @TransCode = TransCode from ContributionArrears   
where schemeNo = @schemeNo and MemberNo = @MemberNo and      
ContrMonth = @ContrMonth and ContrYear = @ContrYear and DatePaid = @DatePaid  
  
if @TransCode is null select @TransCode = 0  
  
if @TransCode > 0  
   update TBL_FundAdministration set M_Level_Posted = 0   
   where schemeNo = @schemeNo and TransCode = @TransCode  

if @TransCode > 0     
   Delete from ContributionArrears where schemeNo = @schemeNo and      
   ContrMonth = @ContrMonth and ContrYear = @ContrYear and DatePaid = @DatePaid and TransCode = @TransCode
else
   Delete from ContributionArrears where schemeNo = @schemeNo and MemberNo = @MemberNo and      
   ContrMonth = @ContrMonth and ContrYear = @ContrYear and DatePaid = @DatePaid      
--AND BatchId = 0      
end  
else if @Mode = 2 /* Transfers */    
begin 

select @TransCode = TransCode from MemberTransfer   
where schemeNo = @schemeNo and MemberNo = @MemberNo and TransferDate = @DatePaid  
  
if @TransCode is null select @TransCode = 0  
  
if @TransCode > 0  
   update TBL_FundAdministration set M_Level_Posted = 0   
   where schemeNo = @schemeNo and TransCode = @TransCode  

if @TransCode > 0     
   Delete from MemberTransfer where schemeNo = @schemeNo      
   and TransferDate = @DatePaid and TransCode = @TransCode
else
   Delete from MemberTransfer where schemeNo = @schemeNo and MemberNo = @MemberNo     
   and TransferDate = @DatePaid      
--AND BatchId = 0      
end    
--AND BatchId = 0
go

