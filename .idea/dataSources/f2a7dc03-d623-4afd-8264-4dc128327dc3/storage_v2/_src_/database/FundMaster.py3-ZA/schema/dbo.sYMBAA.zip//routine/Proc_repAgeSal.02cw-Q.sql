CREATE PROCEDURE [dbo].[Proc_repAgeSal]
@SCHEMENO Int,
@annDate datetime,
@sexOne char(1),
@sexTwo char(1),
@startAge int,
@endAge int,
@ageInterval int
--with Encryption
as
set nocount on

declare @cCount int

if object_id('tempdb..#ageBands') is not null drop table #ageBands

create table #ageBands
(
bandID int identity,
lowerLimit int,
upperLimit int,
ageCaption varchar(9),
primary key (lowerLimit, upperLimit)
)

if @startAge > 0
begin
  insert into #ageBands
  (lowerLimit, upperLimit, ageCaption)
  values
  (0, @startAge - 1, 'Upto ' + cast(@startAge - 1 as varchar(3)))
end

select @cCount = @startAge

while @cCount < @endAge
begin
  insert into #ageBands
  (lowerLimit, upperLimit, ageCaption)
  values
  (@cCount, @cCount + @ageInterval - 1, cast(@cCount as varchar(3)) + ' - ' + cast(@cCount + @ageInterval - 1 as varchar(3)))
  select @cCount = @cCount + @ageInterval
end

select Members.SchemeNo, #ageBands.ageCaption, count(*) as NumMembers, @AnnDate as AnnDate, @sexOne as SexOne, @sexTwo as SexTwo
from #ageBands
left join Members on
dateadd(year, #ageBands.lowerLimit, Members.DOB) <= @annDate and
dateadd(year, #ageBands.upperLimit, Members.DOB) >= @annDate
where
Members.SchemeNo = @SchemeNo and
((Members.Sex = @sexOne) or (Members.Sex = @sexTwo)) and (Members.ReasonForExit = 0)
group by Members.SchemeNo, #ageBands.ageCaption
order by #ageBands.ageCaption

set nocount off
go

