CREATE PROCEDURE [dbo].[RepDeferredStatements] /* RepDeferredStatements 1302,'Dec 31,2012' */                                                        
@SCHEMENO Int,                                                          
@TransDate Datetime                                                                                                                
--with Encryption                                                          
as                                                          
                                                          
--set nocount on                                                          
                                                          
if object_id('tempdb..#MemberCertAffs') is null                                                          
                                                          
begin                                                          
create table #Deferred                                                         
(                                                          
             [CertNo][Int] Identity(1,1) primary Key,                                                                                                          
             [MemberNo] [int] NOT NULL ,     
             [PayrollNo][varchar](20),                                                         
             [Fullname] [varchar](100) NOT NULL ,                                                                                                           
             [AnnualPension][float] null,                                                          
             [ServiceTime] varchar(50),                                                          
             [SchemeName][varchar](100) not null,                                                          
             [RetirementAge][int] not null,                                                          
             [EndingPeriod] [varchar](25) null,                                                          
             [Salary][float] null,                                                          
             [ExpectRet][datetime] null,                                                                                                             
             [dob][Datetime],                                           
             [dje][datetime],                                                  
             [djpens][datetime],                                                          
             [CurrentAge][varchar](50),                                                                                                                                                                     
             [AgeDesc][Varchar](50),                    
             [ServiceToGo][Varchar](50),    
             cashEquivalent float,    
             commLumpsum float,    
             TransDate Varchar(20),    
             sRetAge varchar(3),
             DateDeferred datetime,
             Currency varchar(10)                                                         
)                                          
end                                                          
                                                          
declare @fullname varchar(100),@MemberClass varchar(3),@schemeName varchar(100),@RetAge int,                                                          
        @ServiceTime varchar(50),@Salary float,@ExpectRet datetime,                                                          
        @Dob Datetime,@djpens datetime,@dje datetime,@AgeDesc Varchar(50),@AnnualPension float,                                                        
        @MemberNo Int,@NumYears Int,@NumMonths Int,@NumDays Int,@CashEquivalent float,@doExit datetime,    
        @ServiceToGo Varchar(50),@sTransDate varchar(20),@sRetAge varchar(3),@DateDeferred datetime,@CurrCode int,
        @Currency varchar(10)  
            
        select @SchemeName = schemeName,@CurrCode = CurrCode from scheme where SchemeCode = @schemeNo                                                          
       
        select @Currency = CurrencyCode from CurrencyType where CurrCode = @CurrCode 
                                              
        select @RetAge=55    
        Exec DateToStr @TransDate,@sTransDate out    
        select @sRetAge = CAST(@RetAge as varchar(2))    
            
declare DefCsr Cursor for    
Select m.MemberNo,m.sname+', '+m.fname+' '+m.Onames,m.dob,m.dje,m.djpens,m.doexit,    
       d.SalaryPerCola    
from Members m    
     inner join DeferredPensioner d on m.schemeNo = d.schemeNo and m.MemberNo = d.MemberNo    
where m.schemeNo = @schemeNo    
    
Open defCsr     
fetch from defCsr into @MemberNo,@fullname,@dob,@dje,@djpens,@doExit,@Salary    
while @@FETCH_STATUS = 0    
begin    
   select @ExpectRet = DATEADD(Year,@RetAge,@dob)    
       
   Exec [dbBenef_NRD_Deferred] @schemeno,@memberno,@TransDate,@AnnualPension out,@CashEquivalent Out,@serviceTime out    
       
   Exec GetServiceTime @dob,@TransDate,@NumYears out,@NumMonths Out,@NumDays Out    
       
   select @AgeDesc = CAST(@NumYears as varchar(2))+' Years and '+CAST(@NumMonths as varchar(2))+' Months '  
       
   select @NumYears =0,@NumMonths =0,@NumDays =0     
   Exec GetServiceTime @TransDate,@ExpectRet,@NumYears out,@NumMonths Out,@NumDays Out    
   select @ServiceToGo = CAST(@NumYears as varchar(2))+' Years and '+CAST(@NumMonths as varchar(2))+' Months '    
       
   Insert Into #Deferred(MemberNo,Fullname,AnnualPension,ServiceTime,SchemeName,                                                          
                         RetirementAge,Salary,ExpectRet,dob,dje,djpens,                                                          
                         AgeDesc,ServiceToGo,cashEquivalent,    
                         commLumpsum,TransDate,sRetAge,CurrentAge,DateDeferred,Currency)    
               Values (@MemberNo,@Fullname,@AnnualPension,@ServiceTime,@SchemeName,                                                          
                        @RetAge,@Salary,@ExpectRet,@dob,@dje,@djpens,                                                          
                        @AgeDesc,@ServiceToGo,@cashEquivalent,    
                        @CashEquivalent/2.000,@sTransDate,@sRetAge,@AgeDesc,@doExit,@Currency)         
    
   select @AnnualPension = 0,@CashEquivalent = 0,@serviceTime='',@MemberNo=0,@fullname='',    
          @NumYears =0,@NumMonths =0,@NumDays=0,@Salary=0,@ServiceToGo='',@AgeDesc=''    
   fetch next from defCsr into @MemberNo,@fullname,@dob,@dje,@djpens,@doExit,@Salary    
end    
close defcsr    
deallocate defCsr    
                                                    
                                                          
         
                                                         
select * from #Deferred order by MemberNo
go

