CREATE PROCEDURE [dbo].[Populate]
as
declare @DivisionName varchar(50),
        @CellCount Int,
        @ShelfCount Int,@ShelfCounter Int,@ShelfLetter varchar(2),
        @ShelfId Int,@ShelfName varchar(50)
select @ShelfCounter = 1,@ShelfId = 1

declare Acsr Cursor for
select DivisionName,CellCount,ShelfCount from Divisions
open acsr
fetch from acsr into @DivisionName,@CellCount,@ShelfCount
while @@fetch_status = 0
begin
   while @ShelfCounter <= @ShelfCount
   begin
     if @ShelfCounter = 1 select @ShelfLetter = 'A'
     Else if @ShelfCounter = 2 select @ShelfLetter = 'B'
     Else if @ShelfCounter = 3 select @ShelfLetter = 'C'
     Else if @ShelfCounter = 4 select @ShelfLetter = 'D'
     Else if @ShelfCounter = 5 select @ShelfLetter = 'E'
     Else if @ShelfCounter = 6 select @ShelfLetter = 'F'

     select @ShelfName = @DivisionName+'-'+ @ShelfLetter

     Exec InsertShelf @shelfId,@ShelfName,@CellCount

     select @ShelfCounter = @ShelfCounter + 1,@shelfId = @shelfId + 1
   end
   select @ShelfCounter = 1,@ShelfName = ''
   fetch next from acsr into @DivisionName,@CellCount,@ShelfCount
end
Close Acsr
Deallocate Acsr
go

