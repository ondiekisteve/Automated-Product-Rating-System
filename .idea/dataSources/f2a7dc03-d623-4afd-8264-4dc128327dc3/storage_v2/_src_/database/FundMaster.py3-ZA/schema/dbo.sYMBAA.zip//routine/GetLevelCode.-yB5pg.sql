CREATE PROCEDURE [dbo].[GetLevelCode]
@SCHEMENO Int,
@TopLevel Int,
@LevelNo Int,
@LevelCode varchar(100) Out
as

declare @Length Int,@Counter Int

select @Length = @LevelNo + (@LevelNo + 1)

select @Counter = 3,@LevelCode = '10' + cast(@TopLevel as varchar(1))

while @Counter < @Length
begin
   select @LevelCode = @LevelCode + '10'
   select @Counter = @Counter + 2
end
go

