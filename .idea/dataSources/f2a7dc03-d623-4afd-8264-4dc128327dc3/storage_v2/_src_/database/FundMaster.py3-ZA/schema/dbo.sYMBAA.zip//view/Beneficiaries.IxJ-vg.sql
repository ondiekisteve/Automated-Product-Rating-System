CREATE VIEW [dbo].[Beneficiaries]
--with encryption
AS
SELECT d.schemeNO, d.MemberNo, d.dependantcode, (UPPER(d.SName) 
    + ', ' + d.FName + ' ' + d.OName) AS FullName, d.PcntBenefit, D.PcntGratuity,dt.TypeDesc
FROM dependants d
           inner Join DependantType dt on d.DependantType = dt.Typecode
WHERE d.Alive = 1
go

