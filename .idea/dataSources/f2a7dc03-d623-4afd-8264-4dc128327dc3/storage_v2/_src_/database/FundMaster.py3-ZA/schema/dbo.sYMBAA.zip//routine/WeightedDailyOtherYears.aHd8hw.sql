CREATE PROCEDURE [dbo].[WeightedDailyOtherYears]                  
@schemeno int,                  
@StartDate datetime,                  
@EndDate datetime,                  
@startMonth int,                  
@EndMonth int,                  
@BalanceofInt smallInt,                  
@StartYear int,                  
@EndYear int,                  
@AcctPeriod int                  
                  
as                  
declare @MemberNo int,@DatePaid datetime ,@EmpCont float,@EmprCont float,@VolContr float,                  
      @SpecialContr float,@DoCalc datetime ,@Reason int,                  
 @OpEmpCont float,                  
 @OpEmprCont float,                  
 @OpVolContr float,                  
 @OpSpecialContr float,                  
        @PreEmpCont float,                  
 @PreEmprCont float,                  
 @PreVolContr float,                  
        @NumYears Int,@NumMonths Int,@NumDays Int,@TransferValueS float,                  
        @EmpArrears float,@EmprArrears float,@TransferValue float /* Added on 19/5/2006 */,                  
        @ActiveStatus smallInt,@Weight float,@YaKwanza Int                  
                  
select @YaKwanza = @StartMonth                  
                  
WHILE @StartMonth <= 12                 
BEGIN                          
    Declare Acsr Cursor for                  
    select c.MemberNo,c.DatePaid,c.EmpCont,c.EmprCont,c.VolContr,c.SpecialContr,                  
    m.DoCalc,m.ReasonforExit                  
    from Contributionssummary c                  
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                   
        ((m.ReasonForExit = 0)                  
        or                  
        (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))                  
        And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))                  
    where c.SchemeNo = @schemeNo and DatePart(Month,c.DatePaid) = @StartMonth     
    and DatePart(Year,c.DatePaid) = @StartYear                  
    and c.AcctPeriod = @AcctPeriod                  
                 
    open acsr                  
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                  
    while @@fetch_Status = 0                  
    begin                  
        if @EmpCont is null select @EmpCont = 0                  
        if @EmprCont is null select @EmprCont = 0                  
        if @VolContr is null select @VolContr = 0                  
        if @SpecialContr is null select @SpecialContr = 0                  
                  
        select @Weight = 0.0                  
                  
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                  
                  
        if @TransferValue is null select @TransferValue = 0                  
        if @TransferValueS is null select @TransferValueS = 0                  
                         
        if @EmpArrears is null select @EmpArrears = 0                  
        if @EmprArrears is null select @EmprArrears = 0                  
                  
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                  
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                  
            Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                  
         (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValues + @EmprArrears)* @Weight,                  
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                  
                  
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0 ,                 
 @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                   
                  
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                  
    end                  
    Close Acsr                  
    Deallocate Acsr    
                
       /* Transfer Values */                             
       Declare Acsr Cursor for                      
       select c.MemberNo,c.TransferDate,c.EmpTransfer,c.EmprTransfer+ c.DeferredAmt,c.AVCTransfer,c.avcerTransfer,                      
       m.DoCalc,m.ReasonforExit                      
       from MemberTransfer c                       
          inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                       
         ((m.ReasonForExit = 0)                      
         or                      
         (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))                      
         And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))                      
       where c.SchemeNo = @schemeNo and DatePart(Month,c.TransferDate) = @StartMonth                     
       and DatePart(Year,c.TransferDate) = @StartYear                      
       and c.AcctPeriod = @AcctPeriod                    
                     
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                     
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,(@EmpCont + @TransferValue + @EmpArrears) * @Weight,
              (@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                   
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                     
    /* End Transfer Values */                    
                     
 /* Arrears */                    
                     
    Declare Acsr Cursor for                      
    select c.MemberNo,c.DatePaid,c.ArEmpCont,c.ArEmprCont,c.ArVolContr,c.ArSpecial,                      
    m.DoCalc,m.ReasonforExit                      
    from ContributionArrears c                      
    inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                       
         ((m.ReasonForExit = 0)                      
         or                      
         (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))                      
         And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))                      
    where c.SchemeNo = @schemeNo and DatePart(Month,c.DatePaid) = @StartMonth     
    and DatePart(Year,c.DatePaid) = @StartYear                      
    and c.AcctPeriod = @AcctPeriod                     
                      
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
          
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                      
    /* End Arrears */                   
    select @StartMonth = @StartMonth + 1                  
end                  
                  
/* Contributions in the following Year */                  
select @StartMonth = 1                
while @StartMonth <= @EndMonth                  
begin                               
    Declare Acsr Cursor for                  
    select c.MemberNo,c.DatePaid,c.EmpCont,c.EmprCont,c.VolContr,c.SpecialContr,                  
    m.DoCalc,m.ReasonforExit                  
    from Contributionssummary c                  
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                   
        ((m.ReasonForExit = 0)                  
        or                  
        (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))                  
        And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))                  
    where c.SchemeNo = @schemeNo and datepart(Month,c.Datepaid) = @StartMonth and datepart(Year,c.Datepaid) = @EndYear                  
    and c.AcctPeriod = @AcctPeriod                  
                
    open acsr                  
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                  
    while @@fetch_Status = 0                  
    begin                   
        if @EmpCont is null select @EmpCont = 0                  
        if @EmprCont is null select @EmprCont = 0                  
        if @VolContr is null select @VolContr = 0                  
        if @SpecialContr is null select @SpecialContr = 0                  
                  
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                  
                           
        if @TransferValue is null select @TransferValue = 0                  
        if @TransferValueS is null select @TransferValueS = 0                  
                         
        if @EmpArrears is null select @EmpArrears = 0                  
        if @EmprArrears is null select @EmprArrears = 0                  
                  
                  
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                  
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                  
        Values(@SchemeNo,@MemberNo,@EndYear,@StartMonth,@DatePaid,                  
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValues + @EmprArrears)* @Weight,                  
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                            
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                  
    @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                      
                  
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                  
    end                   
    Close Acsr                  
    Deallocate Acsr
                  
/* Transfer Values */                    
                     
       Declare Acsr Cursor for                      
       select c.MemberNo,c.TransferDate,c.EmpTransfer,c.EmprTransfer+ c.DeferredAmt,c.AVCTransfer,c.avcerTransfer,                      
       m.DoCalc,m.ReasonforExit                      
       from MemberTransfer c                       
          inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                       
         ((m.ReasonForExit = 0)                      
         or                     
         (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))                      
         And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))                      
       where c.SchemeNo = @schemeNo and DatePart(Month,c.TransferDate) = @StartMonth                     
       and DatePart(Year,c.TransferDate) = @EndYear                      
       and c.AcctPeriod = @AcctPeriod                    
                     
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin               
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                     
    /* End Transfer Values */                    
                     
 /* Arrears */                    
                      
     Declare Acsr Cursor for                      
     select c.MemberNo,c.DatePaid,c.ArEmpCont,c.ArEmprCont,c.ArVolContr,c.ArSpecial,                      
      m.DoCalc,m.ReasonforExit                      
       from ContributionArrears c                      
          inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                       
         ((m.ReasonForExit = 0)                      
         or                      
         (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))                      
         And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))                      
       where c.SchemeNo = @schemeNo and DatePart(Month,c.DatePaid) = @StartMonth and DatePart(Year,c.DatePaid) = @EndYear                      
      and c.AcctPeriod = @AcctPeriod                     
                     
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,    
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                      
    /* End Arrears */                 
    select @StartMonth = @StartMonth + 1                  
                  
END --WHILE                  
                  
/* Re-Initialize Start Month */                  
                  
/* Deferred Cases  after Year end */         
                 
select @StartMonth = @YaKwanza                  
                  
while @StartMonth <= 12                    
    begin                    
    Declare Acsr Cursor for                    
    select c.MemberNo,c.DatePaid,c.EmpCont,c.EmprCont,c.VolContr,c.SpecialContr,                    
    m.DoCalc,m.ReasonforExit                    
    from Contributionssummary c                    
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                       
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                      
         and (M.ActiveStatus = 6)                        
    where c.SchemeNo = @schemeNo and datepart(month,c.datepaid) = @StartMonth     
    and datepart(Year,c.datepaid) = @StartYear                    
    and c.AcctPeriod = @AcctPeriod                    
                        
    open acsr                    
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                    
    while @@fetch_Status = 0                    
    begin                    
                  
        if @EmpCont is null select @EmpCont = 0                    
        if @EmprCont is null select @EmprCont = 0                    
        if @VolContr is null select @VolContr = 0                    
        if @SpecialContr is null select @SpecialContr = 0                    
                    
        select @Weight = 0.0                    
                    
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                    
                    
        /* Add Transfer Values and Contribution Arrears paid on the same date */                    
        /* 19/5/2006*/                    
        select @TransferValue = EmpTransfer,@TransferValueS = EmprTransfer + DeferredAmt                     
        from MemberTransfer where schemeNo = @schemeNo and MemberNo = @MemberNo                    
        and TransferDate = @DatePaid                    
                    
        select @EmpArrears = sum(ArEmpCont),@EmprArrears = sum(ArEmprCont)  from ContributionArrears                     
        where schemeNo = @schemeNo and MemberNo = @MemberNo                    
        and DatePaID = @DatePaid                    
                    
        if @TransferValue is null select @TransferValue = 0                    
        if @TransferValueS is null select @TransferValueS = 0                    
                           
        if @EmpArrears is null select @EmpArrears = 0                    
        if @EmprArrears is null select @EmprArrears = 0                    
                    
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                    
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                    
            Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                    
         (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValues + @EmprArrears)* @Weight,                     
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                    
                    
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0 ,                    
    @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                     
                    
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                    
    end                    
    Close Acsr                    
    Deallocate Acsr                 
   /* Transfer Values */                    
    Declare Acsr Cursor for                      
      select c.MemberNo,c.TransferDate,c.EmpTransfer,c.EmprTransfer + c.DeferredAmt,c.AVCTransfer,c.avcerTransfer,                      
       m.DoCalc,m.ReasonforExit                      
      from MemberTransfer c                      
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                 
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                      
         and (M.ActiveStatus = 6)                   
      where c.SchemeNo = @schemeNo and DatePart(Month,c.TransferDate) = @StartMonth 
      and DatePart(Year,c.TransferDate) = @StartYear                      
      and c.AcctPeriod = @AcctPeriod                               
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                     
    /* End Transfer Values */                    
                     
 /* Arrears */                       
    Declare Acsr Cursor for                         
      select c.MemberNo,c.DatePaid,c.ArEmpCont,c.ArEmprCont,c.ArVolContr,c.ArSpecial,                      
       m.DoCalc,m.ReasonforExit                      
      from ContributionArrears c                      
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                       
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                      
         and (M.ActiveStatus = 6)                   
      where c.SchemeNo = @schemeNo and DatePart(Month,c.DatePaid) = @StartMonth 
      and DatePart(Year,c.DatePaid) = @StartYear                      
      and c.AcctPeriod = @AcctPeriod                   
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
  select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                      
    /* End Arrears */                     
                    
    select @StartMonth = @StartMonth + 1                    
    end                    
                    
    /* Contributions in the following Year */                    
                    
    select @StartMonth = 1                    
                    
    while @StartMonth < = @EndMonth                    
    begin                    
                       
    Declare Acsr Cursor for                    
    select c.MemberNo,c.DatePaid,c.EmpCont,c.EmprCont,c.VolContr,c.SpecialContr,                    
 m.DoCalc,m.ReasonforExit                    
    from Contributionssummary c                    
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                       
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                      
         and (M.ActiveStatus = 6)                     
    where c.SchemeNo = @schemeNo and datepart(month,c.datepaid) = @StartMonth and datepart(year,c.datepaid) = @EndYear                    
    and c.AcctPeriod = @AcctPeriod                    
                        
    open acsr                    
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                    
    while @@fetch_Status = 0                    
    begin                    
        if @EmpCont is null select @EmpCont = 0                    
        if @EmprCont is null select @EmprCont = 0                    
        if @VolContr is null select @VolContr = 0                    
if @SpecialContr is null select @SpecialContr = 0                    
                    
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                    
                    
        /* Add Transfer Values and Contribution Arrears paid on the same date */                    
                           
                    
        if @TransferValue is null select @TransferValue = 0                    
        if @TransferValueS is null select @TransferValueS = 0                    
                           
        if @EmpArrears is null select @EmpArrears = 0                    
        if @EmprArrears is null select @EmprArrears = 0                    
                    
                    
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                    
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                    
        Values(@SchemeNo,@MemberNo,@EndYear,@StartMonth,@DatePaid,                    
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValues + @EmprArrears)* @Weight,                    
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                    
                    
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                    
    @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                        
                    
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                    
    end                    
    Close Acsr                    
    Deallocate Acsr                 
/* Transfer Values */                    
    Declare Acsr Cursor for                      
      select c.MemberNo,c.TransferDate,c.EmpTransfer,c.EmprTransfer + c.DeferredAmt,c.AVCTransfer,c.avcerTransfer,                      
       m.DoCalc,m.ReasonforExit                      
      from MemberTransfer c                      
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                       
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                      
         and (M.ActiveStatus = 6)                               
      where c.SchemeNo = @schemeNo and DatePart(Month,c.TransferDate) = @StartMonth 
      and DatePart(Year,c.TransferDate) = @EndYear                      
      and c.AcctPeriod = @AcctPeriod                               
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                   
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                     
    /* End Transfer Values */                    
                     
 /* Arrears */                       
    Declare Acsr Cursor for                         
      select c.MemberNo,c.DatePaid,c.ArEmpCont,c.ArEmprCont,c.ArVolContr,c.ArSpecial,                      
       m.DoCalc,m.ReasonforExit                      
      from ContributionArrears c                      
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                       
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                      
         and (M.ActiveStatus = 6)                     
      where c.SchemeNo = @schemeNo and DatePart(Month,c.DatePaid) = @StartMonth 
      and DatePart(Year,c.DatePaid) = @EndYear                      
      and c.AcctPeriod = @AcctPeriod                   
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0            
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                      
    /* End Arrears */                     
                    
    select @StartMonth = @StartMonth + 1                    
    end                    
                  
/* Re-Initialize Start Month */                  
                  
/* Deferred Cases  within the Year */                  
                  
select @StartMonth = @YaKwanza                  
                  
while @StartMonth < = 12                    
 begin                    
                   
    Declare Acsr Cursor for                    
    select c.MemberNo,c.DatePaid,0.0,c.EmprCont,0.0,c.SpecialContr,                    
    m.DoCalc,m.ReasonforExit                    
    from Contributionssummary c                    
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((M.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))         
    where c.SchemeNo = @schemeNo and datepart(month,c.datepaid) = @StartMonth and datepart(Year,c.datepaid) = @StartYear                    
    and c.AcctPeriod = @AcctPeriod                    
                       
                    
    open acsr                    
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                    
    while @@fetch_Status = 0                    
    begin                    
       if @EmpCont is null select @EmpCont = 0                    
        if @EmprCont is null select @EmprCont = 0                    
        if @VolContr is null select @VolContr = 0                    
        if @SpecialContr is null select @SpecialContr = 0                    
                    
        select @Weight = 0.0,@EmpCont = 0,@VolContr = 0                    
                    
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                    
                    
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                    
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)                    
            Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                    
         @EmpCont * @Weight,@EmprCont * @Weight,                    
         @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)                    
                    
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0                     
                    
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                    
    end                    
    Close Acsr                    
    Deallocate Acsr                    
    select @StartMonth = @StartMonth + 1                    
    end                    
    /* Transfer Values */                    
                      
       Declare Acsr Cursor for                      
       select c.MemberNo,c.TransferDate,0.0,c.EmprTransfer+ c.DeferredAmt,0.0,c.avcerTransfer,                      
       m.DoCalc,m.ReasonforExit                      
       from MemberTransfer c                         
            inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
            (m.ReasonForExit > 0) AND                    
            (((M.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
          OR  
            ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))      
       where c.SchemeNo = @schemeNo and DatePart(Month,c.TransferDate) = @StartMonth                     
       and DatePart(Year,c.TransferDate) = @StartYear                      
       and c.AcctPeriod = @AcctPeriod                    
                      
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0,@EmpCont = 0,@VolContr = 0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                   
    Deallocate Acsr                     
    /* End Transfer Values */                    
                     
 /* Arrears */                    
                     
    Declare Acsr Cursor for                      
    select c.MemberNo,c.DatePaid,0.0,c.ArEmprCont,0.0,c.ArSpecial,                      
    m.DoCalc,m.ReasonforExit                      
       from ContributionArrears c                      
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((M.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))        
       where c.SchemeNo = @schemeNo and DatePart(Month,c.DatePaid) = @StartMonth and DatePart(Year,c.DatePaid) = @StartYear                      
      and c.AcctPeriod = @AcctPeriod                     
                     
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0,@EmpCont = 0,@VolContr = 0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr              
    Deallocate Acsr                      
    /* End Arrears */                
    /* Contributions in the following Year */                    
                    
   select @StartMonth = 1                    
                    
    while @StartMonth < = @EndMonth                    
    begin                    
                   
    Declare Acsr Cursor for                    
    select c.MemberNo,c.DatePaid,0.0,c.EmprCont,0.0,c.SpecialContr,                    
    m.DoCalc,m.ReasonforExit                    
    from Contributionssummary c                    
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((M.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) 
        and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))        
    where c.SchemeNo = @schemeNo and datepart(month,c.datepaid) = @StartMonth and datepart(Year,c.datepaid) = @EndYear                    
    and c.AcctPeriod = @AcctPeriod                    
                      
                    
    open acsr                    
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                    
    while @@fetch_Status = 0                    
    begin                    
        if @EmpCont is null select @EmpCont = 0                    
        if @EmprCont is null select @EmprCont = 0                    
        if @VolContr is null select @VolContr = 0                    
        if @SpecialContr is null select @SpecialContr = 0,@Weight = 0,@EmpCont = 0,@VolContr = 0                    
                    
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                    
                    
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                    
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                    
        Values(@SchemeNo,@MemberNo,@EndYear,@StartMonth,@DatePaid,                    
        @EmpCont * @Weight,@EmprCont * @Weight,                    
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                    
                    
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0                       
                    
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                    
    end                    
    Close Acsr                    
    Deallocate Acsr                  
    /* Transfer Values */                    
                      
       Declare Acsr Cursor for                      
       select c.MemberNo,c.TransferDate,0.0,c.EmprTransfer+ c.DeferredAmt,0.0,c.avcerTransfer,                      
       m.DoCalc,m.ReasonforExit                      
       from MemberTransfer c                         
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((M.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))     
       where c.SchemeNo = @schemeNo and DatePart(Month,c.TransferDate) = @StartMonth                     
       and DatePart(Year,c.TransferDate) = @EndYear                      
       and c.AcctPeriod = @AcctPeriod                    
                        
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0,@EmpCont = 0,@VolContr = 0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                           
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                     
    /* End Transfer Values */                    
                 
 /* Arrears */                    
                     
         Declare Acsr Cursor for                      
       select c.MemberNo,c.DatePaid,0.0,c.ArEmprCont,0.0,c.ArSpecial,                      
      m.DoCalc,m.ReasonforExit                      
       from ContributionArrears c                      
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((M.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))    
       where c.SchemeNo = @schemeNo and DatePart(Month,c.DatePaid) = @StartMonth 
       and DatePart(Year,c.DatePaid) = @EndYear and c.AcctPeriod = @AcctPeriod                     
                     
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
    if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0,@EmpCont = 0,@VolContr = 0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        if @TransferValue is null select @TransferValue = 0                      
        if @TransferValueS is null select @TransferValueS = 0                      
                             
        if @EmpArrears is null select @EmpArrears = 0                      
        if @EmprArrears is null select @EmprArrears = 0                      
                      
        Insert Into ##ContSummaryWeighted (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod,PreEmpCont,PreEmprCont,PreVolContr)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                
        (@EmpCont + @TransferValue + @EmpArrears) * @Weight,(@EmprCont + @TransferValueS + @EmprArrears) * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod,0,0,0)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0,                      
        @TransferValue = 0,@EmpArrears=0,@TransferValueS=0, @EmprArrears=0                       
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end -- for Acsr                      
    Close Acsr                      
    Deallocate Acsr                      
    /* End Arrears */                  
    select @StartMonth = @StartMonth + 1                    
end
go

