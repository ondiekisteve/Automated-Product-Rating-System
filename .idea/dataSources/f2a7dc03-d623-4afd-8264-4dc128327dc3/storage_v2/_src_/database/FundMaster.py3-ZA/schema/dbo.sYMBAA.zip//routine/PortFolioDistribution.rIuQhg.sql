CREATE PROCEDURE [dbo].[PortFolioDistribution]                                 
@SCHEMENO Int,                          
@RepMode int,                              
@AsAt Datetime                                  
--with Encryption                                    
as                                    
                                    
if object_id('tempdb..#Portfolio') is null                                    
                                    
begin                                    
create table #PortFolio                                    
(                                    
                                     
        [SchemeName][varchar](120) null,                                    
        [Investment] [varchar](100) NOT NULL ,                                    
        [amount] [float] not  NULL default 0.0,                                    
        [Percentage] [Float] null default 0.0,                                    
        [MaxPcntofAsset][float] null default 0.0,                                    
        [Total][Float]null default 0.0,                                    
        [Currency][varchar](30),                              
        [AsAtDate][datetime],                              
        [TargetAlloc][float],                    
        MinAllocation float,                    
        MaxAllocation float,        
        VarAllocation float,      
        TargetValue float,      
        ValueVariance float                                                 
)                                     
                                    
ALTER TABLE #PortFolio WITH NOCHECK ADD                                      
                                                
 CONSTRAINT [PK_PortFolio] PRIMARY KEY  NONCLUSTERED                                     
 (                                    
   [Investment]                                          
 )                                     
end                                    
                                    
declare @InvestCode Int,@Investment varchar(50),@Percentage float,@Total FLOAT,@Amount FLOAT,                                    
@MaxPcnt float,@SchemeName varchar(120),@Curr varchar(15),@Currency varchar(30),@TargetAlloc float,                    
@MinAllocation float,@MaxAllocation float,@TargetValue float,@ValueVariance float,@TotalTarget float,@CorpBonds float,  
@Napsa float                                   
                                    
Select @Total = 0,@TotalTarget = 0                                    
                                    
Select @SchemeName = schemeName,@Curr = Currency,@Napsa = Napsa from scheme where schemeCode = @schemeNo                                    
                                    
Select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @Curr   
  
if @Napsa is null select @Napsa = 0                                   
                                    
Declare XCsr Cursor for                                    
Select Distinct(InvestCode) from                                    
InvestMents where SchemeNo = @SchemeNo                                    
and InvStatus = 0                                    
                                    
Open XCsr                                    
                                    
fetch from XCsr into @InvestCode                                    
                                    
while @@fetch_Status = 0                                    
begin                                    
     select @Investment = InvestDesc,@MaxPcnt = MaxPcntofAsset                                     
     from InvestmentTypes where InvestCode = @InvestCode     
         
    -- select @Investment = Rep_Inv_Class_Desc from fn_Rep_Inv_Class() where Rep_Inv_Class = @InvestCode                              
                              
     select @TargetAlloc = TargetAlloc,@MinAllocation = MinAllocation                    
    ,@MaxAllocation = MaxAllocation from TBL_Invest_TaxRates          
     where InvestCode = @InvestCode and schemeNo = @SchemeNo                              
                              
     if @TargetAlloc is null select @TargetAlloc = 0                     
     if @MinAllocation is null select @MinAllocation = 0                    
     if @MaxAllocation is null select @MaxAllocation = 0                                  
                                   
     if @InvestCode = 1 /* Property*/                              
        Exec Proc_Property_Value @SCHEMENO,@AsAt,@Amount Out                                                                                                               
     else if @InvestCode = 2 /* Equities*/                              
        Exec Proc_Equity_Value @SCHEMENO,@AsAt,@AsAt,0,@Amount Out                                                                
     else if @InvestCode = 4 /* Government Paper and Corporate Bonds */     
        begin    
        if @Napsa = 0  
           begin                           
    Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,0,0,@Amount Out    
    Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,1,0,@CorpBonds Out    
    select @Amount = @Amount + @CorpBonds    
              
    select @CorpBonds = 0   
           end   
        else if @Napsa = 1  
           begin                           
    Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,0,0,@Amount Out    
    select @CorpBonds = 0   
    select @Amount = @Amount + @CorpBonds    
           end   
        end                              
     else if @InvestCode = 5 /* Fixed Term Deposits */                    
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,2,0,@Amount Out    
     else if @InvestCode = 7 /* Corporate Bonds */   
        begin   
        if @Napsa = 0   
            select @Amount = 0  
        else if @Napsa = 1                 
            Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,1,0,@Amount Out   
        end                                                                      
     else if @InvestCode = 8 /* Call Deposits */                              
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,3,0,@Amount Out    
     else if @InvestCode = 10 /* Offshore Fixed Interest*/    
        Exec Proc_Endowments_Value @schemeNo,@AsAt,@AsAt,0,0,@Amount Out                                                                                                                                                                  
     else if @InvestCode = 11 /* Offshore Investments */                            
        Exec Rep_OffshoreValue @SCHEMENO,0,@AsAt,@Amount out                              
                                        
     if @Amount is null select @Amount = 0                                    
                                    
     Select @Total = @Total + @Amount                                    
                                    
     Insert Into #PortFolio (Investment,Amount, MaxPcntofAsset,currency,AsAtDate,TargetAlloc,                    
                             MinAllocation,MaxAllocation)                                    
                  Values(@Investment,@Amount,@MaxPcnt,@Currency,@AsAt,@TargetAlloc,                    
                         @MinAllocation,@MaxAllocation)                                    
                                    
     Select @Amount = 0,@TargetAlloc = 0,@MinAllocation=0,@MaxAllocation=0                                    
                                    
   fetch next from XCsr into @InvestCode                                    
end                                    
Close XCsr                                    
Deallocate XCsr                    
                  
/* Missing Investment classes */                  
if @Napsa = 0  
begin                  
Declare XCsr Cursor for                                    
Select InvestCode from InvestmentTypes                                    
where InvestCode not in (select distinct InvestCode from Investments where SchemeNo = @SchemeNo                                   
and InvStatus = 0)                                    
                                    
Open XCsr                                    
                                    
fetch from XCsr into @InvestCode                                    
                                    
while @@fetch_Status = 0                                    
begin                                    
     select @Investment = InvestDesc,@MaxPcnt = MaxPcntofAsset                                     
     from InvestmentTypes where InvestCode = @InvestCode     
         
     select @Investment = Rep_Inv_Class_Desc from fn_Rep_Inv_Class() where Rep_Inv_Class = @InvestCode                              
                              
     select @TargetAlloc = TargetAlloc,@MinAllocation = MinAllocation                    
    ,@MaxAllocation = MaxAllocation from TBL_Invest_TaxRates                              
     where InvestCode = @InvestCode and schemeNo = @SchemeNo                              
                              
     if @TargetAlloc is null select @TargetAlloc = 0                     
     if @MinAllocation is null select @MinAllocation = 0                    
     if @MaxAllocation is null select @MaxAllocation = 0                                  
                                   
     if @InvestCode = 1 /* Property*/                              
        Exec Proc_Property_Value @SCHEMENO,@AsAt,@Amount Out                                                                                                               
     else if @InvestCode = 2 /* Equities*/                              
        Exec Proc_Equity_Value @SCHEMENO,@AsAt,@AsAt,0,@Amount Out               
     else if @InvestCode = 3 /* Quoted Equities*/                              
        Exec Proc_Equity_Value @SCHEMENO,@AsAt,@AsAt,0,@Amount Out                                                               
     else if @InvestCode = 4 /* Government Paper and Corporate Bonds */     
        begin                             
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,0,0,@Amount Out    
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,1,0,@CorpBonds Out    
        select @Amount = @Amount + @CorpBonds    
            
        select @CorpBonds = 0    
        end                               
     else if @InvestCode = 5 /* Fixed Term Deposits */                              
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,2,0,@Amount Out                                                                                                                                   
     else if @InvestCode = 8 /* Call Deposits */                              
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,3,0,@Amount Out    
     else if @InvestCode = 10 /* Offshore Fixed Interest*/    
        Exec Proc_Endowments_Value @schemeNo,@AsAt,@AsAt,0,0,@Amount Out                 
     else if @InvestCode = 11 /* Offshore Investments */                            
        Exec Rep_OffshoreValue @SCHEMENO,0,@AsAt,@Amount out                              
                                        
     if @Amount is null select @Amount = 0                                    
                                    
     Select @Total = @Total + @Amount,@TotalTarget = @TotalTarget + @TargetAlloc                                   
                                    
     Insert Into #PortFolio (Investment,Amount, MaxPcntofAsset,currency,AsAtDate,TargetAlloc,                    
                             MinAllocation,MaxAllocation)                                    
                  Values(@Investment,@Amount,@MaxPcnt,@Currency,@AsAt,@TargetAlloc,                    
                         @MinAllocation,@MaxAllocation)                                    
                                    
     Select @Amount = 0,@TargetAlloc = 0,@MinAllocation=0,@MaxAllocation=0                                    
                                    
   fetch next from XCsr into @InvestCode                                    
end                              
Close XCsr                                    
Deallocate XCsr    
end      
                                   
update #PortFolio set Total = @Total,schemeName = @SchemeName                                    
                                    
Select @Investment = ' '                                    
select @Amount = 0       
      
select @TotalTarget = sum(TargetAlloc) from #PortFolio where Amount > 0      
      
                                    
                                    
declare Acsr cursor for                                    
Select Investment, Amount,TargetAlloc                                    
from #PortFolio                                    
                                    
Open Acsr                                    
                                    
fetch from acsr Into @Investment,@Amount,@TargetAlloc                                    
                                    
while @@fetch_Status = 0                                    
begin                                    
  Select @Percentage = (@Amount/@Total)*100.0000000      
        
  select @TargetValue = (@TargetAlloc/@TotalTarget) * @Total      
        
  if @TargetValue is null select @TargetValue = 0      
        
  select @ValueVariance = @Amount - @TargetValue                                       
                                    
  update #PortFolio set Percentage = @Percentage,TargetValue = @TargetValue,ValueVariance = @ValueVariance                                    
  where Investment = @Investment                                    
                                    
  Select @Percentage = 0,@Amount=0,@TargetAlloc=0,@ValueVariance=0,@TargetValue=0                                                               
  fetch from acsr Into @Investment,@Amount,@TargetAlloc                                    
end                                    
Close Acsr                                    
Deallocate Acsr         
        
update #PortFolio set VarAllocation = Percentage - TargetAlloc                                     
                                    
                                    
Select * from #PortFolio  where Amount > 0
go

