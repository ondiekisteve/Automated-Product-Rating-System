CREATE PROCEDURE [dbo].[RepCertExist]      
@schemeNo Int,      
@DatePrepared Datetime,    
@RepMode Int      
--with Encryption      
as      
if @RepMode = 0 /* All */    
select distinct p.memberNo,p.PenNo, p.schemeNo, p.payYear,       
(upper(m.Sname) + ', ' + m.Fname + '  '+ m.Onames) as fullname,      
(DateDiff(Day,m.dob,@DatePrepared))/365 as age,      
case received      
when 1 then 'Yes'      
when 0 then 'No'      
end as Received,      
p.dateRec,s.SchemeName,p.MonPension,p.DatePrepared,p.ReturnDate      
from  pen_certExist p      
     inner join members m       
     on p.SchemeNo = m.schemeNo and p.memberNo = m.memberNo       
     inner join Scheme s      
     on p.SchemeNo = s.schemeCode       
where p.SchemeNo = @schemeNo and p.DatePrepared = @DatePrepared      
else if @RepMode = 1 /* Renewals */    
select distinct p.memberNo,p.PenNo, p.schemeNo, p.payYear,       
(upper(m.Sname) + ', ' + m.Fname + '  '+ m.Onames) as fullname,      
(DateDiff(Day,m.dob,@DatePrepared))/365 as age,      
case received      
when 1 then 'Yes'      
when 0 then 'No'      
end as Received,      
p.dateRec,s.SchemeName,p.MonPension,p.DatePrepared,p.ReturnDate      
from  pen_certExist p      
     inner join members m       
     on p.SchemeNo = m.schemeNo and p.memberNo = m.memberNo       
     inner join Scheme s      
     on p.SchemeNo = s.schemeCode       
where p.SchemeNo = @schemeNo and p.DatePrepared = @DatePrepared    
And Received = 1     
else if @RepMode = 2 /* Non Renewals */    
select distinct p.memberNo,p.PenNo, p.schemeNo, p.payYear,       
(upper(m.Sname) + ', ' + m.Fname + '  '+ m.Onames) as fullname,      
(DateDiff(Day,m.dob,@DatePrepared))/365 as age,      
case received      
when 1 then 'Yes'      
when 0 then 'No'      
end as Received,      
p.dateRec,s.SchemeName,p.MonPension,p.DatePrepared,p.ReturnDate      
from  pen_certExist p      
     inner join members m       
     on p.SchemeNo = m.schemeNo and p.memberNo = m.memberNo       
     inner join Scheme s      
     on p.SchemeNo = s.schemeCode       
where p.SchemeNo = @schemeNo and p.DatePrepared = @DatePrepared    
And Received <> 1   
else if @RepMode = 3 /* POBS */    
select distinct p.memberNo,p.PenNo, p.schemeNo, p.payYear,       
(upper(m.Sname) + ', ' + m.Fname + '  '+ m.Onames) as fullname,      
(DateDiff(Day,m.dob,@DatePrepared))/365 as age,      
case received      
when 1 then 'Yes'      
when 0 then 'No'      
end as Received,      
p.dateRec,s.SchemeName,p.MonPension,p.DatePrepared,p.ReturnDate      
from  pen_certExist p      
     inner join members m       
     on p.SchemeNo = m.schemeNo and p.memberNo = m.memberNo 
     inner join Pensioner x      
     on p.SchemeNo = x.schemeNo and p.memberNo = x.memberNo and x.PayType = 4      
     inner join Scheme s      
     on p.SchemeNo = s.schemeCode       
where p.SchemeNo = @schemeNo and p.DatePrepared = @DatePrepared    
And Received = 1
go

