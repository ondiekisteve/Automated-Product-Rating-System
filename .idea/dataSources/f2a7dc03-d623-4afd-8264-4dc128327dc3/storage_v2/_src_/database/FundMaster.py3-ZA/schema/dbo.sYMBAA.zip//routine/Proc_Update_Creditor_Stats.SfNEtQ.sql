CREATE PROCEDURE [dbo].[Proc_Update_Creditor_Stats]
@SCHEMENO Int,
@LPONo Int
as
declare @AmountInvoiced float,@AmountPaid float,
@CreditorCode Int
declare acsr cursor for
select sum(Quantity * UnitPrice) from payablesInvoice
where schemeNo = @schemeNo and lpoNo = @lpoNo
group by LpoNo

open acsr

fetch from acsr into @AmountInvoiced

while @@fetch_Status = 0
begin
  select @CreditorCode = CreditorCode from Payables where lpoNo = @lpoNo and SchemeNo = @schemeNo

  select @AmountPaid = sum(Amount) from PayablesPayment where schemeNo = @schemeNo and LpoNo = @LpoNo

  if @AmountPaid is null select @AmountPaid = 0

  if @AmountPaid = @AmountInvoiced
     update CreditorsRegister set DebtorStatus = 1 where DebtorCode = @CreditorCode and SchemeNo = @schemeNo
  else
     update CreditorsRegister set DebtorStatus = 0 where DebtorCode = @CreditorCode and SchemeNo = @schemeNo 

  select @AmountInvoiced = 0,@AmountPaid = 0

  fetch next from acsr into @AmountInvoiced
end
Close Acsr
Deallocate Acsr
go

