CREATE PROCEDURE [dbo].[GetDebitWithholdingTax]
@SCHEMENO Int,
@MemberNo int
--with Encryption
as

if object_id('tempdb..#DebitWithholdingTax') is null

begin
create table #DebitWithholdingTax
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[DrDesc] [varchar](100) NOT NULL ,
	[Debit] [Decimal](12,2) not  NULL default 0.0,
        [Total] [Decimal](12,2) null default 0.0 
) 

ALTER TABLE #DebitWithholdingTax WITH NOCHECK ADD 

            
	CONSTRAINT [PK_DebitTaxOnLumpsums] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end


declare @Desc varchar(50),@Debit decimal(20,2),@YaConversion Varchar(25),@Chapaa decimal(20,2)

	     
      select @Debit = withholdingTax,@Desc = Upper(Consultant) +' - Withholding Tax' from 
      FeesInvoice
      where  SchemeNo = @schemeNo and PayCode = @MemberNo

 select @YaConversion = cast(@Debit as Varchar(25))
                     Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
                     select @Debit = @Chapaa
                     select @Chapaa = 0
      
 insert into #DebitWithholdingTax (drDesc,Debit)
                 Values(@Desc,@Debit)

update #DebitWithholdingTax set total = @Debit
              
select *  from #DebitWithholdingTax
go

