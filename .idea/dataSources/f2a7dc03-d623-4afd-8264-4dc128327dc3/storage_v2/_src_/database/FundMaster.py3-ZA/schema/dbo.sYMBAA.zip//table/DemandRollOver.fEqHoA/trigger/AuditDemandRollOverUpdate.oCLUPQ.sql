CREATE TRIGGER [dbo].[AuditDemandRollOverUpdate] on [dbo].[DemandRollOver]
--WITH ENCRYPTION
for update 
as

declare @SchemeNo varchar(15),@DepositNo Int,@RollOverDate Datetime,@PrimaryKey varchar(50),@SqlStr varchar(1000),
        @Interest decimal(20,2),@Remarks varchar(255),@oInterest decimal(20,2),@oRemarks varchar(100)
        
select @SchemeNo = SchemeNo ,@DepositNo = DepositNo,@RollOverDate  = RollOverDate,
       @oInterest = Interest,@oRemarks = Remarks from Deleted

select @PrimaryKey = @SchemeNo + ' - ' + cast(@DepositNo as varchar(15)) + ' - ' + cast(@RollOverDate as varchar(30))

select @Interest = Interest,@Remarks = Remarks from Inserted


if @Interest <>@OInterest
begin

select @SqlStr = ( 'update DemandRollOver set Interest = ''' + cast(@OInterest as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and DepositNo = ' + cast(@DepositNo as varchar(15)) + ' and RollOverDate = ''' + cast(@RollOverDate as varchar(30))+'''')

insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values('Income Demand Deposits','Interest', @OInterest,@Interest,@PrimaryKey,getdate(),user,'Income',@SqlStr)
 
end

if @Remarks <>@ORemarks
begin

select @SqlStr = ( 'update DemandRollOver set Remarks = ''' + cast(@ORemarks as varchar(100)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and DepositNo = ' + cast(@DepositNo as varchar(15)) + ' and RollOverDate = ''' + cast(@RollOverDate as varchar(30))+'''')

insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values('Income Demand Deposits','Remarks', @ORemarks,@Remarks,@PrimaryKey,getdate(),user,'Remarks',@SqlStr)
 
end
go

