CREATE PROCEDURE [dbo].[Proc_Update_Buy_Sell_Units]   
@CashBookNo Int
--with Encryption    
as    
declare @Buy_Sell_Units smallint,@PeriodClosed smallint,@schemeCode Int,
@TransDate datetime
  
select @Buy_Sell_Units = Buy_Sell_Units,@schemeCode = SchemeCode,@TransDate = ChequeDate from cashbook where CashbookNo = @CashBookNo    
    
if @Buy_Sell_Units is null select @Buy_Sell_Units = 0

select @PeriodClosed = PeriodClosed from AccountingPeriods where SchemeNo = @schemeCode
and StartDate <= @TransDate and EndDate >= @TransDate 

Update AccountingPeriods set PeriodClosed  = 0 where SchemeNo = @schemeCode  
and StartDate <= @TransDate and EndDate >= @TransDate    
    
if @Buy_Sell_Units = 0    
   update CashBook set Buy_Sell_Units = 1 where CashbookNo = @CashBookNo    
else    
   update CashBook set Buy_Sell_Units = 0 where CashbookNo = @CashBookNo 

Update AccountingPeriods set PeriodClosed  = @PeriodClosed where SchemeNo = @schemeCode  
and StartDate <= @TransDate and EndDate >= @TransDate
go

