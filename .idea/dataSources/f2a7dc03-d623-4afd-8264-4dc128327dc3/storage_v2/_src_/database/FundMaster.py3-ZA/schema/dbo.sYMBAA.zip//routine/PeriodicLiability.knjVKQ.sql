CREATE PROCEDURE [dbo].[PeriodicLiability]
@SCHEMENO Int,
@PayMonth int,
@PayYear int,
@RepType bit
--with Encryption
as

if @RepType = 0
   begin
        select m.schemeNo, m.MemberNo, Upper(m.sName) as surName, m.fname +' '+m.Onames as OtherNames, Upper(m.sName) +', '+ m.fname +' '+m.Onames as FullName, 
        sum(p.Net) as TotalLiability, Count(*) as Months
        from Members m
               inner Join PensionPayroll p on m.SchemeNo = p.schemeNo and m.MemberNo = p.MemberNo and p.Hold = 0
               inner Join PensionStoppage ps on  m.SchemeNo = ps.schemeNo and m.MemberNo = ps.MemberNo and ps.Reinstated = 0
         where m.SchemeNo = @schemeNo and ((p.PayYear <= @PayYear) and (p.PayMonth <= @PayMonth)) 
         Group by m.schemeNo, m.MemberNo, m.sname, m.fName, m.Onames
   end
else
   begin
        select m.schemeNo, m.DependantCode as MemberNo, Upper(m.sName) as surName, m.fname +' '+m.Oname as OtherNames, Upper(m.sName) +', '+ m.fname +' '+m.Oname as FullName, 
        sum(p.Net) as TotalLiability, Count(*) as Months
        from Dependants m
               inner Join PensionPayrollBen p on m.SchemeNo = p.schemeNo and m.MemberNo = p.MemberNo and m.DependantCode = p.DependantCode and p.Hold = 0
               inner Join PensionStoppageBen ps on  m.SchemeNo = ps.schemeNo and m.MemberNo = ps.MemberNo and m.DependantCode = ps.DependantCode and ps.Reinstated = 0
         where m.SchemeNo = @schemeNo and ((p.PayYear <= @PayYear) and (p.PayMonth <= @PayMonth)) 
         Group by m.schemeNo, m.DependantCode, m.sname, m.fName, m.Oname


   end
go

