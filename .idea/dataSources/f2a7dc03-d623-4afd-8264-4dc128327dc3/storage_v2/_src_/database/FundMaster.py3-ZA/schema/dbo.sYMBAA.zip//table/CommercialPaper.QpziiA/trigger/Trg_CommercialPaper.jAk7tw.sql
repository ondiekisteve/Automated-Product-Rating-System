CREATE TRIGGER [dbo].[Trg_CommercialPaper] ON [dbo].[CommercialPaper] 
FOR INSERT
AS

declare @SchemeNo Int,@PaperNo Int,@UserName varchar(60),@BankAcc varchar(30)

select @UserName = user

select @schemeNo = SchemeNo,@PaperNo = PaperNo,@BankAcc = BankAcc from Inserted

Exec Proc_Auto_Insert_InvPosting @schemeNo ,@PaperNo,7,140,@PaperNo,1,@UserName

update CommercialPaper set Posted = 0 where schemeNo = @schemeNo and PaperNo = @PaperNo


if @BankAcc is null select @BankAcc ='0'

if @BankAcc <> '0'
begin
if not Exists(select AccountCode from schemeBankBranch where schemeNo = @schemeNo and AccountCode = @BankAcc)
  begin
      raiserror('The Bank account specified has not been set up under the Scheme Bankers in Scheme set up',16,1)
      return
  end
end
go

