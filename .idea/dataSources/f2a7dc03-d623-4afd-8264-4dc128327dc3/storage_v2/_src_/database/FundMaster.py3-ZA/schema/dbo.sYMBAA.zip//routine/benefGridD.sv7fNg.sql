CREATE PROCEDURE [dbo].[benefGridD]    
@SCHEMENO Int,    
@MemberNo int,    
@DecCode int    
--with Encryption    
as    
    
set concat_null_yields_null off    
    
select    
Dependants.SchemeNo, Dependants.MemberNo, Dependants.DependantCode,    
(upper(Dependants.SName) + ', ' + Dependants.FName + ' ' + Dependants.OName) as FullName,    
(Dependants.Address) as FullAddress,    
Dependants.DOB,    
case Dependants.Sex    
  when 'M' then 'Male'    
  when 'F' then 'Female'    
  else 'Unknown'    
end as DepSex,    
DependantType.TypeDesc,    
Dependants.PcntBenefit,    
case    
      (    
      select    
      count(*)    
      from maturePeople    
      where    
      (maturePeople.MaturityDate <= GetDate()) and    
      (maturePeople.DependantCode = Dependants.DependantCode)    
      )    
  when 0 then 'Minor'    
  else 'Adult'    
end as MaturityStatus,Dependants.ArrPosted,Dependants.HasGuardian    
from Dependants inner join    
    DependantType on    
    Dependants.DependantType = DependantType.TypeCode    
where    
(Dependants.SchemeNo = @SchemeNo) and    
(Dependants.MemberNo = @MemberNo) and Dependants.DecDepCode = @DecCode
go

