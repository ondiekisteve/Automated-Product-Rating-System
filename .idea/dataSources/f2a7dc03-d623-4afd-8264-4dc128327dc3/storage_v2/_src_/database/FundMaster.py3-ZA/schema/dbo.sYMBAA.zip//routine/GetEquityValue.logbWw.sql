CREATE PROCEDURE [dbo].[GetEquityValue]    
@SCHEMENO Int,    
@EquityNo int    
--with Encryption    
as    
declare @AverageCost float,@AsAtDate Datetime    
    
select @AsAtDate = GetDate()    
    
Exec fn_Equity_Avg_Cost @schemeNo,@EquityNo, @AsAtDate, @AverageCost Out    
    
select E.SchemeNo, E.EquityNo,E.EquityDesc,E.NoOfShares * E.PricePerShare as BookValue,    
       E.PricePerShare, E.NoOfShares,    
       e.EquityRate, case e.EquityClass    
  when 0 then 'Ordinary'    
  when 1 then 'Preferential' end as EquityClass,    
      i.ManagerName,e.RebateComm,@AverageCost as AverageCost    
from Equity E    
    inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.Manager = i.simCode    
where e.schemeNo = @schemeNo and e.EquityNo = @equityNo
go

