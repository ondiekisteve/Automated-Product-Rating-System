--select * from TBL_Unitization where TransDate = 'Apr 1,2010'

--select sum(Amount) from TBL_Unitization where TransSource = 0 and TransSourceCat = 0 and TransDate = 'Apr 1,2010'
--select sum(Amount) from TBL_Unitization where TransSource = 0 and TransSourceCat = 1 and TransDate = 'Apr 1,2010'

CREATE PROCEDURE [dbo].[Proc_Audit_Unitization]
@schemeNo int,
@TransDate datetime,
@TransSource Int, /* 0 Cash , 1 - Accruals 2 - Journals */
@TransSourceCat int /* 0 - Receipts, 1 - Payments, 2 - Accruals */
--with Encryption
as
if object_id('tempdb..#Unit_Test') is null                             
begin                
create table #Unit_Test                
(           
 TransNo int primary key,        
 InitAmount float,         
 Split float,
 SplitDiff float,        
 GlobalAmt float,
 GlobalDiff float                     
)                       
end
delete from #Unit_Test
         
declare @TransNo int,@Amount float,@Split float,@Global float,@SplitDiff float,@GlobalDiff float
declare acsr cursor for
select transNo,Amount 
from TBL_Unitization where TransSource = @TransSource and TransSourceCat = @TransSourceCat 
and TransDate = @TransDate and SchemeNo = @schemeNo
open acsr
fetch from acsr into @TransNo,@Amount
while @@fetch_status = 0
begin
   if @TransSource = 0
      begin
         select @Split = sum(Amount) from Unit_Buy_Sale_History
         where schemeNo = @schemeNo and ChildSchemeNo <> SchemeNo and UnitType = 7
         and TransType = @TransSourceCat and TransDate = @TransDate and BatchNo_fk = @TransNo 

         select @Global = sum(Amount) from Unit_Buy_Sale_History
         where schemeNo = @schemeNo and ChildSchemeNo = SchemeNo and UnitType = 7
         and TransType = @TransSourceCat and TransDate = @TransDate and BatchNo_fk = @TransNo 
      end

   select @SplitDiff = round(@Amount-@Split,0),@GlobalDiff =round(@Amount-@Global,0) 

   if @SplitDiff < 0 
      select @SplitDiff = 0 - @SplitDiff 

   if @GlobalDiff < 0 
      select @GlobalDiff = 0 - @GlobalDiff 
   
   if ((@SplitDiff > 0) or (@GlobalDiff > 0))
     begin
        Insert into #Unit_Test select @TransNo,@Amount,@Split,round(@Amount-@Split,0),@Global,round(@Amount-@Global,0)            
     end

   select @TransNo=0,@Amount=0
   fetch next from acsr into @TransNo,@Amount
end
close acsr
deallocate acsr

select * from #Unit_Test order by TransNo
go

