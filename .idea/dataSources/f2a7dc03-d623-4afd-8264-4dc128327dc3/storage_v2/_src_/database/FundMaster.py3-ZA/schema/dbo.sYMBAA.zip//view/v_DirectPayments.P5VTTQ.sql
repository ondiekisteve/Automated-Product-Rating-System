CREATE VIEW [dbo].[v_DirectPayments]        
as        
Select SchemeNo,PaymentNo,Payee,Address,PaymentDesc,PaymentDate,ReceiptPayment,Posted,ChequeNo,ReceiptNo,        
vat,Withholding,DeductionMode,BankCode,IncomeCode,ExpenditureCode,ControlTotal        
from DirectPayment where Tran_Status = 0
go

