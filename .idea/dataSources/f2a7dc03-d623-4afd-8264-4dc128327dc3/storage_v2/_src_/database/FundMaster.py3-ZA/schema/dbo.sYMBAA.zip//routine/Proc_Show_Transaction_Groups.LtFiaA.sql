














CREATE PROCEDURE Proc_Show_Transaction_Groups
@SCHEMENO Int,
@TransCode Int,
@Pay_Rec Int
as
if @Pay_Rec =  0
   select * from TBL_Payables 
   where schemeNo = @schemeNo and TransCode = @TransCode
else if @Pay_Rec =  1
   select * from TBL_Receivables 
   where schemeNo = @schemeNo and TransCode = @TransCode


go

