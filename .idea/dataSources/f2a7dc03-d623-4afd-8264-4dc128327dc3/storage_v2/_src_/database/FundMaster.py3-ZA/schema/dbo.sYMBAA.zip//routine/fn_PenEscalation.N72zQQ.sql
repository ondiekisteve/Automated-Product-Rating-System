CREATE FUNCTION [dbo].[fn_PenEscalation](@SCHEMENO Int)
returns @tbl_var table(EscalMode int identity(1,1) primary key,
                       EscalationFactor float not null unique
                       )
as
 begin

  if Not Exists (Select * from AnnuityPackage where schemeNo = @schemeNo)
     Insert Into @tbl_Var(EscalationFactor)
                        Values(0.00)
  else
     Insert Into @tbl_Var select Distinct PenEscalation from AnnuityPackage
              where schemeNo = @schemeNo
  return
 end
go

