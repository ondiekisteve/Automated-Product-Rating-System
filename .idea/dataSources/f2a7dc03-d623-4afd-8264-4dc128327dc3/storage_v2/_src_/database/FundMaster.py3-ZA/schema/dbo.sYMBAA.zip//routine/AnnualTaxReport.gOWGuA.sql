CREATE PROCEDURE [dbo].[AnnualTaxReport]
@SCHEMENO Int,
@payYear int
--with Encryption
as

if object_id('tempdb..#EarlyTax') is null

begin
create table #EarlyTax
( 
  [SCHEMENO][VARCHAR](15) NOT NULL,
  [SCHEMENAME][VARCHAR](100) NOT NULL,
  [DESCRIPTION][VARCHAR](25) NOT NULL,
  [TAX][FLOAT] NULL,
  [EarlyTax][float] null,
  [LumpsumTax][float] null,
  [ForeignTax][float] null,
  [TotalTax][float] null,
  [MONTHName][varchar](15) not null,
  [CurYear][int] not null
) 

ALTER TABLE #EarlyTax WITH NOCHECK ADD             
	CONSTRAINT [PK_EarlyTax] PRIMARY KEY  NONCLUSTERED 
	(
		[SchemeNo],
		[MonthName], 
                           [Description]   
	) 
end

declare @memberNo int
declare @tax float
declare @totPension float
select @totpension =0
declare @fullname varchar(80)
declare @schemeName varchar(100)
declare @Description varchar(20)
declare @MonthName varchar(20)
declare @payMonth int
declare @withHoldingTax float, @foreignTax float, @LumpsumTax float
declare @StartMonth int
declare @TotalTax float
select @TotalTax = 0

select @schemeName = schemeName from scheme where schemeCode = @schemeNo

select @StartMonth = 1

while @StartMonth <= 12
begin
declare PensionCsr cursor for
select p.schemeNo, sum(p.tax) as TotalTax, p.PayMonth, m.MonthName
from  pensionPayroll p 
         Inner Join MonthTable m on p.payMonth = m.MonthNumber 
where
(p.SchemeNo = @schemeNo) and
(p.payYear=@payYear) and (p.payMonth = @StartMonth)

Group by p.schemeNo, p.payMonth, m.MonthName

order by p.PayMonth

open PensionCsr

fetch next from PensionCsr
into @schemeno, @tax,@PayMonth, @MonthName

while (@@fetch_status = 0)
begin
  
   insert into #EarlyTax (schemeNo, schemeName, description, tax, MonthName, curYear)
   
   values (@schemeNo, @schemeName, 'Pensioners', @Tax, @Monthname, @PayYear)
  
/* Tax on withDrawals */
   select @withHoldingTax  = 0
 
   select @withHoldingTax = sum(b.withholdingTax)
   from Members m
               inner join Benefits b on m.schemeNo = b.schemeNo and m.memberNo = b.memberNo
     where m.SchemeNo = @schemeNo and m.doexit is not null and ((datepart(Month, m.doexit ) = @StartMonth) and (datepart(Year,m. doexit) = @PayYear))   
     and ((m.ReasonforExit = 1) or (m.reasonforExit = 5) or (m.reasonforExit =  6) or ((m.reasonforExit >= 8) and (m.reasonforExit <= 15)))       
   
   if @withHoldingTax is null select @withHoldingTax = 0.0
   
  /* Tax on Lumpsums*/
   select @LumpsumTax  = 0
 
   select @LumpsumTax = sum(p.wTaxPd)
   from Members m
               inner join Pensioner p on m.schemeNo = p.schemeNo and m.memberNo = p.memberNo
     where m.SchemeNo = @schemeNo and m.doexit is not null and ((datepart(Month, m.doexit ) = @StartMonth) and (datepart(Year,m. doexit) = @PayYear))          
     and ((ReasonforExit >1) and (ReasonForExit <= 4))

   if @LumpsumTax is null select @LumpsumTax = 0.0

 /* Tax on Foreign Pensioners */
 
   select @ForeignTax  = 0
 
   select @ForeignTax = sum(p.withholdingTax)
   from Members m
               inner join PensionPayroll p on m.schemeNo = p.schemeNo and m.memberNo = p.memberNo
     where m.SchemeNo = @schemeNo and m.doexit is not null and ((datepart(Month, m.doexit ) = @StartMonth) and (datepart(Year,m. doexit) = @PayYear))          
   
   if @ForeignTax is null select @ForeignTax = 0.0

   update  #EarlyTax set EarlyTax = @WithHoldingTax, LumpsumTax = @LumpsumTax, ForeignTax = @ForeignTax
   
   where #EarlyTax.schemeNo = @schemeNo and #EarlyTax.MonthName = @MonthName
  

  select @TotalTax = tax + earlyTax + LumpsumTax + ForeignTax from #earlyTax  where schemeNo = @schemeNo and MonthName = @MonthName


  update  #EarlyTax set TotalTax = @TotalTax
   
   where schemeNo = @schemeNo and MonthName = @MonthName

  fetch next from PensionCsr
  into @schemeno,  @tax, @PayMonth, @MonthName
end

close PensionCsr 
deallocate PensionCsr


    Select @StartMonth = @StartMonth + 1
end
select * from #earlyTax
go

