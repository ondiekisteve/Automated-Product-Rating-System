CREATE PROCEDURE [dbo].[Proc_Excess_Reserve]
@schemeNo Int,
@AcctPeriod Int
--with Encryption
as

declare @Has_ReserveFund smallInt,@ReserveFundLimit float,@MemberBalances float,@ReserveBalance float,
@Excess_Reserve float

select @Has_ReserveFund = Has_ReserveFund,@ReserveFundLimit = ReserveFundLimit from scheme
where schemeCode = @schemeNo

if ((@Has_ReserveFund = 1) and (@ReserveFundLimit > 0.0))
begin
    select @MemberBalances = sum(EmpCont + EmprCont + EmpVolCont + EmprVolCont + Transfer + LockedIn
                                 + PreAvc + PreEmpCont + PreEmprCont)
    from MemberOpeningBalances where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod

    select @ReserveBalance = ReserveBalance 
    from ReserveOpeningBalance where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod

    if @MemberBalances is null select @MemberBalances = 0.0
    if @ReserveBalance is null select @ReserveBalance = 0.0

    if @ReserveBalance >  (@MemberBalances *  (@ReserveFundLimit/100.00))
       select @Excess_Reserve = @ReserveBalance - (@MemberBalances *  (@ReserveFundLimit/100.00)) 
    else 
       select @Excess_Reserve = 0.0


    update ReserveOpeningBalance set ExcessReserve = @Excess_Reserve
    where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod
    
end
go

