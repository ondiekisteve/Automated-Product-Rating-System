CREATE FUNCTION [dbo].[fn_DBStatementMode]()              
returns @tbl_var table(StatementMode int primary key,              
                       DBStatementDesc varchar(100)        
                       )              
as              
 begin              
       
       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(0,'DB Benefits Statement without Accum. Credit')

       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(1,'DB Benefits Statement (with Tabulated Accumulated Credit and Without Actual DB Benefit )')

       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(2,'DB Benefits Statement (with Tabulated Accumulated Credit and Actual DB Benefit)')  

       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(3,'DB Benefits Statement (with Tabulated Accumulated Employee and Actual DB Benefit)')    

       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(4,'DB Benefits (Retirement & Withdrawal Benefits and Tabulated Accumulated Credit)') 

       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(5,'DB Benefits (Retirement & Withdrawal Benefits and Tab. Accum. Credit and Dependants)') 

       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(6,'DB Benefits (Retirement & Withdrawal Benefits)') 

       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(7,'DB Benefits Statement with Combined Accumulated Credit)')

       insert into @tbl_var(StatementMode,DBStatementDesc)        
              Values(8,'Standard DB Benefits Statement') 

  return              
 end
go

