CREATE PROCEDURE [dbo].[Proc_GL_Posting_Det]      
@schemeNo Int,      
@TransNo Int   
--with Encryption
as
select t.*,u.Unit_Desc,u.UnitType,d.Unit_Cat_Desc
from TBL_Unitization_Det t
     inner join Unit_Trusts_Type u on t.schemeNo = u.schemeNo and t.Asset_Class = u.InvestCode
     inner join fn_Unitization_Cat() d on t.Unit_Cat = d.Unit_Cat
where t.schemeNo = @schemeNo and t.TransNo = @TransNo
go

