CREATE TRIGGER [dbo].[T_InvestValue_Treasury] ON [dbo].[GovernmentSecurities] 
FOR UPDATE
AS

declare @SchemeNo Varchar(15),@SecurityNo Int,@AmountInvested Decimal(20,2),@DateInvested Datetime,@RebateComm Decimal(20,2),
@HandlingFees Decimal(20,2),@BankAcc varchar(30),@MatDate datetime,@NoofDays int,@TiedToGl smallint



select @schemeNo = schemeNo,@SecurityNo = SecurityNo,@AmountInvested = AmountInvested,@RebateComm = RebateComm,
@DateInvested = TransDate,@HandlingFees = HandlingFees,@BankAcc = BankAcc,@MatDate = MaturityDate from Inserted

--Exec Proc_Get_Num_Days @schemeNo,@SecurityNo,@DateInvested,@MatDate,@NoofDays out 

select @NoofDays = 0

Exec Proc_Update_Tied @schemeNo,@SecurityNo,@TiedToGl out

if @TiedToGl > 1 select @TiedToGl = 1


update GovernmentSecurities set TiedToGl = @TiedToGl
where SchemeNo = @schemeNo and SecurityNo = @SecurityNo

update Investments set InitValue = @AmountInvested,DateComm =  @DateInvested,HandlingFees = @HandlingFees
where SchemeNo = @schemeNo and InvCode = @SecurityNo


if @BankAcc is null select @BankAcc ='0'

if @BankAcc <> '0'
begin
if not Exists(select AccountCode from schemeBankBranch where schemeNo = @schemeNo and AccountCode = @BankAcc)
  begin
      raiserror('The Bank account specified has not been set up under the Scheme Bankers in Scheme set up',16,1)
      return
  end
end
go

