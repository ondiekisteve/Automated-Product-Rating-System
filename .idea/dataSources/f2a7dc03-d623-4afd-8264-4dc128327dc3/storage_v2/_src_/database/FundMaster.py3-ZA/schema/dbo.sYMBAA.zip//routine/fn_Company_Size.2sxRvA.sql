CREATE FUNCTION [dbo].[fn_Company_Size] ()            
returns @tbl_var table(CompSizeId int primary key,              
                       CompanySize varchar(100)        
                       )              
as              
 begin              
          
  insert into @tbl_var(CompSizeId,CompanySize)        
              Values(0,'<= 350K')       
        
  insert into @tbl_var(CompSizeId,CompanySize)        
              Values(1,'> 350K')       
            
  return   
        
 end
go

