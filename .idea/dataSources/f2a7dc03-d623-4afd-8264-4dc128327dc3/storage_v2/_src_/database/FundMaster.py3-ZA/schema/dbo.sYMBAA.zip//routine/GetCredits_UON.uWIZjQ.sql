/*
Modifications Feb 21,2004
1. where @Vtype = 2 and @VSubType = 1
    Add @PcntBenefit in the Calculation of the @Credit Amount

   Tax on Arrears of Monthly Pension

*/

CREATE PROCEDURE [dbo].[GetCredits_UON]
@SCHEMENO Int,
@MemberNo int,
@Depcode int,
@TransType int,
@vType int,
@vSubType int
--with Encryption
as

if object_id('tempdb..#Credits') is null

begin
create table #Credits
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[glDesc] [varchar](100) NOT NULL ,
	[glCredit] [Decimal](12,2) not  NULL default 0.0,
             [glTotal] [decimal](12,2) null default 0.0,
             [glMax][int] not null    
) 

ALTER TABLE #Credits WITH NOCHECK ADD 

            
	CONSTRAINT [PK_Credits] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end

declare @Credit decimal(20,2), @Deductions float, @Desc varchar(50), @Amount decimal(20,2), @DoExit datetime, @DaysInMonth int, @ExitDay int, @ExitMonth int, @MonthName varchar(20),
             @ExitYear int, @NumDays int, @Claimdate smalldatetime, @doappmt smalldatetime, @Tax decimal(20,2), @Loans decimal(20,2), @Arrears decimal(20,2),
             @xLumpsum decimal(20,2),@xMonthly decimal(20,2), @TaxArr decimal(20,2),@yMonthly decimal(20,2),@DoCalc datetime,@LoanDesc varchar(30),@Attachment float,@MaxCode int,@pcntBenefit float,
             @TaxArrears decimal(20,2),@YaConversion Varchar(25),@Chapaa decimal(20,2),@glCode Int

select @Deductions = 0
Select @Loans = 0
Select @Arrears = 0
select @yMonthly = 0

if @vType = 1  /* MEMBERS AND PENSIONERS RELATED PAYMENTS */
    begin
    if @vSubType = 1
       begin
	if @TransType = 1
   	     begin
     		 if Exists (select * from MemberDeductions where schemeNo like @SchemeNo and MemberNo = @MemberNo) 
         		begin
             			declare DeductCsr cursor for
             			select d.Deduction, (dc.Deduction) from 
            			 MemberDeductions dc 
             			inner Join Deductions d on dc.DeductCode = d.DeductCode  
             
            			 where  dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo
            			 Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
            				 begin
                				 Insert Into #Credits (glDesc, glCredit,glMax)
                   				 Values (@Desc,@Amount, 0)

                				 fetch next from DeductCsr into @Desc, @Amount
           				  end
            				 Close DeductCsr
             				 Deallocate DeductCsr

        				 select @Deductions = sum(glCredit) from #Credits
        			 end
 
   /* Company Loans */
   if Exists (select * from MemberCompanyLoan where schemeNo like @SchemeNo and MemberNo = @MemberNo) 
         		             begin
             			declare DeductCsr cursor for
             			select d.LoanDesc, dc.Loan from 
            			 MemberCompanyLoan dc 
             			inner Join CompanyLoans d on dc.LoanCode = d.LoanCode  
             
            			 where  dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo and dc.Paid = 0
            			 Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
            				 begin
                                                                

                				 Insert Into #Credits (glDesc, glCredit,glMax)
                   				 Values (@Desc,@Amount, 0)

                				 fetch next from DeductCsr into @Desc, @Amount
           				  end
            				 Close DeductCsr
             				 Deallocate DeductCsr

        				 select @Deductions = sum(glCredit) from #Credits
                                                      
        			 end

  /* Court Attachment */

   Select @Attachment = AttachAmount from CourtAttachments where SchemeNo like @SchemeNo 
   and MemberNo = @MemberNo and AttachType = 1
 
   if @Attachment is null select @Attachment = 0

   if @Attachment > 0

                           begin
                                    

                                   Insert Into #Credits (glDesc, glCredit,glMax)
                   	           Values ('Court Attachment',@Attachment, 0)
                            end
                        /*End Court Attachment */

      			select @Credit = (EmprCBal + EmpCBal + VolCBal + SpecialCBal) - withholdingTax from Benefits 
      			where schemeNo like @SchemeNo and MemberNo = @MemberNo
      
      			select @Credit = @Credit - (@deductions + @Attachment)

                                      
      			Insert Into #Credits (glDesc, glCredit, glMax)
                   		 Values ('Withdrawal Benefit',@Credit,1)
                        
                        /*
     			 select @Credit = withholdingTax  from Benefits 
      			where schemeNo like @SchemeNo and MemberNo = @MemberNo
 
                                       if @Credit > 0 begin
                                         

     			 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Withholding Tax',@Credit, 0)
                                      end
                        */
  		 end
              else if @TransType = 3/* Partial Payments */
   	      begin
     		 if Exists (select * from MemberDeductions where schemeNo like @SchemeNo and MemberNo = @MemberNo) 
         		begin
             			declare DeductCsr cursor for
             			select d.Deduction, (dc.Deduction) from 
            			 MemberDeductions dc 
             			inner Join Deductions d on dc.DeductCode = d.DeductCode  
             
            			 where  dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo
            			 Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
            				 begin
                				 Insert Into #Credits (glDesc, glCredit,glMax)
                   				 Values (@Desc,@Amount, 0)

                				 fetch next from DeductCsr into @Desc, @Amount
           				  end
            				 Close DeductCsr
             				 Deallocate DeductCsr

        				 select @Deductions = sum(glCredit) from #Credits
        			 end
 
   /* Company Loans */
      if Exists (select * from MemberCompanyLoan where schemeNo like @SchemeNo and MemberNo = @MemberNo) 
                 begin
             			declare DeductCsr cursor for
             			select d.LoanDesc, dc.Loan from 
            			 MemberCompanyLoan dc 
             			inner Join CompanyLoans d on dc.LoanCode = d.LoanCode  
             
            			 where  dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo and dc.Paid = 0
            			 Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
            				 begin
                                                                

                				 Insert Into #Credits (glDesc, glCredit,glMax)
                   				 Values (@Desc,@Amount, 0)

                				 fetch next from DeductCsr into @Desc, @Amount
           				  end
            				 Close DeductCsr
             				 Deallocate DeductCsr

        				 select @Deductions = sum(glCredit) from #Credits
                                                      
               end

  /* Court Attachment */

   Select @Attachment = AttachAmount from CourtAttachments where SchemeNo like @SchemeNo 
   and MemberNo = @MemberNo and AttachType = 1
 
   if @Attachment is null select @Attachment = 0

  if @Attachment > 0
                           begin
                                  Insert Into #Credits (glDesc, glCredit,glMax)
                   	          Values ('Court Attachment',@Attachment, 0)
                            end

                        /*End Court Attachment */
                        SELECT @Attachment = 0

      			select @Credit = AmountPaid,

                        @Attachment = TaxPaid from PartialPayment 
      			where schemeNo like @SchemeNo and MemberNo = @MemberNo
    
      			select @Credit = @Credit - (@deductions + @Attachment)
                        
                        /*Insert Into #Credits (glDesc, glCredit, glMax)
                   		 Values ('Withholding Tax',@Attachment,0)
                        */
                                      
      			Insert Into #Credits (glDesc, glCredit, glMax)
                   		 Values ('Partial Withdrawal Benefit',@Credit,1)
                        
                       
  		 end
	      else if @TransType = 2
    		  begin
     		      if Exists (select * from MemberDeductions where schemeNo like @SchemeNo and MemberNo = @MemberNo) 
        		       begin
             			declare DeductCsr cursor for
             			select d.Deduction, dc.Deduction from 
             			MemberDeductions dc 
                    		inner Join Deductions d on dc.DeductCode = d.DeductCode and dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo
            
             
             			Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
             			 begin
                                                   

                			 Insert Into #Credits (glDesc, glCredit,glMax)
                   			 Values (@Desc,@Amount, 0)

                			 fetch next from DeductCsr into @Desc, @Amount
             			 end
            			 Close DeductCsr
            			 Deallocate DeductCsr

         			select @Deductions = sum(glCredit) from #Credits

                                      
        	                      end
 
   /* Company Loans */
   if Exists (select * from MemberCompanyLoan where schemeNo like @SchemeNo and MemberNo = @MemberNo) 
         		             begin
             			declare DeductCsr cursor for
             			select d.LoanDesc, dc.Loan from 
            			 MemberCompanyLoan dc 
             			inner Join CompanyLoans d on dc.LoanCode = d.LoanCode  
             
            			 where  dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo
            			 Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
            				 begin
                                                                  

                				 Insert Into #Credits (glDesc, glCredit,glMax)
                   				 Values (@Desc,@Amount, 0)

                				 fetch next from DeductCsr into @Desc, @Amount
           				  end
            				 Close DeductCsr
             				 Deallocate DeductCsr

        				 select @Deductions = sum(glCredit) from #Credits

                                                    
        			 end

   /* Court Attachment */

   Select @Attachment = AttachAmount from CourtAttachments where SchemeNo like @SchemeNo 
   and MemberNo = @MemberNo and AttachType = 1
 
   if @Attachment is null select @Attachment = 0

   if @Attachment > 0
   begin
            
            Insert Into #Credits (glDesc, glCredit,glMax)
                   	                         Values ('Court Attachment',@Attachment, 0)
   end
/*End Court Attachment */

      			select @Credit = ComLumGWTax - wTaxPd, @Arrears = Arrears,@TaxArrears = ArrTax from Pensioner
			where schemeNo like @SchemeNo and MemberNo = @MemberNo
      
   if @TaxArrears is null select @TaxArrears = 0
   if @Arrears is null select @Arrears = 0

     			 select @Credit = @Credit + @Arrears - (@deductions + @Attachment + @TaxArrears)
 
                                      
      			Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Lumpsum Payable',@Credit, 1)

                        /*
                        if @TaxArrears > 0
                                        begin
                                        Insert Into #Credits (glDesc, glCredit,glMax)
                    		        Values ('Tax on Pension Arrears',@TaxArrears,0)
                                        end
                       
      			select @Credit = wTaxPd from Pensioner 
      			where schemeNo like @SchemeNo and MemberNo = @MemberNo
                       
                        
                        if @Credit > 0 begin
                                      
     		             Insert Into #Credits (glDesc, glCredit,glMax)
                    		Values ('Withholding Tax',@Credit,0)

                                        end
     		             if @Credit > 0
        			begin
                 			select @DoExit = DoExit from Members where schemeNo like @schemeNo and MemberNo = @MemberNo

                 			select @ExitDay = datepart(day, @DoExit) + 1

                 			select @ExitMonth = datepart(Month, @DoExit)

                 			select @ExitYear = datepart(Year, @DoExit)
     
                		 	exec getDaysInMonth @ExitMonth, @DaysInMonth out
 
                 			exec getMonthName @ExitMonth, @MonthName out
                
               		
                 			select @MonthName = @MonthName +', '+cast(@ExitYear as varchar(4))
                
               		 	        select @NumDays = @DaysInMonth - @ExitDay

      			       end
                     */
     		end
               end--vSubType - vtype = 1, vsubType = 1 - NORMAL WITHDRAWAL/RETIREMENT LUMPSUM

               else if @vSubType = 2  /* PENSIONERS LIABILITY  */
                         begin
  select @Credit = sum(p.Net)
  from PensionStoppage ps

  inner Join PensionPayroll P on ps.schemeNo like p.schemeNo and ps.MemberNo = p.MemberNo and p.Hold = 0
  where ps.ArrearsPaid = 0 and ps.MemberNo = @MemberNo and ps.SchemeNo = @SchemeNo
 
 Select @Credit =  @Credit
 if @Credit > 0 begin
                        
                        Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Liability on Suspended Pension',@Credit, 1)
                         end
                         end
               else if @vSubType = 3 /*PENSIONERS LIABILITY ON REVISION OF PENSION*/
                         begin
   /* Company Loans */
   if Exists (select * from MemberCompanyLoan where schemeNo like @SchemeNo and MemberNo = @MemberNo and Paid = 0) 
         		             begin
             			declare DeductCsr cursor for
             			select d.LoanDesc, dc.Loan from 
            			 MemberCompanyLoan dc 
             			inner Join CompanyLoans d on dc.LoanCode = d.LoanCode  and dc.Paid = 0
             
            			 where  dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo
            			 Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
            				 begin
                                                                  

                				 Insert Into #Credits (glDesc, glCredit,glMax)
                   				 Values (@Desc,@Amount, 0)

                				 fetch next from DeductCsr into @Desc, @Amount
           				  end
            				 Close DeductCsr
             				 Deallocate DeductCsr

        				 select @Deductions = sum(glCredit) from #Credits

        			 end

                           /*******************************/
 select @Credit =  p.WTaxPd -r.Tax
 From Pen_Revise r
 inner Join Pensioner p on r.schemeNo like p.schemeNo and r.MemberNo = p.MemberNo
 where r.schemeNo like @schemeNo and r.MemberNo = @MemberNo and r.Paid = 0 and r.Voucher = 0
                    
 Select @TaxArr = @Credit

 if @Credit > 0 begin
  
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Tax Arrears',@Credit, 0)
  end
 select @xLumpsum = r.Lumpsum,
  @xMonthly = (p.MonPension -r.MonPension)* cast(datediff(Month,r.Startdate, r.RevDate) as float) +
                    (p.MonPension -r.MonPension)* (cast(31 - (datePart(day,r.Startdate))as float)/31.00)
                    
 From Pen_Revise r
 inner Join Pensioner p on r.schemeNo like p.schemeNo and r.MemberNo = p.MemberNo
 where r.schemeNo like @schemeNo and r.MemberNo = @MemberNo and r.Paid = 0 and r.Voucher = 0
 
 if @xLumpsum > 0 begin
                                                                 
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Paid Lumpsum',@xLumpsum, 0)
 end
 if @xMonthly < 0 begin
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Recoveries for Monthly Pension',0-@xMonthly, 0)
 end

  if not Exists(Select * from PensionPayroll where SchemeNo like @SchemeNo and MemberNo = @MemberNo)
  begin
 Select @DoExit = DoExit,@DoCalc = DoCalc from members where SchemeNo like @SchemeNo and MemberNo = @MemberNo

 select @yMonthly =  (MonPension)* cast((datediff(Month,@DoExit, @DoCalc)) as float) +
 (MonPension)* (cast(31.00 - (datePart(day,@DoExit))as float)/31.00)
 from Pensioner where SchemeNo like @SchemeNo and MemberNo = @MemberNo
 if @yMonthly is null select @yMonthly = 0
 end            
 
 if @xMonthly is null select @xMonthly = 0
  
 if @yMonthly is null select @yMonthly = 0
 if @yMonthly < 0  select @yMonthly = 0

 if @Deductions is null select @Deductions = 0

 if @TaxArr is null select @TaxArr = 0

 declare @Lump float

 select @Lump = p.ComLumgwTax                         
 From Pen_Revise r
 inner Join Pensioner p on r.schemeNo like p.schemeNo and r.MemberNo = p.MemberNo
 where r.schemeNo like @schemeNo and r.MemberNo = @MemberNo and r.Paid = 0 and r.Voucher = 0
                               
 select @Credit = (@Lump + @xMonthly + @yMonthly)  - (@Deductions + @xLumpsum + @TaxArr)             

  if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Lumpsum Arrears',@Credit, 1)
                         end

               else if @vSubType = 4 /*LIABILITY ON PENSIONERS LOST/STALE/RETURNED CHEQUES*/
                         begin
  select @Credit = sum(Amount)
 From ReturnedCheques
 where schemeNo like @schemeNo and MemberNo = @MemberNo and paid = 0
                             
 if @Credit > 0
                          Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Returned Cheques',@Credit, 1)
                         end
             else if @vSubType = 5  /*LIABILITY ON REFUNDS*/
                         begin
                               
 Select @LoanDesc = a.LoanDesc, @Credit = b.Loan
 from MemberCompanyLoan b
  inner Join CompanyLoans a on b.Loancode = a.LoanCode
 where b.SchemeNo = @SchemeNo and b.MemberNo = @MemberNo and  b.Refund = 1
 and b.LoanCode = @DepCode
 
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
  Values (@LoanDesc,@Credit, 1)    
                         end
             else if @vSubType = 6  /*LIABILITY ON UNPAID PENSION*/
                         begin
                               
                               Select @TaxArr = 0
                               
                               Select @Credit =  (dateDiff(Month,u.StartDate,u.EndDate)+1) * p.MonPension ,@TaxArr = u.Tax
                               from UnPaidPension u
                               inner Join Pensioner p on u.schemeNo like p.SchemeNo and u.MemberNo = p.MemberNo
                               inner Join Members m  on u.schemeNo like m.SchemeNo and u.MemberNo = m.MemberNo
                               where u.SchemeNo like @SchemeNo and u.MemberNo = @MemberNo and u.Paid = 0
                               
                              

                               Select @TaxArr = (dateDiff(Day,StartDate,EndDate)/30) * @TaxArr
                               from UnpaidPension where schemeNo like @Schemeno and MemberNo = @MemberNo and Paid = 0

 if @TaxArr >0
 begin
   select @Credit = @Credit - @TaxArr


  
    Insert Into #Credits (glDesc, glCredit,glMax)
    Values ('P.A.Y.E',@TaxArr, 0)    
 end
                               
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
  Values ('Unpaid Pension',@Credit, 1)    
                         end

                else if @vSubType = 7
                         begin
 select @Credit = ((r.MonPension - p.MonPension) * r.Months)
 From Pen_Revise r
   inner Join Pensioner p on r.schemeNo = p.SchemeNo and r.MemberNo = p.MemberNo
 where r.schemeNo like @schemeNo and r.MemberNo = @MemberNo and r.Refund = 1
                             
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Refund on Over-Recovery ',@Credit, 1)
                         end
              else if @vSubType = 8
                         begin
 select @Credit = r.Deduction * r.Months
 From MemberDeductions r
 where r.schemeNo like @schemeNo and r.MemberNo = @MemberNo and r.Refund = 1
 and r.Deduct = @DepCode
                 
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Refund on Over-Recovery ',@Credit, 1)

      end

    else if @vSubType = 9
                         begin

 select @Credit = sum(amount)
 From UnclaimedCheques 
 where schemeNo like @schemeNo and  MemberNo = @MemberNo and  DependantCode = 0  and Reversed = 1 and Paid = 0
                             
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit, glMax)

                   		 Values ('Unclaimed Cheques',@Credit, 1)
                         end

             else if @vSubType = 10  /*LIABILITY ON CASH BENEFIT REVISION*/
                         begin
                               Select @Credit = (b.EmprCBal + b.EmpcBal + b.VolCBal + b.SpecialCBal) - r.RevGross ,
                               @xMonthly = (b.WithholdingTax- r.RevTax)
                               from WithdrawalRevision r
                               inner Join Benefits b  on r.schemeNo like b.SchemeNo and r.MemberNo = b.MemberNo
                               where r.SchemeNo like @SchemeNo and r.MemberNo = @MemberNo 
                               
 if @xMonthly >0
 begin
   select @Credit = @Credit - @xMonthly
  
    Insert Into #Credits (glDesc, glCredit,glMax)
    Values ('P.A.Y.E Arrears',@xMonthly, 0)    
 end

 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
  Values ('Arrears on Revision Pension',@Credit, 1)    
                         end
       end /* MEMBERS / PENSIONERS RELATED PAYMENT VOUCHER CREDITS */


  else if @vType = 2  /* BENEFICIARIES RELATED PAYMENT VOUCHER CREDITS */
       begin
                if @vSubType = 1  /* BENEFICIARIES  DEATH GRATUITY */
                         begin
   /* Company Loans */
   if Exists (select * from MemberCompanyLoan where schemeNo like @SchemeNo and MemberNo = @MemberNo) 
         		             begin
             			declare DeductCsr cursor for
             			select d.LoanDesc, dc.Loan from 
            			 MemberCompanyLoan dc 
             			inner Join CompanyLoans d on dc.LoanCode = d.LoanCode  
             
            			 where  dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo
            			 Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
				 begin
      				 Insert Into #Credits (glDesc, glCredit,glMax)
                   				 Values (@Desc,@Amount, 0)

                				 fetch next from DeductCsr into @Desc, @Amount
           				  end
            				 Close DeductCsr
             				 Deallocate DeductCsr

        				 select @Deductions = sum(glCredit) from #Credits
        			 end
  
  
      			select @Credit = (EmprCBal + EmpCBal)- (withholdingTax + adjustment) from Benefits 
      			where schemeNo like @SchemeNo and MemberNo = @MemberNo
      
 /*****************************************************************************************************/
   select @PcntBenefit = PcntGratuity from Dependants where schemeno like @schemeNo and MemberNo = @MemberNo
   and DependantCode = @DepCode
   
 select @Credit = @Credit*(@PcntBenefit/100.00000)
                    if @deductions > 0 select @deductions = @deductions*(@PcntBenefit/100.00000)
   /*****************************************************************************************************/
   else select @Deductions = 0

      			select @Credit = @Credit - @deductions

      			Insert Into #Credits (glDesc, glCredit, glMax)
                   		 Values ('Death Gratuity',@Credit, 1)

     			 select @Credit = withholdingTax from Benefits 
      			where schemeNo like @SchemeNo and MemberNo = @MemberNo
   
  /*****************************************************************************************************/
 select @Credit = @Credit*(@PcntBenefit/100.00000)
   /*****************************************************************************************************/
 if @Credit > 0
     			      Insert Into #Credits (glDesc, glCredit,glMax)
                   		      Values ('Withholding Tax',@Credit,0)        
                         end

               else if @vSubType = 2  /* BENEFICIARIES LIABILITY  */
                         begin
                               select @Credit = sum(p.Net)
  from PensionStoppageBen ps
  inner Join PensionPayrollBen P on ps.schemeNo like p.schemeNo and ps.MemberNo = p.MemberNo 
        and ps.DependantCode = p.DependantCode and p.Hold = 0
  where ps.ArrearsPaid = 0 and ps.MemberNo = @MemberNo and ps.SchemeNo = @SchemeNo
 
 Select @Credit =  @Credit
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Liability on Suspended Pension',@Credit, 1)
                         end
               else if @vSubType = 3 /*BENEFICIARIES LIABILITY ON REVISION OF PENSION*/
                         begin
                             
 if Exists (Select * from PenBeneficiary where schemeNo like @schemeNo and MemberNo  =@MemberNo and Dependantcode = @Depcode)
  begin
            select  @Credit = (p.MonPension -r.MonPension)* cast(datediff(Month,r.Startdate, r.RevDate) as float) +
                    (p.MonPension -r.MonPension)* (cast(31 - (datePart(day,r.Startdate))as float)/31.00)
                    
            From Pen_Revise_Ben r
            inner Join PenBeneficiary p on r.schemeNo like p.schemeNo and r.MemberNo = p.MemberNo and r.Dependantcode = p.Dependantcode
            where r.schemeNo like @schemeNo and r.MemberNo = @MemberNo and r.Dependantcode = @DepCode and r.Paid = 0 and r.Voucher = 0
    end
 else
    begin
           select  @Credit = (p.MonPension -r.MonPension)* cast(datediff(Month,r.Startdate, r.RevDate) as float) +

                    (p.MonPension -r.MonPension)* (cast(31 - (datePart(day,r.Startdate))as float)/31.00)
                    
            From Pen_Revise_Ben r
            inner Join MemBeneficiary p on r.schemeNo like p.schemeNo and r.MemberNo = p.MemberNo and r.Dependantcode = p.Dependantcode
            where r.schemeNo like @schemeNo and r.MemberNo = @MemberNo  and r.Dependantcode = @DepCode and r.Paid = 0 and r.Voucher = 0
    end

 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Arrears on Revision of Pension',@Credit, 1)
 
                             
                         end
               else if @vSubType = 4 /*LIABILITY ON BENEFICIARIES LOST/STALE CHEQUES*/
                         begin
 select @Credit = sum(Amount)

 From ReturnedChequesBen
 where schemeNo like @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode and paid = 0
                             
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Returned Cheques',@Credit, 1)
                         end
              else if @vSubType = 5 /*PENSION ARREARS ON DEATH OF MEMBERS/PENSIONER*/
                         begin
  if Exists (select * from PenBeneficiary where schemeNo like @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode)
   select @Credit = Arrears, @Tax = Tax  from PenBeneficiary where schemeNo like @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode
   else
   select @Credit = Arrears, @Tax = Tax from MemBeneficiary where schemeNo like @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode

     		             if @Credit > 0
   begin
             select @Claimdate = ClaimDate, @doAppmt = DOApmt from Dependants where schemeNo like @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode
                		 	Insert Into #Credits (glDesc, glCredit, glMax)
                 		 	Values ('Pension arrears from  '+ cast(@doAppmt as varchar(20))+ 'to  ' + cast(@ClaimDate as varchar(20)), @Credit - @Tax,1)
      			  end

  if @Tax > 0 /*  Tax on Pension arrears*/
   begin
                		 	Insert Into #Credits (glDesc, glCredit,glMax)
                 		 	Values ('Tax on Pension arrears from  '+ cast(@doAppmt as varchar(20))+ 'to  ' + cast(@ClaimDate as varchar(20)), @Tax, 0)
      			  end        
                         end
             else if @vSubType = 6 /*BENEFICIARIES LIABILITY ON UNPAID  PENSION*/
                         begin
                               Select @TaxArr = 0

                               if Exists  ( select * from PenBeneficiary where schemeNo like @schemeNo and MemberNo = @MemberNo and Dependantcode = @Depcode)
    BEGIN
             Select @Credit =  (dateDiff(Month,u.StartDate,u.EndDate)+1) * p.MonPension ,@TaxArr = u.Tax
              from UnPaidPensionBen u
              inner Join PenBeneficiary p on u.schemeNo like p.SchemeNo and u.MemberNo = p.MemberNo and u.Dependantcode = p.Dependantcode
              inner Join Dependants m  on u.schemeNo like m.SchemeNo and u.MemberNo = m.MemberNo  and  u.Dependantcode = m.Dependantcode
              where u.SchemeNo like @SchemeNo and u.MemberNo = @MemberNo and u.Dependantcode = @Depcode
and u.Paid = 0
   END
                    else
   BEGIN
                Select @Credit = (dateDiff(Month,u.StartDate,u.EndDate)+1) * p.MonPension ,@TaxArr = u.Tax
              from UnPaidPensionBen u
              inner Join memBeneficiary p on u.schemeNo like p.SchemeNo and u.MemberNo = p.MemberNo and u.Dependantcode = p.Dependantcode
              inner Join Dependants m  on u.schemeNo like m.SchemeNo and u.MemberNo = m.MemberNo  and  u.Dependantcode = m.Dependantcode
              where u.SchemeNo like @SchemeNo and u.MemberNo = @MemberNo and u.Dependantcode = @Depcode and u.Paid = 0

   END

            

    Select @TaxArr =(dateDiff(Day,StartDate,EndDate)/30) * @TaxArr    from UnpaidPensionBen where schemeNo like @Schemeno and MemberNo = @MemberNo
    and Dependantcode = @Depcode and Paid = 0
   
 
 if @TaxArr >0
 begin
   select @Credit = @Credit - @TaxArr
  
    Insert Into #Credits (glDesc, glCredit,glMax)
    Values ('P.A.Y.E',@TaxArr, 0)    
 end
 
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
  Values ('Unpaid Pension',@Credit, 1)    
                         end

              if @vSubType = 7  /* DECEASED PENSIONERS LUMPSUM PAYMENT VIA BENEFICIARY */
  begin
                           
 /* Company Loans */
   if Exists (select * from MemberCompanyLoan where schemeNo like @SchemeNo and MemberNo = @MemberNo) 
         		             begin
             			declare DeductCsr cursor for
             			select d.LoanDesc, dc.Loan from 
            			 MemberCompanyLoan dc 
             			inner Join CompanyLoans d on dc.LoanCode = d.LoanCode  
             
            			 where  dc.SchemeNo like @schemeNo and dc.MemberNo = @MemberNo
            			 Open DeductCsr

            			 fetch from DeductCsr into @Desc, @Amount
            			 while @@fetch_Status =0
            				 begin
                				 Insert Into #Credits (glDesc, glCredit,glMax)
                   				 Values (@Desc,@Amount, 0)

                				 fetch next from DeductCsr into @Desc, @Amount
           				  end
            				 Close DeductCsr
             				 Deallocate DeductCsr

        				 select @Deductions = sum(glCredit) from #Credits
        			 end

      			select @Credit = ComLumGWTax- wTaxPD from Pensioner 
      			where schemeNo like @SchemeNo and MemberNo = @MemberNo
      
      			select @Credit = @Credit - @deductions

      			Insert Into #Credits (glDesc, glCredit, glMax)
                   		 Values ('Lumpsum',@Credit, 1)

     			 select @Credit = wTaxPd from Pensioner 
      			where schemeNo like @SchemeNo and MemberNo = @MemberNo
 
 if @Credit > 0
     			      Insert Into #Credits (glDesc, glCredit,glMax)
                   		      Values ('Withholding Tax',@Credit,0)        
                              end  

              else if @vSubType = 8
                         begin
                    select @Credit = sum(amount)
 From UnclaimedCheques 
 where schemeNo like @schemeNo and  MemberNo = @MemberNo and  DependantCode = @Depcode  and Reversed = 1 and Paid = 0
                             
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Unclaimed Cheques',@Credit, 1)
                         end  
                  else if @vSubType = 9/* Unpaid Pension Balance for pensioner who has died before the Guaranteed period is over */
                         begin
 select @Credit = sum(amount)
 From DependantPayment 
 where schemeNo like @schemeNo and  MemberNo = @MemberNo and  DependantCode = @Depcode and Paid = 0
                             
 if @Credit > 0
 Insert Into #Credits (glDesc, glCredit,glMax)
                   		 Values ('Pension Balance',@Credit, 1)
                         end                
       end

Select @Credit = 0
declare acsr cursor for
Select glCode,glCredit 
from #Credits
open acsr
fetch from acsr into @glCode,@Credit
while @@fetch_Status = 0
begin
     /* rounding  gross*/
              select @YaConversion = cast(@Credit as Varchar(25))
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
              select @Credit = @Chapaa
              select @Chapaa = 0

             update #Credits set glCredit = @Credit
             where glCode = @glCode

             select @Credit = 0
     fetch next from acsr into @glCode,@Credit
end
Close Acsr
Deallocate Acsr

declare @Total decimal(20,2)

select @Total = sum(glCredit) from #Credits

update #Credits set glTotal = @Total

select * from #Credits
go

