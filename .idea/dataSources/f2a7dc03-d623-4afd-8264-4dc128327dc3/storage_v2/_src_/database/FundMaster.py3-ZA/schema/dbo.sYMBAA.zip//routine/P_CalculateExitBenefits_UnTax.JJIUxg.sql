CREATE PROCEDURE [dbo].[P_CalculateExitBenefits_UnTax]
@SCHEMENO Int,
@memberNo int,
@exitReason tinyint,
@exitDate datetime,
@IntMode Int
--with Encryption
as

set nocount on


declare @EmpOpeningBal float
declare @EmprOpeningBal float
declare @EmpContributions float
declare @EmprContributions float
declare @SimpleInterest int
declare @curMonth  int
declare @EmpClosing float
declare @EmprClosing float
declare @VolClosing float
declare @SpecialClosing float,
@funcResult int, @currYear int, @yearClosed bit, @retCode int,@AcctPeriod int, @PeriodToUse int,@DoCalc datetime,
@xDate Datetime

select @DoCalc = DoCalc from Members where SchemeNo = @schemeNo and Memberno = @MemberNo


select @SimpleInterest = CalculationMode from Scheme where schemeCode = @schemeNo

Exec GetAccountingPeriodInaYear @SchemeNo,@CurMonth,@CurrYear,@AcctPeriod Out

Select @xDate = EndDate from schemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod

if @DoCalc is null select @DoCalc = @ExitDate

if @DoCalc > @xDate
select @doCalc = @xDate

select @currYear = datepart(Year, @DoCalc)
select @curMonth = datepart(Month, @DoCalc)


Select @PeriodToUse = @AcctPeriod - 1

--get Opening Balances
declare @hasBal bit
if exists(select * from UnregisteredBalances where SchemeNo = @schemeNo and memberNo = @memberNo) 
  begin
     select @hasBal = 1
     select @EmpOpeningBal  = (Excessemp + Excessvolcontr)  - (EmpTax + VolTax)from UnregisteredBalances
                              where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @PeriodToUse
     
     select @EmprOpeningBal  = (ExcessEmpr + ExcessSpecial)  - (EmprTax + SpecTax) from UnRegisteredBalances
                              where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @PeriodToUse
    

     if @EmprOpeningBal is null select @EmprOpeningBal  =  0
   
     if @EmpOpeningBal  is null select @EmpOpeningBal  =  0 
 end
else
    begin
       select @hasBal = 0
       select @EmprOpeningBal  =  0
       select @EmpOpeningBal  =  0 
    end

select @retCode = @@error
if @retCode <> 0 goto just_go
 
declare @totEmpCont float, @totEmprCont float, @totSpecialContr float, @totVolContr float, @totBenef float

if @simpleInterest = 1
          exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @curMonth,@currYear, @hasBal,@IntMode,@totEmpCont out, @totEmprCont out,  @totVolContr out, @totSpecialContr out
else if @simpleInterest =  2
          exec Proc_CalcMonthlyInterestAVG_Un @schemeNo, @memberNo, @CurMonth, @currYear,  @hasBal, @IntMode,@totEmpCont out,@totEmprCont out,  @totVolContr out, @totSpecialContr out
else if @simpleInterest = 0
           exec Proc_CalcMonthlyInterestSI_Un @schemeNo, @memberNo, @CurMonth, @currYear,  @hasBal, @IntMode,@totEmpCont out, @totEmprCont out, @totVolContr out,  @totSpecialContr out
else if @simpleInterest =  4
          exec Proc_CalcMonthlyInterestAVGComp_Un 0,@schemeNo, @memberNo, @CurMonth, @currYear,  @hasBal, @totEmpCont out,@totEmprCont out,  @totVolContr out, @totSpecialContr out
else if @simpleInterest =  5
          exec Proc_CalcMonthlyInterestAVGComp_SI_Un @schemeNo, @memberNo, @CurMonth, @currYear,  @hasBal,@IntMode, @totEmpCont out,@totEmprCont out,  @totVolContr out, @totSpecialContr out
else if @simpleInterest = 6
        exec Proc_CalcMonthlyInterestSI_MonUn @schemeNo, @memberNo, @curMonth, @currYear,@hasBal,@IntMode, @totEmpCont out, @totEmprCont out,@totVolContr out, @totSpecialContr out
else if @simpleInterest = 7
        exec Proc_CalcMonthlyInterestSI_NonProUn @schemeNo, @memberNo, @curMonth, @currYear,@hasBal, @IntMode,@totEmpCont out, @totEmprCont out,@totVolContr out, @totSpecialContr out
else if @simpleInterest = 9
        exec Proc_CalcMonthlyInterest_Un_Daily @schemeNo, @memberNo, @curMonth, @currYear,@hasBal, @IntMode,@totEmpCont out, @totEmprCont out,@totVolContr out, @totSpecialContr out


else  if @simpleInterest = 11
       exec Proc_CalcMonthlyInterest_UnMonthDep 
       @schemeNo, @memberNo, @curMonth,@currYear, @hasBal, @IntMode,
       @totEmpCont out, @totEmprCont out,  @totVolContr out, @totSpecialContr out
else
       exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @curMonth,@currYear, @hasBal, @IntMode,@totEmpCont out, @totEmprCont out,  @totVolContr out, @totSpecialContr out


select @EmpClosing = @totEmpCont 
select @EmprClosing = @totEmprCont 
Select @VolClosing = @totVolContr
Select @SpecialClosing =  @totSpecialContr                              
                               

if not Exists (select * from UnRegisteredBenefits where SchemeNo = @schemeNo and MemberNo = @MemberNo)
    Insert into UnRegisteredBenefits( schemeNo, MemberNo, ExcessEmpCont, ExcessEmprCont, ExcessVolContr,
                                      ExcessSpecial, SchemeYear,
                                      EEmpCBal,EEmprCBal,EVolCBal,ESpecialCBal)
                  Values(@schemeNo, @MemberNo, @EmpClosing, @EmprClosing, @VolClosing, @SpecialClosing, @currYear,
                                      @EmpClosing, @EmprClosing, @VolClosing, @SpecialClosing)
else
   update UnRegisteredBenefits set ExcessEmpCont = @EmpClosing, ExcessEmprCont = @EmprClosing, 
                                   ExcessVolContr = @VolClosing, ExcessSpecial = @SpecialClosing,
                                   EEmpCBal = @EmpClosing, EEmprCBal = @EmprClosing, EVolCBal=@VolClosing, 
                                   ESpecialCBal = @SpecialClosing
          where SchemeNo = @schemeNo and MemBerNo  = @MemberNo

Exec CalculateCorpTaxExit @SchemeNo,@MemberNo

select @retCode = 0
return --@retCode

just_go:
  return --@retCode

set nocount off

return
go

