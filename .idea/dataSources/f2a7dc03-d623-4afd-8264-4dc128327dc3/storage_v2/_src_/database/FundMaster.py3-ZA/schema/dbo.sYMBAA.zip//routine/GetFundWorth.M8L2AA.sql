CREATE PROCEDURE [dbo].[GetFundWorth]
@SCHEMENO Int,
@FundWorth float out
--with Encryption
as

declare @AcctPeriod int, @OpeningReg float, @OpeningUnReg float,  @ContrReg float, @ContrUnReg float,
        @WithDrawal float

Select @AcctPeriod = Max(AcctPeriod) from MemberOpeningBalances where SchemeNo = @schemeNo

Select @OpeningReg = sum(EmpCont + EmprCont + EmpVolCont + EmprVolCont)
from MemberOpeningBalances
where SchemeNo = @SchemeNo and AcctPeriod = @AcctPeriod

Select @OpeningUnReg = sum(ExcessEmp + ExcessEmpr + ExcessVolContr + ExcessSpecial)
from UnregisteredBalances
where SchemeNo = @SchemeNo and AcctPeriod = @AcctPeriod


Select @ContrReg = sum(EmpCont + EmprCont + VolContr + SpecialContr)
from ContributionsSummary
where SchemeNo = @SchemeNo and AcctPeriod = @AcctPeriod + 1

Select @ContrUnReg = sum(ExcessEmpCont + ExcessEmprCont + ExcessVolContr + ExcessSpecial)
from UnregisteredContributionsSummary
where SchemeNo = @SchemeNo and AcctPeriod = @AcctPeriod + 1

Select @WithDrawal = sum(b.EmpcBal + b.EmprCBal + b.VolCBal + b.SpecialCBal)
from Benefits b
     inner Join Members m on m.SchemeNo = b.SchemeNo and m.MemberNo  = b.MemberNo 
                             and m.ReasonforExit <> 0 and m.ReasonforExit <> 1 and m.ReasonforExit <> 7
where b.SchemeNo = @SchemeNo

declare @DeathClaim float

Select @DeathClaim = sum(b.EmpcBal + b.EmprCBal + b.VolCBal + b.SpecialCBal)
from Benefits b
     inner Join Members m on m.SchemeNo = b.SchemeNo and m.MemberNo  = b.MemberNo 
                             and m.ReasonforExit = 1 
where b.SchemeNo = @SchemeNo

select @FundWorth = (@OpeningReg + @OpeningUnReg + @ContrReg + @ContrUnReg) - (@WithDrawal + @DeathClaim)
go

