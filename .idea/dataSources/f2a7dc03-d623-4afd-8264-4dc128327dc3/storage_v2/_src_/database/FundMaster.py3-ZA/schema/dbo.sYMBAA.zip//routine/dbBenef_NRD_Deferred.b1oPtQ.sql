CREATE PROCEDURE [dbo].[dbBenef_NRD_Deferred]    
@schemeno as Int,    
@memberno as int,   
@TransDate datetime,    
@totBenef as float out,    
@CommLumpsum float Out,  
@serviceTime as varchar(30) out    
--with Encryption    
as    
    
set nocount on    
    
declare @pastservice as float    
declare @dje as datetime, @doexit as datetime    
declare @retsal as float    
declare @dbConstant as float    
declare @dbMODE int    
declare @ContrYear int    
declare @ContrMonth int    
declare @RetAge int    
declare @MemberClass varchar(3)    
declare @Sex varchar(3)    
declare @Age int    
declare @CalcYears float    
declare @dob datetime    
declare @TempService int    
declare @dtemp datetime, @AddedServ int,    
@MaxService int,@Housing float,@HalfDays int,@FullDays int,@Service float,@TotalMonths Int,    
@NumYears Int,@NumMonths Int,@NumDays Int,@TotalDays Int,@Months Int,@Days Int,    
@HalfYears Int,@HalfMonths Int,@TelPosta smallInt,@Mukuba smallint,@avcPension decimal(20,4),    
@CreditService int,@CreditDays int,@expectRet datetime,@Comm float     
    
/* for NSIS */    
Exec Proc_Get_Credit_Service @schemeNo,@MemberNo,@CreditService out,@CreditDays out     
    
select @Housing = 0    
    
select @Maxservice = MaxService from Pension_Setup where SchemeNo = @SchemeNo    
    
if @CreditService = 0    
   select @dTemp = dje,@MemberClass = MemberClass, @Sex = sex,@dje = djpens,@doexit = doexit,    
   @RetSal = Capensal,@dob = dob    
   from Members where SchemeNo = @schemeNo and MemberNo = @memberNo    
else if @CreditService > 0    
   select @dTemp = dje,@MemberClass = MemberClass, @Sex = sex,@dje = dgok,@doexit = doexit,    
   @RetSal = Capensal,@dob = dob   
   from Members where SchemeNo = @schemeNo and MemberNo = @memberNo    
    
if Exists (select MemberNo from DeferredPensioner where SchemeNo = @schemeNo and MemberNo = @MemberNo)   
   begin   
   select @RetSal = SalaryPerCola from DeferredPensioner where SchemeNo = @schemeNo and MemberNo = @MemberNo    
     
   end  
if @RetSal is null    
   select @RetSal = CAPENSAL  from Members where SchemeNo = @schemeNo and MemberNo = @memberNo    
    
   
if @Sex = 'M'   
   select @RetAge = MRetAge from RetirementAges where SchemeNo = @schemeNo and ClassId = @MemberClass    
else     
   select @RetAge = FRetAge from RetirementAges where SchemeNo = @schemeNo and ClassId = @MemberClass  
  
if @RetAge is null select @RetAge = 55  
  
     
select @expectRet = DATEADD(Year,@RetAge,@dob)  
    
Exec GetServiceTime @dob,@TransDate,@Age out,@Months Out,@Days Out    
      
select @dbMode = dbMode,@TelPosta = TelPosta,@Mukuba = Mukuba  from Scheme    
where SchemeCode = @schemeno    
    
if @TelPosta is null select @TelPosta = 0    
    
Exec GetPensionCFactor @SchemeNo,@MemberNo,@dje,@DoExit,@dbConstant out    
Exec GetTemporaryService @SchemeNo, @MemberNo,@dje, @dTemp,@HalfYears out,@HalfMonths Out,@HalfDays out    
Exec AddPastService @doExit,@dje,@AddedServ out   
  
  
if ((@TelPosta = 0) AND (@Mukuba = 0))      
   Exec GetServiceTime @dje,@doExit,@NumYears out,@NumMonths Out,@NumDays Out      
else if ((@TelPosta = 0) AND (@Mukuba = 1))      
   Exec GetServiceTime_Mukuba @dje,@doExit,@NumYears out,@NumMonths Out,@NumDays Out      
else if @TelPosta = 1      
   Exec GetServiceTime_TelPosta @SchemeNo,@MemberNo,@dje,@doExit,@NumYears out,@NumMonths Out,@NumDays Out     
    
    
if @Mukuba = 1    
   begin    
   Exec calcavcpension_mukuba @schemeno,@memberno,@avcpension out     
   end     
else    
   select @avcpension = 0.0    
    
if @dbMode = 0  /* Months In service */    
   begin    
          select @NumYears = @NumYears + @HalfYears    
         select @NumMonths = @NumMonths + @HalfMonths    
    
        if @NumMonths >= 12    
           select @NumYears = @NumYears + 1,@NumMonths = @NumMonths - 12    
    
         select @PastService = (@NumYears * 12) + @NumMonths    
    
         if @HalfDays + @NumDays >= 30 select @AddedServ = 1    
    
         select @PastService = @PastService + @AddedServ    
    
         select @CalcYears = @PastService   
  end    
else if @dbMode = 1  /* Complete Years in Service */    
   begin    
    select @PastService = @NumYears    
    select @CalcYears = cast(@PastService as float)    
  end    
else if @dbMode = 2  /* Complete Years in Service Plus Months in Service */    
   begin    
    
    select @NumYears = @NumYears + @HalfYears    
    select @NumMonths = @NumMonths + @HalfMonths    
    
    
    if @HalfDays + @NumDays >= 30     
           select @AddedServ = 1    
    else     
           select @AddedServ = 0    
    
    select @NumMonths = @NumMonths + @AddedServ    
    
    select @PastService = @NumYears + @NumMonths/12.0000    
    
    select @CalcYears = @PastService    
  end    
    
select @Service= @pastService    
    
select @MaxService = @MaxService * 12    
    
if @Service > @MaxService select @Service = @MaxService    
    
select @serviceTime = cast(@NumYears as varchar(2)) + ' years ' + cast(@NumMonths as varchar(2)) + ' months and '+ cast(@NumDays as varchar(2)) + ' Days '    
    
if @CalcYears > @MaxService select @calcYears = @MaxService    
    
/* To Handle Housing factor for KPA staff who Left the scheme before Jan 1, 1999*/    
    
if @DoExit < 'Jan 01,1999' and @SchemeNo = '1005'    
  begin    
         select @Housing = @RetSal * (15.00000000/100.000000000)     
         if @Housing > 12000.000000 select @Housing = 12000.000000000    
    
         select @Retsal = @RetSal + @Housing    
  end    
    
/**/      
    
Exec CalcNonPensionable @schemeNo,@MemberNo,@TotalMonths out,@TotalDays Out    
    
if @TotalMonths is null select @TotalMonths = 0    
    
if @TelPosta = 0    
begin    
if @TotalMonths > 0    
begin    
if @NumDays < @TotalDays    
   select @CalcYears = @CalcYears - 1    
    
select @CalcYears = @CalcYears - @TotalMonths    
end    
else if (@TotalMonths = 0) and (@TotalDays > 0)    
  begin    
     if @NumDays < @TotalDays    
        select @CalcYears = @CalcYears - 1    
  end    
end   
   
select @totBenef = ((@CalcYears) * (1.0000000000/@dbConstant)) * @retsal    
    
select @totBenef = @TotBenef + @avcpension   
  
/* Get Commutation Factor */  
Exec CalcCommutation @SchemeNo,@MemberNo,@expectRet,@Comm Out  
  
if @Comm is null select @Comm = 1  
  
select @CommLumpsum = @totBenef * @Comm  
    
set nocount off    
    
return
go

