









CREATE TRIGGER trg_moDelete on dbo.memberOpeningBalances
--with encryption
for delete
as

set nocount on

declare @funcResult int, @schemeNo varchar(15), @memberNo int, @AcctPeriod int, @yearClosed bit

select @schemeNo = SchemeNo, @memberNo = MemberNo, @AcctPeriod = AcctPeriod from inserted

Select @YearClosed = YearClosed from schemeYears where SchemeNo = @SchemeNo and AcctPeriod = @AcctPeriod

if (@yearClosed >= 1)
begin
  raiserror('You cannot alter closing balances in a closed period', 16, 1)
  goto error_processing
end

normal_exit:
  set nocount off
  return

error_processing:
  rollback tran
  goto normal_exit


go

