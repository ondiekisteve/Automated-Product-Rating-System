CREATE PROCEDURE [dbo].[PensionerReconciliation]
@SCHEMENO Int,
@PayMonth int,
@PayYear int
--with Encryption
as

if object_id('tempdb..##Reconciliation') is null

begin
create table ##Reconciliation
(
	[SchemeName] [varchar] (120) NOT NULL ,
	[ReconCode] [int] IDENTITY(1,1) NOT NULL ,
	[PrevPension] [float] NOT NULL ,
	[CurPension] [float] not  NULL default 0.0 ,
             [NewEntrants] [float]  not NULL default 0.0,
             [Increase][float] not null default 0.0,
             [Decrease][float] not null default 0.0,
	[Exits] [float] not NULL default 0.0,
	[Total] [float] not NULL  default 0.0,
             [Period][varchar](30) not null,
             [prevPeriod][varchar](30) not null,
             [suspension][float] null,
             [Deductions][float] null ,
             [Net][float] null     
) 

ALTER TABLE ##Reconciliation WITH NOCHECK ADD 

            
	CONSTRAINT [PK_ReconPensioner] PRIMARY KEY  NONCLUSTERED 
	(
		[SchemeName],
		[ReconCode]      
	) 
end

declare @SchemeName varchar(100), @PrevPension float, @NewEntrants float, @curPension float,
        @Increase float, @Exits float, @Total float, @Net Float, @MemberNo int, @MonthName varchar(30), 
        @PrevMonth varchar(30), @startMonth int,@StartYear int, @NetExit float, @NetIncrease float, @cNet float, @pNet float,
        @Decrease float,@NetDecrease float,@dNet float,@Suspension float,@Paye float,@Deductions float,@Attachments float

if @PayMonth = 1 
   begin
    select @StartYear = @PayYear - 1
    select @StartMonth = 12
   end
else
  begin
   select @StartYear = @PayYear
   select @StartMonth =@PayMonth -1
  end
select @SchemeName = schemeName from  scheme where schemecode =  @SchemeNo

select @MonthName = MonthName from MonthTable where MonthNumber  = @PayMonth
select @PrevMonth = MonthName from MonthTable where MonthNumber  = @StartMonth

select @MonthName = @MonthName +', '+ cast(@PayYear as varchar(4))
select @PrevMonth = @PrevMonth +', '+ cast(@StartYear as varchar(4))

select @PrevPension = Sum(Gross) from PensionPayroll 
where SchemeNo = @SchemeNo and PayMonth = @StartMonth and PayYear = @StartYear

select @NewEntrants = 0
select @Increase = 0
select @exits =0
select @NetIncrease = 0
select @Decrease = 0
select @NetDecrease= 0

select @suspension = Sum(Net)from PensionPayroll 
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and Hold = 0

if @suspension is null select suspension = 0

select @Attachments = Sum(Attachment) from AttachmentPayroll 
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear

select @Deductions = Sum(Amount) from MemberDeductionsPayment 
where SchemeNo = @SchemeNo and DeductMonth = @PayMonth and DeductYear = @payYear

select @curPension = Sum(Gross),@Paye = sum(Tax)  from PensionPayroll 
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear

if @Attachments is null select @Attachments = 0

if @Deductions is null select @Deductions = 0

if @Paye is null select @Paye = 0

select @Deductions = @Deductions + @Paye + @Attachments


Select @NewEntrants = PenEntrants from ##NewEntrants

Select @Exits = PenExits from ##NewExits

Select @Increase =  PenIncrease from ##NewIncrease

Select @Decrease = PenDecrease from ##NewDecrease

delete from ##Reconciliation

Declare @xTotal float

Select @xTotal = @PrevPension + @NewEntrants + @Increase  - (@Decrease + @Exits)



insert Into ##Reconciliation(schemeName, PrevPension, CurPension, NewEntrants,Increase,Decrease, Exits,Total, Period, PrevPeriod, Suspension, Deductions,Net)
               Values (@SchemeName, @PrevPension, @PrevPension + @NewEntrants + @Increase  - @Decrease, @NewEntrants,@Increase, @Decrease,@Exits, @xtotal,
               @MonthName, @PrevMonth,@Suspension,@Deductions, @xTotal  - (@Suspension + @Deductions))


select * from ##Reconciliation
go

