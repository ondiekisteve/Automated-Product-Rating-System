CREATE TRIGGER [dbo].[GovernmentIncomeFiscalYear] ON [dbo].[GovernmentIncome] 
--with encryption
FOR INSERT 
AS
declare @TransDate datetime,@startDate datetime,@EndDate datetime, @AcctPeriod int,@FiscalYear int,
@fiscalQuarter int,@SchemeNo varchar(15),
@PayMonth int,@PayYear int,@VoucherNo int,@Closed bit,@SecurityNo Int,@UserName varchar(60)

select @UserName = user

Select @TransDate = SecurityDate,@schemeNo = SchemeNo,@VoucherNo = PayCode,@SecurityNo = SecurityNo from Inserted

Select @StartDate = StartDate,@EndDate = EndDate,@Closed = PeriodClosed from AccountingPeriods where schemeNo = @schemeNo
and @TransDate >=  Startdate and @TransDate <= EndDate

if (@EndDate is null)
  begin
         raiserror('Error!! Invalid Accounting period - Please define a new Accounting period',16,1) 
         rollback transaction
 end

if (@Closed = 1)
  begin
         raiserror('Error!! You cannot process a transaction in a closed Accounting period',16,1) 
         rollback transaction
 end

if (@EndDate < @TransDate)
  begin
         raiserror('Error!! Invalid Accounting period - Please define a new Accounting period',16,1) 
         rollback transaction
 end

       Select @AcctPeriod = AcctPeriod,@FiscalYear = FiscalYear,@FiscalQuarter = FiscalQuarter from accountingperiods
       where schemeNo = @schemeNo and StartDate = @StartDate and EndDate = @EndDate

       update GovernmentIncome set AcctPeriod =@AcctPeriod,FiscalYear = @FiscalYear,FiscalQuarter = @FiscalQuarter,
       Posted = 0
       where schemeNo = @schemeNo and  PayCode = @VoucherNo and SecurityDate = @TransDate

Exec Proc_Auto_Insert_InvPosting @schemeNo ,@SecurityNo,4,132,@VoucherNo,0,@UserName
go

