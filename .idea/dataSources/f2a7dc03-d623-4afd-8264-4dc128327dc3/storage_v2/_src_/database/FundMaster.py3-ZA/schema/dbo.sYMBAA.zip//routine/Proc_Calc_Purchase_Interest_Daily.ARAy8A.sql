CREATE PROCEDURE [dbo].[Proc_Calc_Purchase_Interest_Daily]                        
@SCHEMENO Int,                        
@memberNo int,                        
@ProcDate datetime,                                    
@IntMode Int,                                          
@totBalance decimal(20,6) output,
@AcctPeriod Int Out                                        
--with Encryption                        
as                        
                        
set nocount on                        
                                         
Declare @PeriodtoUse int, @sDate datetime, @IntDays int,          
@CurrInterest float,@newPower float,          
@StartDate datetime,@SMonthDate datetime,    
@CurMonth int,@currYear int,@DoCalc datetime,@CalcAcctPeriod Int,@useBalances int    
    
/* Get Date of Retirement */    
select @DoCalc = DOCalc from Members where schemeNo = @schemeNo and MemberNo = @MemberNo    
    
/* Get Accounting Period of Date of Retirement */    
select @CalcAcctPeriod = AcctPeriod from schemeYears where schemeNo = @schemeNo     
and StartDate <= @DoCalc and EndDate >= @DoCalc     
    
select @CurMonth = datepart(Month,@ProcDate),@currYear = datepart(Year,@ProcDate)                          
          
/* Interest starts after how many days to allow for clearance of Cheques */                              
select @IntDays = intDays from Scheme where schemeCode = @schemeNo                  
                  
if @IntDays is null select @IntDays = 0                       
                        
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @currYear, @AcctPeriod out                        
                        
Select @sDate = StartDate                        
from SchemeYears where SchemeNo = @schemeNo  and AcctPeriod = @AcctPeriod                        
                            
EXEC Proc_Get_Int_Rate @schemeNo,@ProcDate,@IntMode,@currInterest Out               
if @currInterest is null select @currInterest = 0                        
                                              
Select @PeriodToUse = @AcctPeriod - 1     
    
IF @CalcAcctPeriod < @AcctPeriod    
   select @useBalances = 1                       
                        
if @useBalances = 1                        
   begin                        
    Select @SMonthDate = @sDate    
    select @totBalance = PurchasePrice from MemberOpeningBalances    
    where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @PeriodToUse                       
   end                        
else                        
   begin                        
     select @SMonthDate = @DOCalc    
     select @totBalance = PurchasePrice from Benefits    
     where schemeNo = @schemeNo and MemberNo = @MemberNo                              
   end                        
                        
select @newPower = power((1.0000000000 + (@currInterest/100.000)), ((datediff(day,@SMonthDate,@ProcDate)+1)/365.00))                        
            
select @totBalance = @totBalance * @newPower
go

