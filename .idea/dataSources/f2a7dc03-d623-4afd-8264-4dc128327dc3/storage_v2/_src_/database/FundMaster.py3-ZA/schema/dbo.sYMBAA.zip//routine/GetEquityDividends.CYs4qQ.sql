CREATE PROCEDURE [dbo].[GetEquityDividends] /* Dividends Receivable */            
@SCHEMENO Int,            
@EquityNo int            
--with Encryption            
as            
select V.SchemeNo, V.EquityNo,E.EquityDesc,V.NoOfShares * v.Dividend as Income,            
       v.Dividend, v.TransDate,v.Posted,v.Paycode,v.NoOfShares,       
       v.RecordDate,V.DocRefNo,v.PayCode_fk,v.AmountPaid,v.DatePaid,v.PayPosted,  
       v.PerShareOrAmount,V.Description,v.DivType           
from Equity E            
     inner Join EquityDividends V On e.SchemeNo = v.schemeNo and e.EquityNo = v.EquityNo and v.PayCode_fk = 0            
where e.schemeNo = @schemeNo and e.EquityNo = @equityNo
go

