CREATE VIEW [dbo].[ExchangeDates]  
--with encryption  
as  
Select Distinct(ExchangeDate) as ExchangeDate
from CurrencyRates
go

