CREATE PROCEDURE [dbo].[BankStatementBalance] 
@SCHEMENO Int,
@BankCode varchar(15),
@BankDate Datetime
--with Encryption
as


if object_id('tempdb..#BankBalance') is null

begin
create table #BankBalance
(
	     [SchemeNo] [varchar](15) NOT NULL ,
             [BankCode] [varchar](20) not null,
             [Payments] [float] default 0.0,
             [Receipts] [float] default 0.0,
             [Balance] [float] default 0.0                   
) 

ALTER TABLE #BankBalance WITH NOCHECK ADD 

            
	CONSTRAINT [PK_BankBalance] PRIMARY KEY  NONCLUSTERED 
	(
	  [SchemeNo]
	) 
end


Insert Into #BankBalance
select schemeNo, BankCode, sum(Debit) as Payments, sum(Credit) as Receipts, 0 as Balance
from BankStatement where SchemeNo = @schemeNo and BankCode  = @bankCode and 
TransDate = @BankDate
Group by schemeNo, BankCode

update #BankBalance set Balance = (Select  Balance from BankBalance where SchemeNo = @SchemeNo and BankCode = @BankCode
                    and BankDate = @BankDate)
select * from #BankBalance
go

