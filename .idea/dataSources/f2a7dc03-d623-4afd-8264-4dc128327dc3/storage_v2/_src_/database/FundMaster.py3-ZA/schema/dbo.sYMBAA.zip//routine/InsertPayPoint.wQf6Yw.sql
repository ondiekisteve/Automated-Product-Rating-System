CREATE PROCEDURE [dbo].[InsertPayPoint]   
@PaypointCode Int,  
@paypointname varchar (100),  
@address varchar(50),  
@Building  varchar(50),  
@Road  varchar(50),  
@town varchar(50),  
@Country varchar(50),  
@telephone varchar(20),  
@email varchar(30),  
@fax varchar(15),  
@telex varchar(15)  
--with Encryption  
as  
  

insert  into paypointsBranch  
          (PayPointCode,   
           branchName,  
           address,  
           Building,  
           Road,  
           town,  
           Country,  
           telephone,  
           email,  
           fax,  
           telex)  
values  
        (  
 @paypointCode ,   
 @PaypointName ,   
 @address ,  
 @Building,  
 @Road,  
 @town,  
 @Country ,  
 @telephone ,  
 @email ,  
 @fax ,  
 @telex   
        )
go

