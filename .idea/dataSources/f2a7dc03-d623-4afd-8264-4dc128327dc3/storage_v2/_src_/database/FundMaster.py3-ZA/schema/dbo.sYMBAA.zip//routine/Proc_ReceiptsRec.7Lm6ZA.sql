CREATE PROCEDURE [dbo].[Proc_ReceiptsRec] 
@TransNo Int,       
@SCHEMENO Int,        
@Receipt Int,              
@ReceiptDate Datetime,        
@Description varchar(100),        
@Amount float,        
@ChequeNo varchar(15),        
@TransMode Int,  
@BankCode Int,  
@IncomeCode Int        
--with Encryption        
as        
declare @TransSource Int,@DebitAcc varchar(30)        
      
        
if @TransMode = 0 /* Insert new record */        
begin        
        select @TransNo = Max(TransNo) from ReceiptsRec
        where schemeNo = @schemeNo
        
        if @TransNo is null select @TransNo = 0

        select @TransNo = @TransNo + 1

        select @TransSource = TransSource,@DebitAcc = DebitAcc from Receipts    
        where schemeNo = @schemeNo and Receipt = @Receipt    
    
        if @TransSource is null select @TransSource = 0    
        if @DebitAcc is null select @DebitAcc ='0'    
    
        if @TransSource = 0 select @DebitAcc = '0'    
       
        Insert Into ReceiptsRec(TransNo,schemeNo,Receipt,ReceiptDate,Description,  
                              Amount,ChequeNo,RecCounter,CreditAcc,BankCode,IncomeCode)        
        Values (@TransNo,@SchemeNo,@Receipt,@ReceiptDate,@Description,@Amount,  
              @ChequeNo,0,@DebitAcc,@BankCode,@IncomeCode)        
        
        Insert into ReceiptsRecInvoice(schemeNo,Receipt,TransNo_FK,Particulars,Amount,RecCounter)        
                             Values (@SchemeNo,@Receipt,@TransNo,@Description,@Amount,0)        
  end        
else if @TransMode = 1        
  begin    
        select @TransSource = TransSource,@DebitAcc = DebitAcc from Receipts    
        where schemeNo = @schemeNo and Receipt = @Receipt    
    
        if @TransSource is null select @TransSource = 0    
        if @DebitAcc is null select @DebitAcc ='0'    
    
        if @TransSource = 0 select @DebitAcc = '0'    
        
        Update ReceiptsRec set ReceiptDate = @ReceiptDate,Description = @Description,        
                       Amount = @Amount,ChequeNo = @ChequeNo,CreditAcc = @DebitAcc,  
                       BankCode = @BankCode,IncomeCode = @IncomeCode        
        where SchemeNo = @SchemeNo and Receipt = @Receipt and TransNo = @TransNo        
        
        Update ReceiptsRecInvoice set Particulars = @Description,        
                       Amount = @Amount        
        where SchemeNo = @SchemeNo and Receipt = @Receipt and TransNo_FK = @TransNo        
  end
go

