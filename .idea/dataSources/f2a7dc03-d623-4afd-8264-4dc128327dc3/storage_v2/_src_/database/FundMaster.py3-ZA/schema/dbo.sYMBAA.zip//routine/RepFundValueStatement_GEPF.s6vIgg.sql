CREATE PROCEDURE [dbo].[RepFundValueStatement_GEPF]  
@SCHEMENO Int,  
@AcctPeriod Int  
--with Encryption  
as  
  
if object_id('tempdb..#FundValueGEPF') is null  
  
begin  
create table #FundValueGEPF  
(  
        [glcode] [int] IDENTITY(1,1) NOT NULL ,  
        [SchemeName] [varchar](100) NOT NULL ,  
        [Period] [Datetime],  
        [MemberOpening] FLOAT null default 0.0,  
        [MemberContributions] FLOAT null default 0.0,  
        [MemberArrears] FLOAT null default 0.0,  
        [MemberTransfers]FLOAT null default 0.0,  
        [LoanOpening] FLOAT null default 0.0,  
        [LoanIssued] FLOAT null default 0.0,  
        [LoanRepaid] FLOAT null default 0.0,  
        [LoanBalance] FLOAT null default 0.0,  
        [MemberWithdrawal] FLOAT null default 0.0,  
        [MemberInflows] FLOAT null default 0.0,  
        [MemberBalance] FLOAT null default 0.0,  
        [SchemeBalance] FLOAT null default 0.0,  
        [StartDate][Datetime]  
)   
  
ALTER TABLE #FundValueGEPF WITH NOCHECK ADD    
              
 CONSTRAINT [PK_FundValueGEPF] PRIMARY KEY  NONCLUSTERED   
 (  
   [glcode]        
 )   
end  
  
declare @SchemeName varchar(100),@Period Varchar(50),@MemberOpening FLOAT,  
        @MemberContributions FLOAT,@MemberArrears FLOAT,  
        @MemberTransfers FLOAT,@LoanOpening FLOAT,@GLoanIssued FLOAT,  
        @GLoanRepaid FLOAT,@GLoanBalance FLOAT,@MemberWithdrawal FLOAT,  
        @MemberBalance FLOAT,@SchemeBalance FLOAT,@StartDate Datetime,@EndDate Datetime,  
        @LoanIssued FLOAT,@LoanRepaid FLOAT,@LoanBalance FLOAT,  
        @OtherDeductions FLOAT,@LastYear Datetime,@MemberNo Int  
  
select @LoanOpening = 0.0,@GLoanIssued =0.0,@GLoanRepaid = 0.0,@GLoanBalance =0.0

Select @SchemeName = SchemeName from Scheme where schemeCode = @schemeNo  
Select @StartDate = StartDate,@EndDate = EndDate,  
@LastYear = StartDate - 1 from SchemeYears where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod  
  
Select @MemberOpening = Sum(EmpCont + EmprCont+EmpVolCont + EmprVolCont + Transfer + LockedIn + PreEmpCont + PreEmprCont + PreAvc)  
from MemberOpeningBalances where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod - 1  


Select @MemberContributions = Sum(EmpCont + EmprCont+VolContr + SpecialContr)  
from Contributionssummary where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod  

Select @MemberArrears = Sum(ArEmpCont + ArEmprCont)  
from ContributionArrears where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod  
  
Select @MemberTransfers = Sum(EmpTransfer + EmprTransfer)  
from MemberTransfer where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod  
 
Select @MemberWithdrawal = Sum((b.EmpCBal + b.EmprCBal) - b.Deductions)  
from LumpAuthorization l  
     inner join Benefits b on l.schemeNo = b.schemeNo and l.MemberNo = b.MemberNo  
where l.schemeNo = @schemeNo and l.DatePrepared >= @StartDate and l.DatePrepared <= @EndDate  
  
if @MemberOpening is null select @MemberOpening =0.0  
if @MemberContributions is null select @MemberContributions =0.0  
if @MemberArrears is null select @MemberArrears =0.0  
if @MemberTransfers is null select @MemberTransfers =0.0  
if @MemberWithdrawal is null select @MemberWithdrawal =0.0  
  
declare EndLoanCsr Cursor for  
Select Distinct MemberNo from MemberCompanyLoan  
where schemeNo = @schemeNo and DateProcessed <= @LastYear  
Open EndLoanCsr  
Fetch from EndLoanCsr into @MemberNo  
while @@fetch_Status = 0  
begin  
   
   Exec Proc_Member_Loans_Details_AtDate @SCHEMENO,@MemberNo,@LastYear,@LoanIssued Out,@LoanRepaid Out,  
        @LoanBalance Out,@OtherDeductions Out  
   
   IF @LoanIssued IS NULL SELECT @LoanIssued = 0.0
   IF @LoanRepaid IS NULL SELECT @LoanRepaid = 0.0
   IF @LoanBalance IS NULL SELECT @LoanBalance = 0.0
   IF @OtherDeductions IS NULL SELECT @OtherDeductions = 0.0
  

   select @LoanOpening = @LoanOpening + @LoanBalance  
  

   Select @LoanBalance = 0.0,@LoanIssued  =0.0,@LoanRepaid=0.0,@OtherDeductions=0.0  
  
   Fetch next from EndLoanCsr into @MemberNo  
end  
Close EndLoanCsr  
Deallocate EndLoanCsr  
  
  
Select @LoanIssued = sum(Loan) from MemberCompanyLoan where schemeNo = @schemeNo and DateProcessed >= @StartDate and DateProcessed <= @EndDate  
Select @LoanRepaid = sum(Amount) from Member_Loan_Repayment where schemeNo = @schemeNo and DatePaid >= @StartDate and DatePaid <= @EndDate  
  
if @LoanIssued is null select @LoanIssued = 0.0  
if @LoanRepaid is null select @LoanRepaid = 0.0  
  
Select @LoanBalance = (@LoanOpening + @LoanIssued) - @LoanRepaid  
  
Select @MemberBalance = (@MemberOpening + @MemberContributions + @MemberArrears + @MemberTransfers) - @MemberWithdrawal  
  
Select @schemeBalance = @MemberBalance - @LoanBalance  
  
Insert Into #FundValueGEPF(SchemeName,Period,MemberOpening,MemberContributions,MemberArrears,  
                           MemberTransfers,LoanOpening,LoanIssued,LoanRepaid,LoanBalance,  
                           MemberWithdrawal,MemberBalance,SchemeBalance,MemberInflows,StartDate)  
                 Values(@SchemeName,@EndDate,@MemberOpening,@MemberContributions,@MemberArrears,  
                        @MemberTransfers,@LoanOpening,@LoanIssued,@LoanRepaid,@LoanBalance,  
                        @MemberWithdrawal,@MemberBalance,@SchemeBalance, @MemberOpening + @MemberContributions + @MemberArrears +  
                        @MemberTransfers,@StartDate)  
  
select * from #FundValueGEPF
go

