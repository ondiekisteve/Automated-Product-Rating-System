CREATE PROCEDURE [dbo].[Proc_Set_DC_DB]
@SchemeNo Int,
@MemberNo Int,
@ExitReason Int
--with Encryption
as

declare @DCBenefit float,@DBBenefit float,@Ben_Counter Int,@PayGreater smallint,@FundType smallint

select @FundType = FundTypeCode from Scheme where schemeCode = @schemeNo

IF @FundType <> 2
   BEGIN
   Update ConfigDeathInService set PayGreater = 0 where schemeNo = @schemeNo
   Update ConfigRetirement set PayGreater = 0 where schemeNo = @schemeNo
   Update ConfigMedical set PayGreater = 0 where schemeNo = @schemeNo
   Update ConfigWithdrawal set PayGreater = 0 where schemeNo = @schemeNo
   END  

if @ExitReason = 1
   select @PayGreater = PayGreater from ConfigDeathInService where schemeNo = @schemeNo 
else if @ExitReason > 1 and @ExitReason <= 4
   select @PayGreater = PayGreater from ConfigRetirement where schemeNo = @schemeNo 
else if @ExitReason = 5
   select @PayGreater = PayGreater from ConfigMedical where schemeNo = @schemeNo
else if @ExitReason > 5
   select @PayGreater = PayGreater from ConfigWithdrawal where schemeNo = @schemeNo

if @PayGreater < 2
   Update Members set DCDB = @PayGreater WHERE SchemeNo = @schemeNo and MemberNo = @MemberNo
else
   begin

	select @Ben_Counter = Max(Ben_Counter) from TBL_Benefits_DC
	where schemeNo = @schemeNo and MemberNo = @MemberNo

	select @DCBenefit = EE_Ben + AVC_Ben + EE_Transfer + Pre_EE + Pre_AVC + 
					   Er_Ben + AVCER_Ben + Er_Transfer + Pre_Er + Def_Ben
	from TBL_Benefits_DC
	where schemeNo = @schemeNo and MemberNo = @MemberNo and Ben_Counter = @Ben_Counter

	select @Ben_Counter = 0

	select @Ben_Counter = Max(Ben_Counter) from TBL_Benefits_DB
	where schemeNo = @schemeNo and MemberNo = @MemberNo

	select @DBBenefit = CashEquivalent from TBL_Benefits_DB
	where schemeNo = @schemeNo and MemberNo = @MemberNo and Ben_Counter = @Ben_Counter

    if @FundType = 2 /* DC */
       begin
       if @DCBenefit > @DBBenefit
          Update Members set DCDB = 0 WHERE SchemeNo = @schemeNo and MemberNo = @MemberNo
       else
          Update Members set DCDB = 1 WHERE SchemeNo = @schemeNo and MemberNo = @MemberNo
       end
    else
        Update Members set DCDB = 0 WHERE SchemeNo = @schemeNo and MemberNo = @MemberNo
  end
go

