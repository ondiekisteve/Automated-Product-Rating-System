--> CHECKED AND VERIFIED ON JAN 22ND 2002 by the SysTech Development Team        
/*        
This PROCEDURE DBO.is used to close the current scheme year and enter opening balances        
for the current year into the opening balances table        
*/        
        
CREATE PROCEDURE [dbo].[Proc_closeYear_single]        
@SCHEMENO Int,        
@MemberNo Int,        
@StartDate datetime,        
@EndDate datetime        
--with Encryption        
as        
        
set nocount on        
        
declare @totEmpCont float        
declare @totEmprCont float        
declare @totSpecialContr float        
declare @totVolContr float        
declare @yearClosed bit        
,@AcctPeriod int,@SoftClosed Bit,        
@PreEmpCont float,@PreEmprCont float,@PreAVC float,@Transfer float,@LockedIn float,        
@BalanceOfInt SmallInt,@MinPeriod Int,@Calc_Admin_Fees Int,@EmpInt float,@EmprInt float,@VolInt float,@SpecInt float,        
@EmpFeesReg float,@EmprFeesReg float,@EmpFeesUnReg float,@EmprFeesUnReg float,      
@DeferredAmt float,@DefInterest float,@UserName varchar(50), @maxPeriod int, @provorFinal int

select @UserName = user       
        
select @MinPeriod = Min(AcctPeriod), @maxPeriod =  MAX(AcctPeriod) from schemeYears where SchemeNo = @schemeNo        
        
Select @BalanceofInt = CalcBalanceofInterest,@Calc_Admin_Fees = Calc_Admin_Fees         
from ConfigYearEnd where SchemeNo = @schemeNo        
        
if @BalanceofInt is null select @BalanceofInt = 0        
if @Calc_Admin_Fees is null select @Calc_Admin_Fees = 0        
        
Select @AcctPeriod = AcctPeriod, @YearClosed = YearClosed,@SoftClosed = softClosed         
from schemeYears         
where SchemeNo = @schemeNo and  StartDate = @StartDate and Enddate = @EndDate        
        
if @MinPeriod < @AcctPeriod        
begin        
if @SoftClosed = 0        
begin        
  raiserror('The current Fiscal year has not been ''SOFT CLOSED''', 16, 1)        
  return        
end        
        
if @YearClosed = 1        
begin        
  raiserror('The current Fiscal year has already been CLOSED', 16, 1)        
  return        
end        

if @AcctPeriod > 0 and @AcctPeriod < @maxPeriod select @provorFinal =1
        
begin tran        
        
  select @totEmpCont = EmpCont,@totEmprCont= EmprCont,@totVolContr=VolContr,@totSpecialContr=SpecialContr,        
         @PreEmpCont = PreEmpCont,@PreEmprCont = PreEmprCont,@PreAvc = PreAVC,@Transfer = EmpTransfer,        
         @LockedIn = EmprTransfer,@EmpInt = EmpInt,@EmprInt = EmprInt,@VolInt = VolInt,@SpecInt = SpecInt,      
         @DeferredAmt = DeferredAmt,@DefInterest = DefInterest from        
         Benefits where SchemeNo = @SchemeNo and MemberNo = @MemberNo        
          
  if @PreEmpCont is null select @PreEmpCont = 0        
  if @PreEmprCont is null select @PreEmprCont = 0        
  if @totEmpCont is null select  @totEmpCont = 0        
  if @totEmprCont is null select @totEmprCont = 0        
  if @totVolContr is null select @totVolContr = 0        
  if @totSpecialContr  is null select @totSpecialContr = 0        
  if @PreAVC is null select @PreAVC = 0        
  if @Transfer  is null select @Transfer = 0        
  if @LockedIn  is null select @LockedIn = 0        
  if @DeferredAmt  is null select @DeferredAmt = 0        
  if @DefInterest  is null select @DefInterest = 0      
        
  if @EmpInt is null select @EmpInt = 0        
  if @EmprInt is null select @EmprInt = 0        
  if @VolInt is null select  @VolInt = 0        
  if @SpecInt is null select @SpecInt = 0        
        
  if @Calc_Admin_Fees = 1        
     Exec Proc_Calculate_Member_Fees_Split @schemeNo,@MemberNo,@EndDate,@EmpFeesReg Out,@EmprFeesReg Out,        
        @EmpFeesUnReg Out,@EmprFeesUnReg Out        
  else        
     select @EmpFeesReg  = 0,@EmprFeesReg = 0,@EmpFeesUnReg = 0,@EmprFeesUnReg=0        
        
  if Exists (Select MemberNo from MemberOpeningBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo        
             and AcctPeriod = @AcctPeriod and ProvOrFinal = @provorFinal)        
  update MemberOpeningBalances set        
  EmpCont = @totEmpCont,EmprCont = @totEmprCont,EmpVolCont = @totVolContr,EmprVolCont = @totSpecialContr,        
  PreEmpCont = @PreEmpCont,PreEmprCont = @PreEmprCont,PreAVC = @PreAVC,Transfer = @Transfer,LockedIn = @LockedIn,        
  EmpInt = @EmpInt,EmprInt = @EmprInt,VolInt = @VolInt,SpecInt = @SpecInt,        
  EmpFees = @EmpFeesReg,EmprFees = @EmprFeesReg,DeferredAmt = @DeferredAmt,DefInterest = @DefInterest,    
  ProvOrFinal = @provorFinal,PaidRatio = 0,DefPaidRatio = 0,Deferred = @DeferredAmt        
  where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod and ProvOrFinal = @provorFinal      
      
  else        
      
      Insert Into MemberOpeningBalances        
      (SchemeNo,MemberNo,schemeYear,EmpCont,EmpVolCont,EmprCont,EmprVolCont,SchemeMonth,AcctPeriod,PreEmpCont,PreEmprCont,Deficit,PreAvc,Transfer,LockedIn,        
       EmpInt,EmprInt,VolInt,SpecInt,EmpFees,EmprFees,DeferredAmt,DefInterest,ProvOrFinal,PaidRatio,DefPaidRatio,Deferred,  
       UserName,TransDate)        
      Values        
      (@schemeNo,@MemberNo,DatePart(Year,@EndDate),@totEmpCont,@totVolContr,@totEmprCont,@totSpecialContr,DatePart(Month,@EndDate),@AcctPeriod,@PreEmpCont,@PreEmprCont,0,@PreAVC,@Transfer,@LockedIn,        
       @EmpInt,@EmprInt,@VolInt,@SpecInt,@EmpFeesReg,@EmprFeesReg,@DeferredAmt,@DefInterest,@provorFinal,0,0,@DeferredAmt,@UserName,GetDate())        
  select @totEmpCont = 0,@totEmprCont= 0,@totVolContr=0,@totSpecialContr=0,@PreEmpCont=0,@PreEmprCont=0,        
  @PreAVC=0,@Transfer=0,@LockedIn=0        
         
  Exec Proc_closeYear_Un_Single  @schemeNo , @MemberNo, @StartDate, @EndDate        
        
  Update SchemeYears set SoftClosed = 1         
  where SchemeNo = @SchemeNo         
  and StartDate = @StartDate and EndDate = @EndDate        
        
commit tran        
        
end
go

