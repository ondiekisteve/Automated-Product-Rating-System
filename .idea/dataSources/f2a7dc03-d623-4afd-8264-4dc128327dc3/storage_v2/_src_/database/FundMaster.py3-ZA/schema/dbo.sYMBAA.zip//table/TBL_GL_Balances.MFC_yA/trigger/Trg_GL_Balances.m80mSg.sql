CREATE TRIGGER [dbo].[Trg_GL_Balances] ON [dbo].[TBL_GL_Balances]   
FOR INSERT
AS  
  
set nocount on  
  
declare @schemeCode int, @TransDate datetime, @CStatus smallint,@BalanceCode int,@BatchId int  
  
select @schemeCode = SchemeCode, @TransDate = PeriodEnding from Inserted

select @CStatus = PeriodClosed from AccountingPeriods 
where schemeNo = @schemeCode and EndDate = @TransDate

if @CStatus >= 1        
begin        
  raiserror('You cannot add a new record! The Accounting Period for the Transaction has already been closed',16,1)        
  rollBack Tran      
end
go

