CREATE FUNCTION [dbo].[fn_Direct_Pay_Details](@SCHEMENO Int,@PaymentNo Integer,@TransType int)       
returns @tbl_var table(SchemeNo Int not null,      
                       PaymentNo Int,      
                       InvoiceNo Int,      
                       InvoiceDesc varchar(255),      
                       InvoiceAmount float,      
                       FromOther Int,      
                       AccountCode varchar(30),      
                       Tran_Status Int      
                       )      
as       
begin      
      
     
      
if @TransType = 0 /* Direct Payment */      
begin      
Insert Into @tbl_var select SchemeNo,PaymentNo,InvoiceNo,InvoiceDesc,InvoiceAmount,      
                            FromOther,AccountCode,Tran_Status   
                     from DirectPaymentInvoice  
                     where SchemeNo = @schemeno  
                     and PaymentNo = @paymentno and Tran_Status <> -1  
                     order by InvoiceNo    
  
end      
else if @TransType = 1 /* BTF */      
begin      
    Insert Into @tbl_var select SchemeNo,PayCounter,PayCode,Particulars,Amount,      
                            0,AccountCode,Tran_Status   
                     from TBL_Dep_Pay_Det_Lines  
                     where SchemeNo = @schemeno  
                     and PayCounter = @paymentno   
                     order by PayCode     
     
end      
return      
end
go

