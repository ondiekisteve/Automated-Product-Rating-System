CREATE PROCEDURE [dbo].[AuthorizeVoucher]                      
@SCHEMENO Int,                      
@voucherNo int,                      
@username varchar(60),                      
@mode int,                      
@VoucherInc Int                      
--with Encryption                      
as                      
                      
declare @Checked int,@Authorised Int,@ImprestNo Int,@TransCode int,@BankTransfer Int,@TransDate datetime      
      
select @BankTransfer = 0  
  
select @TransDate = TransactionDate from PaymentVoucher                      
where SchemeNo = @schemeNo and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc       
      
if @Mode = 2     
   begin      
      select @BankTransfer = TrNoOut,@TransDate = TransactionDate from PaymentVoucher                      
      where SchemeNo = @schemeNo and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc      
      
      if @BankTransfer is null select @BankTransfer = 0      
   end      
                  
if @Mode = 1                      
   update PaymentVoucher set PreparedBy = @UserName,DatePrepared = GetDate()                      
   where SchemeNo = @schemeNo and VoucherNo = @VoucherNo                      
   and VoucherInc = @VoucherInc                      
else if @Mode = 2                      
   BEGIN                      
        select @Checked = Checked from PaymentVoucher where SchemeNo = @schemeNo and VoucherNo = @VoucherNo                      
        AND VoucherInc = @VoucherInc                      
                      
   IF (@Checked = 1)                      
      begin                      
                     
         raiserror('Voucher Number %d has already been Certified',16,1,@VoucherNo)                      
         rollback tran                      
      end                      
   else                      
      update PaymentVoucher set CheckedBy = @UserName, DateChecked = GetDate(), Checked = 1,post_Status = 1                      
      where SchemeNo = @schemeNo and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc                      
                      
   END                      
else if @Mode = 3                      
   begin                      
        select @Checked = Checked,@Authorised = Authorised,@ImprestNo = ImprestNo,@TransCode = TransactionCode                      
        from PaymentVoucher where SchemeNo = @schemeNo and VoucherNo = @VoucherNo                      
        AND VoucherInc = @VoucherInc                      
                              
        if (@Checked = 1)                      
           begin                      
               if (@Authorised = 1)                      
                  begin                      
                     raiserror('Voucher Number %d has already been Authorised',16,1,@VoucherNo)                      
                      
                     rollback tran                      
                  end                      
               else                    
                  begin                    
                  if ((@ImprestNo > 0) and (@TransCode <> 7))             
                     begin                     
                     update PaymentVoucher set AuthorisedBy = @UserName, DateAuthorised = GetDate(),                      
                     Authorised = 1,Posted = 1,post_Status = 3                      
                     where SchemeNo = @schemeNo and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc            
                                 
                     Update CashBook set ChequeDate = @TransDate,TransDate = @TransDate,Posted = 1                            
                     where SchemeCode = @schemeNo and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc                             
                          
                     Update SchemeGeneralLedger set glDate = @TransDate,Posted = 1                                
                     where SchemeCode = @schemeNo and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc                                   end                     
                  else                    
                     update PaymentVoucher set AuthorisedBy = @UserName, DateAuthorised = GetDate(),                      
                     Authorised = 1,post_Status = 2                      
                     where SchemeNo = @schemeNo and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc                    
                  end                     
           end                      
        else                      
           begin                      
               raiserror('Voucher Number %d cannot be Authorised as it has not been Certified',16,1, @VoucherNo)                      
                      
               return                      
           end                      
   end
go

