CREATE FUNCTION [dbo].[fn_Max_AcctPeriod](@SchemeNo Int,@MemberNo Int)                             
returns Integer                 
as                  
begin     
 declare @AcctPeriod Int     
 
 select @AcctPeriod = Max(AcctPeriod) from v_Contributions 
 where SchemeNo = @schemeNo and MemberNo = @MemberNo   
                   
 RETURN(@AcctPeriod)                  
end
go

