CREATE VIEW [dbo].[DeadPensionerGrid]    
--with encryption    
AS    
SELECT m.schemeNo, m.memberno,m.PayrollNo,m.idnumber, m.SName,    
             (m.FName + ' ' + m.ONames) AS OtherNames, p.PayType, p.PenNo,pd.BenPayType,pd.ReverseLiab,
             pd.ArrPosted   
FROM pensioner p    
           inner Join members m on p.SchemeNo = m.SchemeNo and p.MemberNo = m.MemberNo    
           inner Join PenDeathClaim pd on p.SchemeNo = pd.SchemeNo and p.MemberNo = pd.MemberNo    
WHERE p.alive = 0
go

