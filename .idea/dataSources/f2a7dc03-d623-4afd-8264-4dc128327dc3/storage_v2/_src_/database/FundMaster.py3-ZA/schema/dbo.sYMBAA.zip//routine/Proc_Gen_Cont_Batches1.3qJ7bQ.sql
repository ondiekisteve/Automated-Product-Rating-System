CREATE PROCEDURE [dbo].[Proc_Gen_Cont_Batches1]                            
@schemeNo Int,                            
@BatchMonth Int,                            
@BatchYear Int,                            
@TransMode Int,
@SponsorCode Int                            
--with Encryption                            
as                            
declare @LastMonth Int,@LastYear Int,@TotalEmp float,@TotalEmpr float,@SponsorRef varchar(4),@Contributors Int,                            
@SponsorName varchar(100),@TotalVol float,@DebtorCode Int,@Receipt Int,@batchDate Datetime,@MonthName varchar(40),                            
@BatchNo Int,@MaxTransNo Int,@EmpDebitAcc varchar(30),@EmpCreditAcc varchar(30),                            
@EmprDebitAcc varchar(30),@EmprCreditAcc varchar(30),@AvcDebitAcc varchar(30),@AvcCreditAcc varchar(30),                            
@Descr varchar(120),@schemeMode smallInt,@CurrCode Int,@CurrRate decimal(20,6)                 
                
select @schemeMode = schemeMode,@CurrCode = CurrCode from Scheme where schemeCode = @schemeNo                 
                
if @schemeMode is null select @schemeMode = 0        
select @CurrRate = 1.0000                          
                            
select @EmpDebitAcc = EmpDebitAcc,@EmpCreditAcc=EmpCreditAcc,@EmprDebitAcc=EmprDebitAcc,                            
@EmprCreditAcc=EmprCreditAcc,@AvcDebitAcc=AvcDebitAcc,@AvcCreditAcc=AvcCreditAcc                             
from Pension_Setup where schemeNo = @schemeNo          
          
if @EmpDebitAcc is null          
begin          
   raiserror('The Debtors Account for Employee Contributions had not been specified',16,1)          
   return          
end          
else if @EmpCreditAcc is null           
begin          
   raiserror('The Income Account for Employee Contributions had not been specified',16,1)          
   return          
end           
else if @EmprDebitAcc is null          
begin          
   raiserror('The Debtors Account for Employer Contributions had not been specified',16,1)          
   return          
end          
else if @EmprCreditAcc is null           
begin          
   raiserror('The Income Account for Employer Contributions had not been specified',16,1)          
   return          
end           
else if @AvcDebitAcc is null          
begin          
   raiserror('The Debtors Account for Voluntary Contributions had not been specified',16,1)          
   return          
end          
else if @AvcCreditAcc is null           
begin          
   raiserror('The Income Account for Voluntary Contributions had not been specified',16,1)          
   return          
end          
else          
begin                           
                            
select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeNo                              
if @BatchNo is null select @BatchNo = 0                              
select @BatchNo = @BatchNo + 1                             
                            
Exec GetMaxGLJvTransNo_Out @SchemeNo,0,@MaxTransNo Out                             
                            
Exec GetFirstDate @BatchMonth,@BatchYear,@batchDate oUT                             
                            
Exec GetMonthName @BatchMonth,@MonthName Out                            
                            
select @MonthName = @MonthName +', '+cast(@BatchYear as varchar(4))                             
                                        
if @BatchMonth = 1                            
   select @LastMonth = 12,@LastYear = @BatchYear - 1                            
else                            
   select @LastMonth = @BatchMonth - 1,@LastYear = @BatchYear                            
                            
SELECT @Contributors = Count(*) from BatchEntry where schemeNo >= @schemeNo                        
and BatchMonth = @LastMonth and BatchYear = @LastYear                            
                            
if @Contributors is null select @Contributors = 0                            
                  
if @TransMode = 0                           
   select @TotalEmp = sum(TotalEmp),@TotalEmpr = sum(TotalEmpr),@TotalVol = sum(TotalVol + TotalSpecial)                             
   from Batches where schemeNo = @schemeNo                            
   and BatchMonth = @LastMonth and BatchYear = @LastYear                       
else if ((@TransMode = 1) and (@SchemeMode = 1))                          
   select @TotalEmp = sum(EmpCOnt),@TotalEmpr = sum(EmprCont),@TotalVol = sum(avc)             
   from TBL_ExpectedBatches where schemeNo = @schemeNo                           
   and BatchMonth = @BatchMonth and BatchYear = @BatchYear and SponsorCode = @SponsorCode 
else if ((@TransMode = 1) and (@SchemeMode = 0))                          
   select @TotalEmp = sum(EmpCOnt),@TotalEmpr = sum(EmprCont),@TotalVol = sum(avc)             
   from TBL_ExpectedBatches where schemeNo = @schemeNo                           
   and BatchMonth = @BatchMonth and BatchYear = @BatchYear                 
                         
if @TotalEmp is null select @TotalEmp = 0.0                         
if @TotalEmpr is null select @TotalEmpr = 0.0                            
if @TotalVol is null select @TotalVol = 0.0                          
                
if @schemeMode = 0                          
   select @SponsorName = SchemeName,@SponsorRef = cast(schemeCode as varchar(20)),                
   @SponsorCode=SchemeCode from Scheme where schemeCode = @schemeNo                 
else if ((@SchemeMode = 1) and (@SponsorCode > 0))                
   select @SponsorName = SponsorName,@SponsorRef = SponsorRef,                
   @SponsorCode=SponsorCode from Sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode                           
else if ((@SchemeMode = 1) and (@SponsorCode = 0))                
   select @SponsorName = SponsorName,@SponsorRef = SponsorRef,                
   @SponsorCode=SponsorCode from Sponsor where schemeNo = @schemeNo                           

                                      
if @TransMode = 0                            
   Exec Proc_Import_Expected_Cont @SCHEMENO,@BatchMonth,@BatchYear,@SponsorRef,@TotalEmp,@TotalEmpr,                                  
   @TotalVol,0.0,@Contributors,@SponsorName                              
else if @TransMode = 1                           
begin                            
  if Exists(select Posted from TBL_ExpectedBatches  WHERE schemeNo = @schemeNo                             
            and BatchMonth = @BatchMonth and BatchYear = @BatchYear and Posted = 1 and SponsorCode = @SponsorCode)                            
     begin                          
       Raiserror('Expected Contributions for %s have already been posted to the General Ledger',16,1,@MonthName)                            
       return                            
     end                      
  else                            
     begin              
       if @schemeMode = 0                            
          Select @SponsorName = SchemeName from Scheme where SchemeCode = @schemeNo              
       else              
          select @SponsorName = SponsorName from Sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode                                       
                                  
    /*                                          
     CHECK IF sponsor EXISTS IN DEBTORS REGISTER                                          
    */                                          
       if Exists ( select * from DebtorsRegister where DebtorType = 4                            
                   and Debtor = @SponsorName and SchemeNo = @schemeNo)                                      
          begin                                          
              select @DebtorCode = DebtorCode from DebtorsRegister where DebtorType = 4                                          
              and Debtor = @SponsorName and SchemeNo = @schemeNo                                      
          end                                           
       else                                            
           begin                                          
               Insert Into DebtorsRegister (SchemeNo,DebtorType,Debtor,DebtorStatus)                                          
               Values(@SchemeNo,4,@sponsorName,0)                                          
                                          
               select @DebtorCode = DebtorCode from DebtorsRegister where DebtorType = 4                                         
                      and Debtor = @SponsorName and SchemeNo = @schemeNo                                         
          end                                                                                   
             select @Receipt = Max(Receipt) from Receipts where SchemeNo = @schemeNo                                         
                                          
             if @Receipt is null select @Receipt = 0                                          
                                          
             select @Receipt = @Receipt + 1                                          
                                         
             select @Descr = 'Expected Contributions for '+@SponsorName +' for '+@MonthName                                          
             Insert into Receipts (SchemeNo,Receipt,ReceiptDate,Description,Amount,DebtorCode,PropCode)                                          
             Values (@SchemeNo,@Receipt,@BatchDate,@Descr,@TotalEmp + @TotalEmpr + @TotalVol,                            
             @DebtorCode,@SponsorCode)                            
                                          
             select @Descr=' '                             
             select @Descr = 'Expected Members Contributions for '+@SponsorName +' for '+@MonthName                                                                     
             Insert into ReceiptsInvoice(SchemeNo,ReceiptNo,Particulars,Quantity,UnitPrice,FromOther)                                          
             Values(@schemeNo,@Receipt,@Descr,1,@TotalEmp,1)                             
                                         
             select @Descr=' '                             
             select @Descr = 'Expected Employers Contributions for '+@SponsorName +' for '+@MonthName                            
             Insert into ReceiptsInvoice(SchemeNo,ReceiptNo,Particulars,Quantity,UnitPrice,FromOther)                                          
             Values(@schemeNo,@Receipt,@Descr,1,@TotalEmpr,1)                                   
                                         
             select @Descr=' '                             
             select @Descr = 'Expected Voluntary Contributions for '+@SponsorName +' for '+@MonthName                                      
             IF @totalVol > 0                                       
               Insert into ReceiptsInvoice(SchemeNo,ReceiptNo,Particulars,Quantity,UnitPrice,FromOther)                                          
               Values(@schemeNo,@Receipt,@Descr,1,@totalVol,1)                                         
                                        
             /* Post Contributions Receivable */                            
             /*Members*/                            
             select @Descr=' '                             
             select @Descr = 'Expected Members Contributions for '+@SponsorName +' for '+@MonthName                                         
             Exec PostLedgerDebits_RecPay @SchemeNo,@EmpDebitAcc,@Receipt,@TotalEmp,@BatchMonth,@BatchYear,                                          
             @Descr,0,@BatchDate,@MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,200,8                                          
                                          
             Exec PostLedgerCredits_RecPay @SchemeNo,@EmpCreditAcc,@Receipt,@TotalEmp,@BatchMonth,@BatchYear,                   
             @Descr,0,@BatchDate,@MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,200,8                             
                            
             /*Sponsors*/                             
             select @Descr=' '                             
             select @Descr = 'Expected Employers Contributions for '+@SponsorName +' for '+@MonthName                                       
             Exec PostLedgerDebits_RecPay @SchemeNo,@EmprDebitAcc,@Receipt,@TotalEmpr,@BatchMonth,@BatchYear,                     
             @Descr,0,@BatchDate,@MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,200,8                                           
                                          
             Exec PostLedgerCredits_RecPay @SchemeNo,@EmprCreditAcc,@Receipt,@TotalEmpr,@BatchMonth,@BatchYear,         
             @Descr,0,@BatchDate,@MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,200,8                             
                                                                
             /* FOR AVC - Post Contributions Receivable */                                       
             IF @TotalVol > 0                                
             BEGIN                  
             select @Descr=' '                             
             select @Descr = 'Expected AVC Contributions for '+@SponsorName +' for '+@MonthName                                      
             Exec PostLedgerDebits_RecPay @SchemeNo,@AvcDebitAcc,@Receipt,@TotalVol,@BatchMonth,@BatchYear,                                          
             @Descr,0,@BatchDate,@MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,200,8                                    
                                          
             Exec PostLedgerCredits_RecPay @SchemeNo,@AvcCreditAcc,@Receipt,@TotalVol,@BatchMonth,@BatchYear,                                          
             @Descr,0,@BatchDate,@MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,200,8                            
              
             END                                
     UPDATE RECEIPTS SET Posted = 1 WHERE schemeNo = @schemeNo and Receipt = @Receipt                             
     
     if @SchemeMode = 1                       
        UPDATE TBL_ExpectedBatches SET Posted = 1 
        WHERE schemeNo = @schemeNo and BatchMonth = @BatchMonth and BatchYear = @BatchYear and SponsorCode = @SponsorCode                             
     else if @SchemeMode = 0                       
        UPDATE TBL_ExpectedBatches SET Posted = 1 
        WHERE schemeNo = @schemeNo and BatchMonth = @BatchMonth and BatchYear = @BatchYear                             
                             
   end                                          
 end                
end
go

