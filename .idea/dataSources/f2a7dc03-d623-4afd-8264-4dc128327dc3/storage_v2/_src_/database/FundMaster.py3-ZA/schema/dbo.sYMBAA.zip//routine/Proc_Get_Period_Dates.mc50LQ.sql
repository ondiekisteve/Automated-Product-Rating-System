CREATE PROCEDURE [dbo].[Proc_Get_Period_Dates]
@schemeNo Int,
@TransDate datetime
--with Encryption 
as
select StartDate,EndDate from schemeYears where schemeNo = @schemeNo and startDate <= @TransDate
and endDate >= @TransDate
go

