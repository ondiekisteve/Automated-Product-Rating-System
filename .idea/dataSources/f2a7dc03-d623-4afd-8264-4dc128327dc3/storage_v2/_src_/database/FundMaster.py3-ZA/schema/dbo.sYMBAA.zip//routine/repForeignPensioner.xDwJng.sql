CREATE PROCEDURE [dbo].[repForeignPensioner]
@SCHEMENO Int
--with Encryption
as
select
m.SchemeNo,
m.MemberNo,
m.IDNumber,
m.DOexit,
m.DJE,
m.DJPenS, 
UPPER(m.Sname) + ' , ' + (m.fname) + '  ' + (m.onames) as FullName,
case m.Sex
  when 'M' then 'Male'
  when 'F' then 'Female'
else
  'Unknown'
end as MembSex,
(b.empcont + b.emprcont + b.specialContr + b.volContr) as totalBenefits, reasonDesc, p.PenNo,
p.accrpen as totalpension, p.comlumgwtax as commutation, (p.accrpen - p.comlumgwtax) as purchasePrice, (p.Monpension * 12) as AnnualPension, p.penNo
from Members m
       inner Join  pensioner p on m.schemeNo = p.schemeNo and m.MemberNo = p.MemberNo and p.Foreigner = 1
       inner Join  benefits b on m.SchemeNo = b.schemeNo and m.MemberNo = b.MemberNo
       inner Join  reasonforexit r on m.ReasonforExit = r.ReasonCode
where (m.SchemeNo = @SchemeNo)
        
order by m.MemberNo
go

