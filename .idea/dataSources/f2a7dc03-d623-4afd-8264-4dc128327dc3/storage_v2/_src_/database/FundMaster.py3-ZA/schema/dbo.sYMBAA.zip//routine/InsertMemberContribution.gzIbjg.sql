CREATE PROCEDURE [dbo].[InsertMemberContribution]
--with Encryption
as
declare @memberNo int,@EmpCont float,@EmprCont float,@DatePaid datetime,
@ContrMonth Int,@ContrYear Int,@AcctPeriod int,@VolCont float

select @DatePaid = 'Nov 10,2002',@ContrMonth = 11, @ContrYear = 2002,@AcctPeriod = 1

declare acsr cursor for
Select MemberNo, EmpCont,EmprCont,avc
from Contribution
order by MemberNo

open acsr
fetch from acsr into @MemberNo,@EmpCont,@EmprCont,@VolCont

while @@fetch_Status = 0
begin
  if @empCont is null select @EmpCont = 0
  if @EmprCont is null select @EmprCont = 0
  if @VolCont is null select @VolCont = 0
  
 
  Insert Into COntributionssummary
  (SchemeNo,MemberNo,ContrMonth,ContrYear,DatePaid,AcctPeriod,Salary,EmpCont,EmprCont,SchemeYear, VolContr)
  Values
  ('1203',@MemberNo,@ContrMonth,@ContrYear,@DatePaid,@AcctPeriod,1,@EmpCont,@EmprCont,@ContrYear,@VolCont)

  select @EmpCont = 0,@EmprCont = 0
  fetch next from acsr into @MemberNo,@EmpCont,@EmprCont,@VolCont
end
Close Acsr
Deallocate Acsr
go

