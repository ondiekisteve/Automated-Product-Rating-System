CREATE FUNCTION [dbo].[fn_Remove_Seconds](@TransDate datetime)                             
returns datetime               
as                  
begin     
 
Declare @Month Int,@Year Int,@Day Int,@NewDate Varchar(15),@iDay Varchar(2),@iMonth varchar(2),
@ConvertDate date  
  
select @Month = DatePart(Month,@TransDate),@Day = Datepart(Day,@TransDate),@Year = DatePart(Year,@TransDate)  
  
select @iDay = cast(@Day as Varchar(2)),@iMonth = cast(@Month as Varchar(2))  

select @ConvertDate = Cast(cast(@TransDate AS DATE) as datetime) 
   

RETURN(@ConvertDate)                  
end
go

