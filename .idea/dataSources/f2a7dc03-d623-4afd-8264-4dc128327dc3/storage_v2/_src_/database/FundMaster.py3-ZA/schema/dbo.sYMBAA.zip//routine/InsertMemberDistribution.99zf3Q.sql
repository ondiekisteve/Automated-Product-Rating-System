CREATE PROCEDURE [dbo].[InsertMemberDistribution]
@SCHEMENO Int,
@curMonth int,
@curYear int,
@SchemeDistribution float
--with Encryption
as

declare @SchemeBalance float
select @SchemeBalance = 0

exec TotalOpeningBalance @schemeNo, @SchemeBalance out

SELECT @SCHEMEBALANCE

Declare @MemberBalance float
Declare @DistrAmount float
declare @EmployeeBalance float
declare @EmployerBalance float
declare @EmpInterest float
declare @EmprInterest float

select @MemberBalance = 0
select @DistrAmount = 0
select  @EmployeeBalance = 0
select @EmployerBalance = 0
select @EmpInterest  = 0
select @EmprInterest  = 0


declare @MemberNo int

Declare MembCsr cursor for

select schemeNo, MemberNo 
from Members 
where SchemeNo = @schemeNo and ReasonforExit = 0

Open MembCsr 

fetch from MembCsr into @schemeNo, @MemberNo

while @@fetch_status = 0
begin
  Exec TotalMemberOpeningBalance @schemeNo, @MemberNo, @MemberBalance out, @EmployeeBalance out, @EmployerBalance out
 
  if @MemberBalance is null
    begin
          select @DistrAmount = 0
          select @EmpInterest = 0
          select @EmprInterest = 0
    end
 else
    begin
          select @DistrAmount = (@MemberBalance/@SchemeBalance) * @SchemeDistribution

           select @EmpInterest = (@EmployeeBalance/ (@EmployeeBalance + @EmployerBalance)) * @DistrAmount

            select @EmprInterest = (@EmployerBalance/ (@EmployeeBalance + @EmployerBalance)) * @DistrAmount
  
    end

  Insert into MemberDistribution (schemeNo, MemberNo, curMonth, curYear, DistrAmount, DistrEmp, DistrEmpr)
               values (@schemeNo, @MemberNo, @curMonth, @curYear, @DistrAmount, @EmpInterest, @EmprInterest)

  
  select @MemberBalance = 0
  select @DistrAmount = 0
  select  @EmployeeBalance = 0
  select @EmployerBalance = 0
  select @EmpInterest  = 0
  select @EmprInterest  = 0

fetch next from MembCsr into @schemeNo, @MemberNo
end

Close MembCsr
Deallocate MembCsr
go

