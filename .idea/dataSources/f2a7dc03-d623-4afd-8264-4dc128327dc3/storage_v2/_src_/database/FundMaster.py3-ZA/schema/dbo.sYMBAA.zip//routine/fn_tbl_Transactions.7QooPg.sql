










CREATE FUNCTION fn_tbl_Transactions(@Trans_Group_Id_FK Integer)
returns table
as
return
 select * from tbl_Transactions
 where Trans_Group_Id_FK = @Trans_Group_Id_FK


go

