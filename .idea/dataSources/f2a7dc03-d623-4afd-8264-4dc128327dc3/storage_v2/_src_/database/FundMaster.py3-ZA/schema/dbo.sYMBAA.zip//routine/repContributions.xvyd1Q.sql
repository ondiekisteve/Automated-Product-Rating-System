CREATE PROCEDURE [dbo].[repContributions]
@SCHEMENO Int,
@memberno int
--with Encryption
 AS
SELECT
SchemeNo,
MemberNo,
Sum(EmpCont) AS EmpCont,
Sum(EmprCont) AS EmprCont,
Sum(SpecialContr) AS SpecialContr,
Sum(VolContr) AS VolContr,
Sum(NssfE) AS NssfE,
Sum(Nssf) AS NssF
FROM Contributionssummary
WHERE (MemberNo = @memberno)  and
               ( schemeNo = @schemeNo)
GROUP BY SchemeNo, MemberNo
order by Memberno
go

