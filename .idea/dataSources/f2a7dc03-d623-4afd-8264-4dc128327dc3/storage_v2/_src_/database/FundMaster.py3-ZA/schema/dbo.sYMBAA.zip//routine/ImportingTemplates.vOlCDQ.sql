/*created on 08 March 2008 - Lusaka*/                        
                        
CREATE PROCEDURE [dbo].[ImportingTemplates]                        
@TemplateMode int,    
@SchemeNo Int                        
as                        
                                
If @TemplateMode = 0 /*Contributions Template*/                        
BEGIN                        
if object_id('tempdb..#Contributions') is not null                                
   drop Table #Contributions                                
                                
create table #Contributions                                
(                                
 [Counter] [int] IDENTITY(1,1) primary key,                                
 [MemberNo] [INT],                                
 [FullName] [varchar](100),                                
 [SurName] [varchar](30),                              
 [FirstName] [varchar](30),                              
 [OtherNames] [varchar](30),                            
 [Grade][varchar](30),                        
 [Salary][float],                                
 [EE][float],                                
 [ER][float],                                
 [AVC][float],                                
 [AVCER][float],                                
 [DEFICIT][float],                        
 [PayrollNo] [varchar](20),            
 [IDNumber][varchar](20),                                        
 [NSSF][float],                                
 [NSSFEmployer][float],
 [ActiveStatus] [varchar](20)                                                 
)                         
                        
insert into #Contributions (MemberNo,FullName,SurName,FirstName,OtherNames,Grade,Salary,EE,ER,AVC,AVCER,DEFICIT,                        
     PayrollNo,IDNumber,NSSF,NSSFEmployer,ActiveStatus)                        
  select MemberNo,FullName,SurName,FirstName,OtherNames,Field11,Field1,Field2,Field3,Field4,Field5,                        
   Field6,PayrollNo,IDNumber,Field7,Field8,ActiveStatus from PayrollNos where SchemeNo = @SchemeNo                
  ORDER BY MATCHCODE                 
                        
   select * from #Contributions order by counter                      
END                    
If @TemplateMode = 1 /*Contribution Arrears*/                        
BEGIN                        
if object_id('tempdb..#ContrArrears') is not null                                
   drop Table #ContrArrears                                
                                
create table #ContrArrears                                
(                                
 [Counter] [int] IDENTITY(1,1) primary key,                                
 [MemberNo] [INT],                                
 [EE][float],                                
 [ER][float],                                
 [AVC][float],                                
 [AVCER][float],                                
 [AUGMENTARY][float],                        
 [SALARY] [float],
 [ActiveStatus] [varchar](20)                                                 
)                        
                        
insert into #ContrArrears (MemberNo,EE,ER,AVC,AVCER,AUGMENTARY,SALARY,ActiveStatus)                        
  select MemberNo,Field1,Field2,Field3,Field4,Field5,Field6,ActiveStatus from PayrollNos where SchemeNo = @schemeNo               
  ORDER BY MATCHCODE                    
                       
  select * from #ContrArrears order by counter                      
END                      
                    
If @TemplateMode = 2 /*Opening Balances Template*/                        
BEGIN                        
if object_id('tempdb..#OpeningBal') is not null                                
   drop Table #OpeningBal                                
                                
create table #OpeningBal                                
(                                
 [Counter] [int] IDENTITY(1,1) primary key,                                
 [MemberNo] [INT],                                
 [EEBAL] [float],                                
 [ERBAL] [float],                              
 [AVCBAL] [float],     
 [AVCERBAL] [float],                            
 [PREEEBAL][float](30),                        
 [PREERBAL][float],                                
 [PREAVC][float],                                
 [DEFICITBAL][float],                                
 [TRANSFER][float],                                
 [LOCKEDIN][float],                        
 [UNLOCKDATE] [Datetime],
 [ActiveStatus] [varchar](20)                                                
)                         
                        
insert into #OpeningBal (MemberNo,EEBAL,ERBAL,AVCBAL,AVCERBAL,PREEEBAL,PREERBAL,PREAVC,DEFICITBAL,TRANSFER,LOCKEDIN,UNLOCKDATE,ActiveStatus)                        
  select MemberNo,Field1,Field2,Field3,Field4,Field5,Field6,Field7,Field8,Field9,Field10,Field18,ActiveStatus               
  from PayrollNos where SchemeNo = @schemeNo               
  ORDER BY MATCHCODE                     
                        
   select * from #OpeningBal order by counter                      
END                    
                 
If @TemplateMode = 3 /*Transfer Values Template*/                        
BEGIN                        
if object_id('tempdb..#TransferValues') is not null                                
   drop Table #TransferValues                                
                                
create table #TransferValues                                
(                                
 [Counter] [int] IDENTITY(1,1) primary key,                                
 [MemberNo] [INT],                                
 [EETransfer] [float],                                
 [ERTransfer] [float],                              
 [AVCTransfer] [float],                              
 [AVCERTransfer] [float],                            
 [Deferred][float],                        
 [PastService][INT],
 [ActiveStatus] [varchar](20)                                                
)                         
                        
insert into #TransferValues (MemberNo,EETransfer,ERTransfer,AVCTransfer,AVCERTransfer,Deferred,PastService,ActiveStatus)                        
  select MemberNo,Field1,Field2,Field3,Field4,Field5,Field6,ActiveStatus               
  from PayrollNos where SchemeNo = @schemeNo               
  ORDER BY MATCHCODE                     
                        
   select * from #TransferValues order by counter                      
END                    
                    
If @TemplateMode = 4 /*Benefits Template*/                        
BEGIN                        
if object_id('tempdb..#Benefits') is not null                                
   drop Table #Benefits                                
                                
create table #Benefits                                
(                                
 [Counter] [int] IDENTITY(1,1) primary key,                                
 [MemberNo] [INT],                                
 [PayrollNo] [varchar](20),                                
 [EmployeeBalance] [float],                              
 [EmployerBalance] [float],                              
 [AVCBalance] [float],                            
 [AVCERBalance][float],                        
 [EmployeeFrozen][float],                                
 [EmployerFrozen][float],                                
 [AVCFrozen][float],                                
 [Vesting][float],                                
 [DOExit][Datetime],                                
 [DOCalculation][Datetime],                        
 [ExitReason] [int],                                        
 [ChequeNo][varchar](20),                                
 [PaymentDate][Datetime],
 [ActiveStatus] [varchar](20)                                                 
)                         
                        
insert into #Benefits (MemberNo,PayrollNo,EmployeeBalance,EmployerBalance,AVCBalance,AVCERBalance,EmployeeFrozen,                    
  EmployerFrozen,AVCFrozen,Vesting,DOExit,DOCalculation,ExitReason,ChequeNo,PaymentDate,ActiveStatus)                        
  select MemberNo,PayrollNo,Field1,Field2,Field3,Field4,Field5,Field6,Field7,Field8,Field18,Field19,                    
  Field9,Field11,Field20,ActiveStatus               
  from PayrollNos where SchemeNo = @schemeNo               
  ORDER BY MATCHCODE                     
                        
   select * from #Benefits order by counter                      
END                    
                    
If @TemplateMode = 5 /*Individual Contributions Template*/                        
BEGIN                        
if object_id('tempdb..#IndividualContr') is not null                                
   drop Table #IndividualContr                                
                                
create table #IndividualContr                                
(                                
 [Counter] [int] IDENTITY(1,1) primary key,             
 [MemberNo] [INT],                                
 [EE] [float],                                
 [ER] [float],        
 [AVC] [float],                                
 [AVCER] [float],                              
 [MONTH] [INT],                              
 [YEAR] [INT],
 [ActiveStatus] [varchar](20)                                                 
)                         
        
insert into #IndividualContr (MemberNo,EE,ER,AVC,AVCER,[MONTH],[YEAR],ActiveStatus)                        
  select MemberNo,Field1,Field2,Field3,Field4,Field5,Field6,ActiveStatus               
  from PayrollNos where SchemeNo = @schemeNo                 
  ORDER BY MATCHCODE                   
                        
   select * from #IndividualContr order by counter                      
END                    
                    
If @TemplateMode = 6 /*Member Updates Template*/                        
BEGIN             
if object_id('tempdb..#MemberUpdates') is not null                                
   drop Table #MemberUpdates                                
                                
create table #MemberUpdates                                
(                                
 [Counter] [int] IDENTITY(1,1) primary key,                                
 [MemberNo] [INT],                                
 [SurName] [varchar](30),                             
 [FirstName] [varchar](30),                              
 [OtherNames] [varchar](30),                            
 [Gender] [varchar](30),                  
 [DoBirth][Datetime],                                
 [DoEmployment][Datetime],                  
 [DoScheme][Datetime],                  
 [PayrollNo] [varchar](20),                        
 [IDNumber] [varchar](20),                                
 [PinNumber] [varchar](20),                                
 [Address] [varchar](20),                                
 [Town] [varchar](20),                                
 [Department] [varchar](20),
 [ActiveStatus] [varchar](20)                                                 
)                         
                        
insert into #MemberUpdates (MemberNo,SurName,FirstName,OtherNames,Gender,DoBirth,DoEmployment,DoScheme,                        
     PayrollNo,IDNumber,PinNumber,Address,Town,Department,ActiveStatus)                        
  select MemberNo,SurName,FirstName,OtherNames,Field11,Field18,Field19,Field20,PayrollNo,Field13,                        
   Field14,Field15,Field16,Field17,ActiveStatus               
   from PayrollNos where SchemeNo = @schemeNo               
   ORDER BY MATCHCODE                     
                        
   select * from #MemberUpdates order by counter                      
END
go

