CREATE PROCEDURE [dbo].[repContSummary]    
@SCHEMENO Int,    
@startDate datetime,    
@endDate datetime    
--with Encryption    
 AS    
    
if object_id('tempdb..##ContSummary') is null    
    
begin    
create table #ContSummary    
(     
   [Counter][Int] identity(1,1),    
   [schemeNo][varchar](15) not null,    
   [schemeName] [varchar] (120) not null,    
   [startdate][Datetime]  not null,    
   [Enddate][Datetime] not null,    
   [totEmp][float] not null,    
   [totEmpr][float] not null,    
   [totNssf][float] not null,    
   [totNSSFe][float] not null,    
   [totVol][float] not null,    
   [totSpecial][float] not null,    
   [totAll][float] not null,    
   [AugCont][float],    
   [SponsorName][varchar](100),  
   [PoolName][varchar](120)    
constraint pk_membList primary key (Counter)    
)    
    
end    
    
declare @schemeName varchar(120)    
declare @totEmp float    
declare @totEmpr float    
declare @totnssf float    
declare @totNSSFe float    
declare @totVol float    
declare @totSpecial float    
declare @totAll float,@AugCont float,  
 @SchemeMode Int,@SponsorName varchar(100),  
 @PooledInvestment smallInt,@SchemeCode Int,    
 @PoolName varchar(120),@FundType varchar(2)    
  
select @PoolName = schemeName,@SchemeMode = schemeMode,@PooledInvestment = PooledInvestment,@FundType = FundType    
 from scheme where schemeCode = @schemeNo    
  
if @FundType = 'PF'    
BEGIN    
Declare ContSummaryCsr cursor for    
select schemeCode,schemeName,SchemeMode from Scheme    
where PooledInvestment = 1 and InvestmentScheme = @schemeNo  
    
Open ContSummaryCsr    
Fetch from ContSummaryCsr into @schemeCode,@schemeName,@SchemeMode    
while @@fetch_Status = 0    
begin    
if @schemeMode is null select @schemeMode = 0  
    
if @SchemeMode = 0    
declare ContrCsr cursor for    
SELECT schemeno, sum (EmpCont + ExcessEmpCont) as totemp,    
sum (EmprCont + ExcessEmprcont) as totempr,    
sum(NSSF) as totnssf,    
sum(NssfE) as totnssfe,    
sum(VolContr + ExcessVolContr) as totvol ,    
sum (SpecialContr + ExcessSpecial) as totspecial, sum(AugCont),    
sum (EmpCont + EmprCont + NSSF + NssfE + VolContr+  SpecialContr + ExcessEmprCont + ExcessEmpCont + ExcessVolContr + ExcessSpecial + ExcessSpecial + AugCont) as totall,    
''    
FROM Contributionssummary    
WHERE (schemeNo = @schemeCode)  and    
              ((Datepaid >= @startDate)  and    
              (Datepaid<=@endDate))          
group by schemeno    
else if @schemeMode = 1    
declare ContrCsr cursor for    
SELECT c.schemeno, sum (c.EmpCont + c.ExcessEmpCont) as totemp,    
sum (c.EmprCont + c.ExcessEmprcont) as totempr,    
sum(c.NSSF) as totnssf,    
sum(c.NssfE) as totnssfe,    
sum(c.VolContr + c.ExcessVolContr) as totvol ,    
sum (c.SpecialContr + c.ExcessSpecial) as totspecial, sum(AugCont),    
sum (c.EmpCont + c.EmprCont + c.NSSF + c.NssfE + c.VolContr+  c.SpecialContr + c.ExcessEmprCont + c.ExcessEmpCont + c.ExcessVolContr + c.ExcessSpecial + c.ExcessSpecial + c.AugCont) as totall,    
s.SponsorName    
FROM Members m    
     inner join Contributionssummary c on m.schemeNo = c.schemeNo and m.MemberNo = c.MemberNo    
     and ((c.Datepaid >= @startDate)  and (c.Datepaid<=@endDate))     
     inner join Sponsor s on m.schemeNo = s.schemeno and m.sponsorCode = s.SponsorCode    
WHERE (m.schemeNo = @schemeCode)    
                       
group by c.schemeno,s.SponsorName    
    
open ContrCsr    
    
fetch from ContrCsr into @schemeNo, @totEmp, @totEmpr, @totnssf, @totnssfe, @totvol, @totSpecial, @AugCont,@totAll,    
@SponsorName    
    
while @@fetch_status = 0     
begin    
    insert into #ContSummary (schemeNo,    
                  schemeName,    
                      startdate,    
 Enddate,    
 totEmp,    
 totEmpr,    
 totNssf,    
 totNSSFe,    
 totVol,    
 totSpecial,    
 totAll,    
 AugCont,SponsorName,PoolName)    
 values (@schemeNo,@schemeName, @startdate,    
 @Enddate,    
@totEmp,    
 @totEmpr,    
@totNssf,    
@totNSSFe,    
 @totVol,    
 @totSpecial,    
@totAll,    
@AugCont,    
@SponsorName,  
@PoolName)    
    
select @SponsorName = ''    
fetch next from ContrCsr into @schemeNo, @totEmp, @totEmpr, @totnssf, @totnssfe, @totvol, @totSpecial, @AugCont,@totAll,    
@SponsorName    
end    
    
Close ContrCsr    
deallocate ContrCsr    
  
select @schemeCode=0,@schemeName='',@SchemeMode=0    
Fetch next from ContSummaryCsr into @schemeCode,@schemeName,@SchemeMode    
end    
Close ContSummaryCsr    
Deallocate ContSummaryCsr    
        
END    
ELSE if @FundType <> 'PF'    
BEGIN    
select @schemeName = @PoolName  
  
if @SchemeMode = 0    
declare ContrCsr cursor for    
SELECT schemeno, sum (EmpCont + ExcessEmpCont) as totemp,    
sum (EmprCont + ExcessEmprcont) as totempr,    
sum(NSSF) as totnssf,    
sum(NssfE) as totnssfe,    
sum(VolContr + ExcessVolContr) as totvol ,    
sum (SpecialContr + ExcessSpecial) as totspecial, sum(AugCont),    
sum (EmpCont + EmprCont + NSSF + NssfE + VolContr+  SpecialContr + ExcessEmprCont + ExcessEmpCont + ExcessVolContr + ExcessSpecial + ExcessSpecial + AugCont) as totall,    
''    
FROM Contributionssummary    
WHERE (schemeNo = @schemeNo)  and    
              ((Datepaid >= @startDate)  and    
              (Datepaid<=@endDate))          
group by schemeno    
else if @schemeMode = 1    
declare ContrCsr cursor for    
SELECT c.schemeno, sum (c.EmpCont + c.ExcessEmpCont) as totemp,    
sum (c.EmprCont + c.ExcessEmprcont) as totempr,    
sum(c.NSSF) as totnssf,    
sum(c.NssfE) as totnssfe,    
sum(c.VolContr + c.ExcessVolContr) as totvol ,    
sum (c.SpecialContr + c.ExcessSpecial) as totspecial, sum(AugCont),    
sum (c.EmpCont + c.EmprCont + c.NSSF + c.NssfE + c.VolContr+  c.SpecialContr + c.ExcessEmprCont + c.ExcessEmpCont + c.ExcessVolContr + c.ExcessSpecial + c.ExcessSpecial + c.AugCont) as totall,    
s.SponsorName    
FROM Members m    
     inner join Contributionssummary c on m.schemeNo = c.schemeNo and m.MemberNo = c.MemberNo    
     and ((c.Datepaid >= @startDate)  and (c.Datepaid<=@endDate))     
     inner join Sponsor s on m.schemeNo = s.schemeno and m.sponsorCode = s.SponsorCode    
WHERE (m.schemeNo = @schemeNo)    
                       
group by c.schemeno,s.SponsorName    
    
open ContrCsr    
    
fetch from ContrCsr into @schemeNo, @totEmp, @totEmpr, @totnssf, @totnssfe, @totvol, @totSpecial, @AugCont,@totAll,    
@SponsorName    
    
while @@fetch_status = 0     
begin    
    insert into #ContSummary (schemeNo,    
                  schemeName,    
                      startdate,    
 Enddate,    
 totEmp,    
 totEmpr,    
 totNssf,    
 totNSSFe,    
 totVol,    
 totSpecial,    
 totAll,    
 AugCont,SponsorName)    
 values (@schemeNo,@schemeName, @startdate,    
 @Enddate,    
@totEmp,    
 @totEmpr,    
@totNssf,    
@totNSSFe,    
 @totVol,    
 @totSpecial,    
@totAll,    
@AugCont,    
@SponsorName)    
    
select @SponsorName = ''    
fetch next from ContrCsr into @schemeNo, @totEmp, @totEmpr, @totnssf, @totnssfe, @totvol, @totSpecial, @AugCont,@totAll,    
@SponsorName    
end    
    
Close ContrCsr    
deallocate ContrCsr  
  
END    
if @SchemeMode = 0    
   select * from #ContSummary    
else    
   select * from #ContSummary order by SponsorName
go

