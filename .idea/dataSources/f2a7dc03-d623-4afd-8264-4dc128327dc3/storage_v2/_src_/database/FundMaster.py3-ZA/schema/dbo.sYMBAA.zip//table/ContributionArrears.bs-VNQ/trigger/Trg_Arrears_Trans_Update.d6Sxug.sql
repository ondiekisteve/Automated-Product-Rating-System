

CREATE TRIGGER [Trg_Arrears_Trans_Update] ON dbo.ContributionArrears 
FOR UPDATE,DELETE 
AS 
declare @TransferDate Datetime,@schemeNo Int,@AcctPeriod Int,@YearClosed smallInt  
  
Select @TransferDate = DatePaid,@SchemeNo = SchemeNo from Deleted  
  
select @AcctPeriod = AcctPeriod,@YearClosed = YearClosed from schemeYears where schemeNo = @schemeNo and StartDate <= @TransferDate  
and EndDate >= @TransferDate  

if @YearClosed = 2
  begin
      raiserror('You cannot Edit/Delete Arrears for a closed Period',16,1) 
      rollback tran
  end


go

