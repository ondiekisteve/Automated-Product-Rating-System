CREATE PROCEDURE [dbo].[PeriodBalance]      
@SCHEMENO Int,      
@AcctPeriod Int     
--with Encryption      
as      
      
select SchemeNo,AcctPeriod,Balance,UnBalance,Reserve,IncomefromPool,DrawDown,TransDate,    
Balance + UnBalance + Reserve + DrawDown as Total     
from DistributionBalances     
where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod
go

