CREATE PROCEDURE [dbo].[penPayroll1]
@SchemeNo varchar(15),
@payMonth int,
@payYear int,
@paydate datetime
--with Encryption
as

Declare @curMonth varchar(15), @MonthTaxFree Decimal(20,6), @Taxable Decimal(20,6), 
        @ReturnedEFT bit, @penNo varchar(15),@Relief Decimal(20,6),
        @PensionFreq Int,@Included bit,@YaConversion Varchar(25),@Chapaa Decimal(20,6),
        @BankCode Varchar(20),@DatePaid Datetime,@StartDate Datetime,@FreqPayMonth Int,
        @Okay Bit,@Factor Int,@DoCalc Datetime,@CalcMonth Int,@CalcYear Int,@CalcDay Int,
        @ArrearsCutOff Int,@has_Other_Income Int

select @ArrearsCutOff = ArrearsCutOff from ConfigRetirement where SchemeNo = @schemeNo

if @ArrearsCutOff is null select @ArrearsCutOff = 0

Select @Okay = 0,@Factor = 1

select @BankCode = BankCode from Pension_setup where SchemeNo = @schemeNo

Exec GetFirstDate @PayMonth,@PayYear,@DatePaid Out

/* Delete Data chafu from the Pensioners register */
Exec CleanPayroll @SchemeNo

if not Exists (select * from TaxRelief)
   begin
       raiserror('The Personal Tax Relief has not been defined , Please Contact the Administrator',16,1)
       return
   end
else
   select @Relief = Relief from TaxRelief where TaxYear = (select Max(TaxYear) from TaxRelief)

   Select @MonthTaxFree = MTaxFreeAmt from Pension_Setup where SchemeNo = @SchemeNo

exec GetMonthName @PayMonth, @curMonth out

 if  (select count(*)  from pensionpayroll
      where (SchemeNo = @schemeNo) 
             and (paymonth=@paymonth) and (payYear=@PayYear)) > 0
     begin
        raiserror('The Pensioners Payroll has already been processed for %s, %d', 16,1, @curMonth, @PayYear)
        return 
    end
else
   begin
            
	declare @memberNo int
	declare @gross Decimal(20,6)
	declare @rate float
	declare @hold bit
	declare @bank varchar (15)
	declare @branch varchar(15)
	declare @paypoint varchar(15)
	declare @acctno varchar (15)
        declare @cExist int, @DoExit datetime, @ExitDay int, @Days int
        declare @PayType int, @finCode varchar(15), @finBrCode varchar(15),
        @finAcctNo varchar(20), @foreign int, @PayCode varchar(4)
              
	declare @tax Decimal(20,6), @withTax Decimal(20,6)
        select @Tax = 0
        select @withTax = 0

	declare penPayrollCsr cursor for
	select p.schemeno,p.MemberNo, p.MonPension,p.Hold, p.bankcode, p.Branch, p.paypointcode,p.payCode, p.acctNo, p.PayType, p.finCode, p.finBrCode, p.finAcctNo,
               p.foreigner, p.hold, p.ReturnedEft,  p.penNo, m.DoExit,m.DoCalc, p.PensionFreq,p.PensionStartDate,
               p.has_Other_Income
             from pensioner p
                  inner Join Members m on p.schemeNo = m.schemeNo and p.MemberNo = m.MemberNo
	where
	(p.SchemeNo = @SchemeNo)  and  (p.alive =1) and (p.defer = 0)  and Foreigner = 0
        and p.PenNo = '0193'

	order by p.schemeno,p.MemberNo

	open penPayrollCsr

	fetch from penPayrollCsr
	into @schemeno,@memberNo,@gross,@hold, @bank, @branch, @paypoint, 
             @payCode, @acctno, @PayType, @finCode, @finBrCode, @finAcctNo, 
             @foreign,@hold, @ReturnedEFT, @penNo, @doExit,@DoCalc,@PensionFreq,@StartDate,@has_Other_Income
             
	while (@@fetch_status = 0)
	begin
              select @tax = 0
              select @withTax = 0

              if @has_Other_Income is null select @has_Other_Income = 0

         if @PensionFreq > 1  /* Pension Payment Frequency */
           begin
                   if (@PensionFreq = 2) /* QUARTERLY */
                      begin
                              select @FreqPayMonth = DatePart(Month,@StartDate) + 2
                              
                              if @FreqPayMonth > 12
                                 select @FreqPayMonth = @FreqPayMonth - 12

                              if @PayMonth = @FreqPayMonth /* Check for First Three Months */
                                 select @Okay = 1

                     else
                   select @Okay = 0

                              if @okay = 0 /* Next for the Next 6 Months */
                                 begin
                                    select @FreqPayMonth = DatePart(Month,@StartDate) + 5
                              
                                    if @FreqPayMonth > 12
                     select @FreqPayMonth = @FreqPayMonth - 12

                                    if @PayMonth = @FreqPayMonth 
                                       select @Okay = 1
                                    else
                                       select @Okay = 0
                                 end
                              
                              if @okay = 0 /* Next for the Next 9 Months */
                                 begin
                                    select @FreqPayMonth = DatePart(Month,@StartDate) + 8
                              
                                    if @FreqPayMonth > 12
                                       select @FreqPayMonth = @FreqPayMonth - 12

                                    if @PayMonth = @FreqPayMonth 
                                       select @Okay = 1
                                    else
                                       select @Okay = 0
                                 end

                              if @okay = 0 /* Next for the Next 12 Months */
                                 begin
                                    select @FreqPayMonth = DatePart(Month,@StartDate) + 11
                              
                                    if @FreqPayMonth > 12
                                       select @FreqPayMonth = @FreqPayMonth - 12

                                    if @PayMonth = @FreqPayMonth 
                                       select @Okay = 1
                                    else
                                       select @Okay = 0
                                 end

                            if @Okay = 1
                               begin
                                select @Factor = 3
                                Select @Included = 1
                               end
                            else
                               select @Included = 0
                      end
                   /* THIRDLY */
                          if (@PensionFreq = 5) /* THIRDLY */
                             begin
                              select @FreqPayMonth = DatePart(Month,@StartDate) + 3
                              
                              if @FreqPayMonth > 12
                                 select @FreqPayMonth = @FreqPayMonth - 12

                              print @PayMonth
                              print @FreqPayMonth
                              print ('*************************************************************')
                              if @PayMonth = @FreqPayMonth /* Check for First FOUR Months */
                                 select @Okay = 1
                              else
                                 select @Okay = 0

                              if @okay = 0 /* Next for the Next 8 Months */
                                 begin
                                    select @FreqPayMonth = DatePart(Month,@StartDate) + 7
                              
                                    if @FreqPayMonth > 12
                                       select @FreqPayMonth = @FreqPayMonth - 12

                                    if @PayMonth = @FreqPayMonth 
                                       select @Okay = 1
                                    else
                                       select @Okay = 0
                                 end
                              
                              if @okay = 0 /* Next for the Next 12 Months */
                                 begin
                                    select @FreqPayMonth = DatePart(Month,@StartDate) + 11
                              
                                    if @FreqPayMonth > 12
                                       select @FreqPayMonth = @FreqPayMonth - 12

                               if @PayMonth = @FreqPayMonth 
                                       select @Okay = 1
                                    else
                                       select @Okay = 0
                                 end

                            if @Okay = 1
                               begin
                                select @Factor = 4
                                Select @Included = 1
                               end
                            else
                               select @Included = 0

                         print ('*****************************************************************')
                         print @Okay
                         print @Factor
                         print('******************************************************************')
                      end
                   /* END THIRDLY */
                   else if (@PensionFreq = 3) /* Half Yearly */
                      begin

                              select @FreqPayMonth = DatePart(Month,@StartDate) + 5
                              
                              if @FreqPayMonth > 12
                                 select @FreqPayMonth = @FreqPayMonth - 12

                              if @PayMonth = @FreqPayMonth /* Check for First Six Months */
                                 select @Okay = 1
                              else
                                 select @Okay = 0

                              if @okay = 0 /* Next for the Next 12 Months */
                                 begin
                                    select @FreqPayMonth = DatePart(Month,@StartDate) + 11
                              
                                    if @FreqPayMonth > 12
                                       select @FreqPayMonth = @FreqPayMonth - 12

                                    if @PayMonth = @FreqPayMonth 
                                       select @Okay = 1
                                    else
                                       select @Okay = 0
                                 end
                              
                            if @Okay = 1
                               begin
                                select @Factor = 6
                                Select @Included = 1
                               end
                            else
                               select @Included = 0
                      end
                   else if (@PensionFreq = 4) 
        begin
             select @FreqPayMonth = DatePart(Month,@StartDate) + 11
                              
                            if @FreqPayMonth > 12
                                 select @FreqPayMonth = @FreqPayMonth - 12

                              if @PayMonth = @FreqPayMonth /* Check for First 12 Months */
                             select @Okay = 1
                              else
                                 select @Okay = 0

                              
                            if @Okay = 1
                               begin
                                select @Factor = 12
                                Select @Included = 1
                               end
                            else
                               select @Included = 0
                      end
           end


           print ('*****************************************************************')
                         print @Okay
                         print @Factor
                         print('******************************************************************')
   	   if (@gross > @MonthTaxFree)
                   begin


                           select @Taxable = @gross - @MonthTaxFree
                          
                           Exec CalculateMonthTax @Taxable, @tax out

                          if @has_Other_Income = 0
                            begin
                              if (@Tax > @Relief) 
                                  select @Tax = (@Tax - @Relief)
                              else 
                                 select @Tax = 0
                            end
                       
                      if @Tax > 0
                         select @Tax = @Tax * @Factor
                      else
                         select @Tax = 0

                      select @Gross = @Gross * @Factor
                   end
              else
                  begin
                      select @Tax = 0
                      select @Gross = @Gross * @Factor
                  end
    
            print ('******************************************************************************************')
            print @Gross
            print ('******************************************************************************************')
            /* rounding  gross*/
              select @YaConversion = cast(@gross as Varchar(25))
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
              select @Gross = @Chapaa
              select @Chapaa = 0

               /* rounding  @tax*/
              if @Tax > 0 begin
              select @YaConversion = cast(@tax as Varchar(25))
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
              select @tax = @Chapaa
              select @Tax = round(@Tax,0)
              select @Chapaa = 0
              end

               /* rounding  withholding Tax*/
              if @withTax > 0 begin
              select @YaConversion = cast(@withTax as Varchar(25))
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
              select @withTax = @Chapaa
              select @withTax = round(@withTax,0)
              end
              

              if (datepart(Year, @DoExit) = @PayYear)
                 begin
                     if (Datepart(Month, @DoExit) < @PayMonth) 
                        begin
                          if @PensionFreq > 1 and @included = 1
  	                     insert into pensionpayroll
 	                                 (SchemeNo, MemberNo, paymonth, payyear, gross, net, tax, dateprep,hold, paid, datepaid, bank, branch, paypoint, acctno, PayType,
                                    finCode, finBrCode, finAcctNo, withholdingTax, ReturnedEft, penNo, PayCode,BankCode)
 	                     values
 	                                 (@schemeNo, @memberNo, @paymonth,@payyear, @gross, @gross- (@tax + @withTax), @tax, @paydate, @hold, 1, @DatePaid, @bank, @branch, @paypoint, @acctno, @PayType,
                                    @finCode, @finBrCode, @finAcctNo, @withTax, @ReturnedEft, @PenNo, @PayCode,@BankCode)
                          else if @PensionFreq = 1
                             insert into pensionpayroll
 	                                 (SchemeNo, MemberNo, paymonth, payyear, gross, net, tax, dateprep,hold, paid, datepaid, bank, branch, paypoint, acctno, PayType,
                                    finCode, finBrCode, finAcctNo, withholdingTax, ReturnedEft, penNo, PayCode,BankCode)
 	   values
 	                                 (@schemeNo, @memberNo, @paymonth,@payyear, @gross, @gross- (@tax + @withTax),@tax, @paydate, @hold, 1, @DatePaid, @bank, @branch, @paypoint, @acctno, @PayType,
                                    @finCode, @finBrCode, @finAcctNo, @withTax, @ReturnedEft, @PenNo, @PayCode,@BankCode)
                       end

                    /*if (Datepart(Month, @DoExit) = @PayMonth) 
                       if @ArrearsCutOff > 0
                          if (Datepart(Month, @DoCalc) = @PayMonth) 

                              begin    
                                 
                              end
                    */
                end
            
             if (Datepart(Year, @DoExit) < @PayYear) 
                begin
                    if @PensionFreq > 1 and @included = 1
                       insert into pensionpayroll
 	                   (SchemeNo, MemberNo, paymonth, payyear, gross, net, tax, dateprep,hold, paid, datepaid, bank, branch, paypoint, acctno, PayType,
                            finCode, finBrCode, finAcctNo, withHoldingTax, ReturnedEft, PenNo, PayCode,BankCode)
 	               values
 	                   (@schemeNo, @memberNo, @paymonth,@payyear, @gross,@gross- (@tax + @withTax),@tax, @paydate, @hold, 1,@DatePaid, @bank, @branch, @paypoint, @acctno, @PayType,
                            @finCode, @finBrCode, @finAcctNo, @withTax, @ReturnedEFT, @PenNo, @PayCode,@BankCode)
                    else if @PensionFreq = 1
                       insert into pensionpayroll
 	                   (SchemeNo, MemberNo, paymonth, payyear, gross, net, tax, dateprep,hold, paid, datepaid, bank, branch, paypoint, acctno, PayType,
              finCode, finBrCode, finAcctNo, withHoldingTax, ReturnedEft, PenNo, PayCode,BankCode)
 	               values
 	                   (@schemeNo, @memberNo, @paymonth,@payyear, @gross, @gross - (@tax + @withTax), @tax, @paydate, @hold, 1, @DatePaid, @bank, @branch, @paypoint, @acctno, @PayType,
                            @finCode, @finBrCode, @finAcctNo, @withTax, @ReturnedEFT, @PenNo, @PayCode,@BankCode)
               end
             
               select @withTax = 0
               select @Tax= 0
               Select @hold = 0,
               @FreqPayMonth = 0,
               @Okay =0,@Factor = 1,@has_Other_Income = 0
             

  	fetch next from penPayrollCsr
 	 into @schemeno,@memberNo,@gross,@hold, @bank, @branch, @paypoint, 
              @payCode, @acctno, @PayType, @finCode, @finBrCode, @finAcctNo, 
              @foreign, @hold, @returnedEFT, @penNo, @DoExit,@DoCalc,@PensionFreq,@StartDate,@has_Other_Income
  
	end

	close penPayrollCsr
	deallocate penPayrollCsr
            
             Exec  DeductionsPayroll @SchemeNo, @PayMonth, @PayYear
            
             Exec CourtPayroll  @SchemeNo, @PayMonth, @PayYear

             Exec ApplyDeductions @SchemeNo, @PayMonth, @PayYear

             Exec PenPayrollForeign @SchemeNo, @PayMonth, @PayYear,@Paydate /*Foreign Pensioners Payroll */

             Exec ArrearsPayroll @SchemeNo, @PayMonth, @PayYear

end
go

