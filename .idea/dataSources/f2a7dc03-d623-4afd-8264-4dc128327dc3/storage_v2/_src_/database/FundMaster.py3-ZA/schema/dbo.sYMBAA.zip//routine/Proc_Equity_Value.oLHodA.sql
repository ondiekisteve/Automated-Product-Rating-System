CREATE PROCEDURE [dbo].[Proc_Equity_Value]                                           
@SCHEMENO Int,                                            
@StartDate Datetime,                                            
@EndDate Datetime,                          
@RepMode Int, /* 0 - Quoted Equity, 1 - UnQuarted Equity */          
@InvestValue float out                                     
--with Encryption                                            
as                                            
                                            
if object_id('tempdb..#tt_Equity_Listing') is null                                            
                                            
begin                                            
create table #tt_Equity_Listing                                            
(                                            
        [glcode] [int] IDENTITY(1,1) Primary Key,                                            
        [EquityName] [varchar](100) NOT NULL ,                                            
        [SharesOpen][float],                            
        [SharesTrans][float],                            
        [SharesClose][float],             
        [AvgCost][float],                           
        [CostOpen] float,                            
        [CostTrans] float,                             
        [CostClose] float,                           
        [MarketOpen] float,                            
        [MarketTrans] float,                             
        [MarketClose] float,                          
        [SchemeName][varchar](120),                            
        [StartDate][Datetime],                            
        [EndDate][Datetime],                            
        [ManagerName][varchar](120),                            
        [ChangeInValue] float,                        
        [MarketPerShare] float,            
        [GainLoss] float,            
        [PercentAlloc]float            
                          
)                                             
                                                                         
end                                            
                            
declare @schemeName varchar(120),@OpenDate Datetime,                            
@SharesOpen float,@SharesTrans float,@SharesClose float,                                                
@CostOpen float,@CostTrans float,@CostClose float,                            
@MarketOpen float,@MarketTrans float,@MarketClose float,                            
@EquityNo Int,                            
@Cost float,@Shares float,@Market float,                            
@OtherCost float,@OtherShares float,@OtherMarket float,@EquityName varchar(100),                            
@ChangeInValue float,@ManagerName varchar(120),@MarketPerShare float,            
@AvgCost float,@GainLoss float,@PercentAlloc float,@ConsolShares float              
                                  
select @SchemeName = schemeName from scheme where schemeCode = @schemeNo    
  
select @ConsolShares = 0                          
                          
if @RepMode = 0 /* Monthly */                           
   select @OpenDate = @EndDate                           
else                          
   select @OpenDate = @StartDate - 1                                       
                            
Declare EquityCsr Cursor for                            
Select e.EquityNo,e.NoOfShares * e.PricePerShare,e.NoOfShares,e.NoOfShares * e.MarketValue,i.InvName,                            
im.ManagerName                             
from Equity E                            
Inner Join Investments i on e.schemeNo = i.schemeNo and e.EquityNo = i.InvCode                            
Inner Join InvestmentManagers im on e.schemeNo = im.schemeNo and e.Manager = im.simCode                            
where e.schemeNo = @schemeNo and e.DateInvested <= @EndDate                            
                            
Open EquityCsr                            
fetch from EquityCsr into @EquityNo,@Cost,@Shares,@Market,@EquityName,@ManagerName                            
while @@fetch_Status = 0                            
begin              
     Exec fn_Equity_Avg_Cost @schemeNo,@EquityNo, @EndDate, @AvgCost Out             
                          
     Exec Proc_Get_Shares_Cost_n_Market @schemeNo,@EquityNo,@OpenDate,@SharesOpen Out,@CostOpen Out,@MarketOpen Out                              
                            
     if @SharesOpen is null select @SharesOpen = 0                            
     if @CostOpen is null select @CostOpen = 0                            
     if @MarketOpen is null select @MarketOpen = 0                          
                               
  if @RepMode = 0                          
     begin                         
     if @MarketOpen > 0                         
        select @MarketPerShare = @MarketOpen/cast(@SharesOpen  as Decimal(20,6))                       
     else                        
        select @MarketPerShare = 0.0                        
                        
     if @SharesOpen = 0 select @CostOpen = 0,@MarketPerShare = 0.0                    
                    
     Insert Into #tt_Equity_Listing                                     
     (EquityName,SharesOpen,SharesTrans,SharesClose,CostOpen,CostTrans,CostClose,MarketOpen,MarketTrans,                            
     MarketClose,SchemeName,StartDate,EndDate,ManagerName,ChangeInValue,MarketPerShare,AvgCost,GainLoss)                            
     Values(@EquityName,0,0,@SharesOpen, 0, 0,@CostOpen,                            
         0,0,@MarketOpen,@SchemeName,@StartDate,@EndDate,                            
         @ManagerName,0,@MarketPerShare,@AvgCost,@MarketOpen - @CostOpen)                          
     end                          
  else                          
     begin                          
                            
     if @SharesOpen > 0                            
        select @Cost=0,@Shares=0,@Market=0                            
                            
  /* Acquisitions */                            
  select @OtherCost = sum(NoOfshares * PricePerShare),@OtherMarket = sum(NoOfshares * PricePerShare),                            
  @OtherShares = sum(NoOfShares) from EquityAcquisition where SchemeNo = @schemeNo and EquityNo = @EquityNo                            
  and DateAcquired >= @StartDate and DateAcquired <= @EndDate                            
                            
  if @OtherCost is null select @OtherCost = 0                            
  if @OtherMarket is null select @OtherMarket = 0                            
  if @OtherShares is null select @OtherShares = 0                            
                            
  select @Cost = @Cost + @OtherCost,@Market = @Market + @OtherMarket,@Shares = @Shares + @OtherShares                            
                              
  select @OtherCost=0,@OtherMarket=0,@OtherShares=0                            
                              
  /* Bonuses */                            
  select @OtherCost = 0.0,@OtherMarket = sum(Bonus * MarketValue),                            
  @OtherShares = sum(Bonus) from EquityBonus where SchemeNo = @schemeNo and EquityNo = @EquityNo                            
  and BonusDate >= @StartDate and BonusDate <= @EndDate                            
                            
  if @OtherCost is null select @OtherCost = 0                            
  if @OtherMarket is null select @OtherMarket = 0                            
  if @OtherShares is null select @OtherShares = 0                            
                            
  select @Cost = @Cost + @OtherCost,@Market = @Market + @OtherMarket,@Shares = @Shares + @OtherShares                            
                              
  select @OtherCost=0,@OtherMarket=0,@OtherShares=0                            
                            
  /* Transfers */                            
  select @OtherCost = sum(Cost),@OtherMarket = sum(NoOfUnits * MarketValue),                            
  @OtherShares = sum(NoOfUnits) from InvestmentsTransfer where SchemeNo = @schemeNo and TransferFrom = @EquityNo                            
  and TransferDate >= @StartDate and TransferDate <= @EndDate                            
                            
  if @OtherCost is null select @OtherCost = 0                            
  if @OtherMarket is null select @OtherMarket = 0                            
  if @OtherShares is null select @OtherShares = 0                            
                            
  select @Cost = @Cost - @OtherCost,@Market = @Market - @OtherMarket,@Shares = @Shares - @OtherShares                            
                              
  select @OtherCost=0,@OtherMarket=0,@OtherShares=0                            
                            
  /* Share Splits */                            
  select @OtherCost = 0.0,@OtherMarket = 0.0,                            
  @OtherShares = sum(NewShares - SharesHeld) from TBL_Equity_Split                             
  where SchemeNo = @schemeNo and EquityNo = @EquityNo                            
  and SplitDate >= @StartDate and SplitDate <= @EndDate and SplitType = 0                           
                            
  if @OtherCost is null select @OtherCost = 0                            
  if @OtherMarket is null select @OtherMarket = 0                            
  if @OtherShares is null select @OtherShares = 0                            
                            
  select @Cost = @Cost + @OtherCost,@Market = @Market + @OtherMarket,@Shares = @Shares + @OtherShares                            
                              
  select @OtherCost=0,@OtherMarket=0,@OtherShares=0    
    
    /* Share Consolidation */                            
  select @OtherCost = 0.0,@OtherMarket = 0.0,                            
  @ConsolShares = sum(NewShares - SharesHeld) from TBL_Equity_Split                             
  where SchemeNo = @schemeNo and EquityNo = @EquityNo                            
  and SplitDate >= @StartDate and SplitDate <= @EndDate and SplitType = 1                          
                            
  if @OtherCost is null select @OtherCost = 0                            
  if @OtherMarket is null select @OtherMarket = 0                            
  if @OtherShares is null select @OtherShares = 0  
  if @ConsolShares is null select @ConsolShares = 0                            
                            
  select @Cost = @Cost + @OtherCost,@Market = @Market + @OtherMarket,@Shares = @Shares + @OtherShares + @ConsolShares                            
                              
  select @OtherCost=0,@OtherMarket=0,@OtherShares=0,@ConsolShares = 0                           
                            
  /* Sales */                            
  /* Gains */                            
  select @OtherCost = sum((NoOfshares * PricePerShare) - Income),@OtherMarket = sum(NoOfshares * PricePerShare),                            
  @OtherShares = sum(NoOfShares) from SaleEquity where SchemeNo = @schemeNo and EquityNo = @EquityNo                            
  and TransDate >= @StartDate and TransDate <= @EndDate and IncomeOrLoss = 1                            
                             
  if @OtherCost is null select @OtherCost = 0                            
  if @OtherMarket is null select @OtherMarket = 0                            
  if @OtherShares is null select @OtherShares = 0                            
                            
  select @Cost = @Cost - @OtherCost,@Market = @Market - @OtherMarket,@Shares = @Shares - @OtherShares                            
                              
  select @OtherCost=0,@OtherMarket=0,@OtherShares=0                            
                            
  /* Losses */                            
  select @OtherCost = sum((NoOfshares * PricePerShare) + Income),@OtherMarket = sum(NoOfshares * PricePerShare),                            
  @OtherShares = sum(NoOfShares) from SaleEquity where SchemeNo = @schemeNo and EquityNo = @EquityNo                            
  and TransDate >= @StartDate and TransDate <= @EndDate and IncomeOrLoss = 1                            
                             
  if @OtherCost is null select @OtherCost = 0                            
  if @OtherMarket is null select @OtherMarket = 0                            
  if @OtherShares is null select @OtherShares = 0                            
                            
  select @Cost = @Cost - @OtherCost,@Market = @Market - @OtherMarket,@Shares = @Shares - @OtherShares                            
                              
  select @OtherCost=0,@OtherMarket=0,@OtherShares=0                            
                            
  select @ChangeInValue = sum((NoOfShares * PricePerShare) - Cost) from EquityValue                             
  where SchemeNo = @schemeNo and EquityNo = @EquityNo                            
  and PriceDate >= @StartDate and PriceDate <= @EndDate                            
             
  if @ChangeInValue is null select @ChangeInValue = 0.0                     
                    
  if (@SharesOpen+@Shares) = 0                    
     begin                    
         select @CostOpen = 0,@Cost = 0                      
     end                        
                              
  Insert Into #tt_Equity_Listing                                            
  (EquityName,SharesOpen,SharesTrans,SharesClose,CostOpen,CostTrans,CostClose,MarketOpen,MarketTrans,                            
   MarketClose,SchemeName,StartDate,EndDate,ManagerName,ChangeInValue,AvgCost,GainLoss)                            
  Values(@EquityName,@SharesOpen,@Shares,@SharesOpen+@Shares, @CostOpen, @Cost,@CostOpen + @Cost,                            
         @MarketOpen,@Market,@MarketOpen+@Market + @ChangeInValue,@SchemeName,@StartDate,@EndDate,                            
         @ManagerName,@ChangeInValue,@AvgCost,(@MarketOpen+@Market + @ChangeInValue)-(@CostOpen + @Cost))                          
   end                            
                            
  select @EquityNo=0,@Cost=0,@Shares=0,@Market=0,@EquityName = '',@ManagerName = '',                          
  @SharesOpen = 0,@CostOpen =0,@MarketOpen = 0,@ChangeInValue = 0,@OtherCost=0,@OtherShares=0,@OtherMarket=0,            
  @AvgCost = 0.0                            
fetch next from EquityCsr into @EquityNo,@Cost,@Shares,@Market,@EquityName,@ManagerName                            
end                            
Close EquityCsr                            
Deallocate EquityCsr             
            
/* Calculate Percentage */            
            
select @Cost = sum(MarketClose) from #tt_Equity_Listing            
            
declare EquityCsr Cursor for            
select glCode,MarketClose from #tt_Equity_Listing            
open EquityCsr            
fetch from EquityCsr into @EquityNo,@Market            
while @@fetch_Status = 0            
begin            
  if @Market > 0.0             
     update #tt_Equity_Listing set PercentAlloc = (@Market/@Cost)*100.00            
     where glCode = @EquityNo            
  else             
     update #tt_Equity_Listing set PercentAlloc = 0.0            
     where glCode = @EquityNo            
            
  select @EquityNo=0,@Market=0.0            
  fetch next from EquityCsr into @EquityNo,@Market            
end            
Close EquityCsr            
Deallocate EquityCsr                            
                            
select @InvestValue = SUM(MarketClose) from #tt_Equity_Listing
go

