CREATE VIEW [dbo].[DecBeneficiaries]
--with encryption
AS
SELECT d.schemeNO, d.MemberNo, d.dependantcode, DecDepCode,(UPPER(d.SName) 
    + ', ' + d.FName + ' ' + d.OName) AS FullName, d.PcntBenefit, dt.TypeDesc
FROM dependants d
           inner Join DependantType dt on d.DependantType = dt.Typecode
WHERE d.Alive = 1 and DecDepCode > 1
go

