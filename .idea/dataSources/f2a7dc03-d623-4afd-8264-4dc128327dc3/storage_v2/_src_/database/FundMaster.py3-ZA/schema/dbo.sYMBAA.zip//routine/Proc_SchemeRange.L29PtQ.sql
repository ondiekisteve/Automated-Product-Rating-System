CREATE PROCEDURE [dbo].[Proc_SchemeRange]  
@RangeInterval Int  
--with Encryption  
as  
  
if object_id ('tempdb..##SchemeRange') is null  
begin  
create table ##SchemeRange  
(  
 [counter] [int],  
 [RangeStart] [int] NOT NULL,   
 [RangeEnd] [int] NOT NULL   
)   
end  
  
delete from  ##SchemeRange   
  
declare @MinSchemeNo Int,@MaxSchemeNo Int,@RangeStart Int,@RangeEnd Int,@Counter int,
@SqlStr varchar(2000),@RangeStr varchar(20),@TopScheme Int 
  
select @Counter = 1,@RangeStr = cast(@RangeInterval as varchar(20))
  
select @MinSchemeNo = Min(SchemeCode),@MaxSchemeNo = Max(SchemeCode) 
from Scheme
where BasisCode = 1 and ActiveStatus = 1   
  
select @RangeStart = @MinSchemeNo, @RangeEnd = @MinSchemeNo + @RangeInterval 

Select @SqlStr = 'Insert into ##SchemeRange(Counter,RangeStart,RangeEnd) Select '+cast(@Counter as varchar(20))+',cast(Min(schemeCode) as varchar(20)),0 from Scheme where BasisCode = 1 and ActiveStatus = 1 and 
                  SchemeCode in (Select top '+@RangeStr+' schemeCode from scheme 
                  where BasisCode = 1 and ActiveStatus = 1)'       
        
Exec (@SqlStr)

Select @SqlStr = 'Update ##SchemeRange set RangeEnd = (select cast(Max(schemeCode) as varchar(20)) from Scheme where BasisCode = 1 
                                                       and ActiveStatus = 1 and 
                  SchemeCode in (Select top '+@RangeStr+' schemeCode from scheme 
                  where BasisCode = 1 and ActiveStatus = 1) and Counter = '+cast(@Counter as varchar(20))+')' 

Exec (@SqlStr)

select @TopScheme = RangeEnd from ##SchemeRange where Counter = @Counter 

select @Counter = @Counter + 1
     
while @TopScheme < @MaxSchemeNo  
begin


   Select @SqlStr = 'Insert into ##SchemeRange(Counter,RangeStart,RangeEnd) Select '+cast(@Counter as varchar(20))+',cast(Min(schemeCode) as varchar(20)),0 from Scheme where BasisCode = 1 and ActiveStatus = 1 and 
                  SchemeCode in (Select top '+@RangeStr+' schemeCode from scheme 
                  where BasisCode = 1 and ActiveStatus = 1 and SchemeCode > '+cast(@TopScheme as varchar(20))+')'       
        
   Exec (@SqlStr)


   Select @SqlStr = 'Update ##SchemeRange set RangeEnd = (
                                                          select cast(Max(schemeCode) as varchar(20)) 
                                                          from Scheme 
                                                          where BasisCode = 1 and ActiveStatus = 1 and SchemeCode in 
                                                                (
                                                                 Select top '+@RangeStr+' schemeCode 
                                                                 from scheme 
                                                                 where BasisCode = 1 and ActiveStatus = 1 and SchemeCode > '+cast(@TopScheme as varchar(20))+ '
                                                                 order by schemeCode)
                                                          )
                     where Counter = '+cast(@Counter as varchar(20))

   Exec (@SqlStr)

   select @TopScheme = RangeEnd from ##SchemeRange where Counter = @Counter 
   
   select @Counter = @Counter + 1  
end 

  
select * from ##SchemeRange order by Counter
go

