CREATE PROCEDURE [dbo].[canSeeScheme]
@useName varchar(10),
@canSee varchar(10) out
--with Encryption
as
select 1
go

