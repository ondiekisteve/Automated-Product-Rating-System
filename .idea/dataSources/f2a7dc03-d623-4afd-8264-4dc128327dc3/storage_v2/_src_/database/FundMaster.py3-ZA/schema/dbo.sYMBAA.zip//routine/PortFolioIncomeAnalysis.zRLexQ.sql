




CREATE PROCEDURE PortFolioIncomeAnalysis  
@SCHEMENO Int,  
@PayYear int
--with Encryption  
as  
  
if object_id('tempdb..#Portfolio') is null  
  
begin  
create table #PortFolio  
(  
   
        [InvCounter][Int] identity(1,1) Primary key,
        [SchemeName][varchar](120) null,  
        [Investment] [varchar](100) NOT NULL ,  
        [LastYear] [float] not  NULL default 0.0,  
        [ThisYear] [Float] null default 0.0,  
        [Diff][float] null default 0.0,  
        [Currency][varchar](30),  
        [CurYear][Int],  
        [PastYear][Int]  
                      
)     
end  
  
declare @InvestCode Int,@Investment varchar(50),@LastYear float,  
@ThisYear float,@SchemeName varchar(120),@Curr varchar(15),@Currency varchar(30)  
  
Select @SchemeName = schemeName,@Curr = Currency from scheme where schemeCode = @schemeNo  
  
Select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @Curr  
  
Declare Acsr Cursor for  
Select Distinct(i.InvestCode),It.InvestDesc from  
InvestMents i  
  inner Join InvestmentTypes it on i.InvestCode = it.InvestCode  
where SchemeNo = @schemeNo and i.InvStatus = 0  
  
Open acsr  
  
fetch from acsr into @InvestCode,@Investment  
  
while @@fetch_Status = 0  
begin  
       
     if @Investment = 'Property Unit Trusts'  
        Exec PropertyIncome @SchemeNo,@PayYear,0,@ThisYear out,@LastYear out  
  
     if @Investment = 'Quoted Equity'  
        Exec EquityIncome @SchemeNo,@PayYear,0,@ThisYear out,@LastYear out  
  
     if @Investment = 'Un-Quoted Equity'  
        Exec Un_EquityIncome @SchemeNo,@PayYear,0,@ThisYear out,@LastYear out  
  
     if @Investment = 'Government Paper'  
        Exec TreasuryIncome @SchemeNo,@PayYear,0,@ThisYear out,@LastYear out  
  
     if @Investment = 'Fixed & Time Deposits'  
        Exec DepositsIncome @SchemeNo,@PayYear,0,@ThisYear out,@LastYear out  
  
     if @Investment = 'Commercial Paper'  
        Exec CommIncome @SchemeNo,@PayYear,0,@ThisYear out,@LastYear out  
  
     if @Investment = 'Cash & Demand Deposits'  
        Exec DemandIncome @SchemeNo,@PayYear,0,@ThisYear out,@LastYear out  
  
       
     IF @ThisYear IS NULL select @ThisYear = 0  
     IF @LastYear IS NULL select @LastYear = 0  
  
     Insert Into #PortFolio (Investment,LastYear,ThisYear,Diff,currency,CurYear,PastYear)  
                  Values(@Investment,@LastYear,@ThisYear,@ThisYear - @LastYear,@Currency,  
                         @PayYear,@PayYear - 1)  
  
    Select @ThisYear = 0, @LastYear = 0  
   fetch next from acsr into @InvestCode,@Investment  
end  
Close Acsr  
Deallocate Acsr  
  
Exec OffShoreIncome @SchemeNo,@PayYear, @ThisYear out,@LastYear out  
if ((@ThisYear > 0) or (@LastYear > 0))  
   begin  
       Select @Investment = 'Off-Shore Investments'  
  
       Insert Into #PortFolio (Investment,LastYear,ThisYear,Diff,currency,CurYear,PastYear)  
                  Values(@Investment,@LastYear,@ThisYear,@ThisYear - @LastYear,@Currency,  
                         @PayYear,@PayYear - 1)  
  
  end  
  
update #PortFolio set schemeName = @SchemeName  
  
  
Select * from #PortFolio


go

