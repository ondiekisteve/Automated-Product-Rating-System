CREATE PROCEDURE [dbo].[ShowCurrentCutOff]
@SCHEMENO Int,
@TableName varchar(100)
--with Encryption
as
declare @MinYear int,@MinMonth int,@MonthName varchar(20)

if @TableName = 'Contributions'
   begin
      Select @MinYear = Min(ContrYear) from
      Contributionssummary where
      SchemeNo = @SchemeNo

      Select @MinMonth = Min(ContrMonth) from
      Contributionssummary where
      SchemeNo = @SchemeNo and ContrYear = @MinYear
   end
else if @TableName = 'Pensions Payroll'
   begin
      Select @MinYear = Min(PayYear) from
      PensionPayroll where
      SchemeNo = @SchemeNo

      Select @MinMonth = Min(PayMonth) from
      PensionPayroll where
      SchemeNo = @SchemeNo and PayYear = @MinYear
   end
else if @TableName = 'Batched Data Entry'
   begin
      Select @MinYear = Min(BatchYear) from
      Batches where
      SchemeNo = @SchemeNo

      Select @MinMonth = Min(BatchMonth) from
      Batches where
      SchemeNo = @SchemeNo and BatchYear = @MinYear 
   end
else if @TableName = 'CashBook,General Ledger,Receipts,Payment Vouchers'
   begin
      Select @MinYear = Min(CashYear) from
      CashBook where
      SchemeNo = @SchemeNo

      Select @MinMonth = Min(CashMonth) from
      CashBook where
      SchemeNo = @SchemeNo and CashYear = @MinYear 
   end
else if @TableName = 'Rent Payment'
   begin
      Select @MinYear = Min(PayYear) from
      RentInvoice where
      SchemeNo = @SchemeNo

      Select @MinMonth = Min(PayMonth) from
      RentInvoice where
      SchemeNo = @SchemeNo and PayYear = @MinYear  
   end

Select @MonthName = MonthName from MonthTable
where MonthNumber = @MinMonth

Select @MonthName as CurrentMonth,@MinYear as CurrentYear
go

