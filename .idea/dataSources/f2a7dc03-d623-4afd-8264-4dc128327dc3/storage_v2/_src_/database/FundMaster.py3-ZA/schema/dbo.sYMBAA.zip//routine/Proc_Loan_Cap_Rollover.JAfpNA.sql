CREATE PROCEDURE [dbo].[Proc_Loan_Cap_Rollover]  
@schemeNo Int,  
@MortgageNo int,
@CapOrInt Int  
as  
declare @PayCode Int,@StartDate datetime,@dateDue datetime,@AmountDue decimal(20,2),@NumDays Int,
@InterestRate decimal(20,4),@NumMonths Int,@CapRepFreq int,@IntPayFreq Int,@DaysInYearMode Int,
@DaysInaYear Int

select @CapRepFreq = CapRepFreq,@IntPayFreq = IntPayFreq,@DaysInYearMode = DaysInYearMode from tbl_Loans
where SchemeNo = @schemeNo and MortgageNo = @MortgageNo

if @CapOrInt = 0
 begin
  if @DaysInYearMode = 0
     begin  
      if @CapRepFreq = 1  
         select @NumDays = 30,@NumMonths = 1  
      else if @CapRepFreq = 2  
         select @NumDays = 91,@NumMonths = 3  
      else if @CapRepFreq = 3  
         select @NumDays = 182,@NumMonths = 6  
      else if @CapRepFreq = 4  
         select @NumDays = 365,@NumMonths = 12  
  
      select @DaysInaYear = 365  
   end  
  else  
   begin  
      if @CapRepFreq = 1  
         select @NumDays = 30,@NumMonths = 1  
      else if @CapRepFreq = 2  
         select @NumDays = 90,@NumMonths = 3    
      else if @CapRepFreq = 3  
         select @NumDays = 180,@NumMonths = 6   
      else if @CapRepFreq = 4  
         select @NumDays = 360,@NumMonths = 12   
  
      select @DaysInaYear = 360  
   end  
end
else
 begin
  if @DaysInYearMode = 0
     begin  
      if @IntPayFreq = 1  
         select @NumDays = 30,@NumMonths = 1  
      else if @IntPayFreq = 2  
         select @NumDays = 91,@NumMonths = 3  
      else if @IntPayFreq = 3  
         select @NumDays = 182,@NumMonths = 6  
      else if @IntPayFreq = 4  
         select @NumDays = 365,@NumMonths = 12  
  
      select @DaysInaYear = 365  
   end  
  else  
   begin  
      if @IntPayFreq = 1  
         select @NumDays = 30,@NumMonths = 1  
      else if @IntPayFreq = 2  
         select @NumDays = 90,@NumMonths = 3    
      else if @IntPayFreq = 3  
         select @NumDays = 180,@NumMonths = 6   
      else if @IntPayFreq = 4  
         select @NumDays = 360,@NumMonths = 12   
  
      select @DaysInaYear = 360  
   end  
end

if @CapOrInt = 0
begin 
select @PayCode = max(PayCode) from TBL_Loans_Cap_Repay  
where SchemeNo = @schemeNo and MortgageNo = @MortgageNo  
  
select @StartDate = StartDate,@dateDue = Datedue,@AmountDue = AmountDue  
from TBL_Loans_Cap_Repay where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @PayCode  
   
select @StartDate = @dateDue + 1 

if @DaysInYearMode = 0       
   select @dateDue = dateAdd(Month,@NumMonths,@StartDate) - 1 
else
   select @dateDue = dateAdd(Day,@NumDays,@StartDate) - 1  

  
Insert into TBL_Loans_Cap_Repay(SchemeNo,MortgageNo,StartDate,DateDue,AmountDue,datepaid,  
                                Amountpaid,spotrate,posted,capReSet,CapPosted)  
                      Values(@schemeNo,@MortgageNo,@StartDate,@dateDue,@AmountDue,@dateDue,0.0,1.0000,0,0,0)
end
else if @CapOrInt = 1
begin 
select @PayCode = max(PayCode) from TBL_Loans_Interest  
where SchemeNo = @schemeNo and MortgageNo = @MortgageNo  
  
select @StartDate = StartDate,@dateDue = Datedue,@AmountDue = InterestDue,@InterestRate = InterestRate  
from TBL_Loans_Interest where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @PayCode  
   
select @StartDate = @dateDue + 1 

if @DaysInYearMode = 0       
   select @dateDue = dateAdd(Month,@NumMonths,@StartDate) - 1 
else
   select @dateDue = dateAdd(Day,@NumDays,@StartDate) - 1  

Insert into TBL_Loans_Interest(SchemeNo,MortgageNo,StartDate,DateDue,InterestDue,InterestRate,datepaid,  
                               Amountpaid,spotrate,posted,RateSet,InterestPosted)  
                      Values(@schemeNo,@MortgageNo,@StartDate,@dateDue,@AmountDue,@InterestRate,@dateDue,0.0,1.0000,0,0,0)

end
go

