CREATE PROCEDURE [dbo].[PensionersPayrollRecon]
@SCHEMENO Int,
@PayMonth int,
@PayYear int
--with Encryption
as

select sum(Net) from PensionPayroll 
where SchemeNo = @SchemeNo and PayMonth  = @PayMonth and PayYear = @PayYear

select sum(Net) from PensionPayroll 
where SchemeNo = @SchemeNo and PayMonth  = @PayMonth - 1 and PayYear = @PayYear
go

