CREATE PROCEDURE [dbo].[ShowDepreciation]    
@SCHEMENO Int,    
@AssetNo Int,    
@AssetClass Int    
--with Encryption    
as    
    
if object_id('tempdb..#ShowDep') is null    
    
begin    
create table #ShowDep    
(    
        [SchemeNo] INT NOT NULL ,    
        [PropertyCode][Int] NOT NULL ,    
        [ValueDate] [Datetime] not NULL,    
        [AssetClass] [Int] not null,    
        [CurrentValue] [float],    
        [CurrentDep] [float],    
        [CumulativeDep][float],    
        [BookValue][float],     
        [Posted][VARCHAR](3) not null        
)     
    
    
ALTER TABLE #ShowDep WITH NOCHECK ADD      
                
 CONSTRAINT [PK_ShowDep] PRIMARY KEY  NONCLUSTERED     
 (    
   [SchemeNo],    
   [PropertyCode],    
   [ValueDate],    
   [AssetClass]         
 )     
end    
    
declare @CurrentValue float,@CurrentDep float, @CumulativeDep float,    
        @BookValue float,@ValueDate Datetime, @UpToDate datetime,@DepValueDate Datetime,    
        @Posted VARCHAR(3)  
    
   
SELECT @UpToDate = Max(ValueDate),@ValueDate = Min(ValueDate) from depreciation where schemeNo = @SchemeNo  
and PropertyCode = @AssetNo  
  
select @CurrentValue = AssetCost from Assets where schemeNo = @SchemeNo  
and AssetNo = @AssetNo  
  
   declare Bcsr Cursor for    
   select DepValue,ValueDate,CASE Posted WHEN 0 THEN 'No'
                                         when 1 THEN 'Yes' end as Posted1   
   from depreciation    
   where     
   SchemeNo = @schemeNo and PropertyCode = @AssetNo and AssetClass = @AssetClass    
   and Valuedate >= @ValueDate and Valuedate <= @UpToDate    
    
   Open Bcsr    
    
   Fetch from Bcsr Into @CurrentDep,@DepValueDate,@Posted    
   while @@fetch_Status = 0    
   begin    
    
      select @CumulativeDep = sum(DepValue)    
      from depreciation    
      where     
      SchemeNo = @schemeNo and PropertyCode = @AssetNo and AssetClass = @AssetClass    
      and Valuedate <= @DepValueDate     
    
      Insert Into #ShowDep    
      (schemeNo,PropertyCode,ValueDate,AssetClass,CurrentValue,CurrentDep,CumulativeDep,bookValue,Posted)    
      values    
      (@schemeNo,@Assetno,@DepValueDate,@AssetClass,@CurrentValue,@CurrentDep,@CumulativeDep,@CurrentValue-@CumulativeDep,@Posted)    
          
      select @CumulativeDep = 0    
      Fetch next from Bcsr Into @CurrentDep,@DepValueDate,@Posted    
   end    
   Close bcsr    
   Deallocate bcsr    
      
select * from #ShowDep     
order by valueDate
go

