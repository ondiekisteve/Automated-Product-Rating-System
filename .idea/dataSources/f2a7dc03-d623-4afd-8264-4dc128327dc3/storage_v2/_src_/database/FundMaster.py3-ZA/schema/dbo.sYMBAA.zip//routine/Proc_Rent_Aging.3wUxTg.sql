CREATE PROCEDURE [dbo].[Proc_Rent_Aging]  
@SchemeNo Int,    
@PropCode Int,    
@AsAtDate datetime    
as    
    
    
if object_id('tempdb..#Rent_Aging') is null    
create Table #Rent_Aging    
 (    
  Table_Count int identity(1,1) not null,    
  Tenant_Code int ,    
  Tenant_Name varchar(150) null,    
  Monthly float,    
  Aging float not null,    
  Up_To_30 float,    
  _30_To_60 float,    
  _60_To_90 float,    
  _90_To_1Year float,    
  Over1Year float,    
  Total float,    
  PropertyName varchar(120),    
  AsatDate datetime    
 )    
    
    
declare    
    
 @TenantCode Int,    
 @TenantName varchar(100),    
 @Monthly float,    
 @Invoiced float,    
 @Paid float,    
 @Balance float,    
 @Arrears float,    
 @Prepay float,    
 @Months float,    
 @ClosingDate datetime,    
 @OpeningDate datetime,    
 @PropertyName varchar(100)    
    
    
select @PropertyName = PropertyName from Property where SchemeNo = @schemeNo and PropertyCode = @PropCode    
    
select @OpeningDate = StartDate,@ClosingDate = StartDate - 1    
from schemeYears where schemeNo = @schemeNo and Startdate <= @AsAtDate and EndDate >= @AsAtDate    
    
     
declare acsr cursor for    
    
Select t.TenantCode,t.tenantname,l.Rent    
from Leases l    
inner join Tenants t on l.TenantCode = t.TenantCode where l.LeaseCancelled = 0 and l.PropertyCode = @PropCode 
  
    
open acsr    
    
fetch from acsr into @TenantCode,@TenantName,@Monthly    
    
 while @@fetch_status = 0    
    
 begin    
       
   select @Balance  = Balance, @Prepay = PrePayment from RentPreBalance where TenantCode = @TenantCode and BalanceDate = @ClosingDate--'Jun 30'    
   select @Invoiced = sum(Rent) from RentInvoice where TenantCode = @TenantCode and InvoiceDate >= @OpeningDate    
   select @Paid     = sum(Amount) from RentReceipts where TenantCode = @TenantCode and PayDate >= @OpeningDate and PayDate <= @AsAtDate     
    
   if @Balance is null select @Balance = 0    
   if @Invoiced is null select @Invoiced = 0    
   if @Paid is null select @Paid = 0    
   if @Prepay is null select @Prepay = 0    
    
   select @Arrears = (@Paid + @Prepay) - (@Invoiced + @Balance)

   
   if ((@Arrears < 0) and (@Monthly > 0)) 
      BEGIN  

      SELECT @Arrears = 0 - @Arrears 
      select @Months = @Arrears/@Monthly 
      END   
   else    
      select @Months = 0    
    
   if @Months > 0    
      begin    
    
      if @Months <= 1    
         Insert into #Rent_Aging select @TenantCode,@TenantName,@Monthly,@Months,@Arrears,0,0,0,0,@Arrears,@PropertyName,@AsAtDate    
      else if @Months > 1 and @Months <= 2    
         Insert into #Rent_Aging select @TenantCode,@TenantName,@Monthly,@Months,0,@Arrears,0,0,0,@Arrears,@PropertyName,@AsAtDate    
      else if @Months > 2 and @Months <= 3    
         Insert into #Rent_Aging select @TenantCode,@TenantName,@Monthly,@Months,0,0,@Arrears,0,0,@Arrears,@PropertyName,@AsAtDate    
      else if @Months > 3 and @Months <= 12    
         Insert into #Rent_Aging select @TenantCode,@TenantName,@Monthly,@Months,0,0,0,@Arrears,0,@Arrears,@PropertyName,@AsAtDate    
      else if @Months > 12    
         Insert into #Rent_Aging select @TenantCode,@TenantName,@Monthly,@Months,0,0,0,0,@Arrears,@Arrears,@PropertyName,@AsAtDate    
      end    
     
     select  @TenantCode=0,@Monthly=0,@Arrears = 0,@Months = 0,@Paid=0,@Prepay=0,@Invoiced=0,@Balance=0    
         
    
   fetch next from acsr into @TenantCode,@TenantName,@Monthly    
end    
close acsr    
deallocate acsr    
    
select * from #Rent_Aging ORDER BY Aging
go

