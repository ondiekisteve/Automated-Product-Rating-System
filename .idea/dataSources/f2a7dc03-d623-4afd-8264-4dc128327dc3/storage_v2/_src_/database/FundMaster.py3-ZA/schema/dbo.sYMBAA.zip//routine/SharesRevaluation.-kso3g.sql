CREATE PROCEDURE [dbo].[SharesRevaluation]
@SchemeNo Varchar(15),
@Quarter Int,
@FiscalYear Int,
@simCode varchar(15)
--with Encryption
as

if object_id('tempdb..#SaleofInvest') is null

begin
create table #SaleofInvest
(       [InvNo][Int] identity(1,1),
	[InvestCode] [int] NOT NULL ,
	[FiscalQuarter] [Int]NOT NULL ,
        [FiscalYear][Int] not null,
	[QuarterDesc] [varchar](150) not null,
        [Amount] [Float] null default 0.0, 
        [Manager][varchar](100),
        [SimCode][varchar](15),
        [TransDate][Datetime]
) 

ALTER TABLE #SaleofInvest WITH NOCHECK ADD    
	CONSTRAINT [PK_SaleofInvest] PRIMARY KEY  NONCLUSTERED 
	(
	  [InvNo]     
	) 
end

declare @QuarterDesc varchar(150), @Manager varchar(100),
@StartDate Datetime,@EndDate Datetime,@InvestCode Int,@PortFolio varchar(100),@Amount float,
@Vipijo varchar(150),@sponsor varchar(100),@TransDate Datetime,@OldValue float,@NewValue float,
@NoOfShares Int,@MaxDate Datetime,@FiscalMode bit,@SchemeYear Int

select @schemeYear = Max(SchemeYear) from schemeYears where schemeNo like @schemeNo

select @FiscalMode = FiscalMode from schemeYears where schemeNo like @schemeNo
and SchemeYear= @schemeYear

if @FiscalMode = 0 /* January -December */
begin
if @Quarter = 1
   begin
     Exec GetFirstDate 1,@FiscalYear,@StartDate Out
     Exec GetLastDate 3,@FiscalYear,@EndDate Out

     Select @QuarterDesc = '1 ST Quarter '+cast(@FiscalYear as varchar(4))
   end
else if @Quarter = 2
   begin
     Exec GetFirstDate 4,@FiscalYear,@StartDate Out
     Exec GetLastDate 6,@FiscalYear,@EndDate Out

     Select @QuarterDesc = '2 ND Quarter '+cast(@FiscalYear as varchar(4))
   end
else if @Quarter = 3
   begin
     Exec GetFirstDate 7,@FiscalYear,@StartDate Out
     Exec GetLastDate 9,@FiscalYear,@EndDate Out

     Select @QuarterDesc = '3 RD Quarter '+cast(@FiscalYear as varchar(4))
   end
else if @Quarter = 4
   begin
     Exec GetFirstDate 10,@FiscalYear,@StartDate Out
     Exec GetLastDate 12,@FiscalYear,@EndDate Out

     Select @QuarterDesc = '4 TH Quarter '+cast(@FiscalYear as varchar(4))
   end
end
else if @FiscalMode = 1 /* July-june */   
begin
   if @Quarter = 1
   begin
     Exec GetFirstDate 7,@FiscalYear,@StartDate Out
     Exec GetLastDate 9,@FiscalYear,@EndDate Out

     Select @QuarterDesc = '1 ST Quarter '+cast(@FiscalYear as varchar(4))
   end
else if @Quarter = 2
   begin
     Exec GetFirstDate 10,@FiscalYear,@StartDate Out
     Exec GetLastDate 12,@FiscalYear,@EndDate Out

     Select @QuarterDesc = '2 ND Quarter '+cast(@FiscalYear as varchar(4))
   end
else if @Quarter = 3
   begin
     Exec GetFirstDate 1,@FiscalYear,@StartDate Out
     Exec GetLastDate 3,@FiscalYear,@EndDate Out

     Select @QuarterDesc = '3 RD Quarter '+cast(@FiscalYear as varchar(4))
   end
else if @Quarter = 4
   begin
     Exec GetFirstDate 4,@FiscalYear,@StartDate Out
     Exec GetLastDate 6,@FiscalYear,@EndDate Out

     Select @QuarterDesc = '4 TH Quarter '+cast(@FiscalYear as varchar(4))
   end
end

   select @Manager = ManagerName from InvestmentManagers
   where schemeNo like @schemeNo and simCode = @simCode

   
   /* Shares Revaluation */
   declare bcsr cursor for
   select s.EquityNo,e.NoOfShares,s.PricePerShare,i.InvName,s.PriceDate
   from EquityValue s
        inner Join Equity e on s.schemeno like e.schemeNo and s.EquityNo = e.EquityNo
        and e.Manager = @simCode
        inner Join Investments i on s.schemeno like i.schemeNo and s.EquityNo = i.InvCode
   where s.schemeNo like @schemeNo 
   and s.PriceDate >= @StartDate and s.PriceDate <= @EndDate

   Open Bcsr

   fetch from Bcsr into @InvestCode,@NoOfShares,@NewValue,@PortFolio,@TransDate
   while @@fetch_Status = 0
   begin
     
     
     if Exists(select * from EquityValue where schemeNo like @schemeNo and EquityNo= @InvestCode)
        begin
        select @MaxDate = Max(PriceDate) from EquityValue where schemeNo like @schemeNo and EquityNo= @InvestCode
        and PriceDate < @StartDate

        select @OldValue = PricePerShare from EquityValue where schemeNo like @schemeNo and EquityNo= @InvestCode
        and PriceDate = @MaxDate
        
        if @MaxDate is null
           select @OldValue = PricePerShare from Equity where schemeNo like @schemeNo and EquityNo= @InvestCode
        end
     else 
        select @OldValue = PricePerShare from Equity where schemeNo like @schemeNo and EquityNo= @InvestCode

     
     Select @Amount = (@NewValue - @OldValue)* @NoOfShares

     if @Amount < 0
        begin
        select @Vipijo = '(Loss) '+ @Portfolio+' Revaluation (from '+cast(@OldValue as varchar(10)) +' to '+cast(@NewValue as varchar(10))+' per Share for '+cast(@NoOfShares as varchar(10))+'  shares) for '+ @QuarterDesc +' - '+@Manager
        select @Amount = 0-@Amount
       end
     else
         select @Vipijo = '(Gain) '+ @Portfolio+' Revaluation (from '+cast(@OldValue as varchar(10)) +' to '+cast(@NewValue as varchar(10))+' per Share for '+cast(@NoOfShares as varchar(10))+'  shares) for '+ @QuarterDesc +' - '+@Manager
    
     
    if not Exists(select * from SchemeGeneralLedger
               where schemeNo like @schemeNo and Description = @vipijo) 
     Insert Into #SaleofInvest
     (InvestCode,FiscalQuarter,FiscalYear,QuarterDesc,Amount,Manager,TransDate)
     Values
     (@InvestCode,@Quarter,@FiscalYear,@Vipijo,@Amount,@Manager,@TransDate)

     select @Amount = 0, @Vipijo = '',@NewValue = 0,@OldValue = 0,@MaxDate =''

     fetch next from Bcsr into @InvestCode,@NoOfShares,@NewValue,@PortFolio,@TransDate
   end
   Close Bcsr
   Deallocate Bcsr

  update #SaleofInvest set simCode = @simCode
  select * from #SaleofInvest
go

