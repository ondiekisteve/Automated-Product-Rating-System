CREATE PROCEDURE [dbo].[Proc_TBL_Indiv_Policies]    
@SCHEMENO Int,    
@MemberNo Int,    
@PolicyNo Int,    
@PolicyRef varchar(50),    
@StartDate Datetime,    
@EndDate Datetime,    
@MonthlyPremium float,    
@RetirementAge Integer,    
@AddEdit Int,  
@PayMode Int,  
@AgentCode Int    
--with Encryption    
as    
    
DECLARE @DOB Datetime    
if @AddEdit = 0    
begin    
    
  select @DOB = DOB from Members    
  where schemeNo = @schemeNo and MemberNo = @MemberNo    
    
  SELECT @EndDate = DateAdd(Year,@RetirementAge,@DOB)    
    
  Insert into TBL_Indiv_Policies(schemeNo,MemberNo,PolicyRef,StartDate,EndDate,MonthlyPremium,RetirementAge,PayMode,AgentCode)    
                        Values(@schemeNo,@MemberNo,@PolicyRef,@StartDate,@EndDate,@MonthlyPremium,@RetirementAge,@PayMode,@AgentCode)    
end    
else    
begin    
  Update TBL_Indiv_Policies set PolicyRef = @PolicyRef,StartDate = @StartDate,EndDate = @EndDate,    
                                MonthlyPremium = @MonthlyPremium,RetirementAge = @RetirementAge,  
                                PayMode = @PayMode,AgentCode = @AgentCode     
  where PolicyNo = @PolicyNo    
end
go

