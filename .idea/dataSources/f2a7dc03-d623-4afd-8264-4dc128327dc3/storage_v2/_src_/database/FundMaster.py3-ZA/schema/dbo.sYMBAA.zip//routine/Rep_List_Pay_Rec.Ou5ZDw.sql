CREATE PROCEDURE [dbo].[Rep_List_Pay_Rec]                    
@schemeNo Int,                    
@BankCode Int,                    
@StartDate Datetime,                    
@EndDate Datetime,                    
@Pay_Rec Int,/* 0 - Payments, 1 - Receipts */                    
@RepMode Int, /* 0 - All, 1 - Categorised */
@CurrMode Int                    
--with Encryption                    
as                    
if object_id('tempdb..#Rep_List_Pay_Rec') is null                        
begin                          
create table #Rep_List_Pay_Rec                          
(                          
 [glcode] [int] IDENTITY(1,1) Primary Key ,                          
 [BankCode] [varchar](15) NOT NULL ,                          
 [BankName] [varchar](120),                    
 [TransDate][Datetime],                         
 [CashDesc] [varchar](120),                     
 [ChequeNo] [varchar](50),                
 [PVNO][Varchar](20),                    
 [Amount] [Decimal](20,2),                    
 [StartDate][Datetime],                    
 [EndDate][Datetime],                    
 [TransType][varchar](100),                    
 [ReportDesc][varchar](100),                    
 [SchemeName][varchar](100),                    
 [ColTitle][varchar](30),                
 [TransCategory][varchar](100)                                        
 )                           
end                          
                    
DECLARE @BankName varchar(100),@schemeName varchar(100)                    
select @BankName = BankName from SchemeBankBranch where schemeNo = @schemeNo and BankCode = @BankCode                    
                    
select @schemeName = schemeName from scheme where schemeCode = @schemeNo                  
                         
if @Pay_Rec = 0 /* Payments */                    
begin
  if @CurrMode = 0 /* Functional */  
   begin                    
   if @RepMode = 0 /* All categories */                    
      Insert into #Rep_List_Pay_Rec select c.BankCode,@BankName,c.ChequeDate,c.Description,c.ChequeNo,c.VoucherNo,
            c.Credit * c.SpotRate,@StartDate,@EndDate,                    
            'All','PAYMENTS LISTING',@schemeName,'Cheque No',e.ExpenditureDesc                    
            from CashBook c                 
                 inner join ExpenditureItems e on c.ExpenditureCode = e.ExpenditureCode                  
            where c.schemeCode = @schemeNo and c.BankCode = @BankCode and c.ChequeDate >= @StartDate                    
            and c.ChequeDate <= @EndDate and c.Credit > 0 AND c.Tran_Status = 0 AND c.Posted = 1               
   else if @RepMode = 1                    
      Insert into #Rep_List_Pay_Rec select c.BankCode,@BankName,c.ChequeDate,c.Description,c.ChequeNo,c.VoucherNo,
            c.Credit * c.SpotRate,@StartDate,@EndDate,                    
            E.ExpenditureDesc,'PAYMENTS LISTING',@schemeName,'Cheque No',e.ExpenditureDesc                    
            from CashBook c                    
            inner join ExpenditureItems E ON C.ExpenditureCode = e.ExpenditureCode                  
            where c.schemeCode = @schemeNo and c.BankCode = @BankCode and c.ChequeDate >= @StartDate                    
            and c.ChequeDate <= @EndDate and c.Credit > 0 AND c.Tran_Status = 0 AND c.Posted = 1 
   end
 else if @CurrMode = 1 /* Source */  
   begin                    
   if @RepMode = 0 /* All categories */                    
      Insert into #Rep_List_Pay_Rec select c.BankCode,@BankName,c.ChequeDate,c.Description,c.ChequeNo,c.VoucherNo,c.Credit,@StartDate,@EndDate,                    
            'All','PAYMENTS LISTING',@schemeName,'Cheque No',e.ExpenditureDesc                    
            from CashBook c                 
                 inner join ExpenditureItems e on c.ExpenditureCode = e.ExpenditureCode                  
            where c.schemeCode = @schemeNo and c.BankCode = @BankCode and c.ChequeDate >= @StartDate                    
            and c.ChequeDate <= @EndDate and c.Credit > 0 AND c.Tran_Status = 0 AND c.Posted = 1               
   else if @RepMode = 1                    
      Insert into #Rep_List_Pay_Rec select c.BankCode,@BankName,c.ChequeDate,c.Description,c.ChequeNo,c.VoucherNo,c.Credit,@StartDate,@EndDate,                    
            E.ExpenditureDesc,'PAYMENTS LISTING',@schemeName,'Cheque No',e.ExpenditureDesc                    
            from CashBook c                    
            inner join ExpenditureItems E ON C.ExpenditureCode = e.ExpenditureCode                  
            where c.schemeCode = @schemeNo and c.BankCode = @BankCode and c.ChequeDate >= @StartDate                    
            and c.ChequeDate <= @EndDate and c.Credit > 0 AND c.Tran_Status = 0 AND c.Posted = 1 
   end                
end                    
else if @Pay_Rec = 1 /* Receipts */                    
begin
 if @CurrMode = 0 /* Functional */  
  begin                     
   if @RepMode = 0 /* All categories */                    
      Insert into #Rep_List_Pay_Rec select c.BankCode,@BankName,c.TransDate,c.Description,c.ReceiptNo,' ',c.Debit * c.SpotRate,@StartDate,@EndDate,                    
            'All','RECEIPTS LISTING',@schemeName,'Receipt No',E.IncomeDesc                    
            from CashBook c                 
            inner join IncomeItems E ON C.IncomeCode = e.IncomeCode                   
            where c.schemeCode = @schemeNo and c.BankCode = @BankCode and c.ChequeDate >= @StartDate                    
            and c.ChequeDate <= @EndDate and c.Debit > 0 AND c.Tran_Status = 0 AND c.Posted = 1                  
   else if @RepMode = 1                   
      Insert into #Rep_List_Pay_Rec select c.BankCode,@BankName,c.TransDate,c.Description,c.ChequeNo,' ',c.Debit * c.SpotRate,@StartDate,@EndDate,                    
  E.IncomeDesc,'RECEIPTS LISTING',@schemeName,'Receipt No',E.IncomeDesc                     
            from CashBook c         
            inner join IncomeItems E ON C.IncomeCode = e.IncomeCode                
            where c.schemeCode = @schemeNo and c.BankCode = @BankCode and c.ChequeDate >= @StartDate                    
            and c.ChequeDate <= @EndDate and c.Debit > 0  AND c.Tran_Status = 0 AND c.Posted = 1 
 end
else if @CurrMode = 1 /* Source */  
  begin                     
   if @RepMode = 0 /* All categories */                    
      Insert into #Rep_List_Pay_Rec select c.BankCode,@BankName,c.TransDate,c.Description,c.ReceiptNo,' ',c.Debit,@StartDate,@EndDate,                    
            'All','RECEIPTS LISTING',@schemeName,'Receipt No',E.IncomeDesc                    
            from CashBook c                 
            inner join IncomeItems E ON C.IncomeCode = e.IncomeCode                   
            where c.schemeCode = @schemeNo and c.BankCode = @BankCode and c.ChequeDate >= @StartDate                    
            and c.ChequeDate <= @EndDate and c.Debit > 0 AND c.Tran_Status = 0 AND c.Posted = 1                  
   else if @RepMode = 1                   
      Insert into #Rep_List_Pay_Rec select c.BankCode,@BankName,c.TransDate,c.Description,c.ChequeNo,' ',c.Debit,@StartDate,@EndDate,                    
  E.IncomeDesc,'RECEIPTS LISTING',@schemeName,'Receipt No',E.IncomeDesc                     
            from CashBook c         
            inner join IncomeItems E ON C.IncomeCode = e.IncomeCode                
            where c.schemeCode = @schemeNo and c.BankCode = @BankCode and c.ChequeDate >= @StartDate                    
            and c.ChequeDate <= @EndDate and c.Debit > 0  AND c.Tran_Status = 0 AND c.Posted = 1 
 end                
end                    
                
update #Rep_List_Pay_Rec set ChequeNo = ' ' WHERE ChequeNo = '0'              
              
if @RepMode = 0              
   select * from #Rep_List_Pay_Rec order by TransDate,glcode              
ELSE                   
   select * from #Rep_List_Pay_Rec order by TransCategory,TransDate,glcode
go

