/*        
MODIFICATIONS:        
11/03/2004        
        
Added :        
           Fields:        
           PreparedBy,CheckedBy,AuthorisedBy        
           Variables:        
           @PreparedBy,@CheckedBy,@AuthorisedBy        
           Code:        
           select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo        
           Insert these extra fields in the Temp Table        
*/        
CREATE PROCEDURE [dbo].[RepCalculationSheet_AVC]        
@SCHEMENO Int,        
@memberNo int        
--with Encryption        
as        
        
set nocount on        
        
if object_id('tempdb..#Calculation') is null        
        
begin        
create table #Calculation        
(        
   [SchemeNo] [int] NOT NULL ,        
    [MemberNo] [int] NOT NULL ,        
                [schemeName][varchar](100) not null,       
  [IDNumber][varchar](20) null,       
                [fullname][varchar](100) not null,        
                [DJE][Datetime] not null,        
                [djpens][datetime] not null,        
    [EmpOpeningBal] [float] NULL ,        
                [EmprOpeningBal][float] NULL,         
   [EmpContributions] [float]  NULL ,        
                [EmprContributions] [float]  NULL ,         
                [EmpClosing][float] null,        
                [EmprClosing][float] null,        
                [interest] [float]  NULL ,        
                [DateOfExit][datetime] not null,        
    [curYear] [int]  NULL ,        
    [PastService] [varchar](100) NULL,        
                [BenefitsDC] [float]   NULL ,        
                [Vesting][float]null,        
                [TaxfreeLumpsum][float] null,        
                [WithHoldingTax][float] null,        
                [comments][varchar](50)  null,        
                [empInt][float] null,        
                [emprInt][float] null,        
                [AmountPayable][float] null,        
                [TaxableAmount][float] null,        
                [LastYear][Int],        
                [EndDate][Datetime],        
                [PreparedBy][varchar](100),        
                [CheckedBy][varchar](100),        
                [AuthorisedBy][varchar](100),        
                [ClosingBalance][float],        
                [Bonus][float],        
                [AuditedBy][Varchar](100),        
                [DateAudited][Datetime],        
                        
                 [doBirth][Datetime],        
                 [DoCalc][Datetime],        
                [DatePrepared][Datetime],        
                [DateChecked][Datetime],        
                [DateAuthorised][Datetime],        
                [Reason][varchar](50),  
  [PoolName][varchar](120) null                  
)         
        
ALTER TABLE #Calculation WITH NOCHECK ADD                     
 CONSTRAINT [PK_Calculation] PRIMARY KEY  NONCLUSTERED         
 (        
  [SchemeNo],        
  [memberNo]              
 )         
end        
        
        
declare @fullname varchar(100)        
declare @schemeName varchar(100),@IDNumber varchar(20)        
declare @empopening float        
declare @emprOpening float        
declare @empContribution float        
declare @emprContribution float        
declare @empClosing float        
declare @emprClosing float        
declare @interest float        
declare @DateOfExit datetime        
declare @pastService int        
declare @BenefitsDC Float        
declare @vesting float        
declare @taxfreelumpsum float        
declare @withHoldingTax float        
declare @dje datetime        
declare @djpens datetime        
declare @curYear int        
declare @comments varchar(50)        
declare @VestedCont float        
declare @EmpInt float        
declare @Emprint float        
declare @GrandTotal float        
declare @TaxAmount float        
declare @Doexit datetime        
declare @CurMonth int        
declare @AcctPeriod int, @DoCalc Datetime,@EndDate Datetime,@TaxType Int,@DesignCode int,@Title varchar(20),@ServiceTime varchar(100),        
@PreparedBy varchar(100),@CheckedBy varchar(100),@AuthorisedBy varchar(100),@NumDays Int,@NumMonths Int,@NumYears Int,@rExit Int,@StartDate datetime,@eDate Datetime,        
@YaConversion Varchar(20),@Chapaa Decimal(20,6),@MwishoDate Datetime,@OptionToUse int,@AuditedBy Varchar(100),        
@DateAudited Datetime,@DatePrepared Datetime,@DateChecked Datetime,@DateAuthorised Datetime,@doBirth Datetime,@Reason varchar(50),  
@PooledInvestment smallInt,@InvestmentScheme Int,@PoolName varchar(120)  
        
Exec EmployerOption @schemeNo,@MemberNo,@OptionToUse Out /* PROCEDURE DBO.to Incorporate Budget changes 2005 */        
        
        
 select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy,        
 @DatePrepared = DatePrepared,@DateChecked = DateChecked,@DateAuthorised  = DateAuthorised         
 from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo        
        
select @Doexit = Doexit, @DoCalc = DoCalc,@DesignCode = DesignCode,@rExit = ReasonforExit,@DoBirth = Dob  from Members where SchemeNo = @schemeNo and MemberNo = @MemberNo        
        
Select @Reason = ReasonDesc from ReasonforExit        
        where ReasonCode = @rExit        
        
select @CurMonth = datepart(Month, @DoCalc)        
select @CurYear = datepart(Year, @DoCalc)        
if @DesignCode is null select @DesignCode = 0        
        
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out        
        
select @EndDate = EndDate from SchemeYears where SchemeNo = @SchemeNo and AcctPeriod = (@AcctPeriod -1)        
        
select @Edate = EndDate,@StartDate = StartDate from SchemeYears where SchemeNo = @SchemeNo and AcctPeriod = @AcctPeriod        
        
select @MwishoDate = @Edate        
        
select @schemeName = schemeName,@PooledInvestment = PooledInvestment,@InvestmentScheme = InvestmentScheme  
 from scheme where schemeCode = @schemeNo  
  
if @PooledInvestment = 1            
select @PoolName = schemeNAME FROM Scheme where schemeCode = @InvestmentScheme             
else if @PooledInvestment = 0            
select @PoolName = ' '       
        
declare GenCursor cursor for        
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,         
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,m.IDNumber,        
               b.calcYear, b.interestrate, b.VolcBal + b.PreAVCCBal,b.SpecialCBal,b.withholdingTax, b.taxfreeLumpsum, b.vesting, b.comments,b.VestedCont        
             from Members m        
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo        
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo        
                     
        
open GenCursor        
        
fetch from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @fullname,@IDNumber,  @curYear, @interest,        
 @empclosing, @emprclosing, @withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont        
        
while @@fetch_status =0        
begin        
        
        select @eDate = @DoExit        
        /* FOR AFFS */        
                
        
        select @empContribution = sum(Volcontr),@emprContribution = sum(specialcontr)         
        from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo and AcctPeriod = @AcctPeriod        
        and DatePaid >= @StartDate and DatePaid <= @MwishoDate         
                
        if @EmpContribution is null select @EmpContribution = 0        
        if @EmprContribution is null select @EmprContribution = 0        
                
        Exec GetServiceTime @djpens,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out        
        select @ServiceTime = cast(@NumYears as Varchar(2)) +' Years, '+ cast(@NumMonths as varchar(2))+'  months and '+cast(@NumDays as Varchar(2))+' days '        
        select @PastService = (@NumYears * 12) + @NumMonths        
        
        Select @EmpOpening = empVolCont + PreAvc,         
        @EmprOpening = EmprVolCont from MemberOpeningBalances         
        where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1        
        
        if @empOpening is null select @empOpening = 0        
                
        if @emprOpening is null select @emprOpening = 0        
        
        select @EmpInt = @empClosing - (@EmpOpening + @EmpContribution)        
        select @EmprInt = @emprClosing - (@EmprOpening + @EmprContribution)        
         
        
        select @VestedCont = @EmprClosing * @Vesting/100.000        
        
        if @OptionToUse = 0        
           begin        
             if (@Vesting  = 100.00 )        
               select @GrandTotal =  @EmpClosing  + @EmprClosing        
             else        
               select @GrandTotal =  @EmpClosing + @VestedCont        
           end        
        else if @OptionToUse = 1        
           begin        
              select @GrandTotal =  @EmpClosing, @VestedCont = 0        
   end        
        else if @OptionToUse = 2        
           begin        
             select @GrandTotal =  @EmpClosing  + @EmprClosing,@VestedCont = @EmprClosing         
           end        
        
                
        IF @Rexit = 8 /* Transfers */        
        begin        
           Select @TaxAmount = 0,@TaxFreeLumpsum = 0,@WithHoldingTax = 0        
        end        
        else        
        begin            
            select  @TaxAmount = @GrandTotal - @TaxFreeLumpsum        
        
   if @TaxAmount < 0 select @TaxAmount = 0        
        
            Exec GetTaxType @SchemeNo,@MemberNo,@TaxType Out        
        
            exec CalculateTax @SchemeNo,@TaxAmount,@Doexit, @TaxType,@WithHoldingTax out        
        end        
        
      if @DesignCode > 0        
          begin        
          select @Title = Designation from Designation where DesignCode = @DesignCode        
        
          select @FullName = upper(@Title) +'  '+@FullName        
          end        
        if ((@EmpContribution= 0) and (@EmprContribution = 0))        
          begin        
                raiserror('Cannot generate report, The Member doesn''t have any registered Voluntary Contributions',16,1)        
  close GenCursor        
  deallocate GenCursor      
                return        
          end        
        else        
        
          /* rounding  Grand Total*/        
              select @YaConversion = cast(@GrandTotal as Varchar(25))        
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out        
              select @GrandTotal = @Chapaa        
              select @Chapaa = 0        
        
        /* rounding  Grand Total*/        
              select @YaConversion = cast(@WithholdingTax as Varchar(25))        
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out        
              select @WithholdingTax = @Chapaa        
              select @Chapaa = 0        
        
         insert into #calculation (schemeNo, MemberNo, schemeName, fullname, dje, djpens, empopeningBal, emprOpeningBal,        
                     empcontributions, emprContributions,empclosing, emprClosing,interest, dateofexit,        
                     curYear, pastService, benefitsDC, TaxfreeLumpsum,withHoldingTax,Vesting, Comments, EmprInt, EmpInt, AmountPayable, TaxableAmount,        

                     LastYear,EndDate,PreparedBy,CheckedBy,AuthorisedBy,Bonus,ClosingBalance,AuditedBy,DateAudited,DoBirth,DoCalc,DatePrepared,DateChecked,DateAuthorised,        
                     Reason,IDNumber,PoolName)        
                 
         values(@schemeNo, @memberNo,@schemeName, @fullname, @dje, @djpens, @empOpening, @emprOpening, @empcontribution, @emprContribution, @empclosing, @emprClosing,        
                @interest, @dateofExit, @curYear, @ServiceTime, @GrandTotal, @taxfreeLumpsum, @withHoldingTax, @vesting, @comments, @EmprInt, @EmpInt, @GrandTotal - @WithholdingTax, @TaxAmount,        
                @curYear -1,@EndDate,@PreparedBy,@CheckedBy,@AuthorisedBy,0,@GrandTotal,@AuditedBy,@DateAudited,@DoBirth,@DoCalc,@DatePrepared,@DateChecked,@DateAuthorised,        
                 @Reason,@IDNumber,@PoolName)        
        
        
            
     fetch next from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @fullname,@IDNumber, @curYear, @interest,        
              @empclosing, @emprclosing, @withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont        
          
end        
        
close GenCursor        
deallocate GenCursor        
        
        
select * from #calculation
go

