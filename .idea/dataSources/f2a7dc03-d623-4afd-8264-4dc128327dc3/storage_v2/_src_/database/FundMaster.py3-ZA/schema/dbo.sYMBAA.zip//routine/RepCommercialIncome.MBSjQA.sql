CREATE PROCEDURE [dbo].[RepCommercialIncome]    
@SCHEMENO Int,    
@startDate Datetime,    
@EndDate Datetime    
--with Encryption    
as    
    
    
if object_id('tempdb..#RepCommercial') is null    
    
begin    
create table #RepCommercial    
(    
        [PayCode][Int] Primary Key,
        [SchemeName] [varchar](120) NOT NULL ,    
        [GovernNo][Int] not null,    
        [DateInvested][Datetime] not null,    
        [GovernName][varchar](50),    
        [GovernDesc] [varchar](100) NOT NULL ,    
        [Amount][float],    
        [NorminalValue][float] default 0.0,    
        [InterestRate][float] not null,    
        [MaturityDate][Datetime],    
        [Interest][float],    
        [Period][varchar](30),  
        [StartDate][Datetime],  
        [EndDate][Datetime],
        [IncomeDate][datetime]
               
)          
end    
    

    
Insert into #RepCommercial  Select  gi.PayCode,s.SchemeName,i.InvCode,i.DateComm,    
            i.Invname,i.Description,    
            g.AmountInvested,g.NominalValue,    
            g.InterestRate,g.MaturityDate,gi.Interest,'',@StartDate,@EndDate,gi.PaperDate    
       from CommercialIncome gi    
            inner join scheme s on gi.SchemeNo = s.SchemeCode    
            inner Join CommercialPaper g on gi.PaperNo = g.PaperNo    
                  and gi.SchemeNo = g.SchemeNo    
            inner Join Investments i on gi.PaperNo = i.InvCode    
                  and gi.SchemeNo = i.SchemeNo     
       where gi.SchemeNo = @schemeNo and gi.PaperDate >= @StartDate and gi.PaperDate <= @EndDate    
    

    
Select * from #RepCommercial
go

