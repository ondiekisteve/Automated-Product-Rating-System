










































CREATE PROCEDURE repGroupUnit
@SCHEMENO Int
--with Encryption
as
if exists (select * from sysobjects where id = object_id(N'#tempGroups') and objectproperty(id, N'IsUserTable') = 1)
  drop table #tempGroups
create table #tempGroups
(
  SchemeNo varchar(15),
  MemberNo int,
  AgeCaption varchar(15),
  upperBound int,
  MembAge float,
  primary key (MemberNo, AgeCaption)
)
insert #tempGroups
select
Members.SchemeNo,
Members.MemberNo,
Ages.Caption,
Ages.UpperBound,
datediff(year, Members.DOB, getdate())
from Members
inner join Ages on (datediff(year, Members.DOB, getdate()) >= Ages.LowerBound) and
         (datediff(year, Members.DOB, getdate()) <= Ages.UpperBound)
where (Members.SchemeNo = @SchemeNo)  and (Members.ReasonForExit = 0) 

declare @ContrYear  int

select @contrYear = Max(SchemeYear) from schemeYears where schemeNo = @schemeNo

declare @currCover float
select @currCover = AmtCov from amountOfCover where SchemeNo = @schemeNo and ClassId ='N/A'

declare @Unitrate float
select @unitrate = Min(unitrate) from unitrate where insurecode = (select insurecode from scheme where schemecode = @schemeNo)

select
#tempGroups.SchemeNo,
@currCover as AmtCov,
#tempGroups.AgeCaption,
count(*) as NumMembers,
(sum(#tempGroups.MembAge) / (count(*))) as AvgAge,
sum(c.Salary* 12) as TotSalary,
(sum(c.salary*12) * @currCover) as sumAssured,
((sum(c.salary*12)*@currCover) * (@unitrate/10.0000000000)) as unitrate
from Members
   inner join #tempGroups on (#tempGroups.SchemeNo = Members.SchemeNo) and (#tempGroups.MemberNo = Members.MemberNo)
   inner join contributionssummary c on (c.SchemeNo = Members.SchemeNo) and (c.MemberNo = Members.MemberNo) and (c.contrmonth = 1) and (c.contrYear= @contrYear)
group by #tempGroups.SchemeNo, #tempGroups.AgeCaption, #tempGroups.upperBound
order by #tempGroups.upperBound


go

