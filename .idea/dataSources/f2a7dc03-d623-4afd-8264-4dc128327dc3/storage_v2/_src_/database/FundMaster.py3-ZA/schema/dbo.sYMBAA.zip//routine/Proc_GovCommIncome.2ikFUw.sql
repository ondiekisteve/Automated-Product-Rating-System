CREATE PROCEDURE [dbo].[Proc_GovCommIncome]  
@schemeNo Int,  
@InvCode Int,  
@PayCode Int,  
@TransMode int  
--with Encryption  
as  
if @TransMode = 0 /* Government Income */  
   Update GovernmentIncome set Posted = 1 where schemeNo = @schemeNo and PayCode = @PayCode  
else if @TransMode = 1 /* Commercial Income */  
   Update CommercialIncome set Posted = 1 where schemeNo = @schemeNo and PayCode = @PayCode  
else if @TransMode = 2 /* Equity Value (Change in Market Value) */  
   Update EquityValue set Posted = 1 where schemeNo = @schemeNo and PayCode = @PayCode  
else if @TransMode = 3 /* Equity Dividends */  
   Update EquityDividends set Posted = 1 where schemeNo = @schemeNo and PayCode = @PayCode  
else if @TransMode = 4 /* Equity Acquisition */  
   Update EquityAcquisition set Posted = 1 where schemeNo = @schemeNo and PayCode = @PayCode  
else if @TransMode = 5 /* Investments Transfer */  
   Update InvestmentsTransfer set Posted = 1 where schemeNo = @schemeNo and TransferCode = @PayCode  
else if @TransMode = 6 /* Investments Transfer */  
   Update EquityRefunds set Posted = 1 where schemeNo = @schemeNo and RefundNo = @PayCode  
else if @TransMode = 7 /* New Investments */  
   Update Investments set Posted = 1 where schemeNo = @schemeNo and InvCode = @PayCode  
else if @TransMode = 8 /* Income Due (Government/Commercial Paper) */  
   Update GovCommIncomeDue set Posted = 1 where schemeNo = @schemeNo and DueCounter = @PayCode
go

