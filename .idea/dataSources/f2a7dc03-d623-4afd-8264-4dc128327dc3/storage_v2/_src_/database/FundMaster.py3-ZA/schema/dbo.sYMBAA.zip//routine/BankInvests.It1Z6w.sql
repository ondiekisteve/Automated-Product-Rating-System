CREATE PROCEDURE [dbo].[BankInvests]
@SCHEMENO Int,
@BankCode varchar(15)
as

if object_id('tempdb..#InvestBanks') is null

begin
create table #InvestBanks
(
        [DepositNo] [Int]NOT NULL ,
        [InvName] [varchar](100) not  NULL,
        [Category][varchar](80),
        [CatClass][varchar](80),
        [Amount][float],
        [InterestRate][float],
        [Manager][varchar](80),
        [AccountNo][varchar](20),
        [DateInvested][Datetime],
        [MaturityDate][datetime] 
) 

ALTER TABLE #InvestBanks WITH NOCHECK ADD 

            
	CONSTRAINT [PK_InvestBanks] PRIMARY KEY  NONCLUSTERED 
	(
	  [DepositNo]      
	) 
end

declare @DepositNo Int,
	@InvName varchar(100),
        @Category varchar(80),
        @CatClass varchar(80),
        @amount float,
        @InterestRate float,
        @Manager varchar(15),@ManagerName varchar(80),
        @AccountNo varchar(15),@DateInvested Datetime,
        @MaturityDate Datetime

/* Cash Deposits */
declare Acsr Cursor for
select c.DepositNo, c.Amount,c.TransDate,c.MaturityDate,
       c.AccountNo,c.InterestRate,
       c.Manager,i.InvestDesc, it.InvestDesc 
from CashDeposits c
     inner Join investmentTypes i on c.deptype = i.InvestCode
     inner Join InvestmentTypeDetail it on c.DepType = it.InvestCode
   and c.DepSubType = it.InvestTypeCode
where c.SchemeNo = @schemeNo and c.BankCode = @BankCode

open acsr
fetch from acsr into @DepositNo,@Amount,@DateInvested,@MaturityDate,@AccountNo,
                     @InterestRate, @Manager,@Category,@CatClass
while @@fetch_Status = 0
begin
   if @Manager is not null
      select @ManagerName = ManagerName from InvestmentManagers
      where SchemeNo = @schemeNo and simCode = @Manager
   else
      select @Manager = 'Self'

   select @InvName = InvName from Investments where SchemeNo = @schemeNo and 
   InvCode = @DepositNo

   Insert Into #InvestBanks(DepositNo,InvName,Category,CatClass,Amount,
                            InterestRate,Manager,AccountNo,DateInvested,
                            MaturityDate)
                Values (@DepositNo,@InvName,@Category,@CatClass,@Amount,
                        @InterestRate,@ManagerName,@AccountNo,@DateInvested,@MaturityDate) 

   select @Amount = 0,@InterestRate = 0, @DepositNo = 0, @Manager = ''
   fetch next from acsr into @DepositNo,@Amount,@DateInvested,@MaturityDate,@AccountNo,
                     @InterestRate, @Manager,@Category,@CatClass
end
Close Acsr
Deallocate Acsr


/* Demand Deposits */
declare Acsr Cursor for
select c.DepositNo, c.Amount,c.AccountNo,c.InterestRate,
       c.Manager
from DemandDeposits c
where c.SchemeNo = @schemeNo and c.BankCode = @BankCode

open acsr
fetch from acsr into @DepositNo,@Amount,@AccountNo,
                     @InterestRate, @Manager
while @@fetch_Status = 0
begin
   if @Manager is not null
      select @ManagerName = ManagerName from InvestmentManagers
      where SchemeNo = @schemeNo and simCode = @Manager
   else
      select @Manager = 'Self'

   select @MaturityDate = ''
   select @InvName = i.InvName,@DateInvested = i.DateComm, 
          @Category = iv.InvestDesc, @CatClass = ivt.InvestDesc 
   from Investments i 
        inner Join investmentTypes iv on i.InvestCode = iv.InvestCode
        inner Join InvestmentTypeDetail ivt on i.InvestCode = ivt.InvestCode
   and i.InvestCodeDetail = ivt.InvestTypeCode
   where i.SchemeNo = @schemeNo and 
   i.InvCode = @DepositNo

   Insert Into #InvestBanks(DepositNo,InvName,Category,CatClass,Amount,
                            InterestRate,Manager,AccountNo,DateInvested,
                            MaturityDate)
                Values (@DepositNo,@InvName,@Category,@CatClass,@Amount,
                        @InterestRate,@ManagerName,@AccountNo,@DateInvested,@MaturityDate) 

   select @Amount = 0,@InterestRate = 0, @DepositNo = 0, @Manager = ''

   fetch next from acsr into @DepositNo,@Amount,@AccountNo,
                     @InterestRate, @Manager
end
Close Acsr
Deallocate Acsr

select * from #InvestBanks Order By DateInvested
go

