CREATE FUNCTION [dbo].[fn_Rebasing_float](@Amount float,@Rounder int)            
returns float             
as              
begin              
declare @ConvAmount float,@RebaseFactor float,@BelowZero smallint             
           
select @RebaseFactor = 1000.00000000           
          
if @Amount < 0          
   begin          
   select @BelowZero = 1          
   select @Amount = ABS(@Amount)          
   end          
else          
   select @BelowZero = 0            
            
IF @Amount > 0   
   begin           
     select @Amount = @Amount/@RebaseFactor         
   end           
        
   select @ConvAmount = @Amount             
        
   if @BelowZero  = 1           
     select @ConvAmount  = 0 - @ConvAmount             
               
 RETURN(@ConvAmount)              
end
go

