
CREATE TRIGGER [dbo].[trg_Contributions_Update]
ON [dbo].[ContributionsSummary]
--with encryption  
FOR UPDATE, DELETE
AS
    SET nocount ON

    DECLARE @schemeNo   INT,
            @AcctPeriod INT,
            @YearClosed INT,
            @statusCode SMALLINT,
            @TransDate  DATETIME

    SELECT @schemeNo = SchemeNo,
           @AcctPeriod = AcctPeriod
    FROM   deleted

    SELECT @YearClosed = YearClosed
    FROM   schemeYears
    WHERE  schemeNo = @schemeNo
           AND AcctPeriod = @AcctPeriod

    IF ( @YearClosed >= 1 )
      BEGIN
          RAISERROR('You cannot UPDATE/DELETE contribution in a closed period',16,1)

          ROLLBACK TRAN
      END

go

