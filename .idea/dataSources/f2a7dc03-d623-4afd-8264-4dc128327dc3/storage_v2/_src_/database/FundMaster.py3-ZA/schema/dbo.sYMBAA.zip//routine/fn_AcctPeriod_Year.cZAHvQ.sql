CREATE FUNCTION [dbo].[fn_AcctPeriod_Year](@SchemeNo Int,@AcctPeriod Int)                           
returns Integer              
as                
begin   
 declare @SchemeYear Int
 
 select @SchemeYear = datepart(Year,EndDate) from schemeYears where schemeNo = @schemeNo
 and AcctPeriod = @AcctPeriod
              
 RETURN(@SchemeYear)                
end
go

