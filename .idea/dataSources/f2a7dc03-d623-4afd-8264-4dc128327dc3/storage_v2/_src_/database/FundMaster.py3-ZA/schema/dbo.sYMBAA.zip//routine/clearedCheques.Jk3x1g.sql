CREATE PROCEDURE [dbo].[clearedCheques]
@SCHEMENO Int,
@BankCode varchar(15)
--with Encryption
as

      if object_id('tempdb..##ClearedCheques') is null

begin
create table ##ClearedCheques
(
	[SchemeNo] [varchar](15) NOT NULL ,
	[VoucherNo] [int] not  NULL ,
             [BankCode] [varchar](20) null,
             [TransDate][Datetime] not null ,
             [Description][varchar](100),
             [ChequeNo][varchar](20),
             [Credit][float],
             [CollectedBy][varchar](80),
             [DateCollected][Datetime],
             [CashBookNo][Int] not null
             
  
) 

ALTER TABLE ##ClearedCheques WITH NOCHECK ADD 

            
	CONSTRAINT [PK_ClearedCheques] PRIMARY KEY  NONCLUSTERED 
	(
	  [SchemeNo] ,
               [CashBookNo]     
	) 
end



Delete from ##ClearedCheques

Insert into ##ClearedCheques
   select c.schemeNo, c.Voucherno,c.BankCode, c.TransDate, c.Description,c.ChequeNo, c.Credit,
          p.CollectedBy,p.DateCollected,c.CashBookNo
   from CashBook c
        inner Join PaymentVoucher P On c.SchemeNo = p.SchemeNo and c.VoucherNo = p.VoucherNo
   where ((c.SchemeNo = @schemeNo) and (c.BankCode = @BankCode) and (c.PostedToGL = 1)
   and (c.ChequeStatus = 1) and (c.Credit >0))
   order by c.TransDate


Select * from  ##ClearedCheques
go

