CREATE PROCEDURE [dbo].[CostCenters]
@SCHEMENO Int,
@CompanyId Int
--with Encryption
as
select CompanyName from schemeCompanies
where SchemeNo = @schemeNo and CompanyId = @CompanyId
go

