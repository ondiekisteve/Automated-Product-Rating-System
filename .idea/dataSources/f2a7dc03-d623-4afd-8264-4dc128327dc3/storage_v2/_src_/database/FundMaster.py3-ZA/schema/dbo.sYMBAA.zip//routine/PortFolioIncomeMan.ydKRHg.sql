CREATE PROCEDURE [dbo].[PortFolioIncomeMan]    
@SCHEMENO Int,    
@startDate Datetime,    
@EndDate Datetime,    
@Manager Varchar(15)    
--with Encryption    
as    
    
if object_id('tempdb..#PortfolioIncome') is null    
    
begin    
create table #PortfolioIncome    
(    
        [InvestCode][Integer]Identity (1,1),    
        [SchemeName][varchar](120) null,    
        [Investment] [varchar](100) NOT NULL ,    
        [amount] [float] not  NULL default 0.0,    
        [Percentage] [Float] null default 0.0,    
        [Total][Float]null default 0.0,    
        [Currency][varchar](30),    
        [Period][varchar](30),    
        [AmountInvested][float],    
        [ManagerName][Varchar](120),  
        [StartDate][Datetime],  
        [EndDate][Datetime]    
            
                  
)     
    
ALTER TABLE #PortfolioIncome WITH NOCHECK ADD      
                
 CONSTRAINT [PK_PortfolioIncomeMan] PRIMARY KEY  NONCLUSTERED     
 (    
   [InvestCode]          
 )     
end    
    
declare @InvestCode Int,@Investment varchar(50),@Percentage float,@Total float,@Amount float,    
@AmountInvested float,@SchemeName varchar(120),@Curr varchar(15),@Currency varchar(30),@Period varchar(20),    
@OffShoreVal float,@ManagerName varchar(120)    
    
Select @ManagerName = ManagerName from InvestmentManagers    
where SchemeNo = @SchemeNo and simCode = @Manager    
    
Select @Total = 0    
    
Select @SchemeName = schemeName,@Curr = Currency from scheme where schemeCode = @schemeNo    
    
Select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @Curr    
    
Select @OffShoreVal = 0    
    
Declare Acsr Cursor for    
Select Distinct(InvestCode) from    
InvestMents     
where SchemeNo = @SchemeNo and simCode is not Null    
   
Open acsr    
    
fetch from acsr into @InvestCode    
    
while @@fetch_Status = 0    
begin    
     select @Investment = InvestDesc from InvestmentTypes where InvestCode = @InvestCode    
    
   
            if @InvestCode = 1 /*Rental Income */    
               select @Amount = sum(c.Rent + c.ServiceCharge)     
               from RentInvoice c    
                       inner Join Investments i on c.SchemeNo = i.schemeNo and c.PropertyCode = i.InvCode   
                       and i.simCode = @Manager    
               where c.SchemeNo = @schemeNo and c.InvoiceDate >= @StartDate and c.InvoiceDate <= @EndDate    
                
            else if @InvestCode = 2 /*Quoated Equity*/    
               begin  
               select @Amount = sum(a.Dividend*b.NoofShares)     
               from EquityDividends a    
                     inner Join Equity b on a.SchemeNo = b.schemeNo    
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode    
                      inner Join Investments i on a.SchemeNo = i.schemeNo and a.EquityNo = i.InvCode   
                      and i.simCode = @Manager    
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate   
               
               select @Amount = sum(Income)     
               from SaleEquity a    
                     inner Join Equity b on a.SchemeNo = b.schemeNo    
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode    
                      inner Join Investments i on a.SchemeNo = i.schemeNo and a.EquityNo = i.InvCode    
                      and i.simCode = @Manager    
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate   
  
              end  
            else if @InvestCode = 3 /*Un-Quoated Equity*/    
               select @Amount = sum(a.Dividend*b.NoofShares)     
               from EquityDividends a    
                     inner Join Equity b on a.SchemeNo = b.schemeNo    
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode    
                     inner Join Investments i on a.SchemeNo = i.schemeNo and a.EquityNo = i.InvCode    
                     and i.simCode = @Manager    
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate  
  
   
             
      
            else if @InvestCode = 4 /*Government Paper */    
               select @Amount = sum(c.Interest)     
               from GovernmentIncome c    
                        inner Join Investments i on c.SchemeNo = i.schemeNo and c.SecurityNo = i.InvCode   
                        and i.simCode = @Manager    
               where c.SchemeNo = @schemeNo and c.SecurityDate >= @StartDate and c.SecurityDate <= @EndDate  
    
            else if @InvestCode = 5 /*Fixed and Time Deposits */    
               select @Amount = sum(Interest)     
               from CashRollOver c    
                       inner Join Investments i on c.SchemeNo = i.schemeNo and c.DepositNo = i.InvCode  
                       and i.simCode = @Manager    
               where c.SchemeNo = @schemeNo and c.RollOverDate >= @StartDate and c.RollOverDate <= @EndDate   
    
             
            else if @InvestCode = 7 /*Commercial Paper */    
               select @Amount = sum(c.Interest)     
               from CommercialIncome c     
                      inner Join Investments i on c.SchemeNo = i.schemeNo and c.PaperNo = i.InvCode    
                      and i.simCode = @Manager    
               where c.SchemeNo = @schemeNo and c.PaperDate >= @StartDate and c.PaperDate <= @EndDate   
      
    
            else if @InvestCode = 8 /*Cash and Demand Deposits */    
               select @Amount = sum(c.Interest)     
               from DemandRollOver  c    
                       inner Join Investments i on c.SchemeNo = i.schemeNo and c.DepositNo = i.InvCode  
                       and i.simCode = @Manager    
               where c.SchemeNo = @schemeNo and c.RollOverDate >= @StartDate and c.RollOverDate <= @EndDate    
    
              
  
          else if @InvestCode = 10 /*Other Investments */    
               select @Amount = sum(c.UnitsSold * c.PricePerUnit)     
               from ForexMangondo  c    
                       inner Join Investments i on c.SchemeNo = i.schemeNo and c.OffshoreNo = i.InvCode and i.simCode = @Manager    
               where c.SchemeNo = @schemeNo and c.IncomeDate >= @StartDate and c.IncomeDate <= @EndDate   
    
          else if @InvestCode = 11 /*Offshore Investments */    
               select @Amount = sum(c.UnitsSold * c.PricePerUnit)     
               from OffshoreMangondo  c    
                       inner Join Investments i on c.SchemeNo = i.schemeNo and c.OffshoreNo = i.InvCode and i.simCode = @Manager    
               where c.SchemeNo = @schemeNo and c.IncomeDate >= @StartDate and c.IncomeDate <= @EndDate    
          
    
        Select @AmountInvested = sum(InitValue)     
        from Investments    
        where SchemeNo = @SchemeNo and InvestCode = @InvestCode    
        and simCode = @Manager    
    
    
        if @amount is null select @Amount = 0    
    
        Select @Total = @Total + @Amount    
    
     if @Amount > 0     
     Insert Into #PortfolioIncome (Investment,Amount,currency,AmountInvested, ManagerName,StartDate,EndDate)    
                  Values(@Investment,@Amount,@Currency,@AmountInvested,@ManagerName,@StartDate,@EndDate)    
    
     Select @Amount = 0,@AmountInvested = 0    
    
   fetch next from acsr into @InvestCode    
end    
Close Acsr    
Deallocate Acsr    
    
update #PortfolioIncome set Total = @Total,schemeName = @SchemeName,Period = @Period    
    
Select @Investment = ' '    
select @Amount = 0    
    
declare Acsr cursor for    
Select Investment, Amount    
from #PortfolioIncome where amount > 0    
    
Open Acsr    
    

fetch from acsr Into @Investment,@Amount    
    
while @@fetch_Status = 0    
begin    
  Select @Percentage = (@Amount/@Total)*100.0000000    
    
  update #PortfolioIncome set Percentage = @Percentage    
  where Investment = @Investment    
    
  Select @Percentage = 0    
    
  fetch from acsr Into @Investment,@Amount    
end    
Close Acsr    
Deallocate Acsr    
    
    
Select * from #PortfolioIncome
go

