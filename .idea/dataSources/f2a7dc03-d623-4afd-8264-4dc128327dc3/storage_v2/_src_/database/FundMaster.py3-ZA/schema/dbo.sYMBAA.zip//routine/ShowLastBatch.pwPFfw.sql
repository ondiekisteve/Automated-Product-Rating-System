CREATE PROCEDURE [dbo].[ShowLastBatch]
@SCHEMENO Int,
@PrevBatchId Int
--with Encryption
as

if object_id('tempdb..##LastBatch') is null

begin
create table ##LastBatch
(
        [Counter][Int] identity(1,1),
	[MemberNo] [int] NOT NULL ,
	[Salary] [float] NOT NULL ,
	[EmpCont] [float] not  NULL default 0.0,
        [EmprCont] [Float] null default 0.0,
        [VolCont][float] not null,
        [Special][float] not null,
        [CompanyId][Int] not null,
        [SponsorCode][Int] not null    
) 

ALTER TABLE ##LastBatch WITH NOCHECK ADD 

            
	CONSTRAINT [PK_LastBatch] PRIMARY KEY  NONCLUSTERED 
	(
	  [MemberNo],[Counter]      
	) 
end

   delete from ##LastBatch


   Insert Into ##LastBatch Select MemberNo,Salary,EmpCont,EmprCont,VolContr,SpecialContr,
                        CompanyId,SponsorCode
                        from BatchEntry
                        where SchemeNo = @SchemeNo and BatchId = @PrevBatchId
go

