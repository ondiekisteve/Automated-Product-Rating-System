CREATE PROCEDURE [dbo].[CashDueRedemption]                                                    
@SCHEMENO Int,                                                    
@SecurityNo Int,
@RedeemDate datetime                                                    
--with Encryption                                                    
as                                                    
                                    
declare @StartDate datetime,@SecType int,@Interest float,@IntFreq int,@NormValue float,                                                    
        @Maturity Datetime,@Income Decimal(20,6),@DateDue Datetime,@NumDays Int,@NumInstal Int,                                                    
        @Start int,@TotalDue float,@InvestCode Int,@InvestTypeCode Int,@Term Bit,                                                    
        @Amount float,@EndDate Datetime,@DaysToEnd Int,@PartialIncome float,@NumInstalPA Int,                                              
        @MaxPayDate Datetime,@PrevDateDue Datetime,@NoOfDays Int,@glCode Int,@QuarterDate datetime,                    
        @DateBought Datetime,@FromSecond smallInt,@HizoSiku Int,@SellerIncome Decimal(20,6),                
        @IncomeRec Decimal(20,6),@InterestType smallInt,@MedLevy float,@WithTax float,    
        @MediLevy Decimal(20,6),@WithiTax Decimal(20,6)                                              
                                      
if Not Exists (Select * from GovCommIncomeDue where schemeNo = @schemeNo and SecurityNo = @SecurityNo and Posted = 1)                                      
begin            
                                     
Delete from GovCommIncomeDue where schemeNo = @schemeNo and SecurityNo = @SecurityNo                                        
                                              
Select @StartDate = InterestDate,@Interest = InterestRate,@InterestType = InterestType,                                                    
       @IntFreq = InterestFreq,@NormValue = Amount,@Maturity = @RedeemDate,                                                    
       @Amount = Amount,@NoOfDays = NoOfDays                                                  
from CASHDEPOSITS                                                     
where SchemeNo = @schemeNo and DepositNo = @SecurityNo 

SELECT @NoOfDays = DateDiff(Day,@StartDate,@Maturity)                                            
   
select @MedLevy = Max(MedicalLevy),@WithTax = Max(WithholdingTax) from TBL_Invest_TaxRates                        
where schemeNo = @schemeNo and InvestCode = 5     
    
if @MedLevy is null select @MedLevy = 0                        
if @WithTax is null select @WithTax = 0      
               
select @IncomeRec = 0.00                
  
Select @NumDays = @NoOfDays                                                  
                    
if @FromSecond is null select @FromSecond = 0                    
                    
select @InvestCode = InvestCode,@InvestTypeCode = InvestCodeDetail from                                                    
Investments                                                     
where SchemeNo = @schemeNo and InvCode = @SecurityNo                                                    
                                                    
Select @Term = Term from InvestmentTypeDetail                                                    
where InvestCode = @InvestCode and InvestTypeCode = @InvestTypeCode                                                    
                            
Select @Income = @NormValue * (@Interest/100.00000000)                                                    
                           
      
if @InterestType = 1 /* Floating */      
begin                                                       
      /*Calculate Number of Instalments */                                                    
      Select @NumInstal = @NoOfDays/@NumDays                                                  
                                       
      select @NumInstalPA = 365/@NumDays                                                    
                                                                                    
      Select @DateDue = DateAdd(Day,@NumDays,@StartDate)                    
                    
      if ((@FromSecond = 1) and (@StartDate < @DateBought))                    
        begin                    
          select @HizoSiku = DateDiff(Day,@StartDate,@DateBought)                    
          select @SellerIncome = (cast(@HizoSiku as float)/cast(@NumDays as float))* @Income                    
        end                    
      else select @SellerIncome = 0.0                                              
                                                        
      Select @Start = 0                                                    
      while @Start < @NumInstal                                                    
      begin                  
           Select @IncomeRec = @Income * cast(@numDays as Float)/365.00     
    
      if @MedLevy > 0    
         select @MediLevy = (@MedLevy/100.00)* @Income    
      else    
         select @MediLevy = 0.0    
    
      if @WithTax > 0    
         select @WithiTax = (@WithTax/100.00)* @Income    
      else    
         select @WithiTax = 0.00                
                                                                      
           Insert Into GovCommIncomeDue(DateDue,Income,SchemeNo,SecurityNo,TotalDue,Posted,NumDays,              
                                        SellerIncome,RateUpdated,WithTax,MedLevy)                                          
           Values(@DateDue,@IncomeRec - @SellerIncome,@schemeNo,@SecurityNo,0.0,0,@NumDays,              
                  @SellerIncome,0,@WithiTax,@MediLevy)                                                      
                           
           Select @DateDue = DateAdd(Day,@NumDays,@DateDue),@IncomeRec = 0.0                 
           if @numDays = 182 select @numDays = 183                
           else if @NumDays = 183 select @numDays = 182                
                                                   
           Select @Start = @Start + 1,@SellerIncome = 0.0                                                   
      end      
      
    Delete from TBL_GOV_COMM_FloatRate where schemeNo = @schemeNo and SecurityNo = @SecurityNo        
          
    Exec Proc_Floating_Rate @schemeNo,@SecurityNo,2        
  end      
 else      
  begin      
    select @Income = @Amount * (cast(@Interest as float)/100.00)              
              
    select @Income = @Income * (cast(@NoOfDays as float)/365.00)    
    
    if @MedLevy > 0    
         select @MediLevy = (@MedLevy/100.00)* @Income    
      else    
         select @MediLevy = 0.0    
    
      if @WithTax > 0    
         select @WithiTax = (@WithTax/100.00)* @Income    
      else    
         select @WithiTax = 0.00                
              
    Insert Into GovCommIncomeDue(DateDue,Income,SchemeNo,SecurityNo,TotalDue,Posted,NumDays,RateUpdated,    
                                 MedLevy,WithTax)                              
                    Values(@Maturity,@Income,@schemeNo,@SecurityNo,0.0,0,@NoOfDays,0,@MediLevy,@WithiTax)      
  end                                                   
                                                                                         
  Select @TotalDue = sum(Income) from GovCommIncomeDue where SchemeNo = @schemeNo and SecurityNo = @SecurityNo                   
  update GovCommIncomeDue set TotalDue = @TotalDue where SchemeNo = @schemeNo and SecurityNo = @SecurityNo                                                        
end
go

