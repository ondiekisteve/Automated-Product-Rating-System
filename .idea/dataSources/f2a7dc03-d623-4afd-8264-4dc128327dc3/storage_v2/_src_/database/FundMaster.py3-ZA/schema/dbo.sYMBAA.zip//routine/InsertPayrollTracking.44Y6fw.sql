CREATE PROCEDURE [dbo].[InsertPayrollTracking]          
@SCHEMENO Int,          
@PayMonth int,          
@PayYear int,          
@UserName varchar(80),        
@PenStatus Int,         
@Reverse Int         
--with Encryption          
as         
      
       
if @Reverse = 0        
begin        
if @PenStatus = 0 /* Prepare */        
   begin        
    Insert into PayrollTracking (schemeNo, PayMonth,PayYear,PreparedBy,DatePrepared,TaxPosted,Tax_PV)          
    Values(@schemeNo,@PayMonth,@PayYear,@UserName,getdate(),0,0)        
   end         
else if @PenStatus = 1 /* Check */        
   begin        
    Update PayrollTracking set CheckedBy = @UserName,DateChecked = getDate(),PenStatus = 1          
    where SchemeNo = @schemeNo and PayMonth = @PayMonth and PayYear = @PayYear        
   end         
else if @PenStatus = 2 /* Authorize */        
   begin        
    Update PayrollTracking set AuthorisedBy = @UserName,DateAuthorised = getDate(),PenStatus = 2          
    where SchemeNo = @schemeNo and PayMonth = @PayMonth and PayYear = @PayYear        
   end         
else if @PenStatus = 3 /* Posted */        
   begin        
    Update PayrollTracking set PostedBy = @UserName,DatePosted = getDate(),PenStatus = 3          
    where SchemeNo = @schemeNo and PayMonth = @PayMonth and PayYear = @PayYear        
   end        
        
   update PensionPayroll set PenStatus = @PenStatus where schemeNo = @schemeNo        
   and PayMonth = @PayMonth and PayYear = @PayYear        
        
   update PensionPayrollBen set PenStatus = @PenStatus where schemeNo = @schemeNo        
   and PayMonth = @PayMonth and PayYear = @PayYear        
        
end        
else if @Reverse = 1        
begin        
   update PensionPayroll set PenStatus = 0 where schemeNo = @schemeNo        
   and PayMonth = @PayMonth and PayYear = @PayYear        
        
   update PensionPayrollBen set PenStatus = 0 where schemeNo = @schemeNo        
   and PayMonth = @PayMonth and PayYear = @PayYear  
  
   update PayrollTracking set PenStatus = 2 where schemeNo = @schemeNo        
   and PayMonth = @PayMonth and PayYear = @PayYear         
end
go

