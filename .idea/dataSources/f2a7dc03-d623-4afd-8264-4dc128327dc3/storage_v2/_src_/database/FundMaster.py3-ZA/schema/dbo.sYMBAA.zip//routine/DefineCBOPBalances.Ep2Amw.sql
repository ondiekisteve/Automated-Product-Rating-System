CREATE PROCEDURE [dbo].[DefineCBOPBalances]                
@SCHEMENO Int,                
@BankCode Int,                
@DrCr Int, /* Debit or Credit Cashbook Balance */               
@Amount Float,                
@TransMode Int,    
@CurrCode int,    
@SpotRate float,              
@PeriodEnding Datetime,  
@bDrCr Int, /* Debit or Credit Bank Balance */               
@bAmount Float                
--with Encryption                
as                
                
declare @Account varchar(40), @sYear varchar(5),@StartDate datetime,                
@AcctPeriod Int,@Description varchar(50), @FiscalYear int,@Month Int,@MonthName varchar(30),            
@Year Int,@bankYear Int,@BankMonth Int,@GSchemeNo Int,  
@cbDebitBalance float,@cbCreditBalance float,  
@brDebitBalance float,@brCreditBalance float                
      
Exec Proc_Parent_Scheme @GSchemeNo Out      
                
Select @FiscalYear = Max(SchemeYear) from SchemeYears where SchemeNo = @schemeNo       
               
select @StartDate = StartDate from SchemeYears where SchemeNo = @schemeNo                
and SchemeYear = @FiscalYear               
              
select @StartDate = @PeriodEnding + 1             
            
select @Month = DatePart(Month,@StartDate),@Year = DatePart(Year,@StartDate)            
          
select @BankMonth = DatePart(Month,@PeriodEnding),@BankYear = DatePart(Year,@PeriodEnding)            
          
Exec GetMonthName @Month,@MonthName Out             
            
select @MonthName = @MonthName+', '+cast(@Year as varchar(4))                
                
select @AcctPeriod = AcctPeriod from AccountingPeriods where SchemeNo = @schemeNo                
and StartDate = @StartDate                
                
Select @sYear = cast(@FiscalYear as varchar(4))                
                
select @Account = BankName from SchemeBankBranch                
where BankCode = @bankCode and SchemeNo = @schemeNo                
                
Select @Description = 'Opening Balance for '+@MonthName                
                
              
    Delete from TBL_CashBook_Balances where schemeCode = @schemeNo and BankCode=@BankCode             
                                 and PeriodEnding = @PeriodEnding               
      
    if @DrCr = 0  
       begin  
         select @cbDebitBalance = @Amount,@cbCreditBalance = 0   
       end  
    else  
       begin  
         select @cbDebitBalance = 0.0,@cbCreditBalance = @Amount  
       end  
  
    if @bDrCr = 0  
       begin  
         select @brDebitBalance  = @bAmount,@brCreditBalance =  0.0   
       end  
    else  
       begin  
         select @brDebitBalance  = 0.0,@brCreditBalance = @bAmount   
       end  
                   
     Insert Into TBL_CashBook_Balances (schemeNo,BankCode,PeriodEnding,DebitBalance,CreditBalance,SchemeCode,    
                                        CurrCode,SpotRate,DrBankBalance,CrBankBalance)              
                  Values(@GSchemeNo,@BankCode,@PeriodEnding,@cbDebitBalance,@cbCreditBalance,@SchemeNo,  
                         @CurrCode,@SpotRate,@brDebitBalance,@brCreditBalance)
go

