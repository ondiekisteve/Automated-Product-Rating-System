CREATE PROCEDURE [dbo].[Proc_Post_Invest_GL_Only]                                                                                                                  
@schemeNo Int,                                                                                                                
@TransType Int,                                                                                                                
@TransNo Int,                                                                                                                
@Amount float,                                                                                                                
@TransParticulars varchar(255),                                                                                                                
@TransDate datetime,                                                                                                                
@InvCode Int                                                                                                                
--with Encryption                                                                                                                  
as                                                                                                                  
                                                                                                                
declare @BatchNo Int,@MaxTransNo Int,                                                                                                                
@CreditAcc varchar(20),@DebitAcc varchar(20),@PayMonth Int,@PayYear Int,@CStatus smallInt,@CurrCode Int,                                                                                                    
@CurrRate FLOAT,@TaxCreditAcc varchar(30),@MedLevyCreditAcc  varchar(30),@MedLevy float,                                                                                          
@WithTax float,@InvestCode Int,@ClearingAcc varchar(30),@FeesAcc varchar(30),@DrCrType smallint,                                  
@Serv_Charge_Debit_Acc varchar(30),@TenantCode Int,@GainLossAcc varchar(30),@GainLoss float,@AssetValue float,      
@AgentCode Int,@BrokerFees float,@Payee varchar(120),@CombAmount float                    
                    
                    
                        
begin tran                                                                              
                                                                                                          
select @CurrCode = CurrCode,@CurrRate= 1.0000,@GainLoss = 0,@AssetValue = 0 from Scheme where schemeCode = @schemeNo                                                                                  
                                                                                  
select @InvestCode = InvestCode from Investments where schemeNo = @schemeNo and InvCode = @InvCode                                                                                                           
                                                                                  
if @InvestCode is null select @InvestCode = 8     
    
/* Posting Other Adjustment Account */    
--select @TransType = 500    
    
                                                                                                                                                                                   
Exec Proc_Check_Periods @schemeNo,@TransDate,@CStatus Out                                                                                                            
                                                                                                            
if @CStatus = 1                                                                                                            
begin                                                                                                            
  raiserror('The Accounting Period for the Transaction does not Exist',16,1)                                       
  return                     
end                                                                                                            
else if @CStatus = 2                                                 
begin                                                                          
  raiserror('The Accounting Period for the Transaction has already been closed',16,1)                                                   
  return                                                                             
end                                                                                               
else if @CStatus = 3                                        
begin                                             
  raiserror('The Fiscal Year for the Transaction has already been closed',16,1)                                                            
  return                                                                        
end                                                           
else                                                           
begin 
                                                                                        
                                                                                   
select @TaxCreditAcc = TaxCreditAcc,@MedLevyCreditAcc = MedLevyCreditAcc,@ClearingAcc = ClearingAcc,                                    
       @Serv_Charge_Debit_Acc = Serv_Charge_Debit_Acc                                                                                          
from Pension_Setup where schemeNo = @schemeNo                                                                                                                     
                                                                                                        
                                                                                         
select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeNo                                                               
if @BatchNo is null select @BatchNo = 0                                                       
select @BatchNo = @BatchNo + 1                                                         
                                                                                                                        
select @MaxTransNo = Max(glTransNo) from SchemeGeneralLedger where schemeCode = @schemeNo                                                                                                                        
if @MaxTransNo is null select @MaxTransNo = 0                                                                                                                        
select @MaxTransNo = @MaxTransNo + 1                                                                                         
                                                                                        
select @PayMonth = DatePart(Month,@TransDate),@PayYear = DatePart(Year,@TransDate)                                                                                                                 
                                                                                           
if @TransType = 191 /* Rent Receivable */                                                                     
  begin                                                                                                                
                                                                                                                  
  select @PayYear = Max(PayYear),@PayMonth = Max(PayMonth) from RentInvoice                                                                                                                
  where schemeNo = @schemeNo and InvBatchNo = @TransNo                                                                                                                
                                           
 Exec PostRentReceivable @SCHEMENO,@InvCode,@PayMonth,@PayYear,3                               
  end                                                                                                 
                               
else if @TransType = 194  /* Property Valuation */                                                                                  
begin          
    if @Amount < 0        
       begin        
       select @Amount = 0 - @Amount                                                                           
        
       select @DebitAcc = ValuationAcc,@CreditAcc = AssetAcc from Property                                                                                                   
       where schemeNo = @schemeNo and PropertyCode = @InvCode         
      end        
    else        
      begin        
       select @DebitAcc = AssetAcc,@CreditAcc = ValuationAcc from Property                                                                                                   
       where schemeNo = @schemeNo and PropertyCode = @InvCode         
      end                 
end                                                                                    
else if @TransType = 198  /* Rent Debit Notes */                                                                                                                
begin                                                                          
      select @CurrCode = CurrCode,@CurrRate = SpotRate,@DrCrType = DrCrType,                                
      @TenantCode = SourceDocNo                                     
      from TBL_Debit_Credit_Notes where DrCrNoteNo = @TransNo                                
                                
      select @DebitAcc = RentDebitAcc,@CreditAcc = @ClearingAcc                                 
      from Tenants                                 
      where TenantCode = @TenantCode                                 
                                
      if @DebitAcc is null                          
         begin                          
         select @DebitAcc = DebitAcc from Property                                                
         where schemeNo = @schemeNo and PropertyCode = @InvCode                           
         end                                                
                                                            
      if @DrCrType = 2 select @CreditAcc = @ClearingAcc                                                                                            
end                                                                                                    
else if @TransType = 199  /* Rent Credit Notes */                                                                          
begin                                   
      select @CurrCode = CurrCode,@CurrRate = SpotRate,@DrCrType = DrCrType,                                
      @TenantCode = SourceDocNo                                  
      from TBL_Debit_Credit_Notes where DrCrNoteNo = @TransNo                                 
                                      
      select @CreditAcc = RentDebitAcc,@DebitAcc = @ClearingAcc                                 
      from Tenants                                 
      where TenantCode = @TenantCode                                 
                                
      if @CreditAcc is null                          
         begin                             
            select @CreditAcc = DebitAcc from Property                                                                                                                
            where schemeNo = @schemeNo and PropertyCode = @InvCode                           
         end                                        
                                                      
      if @DrCrType = 2 select @DebitAcc = @ClearingAcc   
end                                                     
else if @TransType = 200  /* Penalty Debit Notes */                                               
begin                                                                           
      select @DebitAcc = AccrPenaltyAcc,@CreditAcc = PenaltyAcc from Property                                                                                                                
     where schemeNo = @schemeNo and PropertyCode = @InvCode                                     
                                                
      select @CurrCode = CurrCode,@CurrRate = SpotRate,@DrCrType = DrCrType from TBL_Debit_Credit_Notes where DrCrNoteNo = @TransNo                                                                                                                
end                                                         
else if @TransType = 201  /* Shared Estate Expenditure */                                                                                                                
begin                                                                                                                  
      select @DebitAcc = @Serv_Charge_Debit_Acc,@CreditAcc = @ClearingAcc from Property                                                                                                                
      where schemeNo = @schemeNo and PropertyCode = @InvCode                                                           
end                                
else if @TransType = 222  /* Endowment Bonus */                                                                                                                
begin                                                                                       
      select @DebitAcc = AssetAcc,@CreditAcc = BonusAcc from TBL_Endowments                                                                                                                
      where schemeNo = @schemeNo and OffshoreNo = @InvCode                                
                  select @CurrCode = rCurrCode,@CurrRate = SpotRate from TBL_Endowment_Prem                              
      where PayCode = @TransNo                           
end                                                                                                                
else if @TransType = 144  /* Revaluation - CommercialPaper */                                                                                                                
begin                                           
     if @Amount > 0                                                                                                       
        select @DebitAcc = AssetAcc,@CreditAcc = CurrRevalAcc,@CurrCode = CurrCode from CommercialPaper                                                                                                                
        where schemeNo = @schemeNo and PaperNo = @InvCode                                                              
     else                                                              
        begin                                                              
        select @Amount = 0 - @Amount                                                              
        select @DebitAcc = CurrRevalAcc,@CreditAcc = AssetAcc,@CurrCode = CurrCode from CommercialPaper                                                                                                       
        where schemeNo = @schemeNo and PaperNo = @InvCode                                                              
                                                              
        end                                                                                                                
end                                                                                                           
else if @TransType = 154  /* Revaluation - Fixed Term Deposits */                                                             
begin                                                                
     if @Amount > 0                                                                           
        select @DebitAcc = AssetAcc,@CreditAcc = CurrRevalAcc,@CurrCode = CurrCode from CashDeposits                                                                          
        where schemeNo = @schemeNo and DepositNo = @InvCode                                                               
  else                                                              
      begin                                 
        select @Amount = 0 - @Amount                                                              
                                                                      
        select @DebitAcc = CurrRevalAcc,@CreditAcc = AssetAcc,@CurrCode = CurrCode from CashDeposits                                                                            
        where schemeNo = @schemeNo and DepositNo = @InvCode                                           
      end                                                                                                               
end                         
else if @TransType = 156  /* Interest Rollover - Fixed Term Deposits */                                                                                                                
begin                                                            
      select @DebitAcc = AssetAcc,@CreditAcc = DebitAcc,@CurrCode = CurrCode from CashDeposits                                                                                                                
      where schemeNo = @schemeNo and DepositNo = @InvCode                                                                                           
                                                                 
      select @WithTax = WithholdingTax,@MedLevy = MedicalLevy from CashRollOver                                                 
      where schemeNo = @schemeNo and PayCode = @TransNo                                                                        
                                              
end                                                                                                        
else if @TransType = 166  /* Revaluation - Call Deposits */                                                                    
begin                                                               
     if @Amount > 0                                                                                            
        select @DebitAcc = AssetAcc,@CreditAcc = CurrRevalAcc,@CurrCode = CurrCode from DemandDeposits                              
        where schemeNo = @schemeNo and DepositNo = @InvCode                                                              
     else                                                              
      begin                                                              
        select @Amount = 0 - @Amount                                                              
                                                              
        select @DebitAcc = CurrRevalAcc ,@CreditAcc = AssetAcc,@CurrCode = CurrCode from DemandDeposits                                                                                                          
        where schemeNo = @schemeNo and DepositNo = @InvCode                                                              
      end                                                                                                
end                    
else if @TransType = 163  /* Expenses - Call Deposits */                                                                    
begin                                                                                                                                      
     select @DebitAcc = ExpenseAcc,@CreditAcc = AssetAcc,@CurrCode = CurrCode from DemandDeposits            
     where schemeNo = @schemeNo and DepositNo = @InvCode                 
                
      select @CurrRate = SpotRate from DemandRollover where PayCode = @TransNo                                                                                            
end                                                                                                         
else if @TransType = 174  /* Revaluation - Offshore Equity */                                                                                                 
begin                                                                
     if @Amount > 0                                         
      select @DebitAcc = AssetAcc,@CreditAcc = CurrRevalAcc,@CurrCode = CurrCode from Offshore                                                                                     
      where schemeNo = @schemeNo and OffshoreNo = @InvCode                                                              
     else                                                              
      begin                                                              
        select @Amount = 0 - @Amount                                                              
                                                              
        select @DebitAcc = CurrRevalAcc ,@CreditAcc = AssetAcc,@CurrCode = CurrCode from Offshore                                                              
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                                                              
      end                                                                                                                 
end                                                     
else if ((@TransType = 176) or (@TransType = 186))  /* Management Fees - Offshore Equity */                                                                                                 
begin                                                                                                           
      select @DebitAcc = FeesAcc,@CreditAcc = AssetAcc,@CurrCode = CurrCode,@GainLossAcc = FairValueAcc  from Offshore                                                        
      where schemeNo = @schemeNo and OffshoreNo = @InvCode                      
                      
      select @CurrRate = SpotRate,@AssetValue = UnitsSold * AvgCost                                      
      from OffshoreMangondo where PayCode = @TransNo                       
                      
      select @GainLoss = @Amount - @AssetValue                                                                                                                        
end                                                                               
else if @TransType = 184  /* Revaluation - Offshore FXD */                                             
begin                                                                
     if @Amount > 0                                       
        select @DebitAcc = AssetAcc,@CreditAcc = CurrRevalAcc,@CurrCode = CurrCode from Offshore                                                                            
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                                                               
     else                                                              
      begin                                                              
        select @Amount = 0 - @Amount                                                              
                                                              
        select @DebitAcc = CurrRevalAcc ,@CreditAcc = AssetAcc,@CurrCode = CurrCode from Offshore                                                                                                                
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                          
      end                                                                                                  
end                                         
else if ((@TransType = 1210) or (@TransType = 177) or (@TransType = 187))  /* Acquisition using Dividends */                                                                                                 
begin        
     if @TransType = 1210            
        select @DebitAcc = AssetAcc,@CreditAcc = DividendsAcc,@CurrCode = CurrCode,@AgentCode = BrokerCode from Equity                                                        
        where schemeNo = @schemeNo and EquityNo = @InvCode              
     else                                                                
        select @DebitAcc = AssetAcc,@CreditAcc = DividendsAcc,@CurrCode = CurrCode from Offshore                                                        
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                      
                      
      select @CurrRate = SpotRate,@AgentCode = 8,@BrokerFees = Fees       
      from EquityAcquisition where PayCode = @TransNo       
                                                                         
    if @BrokerFees is null select @BrokerFees = 0                                                                          
                  
    if @BrokerFees > 0               
    begin                                                                         
    select @FeesAcc = FeesAcc,@Payee = AgentName from EstateAgents where AgentCode = @AgentCode                
               
    if @FeesAcc is null               
    select @FeesAcc = @DebitAcc              
    end                                                                                                            
end                                                                       
else if @TransType = 226  /* Revaluation - Endowments */                                                                                                         
begin                                                               
    if @Amount > 0                                                                                                           
     select @DebitAcc = AssetAcc,@CreditAcc = CurrRevalAcc,@CurrCode = CurrCode from tbl_Endowments                                 
     where schemeNo = @schemeNo and OffshoreNo = @InvCode                                                              
   else                                                              
      begin                                                              
        select @Amount = 0 - @Amount                                                              
                                                              
        select @DebitAcc = CurrRevalAcc,@CreditAcc = AssetAcc,@CurrCode = CurrCode from tbl_Endowments                                                                    
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                                                              
     end                                                                                                         
end                                                                          
else if @TransType = 216  /* Revaluation - Loans */                                                                                                         
begin                                                                
    if @Amount > 0                                                                                                         
     select @DebitAcc = AssetAcc,@CreditAcc = CurrRevAcc,@CurrCode = CurrCode from tbl_Loans                                                            
     where schemeNo = @schemeNo and MortgageNo = @InvCode                                                               
    else                                                              
      begin                                                              
        select @Amount = 0 - @Amount                                                              
                                               
        select @DebitAcc = CurrRevAcc ,@CreditAcc = AssetAcc,@CurrCode = CurrCode from tbl_Loans                                                                                                          
        where schemeNo = @schemeNo and MortgageNo = @InvCode                                 
      end                                                  
end                                         
else if @TransType = 128  /* Revaluation - Preferential Shares */                                                                                                         
begin                                                              
    if @Amount > 0                                                                                                        
     select @DebitAcc = AssetAcc,@CreditAcc = CurrRevalAcc,@CurrCode = CurrCode from Equity                                                                                                          
     where schemeNo = @schemeNo and EquityNo = @InvCode                                                              
    else                                           
      begin                                                              
        select @Amount = 0 - @Amount                                                              
                                                                    
        select @DebitAcc = CurrRevalAcc ,@CreditAcc = AssetAcc,@CurrCode = CurrCode from Equity                                 
        where schemeNo = @schemeNo and EquityNo = @InvCode                                                              
     end                                                                                                          
end                         
else if @TransType = 122  /* Change In Market Value */                                                                                                                
begin                                                                                                                  
   if @Amount > 0                                                                                     
      begin                                                                                                                
        select @DebitAcc = AssetAcc,@CreditAcc = FairValueAcc from Equity                                                                                                                
        where schemeNo = @schemeNo and EquityNo = @InvCode                                               
      end                                                                                                                
   else                                                                                                                
      begin                                                                                                                
        select @Amount = 0 - @Amount                                                         
        select @DebitAcc = FairValueAcc,@CreditAcc = AssetAcc from Equity                                                                                                                
        where schemeNo = @schemeNo and EquityNo = @InvCode                                                                                                                
      end                                                                           
                                                    
end                                                                    
else if @TransType = 123  /* Dividends Receivable */                                                                                                                
begin                   
     select @DebitAcc = AccrDividendsAcc,@CreditAcc = DividendsAcc from Equity                                                                                                           
     where schemeNo = @schemeNo and EquityNo = @InvCode                                                                                                                                         
end                                                                               
else if @TransType = 124  /* Equity Bonus */                                                                    
begin                                                                                                       
      select @DebitAcc = AssetAcc,@CreditAcc = DividendsAcc from Equity                                                                                      
      where schemeNo = @schemeNo and EquityNo = @InvCode                                                                
end                                      
                                                                                                                
else if @TransType = 172  /* Change In Offshore equity Market Value */                                                                                        
begin                                                             
   select @CurrRate = SpotRate from OffshoreValue                                                                      
   where schemeNo = @schemeNo and PayCode = @TransNo                                                            
                                                                                                             
   if @Amount > 0                                                                                                                
      begin                                                                                                                
        select @DebitAcc = AssetAcc,@CreditAcc = FairValueAcc,@CurrCode = CurrCode from Offshore                                                                 
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                                                                                                                
      end                                            
   else                                                                           
      begin                                                                            
        select @Amount = 0 - @Amount                                                                                                                
        select @DebitAcc = FairValueAcc,@CreditAcc = AssetAcc,@CurrCode = CurrCode from Offshore                                                                                                                
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                                        
      end                                                                                                                
end                                                                          
else if @TransType = 182  /* Change In Offshore fxd Market Value */                                                                                                                
begin                                                            
   select @CurrRate = SpotRate from OffshoreValue                                                                             
   where schemeNo = @schemeNo and PayCode = @TransNo                                                            
                                             
   if @Amount > 0                                                                                                                
      begin                                         
        select @DebitAcc = AssetAcc,@CreditAcc = FairValueAcc,@CurrCode = CurrCode from Offshore                                                                                                                
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                           
      end                                        
   else                                                                                                                
      begin                                                                                          
        select @Amount = 0 - @Amount                                                                                                                
select @DebitAcc = FairValueAcc,@CreditAcc = AssetAcc,@CurrCode = CurrCode from Offshore                                                                     
        where schemeNo = @schemeNo and OffshoreNo = @InvCode                                                                                                                
      end                                                                                                     
end                                                             
else if @TransType = 135  /* Partial Redemption - Call Deposits */                          
begin                                                                                                         
      select @CreditAcc = AssetAcc from GovernmentSecurities                                                                                                          
      where schemeNo = @schemeNo and SecurityNo = @InvCode                                                          
                                                                            
      select @DebitAcc = DebitAcc from TBL_Partial_Redemption                                                                                                             
      where schemeNo = @schemeNo and InvCode = @InvCode and PayCode = @TransNo                                                          
                                                                                                            
end                                                                       
else if @TransType = 155  /* Partial Redemption - Cash Deposits */                                                                   
begin                        
      select @CreditAcc = AssetAcc,@CurrCode = CurrCode from CashDeposits                                                              
      where schemeNo = @schemeNo and DepositNo = @InvCode                                                              
                                                                      
      select @DebitAcc = DebitAcc from TBL_Partial_Redemption                                              
      where schemeNo = @schemeNo and InvCode = @InvCode and PayCode = @TransNo                                                                                                          
end                                                                       
else if @TransType = 148  /* Partial Redemption - Corporate Bonds */                                                                              
begin                                                                                  
      select @CreditAcc = AssetAcc,@CurrCode = CurrCode from CommercialPaper                                                                          
      where schemeNo = @schemeNo and PaperNo = @InvCode                                                                       
                                                                      
      select @DebitAcc = DebitAcc from TBL_Partial_Redemption                               
      where schemeNo = @schemeNo and InvCode = @InvCode and PayCode = @TransNo                                                                                                          
end                                                                       
else if @TransType = 167  /* Partial Redemption - Call Deposits */                                                                       
begin                               
      select @CreditAcc = AssetAcc,@CurrCode = CurrCode from DemandDeposits                                                                
      where schemeNo = @schemeNo and DepositNo = @InvCode                                                                       
                                                                      
      select @DebitAcc = DebitAcc from TBL_Partial_Redemption                           
      where schemeNo = @schemeNo and InvCode = @InvCode and PayCode = @TransNo                                                             
end                                                                       
else if @TransType = 217  /* Partial Redemption - Long Term Loans */                                                                                                         
begin                 
      select @CreditAcc = AssetAcc,@CurrCode = CurrCode from TBL_Loans                                                                                                          
      where schemeNo = @schemeNo and MortgageNo = @InvCode                                                                        
                                                                      
      select @DebitAcc = DebitAcc from TBL_Partial_Redemption                                                             
      where schemeNo = @schemeNo and InvCode = @InvCode and PayCode = @TransNo                                                                                                         
end                                                                
else if @TransType in (127,137,157,147,168,215,175,185,225)  /* Investments Debit/Credit Notes */                                                                                                         
begin                                                                                                           
     select @DebitAcc = DebitAcc,@CreditAcc = CreditAcc,@CurrCode = CurrCode,@CurrRate = SpotRate from TBL_Invest_Debit_Credit_Note                                                                             
     where schemeNo = @schemeNo and DrCrNoteNo = @TransNo                                                                                                         
end                                                                                                               
else if @TransType = 300 /* Contributions Receivable */                                      
begin                                                                                                              
    select @PayYear = BatchYear,@PayMonth = BatchMonth from TBL_ExpectedBatches                                                                             
    where schemeNo = @schemeNo and BatchNo = @TransNo                            
                                                                                                                 
    Exec Proc_Gen_Cont_Batches @schemeNo,@PayMonth,@PayYear,1                                                                                                                
end       
    
if @TransType = 500    
   begin    
      select @DebitAcc = 7004 /* Operational Reserves */    
      select @CreditAcc = 4901    
   end      
         
if @TransType = 1210      
   begin        
   select @CreditAcc = ltrim(rtrim(@CreditAcc))                                                       
   select @DebitAcc = ltrim(rtrim(@DebitAcc))                                                                                                                
                                                                                            
                                                                                                                
   if @CreditAcc is null select @CreditAcc ='0'                                                                                                                
   if @DebitAcc is null select @DebitAcc ='0'                                                                            
                                                                              
   if ((len(@CreditAcc) < 2) or (len(@DebitAcc) < 2))                                                                                                                
   begin                                                                                             
       raiserror('The General Ledger mapping for this transaction has not been specified',16,1)                                                                            
       rollback tran                                                                                                                
   end      
   else      
   begin      
         
      if @BrokerFees is null select @BrokerFees = 0       
            
      select @CombAmount = @Amount + @BrokerFees      
         
       if @BrokerFees > 0      
          Exec PostLedgerCredits_RecPay @SchemeNo,@CreditAcc,0,@CombAmount,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                
          @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode      
       else      
          Exec PostLedgerCredits_RecPay @SchemeNo,@CreditAcc,0,@Amount,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                         
          @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode      
                                                                                                                                                                                                                                                              
  
    
                                                                                              
       Exec PostLedgerDebits_RecPay @SchemeNo,@DebitAcc,0,@Amount,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                                          
       @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode      
             
       if @BrokerFees > 0      
          Exec PostLedgerDebits_RecPay @SchemeNo,@FeesAcc,0,@BrokerFees,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                                          
          @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode      
                
   end                  
   end                                                                                                                                                                                          
else if ((@TransType <> 300)  and (@TransType <> 191))                                                                                                          
  begin                                                                                                                                                                                                                             
   select @CreditAcc = ltrim(rtrim(@CreditAcc))                                                       
   select @DebitAcc = ltrim(rtrim(@DebitAcc))                                                                                                                
                                                                                            
                                                                                                                
   if @CreditAcc is null select @CreditAcc ='0'                                                                                                                
   if @DebitAcc is null select @DebitAcc ='0'                                                                            
        
   if ((len(@CreditAcc) < 2) or (len(@DebitAcc) < 2))                                                                                                                
   begin                                                                                             
       raiserror('The General Ledger mapping for this transaction has not been specified',16,1)                                                                            
       rollback tran                                                                                                                
   end                                                                                        
                                                   
   if @WithTax is null select @WithTax = 0                                                                       
   if @Medlevy is null select @MedLevy = 0                       
                      
   if @GainLoss = 0                      
      begin 
                                                                                                                                                                                                 
   Exec PostLedgerCredits_RecPay @SchemeNo,@CreditAcc,0,@Amount,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                         
   @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode                                                                                                                
                                                                                                                        
                                                                    
   select @Amount = @Amount - (@Medlevy + @WithTax) 
                                                                                            
                                                                                                                   
   Exec PostLedgerDebits_RecPay @SchemeNo,@DebitAcc,0,@Amount,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                                          
   @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode                                                                                           
                                                                                          
   if @WithTax > 0                                                                         
    Exec PostLedgerDebits_RecPay @SchemeNo,@TaxCreditAcc,0,@WithTax,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                      
    @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode                                                                                           
                                             
   if @MedLevy > 0                                                                          
    Exec PostLedgerDebits_RecPay @SchemeNo,@MedLevyCreditAcc,0,@MedLevy,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                                          
    @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode                                                                                   
      end                       
   else                      
      begin                         
          /* Debit Management Fees Expense Account */                      
          Exec PostLedgerDebits_RecPay @SchemeNo,@DebitAcc,0,@Amount,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                                          
          @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode                      
                       
        /* Credit Asset Account */                      
          Exec PostLedgerCredits_RecPay @SchemeNo,@CreditAcc,0,@AssetValue,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                                          
          @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode                       
                      
           /* Debit/Credit Management Fees Expense Account */                      
          if @GainLoss > 0                      
             Exec PostLedgerCredits_RecPay @SchemeNo,@GainLossAcc,0,@GainLoss,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                                                                                                          
             @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode                       
          else                      
             begin                      
               select @GainLoss = 0-@GainLoss                      
                                     
               Exec PostLedgerDebits_RecPay @SchemeNo,@GainLossAcc,0,@GainLoss,@PayMonth,@PayYear,@TransParticulars,0,@TransDate,                                      
               @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,@TransNo,@TransType,@InvestCode               
             end                        
      end                       
                      
   end                                                                                      
end                                                                        
                            
commit tran
go

