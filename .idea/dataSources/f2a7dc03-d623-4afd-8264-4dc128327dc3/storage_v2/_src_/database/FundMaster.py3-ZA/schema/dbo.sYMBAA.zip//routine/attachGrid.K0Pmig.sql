CREATE PROCEDURE [dbo].[attachGrid]
@SCHEMENO Int
--with Encryption
as
select DocType, LodgedRBA, CustodianCode,AttachmentNo
from Attachments
where SchemeNo = @SchemeNo
order by DocType
go

