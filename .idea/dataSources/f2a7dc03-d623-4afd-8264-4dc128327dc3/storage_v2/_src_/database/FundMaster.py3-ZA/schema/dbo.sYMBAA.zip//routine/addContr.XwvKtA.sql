CREATE PROCEDURE [dbo].[addContr]
@SCHEMENO Int,
@memberNo int,
@contrYear int,
@contrMonth tinyint,
@salary float,
@DatePaid datetime

--with Encryption
as

Declare @AcctPeriod Int

select @AcctPeriod = AcctPeriod from schemeYears where SchemeNo = @schemeNo and 
       StartDate <= @DatePaid and EndDate >= @DatePaid

if @AcctPeriod is null
   select  @AcctPeriod = Max(AcctPeriod) from schemeYears where SchemeNo = @schemeNo

IF Exists (Select * from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @MemberNo
           and ContrMonth = @ContrMonth and ContrYear = @ContrYear)
           Update Contributionssummary set Salary = @Salary,DatePaid = @DatePaid
           where SchemeNo = @schemeNo and MemberNo = @MemberNo
           and ContrMonth = @ContrMonth and ContrYear = @ContrYear
else
    Insert Into Contributionssummary(SchemeNo,MemberNo,AcctPeriod,ContrYear,ContrMonth,Salary,SchemeYear,
                EmpCont,EmprCont,VolContr,SpecialContr,NSSF,NSSFE,AugCont,DatePaid)
                Values(@SchemeNo,@MemberNo,@AcctPeriod,@ContrYear,@ContrMonth,@Salary,@ContrYear,
                0,0,0,0,0,0,0,@DatePaid)
go

