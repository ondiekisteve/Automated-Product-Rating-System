CREATE PROCEDURE [dbo].[Stab_Barclays]
@schemeNo int,
@Proc_Date datetime
--with Encryption
as

if object_id('tempdb..#Barclays') is null            
            
begin            
create table #Barclays            
(            
                  
        [memberNo] [int],
        idNumber varchar(20),
        FullName varchar(120),            
        [s_Desc] varchar(15),
        asAtDate datetime            
)                
end  

Insert into  #Barclays select m.memberNo,m.idnumber,m.sname+', '+m.fname+' '+m.onames,'Active',@Proc_Date
from Contributionssummary c
     inner join Members m on c.schemeNo = m.schemeNo and c.MemberNo = m.MemberNo and m.ReasonforExit = 0
where c.schemeNo = @schemeNo and datepart(month,@proc_date) = ContrMonth 
and datepart(Year,@proc_date) = ContrYear   

Insert into  #Barclays select m.memberNo,m.idnumber,m.sname+', '+m.fname+' '+m.onames,'In-Active',@Proc_Date
from Members m
where m.schemeNo = @schemeNo and m.reasonforexit = 0 and 
m.memberNo not in (select memberNo from Contributionssummary where schemeNo = @schemeNo and datepart(month,@proc_date) = ContrMonth 
and datepart(Year,@proc_date) = ContrYear) 

select * from #Barclays order by s_Desc,memberNo
go

