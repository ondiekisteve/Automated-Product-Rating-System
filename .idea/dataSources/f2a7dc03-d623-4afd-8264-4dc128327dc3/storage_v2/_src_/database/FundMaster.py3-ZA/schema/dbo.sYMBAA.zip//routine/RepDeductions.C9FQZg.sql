CREATE PROCEDURE [dbo].[RepDeductions]
@SCHEMENO Int,
@StopMonth int,
@StopYear int
--with Encryption
as

Select s.SchemeName, a.MemberNo, a.Deduction,a.StopDate, b.Deduction as Description,
       upper(m.sname)+', '+m.fname+' '+m.Onames as fullName, p.PenNo,
       x.MonthName +', '+cast(@StopYear as varchar(4)) as Period
from MemberDeductions a
     inner Join Deductions b on a.DeductCode = b.DeductCode
     inner Join Members m on a.SchemeNo = m.SchemeNo and a.MemberNo = m.MemberNo
     inner Join Pensioner p on a.SchemeNo = p.SchemeNo and a.MemberNo = p.MemberNo
     inner Join MonthTable x on Datepart(Month,a.StopDate) = x.MonthNumber
     inner Join Scheme s on a.SchemeNo = s.SchemeCode
where a.SchemeNo = @SchemeNo and Datepart(Month,a.StopDate) = @StopMonth and
     DatePart(Year,a.StopDate) = @StopYear
order by a.MemberNo
go

