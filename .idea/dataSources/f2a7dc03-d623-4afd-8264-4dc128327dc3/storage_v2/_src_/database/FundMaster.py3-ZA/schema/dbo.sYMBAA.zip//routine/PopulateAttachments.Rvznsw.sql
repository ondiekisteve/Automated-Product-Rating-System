CREATE PROCEDURE [dbo].[PopulateAttachments]
@SCHEMENO Int,
@AttachmentNo Int
--with Encryption
as
Select Count(*) as NumPages
from AttachmentPages
where SchemeNo = @schemeNo and AttachmentNo = @AttachmentNo
go

