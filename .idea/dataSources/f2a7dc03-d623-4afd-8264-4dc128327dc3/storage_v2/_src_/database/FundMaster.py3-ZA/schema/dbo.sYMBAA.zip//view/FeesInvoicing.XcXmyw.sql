CREATE VIEW [dbo].[FeesInvoicing]
--with encryption
as
Select i.SchemeNo, i.FeesCode, i.InvoiceDate,i.Consultant,i.Description, i.Amount + i.withholdingTax + i.vat as Amount,
upper(F.FeesType) as FeesType,s.SchemeName
from FeesInvoice i
     inner Join FeesSetup f on i.FeesCode = f.FeesCode
     inner Join Scheme s on i.SchemeNo = s.SchemeCode
go

