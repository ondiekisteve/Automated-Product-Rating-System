CREATE PROCEDURE [dbo].[BackUpFundMaster]
as
declare @sqlStr varchar(5000)
select @sqlStr = ('USE FundMaster')
go

