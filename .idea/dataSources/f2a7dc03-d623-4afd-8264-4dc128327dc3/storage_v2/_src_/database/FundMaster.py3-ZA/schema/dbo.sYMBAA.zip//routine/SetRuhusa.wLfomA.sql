CREATE PROCEDURE [dbo].[SetRuhusa]      
@UserRole Varchar(100)      
--with Encryption      
as      
declare @Object varchar(100),@SqlStr varchar(1000)      
 
/* Tables */     
declare Acsr cursor for      
Select NAME from SysObjects where Type ='U' and Uid = 1  
order by Name  
open acsr      
      
fetch from acsr into @Object      
      
while @@fetch_Status = 0      
begin      
      
   Select @SqlStr = 'Grant Select,Delete,Update,Insert on ['+@Object +'] to ['+ @UserRole +']'      
      
   Exec (@SqlStr)      
         
   fetch next from acsr into @Object      
end      
Close Acsr      
Deallocate acsr      

/* Views */      
declare Acsr cursor for      
Select NAME from SysObjects where Type ='v' and Uid = 1   
and ((name <> 'sysConstraints') and (name <> 'sysSegments'))  
order by Name      
open acsr      
      
fetch from acsr into @Object      
      
while @@fetch_Status = 0      
begin      
      
   Select @SqlStr = 'Grant Select on ['+@Object +'] to ['+ @UserRole+']'      
      
   Exec (@SqlStr)      
         
   fetch next from acsr into @Object      
end      
Close Acsr      
Deallocate acsr 


/* User Defined Functions */      
declare Acsr cursor for      
Select NAME from SysObjects where Type ='TF' and Uid = 1    
order by Name      
open acsr      
      
fetch from acsr into @Object      
      
while @@fetch_Status = 0      
begin      
      
   Select @SqlStr = 'Grant Select on ['+@Object +'] to ['+ @UserRole+']'      
      
   Exec (@SqlStr)      
         
   fetch next from acsr into @Object      
end      
Close Acsr      
Deallocate acsr     
      
      
/* Procedures */      
declare Acsr cursor for      
Select NAME from SysObjects where Type ='p' and Uid = 1      
open acsr      
      
fetch from acsr into @Object      
      
while @@fetch_Status = 0      
begin      
      
   Select @SqlStr = 'Grant exec on ['+@Object +'] to ['+ @UserRole+']'      
      
   Exec (@SqlStr)      
         
   fetch next from acsr into @Object      
end      
Close Acsr      
Deallocate acsr
go

