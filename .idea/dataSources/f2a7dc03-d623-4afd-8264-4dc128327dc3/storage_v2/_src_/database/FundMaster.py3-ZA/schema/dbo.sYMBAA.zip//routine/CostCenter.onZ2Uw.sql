CREATE PROCEDURE [dbo].[CostCenter]
@SCHEMENO Int
--with Encryption
as
select * from schemeCompanies
where SchemeNo = @schemeNo
go

