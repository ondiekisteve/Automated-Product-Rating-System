CREATE PROCEDURE [dbo].[Proc_CalcMonthlyInterest_Daily_Mon_Un]              
@SCHEMENO Int,              
@memberNo int,              
@CurMonth int,              
@currYear int,              
@useBalances bit,              
@IntMode Int,              
@Calc_Status smallInt, /* 0 - YearEnd, 1 - Withdrawal, 2 - Projection, 3 - Initial Docalc */              
@totEmpCont float output,              
@totEmprCont float output,              
@totVolContr float output,              
@totSpecialContr float output,                              
@totDeferred float output              
--with Encryption              
as              
              
set nocount on              
                           
Declare @AcctPeriod int,@PeriodtoUse int, @sDate datetime,               
@CempCont float,@CemprCont float,@CspecialContr float,@CvolContr float,              
@SMonthDate Datetime,@EMonthDate Datetime,             
@EndDate Datetime,@ctrEmpCont float,@ctrEmprCont float,@cPreEmpCont float,@cPreEmprCont float ,@cPreAvc float,              
@DistrEmp float,@DistrEmpr float,@DistrAVC float,@DistrSpec float, @activestatus int,@IntDays Int,@DateYaLast Datetime,    
@CDeferred float             
              
          
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @currYear, @AcctPeriod out              
              
Select @sDate = StartDate,@DateYaLast = EndDate              
from SchemeYears where SchemeNo = @schemeNo  and AcctPeriod = @AcctPeriod              
                          
select @activestatus = activestatus from members where schemeno = @schemeno and memberno = @memberno        
        
exec getLastDate @CurMonth,@CurrYear,@EndDate out              
              
if @Calc_Status = 1 /* Withdrawal */       
   select @EndDate = DoCalc from Members where schemeNo = @schemeNo and MemberNo = @MemberNo              
else if @Calc_Status = 2 /* Projection */              
   select @EndDate = ProjectDoCalc from Members where schemeNo = @schemeNo and MemberNo = @MemberNo              

            
Select @PeriodToUse = @AcctPeriod - 1              
              
select @sMonthDate = @sDate
            
/* Initialize all variables to Zero */                         
if @useBalances = 1              
  begin              
  select @totEmpCont = ExcessEmp , @totEmprCont = ExcessEmpr,              
  @totVolContr = ExcessVolContr,               
  @totSpecialContr = ExcessSpecial,              
  @totDeferred = DeferredAmt                
  from UnregisteredBalances              
  where SchemeNo = @schemeNo               
  and memberNo = @memberNo              
  and AcctPeriod = @PeriodToUse  
          
              
  if @totEmpCont is null  select @totEmpCont = 0.0              
  if @totEmprCont is null  select @totEmprCont = 0.0              
  if @totVolContr is null  select @totVolContr = 0.0              
  if @totSpecialContr is null  select @totSpecialContr = 0.0        
                                   
  if @totDeferred is null  select @totDeferred = 0.0     
                
   if @DistrEmp is null select @DistrEmp = 0.0        
   if @DistrEmpr is null select @DistrEmpr = 0.0        
   if @DistrAvc is null select @DistrAVC = 0.0        
   if @DistrSpec is null select @DistrSpec = 0.0        
        
       
        
  select @totEmpCont = @totEmpCont + @DistrEmp              
  select @totEmprCont = @totEmprCont + @DistrEmpr              
  select @totSpecialContr = @totSpecialContr + @DistrAVC              
  select @totVolContr = @totVolContr + @DistrSpec               
  end              
else              
  begin              
  select @totEmpCont = 0, @totEmprCont = 0,              
  @totVolContr = 0, @totSpecialContr = 0,@totDeferred = 0              
  end              
  /*Initialize the Opening Balances */ 

  select @cEmpCont = @totEmpCont, @cEmprCont = @totEmprCont,              
  @cVolContr = @totVolContr, @cSpecialContr = @totSpecialContr,@cDeferred = @totDeferred

  
/* Calculate the Interest */             
  while @sMonthDate <= @EndDate
  begin
     select @CurMonth = datepart(Month,@sMonthDate),@Curryear = datepart(year,@sMonthDate)

     Exec getlastDate @CurMonth,@Curryear,@eMonthDate out

     if @sMonthDate > @EndDate
        select @eMonthDate = @EndDate

     Exec [DBO].[Proc_Ret_Int_Monthly_Un] @SCHEMENO,@memberNo,@eMonthDate,@IntMode,              
     @cEmpCont,@cEmprCont,@cVolContr,@cSpecialContr,@cDeferred, 
     /* Output Params */             
     @totEmpCont output,@totEmprCont output,@totVolContr output,@totSpecialContr output,              
     @totDeferred output 

     select @cEmpCont = @totEmpCont, @cEmprCont = @totEmprCont,              
     @cVolContr = @totVolContr, @cSpecialContr = @totSpecialContr,@cDeferred = @totDeferred
         
     select @sMonthDate = dateAdd(Month,1,@sMonthDate)
  end
go

