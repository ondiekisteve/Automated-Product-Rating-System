CREATE PROCEDURE [dbo].[calcBenefits_Un_ShortFall_Distr]  --exec calcBenefits_Un_ShortFall_Distr 1243,12,2009                                                      
@SCHEMENO Int,                                                        
@CurMonth int,                                                        
@curyear int                                                      
--with Encryption                                                        
as                                 
                                
                                      
if object_id('tempdb..#Distr_Income') is null                                           
begin                                      
create table #Distr_Income                                      
(                                      
        PayCode int IDENTITY(1,1) Primary Key,                                
        MemberNo Int,                                
        DoCalc   Datetime,                                
        EmpBalance Decimal(20,6),                                
        EmprBalance Decimal(20,6),                                
        FullName varchar(120),                                
        SponsorCode Int,                        
        Status smallint                                              
)                                             
end                                 
                                                       
declare @memberNo int                                                        
declare @totEmp float                                                        
declare @totEmpr float                                                        
declare @totVol float                                                        
declare @totSpecial float,@StartDate Datetime,@EndDate Datetime,@EmpBalance Decimal(20,6),                                
@EmprBalance Decimal(20,6),@EmpBalanceOp Decimal(20,6),                                
@EmprBalanceOp Decimal(20,6),                                                                                                                                
@ProcessDate Datetime,@ActiveStatus smallInt,@DoCalc datetime,                                    
@currYear int,@AcctPeriod int, @PeriodToUse int,@FullName varchar(120),@WithSurplusReg float,                                
@TotalEmp float,@TotalEmpr float,@EmpPortion float,@EmprPortion float,@EmpInt float,@EmprInt float,                                
@PayCode Int,@Surplus float,@SponsorCode Int,@TotInterest float,@Status smallint,@totsurplus float                                
                                
begin tran                                                        
                                                        
Exec GetLastDate @CurMonth,@CurYear,@ProcessDate Out                               
                              
select @TotInterest = 0       
select @Totsurplus = 0                                   
                                                                         
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out                              
                                
/* Get Withdrawal surplus to Distribute */                                
select @WithSurplusReg = WithSurplusRegUn                     
from DistributionBalances                     
where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod                                  
                              
IF @WithSurplusReg IS NULL SELECT @WithSurplusReg = 0.0                                
                                
Select @StartDate = StartDate,@EndDate = EndDate                                                         
from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod                                                        
                                                        
Select @PeriodToUse = @AcctPeriod - 1                                                        
                                                        
                                                     
                                                      
/* Normal Withdrawals */                                                      
DECLARE membersCsr CURSOR FOR                                                        
Select m.MemberNo,m.ActiveStatus,m.DoCalc,m.sname+', '+m.fname+' '+Onames+' Shortfall Interest',                                
       m.sponsorCode                 
from Members m                                                        
     inner join UnRegisteredBenefits b on m.schemeNo = b.schemeNo and m.MemberNo = b.MemberNo                                                        
where m.schemeNo = @SchemeNo and M.ReasonforExit > 0 and m.DoCalc >= @StartDate and m.DoCalc <= @EndDate                                                      
and m.ActiveStatus <> 6                                                        
                                                        
open membersCsr                                    
                                                        
fetch next from membersCsr                                                        
into @memberNo,@ActiveStatus,@DoCalc,@FullName,@SponsorCode                                                        
while (@@fetch_status = 0)                                      
begin                                                         
  Exec DBO.Proc_GetUnRegMemberBalance_Short @SCHEMENO,@MemberNo,@curMonth,@curYear,0,                                         
       @totEmp out,@totEmpr out,@totVol out,@totSpecial out                    
                                                      
  select @EmpBalance = @totEmp + @totVol,@EmprBalance = @totEmpr + @totSpecial                
                            
  Insert into #Distr_Income (MemberNo,DoCalc,EmpBalance,EmprBalance,FullName,SponsorCode,Status)                                
                     Values(@MemberNo,@DoCalc,@EmpBalance,@EmprBalance,@FullName,@SponsorCode,0)                                 
                                                    
  select @totEmp=0, @totEmpr=0, @totSpecial=0, @totVol=0,                                                        
         @EmpBalance = 0,@EmprBalance = 0,@FullName='',@SponsorCode=0                                      
                                                                                
  fetch next from membersCsr                                                      
 into @memberNo,@ActiveStatus,@DoCalc,@FullName,@SponsorCode                                                        
                                                        
end                                                        
                                                        
close membersCsr                                                        
deallocate membersCsr                                                        
                                                      
/* Deferred Employee */                                                        
DECLARE membersCsr CURSOR FOR                                                        
Select m.MemberNo,m.ActiveStatus,m.InitialDoCalc,m.sname+', '+m.fname+' '+Onames+' Shortfall Interest on Deferred',                                
       m.sponsorCode                                                        
from Members m                                                        
     inner join UnRegisteredBenefits b on m.schemeNo = b.schemeNo and m.MemberNo = b.MemberNo                                                        
where m.schemeNo = @SchemeNo and M.ReasonforExit > 0 and m.InitialDoCalc >= @StartDate and m.InitialDoCalc <= @EndDate                                                      
and m.ActiveStatus = 6                                                        
                                                        
open membersCsr                                                        
                                                        
fetch next from membersCsr                                                 
into @memberNo,@ActiveStatus,@DoCalc,@Fullname,@SponsorCode                                                        
while (@@fetch_status = 0)                                    
begin                                            
                                                    
  Exec DBO.Proc_GetUnRegMemberBalance_Short @SCHEMENO,@MemberNo,@curMonth,@curYear,1,                                         
       @totEmp out,@totEmpr out,@totVol out,@totSpecial out                     
                    
                                                      
  select @EmpBalance = @totEmp + @totVol,@EmprBalance = @totEmpr + @totSpecial                
                     
                                
  Insert into #Distr_Income (MemberNo,DoCalc,EmpBalance,EmprBalance,Fullname,SponsorCode,Status)                                
                     Values(@MemberNo,@DoCalc,@EmpBalance,@EmprBalance,@Fullname,@SponsorCode,1)                                 
                                                    
  select @totEmp=0, @totEmpr=0, @totSpecial=0, @totVol=0,                                                        
         @EmpBalance = 0,@EmprBalance = 0,@SponsorCode=0                                      
                                                                                
  fetch next from membersCsr                                                        
  into @memberNo,@ActiveStatus,@DoCalc,@Fullname,@SponsorCode                                                         
                                                        
end                                                        
                                                        
close membersCsr                                     
deallocate membersCsr                                                       
                                                      
/* Deferred Employer */                                                       
DECLARE membersCsr CURSOR FOR                                    
Select m.MemberNo,m.ActiveStatus,m.DoCalc,m.sname+', '+m.fname+' '+Onames+' Shortfall Interest on Deferred Payment',                                
       m.sponsorCode                                                         
from Members m                                      
     inner join UnRegisteredBenefits b on m.schemeNo = b.schemeNo and m.MemberNo = b.MemberNo                                                        
where m.schemeNo = @SchemeNo and M.ReasonforExit > 0 and m.DoCalc >= @StartDate and m.DoCalc <= @EndDate                                                      
and m.ActiveStatus = 6 and DeferredPaid = 1                                                       
                                                        
open membersCsr                                                        
                                                        
fetch next from membersCsr                                                        
into @memberNo,@ActiveStatus,@DoCalc,@Fullname,@SponsorCode                                                        
while (@@fetch_status = 0)                                                        
begin                                                        
                                                       
  Exec DBO.Proc_GetUnRegMemberBalance_Short @SCHEMENO,@MemberNo,@curMonth,@curYear,2,                                         
       @totEmp out,@totEmpr out,@totVol out,@totSpecial out                     
                                                     
                                                        
  select @EmpBalance = @totEmp + @totVol,@EmprBalance = @totEmpr + @totSpecial                  
                
                                              
  Insert into #Distr_Income (MemberNo,DoCalc,EmpBalance,EmprBalance,Fullname,SponsorCode,Status)                                
                     Values(@MemberNo,@DoCalc,@EmpBalance,@EmprBalance,@Fullname,@SponsorCode,2)                           
                                                    
  select @totEmp=0, @totEmpr=0, @totSpecial=0, @totVol=0,                                                        
         @EmpBalance = 0,@EmprBalance = 0,@SponsorCode=0                                    
                    
  fetch next from membersCsr                                                        
  into @memberNo,@ActiveStatus,@DoCalc,@Fullname,@SponsorCode                                                        
                                                        
end                                                        
       
close membersCsr                                                        
deallocate membersCsr                                                
                                
                                
/* Distribute Income */                                
select @TotalEmp = sum(EmpBalance),@TotalEmpr = sum(EmprBalance)             
from #Distr_Income            
          
if  (@TotalEmp + @TotalEmpr) > 0   
    begin   
      if @TotalEmp > 0                        
         select @EmpPortion = @WithSurplusReg * (@TotalEmp/(@TotalEmp + @TotalEmpr))   
      else  
         select @EmpPortion = 0  
  
      if @TotalEmpr > 0                                 
         select @EmprPortion = @WithSurplusReg * (@TotalEmpr/(@TotalEmp + @TotalEmpr))  
      else  
         select @EmprPortion = 0   
  
   end            
else                
    select @EmpPortion = 0,@EmprPortion = 0          
                                
DECLARE membersCsr CURSOR FOR                                                        
Select PayCode,MemberNo,DoCalc,fullname,EmpBalance,EmprBalance,sponsorCode,Status                                                        
from #Distr_Income order by MemberNo                                
                                
Open membersCsr                                
fetch from membersCsr into @PayCode,@MemberNo,@DoCalc,@FullName,@EmpBalance,@EmprBalance,@SponsorCode,@Status                                
while @@fetch_status = 0                                
begin                                
                                
  if (@EmpBalance > 0)                                
     select @EmpInt = @EmpPortion * (@EmpBalance/@TotalEmp)                                
  else                                
     select @EmpInt = 0                                
                    
  if @EmprBalance > 0                                
     select @EmprInt = @EmprPortion * (@EmprBalance/@TotalEmpr)                                
  else                                
     select @EmprInt = 0                                
                                
  select @TotInterest = @TotInterest + @EmprInt + @EmpInt        
         
       
  select @totsurplus = @totsurplus + @surplus                              
                        
  select @EmpBalanceOp = @EmpBalance, @EmprBalanceOp = @EmprBalance                              
  select @EmpBalance = @EmpBalance + @EmpInt, @EmprBalance = @EmprBalance + @EmprInt                                
                                  
  select @Surplus = @EmpInt + @EmprInt        
                                
                                
  Delete from Surplus_UnReg where SchemeNo = @schemeNo and SurplusDate = @DoCalc and SurplusDesc = @Fullname                    
                  
  print @FullName                
  print @MemberNo                 
  print @WithSurplusReg    
  print @EmprBalance  
  print @EmprPortion  
  print @TotalEmpr  
  print @TotalEmp  
  
   
  print ('*************************')              
              
  IF @Surplus <> 0                                                         
     Exec InsertSurplus_Memb @SchemeNo,@MemberNo,@DoCalc,@FullName,@Surplus,0,0,0,0,1,5,@SponsorCode,                                      
                                @EmpBalance,@EmprBalance,@EmpBalanceOp,@EmprBalanceOp,@Status                                 
                   
  select @PayCode=0,@MemberNo=0,@FullName='',@EmpBalance=0,@EmprBalance=0,@SponsorCode=0,                                
         @EmpBalance=0,@EmprBalance=0,@EmpBalanceOp=0,@EmprBalanceOp=0,@EmpInt = 0,@EmprInt = 0,@Surplus = 0,@Status=0                                
  fetch next from membersCsr into @PayCode,@MemberNo,@DoCalc,@FullName,@EmpBalance,@EmprBalance,@SponsorCode,@Status                                
end                                
close membersCsr                                
deallocate membersCsr                 
      
print 'ddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd'                
print @TotInterest        
print @Totsurplus        
print 'zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz'      
                           
                                                             
commit Tran
go

