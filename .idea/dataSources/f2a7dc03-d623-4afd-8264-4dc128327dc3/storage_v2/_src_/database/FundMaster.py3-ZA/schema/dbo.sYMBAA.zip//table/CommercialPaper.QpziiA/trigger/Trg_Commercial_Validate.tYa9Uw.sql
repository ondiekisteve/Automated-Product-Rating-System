CREATE TRIGGER [dbo].[Trg_Commercial_Validate] ON [dbo].[CommercialPaper] 
FOR INSERT, UPDATE, DELETE 
AS

declare @SchemeNo Int,@DepositNo Int,@DateInvested datetime,@InterestRate decimal(6,4),@YearClosed smallInt

select @schemeNo = SchemeNo,@DepositNo = PaperNo,@DateInvested = TransDate,@InterestRate = InterestRate from Inserted

select @YearClosed = PeriodClosed from AccountingPeriods where schemeNo = @schemeNo and StartDate <= @DateInvested
and EndDate >= @DateInvested

if @YearClosed = 1
   begin
       raiserror('You cannot Add/Edit/Delete transactions in a closed Accounting Period',16,1)
       rollback tran
   end


if @InterestRate > 100.00
   begin
        raiserror('The Interest rate cannot be more than 100 %',16,1)
        rollback tran
  end
go

