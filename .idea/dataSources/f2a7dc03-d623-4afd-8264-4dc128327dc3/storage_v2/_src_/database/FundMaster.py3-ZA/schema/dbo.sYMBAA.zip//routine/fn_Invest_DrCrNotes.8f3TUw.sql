CREATE FUNCTION [dbo].[fn_Invest_DrCrNotes](@InvestCode int)        
returns @tbl_var table(TransType int not null primary key,        
                       TransDesc varchar(120) not null       
                       )        
as        
 begin        
  if ((@InvestCode >= 2) and (@InvestCode <= 3)) /* Listed Equity */       
     begin        
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(1,'Change in Market Value')        
          
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(2,'Accrued Dividends')        
             
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(3,'Currency Revaluation') 

       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(4,'Accrued Interest')   
     
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(5,'Other')      
       
     end         
   else if @InvestCode = 4 /* Government Securities */       
     begin        
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(1,'Accrued Interest')        
          
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(2,'Accrued Discount')        
             
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(3,'Valuation of Bonds')     
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(4,'Other')      
     end        
  else if @InvestCode = 5 /* Fixed Term Deposits */       
     begin        
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(1,'Accrued Interest')     
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(2,'Currency Revaluation')    
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(3,'Other')          
     end     
  else if @InvestCode = 7 /* Commercial Paper */       
     begin        
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(1,'Accrued Interest')        
          
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(2,'Valuation of Bonds')        
             
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(3,'Currency Revaluation')    
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(4,'Other')        
     end     
  else if @InvestCode = 8 /* Call Deposits */       
     begin        
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(1,'Accrued Interest')     
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(2,'Currency Revaluation')    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(3,'Other')           
     end     
  else if @InvestCode = 9 /* Long Term Loans */       
     begin        
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(1,'Accrued Interest')        
          
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(2,'Accrued Capital Repayment')    
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(3,'Currency Revaluation')     
           
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(4,'Other')          
              
     end      
   else if ((@InvestCode >= 10) and (@InvestCode <= 11)) /* Offshore Investments */       
     begin        
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(1,'Change in Market Value')        
          
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(2,'Currency Revaluation')     
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(3,'Other')          
              
     end     
   else if @InvestCode = 12 /* Endowments */       
     begin        
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(1,'Bonus')        
    
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(2,'Currency Revaluation')     
    
       Insert Into @tbl_Var (TransType,TransDesc)        
               Values(3,'Other')          
              
     end       
  return        
 end
go

