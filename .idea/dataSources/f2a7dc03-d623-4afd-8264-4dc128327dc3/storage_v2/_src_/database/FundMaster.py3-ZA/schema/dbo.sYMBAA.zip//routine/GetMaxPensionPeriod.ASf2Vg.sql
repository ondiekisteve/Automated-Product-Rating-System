CREATE PROCEDURE [dbo].[GetMaxPensionPeriod]
@SCHEMENO Int
--with Encryption
as

declare @Year int,@Month int

Select @Year = Max(PayYear) from PensionArrears where schemeNo = @SchemeNo

if @Year is not null
Select @Month = Max(PayMonth) from PensionArrears where schemeNo = @SchemeNo
and PayYear = @Year
else
  begin
   Select @Year = 2000,@Month = 1 
  end

Select @Year as PayYear,@Month as PayMonth
go

