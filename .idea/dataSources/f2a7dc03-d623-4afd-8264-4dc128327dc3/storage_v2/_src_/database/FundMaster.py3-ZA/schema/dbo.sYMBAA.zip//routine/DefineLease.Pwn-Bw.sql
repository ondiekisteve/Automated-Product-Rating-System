















CREATE PROCEDURE DefineLease
@SchemeNo varchar(15),
@PropCode int,
@UnitNo varchar(15),
@Tenant int,
@StartDate Datetime,
@EndDate Datetime,
@EscalClause float,
@EscalDesc varchar(100),
@RentFreq Int,
@EscalStart Datetime,
@Area float,
@Rent float,
@Service float,
@TransMode Bit,
@Cancelled Bit
--with Encryption
as

if @TransMode = 0
begin
if Exists (select * from Leases where SchemeNo = @schemeNo and Propertycode = @Propcode and 
           unitNo = @UnitNo and Tenantcode = @Tenant and StartDate = @StartDate)
   begin
       raiserror('Error!!!, This Lease already Exists- Define another',16,1)
       return
   end
else
  begin
  Insert into Leases (SchemeNo,Propertycode,UnitNo,Tenantcode,StartDate,EndDate,EscalClause,EscalDesc,
                      PaymentFreq,CurrLease,EscalStartDate,Area,RentPerUnit,ServicePerUnit,LeaseCancelled)
              Values(@SchemeNo,@PropCode,@UnitNo,@Tenant,@StartDate,@EndDate,@EscalClause,@EscalDesc,
                     @RentFreq,1,@EscalStart,@Area,@Rent,@Service,@Cancelled)

  update Leases set CurrLease = 0
  where SchemeNo = @schemeNo and Propertycode = @Propcode and 
  unitNo = @UnitNo and Tenantcode = @Tenant and StartDate < @StartDate
  end
end
else
begin
   Update Leases set StartDate = @StartDate,EndDate = @EndDate,EscalClause = @EscalClause,
                     PaymentFreq = @RentFreq,EscalStartDate = @EscalStart,Area = @Area,
                     RentPerUnit = @Rent,ServicePerUnit = @Service,LeaseCancelled = @Cancelled
   where SchemeNo = @schemeNo and Propertycode = @Propcode and 
   unitNo = @UnitNo and Tenantcode = @Tenant and StartDate = @StartDate
end


go

