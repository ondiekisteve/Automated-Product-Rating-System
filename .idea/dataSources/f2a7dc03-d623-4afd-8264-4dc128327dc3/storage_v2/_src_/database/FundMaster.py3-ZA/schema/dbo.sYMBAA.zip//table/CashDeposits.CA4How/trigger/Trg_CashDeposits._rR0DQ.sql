CREATE TRIGGER [dbo].[Trg_CashDeposits] ON [dbo].[CashDeposits] 
FOR INSERT
AS

declare @SchemeNo Int,@DepositNo Int,@UserName varchar(60),@DateInvested datetime,@YearClosed smallInt,@Rollover smallint

select @UserName = user


select @schemeNo = SchemeNo,@DepositNo = DepositNo,@DateInvested = TransDate,@Rollover = Rollover from Inserted
/*
select @YearClosed = YearClosed from SchemeYears where schemeNo = @schemeNo and StartDate <= @DateInvested
and EndDate >= @DateInvested

if @YearClosed >= 1
   begin
       raiserror('You cannot Add/Edit/Delete transactions in a closed Year',16,1)
       rollback tran
   end
*/

if @Rollover is null select @Rollover = 0

if @Rollover = 0
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@DepositNo,5,150,@DepositNo,1,@UserName
go

