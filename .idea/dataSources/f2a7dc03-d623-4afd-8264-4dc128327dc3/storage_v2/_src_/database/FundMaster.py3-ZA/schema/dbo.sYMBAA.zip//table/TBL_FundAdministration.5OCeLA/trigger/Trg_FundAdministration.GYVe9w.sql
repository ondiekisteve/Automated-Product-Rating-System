CREATE TRIGGER [dbo].[Trg_FundAdministration] ON [dbo].[TBL_FundAdministration] 
--with encryption
for insert
as

declare @schemeNo Int,@Counter bigInt,@UserName varchar(60),@Surplus decimal(20,2),@Credit decimal(20,2)

select @schemeNo  = SchemeNo,@Counter = TransCode,@Surplus = Receipt,@Credit = Payment from Inserted

select @UserName = user  

if @Surplus > 0 /* Inflows */
   Exec Proc_Auto_Insert_InvPosting @schemeNo,@Counter,24,340,@Counter,0,@UserName 
else if @Credit > 0
   Exec Proc_Auto_Insert_InvPosting @schemeNo,@Counter,24,341,@Counter,1,@UserName
go

