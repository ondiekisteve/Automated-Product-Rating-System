








































CREATE PROCEDURE AssetDistr
@SCHEMENO Int,
@AssetMode Int
--with Encryption
as

Select * from AssetAllocation
where AssetMode = @AssetMode and SchemeNo = @SchemeNo


go

