CREATE PROCEDURE [dbo].[Proc_Invest_Rollback]      
@schemeNo int,      
@PostNo int,      
@TransCat int      
--with encryption      
as      
      
declare @PaymentNo int,@VoucherNo int,@VoucherInc int,@InvestCode int,@TransType int,      
@TransNo int,@InvCode int,@RecOrPay smallint      
      
select @InvestCode = InvestCode,@TransType = TransType,@TransNo = TransNo,@InvCode = InvCode,      
@RecOrPay = ReceiptOrPayment        
from tbl_invest_posting where PostNo = @PostNo       
      
select @PaymentNo = PaymentNo from directpayment where PostNo = @PostNo and schemeno = @schemeNo    
and Tran_status = 0     
    
Update tbl_invest_posting set TranStatus = 2 where PostNo = @PostNo   
      
if @RecOrPay = 0 /* Direct Receipts */      
   begin      
     select @VoucherNo  = RecTransNo       
     from TBL_Receipts_Register where TransNo_FK = @PaymentNo and schemeno = @schemeNo      
      
     UPDATE directpayment set Tran_status = -1       
     where PaymentNo = @PaymentNo and schemeno = @schemeNo      
      
     UPDATE directpaymentInvoice set Tran_status = -1       
     where PaymentNo = @PaymentNo and schemeno = @schemeNo      
      
     UPDATE TBL_Receipts_Register set Tran_status = -1       
     where schemeNo = @schemeno and RecTransNo = @VoucherNo      
      
     UPDATE cashbook set Tran_status = -1       
     where schemeCode = @schemeno and RecTransNo = @VoucherNo      
      
     UPDATE schemeGeneralLedger set Tran_status = -1       
     where schemeCode = @schemeno and RecTransNo = @VoucherNo      
      
     update tbl_invest_posting set TranStatus = 2 where schemeNo = @schemeNo and PostNo = @PostNo       
  end      
else if @RecOrPay = 1 /* Direct Payments */      
   begin      
     select @VoucherNo  = VoucherNo,@VoucherInc  = VoucherInc       
     from paymentVoucher where memberno = @PaymentNo and schemeno = @schemeNo      
     and VoucherType = 21 and VoucherSubType = 1      
      
     UPDATE directpayment set Tran_status = -1       
     where PaymentNo = @PaymentNo and schemeno = @schemeNo      
      
     UPDATE directpaymentInvoice set Tran_status = -1       
     where PaymentNo = @PaymentNo and schemeno = @schemeNo      
      
     UPDATE PaymentVoucher set Tran_status = -1       
     where schemeNo = @schemeno and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc      
      
     UPDATE cashbook set Tran_status = -1       
     where schemeCode = @schemeno and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc      
      
     UPDATE schemeGeneralLedger set Tran_status = -1       
     where schemeCode = @schemeno and VoucherNo = @VoucherNo and VoucherInc = @VoucherInc      
      
     update tbl_invest_posting set TranStatus = 2 where schemeNo = @schemeNo and PostNo = @PostNo       
  end
go

