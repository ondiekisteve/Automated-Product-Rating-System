CREATE PROCEDURE [dbo].[Pensionbooks]      
@schemeno int,      
@penno varchar(15),      
@startdate datetime,      
@mode int /* 0 - All, 1 - Individual */      
      
as      
      
if object_id('tempdb..##pensionbooks') is not null drop table ##pensionbooks      
      
begin      
create table ##pensionbooks      
(      
bookcode int identity(1,1) primary key,      
memberno int,      
penno varchar(15),      
fullname varchar(120),      
NationalIdNo Varchar(15),      
description varchar(60),      
datepayable datetime,      
Periodpayable varchar(60),      
Amount decimal(20,4),
AmountInWords varchar(255)   
)      
end      
      
      
declare @description varchar(60),@Memberno int, @amount decimal(20,3), @pensionfreq int, @pensionstartdate datetime, @periodpayable varchar(60),      
@memorben int,@startdate1 datetime,@EndDate1 datetime,@fullname varchar(120),@idnumber varchar(15),@sDate datetime,      
@enddate datetime,@Kuanza datetime,@AmountInWords varchar(255),@CurrCode int      
 /* EndDate of the Year */ 

select @CurrCode = CurrCode from scheme where schemeCode = @schemeNo     
      
if @mode = 0      
begin      
      
select @SDate = StartDate,@enddate = enddate from SchemeYears where schemeNo = @schemeNo and StartDate <= @StartDate      
and EndDate >= @StartDate      
      
select @Kuanza = @StartDate      
select @StartDate = @sDate      
      
declare bookcsr cursor for      
select p.memberno,p.penno,m.sname+','+m.fname+' '+m.onames,p.pensionfreq,p.pensionstartdate,      
p.monpension, 'Member Receiving Pension' particulars,m.idnumber       
from pen_CertExist x inner join members m on x.schemeno = m.schemeno and x.memberno = m.memberno       
                     inner join Pensioner p on x.schemeno = p.schemeno and x.memberno = p.memberno       
                                and p.PayType = 4 and p.Hold = 1      
where x.schemeno = @schemeno and x.DatePrepared = @Kuanza and x.PobPrinted = 0 and x.Received = 1      
      
order by m.memberno,m.companyid      
end      
else      
begin        
select @enddate = enddate from SchemeYears where schemeNo = @schemeNo and StartDate <= @StartDate      
and EndDate >= @StartDate      
      
declare bookcsr cursor for      
select p.memberno,p.penno,m.sname+','+m.fname+' '+m.onames,p.pensionfreq,p.pensionstartdate,      
p.monpension, 'Member Receiving Pension' particulars,m.idnumber       
from pen_CertExist x inner join members m on x.schemeno = m.schemeno and x.memberno = m.memberno       
                     inner join Pensioner p on x.schemeno = p.schemeno and x.memberno = p.memberno       
                                and p.PayType = 4 and p.Hold = 1      
where x.schemeno = @schemeno and x.DatePrepared = @Kuanza and x.PobPrinted = 0 and x.Received = 1      
     and x.penno = @penno      
end      
      
open bookcsr      
      
fetch from bookcsr into @memberno,@penno,@fullname,@pensionfreq,@pensionstartdate,@amount, @description,@idnumber      
      
while @@fetch_status =0      
begin    
      
Exec Proc_NumToWords @CurrCode, @amount,@AmountInWords output 
      
select @Kuanza = @StartDate 
if @idnumber is null select @idnumber = ' '      
select @startdate1 = @startdate      
if @pensionfreq = 1 select @pensionfreq = 1      
else if @pensionfreq = 2 select @pensionfreq = 3      
else if @pensionfreq = 3 select @pensionfreq = 6      
else if @pensionfreq = 4 select @pensionfreq = 12      
      
while @startdate1 < @enddate      
begin      
if @pensionfreq = 1      
select @periodpayable = datename(month,@startdate1)+', '+cast(datepart(year,@startdate1) as varchar(4))      
else       
begin      
select @EndDate1 = dateadd(month,@pensionfreq,@startdate1)-1      
select @periodpayable = datename(month,@startdate1)+', '+cast(datepart(year,@startdate1) as varchar(4))+' - '+datename(month,@EndDate1)+', '+cast(datepart(year,@EndDate1) as varchar(4))      
end      
insert into ##pensionbooks (memberno,penno,fullname,description,datepayable,periodpayable,Amount,NationalIdNO,AmountInWords)      
 values(@memberno,@penno,Upper(@fullname),Upper(@description),dateadd(month,@pensionfreq,@startdate1)-1,Upper(@periodpayable),@amount*@pensionfreq,@IdNUmber,@AmountInWords)      
      
select @startdate1 = dateadd(month,@pensionfreq,@startdate1)      
end          
UPDATE Pen_CertExist set PobPrinted = 1,DatePrinted = GetDate() where schemeNo = @SchemeNo    
and DatePrepared = @Kuanza and PenNo = @PenNo    
    
select @memberno = 0,@penno =' ',@fullname =' ',@pensionfreq = 0,@amount =0.00, @description =' ',@idnumber=' ',@AmountInWords=''      
fetch next from bookcsr into @memberno,@penno,@fullname,@pensionfreq,@pensionstartdate,@amount, @description,@idnumber      
end      
close bookcsr      
deallocate bookcsr   
  
select * from ##pensionbooks order by bookcode
go

