CREATE PROCEDURE [dbo].[Proc_Get_ImprestNo]                    
@schemeNo Int,            
@bankCode Int,    
@TransDate datetime,      
@ImprestNo Int Out,      
@Balance Decimal(20,6) Out                    
--with Encryption                    
as                    
declare @Imprest Decimal(20,6),@Expended Decimal(20,6),@BalanceBF Decimal(20,6)                    
select @ImprestNo = Max(ImprestNo) from TBL_Imprest where schemeNo = @schemeNo            
and PettyCode = @bankCode and ImprestDate <= @TransDate          
                    
IF @ImprestNo is null select @ImprestNo = 0                   
                  
if @ImprestNo > 0                  
   begin                  
        select @Imprest = Imprest,@BalanceBF = BalanceBF       
        from TBL_Imprest where schemeNo = @schemeNo and ImprestNo = @ImprestNo                   
                      
        if @BalanceBF is null select @BalanceBF = 0              
              
        select @Expended = sum(Credit) - sum(Debit)       
        from Cashbook where schemeCode = @schemeNo and ImprestNo = @ImprestNo
        and Tran_Status = 0                  
        if @Expended is null select @Expended = 0                  
                  
        select @Balance = (@Imprest + @BalanceBF) - @Expended                  
   end                  
else select @Balance = 0
go

