CREATE PROCEDURE [dbo].[Proc_Calc_Purchase_YD]
@SchemeNo Int,
@Proc_Date datetime,
@IntMode Int
--with Encryption
as

declare @totBalance decimal(20,6),@MemberNo Int,@AcctPeriod Int,@Month Int,@Year Int

select @Month  = datepart(month,@Proc_Date),@Year  = datepart(Year,@Proc_Date)

declare pcsr cursor for
select m.MemberNo
from Benefits b 
     inner join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo
                          and m.DoCalc <= @Proc_Date
where b.PurchasePrice > 0 and b.schemeNo = @schemeNo and b.Purch_Posted = 0

open pcsr
fetch from pcsr into @MemberNo
while @@fetch_status = 0
begin
   Exec Proc_Calc_Purchase_Interest_Daily @SchemeNo,@MemberNo,@Proc_Date,@IntMode,@totBalance output,@AcctPeriod out

   if @totBalance is null select @totBalance = 0

   if Not Exists (Select * from MemberOpeningBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo      
                                 and AcctPeriod = @AcctPeriod)      
                      insert  into memberOpeningBalances (schemeNo, memberNo, empCont, empVolCont, emprCont, emprVolCont, schemeYear, schemeMonth, AcctPeriod,      
                       PreEmpCont,PreEmprCont,PreAVC,Transfer,LockedIn,UnlockDate,PurchasePrice)      
                      values (@schemeNo, @memberNo, 0, 0, 0, 0, @Year, @Month, @AcctPeriod,      
                      0,0,0,0,0,@Proc_Date,@totBalance)      
   else      
      Update MemberOpeningBalances set PurchasePrice = @totBalance
      where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod      

   select @MemberNo = 0,@AcctPeriod = 0
   fetch next from pcsr into @MemberNo
end
close pcsr
deallocate pcsr
go

