CREATE PROCEDURE [dbo].[SeeUnPaidPensionBen]  
@SCHEMENO Int,
@Posted Int  
--with Encryption  
as  
  
if object_id('tempdb..#UnPaid') is null  
  
begin  
create table #UnPaid  
(  
        [DepCode][int] identity (1,1) Primary Key,  
        [PenNo] [varchar](50)NULL ,  
        [MonPension][float],  
        [MemberNo] [Int]NULL,  
        [Dependantcode][int] not null,  
        [surname][varchar](50),  
        [Othernames][varchar](60),  
        [StartDate][Datetime],  
        [EndDate][Datetime],  
        [TotalLiability][float],
        MaxCode Int        
)   
   
end  
  
Insert into #UnPaid  
Select p.PenNo,p.MonPension, m.MemberNo, m.Dependantcode,   
upper(m.sname) as surname,m.fname +' '+m.Oname as Othernames,  
u.StartDate,u.EndDate, (dateDiff(Month,u.StartDate,u.EndDate)+ 1) * p.MonPension   
as TotalLiability,u.MaxCode  
from UnPaidPensionBen u  
     inner Join PenBeneficiary p on u.SchemeNo = p.SchemeNo and u.MemberNo = p.MemberNo  
  and u.DependantCode = p.Dependantcode  
     inner Join Dependants m  on u.SchemeNo = m.SchemeNo and u.MemberNo = m.MemberNo  
                              and u.DependantCode = m.Dependantcode  
where u.SchemeNo = @SchemeNo and U.Paid = @Posted 
  
Insert into #UnPaid  
Select p.PenNo,p.MonPension, m.MemberNo, m.Dependantcode,   
upper(m.sname) as surname,m.fname +' '+m.Oname as Othernames,  
u.StartDate,u.EndDate, (dateDiff(Month,u.StartDate,u.EndDate)+1) * p.MonPension   
as TotalLiability,u.MaxCode  
from UnPaidPensionBen u  
     inner Join MemBeneficiary p on u.SchemeNo = p.SchemeNo and u.MemberNo = p.MemberNo  
  and u.DependantCode = p.Dependantcode  
     inner Join Dependants m  on u.SchemeNo = m.SchemeNo and u.MemberNo = m.MemberNo  
                              and u.DependantCode = m.Dependantcode  
where u.SchemeNo = @SchemeNo and U.Paid = @Posted 
  
Select * from #UnPaid
go

