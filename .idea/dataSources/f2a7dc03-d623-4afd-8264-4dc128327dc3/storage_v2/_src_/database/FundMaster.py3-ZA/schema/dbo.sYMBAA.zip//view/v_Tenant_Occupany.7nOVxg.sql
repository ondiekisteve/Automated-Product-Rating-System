CREATE VIEW [dbo].[v_Tenant_Occupany]    
--with Encryption    
as    
Select L.LeaseNo,l.StartDate,l.EndDate,l.SchemeNo,l.TenantCode,case l.RentMode    
                                       when 0 then l.Rent    
                                       when 1 then l.RentPerMeter * l.Area    
                                       end as MonthlyRent,     
case L.PaymentFreq                           
          when 1 then 'Monthly'                          
          when 2 then 'Quarterly'                          
          when 3 then 'Semi-Annually'                          
          when 4 then 'Annually'                          
          else 'Not Defined'                          
          end as RentFrequency,        
          case L.LeaseCancelled                          
          when 0 then 'Active'                          
          when 1 then 'Cancelled'                                            
          else 'Not Defined'                          
          end as LeaseStatus,    
p.PropertyName, u.UnitNo,       
f.CurrencyDesc as CurrencyCode                          
from Leases l     
     inner Join Property p on l.schemeNo = p.schemeNo and l.PropertyCode = p.propertyCode    
     inner Join Units u on l.schemeNo = u.schemeNo and l.PropertyCode = u.PropertyCode and l.UnitCode = u.UnitCode                     
     inner Join CurrencyType f on l.CurrCode = f.CurrCode
go

