CREATE PROCEDURE [dbo].[CalculateVesting_Britak]
@SCHEMENO Int,
@MemberNo Int,
@Vesting float Out
as
declare 
@VestingYears Int, @StartPeriod float,@EndPeriod float,@Reason Int,@GEPF smallInt,@SponsorCode Int,@schemeMode Int,
@FundType varchar(2)

select @GEPF = GEPF,@schemeMode = SchemeMode,@FundType = FundType from Scheme where schemeCode = @schemeNo
if @schemeMode is null select @schemeMode = 0
if @FundType is null select @FundType = 'DC'

IF @FundType = 'IF'
   SELECT @Vesting = 100.00
else
  begin
select @Reason = ReasonforExit,@SponsorCode = SponsorCode 
from Members where schemeNo = @schemeNo and MemberNo = @MemberNo

if @GEPF is null select @GEPF = 0

if @GEPF = 0
begin
Exec Proc_VestingYears @schemeNo,@MemberNo,@VestingYears Out

if @schemeMode = 0
   Select @StartPeriod = Max(startYear) from TBL_Vestingformula where SchemeNo = @schemeNo
else
   Select @StartPeriod = Max(startYear) from TBL_Vestingformula where SchemeNo = @schemeNo
   and SponsorCode = @SponsorCode

if ((@Reason = 1) or (@Reason = 5) or (@Reason = 9) or (@Reason = 11)) /* Death,Ill-Health,Redundancy,Retrenchment */
   select @Vesting = 100
else
   begin
      if @VestingYears >= @StartPeriod
         select @Vesting = 100.00
      else
         begin
          if @SchemeMode = 0
           select @Vesting = Entitlement from TBL_Vestingformula 
           where (SchemeNo = @schemeNo)
           and (StartYear <= @VestingYears and EndYear >= @VestingYears)
          else if @SchemeMode = 1
           select @Vesting = Entitlement from TBL_Vestingformula 
           where (SchemeNo = @schemeNo)
           and (StartYear <= @VestingYears and EndYear >= @VestingYears)
           and SponsorCode = @SponsorCode

          if @vesting is null  select @Vesting = 100

       end
  end
end
else if @GEPF = 1 /* GEPF Only Dismissals are not fully vested */
begin
   if @Reason = 16 /* Dismissal */
      select @vesting = 0.00
   else
      select @Vesting = 100.00

end
end
go

