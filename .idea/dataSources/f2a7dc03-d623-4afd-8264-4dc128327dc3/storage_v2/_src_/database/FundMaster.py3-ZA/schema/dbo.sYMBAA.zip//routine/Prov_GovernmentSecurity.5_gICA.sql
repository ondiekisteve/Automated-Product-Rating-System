CREATE PROCEDURE [dbo].[Prov_GovernmentSecurity](@SchemeNo Int,@GovComm Int,@InvStatus Int)                                    
--with Encryption                                    
as                                    
if object_id('tempdb..#tt_GovernmentSecurities') is null                                    
begin                                    
create table #tt_GovernmentSecurities(SchemeNo int not null,                                    
                       SecurityNo Int,                                    
                       AmountInvested Decimal(20,6),                                    
                       MaturityDate Datetime,                                    
                       InterestRate Decimal(9,2),                                    
                       TransDate Datetime,                                    
                       InvestDesc varchar(120),                                    
                       Description varchar(120),                                    
                       InvName varchar(100),                                    
                       IncomeDue Decimal(20,6),                                    
                       NominalValue Decimal(20,6),                                    
                       InvStatus Int,                                    
                       Frequency varchar(20),                                    
                       ManagerName varchar(120),                                
                       MatStatus varchar(4),                              
                       GLMapping varchar(3),                          
                       CurrCode varchar(3),                        
                       rCurrCode int,                  
                       InvestCode Int,    
                       MaxAccrualDate varchar(20)                                    
                       )                                    
end                                    
                                    
DECLARE @SecurityNo Int,@PcntSoldB4 float,@PcntSoldAfter float,@PcntTransfer decimal(9,2),                                    
@AmountInvested Decimal(20,6),@NominalValue Decimal(20,6),@TransferDate Datetime,                                
@CurDate Datetime,@MatDate Datetime,@MatStatus varchar(4),@GLMapping varchar(3),@CurrCode varchar(3),                        
@rCurrCode int,@xCurrCode int,@Aflife int,@InvestCode int,@PartRedeem decimal(20,6),@PartCost decimal(20,6),        
@AcquireCost float, @AcquireFace float,@DisposalCost float, @DisposalFace float,@MaxAccrualDate datetime,@sMaxAccrualDate varchar(20)    
    
if @GovComm = 0        
   select @MaxAccrualDate = max(TransDate) from TBL_Invest_Receivable where schemeNo = @schemeNo and InvestCode = 4    
else if @GovComm = 1        
   select @MaxAccrualDate = max(TransDate) from TBL_Invest_Receivable where schemeNo = @schemeNo and InvestCode = 7    
       
if @MaxAccrualDate is not null    
   Exec DateToStr @MaxAccrualDate,@sMaxAccrualDate Out    
else    
   select @sMaxAccrualDate = 'None'                              
                                
select @CurDate = GetDate(),@xCurrCode = currCode,@Aflife = Aflife from scheme where schemeCode = @schemeNo                   
                  
if @Aflife is null select @Aflife = 0                                   
                  
                                    
if @GovComm = 0 /* Government Paper */                                    
begin                                    
declare GovCommCsr Cursor for                                    
Select SecurityNo,MaturityDate,case tiedtogl                              
       when 0 then 'No'                              
       when 1 then 'Yes' end as GLMapping,'KES',@xCurrCode,4                                               
from GovernmentSecurities where schemeNo = @schemeNo and Redeem = @InvStatus                                    
end                                    
else if @GovComm = 1 /* Commercial Paper */                                    
begin                                    
declare GovCommCsr Cursor for                                    
Select c.PaperNo,c.MaturityDate,case c.tiedtogl                              
       when 0 then 'No'                              
       when 1 then 'Yes' end as GLMapping,F.CurrencyCode,c.CurrCode,7                               
from CommercialPaper c                          
     inner Join CurrencyType F on c.CurrCode = F.CurrCode                          
where c.schemeNo = @schemeNo and c.Redeem = @InvStatus                                    
end                                    
Open GovCommCsr                                    
Fetch from GovCommCsr Into @SecurityNo,@MatDate,@glMapping,@CurrCode,@rCurrCode,@InvestCode                                   
while @@fetch_Status = 0                                    
begin                        
   if @glMapping is null select @glMapping = 'No'                                 
   if @CurDate > @MatDate                                
      select @MatStatus = 'Yes'                                
  else                                
      select @MatStatus = 'No'              
              
  Select @PartRedeem = sum(Amount),@PartCost = sum(Cost)                                                   
  from TBL_Partial_Redemption where schemeNo = @schemeNo and InvCode = @SecurityNo                 
                            
  if @PartRedeem is null select @PartRedeem = 0              
  if @PartCost is null select @PartCost = 0              
                                
   select @PcntTransfer = PcntTransfer,@TransferDate = TransferDate                                     
   from InvestmentsTransfer where schemeNo = @schemeNo and TransferFrom = @SecurityNo                                    
                                    
   if @GovComm = 0                      
      BEGIN                                  
        select @AmountInvested = AmountInvested,@NominalValue = NominalValue                                     
        from GovernmentSecurities where schemeNo = @schemeNo and SecurityNo = @SecurityNo                     
                                     
      END                                   
   else if @GovComm = 1                     
      BEGIN                                   
        select @AmountInvested = AmountInvested,@NominalValue = NominalValue                                     
        from CommercialPaper where schemeNo = @schemeNo and PaperNo = @SecurityNo                    
                                     
        END                                    
                                    
   select @AcquireCost = sum(FaceValue)/*sum(Cost)*/, @AcquireFace = sum(FaceValue) from GovernmentAcquisition        
   where schemeNo = @schemeNo and SecurityNo = @SecurityNo         
           
   if @AcquireCost is null select @AcquireCost = 0        
   if @AcquireFace is null select @AcquireFace = 0        
        
   select @DisposalCost = sum(AccumCostOfSale), @DisposalFace = sum(FaceValue) from SaleGovComm        
   where schemeNo = @schemeNo and PaperNo = @SecurityNo         
        
   if @DisposalCost is null select @DisposalCost = 0        
   if @DisposalFace is null select @DisposalFace = 0        
                 
   select @AmountInvested = (@AmountInvested + @AcquireCost) - (@PartCost + @DisposalCost),        
          @NominalValue = (@NominalValue + @AcquireFace) - (@PartRedeem + @DisposalFace)             
                                 
   if @GovComm = 0 /* Government Paper */                                    
   Insert Into #tt_GovernmentSecurities                                     
   SELECT g.SchemeNo, g.SecurityNo, @AmountInvested,                                    
   g.MaturityDate,                                       
   g.InterestRate, g.TransDate, i.InvestDesc, si.Description, si.Invname, (@NominalValue *  (g.InterestRate/100.0000000000)) as IncomeDue,                                      
  @NominalValue,si.InvStatus,                                      
   case g.InterestFreq                                       
            when 1 then 'Monthly'                                      
            when 2 then 'Quarterly'                                      
            when 3 then 'Half Yearly'        
   when 4 then 'Yearly'                                      
   end as Frequency,                                      
   im.ManagerName,@MatStatus,@glMapping,@CurrCode,@rCurrCode,@InvestCode,@sMaxAccrualDate                                       
   FROM GovernmentSecurities g                                      
    INNER JOIN InvestmentTypeDetail i ON g.SecurityType = i.InvestTypeCode                                       
    INNER JOIN  Investments si ON g.schemeNo = si.SchemeNo ANd g.SecurityNo = si.InvCode and si.InvStatus = @InvStatus                                      
    inner Join InvestmentManagers im on g.schemeNo = im.schemeNo and g.Manager = im.simCode                                     
   where g.schemeNo = @schemeNo and g.SecurityNo = @SecurityNo                                    
                                    
   else if @GovComm = 1 /* Commercial Paper */                                    
   Insert Into #tt_GovernmentSecurities                                     
   SELECT g.SchemeNo, g.PaperNo, @AmountInvested,                                    
   g.MaturityDate,                                       
   g.InterestRate, g.TransDate, i.InvestDesc, si.Description, si.Invname, (@NominalValue *  (g.InterestRate/100.0000000000)) as IncomeDue,                                      
   @NominalValue,si.InvStatus,                                      
   case g.InterestFreq                                       
            when 1 then 'Monthly'                                      
            when 2 then 'Quarterly'                                      
            when 3 then 'Half Yearly'                                      
            when 4 then 'Yearly'                                      
   end as Frequency,                                      
   im.ManagerName,@MatStatus,@glMapping,@CurrCode,@rCurrCode,@InvestCode,@sMaxAccrualDate                                       
   FROM CommercialPaper g                                       
    INNER JOIN InvestmentTypeDetail i ON g.PaperType = i.InvestTypeCode                                       
    INNER JOIN  Investments si ON g.schemeNo = si.SchemeNo ANd g.PaperNo = si.InvCode and si.InvStatus = @InvStatus                                     
    inner Join InvestmentManagers im on g.schemeNo = im.schemeNo and g.Manager = im.simCode                                     
   where g.schemeNo = @schemeNo and g.PaperNo = @SecurityNo                                    
   --end                                      
                                    
                                    
   select @SecurityNo = 0,@PcntSoldB4 =0,@PcntSoldAfter =0,@PcntTransfer=0,                                    
   @AmountInvested =0,@NominalValue =0,@glMapping ='',@CurrCode='',@rCurrCode = @xCurrCode,@InvestCode = 0,              
   @PartRedeem = 0,@PartCost = 0                                   
                                     
   Fetch next from GovCommCsr Into @SecurityNo,@MatDate,@glMapping,@CurrCode,@rCurrCode,@InvestCode                                    
end                                    
Close GovCommCsr                                    
Deallocate GovCommCsr                    
                              
                                    
select * from #tt_GovernmentSecurities WHERE AmountInvested > 0 --order by InvName,TransDate       
order by len(right(InvName, len(InvName) - len((left(Invname, len(left(InvName, (PatIndex('%/%',InvName)))) + 5))))),      
         right(InvName, len(InvName) - len((left(Invname, len(left(InvName, (PatIndex('%/%',InvName)))) + 5)))),      
         right(left(Invname, len(left(InvName, (PatIndex('%/%',InvName)))) + 4),4)
go

