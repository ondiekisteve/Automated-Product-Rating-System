











CREATE FUNCTION fn_GL_Pay_Rec_Mapping(@SCHEMENO Int,@Pay_Rec Int)
returns @tbl_var table(SchemeNo varchar(15),
                       TransCode Int Primary key,
                       Trans_Name varchar(100),
                       Dr_Account varchar(30),
                       Dr_Account_Name varchar(100),
                       Cr_Account varchar(30),
                       Cr_Account_Name varchar(100),
                       Trans_Type Int,
                       TransactionGroup varchar(100)
                       )
as
 begin
  if @Pay_Rec = 0
     
     Insert Into @tbl_Var(SchemeNo,TransCode,Trans_Name,Dr_Account,Dr_Account_Name,
                          Cr_Account,Cr_Account_Name,Trans_Type,TransactionGroup)
                 select t.SchemeNo,t.TransCode,t.Trans_Name,t.Dr_Account,t.Dr_Account_Name,
                 t.Cr_Account,t.Cr_Account_Name,t.Trans_Type,case t.Trans_Type 
                 when 0 then 'Member Benefits'
                 when 1 then 'Beneficiary Benefits'
                 end as TransactionGroup
                 from tbl_Payables t
                 where t.SchemeNo = @schemeNo
  else
     Insert Into @tbl_Var(SchemeNo,TransCode,Trans_Name,Dr_Account,Dr_Account_Name,
                          Cr_Account,Cr_Account_Name,Trans_Type,TransactionGroup)
                 select t.SchemeNo,t.TransCode,t.Trans_Name,t.Dr_Account,t.Dr_Account_Name,
                 t.Cr_Account,t.Cr_Account_Name,t.Trans_Type,case t.Trans_Type 
                 when 0 then 'Member Benefits'
                 when 1 then 'Beneficiary Benefits'
                 end as TransactionGroup
                 from tbl_Receivables t
                 where t.SchemeNo = @schemeNo
  return
 end


go

