CREATE PROCEDURE [dbo].[Proc_Update_Surplus_Cont]
@SCHEMENO Int,
@BatchId Int
--with Encryption
as
declare @BatchDate Datetime,@MemberNo Int
select @BatchDate = BatchDate from Batches where schemeNo = @schemeNo and BatchId = @BatchId

declare Acsr Cursor for
Select m.MemberNo from Members m 
       inner Join BatchEntry b on m.schemeNo = b.schemeNo and m.MemberNo = b.MemberNo
       and b.BatchId = @BatchId 
where m.schemeno = @schemeNo and m.ReasonforExit > 0 and m.DoCalc < @BatchDate

Open Acsr
fetch from acsr into @MemberNo
while @@fetch_Status = 0
begin
   update Members set Has_Surplus_Cont = 1
   where schemeNo = @schemeNo and MemberNo = @MemberNo

   update Contributionssummary set Surplus = 1
   where schemeNo = @schemeNo and MemberNo = @MemberNo and BatchId = @BatchId
   
   select @MemberNo = 0
   fetch next from acsr into @MemberNo
end
Close Acsr
Deallocate Acsr
go

