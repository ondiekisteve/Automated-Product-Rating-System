CREATE PROCEDURE [dbo].[InsertMortgage]  
@SCHEMENO Int,  
@MortgageNo Int,    
@Manager Varchar(15)  
--with Encryption  
as  
INSERT INTO Mortgage  
(schemeNo,MortgageNo,Manager)  
Values  
(@schemeNo,@MortgageNo,@Manager)
go

