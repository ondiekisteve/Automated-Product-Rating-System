CREATE PROCEDURE [dbo].[Proc_Investments_Transfer]      
@schemeNo Int,      
@TransferFrom Int,      
@TransferDate Datetime,      
@PcntTransfer float,      
@NewFundManager varchar(15),      
@Ngoa Int      
--with Encryption      
as      
      
declare @MarketValue Decimal(20,6),@Cost Decimal(20,6),@NoOfUnits Int,@InvCode Int,@PricePerShare Decimal(20,6),      
@EndDate Datetime      
/* Get Most Current Market Value/Balances C/F on or before the Transfer */      
select @EndDate = Max(EndDate) from InvestmentsValue where schemeNo = @schemeNo and EndDate <= @TransferDate      
      
select @MarketValue = MarketValue,@Cost = Cost,@NoOfUnits = NoOfUnits from InvestmentsValue      
where SchemeNo = @schemeNo and EndDate = @EndDate and InvCode = @TransferFrom      
      
if @NoOfUnits > 1      
   select @MarketValue = @MarketValue * (@PcntTransfer/100.00),@Cost = @Cost * (@PcntTransfer/100.00),      
   @NoOfUnits = @NoOfUnits * (@PcntTransfer/100.00)      
else      
   select @MarketValue = @MarketValue * (@PcntTransfer/100.00),@Cost = @Cost * (@PcntTransfer/100.00),      
   @NoOfUnits = 1       
      
select @PricePerShare = @Cost/@NoOfUnits,@MarketValue = @MarketValue/@NoOfUnits      
      
if @Ngoa = 0      
   begin      
      select @InvCode = Max(InvCode) from Investments where SchemeNo = @schemeNo      
      
      select @InvCode = @InvCode + 1      
   end      
else if @Ngoa = 1      
  begin      
      select @InvCode = TransferTo from InvestmentsTransfer where SchemeNo = @schemeNo and TransferFrom = @TransferFrom      
  end      
      
if Exists(Select EquityNo from Equity where schemeNo = @schemeNo and EquityNo = @TransferFrom)      
   /* Transfer Equities */      
   begin      
       if @Ngoa = 0      
       begin      
       Insert into InvestmentsTransfer(SchemeNo,TransferDate,MarketValue,Cost,NoOfUnits,TransferFrom,TransferTo,PcntTransfer,      
                                       FundManager)      
                              Values(@schemeNo,@TransferDate,@MarketValue,@Cost,@NoOfUnits,@TransferFrom,@InvCode,@PcntTransfer,      
                                     @NewFundManager)      
      
       Insert Into Investments (InvCode,SchemeNo,simCode,InvestCode,InvestCodeDetail,InvName,Description,InitValue,DateComm,      
                                InvStatus,DateRedeemed,RebateComm,Posted,MarketValue)      
                                select @InvCode,@schemeNo,@NewFundManager,InvestCode,InvestCodeDetail,InvName,Description,      
                                      @Cost,@TransferDate,InvStatus,DateRedeemed,RebateComm,      
                                      0,@MarketValue from Investments where SchemeNo = @schemeNo and invCode = @TransferFrom      

      
       Insert Into Equity (SchemeNo,EquityNo,EquityType,EquitySubClass,EquityDesc,NoofShares,PricePerShare,DateInvested,
                           EquityInMarket,EquityClass,EquityRate,Manager,Posted,RebateComm,MarketValue,Redeem,shareSuspended,UnderReceivership,
                           settlementdate, Fees, BrokerCode, AssetAcc, BankAcc,DividendsAcc,AccrDividendsAcc,FairValueAcc,GainLossOnSaleAcc)
       Select @schemeNo,@InvCode,EquityType,EquitySubClass,EquityDesc,@NoOfUnits,@PricePerShare,@TransferDate,
                           EquityInMarket,EquityClass,EquityRate, @NewFundManager,0,0,@MarketValue,0,0,0,settlementdate, Fees, BrokerCode, 
                           AssetAcc, BankAcc,DividendsAcc,AccrDividendsAcc,FairValueAcc,GainLossOnSaleAcc    
       from Equity where SchemeNo = @schemeNo and EquityNo = @TransferFrom      
       end      
       else if @Ngoa = 1      
       begin      
            Delete from InvestmentsTransfer where SchemeNo = @schemeNo and TransferFrom = @TransferFrom      
            Delete from Investments where SchemeNo = @schemeNo and InvCode = @InvCode      
            Delete from Equity where SchemeNo = @schemeNo and EquityNo = @InvCode      
       end      
             
   end      
else if Exists(Select SecurityNo from GovernmentSecurities where schemeNo = @schemeNo and SecurityNo = @TransferFrom)      
   /* Transfer Equities */      
   begin      
       if @Ngoa = 0      
       begin      
          Insert into InvestmentsTransfer(SchemeNo,TransferDate,MarketValue,Cost,NoOfUnits,TransferFrom,TransferTo,PcntTransfer,      
                                       FundManager)      
                              Values(@schemeNo,@TransferDate,@MarketValue,@Cost,@NoOfUnits,@TransferFrom,@InvCode,@PcntTransfer,      
                                     @NewFundManager)      
          Insert Into Investments (InvCode,SchemeNo,simCode,InvestCode,InvestCodeDetail,InvName,Description,InitValue,DateComm,      
                                InvStatus,DateRedeemed,RebateComm,Posted,MarketValue)      
                                select @InvCode,@schemeNo,@NewFundManager,InvestCode,InvestCodeDetail,InvName,Description,      
                                      @Cost,@TransferDate,InvStatus,DateRedeemed,RebateComm,      
                                      0,@MarketValue from Investments where SchemeNo = @schemeNo and invCode = @TransferFrom      
      
      
          Insert Into GovernmentSecurities (SchemeNo,SecurityNo,SecurityType,TransDate,AmountInvested,NominalValue,MaturityDate,InterestRate,Manager,InterestFreq,      
                                         InterestType,Posted,RebateComm,MarketValue,Redeem,InterestDate)      
          select @schemeNo,@InvCode,SecurityType,@TransferDate,AmountInvested * (@PcntTransfer/100.00),      
                                        NominalValue * (@PcntTransfer/100.00),MaturityDate,InterestRate,@NewFundManager,InterestFreq,InterestType      
                                        ,Posted,RebateComm,@MarketValue,Redeem,InterestDate      
          from GovernmentSecurities where SchemeNo = @schemeNo and SecurityNo = @TransferFrom      
       end      
       else if @Ngoa = 1      
       begin      
            Delete from InvestmentsTransfer where SchemeNo = @schemeNo and TransferFrom = @TransferFrom      
            Delete from Investments where SchemeNo = @schemeNo and InvCode = @InvCode      
            Delete from GovernmentSecurities where SchemeNo = @schemeNo and SecurityNo = @InvCode      
       end      
      
      
   end      
else if Exists(Select PaperNo from CommercialPaper where schemeNo = @schemeNo and PaperNo = @TransferFrom)      
   /* Transfer Equities */      
   begin      
       if @Ngoa = 0      
       begin      
       Insert into InvestmentsTransfer(SchemeNo,TransferDate,MarketValue,Cost,NoOfUnits,TransferFrom,TransferTo,PcntTransfer,      
                                       FundManager)      
                              Values(@schemeNo,@TransferDate,@MarketValue,@Cost,@NoOfUnits,@TransferFrom,@InvCode,@PcntTransfer,      
                                     @NewFundManager)      
       Insert Into Investments (InvCode,SchemeNo,simCode,InvestCode,InvestCodeDetail,InvName,Description,InitValue,DateComm,      
                                InvStatus,DateRedeemed,RebateComm,Posted,MarketValue)      
                                select @InvCode,@schemeNo,@NewFundManager,InvestCode,InvestCodeDetail,InvName,Description,      
                                      @Cost,@TransferDate,InvStatus,DateRedeemed,RebateComm,      
                                      0,@MarketValue from Investments where SchemeNo = @schemeNo and invCode = @TransferFrom      
      
       Insert Into CommercialPaper(SchemeNo,PaperNo,PaperType,TransDate,AmountInvested,NominalValue,MaturityDate,InterestRate,Manager,InterestFreq,      
                                         InterestType,Posted,RebateComm,MarketValue,Redeem,InterestDate)      
        select @schemeNo,@InvCode,PaperType,@TransferDate,AmountInvested * (@PcntTransfer/100.00),      
                                        NominalValue * (@PcntTransfer/100.00),MaturityDate,InterestRate,@NewFundManager,InterestFreq,InterestType,      
                                        Posted,RebateComm,@MarketValue,Redeem,InterestDate      
       from CommercialPaper where SchemeNo = @schemeNo and PaperNo = @TransferFrom      
       end      
       else if @Ngoa = 1      
       begin      
            Delete from InvestmentsTransfer where SchemeNo = @schemeNo and TransferFrom = @TransferFrom      
            Delete from Investments where SchemeNo = @schemeNo and InvCode = @InvCode      
            Delete from CommercialPaper where SchemeNo = @schemeNo and PaperNo = @InvCode      
       end      
   end
go

