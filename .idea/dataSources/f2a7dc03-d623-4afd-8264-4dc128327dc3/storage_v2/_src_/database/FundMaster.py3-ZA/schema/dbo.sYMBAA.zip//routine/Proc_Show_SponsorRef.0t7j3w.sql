CREATE PROCEDURE [dbo].[Proc_Show_SponsorRef]
@SCHEMENO Int,
@MemberNo Int
as
declare @SponsorCode Int

select @SponsorCode = SponsorCode from Members where schemeNo  = @schemeNo and MemberNo = @MemberNo

select @SponsorCode as SponsorCode,SponsorRef,SponsorName from Sponsor
where schemeNo = @schemeNo and SponsorCode = @SponsorCode
go

