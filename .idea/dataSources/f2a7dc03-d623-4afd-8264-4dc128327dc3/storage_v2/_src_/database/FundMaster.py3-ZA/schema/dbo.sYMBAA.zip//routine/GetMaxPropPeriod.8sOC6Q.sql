CREATE PROCEDURE [dbo].[GetMaxPropPeriod]
@SCHEMENO Int,
@PropCode int
--with Encryption
as

declare @PayYear int,@PropName varchar(100)
select @PayYear = Max(PayYear) 
from RentInvoice where SchemeNo = @SchemeNo and PropertyCode = @Propcode 

if @PayYear is null
   begin
      select @PropName = PropertyName from Property where SchemeNo = @schemeNo
      and PropertyCode = @PropCode
      raiserror('No rent Invoices have been processed for %s',16,1,@PropName)
      rollback tran
   end
else
select Max(PayMonth) as PayMonth,PayYear
from RentInvoice 
where SchemeNo = @SchemeNo and PropertyCode = @propcode and PayYear = @payYear
group by PayYear
go

