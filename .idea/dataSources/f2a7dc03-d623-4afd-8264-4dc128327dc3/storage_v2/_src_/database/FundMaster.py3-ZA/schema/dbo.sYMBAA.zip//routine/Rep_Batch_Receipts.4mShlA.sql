CREATE PROCEDURE [dbo].[Rep_Batch_Receipts]    
@SCHEMENO Int, 
@SponsorCode Int,   
@StartDate Datetime,    
@EndDate Datetime,
@Mode Int    
--with Encryption    
as    
    
declare @schemeName varchar(120)    
    
select @schemeName = SchemeName from scheme where SchemeCode = @SCHEMENO 

if @Mode = 0  
select @schemeName as SchemeName,p.SponsorName,r.ReceiptDate,r.ReceiptNo,r.cHEQUEnO,R.ReceiptAmount,         
          M.MonthName+', '+cast(r.BatchYear as varchar(4)) as MonthName,
       @StartDate as StartDate,@EndDate as EndDate
from TBL_ExpectedContributions_Rec r
         inner join Sponsor p on r.sponsorCode = p.SponsorCode
         inner join MonthTable m on r.BatchMonth = m.MonthNumber
where r.ReceiptDate >= @StartDate and r.ReceiptDate <= @EndDate 
ORDER BY SPONSORNAME,RECEIPTDATE
else
select @schemeName as SchemeName,p.SponsorName,r.ReceiptDate,r.ReceiptNo,r.cHEQUEnO,R.ReceiptAmount,         
          M.MonthName+', '+cast(r.BatchYear as varchar(4)) as MonthName,
       @StartDate as StartDate,@EndDate as EndDate
from TBL_ExpectedContributions_Rec r
         inner join Sponsor p on r.sponsorCode = p.SponsorCode
         inner join MonthTable m on r.BatchMonth = m.MonthNumber
where r.ReceiptDate >= @StartDate and r.ReceiptDate <= @EndDate and r.SponsorCode = @sponsorCode   
ORDER BY RECEIPTDATE
go

