CREATE PROCEDURE [dbo].[repMovement_Detail]                                      
@SCHEMENO Int,                                      
@StartDate datetime,                                      
@EndDate datetime                                      
--with Encryption                                      
as                                      
            
IF EXISTS (SELECT name FROM sysindexes                   
      WHERE name = 'MoveNo')                  
   DROP INDEX #Movement.MoveNo              
                                     
if object_id('tempdb..#Movement') is null                                      
                                      
begin                                      
create table #Movement                                      
(                                      
        [memberCounter][int] identity(1,1) PRIMARY KEY,                                      
        [SchemeNo] [varchar] (15) NOT NULL ,                                      
        [MemberNo] [int] NOT NULL ,                                      
        [fullname] [varchar](100)  NOT NULL ,                                      
        [DOB][Datetime],                                      
        [dje][Datetime],                                      
        [Djpens] [datetime] NULl,                                      
        [DoExit] [datetime]  NULL,                                      
        [Reason] [varchar] (50) NULL ,                                      
        [AllReason][varchar](30) null,                                      
        [StartDate][datetime] not null,                                      
        [EndDate][datetime] not null,                                      
        [Tax] float,                                      
        [Net] float,                                      
        [Employee] float,                                      
        [Employer] float,                                      
        [Deferred] float,                                      
        [DatePaid][Datetime],                                      
        [Sex][Varchar](1),                                      
        [SponsorName][Varchar](100),                                      
        [SchemeName][varchar](100)                                                 
)                                                                 
end                                      
            
CREATE INDEX MoveNo                  
   ON #Movement (SchemeNo, MemberNo, memberCounter)             
                                      
declare @memberNo int                                      
declare @fullname varchar(100)                                      
declare @djpens datetime                                      
declare @doexit datetime                                      
declare @reason varchar(50)                                      
declare @Benefits float, @xBenefit float,@FundType Int,@LumpFactor int,@Tax float,@xReason int,                                      
@dob Datetime,@dje Datetime,@UnRegBenefit float,@Gross float,@Sex Varchar(1),@DatePaid Datetime,                                      
@Employee float,@Employer float,@Deferred float,@EmployeeUn float,@EmployerUn float,                                      
@Vesting float,@unRegTax float,@EmpFeesReg FLOAT,@EmprFeesReg FLOAT,                                      
@EmpFeesUnReg FLOAT,@EmprFeesUnReg FLOAT,@AdminFees Int,@DeferredBenefit Int,                                      
@Test Decimal(20,6),@SponsorName varchar(100),@SchemeMode smallInt,@SCHEMENAME VARCHAR(120), @ReconDiff decimal (12,2),                                    
@UnReconDiff decimal (12,2),@Penalty Decimal(20,6),@RegDeferred Decimal(20,6),@UnRegDeferred Decimal(20,6),                        
@Britak Int,@UnBritak float,@AmountPaidUn Decimal(20,6),@TaxPaidUn Decimal(20,6),@PenaltyUn Decimal(20,6),        
@EmpTax Decimal(20,6),@EmprTax Decimal(20,6),@TransType Int                       
                        
select @UnBritak = 0,@AmountPaidUn = 0,@TaxPaidUn = 0,@PenaltyUn = 0.0,@Penalty = 0.0                                  
            
                                      
select @FundType = FundTypeCode,@SchemeMode = SchemeMode,@SCHEMENAME = SCHEMENAME,                        
@Britak = Britak from Scheme where schemeCode = @schemeNo                        
if @Britak is null select @Britak = 0                                      
                                      
IF @SchemeMode is null select @SchemeMode = 0                                      
            
select @unRegTax = 0                                      
                        
/* Normal Exits - without Deferred cases */                
if @SchemeMode = 0                                      
   declare MoveCsr cursor for                                      
   select                                      
   M.SchemeNo, M.MemberNo, M.DJPenS, M.DOExit,                                      
   (upper(M.SName) + ', ' + M.FName + ' '+ M.ONames) as FullName,M.ReasonforExit,                                      
   R.ReasonDesc, b.WithholdingTax,M.DOb,M.Dje,                                      
   b.DatePaid,M.Sex,                   
   b.EmpCBal + b.VolCBal + b.PreEmpCBal+ B.PreAvcCBal + b.EmpTransferCBal,            
   b.EmprCBal + b.SpecialCBal + b.PreEmprCBal + b.EmprTransferCBal + b.DeferredCBal,                                      
   b.Vesting,b.EmpFees,0,B.EmpFees,b.EmprFees,'',b.ReconDiff,b.Penalty,b.TransType                                   
   from Members m                                    
        inner join ReasonForExit r on (M.ReasonForExit = R.ReasonCode)                                      
        inner join benefits  B on m.schemenO = B.schemeNo and m.memberNo = b.memberNo                                      
   where                                      
   M.SchemeNo = @SchemeNo and                                      
   (M.ReasonForExit > 0) and  ((M.DOCalc >= @StartDate) and (M.DOCalc <= @EndDate))                         
   And M.ActiveStatus <> 6                                      
                              
else if @SchemeMode = 1                                      
   declare MoveCsr cursor for                                      
   select                                      
   M.SchemeNo, M.MemberNo, M.DJPenS, M.DOExit,                                      
   (upper(M.SName) + ', ' + M.FName + ' '+ M.ONames) as FullName,M.ReasonforExit,                                      
   R.ReasonDesc, b.WithholdingTax,M.DOb,M.Dje,                                      
   b.DatePaid,M.Sex,                                      
   b.EmpCBal + b.VolCBal + b.PreEmpCBal+ B.PreAvcCBal + b.EmpTransferCBal,            
   b.EmprCBal + b.SpecialCBal + b.PreEmprCBal + b.EmprTransferCBal + b.DeferredCBal,                                      
   b.Vesting,b.EmpFees,0,B.EmpFees,b.EmprFees,sp.SponsorName,b.ReconDiff,b.Penalty,b.TransType                                    
   from Members m                                    
        inner join ReasonForExit r on (M.ReasonForExit = R.ReasonCode)                                           
        inner join benefits  B on m.schemenO = B.schemeNo and m.memberNo = b.memberNo                                      
        inner join Sponsor sp on m.schemenO = sp.schemeNo and m.SponsorCode = sp.SponsorCode                                      
   where                                      
   M.SchemeNo = @SchemeNo and                                      
   (M.ReasonForExit > 0) and  ((M.DOCalc >= @StartDate) and (M.DOCalc <= @EndDate))                        
   And M.ActiveStatus <> 6                                      
                                        
   Open MoveCsr                                      
                                      
  fetch from MoveCsr into @schemeNo, @memberNo, @djpens, @doexit, @fullname, @xReason, @reason,@Tax,@dob,@dje,                                      
                          @DatePaid,@Sex,@Employee,@Employer,@Vesting,@AdminFees,@DeferredBenefit,                                      
                          @EmpFeesReg,@EmprFeesReg,@SponsorName,@ReconDiff,@Penalty,@TransType                                     
       
  while @@fetch_status = 0                                      
  begin                         
                        
                             
       if @EmpFeesReg is null select @EmpFeesReg = 0                                      
       if @EmprFeesReg is null select @EmprFeesReg = 0                        
       if @ReconDiff is null select @ReconDiff = 0                                    
       if @Penalty is null select @Penalty = 0                                   
       if @DeferredBenefit is null select @DeferredBenefit = 0                                      
       if @Tax is null select @Tax = 0                                      
       if @AdminFees is null select @AdminFees = 0 
       if @TransType is null select @TransType = 0                          
                        
       /* Knock Off admin Fees from Benefits */                               
       select @Employee = @Employee - @EmpFeesReg,@Employer = @Employer - @EmprFeesReg          
          
       if @vesting = 0          
          select @AdminFees = @AdminFees - @EmprFeesReg                         
                        
       /* Get the Employer Equivalent for members who are not fully vested */                        
       if @vesting < 100.00 and @vesting > 0.00                        
          select @Employer = @Employer * @vesting/100.00                        
       else if @vesting = 0.0          
          begin                        
          select @Employer = 0.0,@EmprFeesReg = 0.0          
          
          end                         
          
          
                         
       /* Check if Member has unregistered Benefits */                         
       if @Britak = 0                     
       begin                         
        select @EmployeeUn = EempcBal + EVolCBal,                                      
        @EmployerUn = eEmprcBal + ESpecialCBal + deferredCBal,                          
        @EmpTax = CEmpTax + cVolTax,@EmprTax = cEmprTax + cSpecTax,                                      
        @EmpFeesUnReg = EmpFees_Un,@EmprFeesUnReg = EmprFees_Un,                        
        @UnReconDiff = ReconDiff,@PenaltyUn = Penalty                                      
        from UnRegisteredBenefits                                      
        where SchemeNo = @schemeNo and MemberNo = @MemberNo                         
       end                        
       else if @Britak = 1                    
       begin                        
        select @EmployeeUn = EempcBal + EVolCBal,                                      
        @EmployerUn = eEmprcBal + ESpecialCBal + deferredCBal,                           
        @EmpTax = CEmpTax + cVolTax,@EmprTax = cEmprTax + cSpecTax,                                      
        @EmpFeesUnReg = EmpFees_Un,@EmprFeesUnReg = EmprFees_Un,                        
        @UnReconDiff = ReconDiff,@PenaltyUn = Penalty                                      
        from UnRegisteredBenefits                                      
        where SchemeNo = @schemeNo and MemberNo = @MemberNo                         
                  
                       
        select @UnBritak = sum(((b.EEmpCBal + b.EVolCBal)- b.EmpFees_Un) +                          
       (((b.EEmprCBal + b.ESpecialCBal)- b.EmprFees_Un) * (ba.Vesting/100.00)) - b.ReconDiff)                          
        - sum(b.cEmpTax + (b.cEmprTax * (ba.Vesting/100.000))) + sum(b.cEmpTax + b.cEmprTax)                          
                        from Members m                        
                        Inner Join UnRegisteredBenefits b on m.schemeNo = b.schemeNo and m.MemberNo = b.MemberNo                        
                       Inner Join Benefits ba on m.schemeNo = ba.schemeNo and m.MemberNo = ba.MemberNo                        
                        where m.schemeNo = @schemeNo AND M.mEMBERNO = @MemberNo                       
      end                         
                        
                                 
       if @UnBritak is null select @UnBritak = 0.0                 
       if @EmployeeUn is null select @EmployeeUn = 0                                     
    if @EmployerUn is null select @EmployerUn = 0         
       if @EmpTax is null select @EmpTax = 0         
       if @EmprTax is null select @EmprTax = 0                                    
       if @unRegTax is null select @unRegTax = 0                         
                                     
       if @EmpFeesUnReg is null select @EmpFeesUnReg = 0                                      
       if @EmprFeesUnReg is null select @EmprFeesUnReg = 0                                      
       if @UnReconDiff is null select @UnReconDiff = 0            
       if @PenaltyUn is null select @PenaltyUn = 0           
          
       print @tax    
       print @memberNo    
    
       if @vesting = 0.0           
          begin          
             select @EmprFeesUnReg = 0.0,@EmployerUn = 0.0,@EmprTax = 0.0          
          end        
        
       select @unRegTax = @EmpTax + @EmprTax             
            
       select @penalty = @Penalty + @PenaltyUn                      
                        
       if (@EmployeeUn + @EmployerUn) > 0 /* Has Unregistered Benefits */                        
       begin                        
          /* Knock Off admin Fees from Benefits */                               
          select @EmployeeUn = @EmployeeUn - @EmpFeesUnReg,@EmployerUn = @EmployerUn - @EmprFeesUnReg                           
          if @EmployerUn > 0                        
             begin                        
                if @vesting < 100.00 and @vesting > 0.00                        
                   select @EmployerUn = @EmployerUn * @vesting/100.00                        
                else if @vesting = 0.0                        
                   select @EmployerUn = 0.0,@EmprFeesUnReg = 0.0                        
             end          
          else           
             begin          
               select @EmployerUn = 0.0,@EmprFeesUnReg = 0.0           
             end                         
       end           
       else if ((@EmployeeUn = 0) and (@EmployerUn < 0.0))          
          begin          
              select @EmployerUn = 0.0,@EmprFeesUnReg = 0.0           
          end          
          
          
                               
       if @xReason > 1 and @xReason <= 5                                       
          begin                                      
             IF @FundType = 2                                      
                select @Benefits = ComLumgwTax,@Employee =ComLumgwTax,@Employer=0,                        
                @EmployeeUn =0,@EmployerUn=0,@UnRegBenefit=0,                  
                @Tax = WTaxPd from Pensioner                                      
                where SchemeNo = @schemeNo and MemberNo = @MemberNo                                       
             Else                           
                begin
                if (@TransType = 4)                   
                     select @Benefits = CommLumpsum,@Employee = CommLumpsum,@Employer=0,                        
                     @EmployeeUn =0,@EmployerUn=0,@UnRegBenefit=0                  
                     from Benefits                    
                     where schemeNo = @schemeNo and MemberNo = @MemberNo 
                else
                    select @Benefits = @Employee + @Employer,@UnRegBenefit = @EmployeeUn + @EmployerUn 
                end                       
         end                                                    
                              
        if ((@EmployerUn > 0) and ((@vesting > 0) and (@vesting < 100.00)))                        
           select @EmployerUn = @EmployerUn - (@UnBritak - (@EmployeeUn + @UnRegTax))                        
                        
                        
        select @Employer = @Employer + @EmployerUn, @ReconDiff = @ReconDiff + @UnReconDiff,                                    
        @Employee = @Employee + @EmployeeUn                        
        select @Employer = @Employer - @ReconDiff                         
        select @Benefits = @Employee + @Employer,@Deferred = 0.0                           
                          
  if @xReason = 8                        
           select @Tax = 0.0                        
                               
        insert into #Movement (schemeNo, memberNo, djpens, doexit,fullname, Reason, startdate, enddate, allReason,Tax,Net,                                      
        dob,dje ,DatePaid,Sex,Employee,Employer,Deferred,SponsorName,SCHEMENAME)                                      
                       values (@schemeNo, @MemberNo, @djpens, @doexit, @fullname, @Reason, @startDate, @EndDate,                                       
                       @Reason,                                      
        @Tax + @UnRegTax,@Benefits - (@Tax + @Penalty),@dob,@dje,@DatePaid,@Sex,                                      
                       @Employee,@Employer,@Deferred,@SponsorName,@SCHEMENAME)       
                                      
       SELECT @memberNo=0, @fullname='',@Tax=0,                                      
         @Sex='',@Employee=0,@Employer=0,@Vesting=0,@AdminFees=0,@DeferredBenefit=0,                                      
         @EmpFeesReg=0,@EmprFeesReg=0,@SponsorName='',@ReconDiff=0,@Penalty=0,                        
         @EmployeeUn=0,@EmployerUn=0,@unRegTax=0,@EmpFeesUnReg=0,@EmprFeesUnReg=0,                        
         @UnReconDiff=0,@Benefits = 0,@UnRegBenefit = 0,@RegDeferred = 0,@UnRegDeferred = 0,@Deferred = 0,                        
         @UnBritak = 0.0,@PenaltyUn = 0,@emptax = 0,@emprtax = 0,@TransType=0                                  
                                      
  fetch next from MoveCsr into @schemeNo, @memberNo, @djpens, @doexit, @fullname, @xReason, @reason,@Tax,@dob,@dje,                                      
                         @DatePaid,@Sex,@Employee,@Employer,@Vesting,@AdminFees,@DeferredBenefit,@EmpFeesReg,@EmprFeesReg,                                      
                               @SponsorName,@ReconDiff,@Penalty,@TransType                                      
 end                                      
                                      
 close MoveCsr                                      
 Deallocate MoveCsr                                      
                                      
                        
/* Deferred cases - ( Employer portion still unpaid ) */                
if @SchemeMode = 0                                      
  declare MoveCsr cursor for                                      
   select                                      
   M.SchemeNo, M.MemberNo, M.DJPenS, M.InitialDOExit,                                      
   (upper(M.SName) + ', ' + M.FName + ' '+ M.ONames) as FullName,M.InitialReason,                                      
   R.ReasonDesc, p.TaxPaid,M.DOb,M.Dje,                                      
   p.DatePaid,M.Sex,                                      
   p.AmountPaid,0.0,                                      
   100.00,b.AdminFees,0,0.0,0.0,'',0.0,0.0,                        
   p.RegDeferred,p.UnRegDeferred,p.AmountPaidUn,p.TaxPaidUn                                    
   from Members m                                    
        inner join ReasonForExit r on (M.InitialReason = R.ReasonCode)                                      
        inner join benefits  B on m.schemenO = B.schemeNo and m.memberNo = b.memberNo                         
        inner join PartialPayment p on m.schemenO = p.schemeNo and m.memberNo = p.memberNo                         
        and  ((p.DatePaid >= @StartDate) and (p.DatePaid <= @EndDate))                                   
   where M.SchemeNo = @SchemeNo and M.ReasonForExit > 0 And M.ActiveStatus = 6                            
else if @SchemeMode = 1                                      
   declare MoveCsr cursor for                                      
   select                                      
   M.SchemeNo, M.MemberNo, M.DJPenS, M.DOExit,                                      
   (upper(M.SName) + ', ' + M.FName + ' '+ M.ONames) as FullName,M.InitialReason,                                      
   R.ReasonDesc, p.TaxPaid,M.DOb,M.Dje,                                      
   p.DatePaid,M.Sex,                                      
   p.AmountPaid,0.0,                                      
   100.00,b.AdminFees,0,0.0,0.0,sp.SponsorName,0.0,0.0,                        
   p.RegDeferred,p.UnRegDeferred,p.AmountPaidUn,p.TaxPaidUn                                     
   from Members m                              
        inner join ReasonForExit r on (M.InitialReason = R.ReasonCode)                                           
        inner join benefits  B on m.schemenO = B.schemeNo and m.memberNo = b.memberNo                                      
        inner join Sponsor sp on m.schemenO = sp.schemeNo and m.SponsorCode = sp.SponsorCode                                      
   inner join PartialPayment p on m.schemenO = p.schemeNo and m.memberNo = p.memberNo                                           
   where M.SchemeNo = @SchemeNo and M.ReasonForExit > 0 And M.ActiveStatus = 6             
   and  ((m.InitialDoCalc >= @StartDate) and (m.InitialDoCalc <= @EndDate))               
                                                           
   Open MoveCsr                                      
                                      
  fetch from MoveCsr into @schemeNo, @memberNo, @djpens, @doexit, @fullname, @xReason, @reason,@Tax,@dob,@dje,                                      
                          @DatePaid,@Sex,@Employee,@Employer,@Vesting,@AdminFees,@DeferredBenefit,                                      
                          @EmpFeesReg,@EmprFeesReg,@SponsorName,@ReconDiff,@Penalty,@RegDeferred,@UnRegDeferred,            
                          @AmountPaidUn,@TaxPaidUn                                    
                                      
  while @@fetch_status = 0                                      
  begin                                      
       if @EmpFeesReg is null select @EmpFeesReg = 0                                      
       if @EmprFeesReg is null select @EmprFeesReg = 0                        
       if @ReconDiff is null select @ReconDiff = 0                                    
       if @Penalty is null select @Penalty = 0                                   
       if @DeferredBenefit is null select @DeferredBenefit = 0                                      
       if @Tax is null select @Tax = 0                                      
       if @AdminFees is null select @AdminFees = 0                        
       if @RegDeferred is null select @RegDeferred = 0                                      
       if @UnRegDeferred is null select @UnRegDeferred = 0                     
             
       if @AmountPaidUn is null select @AmountPaidUn = 0                                      
       if @TaxPaidUn is null select @TaxPaidUn = 0             
                      
       /* Knock Off admin Fees from Benefits */                               
       select @Employee = @Employee + @AmountPaidUn,@Employer = 0.0,@Tax = @Tax + @TaxPaidUn                       
                        
       if @EmployeeUn is null select @EmployeeUn = 0                                     
       if @EmployerUn is null select @EmployerUn = 0                                    
       if @unRegTax is null select @unRegTax = 0                         
                          
       if @EmpFeesUnReg is null select @EmpFeesUnReg = 0                                      
       if @EmprFeesUnReg is null select @EmprFeesUnReg = 0                                      
       if @UnReconDiff is null select @UnReconDiff = 0                                      
                        
                               
       select @Benefits = @Employee + @Employer,                        
       @Deferred = @RegDeferred + @UnRegDeferred                        
                                                  
                              
                                             
        select @ReconDiff = 0.0--@ReconDiff + @UnReconDiff,              
                        
      select @Employer = @Employer - @ReconDiff                         
        select @Benefits = @Employee + @Employer                        
                          
 insert into #Movement (schemeNo, memberNo, djpens, doexit,fullname, Reason, startdate, enddate, allReason,Tax,Net,                                      
        dob,dje ,DatePaid,Sex,Employee,Employer,Deferred,SponsorName,SCHEMENAME)                                      
                       values (@schemeNo, @MemberNo, @djpens, @doexit, @fullname, @Reason, @startDate, @EndDate,                                       
          @Reason,                                      
                       @Tax,@Benefits - (@Tax + @Penalty),@dob,@dje,@DatePaid,@Sex,                                      
                       @Employee,@Employer,@Deferred,@SponsorName,@SCHEMENAME)                                      
                                      
       SELECT  @memberNo=0, @fullname='', @xReason=0, @reason='',@Tax=0,                                      
         @Sex='',@Employee=0,@Employer=0,@Vesting=0,@AdminFees=0,@DeferredBenefit=0,                                      
         @EmpFeesReg=0,@EmprFeesReg=0,@SponsorName='',@ReconDiff=0,@Penalty=0,                        
         @EmployeeUn=0,@EmployerUn=0,@unRegTax=0,@EmpFeesUnReg=0,@EmprFeesUnReg=0,                        
         @UnReconDiff=0,@Benefits = 0,@UnRegBenefit = 0,@RegDeferred = 0,@UnRegDeferred = 0,@Deferred = 0,            
         @AmountPaidUn=0,@TaxPaidUn=0                                  
                                      
  fetch next from MoveCsr into @schemeNo, @memberNo, @djpens, @doexit, @fullname, @xReason, @reason,@Tax,@dob,@dje,                                      
                               @DatePaid,@Sex,@Employee,@Employer,@Vesting,@AdminFees,@DeferredBenefit,@EmpFeesReg,@EmprFeesReg,                                      
                               @SponsorName,@ReconDiff,@Penalty,@RegDeferred,@UnRegDeferred,@AmountPaidUn,@TaxPaidUn                           
 end                                      
                                      
 close MoveCsr                                      
 Deallocate MoveCsr                         
                        
                         
/* Deferred Cases - Paid */                                     
if @SchemeMode = 0                                      
   declare MoveCsr cursor for                                      
   select                                      
   M.SchemeNo, M.MemberNo, M.DJPenS, M.DOExit,                                      
   (upper(M.SName) + ', ' + M.FName + ' '+ M.ONames) as FullName,M.ReasonforExit,                                      
   R.ReasonDesc, b.WithholdingTax,M.DOb,M.Dje,                                      
   b.DatePaid,M.Sex,                                      
   0.0,b.EmprCBal + b.SpecialCBal + b.PreEmprCBal + b.EmpTransferCBal + b.DeferredCBal,                                      
   100.00,b.EmprFees,0,0.0,b.EmprFees,'',0.0,0.0,b.TransType                                    
   from Members m                                    
inner join ReasonForExit r on (M.ReasonForExit = R.ReasonCode)                                      
        inner join benefits  B on m.schemenO = B.schemeNo and m.memberNo = b.memberNo                                      
   where                                      
   M.SchemeNo = @SchemeNo and                                      
   (M.ReasonForExit > 0) and  ((M.DOCalc >= @StartDate) and (M.DOCalc <= @EndDate))                        
   And M.ActiveStatus = 6 and m.DeferredPaid = 1                                     
                              
else if @SchemeMode = 1                                      
   declare MoveCsr cursor for                     
   select                                      
   M.SchemeNo, M.MemberNo, M.DJPenS, M.DOExit,                                      
   (upper(M.SName) + ', ' + M.FName + ' '+ M.ONames) as FullName,M.ReasonforExit,                                      
   R.ReasonDesc, b.WithholdingTax,M.DOb,M.Dje,                                      
   b.DatePaid,M.Sex,                                      
   0.0,b.EmprCBal + b.SpecialCBal + b.PreEmprCBal + b.EmpTransferCBal + b.DeferredCBal,                                      
   100.00,b.EmprFees,0,0.0,b.EmprFees,sp.SponsorName,0.0,0.0,b.TransType                                    
   from Members m                                    
        inner join ReasonForExit r on (M.ReasonForExit = R.ReasonCode)                                  
        inner join benefits  B on m.schemenO = B.schemeNo and m.memberNo = b.memberNo                                      
        inner join Sponsor sp on m.schemenO = sp.schemeNo and m.SponsorCode = sp.SponsorCode                                      
   where                                      
   M.SchemeNo = @SchemeNo and                                      
   (M.ReasonForExit > 0) and  ((M.DOCalc >= @StartDate) and (M.DOCalc <= @EndDate))                        
   And M.ActiveStatus = 6 and m.DeferredPaid = 1                                     
                                        
   Open MoveCsr                                      
                                      
  fetch from MoveCsr into @schemeNo, @memberNo, @djpens, @doexit, @fullname, @xReason, @reason,@Tax,@dob,@dje,                                      
                          @DatePaid,@Sex,@Employee,@Employer,@Vesting,@AdminFees,@DeferredBenefit,                                      
                          @EmpFeesReg,@EmprFeesReg,@SponsorName,@ReconDiff,@Penalty,@TransType                                     
                              
  while @@fetch_status = 0                                      
  begin                                      
       if @EmpFeesReg is null select @EmpFeesReg = 0                                      
       if @EmprFeesReg is null select @EmprFeesReg = 0                        
       if @ReconDiff is null select @ReconDiff = 0                                    
       if @Penalty is null select @Penalty = 0                                   
       if @DeferredBenefit is null select @DeferredBenefit = 0                                      
       if @Tax is null select @Tax = 0                                      
       if @AdminFees is null select @AdminFees = 0 
       if @TransType is null select @TransType = 0 
  
                                
                        
       /* Knock Off admin Fees from Benefits */                               
       select @Employee = 0.0,@Employer = @Employer - @EmprFeesReg  
                 
       /* Check if Member has unregistered Benefits */                          
        select @EmployeeUn =0.0,                                      
        @EmployerUn = eEmprcBal + ESpecialCBal,                        
        @unRegTax = cEmprTax + cSpecTax,                                      
        @EmpFeesUnReg = 0.0,@EmprFeesUnReg = EmprFees_Un,                        
        @UnReconDiff = 0.0                                       
        from UnRegisteredBenefits                                      
        where SchemeNo = @schemeNo and MemberNo = @MemberNo                         
                        
       if @EmployeeUn is null select @EmployeeUn = 0                                     
       if @EmployerUn is null select @EmployerUn = 0                                    
       if @unRegTax is null select @unRegTax = 0                         
                                     
       if @EmpFeesUnReg is null select @EmpFeesUnReg = 0                                      
       if @EmprFeesUnReg is null select @EmprFeesUnReg = 0                                      
       if @UnReconDiff is null select @UnReconDiff = 0                                      
                        
       if (@EmployeeUn + @EmployerUn) > 0 /* Has Unregistered Benefits */                        
       begin                        
          /* Knock Off admin Fees from Benefits */                               
          select @EmployeeUn = @EmployeeUn - @EmpFeesUnReg,@EmployerUn = @EmployerUn - @EmprFeesUnReg                        
                        
       end                         
                                        
       if @xReason > 1 and @xReason <= 5                                       
          begin                                      
             IF @FundType = 2                                     
                select @Benefits = ComLumgwTax,@Employee =ComLumgwTax,@Employer=0,                        
                @EmployeeUn =0,@EmployerUn=0,@UnRegBenefit=0,                         
                @Tax = WTaxPd from Pensioner                                      
                where SchemeNo = @schemeNo and MemberNo = @MemberNo      
             Else                           
                begin
                if (@TransType = 4)                   
                     select @Benefits = CommLumpsum,@Employee = CommLumpsum,@Employer=0,                        
                     @EmployeeUn =0,@EmployerUn=0,@UnRegBenefit=0                  
                     from Benefits                    
                     where schemeNo = @schemeNo and MemberNo = @MemberNo 
                else
                    select @Benefits = @Employee + @Employer,@UnRegBenefit = @EmployeeUn + @EmployerUn 
                end                         
         end                            
                              
                                             
        select @Employer = @Employer + @EmployerUn, @ReconDiff = @ReconDiff + @UnReconDiff,                                    
        @Employee = @Employee + @EmployeeUn                        
        select @Employer = @Employer - @ReconDiff                         
        select @Benefits = @Employee + @Employer,@Deferred = 0.0                           
                          
        if @xReason = 8                        
           select @Tax = 0.0                        
                               
        insert into #Movement (schemeNo, memberNo, djpens, doexit,fullname, Reason, startdate, enddate, allReason,Tax,Net,                                      
        dob,dje ,DatePaid,Sex,Employee,Employer,Deferred,SponsorName,SCHEMENAME)                                      
                       values (@schemeNo, @MemberNo, @djpens, @doexit, @fullname, @Reason, @startDate, @EndDate,                                       
                       @Reason,                                      
            @Tax,@Benefits - (@Tax + @Penalty),@dob,@dje,@DatePaid,@Sex,                                      
                       @Employee,@Employer,@Deferred,@SponsorName,@SCHEMENAME)                                      
                                      
       SELECT @memberNo=0, @fullname='', @xReason=0, @reason='',@Tax=0,                                      
         @Sex='',@Employee=0,@Employer=0,@Vesting=0,@AdminFees=0,@DeferredBenefit=0,                                      
         @EmpFeesReg=0,@EmprFeesReg=0,@SponsorName='',@ReconDiff=0,@Penalty=0,                        
         @EmployeeUn=0,@EmployerUn=0,@unRegTax=0,@EmpFeesUnReg=0,@EmprFeesUnReg=0,                        
         @UnReconDiff=0,@Benefits = 0,@UnRegBenefit = 0,@RegDeferred = 0,@UnRegDeferred = 0,@Deferred = 0,@TransType=0                               
                                      
  fetch next from MoveCsr into @schemeNo, @memberNo, @djpens, @doexit, @fullname, @xReason, @reason,@Tax,@dob,@dje,                                      
                               @DatePaid,@Sex,@Employee,@Employer,@Vesting,@AdminFees,@DeferredBenefit,@EmpFeesReg,@EmprFeesReg,                                      
                               @SponsorName,@ReconDiff,@Penalty,@TransType                                      
 end                                      
                                      
 close MoveCsr                                      
 Deallocate MoveCsr                                      
                                      
                                     
if @SchemeMode = 0                                      
  select * from  #Movement                 
  where (Employee + Employer + Deferred) > 0.0                 
  order by MemberNo,DatePaid                                      
else if @SchemeMode = 1                                      
  select * from  #Movement where (Employee + Employer + Deferred) > 0.0 order by SponsorName,MemberNo,DatePaid
go

