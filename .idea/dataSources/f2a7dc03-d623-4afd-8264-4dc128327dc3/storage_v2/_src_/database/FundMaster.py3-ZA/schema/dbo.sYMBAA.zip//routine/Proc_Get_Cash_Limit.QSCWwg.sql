CREATE PROCEDURE [dbo].[Proc_Get_Cash_Limit]  
@schemeNo Int,  
@TransDate datetime,  
@AnnCont float out,  
@CashLimit float Out  
--with Encryption  
as  

set nocount off

declare @AcctPeriod Int,@StartDate datetime,@EndDate datetime,@NumMonths Int,@Contribution float,
@CashLimitPcnt float

select @CashLimitPcnt = CashLimitPcnt from scheme where schemeCode = @schemeNo

if @CashLimitPcnt is null select @CashLimitPcnt = 25
 
select @AcctPeriod = AcctPeriod,@StartDate  = StartDate,@EndDate = enddate from schemeYears  
where schemeNo = @schemeNo and startDate <= @TransDate and endDate >= @TransDate  
  
SELECT @NumMonths = COUNT(DISTINCT CONTRMONTH)   
FROM CONTRIBUTIONSSUMMARY WHERE SCHEMENO = @SCHEMENO AND ACCTPERIOD = @AcctPeriod  
  
select @Contribution = sum(EmpCont + EmprCont + VolContr + SpecialContr)   
FROM CONTRIBUTIONSSUMMARY WHERE SCHEMENO = @SCHEMENO AND ACCTPERIOD = @AcctPeriod  
  
if @NumMonths is null select @NumMonths = 0  
if @Contribution is null select @Contribution = 0  
  
if ((@NumMonths > 0) and (@Contribution > 0))  
   begin  
   select @AnnCont = (@Contribution/cast(@NumMonths as float))*12.000  
     
   select @CashLimit = (@CashLimitPcnt/100.000) * @AnnCont  
   end  
else  
   begin  
   select @CashLimit = 0,@AnnCont = 0  
   end 
   
set nocount off
go

