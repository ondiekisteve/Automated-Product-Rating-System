CREATE FUNCTION [dbo].[fn_PaymentModes]()
returns @tbl_var table(PayMode int not null primary key,
                       ModeDescription varchar(40) not null unique
                       )
as
 begin
  
  insert into @tbl_var values(0, 'Cash')
  insert into @tbl_var values(1, 'Cheque')
  insert into @tbl_var values(2, 'EFT')
  insert into @tbl_var values(3, 'Check-off')
  
  return
 end
go

