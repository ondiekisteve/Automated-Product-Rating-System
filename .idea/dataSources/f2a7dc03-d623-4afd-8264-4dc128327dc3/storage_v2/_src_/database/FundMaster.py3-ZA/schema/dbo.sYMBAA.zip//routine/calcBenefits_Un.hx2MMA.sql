CREATE PROCEDURE [dbo].[calcBenefits_Un]                                      

@SCHEMENO Int,                                      

@CurMonth int,                                      

@curyear int,                                      

@IntMode Int                                      

--with Encryption                                      

as                                      

declare @memberNo int                                      

declare @totEmp float                                      

declare @totEmpr float                                      

declare @totVol float                                      

declare @totSpecial float                                      

declare @CalculationMode int,@BalanceofInt smallInt,@StartDate Datetime,@EndDate Datetime,                                      

@ProcessDate Datetime,@InterestRate float,@EmpInterest FLOAT,@EmprInterest FLOAT,@VolInterest FLOAT,@SpecInterest FLOAT ,                                      

@ShowInterest float,@Calc_Status smallInt,@TotDeferred float,@DefInterest float,@InitDoCalc datetime,                          

@ActStatus smallInt                              

                                      

declare @hasBal bit                                      

select @Calc_Status = 0 /* Year End */                                      

                                      

select @ShowInterest = showInterest from Scheme where SchemeCode = @schemeNo                                      

                                      

if @ShowInterest is null select @ShowInterest = 0                                      

                                      

Exec GetLastDate @CurMonth,@CurYear,@ProcessDate Out                               

                              

EXEC Proc_Get_Int_Rate_Un @schemeNo,@ProcessDate,@IntMode,@InterestRate Out                                      

                                      

Select @BalanceofInt = CalcBalanceofInterest,@CalculationMode = CalculationMode                                      

from ConfigYearEnd where SchemeNo = @schemeNo                                      

                                      

if @BalanceofInt is null select @BalanceofInt = 0                                      

                                      

declare @funcResult int, @currYear int, @yearClosed bit, @retCode int, @AcctPeriod int, @PeriodtoUse int                                      

                                      

exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out                                      

                                      

select @StartDate = StartDate,@EndDate = EndDate from schemeYears where SchemeNo = @schemeNo                                      

and AcctPeriod = @AcctPeriod                                      

                                      

Select @PeriodToUse = @AcctPeriod - 1    

                                    

declare membersCsr cursor for                                      

select distinct m.MemberNo,M.InitialDoCalc,M.ActiveStatus from Members m                                      

inner Join UnregisteredContributionssummary u on m.schemeNo = u.schemeNo                                       

and m.memberNo = u.memberNo and u.AcctPeriod = @AcctPeriod                                      

where                                      

m.SchemeNo = @schemeNo and ((m.ReasonForExit = 0)                                 

or                                       

(m.ReasonforExit > 0 and m.DoCalc >= @ProcessDate))                        

order by m.MemberNo                                       

                                     

open membersCsr                                                                

fetch next from membersCsr                                      

into @memberNo,@InitDoCalc,@ActStatus                                      

while (@@fetch_status = 0)             

begin                                      

                                      

select @HasBal = 0                                     

                                 

if exists(select * from UnregisteredBalances                                 

          where SchemeNo = @schemeNo and memberNo = @memberNo                               

          and AcctPeriod = @PeriodToUse)                                       

          select @hasBal = 1                                       

else select @hasBal = 0                        

                                      

 if @CalculationMode = 1                                      

         exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                      

 else if @CalculationMode = 0                                      

          exec Proc_CalcMonthlyInterestSI_Un   @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output, @totSpecial output                                      

 else if @CalculationMode = 2                                      

         exec Proc_CalcMonthlyInterestAVG_Un @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 4                                      

         exec Proc_CalcMonthlyInterestAVGComp_Un_YE @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output,                                       

         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out,@TotDeferred out,@DefInterest out                                       

 else if @CalculationMode = 5                                      

         exec Proc_CalcMonthlyInterestAVGComp_SI_Un @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode, @totEmp output, @totEmpr output , @totVol output ,@totSpecial output,                                      

         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out                                        

 else if @CalculationMode = 6                                      

         exec Proc_CalcMonthlyInterestSI_MonUn @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode, @totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 7                                      

         exec Proc_CalcMonthlyInterestSI_NonProUn @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 9                                      

         exec Proc_CalcMonthlyInterest_Un_Daily @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@Calc_Status,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

else if @CalculationMode = 11                                      

         exec Proc_CalcMonthlyInterest_UnMonthDep @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,                                      

         @totEmp output, @totEmpr output, @totVol output, @totSpecial output                                       

                    

else                                      

        exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                         

                

                    

if @TotDeferred is null select @TotDeferred = 0            

if @TotEmp is null select @TotEmp = 0           

if @TotEmpr is null select @TotEmpr = 0           

if @totVol is null select @totVol = 0           

if @totSpecial is null select @totSpecial = 0               

                               

if ((@InitDoCalc < @ProcessDate) and (@ActStatus = 6))                           

  begin                                 

    if (@TotEmp  + @TotEmpr + @totVol  + @totSpecial + @TotDeferred) > 0                          

     begin     

             

 Insert Into UnRegisteredBalances                                  

         (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,                                  

         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,                                  

         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,DeferredAmt,DefInterest,DefTax,ProvOrFinal)                                  

         Values                                  

         (@schemeNo,@MemberNo,@CurYear,@CurMonth,@AcctPeriod,                                  

         0,@totEmpr,0,@totSpecial,0,0,0,0,                                  

         0,@EmprInterest,0,@SpecInterest,0,0,                                

         @TotDeferred,@DefInterest,0,0)              

                                       

        if not Exists(select MemberNo from UnRegisteredBenefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))                  

           insert into UnRegisteredBenefits                                      

           (SchemeNo, MemberNo, ExcessEmpCont, ExcessEmprCont, ExcessVolContr, ExcessSpecial, schemeYear,                           

            ProcessDate,CalcInterest,EmpInt,EmprInt,VolInt,SpecInt,IncludeRec,ActiveStatus,DeferredAmt,DefInterest)                                      

           values                                      

            (@schemeNo, @memberNo, 0, @totEmpr, 0, @totSpecial, datepart(year,getdate()),@ProcessDate,                                      

            @InterestRate,0,@EmprInterest,0,@SpecInterest,1,1,@TotDeferred,@DefInterest)                                      

        else                                      

           update UnRegisteredBenefits set ExcessEmpCont = 0,                               

                  ExcessEmprCont = @totEmpr, ExcessSpecial = @totSpecial,                                      

                  ExcessVolContr = 0,ProcessDate = @ProcessDate,CalcInterest = @InterestRate,                                      

                  EmpInt = 0,EmprInt = @EmprInterest,VolInt = 0,SpecInt = @SpecInterest,                                      

                  IncludeRec=1,ActiveStatus=1,DeferredAmt = @TotDeferred,DefInterest  = @DefInterest                                      

           where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)                                    

                                            

        Exec dbo.CalculateCorpTaxYearEnd @SchemeNo,@MemberNo,@CurMonth,@CurYear                                      

     end                                 

  end                                

else                                

  begin                 

                                  

   if (@TotEmp  + @TotEmpr + @totVol  + @totSpecial + @TotDeferred) > 0                                      

     begin                 

          

        Insert Into UnRegisteredBalances                                  

         (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,                                  

         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,                                  

         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,DeferredAmt,DefInterest,DefTax,ProvOrFinal)                                  

         Values                                  

         (@schemeNo,@MemberNo,@CurYear,@CurMonth,@AcctPeriod,                                  

         @totEmp,@totEmpr,@totVol,@totSpecial,0,0,0,0,    

         @EmpInterest,@EmprInterest,@VolInterest,@SpecInterest,0,0,                                

         @TotDeferred,@DefInterest,0,0)          

                                               

      if not Exists(select MemberNo from UnRegisteredBenefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))                                                    

      insert into UnRegisteredBenefits                                      

      (SchemeNo, MemberNo, ExcessEmpCont, ExcessEmprCont, ExcessVolContr, ExcessSpecial, schemeYear,              

            ProcessDate,CalcInterest,EmpInt,EmprInt,VolInt,SpecInt,IncludeRec,ActiveStatus,DeferredAmt,DefInterest)                                      

     values                                      

      (@schemeNo, @memberNo, @totEmp, @totEmpr, @totVol, @totSpecial, datepart(year,getdate()),@ProcessDate,                                      

            @InterestRate,@EmpInterest,@EmprInterest,@VolInterest,@SpecInterest,1,1,@TotDeferred,@DefInterest)                                      

        else                                      

           update UnRegisteredBenefits set ExcessEmpCont = @totEmp,                                      

                  ExcessEmprCont = @totEmpr, ExcessSpecial = @totSpecial,                                      

                  ExcessVolContr = @totVol,ProcessDate = @ProcessDate,CalcInterest = @InterestRate,                                      

                  EmpInt = @EmpInterest,EmprInt = @EmprInterest,VolInt = @VolInterest,SpecInt = @SpecInterest,                                      

                  IncludeRec=1,ActiveStatus=1,DeferredAmt = @TotDeferred,DefInterest  = @DefInterest                                      

           where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)                                      

                                            

        Exec dbo.CalculateCorpTaxYearEnd @SchemeNo,@MemberNo,@CurMonth,@CurYear                                      

     end                                 

   end                                     

                                      

     select @TotEmp = 0                                      

     select @totEmpr =0                                      

     select @totVol = 0                                      

     select @totSpecial = 0                                      

                                

     select @EmpInterest = 0,@EmprInterest=0,@VolInterest=0,@SpecInterest=0,@totEmp=0, @totEmpr=0, @totVol=0, @totSpecial=0,                                    

     @TotDeferred=0,@DefInterest=0,@memberNo=0,@ActStatus=0                                     

  fetch next from membersCsr                                      

  into @memberNo,@InitDoCalc,@ActStatus                                      

end                

                                      

close membersCsr                                      

deallocate membersCsr                                      

                                      

                                      

/* Members with Balances but without UnRegistered Contributions */                                      

declare membersCsr cursor for                                      

select distinct m.MemberNo,M.InitialDoCalc,M.ActiveStatus                                 

from Members m                                      

inner Join UnregisteredBalances u on                                 

m.schemeNo = u.schemeNo and m.memberNo = u.memberNo and u.AcctPeriod = @AcctPeriod - 1                                      

where                                      

(m.SchemeNo = @SchemeNo) and                                      

((m.ReasonForExit = 0)  or ((m.ReasonforExit > 0) and (m.DoCalc  >= @ProcessDate)))                         

and m.MemberNo Not In                                       

(Select MemberNo from  UnregisteredContributionssummary where schemeNo = @SchemeNo and AcctPeriod = @AcctPeriod)                                      

order by m.MemberNo                                          

                                       

open membersCsr                                      

                                      

                                      

fetch next from membersCsr                                      

into @memberNo,@InitDoCalc,@ActStatus                                

while (@@fetch_status = 0)                                      

begin                                      

                                      

select @HasBal = 0                                       

                                      

if exists(select * from UnregisteredBalances where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @PeriodToUse) select @hasBal = 1 else select @hasBal = 0                                      

                                      

 if @CalculationMode = 1                              

         exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                      

 else if @CalculationMode = 0                                      

          exec Proc_CalcMonthlyInterestSI_Un   @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output, @totSpecial output                                      

 else if @CalculationMode = 2                                      

         exec Proc_CalcMonthlyInterestAVG_Un @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 4                                      

         exec Proc_CalcMonthlyInterestAVGComp_Un_YE @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output,                                      

         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out,@TotDeferred out,@DefInterest out                                      

 else if @CalculationMode = 5                                   

         exec Proc_CalcMonthlyInterestAVGComp_SI_Un @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode, @totEmp output, @totEmpr output , @totVol output ,@totSpecial output,                   

         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out                                       

 else if @CalculationMode = 6                                      

         exec Proc_CalcMonthlyInterestSI_MonUn @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode, @totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 7                                      

         exec Proc_CalcMonthlyInterestSI_NonProUn @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 9                                      

         exec Proc_CalcMonthlyInterest_Un_Daily @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@Calc_Status,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

else if @CalculationMode = 11                   

         exec Proc_CalcMonthlyInterest_UnMonthDep @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,                                      

         @totEmp output, @totEmpr output, @totVol output, @totSpecial output                           

                                        

else                                      

         exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                         

          

if @TotDeferred is null select @TotDeferred = 0            

if @TotEmp is null select @TotEmp = 0           

if @TotEmpr is null select @TotEmpr = 0           

if @totVol is null select @totVol = 0           

if @totSpecial is null select @totSpecial = 0            

                                      

if ((@InitDoCalc < @ProcessDate) and (@ActStatus = 6))                                

  begin                                 

    if (@TotEmp  + @TotEmpr + @totVol  + @totSpecial + @TotDeferred) > 0                                      

     begin     

         Insert Into UnRegisteredBalances                                  

         (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,                                  

         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,                                  

         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,DeferredAmt,DefInterest,DefTax,ProvOrFinal)                                  

         Values                                  

         (@schemeNo,@MemberNo,@CurYear,@CurMonth,@AcctPeriod,                                  

         0,@totEmpr,0,@totSpecial,0,0,0,0,                                  

         0,@EmprInterest,0,@SpecInterest,0,0,                                

         @TotDeferred,@DefInterest,0,0)     

                                       

        if not Exists(select MemberNo from UnRegisteredBenefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))                                                    

           insert into UnRegisteredBenefits                                    

           (SchemeNo, MemberNo, ExcessEmpCont, ExcessEmprCont, ExcessVolContr, ExcessSpecial, schemeYear,                                      

            ProcessDate,CalcInterest,EmpInt,EmprInt,VolInt,SpecInt,IncludeRec,ActiveStatus,DeferredAmt,DefInterest)                                      

           values                              

            (@schemeNo, @memberNo, 0, @totEmpr, 0, @totSpecial, datepart(year,getdate()),@ProcessDate,                                      

            @InterestRate,0,@EmprInterest,0,@SpecInterest,1,1,@TotDeferred,@DefInterest)                                      

        else                                      

           update UnRegisteredBenefits set ExcessEmpCont = 0,                                      

                  ExcessEmprCont = @totEmpr, ExcessSpecial = @totSpecial,                                      

                  ExcessVolContr = 0,ProcessDate = @ProcessDate,CalcInterest = @InterestRate,                                      

                  EmpInt = 0,EmprInt = @EmprInterest,VolInt = 0,SpecInt = @SpecInterest,                                      

                  IncludeRec=1,ActiveStatus=1,DeferredAmt = @TotDeferred,DefInterest  = @DefInterest                                      

           where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)                                      

                                            

                                            

     end                                 

  end                                

else                                

  begin                                    

   if (@TotEmp  + @TotEmpr + @totVol  + @totSpecial + @TotDeferred) > 0                                      

     begin     

         Insert Into UnRegisteredBalances                                  

         (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,                                  

         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,                                  

         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,DeferredAmt,DefInterest,DefTax,ProvOrFinal)                                  

         Values                                  

         (@schemeNo,@MemberNo,@CurYear,@CurMonth,@AcctPeriod,                                  

         @totEmp,@totEmpr,@totVol,@totSpecial,0,0,0,0,                                  

         @EmpInterest,@EmprInterest,@VolInterest,@SpecInterest,0,0,                                

         @TotDeferred,@DefInterest,0,0)    

                                       

        if not Exists(select MemberNo from UnRegisteredBenefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))                    

      insert into UnRegisteredBenefits                                

      (SchemeNo, MemberNo, ExcessEmpCont, ExcessEmprCont, ExcessVolContr, ExcessSpecial, schemeYear,                                      

            ProcessDate,CalcInterest,EmpInt,EmprInt,VolInt,SpecInt,IncludeRec,ActiveStatus,DeferredAmt,DefInterest)                                      

     values                                      

      (@schemeNo, @memberNo, @totEmp, @totEmpr, @totVol, @totSpecial, datepart(year,getdate()),@ProcessDate,                  

            @InterestRate,@EmpInterest,@EmprInterest,@VolInterest,@SpecInterest,1,1,@TotDeferred,@DefInterest)                                      

        else                                      

           update UnRegisteredBenefits set ExcessEmpCont = @totEmp,                                      

                  ExcessEmprCont = @totEmpr, ExcessSpecial = @totSpecial,                  

                  ExcessVolContr = @totVol,ProcessDate = @ProcessDate,CalcInterest = @InterestRate,                                      

                  EmpInt = @EmpInterest,EmprInt = @EmprInterest,VolInt = @VolInterest,SpecInt = @SpecInterest,                                      

                  IncludeRec=1,ActiveStatus=1,DeferredAmt = @TotDeferred,DefInterest  = @DefInterest                                      

           where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)                 

                                            

                                             

     end                                 

   end                                     

                                      

     select @TotEmp = 0                                      

     select @totEmpr =0                                      

     select @totVol = 0                                      

     select @totSpecial = 0,@MemberNo = 0,@ActStatus = 0                                      

                  select @EmpInterest = 0,@EmprInterest=0,@VolInterest=0,@SpecInterest=0,@totEmp=0, @totEmpr=0, @totVol=0, @totSpecial=0,                                    

     @TotDeferred=0,@DefInterest = 0                                      

  fetch next from membersCsr                                      

  into @memberNo,@InitDoCalc,@ActStatus                                       

                                      

end                                      

                                      

close membersCsr                                      

deallocate membersCsr                                      

                                      

/* Members with Transfer Values but without UnRegistered Contributions and Balances */                     

declare membersCsr cursor for                                      

select distinct m.MemberNo,M.InitialDoCalc,M.ActiveStatus from Members m                                      

inner Join MemberTransferUn u on m.schemeNo = u.schemeNo and m.memberNo = u.memberNo and u.AcctPeriod = @AcctPeriod                                      

where                                      

(m.SchemeNo = @SchemeNo) and                                      

((m.ReasonForExit = 0)  or ((m.ReasonforExit > 0) and (m.DoCalc  >= @ProcessDate)))                                      

and m.MemberNo Not In                                       

(Select MemberNo from  UnregisteredContributionssummary where schemeNo = @SchemeNo and AcctPeriod = @AcctPeriod)                                      

and m.MemberNo Not In                                       

(Select MemberNo from  UnregisteredBalances where schemeNo = @SchemeNo and AcctPeriod = @AcctPeriod - 1)                                      

order by m.MemberNo                                         

                                      

open membersCsr                                      

                                      

                                      

fetch next from membersCsr                                      

into @memberNo,@InitDoCalc,@ActStatus                                       

while (@@fetch_status = 0)                                      

begin                                      

                                      

select @HasBal = 0                                       

            

if exists(select memberno from UnregisteredBalances where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @PeriodToUse) select @hasBal = 1 else select @hasBal = 0                                      

                                      

 if @CalculationMode = 1                                      

         exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                      

 else if @CalculationMode = 0          

          exec Proc_CalcMonthlyInterestSI_Un   @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output, @totSpecial output                                      

 else if @CalculationMode = 2                                      

         exec Proc_CalcMonthlyInterestAVG_Un @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 4                                      

         exec Proc_CalcMonthlyInterestAVGComp_Un_YE @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output,                                      

         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out,@TotDeferred out,@DefInterest out                                       

 else if @CalculationMode = 5                                      

         exec Proc_CalcMonthlyInterestAVGComp_SI_Un @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode, @totEmp output, @totEmpr output , @totVol output ,@totSpecial output,                                      

         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out                                       

 else if @CalculationMode = 6                                      

         exec Proc_CalcMonthlyInterestSI_MonUn @schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode, @totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 7                                      

         exec Proc_CalcMonthlyInterestSI_NonProUn @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

 else if @CalculationMode = 9                                      

         exec Proc_CalcMonthlyInterest_Un_Daily @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@Calc_Status,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output                                      

else if @CalculationMode = 11                                      

         exec Proc_CalcMonthlyInterest_UnMonthDep @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,                                      

         @totEmp output, @totEmpr output, @totVol output, @totSpecial output                                       

                    

else                         

         exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                         

                  

                  

if @TotDeferred is null select @TotDeferred = 0            

if @TotEmp is null select @TotEmp = 0           

if @TotEmpr is null select @TotEmpr = 0           

if @totVol is null select @totVol = 0           

if @totSpecial is null select @totSpecial = 0                   

                                      

if ((@InitDoCalc < @ProcessDate) and (@ActStatus = 6))                                

  begin                                 

    if (@TotEmp  + @TotEmpr + @totVol  + @totSpecial + @TotDeferred) > 0                                      

     begin    

         Insert Into UnRegisteredBalances                                  

         (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,                                  

         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,                                  

         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,DeferredAmt,DefInterest,DefTax,ProvOrFinal)                                  

         Values                                  

         (@schemeNo,@MemberNo,@CurYear,@CurMonth,@AcctPeriod,                                  

         0,@totEmpr,0,@totSpecial,0,0,0,0,                                  

         0,@EmprInterest,0,@SpecInterest,0,0,                                

         @TotDeferred,@DefInterest,0,0)     

                                        

        if not Exists(select MemberNo from UnRegisteredBenefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))        

           insert into UnRegisteredBenefits                                  

           (SchemeNo, MemberNo, ExcessEmpCont, ExcessEmprCont, ExcessVolContr, ExcessSpecial, schemeYear,                                      

            ProcessDate,CalcInterest,EmpInt,EmprInt,VolInt,SpecInt,IncludeRec,ActiveStatus,DeferredAmt,DefInterest)                                      

           values                                      

            (@schemeNo, @memberNo, 0, @totEmpr, 0, @totSpecial, datepart(year,getdate()),@ProcessDate,                                      

            @InterestRate,0,@EmprInterest,0,@SpecInterest,1,1,@TotDeferred,@DefInterest)                                      

        else                                      

           update UnRegisteredBenefits set ExcessEmpCont = 0,                                      

                  ExcessEmprCont = @totEmpr, ExcessSpecial = @totSpecial,                                      

                  ExcessVolContr = 0,ProcessDate = @ProcessDate,CalcInterest = @InterestRate,                                      

                  EmpInt = 0,EmprInt = @EmprInterest,VolInt = 0,SpecInt = @SpecInterest,                                      

                  IncludeRec=1,ActiveStatus=1,DeferredAmt = @TotDeferred,DefInterest  = @DefInterest                                      

           where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)                                      

                                            

                                             

     end                                 

  end                                

else                                

  begin                   

   if (@TotEmp  + @TotEmpr + @totVol  + @totSpecial + @TotDeferred) > 0                                      

     begin     

       Insert Into UnRegisteredBalances                                  

         (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,                                  

         ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,EmpTax,EmprTax,VolTax,SpecTax,                             

         EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,DeferredAmt,DefInterest,DefTax,ProvOrFinal)                                  

         Values                                  

         (@schemeNo,@MemberNo,@CurYear,@CurMonth,@AcctPeriod,                                  

         @totEmp,@totEmpr,@totVol,@totSpecial,0,0,0,0,                                  

         @EmpInterest,@EmprInterest,@VolInterest,@SpecInterest,0,0,                                

         @TotDeferred,@DefInterest,0,0)    

                                       

        if not Exists(select MemberNo from UnRegisteredBenefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))                                                    

      insert into UnRegisteredBenefits                                      

      (SchemeNo, MemberNo, ExcessEmpCont, ExcessEmprCont, ExcessVolContr, ExcessSpecial, schemeYear,                                      

            ProcessDate,CalcInterest,EmpInt,EmprInt,VolInt,SpecInt,IncludeRec,ActiveStatus,DeferredAmt,DefInterest)                                      

     values                       

      (@schemeNo, @memberNo, @totEmp, @totEmpr, @totVol, @totSpecial, datepart(year,getdate()),@ProcessDate,                                      

            @InterestRate,@EmpInterest,@EmprInterest,@VolInterest,@SpecInterest,1,1,@TotDeferred,@DefInterest)                                      

        else                                      

           update UnRegisteredBenefits set ExcessEmpCont = @totEmp,                                      

             ExcessEmprCont = @totEmpr, ExcessSpecial = @totSpecial,                                      

                  ExcessVolContr = @totVol,ProcessDate = @ProcessDate,CalcInterest = @InterestRate,                                      

                  EmpInt = @EmpInterest,EmprInt = @EmprInterest,VolInt = @VolInterest,SpecInt = @SpecInterest,                                      

                  IncludeRec=1,ActiveStatus=1,DeferredAmt = @TotDeferred,DefInterest  = @DefInterest                                      

           where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)                                      

                                            

                                             

     end                                 

   end                                        

                                      

     select @TotEmp = 0                                      

     select @totEmpr =0                                      

     select @totVol = 0                                      

     select @totSpecial = 0,@MemberNo = 0,@ActStatus = 0                                      

                                           

     select @EmpInterest = 0,@EmprInterest=0,@VolInterest=0,@SpecInterest=0,@totEmp=0, @totEmpr=0, @totVol=0, @totSpecial=0              

  fetch next from membersCsr                                      

  into @memberNo,@InitDoCalc,@ActStatus                                      

                                      

end                                      

                                      

close membersCsr                                      

deallocate membersCsr               

              

/* Calculate Corporate Tax */              

Exec Proc_Corp_Tax @schemeNo,@ProcessDate

go

