CREATE PROCEDURE [dbo].[consultGrid_Prev]
@SCHEMENO Int
--with Encryption
as
select ConsultantCode, SchemeNo, ConsultantName, ContactName, DOApmt, ConsultantType
from Scheme_Consultants
where SchemeNo = @SchemeNo and CurrentT = 0
go

