CREATE PROCEDURE [dbo].[Proc_Pension_History]
@SchemeNo Int,
@MemberNo Int
--with Encryption
as

if object_id('tempdb..#tt_Pension_History') is null

begin
create table #tt_Pension_History
(
        [PenCounter][Int] identity(1,1),
	[schemeNo] [int],
	[MemberNo] [Int],
        [PayMonth][Int],
        [PayYear][Int],
        [MonthName][varchar](30),
        [Gross][Decimal](12,2),
        [Tax][Decimal](12,2),
        [Arrears][Decimal](12,2),
        [Net][Decimal](12,2),
        [Paypoint][varchar](200),
	[Fullname][varchar](200)null,  
	[schemename][varchar](100) null
) 

ALTER TABLE #tt_Pension_History WITH NOCHECK ADD 

            
	CONSTRAINT [PK_#tt_Pension_History] PRIMARY KEY  NONCLUSTERED 
	(
	  [PenCounter]      
	) 
end

declare @Gross Decimal(20,6),@Arrears Decimal(20,6),@Tax Decimal(20,6),@PayMonth Int,@PayYear Int,
@MonthName varchar(30),@Paypoint varchar(200),@bank int,@branch int,@AcctNo varchar(20),
@BankName varchar(200),@BranchName varchar(100),@PayType int,@schemename varchar(100), @fullname varchar(200)

Declare PenCsr Cursor for
Select p.Gross,p.Tax,p.PayMonth,p.PayYear,p.Bank,p.Branch,p.AcctNo
from PensionPayroll p
where p.schemeNo = @schemeNo and p.MemberNo = @MemberNo and p.PayType = 1

open PenCsr
Fetch from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
while @@fetch_Status = 0
begin
  Exec GetMonthName @PayMonth,@MonthName Out

  select @BankName = BankName from Bank_setup where BankCode = @Bank
  select @BranchName = BranchName from Bank_Branch where BankCode = @Bank
  and BranchCode = @branch
if @Tax is null select @Tax =0.0
if @Gross is null select @Gross =0.0

  Insert Into #tt_Pension_History(schemeNo,MemberNo,PayMonth,PayYear,MonthName,Gross,Tax,Arrears,Net,Paypoint)
                  Values(@schemeNo,@MemberNo,@PayMonth,@PayYear,@MonthName+', '+cast(@PayYear as varchar(4)),
                         @Gross,@Tax,0.0,@Gross - @Tax,@BankName+' - '+@BranchName+' - '+@AcctNo)

  select @Gross=0,@Tax=0,@PayMonth=0,@PayYear=0,@Bank=0,@Branch=0,@AcctNo=' ',@BankName =' ',
         @BranchName=' '
  Fetch next from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
end
Close PenCsr
Deallocate PenCsr
select @fullname = fname + ' ' + onames +' '+ sname from members where schemeno = @schemeno and memberno = @memberno
select @schemename = schemename from scheme where schemecode = @schemeno
update #tt_Pension_History set Fullname = @fullname, Schemename = @schemename
/* Financial Institutions */
Declare PenCsr Cursor for
Select p.Gross,p.Tax,p.PayMonth,p.PayYear,p.FinCode,p.FinBrCode,p.FinAcctNo
from PensionPayroll p
where p.schemeNo = @schemeNo and p.MemberNo = @MemberNo and p.PayType = 2

open PenCsr
Fetch from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
while @@fetch_Status = 0
begin
  Exec GetMonthName @PayMonth,@MonthName Out

  select @BankName = FinName from FinInstitutions where FinCode = @Bank
  select @BranchName = FinBrName from FinInstitutionsBranch where FinCode = @Bank
  and FinBrCode = @branch
if @Tax is null select @Tax =0.0
if @Gross is null select @Gross =0.0

  Insert Into #tt_Pension_History(schemeNo,MemberNo,PayMonth,PayYear,MonthName,Gross,Tax,Arrears,Net,Paypoint)
                  Values(@schemeNo,@MemberNo,@PayMonth,@PayYear,@MonthName+', '+cast(@PayYear as varchar(4)),
                         @Gross,@Tax,0.0,@Gross - @Tax,@BankName+' - '+@BranchName+' - '+@AcctNo)

  select @Gross=0,@Tax=0,@PayMonth=0,@PayYear=0,@Bank=0,@Branch=0,@AcctNo=' ',@BankName =' ',
         @BranchName=' '
  Fetch next from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
end
Close PenCsr
Deallocate PenCsr

/* Direct Payments */
Declare PenCsr Cursor for
Select p.Gross,p.Tax,p.PayMonth,p.PayYear,p.FinCode,p.FinBrCode,p.FinAcctNo
from PensionPayroll p
where p.schemeNo = @schemeNo and p.MemberNo = @MemberNo and p.PayType = 3



open PenCsr
Fetch from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
while @@fetch_Status = 0
begin
  Exec GetMonthName @PayMonth,@MonthName Out

  select @BranchName = Address +'   '+TownAddress from Members where schemeNo = @schemeNo and MemberNo = @MemberNo

if @Tax is null select @Tax =0.0
if @Gross is null select @Gross =0.0

  Insert Into #tt_Pension_History(schemeNo,MemberNo,PayMonth,PayYear,MonthName,Gross,Tax,Arrears,Net,Paypoint)
                  Values(@schemeNo,@MemberNo,@PayMonth,@PayYear,@MonthName+', '+cast(@PayYear as varchar(4)),
                         @Gross,@Tax,0.0,@Gross - @Tax,@BranchName)

  select @Gross=0,@Tax=0,@PayMonth=0,@PayYear=0,@Bank=0,@Branch=0,@AcctNo=' ',@BankName =' ',
         @BranchName=' '
  Fetch next from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
end
Close PenCsr
Deallocate PenCsr

/* Paypoints */
Declare PenCsr Cursor for
Select p.Gross,p.Tax,p.PayMonth,p.PayYear,p.Paypoint,p.PayCode,p.FinAcctNo
from PensionPayroll p
where p.schemeNo = @schemeNo and p.MemberNo = @MemberNo and p.PayType = 4

open PenCsr
Fetch from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
while @@fetch_Status = 0
begin
  Exec GetMonthName @PayMonth,@MonthName Out

  select @BankName = PaypointName from Paypoints where PaypointCode = @Bank
  select @BranchName = BranchName from PaypointsBranch where PaypointCode = @Bank
  and BranchCode = @branch
if @Tax is null select @Tax =0.0
if @Gross is null select @Gross =0.0

  Insert Into #tt_Pension_History(schemeNo,MemberNo,PayMonth,PayYear,MonthName,Gross,Tax,Arrears,Net,Paypoint)
                  Values(@schemeNo,@MemberNo,@PayMonth,@PayYear,@MonthName+', '+cast(@PayYear as varchar(4)),
                         @Gross,@Tax,0.0,@Gross - @Tax,@BankName+' - '+@BranchName)

  select @Gross=0,@Tax=0,@PayMonth=0,@PayYear=0,@Bank=0,@Branch=0,@AcctNo=' ',@BankName =' ',
         @BranchName=' '
  Fetch next from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
end
Close PenCsr
Deallocate PenCsr

select * from #tt_Pension_History order by PayYear,PayMonth
go

