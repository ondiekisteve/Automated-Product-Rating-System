CREATE PROCEDURE [dbo].[InsertPensionArrears]              
@SCHEMENO Int,              
@PayMonth int,              
@PayYear int,          
@PenOrBen Int,              
@PenNo varchar(15),              
@FullName varchar(50),              
@Pension float,          
@Tax float,             
@Desc varchar(80),              
@PayType int,              
@ArrearsType Int,              
@TaxArrears float,              
@BankCode varchar(15),              
@BranchCode varchar(15),              
@AcctNo varchar(15),              
@FinCode varchar(15),              
@FinBrCode varchar(15),              
@FinAcctNo varchar(15)              
--with Encryption              
as              
--select * from MemBeneficiary             
declare @MonthName varchar(30),@PayCode int,@PaypointCode Int,@MemberNo int    
          
if @PenOrBen = 0           
   SELECT @MemberNo = MemberNo,@PayType = payType,@BankCode = BankCode,@BranchCode = Branch,@AcctNo = AcctNo,            
       @FinCode = FinCode, @FinBrCode  = FinBrCode,@FinAcctNo = FinAcctNo,            
       @PayCode = PayCode,@PaypointCode = PaypointCode            
   from pensioner where SchemeNo = @schemeNo and PenNo = @PenNo           
else if @PenOrBen = 1          
   begin          
     if exists(select penno from MemBeneficiary where SchemeNo = @schemeNo and PenNo = @PenNo)           
        SELECT @MemberNo = MemberNo,@PayType = payType,@BankCode = Bank,@BranchCode = Branch,@AcctNo = AcctNo,            
        @FinCode = FinCode, @FinBrCode  = FinBrCode,@FinAcctNo = FinAccountNo,            
        @PayCode = PayCode,@PaypointCode = PayCode            
        from MemBeneficiary where SchemeNo = @schemeNo and PenNo = @PenNo           
     else          
        SELECT @MemberNo = MemberNo,@PayType = payType,@BankCode = Bank,@BranchCode = Branch,@AcctNo = AcctNo,            
        @FinCode = FinCode, @FinBrCode  = FinBrCode,@FinAcctNo = FinAccountNo,            
        @PayCode = PayCode,@PaypointCode = PayCode            
        from PenBeneficiary where SchemeNo = @schemeNo and PenNo = @PenNo           
   end           
              
select @MonthName = MonthName from MonthTable               
where MonthNumber = @PayMonth              
              
Select @MonthName = @MonthName +' '+cast(@PayYear as varchar(4))              
              
if Exists (select * from PensionArrears where              
           SchemeNo = @schemeNo and PayMonth = @PayMonth and PayYear = @PayYear and PenNo = @PenNo)              
   begin              
        raiserror('Arrears for %s already defined for %',16,1,@fullName,@MonthName)              
        return              
   end              
else              
   BEGIN

   Insert into PensionArrears(SchemeNo,PayMonth,PayYear,PenNo,FullName,Pension,BankCode,              
                              BranchCode,AcctNo,PayType,FinCode,FinBrCode,FinAcctNo,              
                              Description,ArrearsType,TaxArrears)              
               Values(@SchemeNo,@PayMonth,@PayYear,@PenNo,@FullName,@Pension,@BankCode,              
                      @BranchCode,@AcctNo,@PayType,@FinCode,@FinBrCode,@FinAcctNo,              
                             @Desc,@ArrearsType,@TaxArrears)

   IF left(@desc,16) = 'Arrears on Revis'
      begin
         update Pen_Revise set Paid  = 1 where schemeNo = @schemeNo and MemberNo = @MemberNo 
      end
   END
go

