CREATE PROCEDURE [dbo].[GetInterest]  
@SCHEMENO Int,
@curMonth int,  
@CurYear int,  
@IntMode Int  
--with Encryption  
as  
 
declare @CalcDate datetime,@currInterest float
exec getlastdate @curMonth,@curYear,@CalcDate out
EXEC Proc_Get_Int_Rate @schemeNo,@CalcDate,@IntMode,@currInterest Out 
select @currInterest as Interestrate
go

