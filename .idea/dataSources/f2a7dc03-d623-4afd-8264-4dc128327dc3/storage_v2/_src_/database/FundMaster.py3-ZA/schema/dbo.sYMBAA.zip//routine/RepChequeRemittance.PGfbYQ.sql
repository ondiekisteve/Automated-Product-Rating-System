CREATE PROCEDURE [dbo].[RepChequeRemittance]  
@SCHEMENO Int,  
@VoucherNo int,  
@VoucherInc Int  
--with Encryption  
as  
  
  
if object_id('tempdb..##Remittance') is null  
  
begin  
create table ##Remittance  
(  
        [rmcode] [int] IDENTITY(1,1) Primary Key ,  
        [rmDesc] [varchar](100) NULL ,  
        [rmCredit] [float] not  NULL default 0.0,  
        [rmDebit][float] not null default 0.0,  
        [rmPayable][float] null,  
        [fullName][varchar](100) null,  
        [Address][varchar](40) null,  
        [Town][varchar](40) null,  
        [SchemeName][varchar](120),  
        [ChequeNo][varchar](30),  
        [Bank][varchar](100),  
        [Particulars][Varchar](150),  
        [HioDebit][float],
        [CurrCode][varchar](100),
        [RCurrCode][Integer]  
)    
end  
  
Delete  from ##Remittance  
  
Declare @Debit float, @Credit float, @Cash float, @glDesc varchar(60),  
@Address varchar(40),@town varchar(40),@fullName varchar(100),@MemberNo int,@Scheme varchar(120), @DepCode int,@vType int,@vSubType int,  
@Propcode int,@Paycode int,@PayMode int,@Name varchar(100),@Count int ,@ChequeNo varchar(30),@BankCode Int,@Bank varchar(100),  
@Particulars Varchar(150),@HioDebit float,@CurrCode varchar(100),@RCurrCode Integer
  
Select @Count = 0  
select @ChequeNo = ChequeNo,@BankCode = BankCode   
from CashBook where SchemeCode = @schemeNo and VoucherNo = @VoucherNo  
and VoucherInc = @VoucherInc  
  
select @Bank = BankName from schemeBankBranch where  
SchemeNo = @schemeNo and BankCode = @BankCode  
  
Select @Scheme = SchemeName from scheme where schemeCode = @SchemeNo 
 
Select @MemberNo =  p.MemberNo, @Depcode = p.DependantCode,@vType = p.VoucherType,@vSubType = p.VoucherSubType,  
@Propcode = p.PropCode,@Paycode = p.Paycode,@RCurrCode = p.CurrCode,@CurrCode = f.CurrencyDesc  
from PaymentVoucher p 
     inner Join CurrencyType f on p.CurrCode = f.CurrCode
where p.SchemeNo = @SchemeNo and p.VoucherNo = @VoucherNo  
  
select @FullName = Payee,@Particulars = Description FROM PaymentVoucher where SchemeNo = @SchemeNo and VoucherNo = @VoucherNo  
and VoucherInc = @VoucherInc  
     
Select @Debit = Sum(Debit) from SchemeGeneralLedger where SchemeCode = @SchemeNo and VoucherNo = @VoucherNo  
and VoucherInc = @VoucherInc 
 
Select @Cash = Credit from CashBook where SchemeCode = @SchemeNo and VoucherNo = @VoucherNo  
and VoucherInc = @VoucherInc  
  
if @Debit is null select @Debit = 0  
  
insert into ##Remittance (rmDesc,rmCredit,rmDebit)  
              Values(@Particulars,0, @Debit)  
  
Select @Credit = 0  
  
Declare Acsr Cursor for  
Select s.Credit,ltrim(g.glAccount)  
from SchemeGeneralLedger s  
     inner Join glAccountCodes g on s.AccountCode = g.AccountCode   
where s.SchemeCode = @SchemeNo and s.VoucherNo = @VoucherNo  
and s.Credit > 0  
Open Acsr  
  
Fetch from Acsr into @Credit, @glDesc  
  
while @@fetch_Status = 0  
begin  
   if (@Credit <> @Cash)      
   insert into ##Remittance (rmDesc,rmCredit,rmDebit)  
              Values(@glDesc, @Credit, 0)  
  
   Fetch Next from Acsr into @Credit,@glDesc  
end  
Close ACSR  
deallocate Acsr  
  
if (Select Count(*) from ##Remittance) = 1  
    insert into ##Remittance (rmDesc,rmCredit,rmDebit)  
              Values('P.A.Y.E  ', 0, 0)  
  
Declare @Payable float  
  
Select @Payable = sum(rmDebit) - sum(rmCredit) from ##Remittance  
  
  
  
Update ##Remittance set rmPayable = @Payable, fullName = @fullname, Address = @Address, town = @town,  
                        ChequeNo= @ChequeNo,Particulars = @Particulars,  
                        SchemeName = @Scheme,Bank = @Bank,RCurrCode = @RCurrCode,CurrCode= @CurrCode  
  
Select @HioDebit = rmDebit from ##Remittance  
where rmCredit = 0  
  
update ##Remittance set HioDebit = @HioDebit  
  
Select * from ##Remittance  where rmDebit =  0
go

