/*   
PROCEDURE DBO.to Insert Members Liabilities upon Retirement or Leaving scheme  
*/  
CREATE PROCEDURE [dbo].[InsertMemberDeduction]  
@SCHEMENO Int,  
@MemberNo int, 
@DepCode Int, 
@DeductCode int,   
@deductMode int,  
@Deduction float,  
@Instal float,  
@Stopdate datetime  
--with Encryption  
as  
declare @Deduct varchar(50) 

if @DepCode is null select @DepCode = 0 
  
select @Deduct  = Deduction from Deductions where DeductCode = @DeductCode  
  
if Exists (select @DeductCode from MemberDeductions 
           where SchemeNo = @SchemeNo and MemberNo = @MemberNo and DependantCode = @DepCode
           and DeductCode = @DeductCode and StopDate = @StopDate )  
  begin  
     raiserror('%s has already been defined', 16,1,@Deduct)  
     return  
  end  
else  
  begin  
       insert into MemberDeductions (schemeNo, MemberNo, DependantCode,DeductCode,DeductMode, Deduction, Instalments, Stopdate)  
                   Values(@SchemeNo, @MemberNo,@DepCode, @DeductCode, @DeductMode, @Deduction, @Instal, @Stopdate)  
  
      update Pensioner set HasLiability = 1 
      where SchemeNo = @schemeNo and MemberNo = @MemberNo
      
      update MemBeneficiary Set HasLiability = 1 
      where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode

      update PenBeneficiary Set HasLiability = 1 
      where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode

  
  end
go

