CREATE PROCEDURE [dbo].[RepDeathCalculationSheetPCNTGrat]
@SCHEMENO Int,
@memberNo int
--with Encryption
as

set nocount on

if object_id('tempdb..#CalculationPCNT') is null

begin
create table #CalculationPCNT
(          [SchemeNo] [varchar] (15) NOT NULL ,
           [MemberNo] [varchar](15)  NOT NULL ,
           [schemeName][varchar](100) not null,
           [fullname][varchar](100) not null,
           [Sex][varchar](10) not null,
           [Dob][datetime] not null,
           [DJE][Datetime] null,
           [djpens][datetime] not null,
           [AgeDesc][varchar](50) not null,
           [DateOfExit][datetime] not null,
           [curYear] [int] NOT NULL,
           [Salary][float] not null,
           [ServiceTime][varchar](100) not null,
           [ActService][varchar](100) not null,
           [ProService][varchar](100) not null,  
           [GratFact][float],
           [RedFact][float],
           [UnRedFact][float],
           [GratAdd][float],
           [RedAdd][float],
           [UnRedAdd][float],
           [GratFactJuu][float],
           [RedFactJuu][float],
           [GratAddJuu][float],
           [RedAddJuu][float],
           [UnRedFactJuu][float],
           [UnRedAddJuu][float],
           [GratReal][float],
           [GratAddition][float], 
           [Gratuity][float],
           [Reduced][float],
           [UnReduced][float],
           [ReducedReal][float],
           [ReducedAddition][float],
           [UnReducedReal][float],
           [UnReducedAddition][float],  
           [TaxfreeLumpsum][float] not null,
           [WithHoldingTax][float] not null,
           [Reason][varchar](25) not null,
           [AmountPayable][float],
           [TaxableAmount][float]  null,
           [MonPension][float] null,
           [Grade][Varchar](40) null,
           [preparedby][varchar](60) null,
           [DatePrepared][smalldatetime] null,
           [CheckedBy][varchar](60) null,
           [DateChecked][smalldatetime] null,
           [AuthorisedBy][varchar](60) null,
           [DateAuthorised][smalldatetime] null,
           [TotalReduced][float] null,
           [GratuityFactor][float] null,
           [BreakInService][Varchar](50),
           [CutOffPeriod][Varchar](100),
           [PreSalary][float],
           [GratuityJuu][float],
           [ReducedJuu][float],
           [CutOffDate][Datetime],
           [AuditedBy][Varchar](100),
           [DateAudited][Datetime],
           [PreBreakInService][Varchar](100),
           [PostBreakInService][Varchar](100),
           [DeathSalary][float],
           [DoCalc][Datetime],
           [IkoPension][Int]            
) 

ALTER TABLE #CalculationPCNT WITH NOCHECK ADD 

            
	CONSTRAINT [PK_CalculationPCNT] PRIMARY KEY  NONCLUSTERED 
	(
		[SchemeNo],
		[memberNo]      
	) 
end


declare @fullname varchar(100)
declare @schemeName varchar(100)
declare @DateOfExit datetime
declare @taxfreelumpsum float
declare @withHoldingTax float
declare @dje datetime
declare @djpens datetime
declare @curYear int
declare @Salary float
declare @ContrMonth int
declare @ServiceTime varchar(100)
declare @dob datetime
declare @sex varchar(10)
declare @Reason varchar(25)
declare @AgeDesc varchar(50)
declare @Years int,@Months int
declare @ReducedPension float
declare @AmountPayable float
declare @grade varchar(40),@CheckNo varchar(15), @Age int,
@GratFact float,@RedFact float,@GratAdd float,@RedAdd float,@dTemp Datetime,
@Gratuity float, @Reduced float,@UnReduced float,@UnRedFact float,@UnRedAdd float,
@GratReal float,@GratAddition float,@ReducedReal float,@ReducedAddition float, @ProService Int,
@UnReducedReal float,@UnReducedAddition float,@PayGratuity int,@MonPension float,
@ActService varchar(100),@ProServ varchar(100) ,@TaxType Int,@GratuityFactor float,@Prospect bit,@DesignCode Int,@Title varchar(20),@Days Int,
@TotalMonths Int,@TotalDays Int,@Miaka Int,@Miezi Int,@BreakInService Varchar(50),
@YearsJuu Int,@MonthsJuu Int,@DaysJuu Int,@CutOff Bit,@CutOffDate Datetime,
@PreSalary float,@MiakaJuu Int,@MieziJuu Int,@NewStart Datetime,@Cheki Bit,@CutOffPeriod Varchar(100),
@GratuityJuu float,
@ReducedJuu float,
@UnReducedJuu float,
@GratFactJuu float,@RedFactJuu float,@UnRedFactJuu float,
@GratAddJuu float,@RedAddJuu float,@UnRedAddJuu float,@DoCalc Datetime,@AuditedBy Varchar(100),@DateAudited Datetime,
@PreBreakInService Varchar(100),
@PostBreakInService Varchar(100),
@TotalMonthsPost Int,@TotalDaysPost Int,@DeathSalary float,
@MiakaYote Int,@MieziYote Int,@SikuZote Int,@IkoPension smallInt,
@PensionPeriod smallInt

select @Cheki = 0

select @CutOff = BenefitsCutOff,@CutOffDate = CutOffDate from 
ConfigSalary
where schemeNo = @schemeNo

if @CutOff is null select @CutOff = 0



declare @PreparedBy varchar(60), @DatePrepared smalldatetime, @CheckedBy  varchar(60), @dateChecked varchar(60), @AuthorisedBy varchar(60), @DateAuthorised smalldatetime,
@MembSex char(1)
select @Membsex = sex , @dTemp = dje, @Grade = grade,@DesignCode = DesignCode,
@DoCalc = DoCalc from Members where schemeNo = @schemeNo and MemberNo = @MemberNo

if @DesignCode is null select @DesignCode = 0

select @PreparedBy = PreparedBy, @DatePrepared = DatePrepared, @CheckedBy = CheckedBy, @DateChecked = DateChecked, 
           @AuthorisedBy = AuthorisedBy, @DateAuthorised = DateAuthorised,@AuditedBy = AuditedBy,@DateAudited = DateAudited
 from LumpAuthorization
       where schemeNo = @schemeNo and MemberNo = @MemberNo

select @Prospect = AddProspective,@PensionPeriod = PensionPeriod from ConfigDeathInservice where schemeNo = @schemeNo

select @curYear = max(ContrYear) from contributionssummary where schemeNo  = @schemeNo and memberNo = @memberNo
select @ContrMonth  = Max(ContrMonth)  from contributionssummary where schemeNo  = @schemeNo and memberNo = @memberNo and ContrYear = @CurYear

select @schemeName = schemeName from scheme where schemeCode = @schemeNo

declare GenCursor cursor for
              select m.schemeNo, m.memberNo,m.dje,m.djpens,m.doexit,  m.dob, case m.Sex when 'M' then 'Male' when 'F' then 'Female' end, 
             		(Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,
            		 b.calcYear, b.taxfreeLumpsum, r.ReasonDesc
             from Members m
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo
                       inner join ReasonforExit r on m.reasonforexit = r.ReasonCode
            where m.schemeNo = @schemeNo and m.memberNo = @memberNo

             
open GenCursor

fetch from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @dob, @sex,  @fullname,  @curYear,
                          @taxfreeLumpsum, @Reason


while @@fetch_status =0
begin
     
       --Exec GetTaxFreeLumpsumD @SchemeNo,@dateofExit,@TaxFreeLumpsum out

       Exec GetServiceTime @djpens,@DateOfExit,@MiakaYote out,@MieziYote Out,@SikuZote Out

       if @PensionPeriod > @MiakaYote
          select @IkoPension = 0
       else
          select @IkoPension = 1

       select @salary = CAPenSal from Members where schemeNo = @schemeNo and memberNo = @memberNo
  
       /* Mupya */
      if @CutOff = 1
         begin
               select @Cheki = 1
               Exec Proc_GetCapenSal_Pre  @schemeNo,@MemberNo, @PreSalary Out

               if @dateofExit >= @CutOffDate
                  Exec GetServiceTime @Djpens,@CutOffDate,@Years out,@Months out,@Days Out
               else
                  Exec GetServiceTime @Djpens,@dateofExit,@Years out,@Months out,@Days Out

               select @NewStart = DateAdd(Day,1,@CutOffDate)
   
               if @dateofExit >= @NewStart
                  Exec GetServiceTime @NewStart,@dateofExit,@YearsJuu out,@MonthsJuu out,@DaysJuu Out
               else
                  select @YearsJuu = 0.0,@MonthsJuu = 0.0,@DaysJuu = 0.0
         end
     else
        begin
             Exec GetServiceTime @Djpens,@dateofExit,@Years out,@Months out,@Days Out

             select @YearsJuu = 0,@MonthsJuu =0,@DaysJuu=0,@PreSalary = @Salary
        end
       /*Mupya */
       select @ActService = cast(@Years as varchar(2)) + ' years, ' + cast(@Months as varchar(2)) + ' months and '+ cast(@Days as varchar(2))+' Days'
       select @CutOffPeriod = cast(@YearsJuu as varchar(2)) + ' years, ' + cast(@MonthsJuu as varchar(2)) + ' months and '+ cast(@DaysJuu as Varchar(2)) + '  Days'


       if @Prospect = 1
       begin
               Exec GetProspectiveService @SchemeNo,@MemberNo,@ProService out
       
               if @ProService is null select @Proservice = 0
       end
       else select @ProService = 0
 
       select @ProServ = cast(@ProService as varchar(2)) + ' years '

       Select @Years = @Years + @ProService
        
       select @Miaka = @Years,@Miezi = (@Miaka * 12) + @Months
       select @Miakajuu = @Yearsjuu,@Miezijuu = (@Miakajuu * 12) + @Monthsjuu


       Exec CalcNonPensionableUon @schemeNo,@MemberNo,@TotalMonths out,@TotalDays Out,@TotalMonthsPost out,@TotalDaysPost Out

       
       select @PreBreakInService = Cast (@TotalMonths as Varchar(2))+ ' Months and '+ cast(@TotalDays as Varchar(2))+'  Days '
      
       select @PostBreakInService = Cast (@TotalMonthsPost as Varchar(2))+ ' Months and '+ cast(@TotalDaysPost as Varchar(2))+'  Days '
      

       if @TotalMonths > 0
        begin
               if @Days < @TotalDays
                   select @Miezi = @Miezi - 1

          select @Miezi = @Miezi - @TotalMonths
       end

       if @TotalMonthsPost > 0
        begin
          select @Miezijuu = @Miezijuu - @TotalMonthsPost
       end

      

      select @Years = @Miezi/12,@Months = @Miezi%12
      select @YearsJuu = @Miezijuu/12,@Monthsjuu = @Miezijuu%12


       select @serviceTime = cast(@Years as varchar(2)) + ' years, ' + cast(@Months as varchar(2)) + ' months and '+ cast(@Days as varchar(2))+' Days'
     
       declare @MYears int
       select @MYears = datediff(Month, @dob,@dateofExit)

       declare @aMonths as int, @aYears as int
       select @aMonths = @MYears % 12
       select @aYears = (@MYears - (@MYears % 12)) / 12
       
       Select @AgeDesc = cast(@aYears as Varchar(3))+' Years '+ Cast(@aMonths as varchar(2))+' '+'Months'

       Select @GratFact = Gratuity,@RedFact = Reduced,@UnRedFact = UnReduced
       from PercentageFactors where schemeNo = @schemeNo and ServiceYears = @Years

       if @Months > 0
       Select @GratAdd = Gratuity,@RedAdd = Reduced,@UnRedAdd = UnReduced
       from PercentagePoint where schemeNo = @schemeNo and @Months >= StartMonth and @Months < EndMonth
      else
        Select @GratAdd = 0.0,@RedAdd = 0.0,@UnRedAdd = 0.0

       Select @GratFactJuu = Gratuity,@RedFactJuu = Reduced,@UnRedFactJuu = UnReduced
       from PercentageFactors where schemeNo = @schemeNo and ServiceYears = @YearsJuu

       if @GratFactJuu is null Select @GratFactJuu = 0.0
       if @RedFactJuu is null select @RedFactJuu = 0.0
       if @UnRedFactJuu is null select @UnRedFactJuu = 0.0

     
     if @MonthsJuu > 0
       Select @GratAddJuu = Gratuity,@RedAddJuu = Reduced,@UnRedAddJuu = UnReduced
       from PercentagePoint where schemeNo = @schemeNo and @MonthsJuu >= StartMonth and @MonthsJuu < EndMonth
      else
        Select @GratAddJuu = 0.0,@RedAddJuu = 0.0,@UnRedAddJuu = 0.0
        
  
       Exec CalcPercentageBenefits @schemeNo, @MemberNo, @Salary,@Gratuity out,@Reduced out,
            @UnReduced out,@GratuityJuu out,@ReducedJuu out,@UnReducedJuu out

                    
      select @Gratuity = @Gratuity + @GratuityJuu,
       @Reduced = @Reduced + @ReducedJuu,
       @UnReduced = @UnReduced + @UnReducedJuu
       
        if @Cheki = 1
          begin 

             Select @GratReal = ((@GratFact/100.00000000)* @PreSalary) + ((@GratFactJuu/100.00000000)* @Salary)
             Select @GratAddition = ((@GratAdd/100.00000000)* @PreSalary) + ((@GratAddJuu/100.00000000)* @Salary)
             Select @ReducedReal = ((@RedFact/100.00000000)* @PreSalary) + ((@RedFactJuu/100.00000000)* @Salary)
             Select @ReducedAddition = ((@RedAdd/100.00000000)* @PreSalary) + ((@RedAddJuu/100.00000000)* @Salary)
             Select @UnReducedReal = ((@UnRedFact/100.00000000)* @PreSalary) + ((@UnRedFactJuu/100.00000000)* @Salary)
             Select @UnReducedAddition = ((@UnRedAdd/100.00000000)* @PreSalary)+ ((@UnRedAddJuu/100.00000000)* @Salary)
end
       else
          begin
             Select @GratReal = (@GratFact/100.00000000)* @Salary
             Select @GratAddition = (@GratAdd/100.00000000)* @Salary
             Select @ReducedReal = (@RedFact/100.00000000)* @Salary
             Select @ReducedAddition = (@RedAdd/100.00000000)* @Salary
             Select @UnReducedReal = (@UnRedFact/100.00000000)* @Salary
             Select @UnReducedAddition = (@UnRedAdd/100.00000000)* @Salary
          end
             

       

       if @GratAddition is null select @GratAddition = 0
       if @ReducedAddition is null select @ReducedAddition = 0
       if @UnReducedAddition is null select @UnReducedAddition = 0 


       Select @PayGratuity = Gratuity,@GratuityFactor = SalaryFactor 
       from ConfigDeathInService where schemeNo = @schemeNo

       if @Salary > 0
          begin
          select @DeathSalary = @Salary
          select @Gratuity = @DeathSalary * @GratuityFactor
          end
       else
          begin
              select @DeathSalary = @PreSalary
              select @Gratuity = @DeathSalary * @GratuityFactor
          end

       If @Years > 10
          select @TaxFreeLumpsum = @TaxFreeLumpsum
       else
          select @TaxFreeLumpsum = @TaxFreeLumpsum

       declare @TaxAmount float

       
       if @PayGratuity  = 1
          begin
       	     select @TaxAmount = @Gratuity - @taxfreeLumpsum
      
             if @TaxAmount < 0 select @TaxAmount = 0

             Exec GetTaxType @SchemeNo,@MemberNo,@TaxType out

             exec  CalculateTax @schemeNo,@TaxAmount,@DoCalc, @TaxType, @WithHoldingTax out

      
             select @AmountPayable = @Gratuity - @WithHoldingTax

             if @IkoPension = 0
                select @MonPension = 0.0
             else
                 Select @MonPension = (@ReducedReal + @ReducedAddition)/12.0000000

             
             update Benefits set EmpCBal = @Gratuity,EmprCBal = 0,WithholdingTax = @WithHoldingTax
             where SchemeNo = @schemeNo and MemberNo = @MemberNo

             Update DeathClaim set AmountOfCover = @Gratuity,MonPension = @MonPension
             where SchemeNo = @schemeNo and MemberNo = @MemberNo
         end
        else
         begin
            Select @AmountPayable = 0
            Select @TaxAmount = 0
            Select @WithHoldingTax = 0

            if @IkoPension = 0
                select @MonPension = 0.0
             else
                Select @MonPension = (@UnReducedReal+@UnReducedAddition)/12.000000
         end 

    

       Select @CheckNo = CheckNo from Members where SchemeNo = @SchemeNo and MemberNo  = @MemberNo
    
       if @DesignCode > 0
          begin
          select @Title = Designation from Designation where DesignCode = @DesignCode

          select @FullName = upper(@Title) +'  '+@FullName
          end

   if ((@IkoPension = 1) and (@MonPension < 2000.00))
       select @MonPension =  2000.00

   update DeathClaim set MonPension = @MonPension where schemeNO = @SCHEMENO and MEMBERNO = @MEMBERnO

   insert into #calculationPCNT (schemeNo, MemberNo, schemeName, fullname, dje, djpens,
   dateofexit,curYear, salary, serviceTime, dob,
   TaxfreeLumpsum,withHoldingTax,sex, Reason, ageDesc, AmountPayable, TaxableAmount, Grade,
   preparedBy, DatePrepared, CheckedBy, DateChecked, AuthorisedBy, DateAuthorised, MonPension,
                              GratFact,RedFact,UnRedFact,GratAdd,RedAdd,UnRedAdd, Gratuity,Reduced,UnReduced, GratReal, GratAddition, ReducedReal,ReducedAddition,
   UnReducedReal,UnReducedAddition,ProService,ActService,TotalReduced,GratuityFactor,BreakInService,PreSalary,GratuityJuu,ReducedJuu,CutOffPeriod,CutOffDate,
   GratFactJuu,RedFactJuu,GratAddJuu,RedAddJuu,UnRedFactJuu,UnRedAddJuu,AuditedBy,DateAudited,
   PreBreakInservice,PostBreakInService,DeathSalary,DoCalc,IkoPension)
              
        values(@schemeNo, @CheckNo,@schemeName, @fullname, @dTemp, @djpens,@dateofExit, 
                @curYear, @salary,@ServiceTime, @dob,@taxfreeLumpsum ,
                @withHoldingTax,@sex, @Reason, @AgeDesc,
                @AmountPayable,@TaxAmount,@Grade,
                @preparedBy, @DatePrepared, @CheckedBy, @DateChecked, @AuthorisedBy, @DateAuthorised, @MonPension,
                @GratFact,@RedFact,@UnRedFact, @GratAdd,@RedAdd,@UnRedAdd, @Gratuity,@Reduced,@UnReduced, @GratReal, @GratAddition, @ReducedReal,@ReducedAddition,
                @UnReducedReal,@UnReducedAddition,@ProServ,@ActService,@ReducedReal+@ReducedAddition,@GratuityFactor,@BreakInService,
                @PreSalary,@GratuityJuu,@ReducedJuu,@CutOffPeriod,@CutOffDate,
                @GratFactJuu,@RedFactJuu,@GratAddJuu,@RedAddJuu,@UnRedFactJuu,@UnRedAddJuu,@AuditedBy,@DateAudited,
                @PreBreakInservice,@PostBreakInService,@DeathSalary,@DoCalc,@IkoPension)


    
     fetch next from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @dob,  @sex, @fullname,  @curYear,
  @taxfreeLumpsum,@reason
  
end

close GenCursor
deallocate GenCursor

select * from #calculationPCNT
go

