CREATE VIEW [dbo].[FeesRateHistory]      
--with encryption      
as      
Select FR.*,fm.RateDesc,      
       C.ContDesc,S.SponsorName      
from FeesRate fr      
     inner Join FeesRateMode fm on fr.PayMode = fm.RateMode      
     inner Join ContributionType c on fr.PayFrequency = c.ContTypeID     
     inner join Sponsor s on fr.schemeNo = s.schemeNo and fr.SponsorCode = s.SponsorCode
go

