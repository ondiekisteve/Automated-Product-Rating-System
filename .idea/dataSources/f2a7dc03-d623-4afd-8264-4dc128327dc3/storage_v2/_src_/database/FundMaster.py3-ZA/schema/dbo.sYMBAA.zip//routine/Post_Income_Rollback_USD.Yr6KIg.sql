CREATE PROCEDURE [dbo].[Post_Income_Rollback_USD]                                                                     
@schemeNo int,    
@InvCode Int,                         
@InvestCode int,                                                               
@TransDate Datetime,    
@Income Decimal(20,6) out,    
@Withholding float out,    
@Medical float out,    
@AccruedDisc Decimal(20,6) out,    
@CapRepayment float out                                                                                                                                      
--with Encryption                                                                      
as                                                                      
                                                                   
Declare @WithholdingTax float,@MedicalLevy float,                                            
@CreditAcc Varchar(30),@DebitAcc varchar(30),@PayMonth Int,@PayYear Int,@MaxTransNo Int,@Tax float,@BatchNo Int,                                          
@MedLevyDebitAcc varchar(30),@TaxCreditAcc varchar(30),@WithTaxDebitAcc varchar(30),@CStatus smallInt,@CurrCode Int,                                  
@MedLevyCreditAcc varchar(30),@sDate varchar(20),@BondName varchar(200),                        
@dCurrCode int,@CurrRate decimal(20,6),@SecType int,@DrDiscAcc varchar(30),@CrDiscAcc varchar(30),        
@InvName varchar(120),@PrevDate datetime                      
                      
select @SecType = 0                       
                        
Exec DateToStr @TransDate,@sDate out                                    
                                                       
select @dCurrCode = CurrCode from Scheme where schemeCode = @schemeNo                                        
                                    
Exec Proc_Check_Periods @schemeNo,@TransDate,@CStatus Out                                        
                                        
if @CStatus = 1                                        
begin                                        
  raiserror('The Accounting Period for the Transaction does not Exist',16,1)                                        
  return                                      
end                                        
else if @CStatus = 2                                        
begin                                        
  raiserror('The Accounting Period for the Transaction has already been closed',16,1)                                        
  return                                        
end                                        
else if @CStatus = 3                                        
begin                                        
  raiserror('The Fiscal Year for the Transaction has already been closed',16,1)                                        
  return                                        
end                                        
else                                        
begin                                          
        select @TaxCreditAcc = TaxCreditAcc,@MedLevyCreditAcc = MedLevyCreditAcc               
        from Pension_Setup where schemeNo = @schemeNo              
                     
        select @MedLevyDebitAcc = MedLevyAcc,@WithTaxDebitAcc= WithTaxAcc                                  
        from TBL_Invest_TaxRates where schemeNo = @schemeNo and InvestCode = @InvestCode              
                                          
        select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeNo                       
                                            
        if @BatchNo is null select @BatchNo = 0                                            
        select @BatchNo = @BatchNo + 1                                              
                                              
        select @PayMonth = DatePart(Month,@TransDate),@PayYear = DatePart(Year,@TransDate)                      

                
                                              
        select @MaxTransNo = Max(glTransNo) from SchemeGeneralLedger where schemeCode = @schemeNo                         
        if @MaxTransNo is null select @MaxTransNo = 0                                              
        select @MaxTransNo = @MaxTransNo + 1                        
                                                
select @PrevDate = Max(TransDate) from TBL_INVEST_RECEIVABLE                                           
where schemeNo = @schemeNo and InvestCode = @InvestCode and TransDate < @TransDate     
and InvCode = @InvCode    
    
if @PrevDate is not null    
BEGIN                                                                                                                               
if @InvestCode = 4  /* Treasury Bills and Bonds */                                                   
   begin                                                                               
    Declare PrevCsr Cursor for                                                                     
    select i.InvName,t.IncomePrev,t.WithholdingPrev,t.MedicalPrev,t.AccruedDiscPrev,t.ExRate,t.CapRepaymentPrev,p.CreditAcc,p.DebitAcc,@dCurrCode,                      
    p.SecurityType,p.AccDiscountAcc,p.DiscountAcc                                             
    from TBL_INVEST_RECEIVABLE t                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                        
        inner join GovernmentSecurities p on t.schemeNo = p.schemeNo and t.invCode = p.SecurityNo                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @PrevDate and t.InvCode = @InvCode                                                     
   end                                          
else if @InvestCode = 7  /* Commercial Paper */                                                   
   begin                                                                                                 
    Declare PrevCsr Cursor for                                                                     
    select i.InvName,t.IncomePrev,t.WithholdingPrev,t.MedicalPrev,t.AccruedDiscPrev,t.ExRate,t.CapRepaymentPrev,p.CreditAcc,p.DebitAcc,p.CurrCode,                      
    0,'',''                                              
    from TBL_INVEST_RECEIVABLE t                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                        
        inner join CommercialPaper p on t.schemeNo = p.schemeNo and t.invCode = p.PaperNo                            
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @PrevDate and t.InvCode = @InvCode                                       
  end                                                          
else if @InvestCode = 5 /* Cash and Deposits */                                                  
  begin                                        
    Declare PrevCsr Cursor for                                                                     
    select i.InvName,t.IncomePrev,t.WithholdingPrev,t.MedicalPrev,t.AccruedDiscPrev,t.ExRate,t.CapRepaymentPrev,p.CreditAcc,p.DebitAcc,p.CurrCode,                      
    0,'',''                                              
    from TBL_INVEST_RECEIVABLE t                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                        
        inner join CashDeposits p on t.schemeNo = p.schemeNo and t.invCode = p.DepositNo                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @PrevDate and t.InvCode = @InvCode                        
  end            
else if @InvestCode = 9  /* Long Term Loans */                                                   
   begin                                                                                   
    Declare PrevCsr Cursor for                                         
    select i.InvName,t.IncomePrev,t.WithholdingPrev,t.MedicalPrev,t.AccruedDiscPrev,t.ExRate,t.CapRepaymentPrev,p.InterestAcc,p.InterestRecAcc,@dCurrCode,                      
    0,p.CapRepayRecAcc,p.AssetAcc                                             
    from TBL_INVEST_RECEIVABLE t                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode            
        inner join TBL_LOANS p on t.schemeNo = p.schemeNo and t.invCode = p.MortgageNo                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @PrevDate and t.InvCode = @InvCode                                                                                     
   end       
else if @InvestCode = 2 /* Preferential Shares */                                                  
  begin                                        
    Declare PrevCsr Cursor for                                                                     
    select i.InvName,t.IncomePrev,t.WithholdingPrev,t.MedicalPrev,t.AccruedDiscPrev,t.ExRate,t.CapRepaymentPrev,p.DividendsAcc,p.AccrDividendsAcc,p.CurrCode,                      
    0,'',''                                              
    from TBL_INVEST_RECEIVABLE t                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                        
        inner join Equity p on t.schemeNo = p.schemeNo and t.invCode = p.EquityNo                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @PrevDate and t.InvCode = @InvCode                        
  end                                                 
                                              
Open PrevCsr                                              
Fetch from PrevCsr Into @BondName,@Income,@Withholding,@Medical,@AccruedDisc,@CurrRate,@CapRepayment,@CreditAcc,@DebitAcc,@CurrCode,                      
                        @SecType,@DrDiscAcc,@CrDiscAcc                                              
while @@fetch_Status = 0                                              
begin         
   select @InvName = @BondName        
          
   IF @CapRepayment is null select @CapRepayment = 0   
   IF @Income is null select @Income = 0     
   IF @Withholding is null select @Withholding = 0   
   IF @Medical is null select @Medical = 0    
   IF @CapRepayment is null select @CapRepayment = 0       
                        
   Exec Proc_Get_Forex_Rate @schemeNo,@CurrCode,@PrevDate,@CurrRate Out          
                                                                       
   select @Tax = @Medical + @Withholding                                  
                                              
   select @BondName = 'Rollback accrued Interest for '+ @InvName                                              
                                          
   Exec PostLedgerCredits_RecPay @SchemeNo,@DebitAcc,0,@Income,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
   @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                
                                              
   Exec PostLedgerDebits_RecPay @SchemeNo,@CreditAcc,0,@Income,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
   @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                               
                               
   IF @Tax > 0                                          
   BEGIN                                           
   IF @Medical > 0                                   
      begin                                    
      Exec PostLedgerCredits_RecPay @SchemeNo,@MedLevyDebitAcc,0,@Medical,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
      @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                   
                                          
      Exec PostLedgerDebits_RecPay @SchemeNo,@MedLevyCreditAcc,0,@Medical,@PayMonth,@PayYear,@BondName,0,@TransDate,                              
      @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                            
      end                  
                                              
   IF @Withholding > 0                                   
      begin                                   
      Exec PostLedgerCredits_RecPay @SchemeNo,@WithTaxDebitAcc,0,@Withholding,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
      @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                   
                                                  
      Exec PostLedgerDebits_RecPay @SchemeNo,@TaxCreditAcc,0,@Withholding,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
      @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                    
      end                                          
   END                       
                      
                      
   if ((@InvestCode = 4) and (@SecType = 28))                      
      begin                      
         if @AccruedDisc <> 0                      
            begin                      
                               
              Exec PostLedgerCredits_RecPay @SchemeNo,@DrDiscAcc,0,@AccruedDisc,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
              @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                   
                                                  
              Exec PostLedgerDebits_RecPay @SchemeNo,@CrDiscAcc,0,@AccruedDisc,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
              @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                    
                      
            end                      
      end           
          
   if ((@InvestCode = 9) and (@CapRepayment > 0))          
      begin           
          
        select @BondName = 'Accrued Capital Repayment for '+ @InvName                                              
                                          
        Exec PostLedgerCredits_RecPay @SchemeNo,@DrDiscAcc,0,@CapRepayment,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
        @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                
                                              
        Exec PostLedgerDebits_RecPay @SchemeNo,@CrDiscAcc,0,@CapRepayment,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                
        @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode          
      end     
                   
                                                                
   select @BondName='',@MaxTransNo = @MaxTransNo + 1,@CreditAcc='',@DebitAcc='',                                              
   @Tax = 0,@CurrCode=0,@CurrRate = 1.0000,@SecType=0,@DrDiscAcc='',@CrDiscAcc=''                        
                                              
   Fetch next from PrevCsr Into @BondName,@Income,@Withholding,@Medical,@AccruedDisc,@CurrRate,@CapRepayment,@CreditAcc,@DebitAcc,@CurrCode,                      
                                @SecType,@DrDiscAcc,@CrDiscAcc                                               
end                                              
Close PrevCsr                                              
Deallocate PrevCsr     
    
END    
else    
BEGIN    
  SELECT @Income = 0,@Withholding=0,@Medical=0,@AccruedDisc=0,@CapRepayment = 0     
END                                                      
                       
end
go

