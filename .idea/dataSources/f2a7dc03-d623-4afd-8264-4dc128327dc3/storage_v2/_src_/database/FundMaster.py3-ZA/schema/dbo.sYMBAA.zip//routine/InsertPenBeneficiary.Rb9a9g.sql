CREATE PROCEDURE [dbo].[InsertPenBeneficiary]                                    
@SCHEMENO Int,                                    
@MemberNo int,                                    
@DepCode int,                                    
@Pension float,                                    
@PenNo1 Varchar(15)                                    
--with Encryption                                    
as                                    
                                    
declare @DoDeath datetime,@sName varchar(50),@penNo varchar(15),                                    
@BenPenReduce Bit,@FullRate Int,@HalfRate Int,@Guarantee Int,@GuaranteeEnd Datetime,@PenOnGuarantee smallInt,                                  
@GuaranteePeriod Int,@DoBirth datetime,@doClaim datetime,@Minor smallint,@NumYears int,@NumMonths int,@NumDays Int,                                
@Disabled smallint,@ChildMaxAge int,@DepType Int,@Mukuba smallint,@DecDepCode Int,@DecMonPension decimal(20,2),                          
@EndDate datetime,@HalfDate datetime,@penStartDate datetime,@User varchar(50),@DateCaptured datetime,                  
@cmonth int,@cYear int,@ChangeDate datetime,@stop int,@HasGuardian int,@Guardian int,@Arrears float,    
@BenLifeGuarantee smallint,@ChildLifeGuarantee smallint,@AccountName varchar(155)                                                
                          
select @User = user,@DateCaptured = getdate()                  
                  
select @cMonth  = datepart(month,@DateCaptured),@cYear = datepart(Year,@DateCaptured)                      
                      
Exec GetFirstDate @cMonth,@cYear,@ChangeDate out                              
                            
                                
                              
select @Mukuba = Mukuba from scheme where schemeCode = @schemeNo                              
if @Mukuba is null select @Mukuba = 0                                         
                                
select @ChildMaxAge = ChildMaxAge from Pension_setup                                    
where SchemeNo = @schemeNo                                 
                                
if @ChildMaxAge is null select @ChildMaxAge = 18                                    
                                    
                                    
Select @BenPenReduce = BenPenReduce,@FullRate = FullRate,@HalfRate = HalfRate,                                  
@PenOnGuarantee = PenOnGuarantee,@BenLifeGuarantee = BenLifeGuarantee,@ChildLifeGuarantee = ChildLifeGuarantee from ConfigDeathRetirement                                    
where SchemeNo = @schemeNo                                   
                                  
if @PenOnGuarantee is null select @PenOnGuarantee = 0    
    
if @BenLifeGuarantee is null select @BenLifeGuarantee = 1    
if @ChildLifeGuarantee is null select @ChildLifeGuarantee = 0                                   
                                    
if @BenPenReduce is null                                     
   begin                                    
           select @BenPenReduce = 0                                    
           select @FullRate = 5                                    
           Select @HalfRate = 0                                    
   end                                    
                                  
                                   
   select @Guarantee = @FullRate + @HalfRate                                  
                                   
                                    
select @sName = Sname,@DoBirth = doB,@doClaim = ClaimDate,@Disabled = Disabled,@DepType = DependantType,      
@DecDepCode = DecDepCode,@HasGuardian = HasGuardian,@Guardian = Guardian,@AccountName = Sname +', '+fname+' '+Oname                                
from Dependants where SchemeNo = @SchemeNo and MemberNo = @MemberNo and DependantCode = @DepCode   
  
/* Update AccountName in Dependants */  

update Dependants set AccountName = @AccountName   
where SchemeNo = @SchemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                                    
                      
select @PenStartDate = @doClaim + 1                          
                                    
if @Disabled is null select @Disabled = 0                            
if @DecDepCode is null select @DecDepCode = 0      
if @HasGuardian is null select @HasGuardian = 0        
if @Guardian is null select @Guardian = 0                                
                              
if @SchemeNo = 1005                                 
   exec GetPenNo @schemeNo,@sName,3,@PenNo out                              
else if @Mukuba = 1                              
   begin                              
   exec GetPenNo @schemeNo,@sName,3,@PenNo out                               
   /*                           
   if ((@DepType >= 3) and (@DepType <= 4))                              
      select @PenNo = 'C'+@PenNo                              
   else                              
      select @PenNo = 'S'+@PenNo                              
   */                           
   end        
else        
   select @PenNo = @PenNo1             
            
SELECT @DecDepCode = 0            
                                   
                          
IF @DecDepCode = 0                                    
   select @DoDeath = DoDeath,@GuaranteeEnd = GuaranteeEnd                                   
   from PenDeathClaim where SchemeNo = @schemeNo and MemberNo = @MemberNo                                    
else                             
   select @DoDeath = DoDeath from BenDeathClaim where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DecDepCode                                 
                                     
select @doDeath = dateAdd(Day,1,@DoDeath)                
                                    
/*                                    
if @DoDeath <= 'Oct 01,2001'                                    
   select @FullRate = 3,@HalfRate = 7                                                          
select @Guarantee = @FullRate + @HalfRate                                    
                                    
if  @BenPenReduce  = 0  select @HalfRate= @FullRate                                    
                                  
if @DoDeath > 'Oct 01,2001'                                    
   Select @HalfRate = @FullRate                                
*/                                    
if @PenOnGuarantee = 1                                  
   begin                                  
     if @DoDeath >= @GuaranteeEnd                                  
        begin                                  
          raiserror('The Date deceased is after the end of the Guaranteed Period',16,1)                                  
        Return                                  
        end                                  
     else                                  
        begin                                  
          select @GuaranteePeriod = Guarantee from Pensioner where SchemeNo = @schemeNo and MemberNo = @MemberNo                                  
                                  
          if @GuaranteePeriod = 1 /* Zero Guarantee */                                  
             select @Guarantee = 10                                  
          else if @GuaranteePeriod = 2 /* 5 Year Guarantee */                                  
             select @Guarantee = 5                                  
          else if @GuaranteePeriod = 3 /* 10 Year Guarantee */                                  
             select @Guarantee = 10                                  
          else if @GuaranteePeriod = 4 /* 15 Year Guarantee */                                  
             select @Guarantee = 15                                 
                                
                            
          if @Disabled is null select @Disabled = 0                                
                                
          Exec GetServiceTime @DoBirth,@doClaim,@NumYears Out,@NumMonths Out,@NumDays Out                             
                                
              
if @DepType <= 2 /* Spouse */    
   begin     
       if @BenLifeGuarantee = 0 /* Spouse Pension Not guaranteed for Life - pension end after the guaranteed period (fullrate) */    
          begin    
             select @EndDate = DateAdd(Year, @fullRate,@doDeath),@HalfDate = DateAdd(Year,@fullRate,@doDeath)    
          end    
       else    
          select @EndDate = 'Dec 31,9999'    
   end    
else if @DepType >= 3 and @DepType <= 4 /* Child Pension */    
   begin    
       if @ChildLifeGuarantee = 0 /* Child Pension Not guaranteed for Life - pension end after attaining the maximum age to receive pension */    
          begin    
              select @EndDate = DateAdd(Year, @ChildMaxAge,@DoBirth),@HalfDate = DateAdd(Year, @ChildMaxAge,@DoBirth)    
          end    
       else    
          select @EndDate = 'Dec 31,9999'    
   end     
else  /* Other Dependant Types - pension end after the guaranteed period (fullrate) */       
   begin    
      select @EndDate = DateAdd(Year, @fullRate,@doDeath),@HalfDate = DateAdd(Year,@fullRate,@doDeath)    
   end    
    
if @enddate is null /* pension end after the guaranteed period (fullrate) */    
    begin    
       select @EndDate = DateAdd(Year, @fullRate,@doDeath),@HalfDate = DateAdd(Year,@fullRate,@doDeath)    
    end    
    
                     
if @disabled = 1 /* for Beneficiaries with Disability  - Pension paid for Life */                              
   select @EndDate = 'Dec 31,9999'                               
                                   
        end                                  
   end                                     
          
if @EndDate is null select @EndDate = 'Dec 31,2013'          
                                    
if Exists(Select * from PenBeneficiary where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode)                                    
   BEGIN        
                    
   Select @Stop = Stop,@Arrears = Arrears from PenBeneficiary                 
   where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode       
   if @Arrears is null select @Arrears = 0      
      
   if ((@Arrears > 0) and (@HasGuardian = 1) and (@Guardian > 0))      
      begin      
         update PenBeneficiary set Arrears = Arrears + @Arrears      
         where schemeNo = @schemeNo and memberNo = @MemberNo and Dependantcode = @Guardian      
      end        
                          
   IF @Stop = -1                
     BEGIN                         
     if @DecDepCode = 0                            
        Update PenBeneficiary  set MonPension = @Pension, StartDate = @doDeath, EndDate = @EndDate,                                    
        HalfRateDate = @HalfDate,PenNo = @PenNo1                                    
        where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                            
     else                            
        Update PenBeneficiary  set DecMonPension = @Pension,PenNo = @PenNo1                                   
        where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                  
     END        
   ELSE        
     BEGIN        
       if @DecDepCode = 0                            
        Update PenBeneficiary  set MonPension = @Pension, StartDate = @doDeath, EndDate = @EndDate,                                    
        HalfRateDate = @HalfDate,PenNo = @PenNo1                                    
        where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                            
     else                            
        Update PenBeneficiary  set DecMonPension = @Pension,PenNo = @PenNo1                                   
        where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode         
     END                          
   END                                    
else                                       begin                           
         if @DecDepCode = 0                            
             select @DecMonPension = 0                            
         else                            
             select @DecMonPension = @Pension,@pension = 0                    
                                   
         if @schemeNo = 1005                                    
                 begin                                    
                      insert into PenBeneficiary(SchemeNo, MemberNo, DependantCode, MonPension,                            
                                                  StartDate, EndDate, PenNo, PayType,PayPoint,Paycode,                          
                                                  HalfRateDate,Arrears, DecMonPension,DecArrears,Stop,AccountName)                                   
                      Values(@SchemeNo, @MemberNo, @DepCode, @Pension, @DoDeath, @EndDate,@penNo, 4,                            
                 '1005', 1,@HalfDate,0.0,@DecMonPension,0,-1,@AccountName)                       
                      
                      
                      Delete from TBL_Payroll_Changes where schemeNo = @schemeNo and MemberNo = @MemberNo                           
                      and DepCode = @DepCode and ChangeType = 1                            
                            
                      Insert into TBL_Payroll_Changes(schemeNo,MemberNo,DepCode,PenOrBen,MonPension,Bank,Branch,AccountNo,                                        
                                          finBank,FinBranch,FinAccountNo,Paypoint,PaypointBranch,PenFrequency,                                        
                                          FreqstartDate,PayType,Approved,ChangeType,CapturedBy,DateCaptured,ChangeDate)                                        
                      Values(@SchemeNo,@MemberNo,@DepCode,1,@Pension,0,0,'0',0,0,'',                                        
                                         0,0,1,@PenStartDate,4,0,1,@User,@DateCaptured,@ChangeDate)                                     
                 end                                
         else if @mukuba = 1                           
                 begin                                    
                       insert into PenBeneficiary(SchemeNo, MemberNo, DependantCode, MonPension, StartDate, EndDate,                             
                                                  PenNo, PayType,PayPoint,Paycode,HalfRateDate,Arrears,                       
                                   DecMonPension,DecArrears,Stop,AccountName)                                   
                      Values(@SchemeNo, @MemberNo, @DepCode, @Pension, @DoDeath,@EndDate,                            
                             @penNo, 4, '0', 1,@HalfDate,0.0,@DecMonPension,0,-1,@AccountName)                       
                      
                      Delete from TBL_Payroll_Changes where schemeNo = @schemeNo and MemberNo = @MemberNo                           
                      and DepCode = @DepCode and ChangeType = 1                            
                            
                      Insert into TBL_Payroll_Changes(schemeNo,MemberNo,DepCode,PenOrBen,MonPension,Bank,Branch,AccountNo,                                        
                                          finBank,FinBranch,FinAccountNo,Paypoint,PaypointBranch,PenFrequency,                                        
                                          FreqstartDate,PayType,Approved,ChangeType,CapturedBy,DateCaptured,ChangeDate)                                        
                      Values(@SchemeNo,@MemberNo,@DepCode,1,@Pension,0,0,'0',0,0,'',                                        
                                         0,0,1,@PenStartDate,1,0,1,@User,@DateCaptured,@ChangeDate)                                   
                 end                                    
         else                                    
                 begin                                
                      Select @PenNo = @PenNo1          
                                                       
                                    
                      insert into PenBeneficiary(SchemeNo, MemberNo, DependantCode, MonPension, StartDate,                             
                      EndDate, PenNo,HalfRateDate,Arrears, DecMonPension,DecArrears,Stop,AccountName)                                    
                      Values(@SchemeNo, @MemberNo, @DepCode, @Pension, @DoDeath, @EndDate                            
                            ,@PenNo,@halfdate,0.0,@DecMonPension,0,-1,@AccountName)                      
                      
                      Delete from TBL_Payroll_Changes where schemeNo = @schemeNo and MemberNo = @MemberNo               
               and DepCode = @DepCode and ChangeType = 1                            
                            
                      Insert into TBL_Payroll_Changes(schemeNo,MemberNo,DepCode,PenOrBen,MonPension,Bank,Branch,AccountNo,                                        
                                          finBank,FinBranch,FinAccountNo,Paypoint,PaypointBranch,PenFrequency,                                        
                                  FreqstartDate,PayType,Approved,ChangeType,CapturedBy,DateCaptured,ChangeDate)                                        
                      Values(@SchemeNo,@MemberNo,@DepCode,1,@Pension,0,0,'0',0,0,'',                                        
                                         0,0,1,@PenStartDate,1,0,1,@User,@DateCaptured,@ChangeDate)                                    
  end                                    
                                    
  end
go

