








































CREATE PROCEDURE PerformanceAnalysis
@SCHEMENO Int,
@PropCode Int,
@ManageRate float,
@MaintRate float,
@InsureRate float,
@NumYear Int,
@EscalRate float,
@EscalPeriod Int,
@RoRet float,
@UseData bit,
@PCost float,
@PIncome float,
@PropName Varchar(100)
as

if object_id('tempdb..##Performance') is null

begin
create table ##Performance
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[PerfGroup] [Int]NOT NULL,
        [RowName][Varchar](100),
	[Year1][float],
        [Year2][float],
        [Year3][float],
        [Year4][float],
        [Year5][float],
        [Year6][float],
        [Year7][float],
        [Year8][float],
        [Year9][float],
        [Year10][float],
        [Year11][float],
        [Year12][float],
        [Year13][float],
        [Year14][float],
        [Year15][float],
        [Year16][float],
        [Year17][float],
        [Year18][float],
        [Year19][float],
        [Year20][float],
        [ManageRate][float],
        [MaintRate][float],
        [InsureRate][float],
        [Cost][float],
        [AVGROi][float],
        [PayBack][float],
        [NPV][Float],
        [IRR][Float],
        [ProfIndex][float],
        [PropName][Varchar](100)
) 

ALTER TABLE ##Performance WITH NOCHECK ADD 

            
	CONSTRAINT [PK_Performance] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end

declare @Cost float,@AnnRent float,@PerfGroup Int,@RowName Varchar(100),
@MaintVal float,@ManageVal float,@InsureVal float,
@Year1 float,@Year2 float,@Year3 float,@Year4 float,@Year5 float,@Year6 float,@Year7 float,
@Year8 float,@Year9 float,@Year10 float,@Year11 float,@Year12 float,
@Year13 float,@Year14 float,@Year15 float,@Year16 float,@Year17 float,
@Year18 float,@Year19 float,@Year20 float,@StartYear Int,@AnnRent1 float,
@TumiaRate float,
@Year1C float,@Year2C float,@Year3C float,@Year4C float,@Year5C float,@Year6C float,
@Year7C float,
@Year8C float,@Year9C float,@Year10C float,@Year11C float,@Year12C float,
@Year13C float,@Year14C float,@Year15C float,@Year16C float,@Year17C float,
@Year18C float,@Year19C float,@Year20C float,@npv float,@irr float,@profIndex float,@Property Varchar(100)

Select @StartYear = 1
if @UseData = 0
   begin
         select @Cost = InitValue,@Property = InvName from Investments
         where SchemeNo = @schemeNo and InvCode = @PropCode
         select @AnnRent = sum(RentPerMonth) from Units
         where SchemeNo = @schemeNo and PropertyCode = @PropCode
   end
else
  begin
       select @Cost = @pCost,@AnnRent = @PIncome,@Property =@PropName
  end
delete from ##Performance
/* PROJECT Rental Income */
select @TumiaRate = @MaintRate
if @EscalPeriod > 0 and @EscalRate > 0
begin
   /* Maintenance */
   if @EscalPeriod = 1
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year2 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year3 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year4 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year6 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year8 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000)



        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year12 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year14 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year18 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year20 = @AnnRent1 * (@TumiaRate/100.00000000)
      end
   else if @EscalPeriod = 2
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year3 = @AnnRent1 * (@TumiaRate/100.00000000),@Year4 = @Year3
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000),@Year6 = @Year5
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000),@Year16 = @Year15
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19
      end
   else if @EscalPeriod = 3
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year4 = @AnnRent1 * (@TumiaRate/100.00000000),@Year5 = @Year4,
        @Year6 = @Year4
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7,
        @Year9 = @Year7 
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000),@Year11 = @Year10,
        @Year12 = @Year10 
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000),@Year17 = @Year16,
        @Year18 = @Year16
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19   
      end
   else if @EscalPeriod = 4
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000),@Year6 = @Year5,
        @Year7 = @Year5,@Year8 = @Year5
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9,
        @Year11 = @Year9,@Year12 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15 = @Year13,@Year16 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17,
        @Year19 = @Year17,@Year20 = @Year17
      end
   else if @EscalPeriod = 5
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year6 = @AnnRent1 * (@TumiaRate/100.00000000),@Year7 = @Year6,
        @Year8 = @Year6,@Year9 = @Year6,@Year10 = @Year6
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11,
        @Year13 = @Year11,@Year14 = @Year11,@Year15 = @Year11
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000),@Year17 = @Year16,
        @Year18 = @Year16,@Year19 = @Year16,@Year20 = @Year16
      end
   else if @EscalPeriod = 6
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7,
        @Year9= @Year7,@Year10 = @Year7,@Year11 = @Year7,@Year12 = @Year7
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15= @Year13,@Year16 = @Year13,@Year17 = @Year13,@Year18 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19
      end
   else if @EscalPeriod = 7
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year8 = @AnnRent1 * (@TumiaRate/100.00000000),@Year9 = @Year8,
        @Year10= @Year8,@Year11 = @Year8,@Year12 = @Year8,@Year13 = @Year8,
        @Year14 = @Year8
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000),@Year16 = @Year15,
        @Year17= @Year15,@Year18 = @Year15,@Year19 = @Year15,@Year20 = @Year15
      end
   else if @EscalPeriod = 8
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9,
        @Year11= @Year9,@Year12 = @Year9,@Year13 = @Year9,@Year14 = @Year9,
        @Year15 = @Year9,@Year16 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17,
        @Year19= @Year17,@Year20 = @Year17
      end
   else if @EscalPeriod = 9
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1,@Year9= @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000),@Year11 = @Year10,
        @Year12= @Year10,@Year13 = @Year10,@Year14 = @Year10,@Year15 = @Year10,
        @Year16 = @Year10,@Year17 = @Year10,@Year18 = @Year10
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19      end
   else if @EscalPeriod = 10
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1,@Year9= @Year1,@Year10 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11,
        @Year13= @Year11,@Year14 = @Year11,@Year15 = @Year11,@Year16 = @Year11,
        @Year17 = @Year11,@Year18 = @Year11,@Year19 = @Year11,@Year20 = @Year11
      end
end
else
   begin
       Select @Year1= @AnnRent * (@TumiaRate/100.00000000)
       select @Year2= @Year1,@Year3 = @Year1,@Year3 = @Year1,@Year4 = @Year1,
              @Year5= @Year1,@Year6 = @Year1,@Year7 = @Year1,@Year8 = @Year1,
              @Year9= @Year1,@Year10 = @Year1,@Year11 = @Year1,@Year12 = @Year1,
              @Year13= @Year1,@Year14 = @Year1,@Year15 = @Year1,@Year16 = @Year1,
              @Year17= @Year1,@Year18 = @Year1,@Year19 = @Year1,@Year20 = @Year1
   end

Select @PerfGroup = 1,@RowName = 'Maintenance'
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1,@Year2,@Year3,@Year4,@Year5,@Year6,@Year7,@Year8,@Year9,@Year10,
 @Year11,@Year12,@Year13,@Year14,@Year15,@Year16,@Year17,@Year18,@Year19,@Year20)

/* PROJECT Rental Income */
select @TumiaRate = @ManageRate
if @EscalPeriod > 0 and @EscalRate > 0
begin
   /* Management Fees */
  if @EscalPeriod = 1
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year2 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year3 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year4 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year6 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year8 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000)

        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year12 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year14 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year18 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year20 = @AnnRent1 * (@TumiaRate/100.00000000)
      end
   else if @EscalPeriod = 2
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year3 = @AnnRent1 * (@TumiaRate/100.00000000),@Year4 = @Year3
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000),@Year6 = @Year5
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000),@Year16 = @Year15
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19
      end
   else if @EscalPeriod = 3
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year4 = @AnnRent1 * (@TumiaRate/100.00000000),@Year5 = @Year4,
        @Year6 = @Year4
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7,
        @Year9 = @Year7 
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000),@Year11 = @Year10,
        @Year12 = @Year10 
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000),@Year17 = @Year16,
        @Year18 = @Year16
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19   
      end
   else if @EscalPeriod = 4
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000),@Year6 = @Year5,
        @Year7 = @Year5,@Year8 = @Year5
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9,
        @Year11 = @Year9,@Year12 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15 = @Year13,@Year16 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17,
        @Year19 = @Year17,@Year20 = @Year17
      end
   else if @EscalPeriod = 5
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year6 = @AnnRent1 * (@TumiaRate/100.00000000),@Year7 = @Year6,
        @Year8 = @Year6,@Year9 = @Year6,@Year10 = @Year6
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11,
        @Year13 = @Year11,@Year14 = @Year11,@Year15 = @Year11
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000),@Year17 = @Year16,
        @Year18 = @Year16,@Year19 = @Year16,@Year20 = @Year16
      end
   else if @EscalPeriod = 6
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7,
        @Year9= @Year7,@Year10 = @Year7,@Year11 = @Year7,@Year12 = @Year7
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15= @Year13,@Year16 = @Year13,@Year17 = @Year13,@Year18 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19
      end
   else if @EscalPeriod = 7
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year8 = @AnnRent1 * (@TumiaRate/100.00000000),@Year9 = @Year8,
        @Year10= @Year8,@Year11 = @Year8,@Year12 = @Year8,@Year13 = @Year8,
        @Year14 = @Year8
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000),@Year16 = @Year15,
        @Year17= @Year15,@Year18 = @Year15,@Year19 = @Year15,@Year20 = @Year15
      end
   else if @EscalPeriod = 8
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9,
        @Year11= @Year9,@Year12 = @Year9,@Year13 = @Year9,@Year14 = @Year9,
        @Year15 = @Year9,@Year16 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17,
        @Year19= @Year17,@Year20 = @Year17
      end
   else if @EscalPeriod = 9
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1,@Year9= @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000),@Year11 = @Year10,
        @Year12= @Year10,@Year13 = @Year10,@Year14 = @Year10,@Year15 = @Year10,
        @Year16 = @Year10,@Year17 = @Year10,@Year18 = @Year10
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19      end
   else if @EscalPeriod = 10
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1,@Year9= @Year1,@Year10 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11,
        @Year13= @Year11,@Year14 = @Year11,@Year15 = @Year11,@Year16 = @Year11,
        @Year17 = @Year11,@Year18 = @Year11,@Year19 = @Year11,@Year20 = @Year11
      end
end
else
   begin
       Select @Year1= @AnnRent * (@TumiaRate/100.00000000)
       select @Year2= @Year1,@Year3 = @Year1,@Year3 = @Year1,@Year4 = @Year1,
              @Year5= @Year1,@Year6 = @Year1,@Year7 = @Year1,@Year8 = @Year1,
              @Year9= @Year1,@Year10 = @Year1,@Year11 = @Year1,@Year12 = @Year1,
              @Year13= @Year1,@Year14 = @Year1,@Year15 = @Year1,@Year16 = @Year1,
              @Year17= @Year1,@Year18 = @Year1,@Year19 = @Year1,@Year20 = @Year1
   end

Select @PerfGroup = 1,@RowName = 'Management Fees'
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1,@Year2,@Year3,@Year4,@Year5,@Year6,@Year7,@Year8,@Year9,@Year10,
 @Year11,@Year12,@Year13,@Year14,@Year15,@Year16,@Year17,@Year18,@Year19,@Year20)

/* PROJECT Rental Income */
select @TumiaRate = @InsureRate
if @EscalPeriod > 0 and @EscalRate > 0
begin
   /* Insurance */
   if @EscalPeriod = 1
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year2 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year3 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year4 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year6 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year8 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000)

        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year12 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year14 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year18 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000)
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year20 = @AnnRent1 * (@TumiaRate/100.00000000)
      end
   else if @EscalPeriod = 2
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year3 = @AnnRent1 * (@TumiaRate/100.00000000),@Year4 = @Year3
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000),@Year6 = @Year5
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000),@Year16 = @Year15
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19
      end
   else if @EscalPeriod = 3
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year4 = @AnnRent1 * (@TumiaRate/100.00000000),@Year5 = @Year4,
        @Year6 = @Year4
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7,
        @Year9 = @Year7 
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000),@Year11 = @Year10,
        @Year12 = @Year10 
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000),@Year17 = @Year16,
        @Year18 = @Year16
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19   
      end
   else if @EscalPeriod = 4

      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1 * (@TumiaRate/100.00000000),@Year6 = @Year5,
        @Year7 = @Year5,@Year8 = @Year5
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9,
        @Year11 = @Year9,@Year12 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15 = @Year13,@Year16 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17,
        @Year19 = @Year17,@Year20 = @Year17
      end
   else if @EscalPeriod = 5
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year6 = @AnnRent1 * (@TumiaRate/100.00000000),@Year7 = @Year6,
        @Year8 = @Year6,@Year9 = @Year6,@Year10 = @Year6
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11,
        @Year13 = @Year11,@Year14 = @Year11,@Year15 = @Year11
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1 * (@TumiaRate/100.00000000),@Year17 = @Year16,
        @Year18 = @Year16,@Year19 = @Year16,@Year20 = @Year16
      end
   else if @EscalPeriod = 6
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1 * (@TumiaRate/100.00000000),@Year8 = @Year7,
        @Year9= @Year7,@Year10 = @Year7,@Year11 = @Year7,@Year12 = @Year7
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1 * (@TumiaRate/100.00000000),@Year14 = @Year13,
        @Year15= @Year13,@Year16 = @Year13,@Year17 = @Year13,@Year18 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19
      end
   else if @EscalPeriod = 7
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year8 = @AnnRent1 * (@TumiaRate/100.00000000),@Year9 = @Year8,
        @Year10= @Year8,@Year11 = @Year8,@Year12 = @Year8,@Year13 = @Year8,
        @Year14 = @Year8
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1 * (@TumiaRate/100.00000000),@Year16 = @Year15,
        @Year17= @Year15,@Year18 = @Year15,@Year19 = @Year15,@Year20 = @Year15
      end
   else if @EscalPeriod = 8
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1 * (@TumiaRate/100.00000000),@Year10 = @Year9,
        @Year11= @Year9,@Year12 = @Year9,@Year13 = @Year9,@Year14 = @Year9,
        @Year15 = @Year9,@Year16 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1 * (@TumiaRate/100.00000000),@Year18 = @Year17,
        @Year19= @Year17,@Year20 = @Year17
      end
   else if @EscalPeriod = 9
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1,@Year9= @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1 * (@TumiaRate/100.00000000),@Year11 = @Year10,
        @Year12= @Year10,@Year13 = @Year10,@Year14 = @Year10,@Year15 = @Year10,
        @Year16 = @Year10,@Year17 = @Year10,@Year18 = @Year10
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1 * (@TumiaRate/100.00000000),@Year20 = @Year19      end
   else if @EscalPeriod = 10
      begin
        Select @Year1= @AnnRent * (@TumiaRate/100.00000000),@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1,@Year9= @Year1,@Year10 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1 * (@TumiaRate/100.00000000),@Year12 = @Year11,
        @Year13= @Year11,@Year14 = @Year11,@Year15 = @Year11,@Year16 = @Year11,
        @Year17 = @Year11,@Year18 = @Year11,@Year19 = @Year11,@Year20 = @Year11
      end
   end
else
   begin
       Select @Year1= @AnnRent * (@TumiaRate/100.00000000)
       select @Year2= @Year1,@Year3 = @Year1,@Year3 = @Year1,@Year4 = @Year1,
              @Year5= @Year1,@Year6 = @Year1,@Year7 = @Year1,@Year8 = @Year1,
              @Year9= @Year1,@Year10 = @Year1,@Year11 = @Year1,@Year12 = @Year1,
              @Year13= @Year1,@Year14 = @Year1,@Year15 = @Year1,@Year16 = @Year1,
              @Year17= @Year1,@Year18 = @Year1,@Year19 = @Year1,@Year20 = @Year1
   end

Select @PerfGroup = 1,@RowName = 'Insurance'
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1,@Year2,@Year3,@Year4,@Year5,@Year6,@Year7,@Year8,@Year9,@Year10,
 @Year11,@Year12,@Year13,@Year14,@Year15,@Year16,@Year17,@Year18,@Year19,@Year20)

/* RENTAL INCOME */
/* PROJECT Rental Income */
select @TumiaRate = 0.0000
if @EscalPeriod > 0 and @EscalRate > 0
begin
   /* Rental Income */
  if @EscalPeriod = 1
      begin
        Select @Year1= @AnnRent
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year2 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year3 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year4 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year6 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year8 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year12 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year14 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year18 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year20 = @AnnRent1
      end
   else if @EscalPeriod = 2
      begin
        Select @Year1= @AnnRent,@Year2 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year3 = @AnnRent1,@Year4 = @Year3
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1,@Year6 = @Year5
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1,@Year8 = @Year7
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1,@Year10 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1,@Year12 = @Year11
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1,@Year14 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1,@Year16 = @Year15
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1,@Year18 = @Year17
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1,@Year20 = @Year19
      end
   else if @EscalPeriod = 3
      begin
        Select @Year1= @AnnRent,@Year2 = @Year1,
        @Year3 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year4 = @AnnRent1,@Year5 = @Year4,
        @Year6 = @Year4
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1,@Year8 = @Year7,
        @Year9 = @Year7 
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1,@Year11 = @Year10,
        @Year12 = @Year10 
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1,@Year14 = @Year13,
        @Year15 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1,@Year17 = @Year16,
        @Year18 = @Year16
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1,@Year20 = @Year19   
      end
   else if @EscalPeriod = 4
      begin
        Select @Year1= @AnnRent ,@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year5 = @AnnRent1,@Year6 = @Year5,
        @Year7 = @Year5,@Year8 = @Year5
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1,@Year10 = @Year9,
        @Year11 = @Year9,@Year12 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1,@Year14 = @Year13,
        @Year15 = @Year13,@Year16 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1,@Year18 = @Year17,
        @Year19 = @Year17,@Year20 = @Year17
      end
   else if @EscalPeriod = 5
      begin
        Select @Year1= @AnnRent,@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year6 = @AnnRent1,@Year7 = @Year6,
        @Year8 = @Year6,@Year9 = @Year6,@Year10 = @Year6
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1,@Year12 = @Year11,
        @Year13 = @Year11,@Year14 = @Year11,@Year15 = @Year11
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year16 = @AnnRent1,@Year17 = @Year16,
        @Year18 = @Year16,@Year19 = @Year16,@Year20 = @Year16
      end
   else if @EscalPeriod = 6
      begin
        Select @Year1= @AnnRent,@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year7 = @AnnRent1,@Year8 = @Year7,
        @Year9= @Year7,@Year10 = @Year7,@Year11 = @Year7,@Year12 = @Year7
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year13 = @AnnRent1,@Year14 = @Year13,
        @Year15= @Year13,@Year16 = @Year13,@Year17 = @Year13,@Year18 = @Year13
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1,@Year20 = @Year19
      end
   else if @EscalPeriod = 7
      begin
        Select @Year1= @AnnRent,@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year8 = @AnnRent1,@Year9 = @Year8,
        @Year10= @Year8,@Year11 = @Year8,@Year12 = @Year8,@Year13 = @Year8,
        @Year14 = @Year8
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year15 = @AnnRent1,@Year16 = @Year15,
        @Year17= @Year15,@Year18 = @Year15,@Year19 = @Year15,@Year20 = @Year15
      end
   else if @EscalPeriod = 8
      begin
        Select @Year1= @AnnRent,@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year9 = @AnnRent1,@Year10 = @Year9,
        @Year11= @Year9,@Year12 = @Year9,@Year13 = @Year9,@Year14 = @Year9,
        @Year15 = @Year9,@Year16 = @Year9
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year17 = @AnnRent1,@Year18 = @Year17,
        @Year19= @Year17,@Year20 = @Year17
      end
   else if @EscalPeriod = 9
      begin
        Select @Year1= @AnnRent,@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1,@Year9= @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year10 = @AnnRent1,@Year11 = @Year10,
        @Year12= @Year10,@Year13 = @Year10,@Year14 = @Year10,@Year15 = @Year10,
        @Year16 = @Year10,@Year17 = @Year10,@Year18 = @Year10
        Select @AnnRent1= @AnnRent1 * (1.0000 + (@EscalRate/100.00000))
        select @Year19 = @AnnRent1,@Year20 = @Year19      end
   else if @EscalPeriod = 10
      begin
        Select @Year1= @AnnRent,@Year2 = @Year1,
        @Year3 = @Year1,@Year4 = @Year1,@Year5 = @Year1,@Year6 = @Year1,
        @Year7 = @Year1,@Year8 = @Year1,@Year9= @Year1,@Year10 = @Year1
        Select @AnnRent1= @AnnRent * (1.0000 + (@EscalRate/100.00000))
        select @Year11 = @AnnRent1,@Year12 = @Year11,
        @Year13= @Year11,@Year14 = @Year11,@Year15 = @Year11,@Year16 = @Year11,
        @Year17 = @Year11,@Year18 = @Year11,@Year19 = @Year11,@Year20 = @Year11
      end
end
else
   begin
       Select @Year1= @AnnRent 
       select @Year2= @Year1,@Year3 = @Year1,@Year3 = @Year1,@Year4 = @Year1,
              @Year5= @Year1,@Year6 = @Year1,@Year7 = @Year1,@Year8 = @Year1,
              @Year9= @Year1,@Year10 = @Year1,@Year11 = @Year1,@Year12 = @Year1,
              @Year13= @Year1,@Year14 = @Year1,@Year15 = @Year1,@Year16 = @Year1,
              @Year17= @Year1,@Year18 = @Year1,@Year19 = @Year1,@Year20 = @Year1
   end

Select @PerfGroup = 2,@RowName = 'Rental Income'
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1,@Year2,@Year3,@Year4,@Year5,@Year6,@Year7,@Year8,@Year9,@Year10,
 @Year11,@Year12,@Year13,@Year14,@Year15,@Year16,@Year17,@Year18,@Year19,@Year20)

/*Total Income */
Select @PerfGroup = 3,@RowName = 'Total Income'
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1,@Year2,@Year3,@Year4,@Year5,@Year6,@Year7,@Year8,@Year9,@Year10,
 @Year11,@Year12,@Year13,@Year14,@Year15,@Year16,@Year17,@Year18,@Year19,@Year20)

Select @PerfGroup = 3,@RowName = 'Operating Costs'
begin
Select @Year1C = Sum(Year1),@Year2c = sum(Year2),@Year3c =sum(Year3),@Year4c=sum(Year4),
       @Year5C = Sum(Year5),@Year6c = sum(Year6),@Year7c =sum(Year7),@Year8c=sum(Year8),
       @Year9C = Sum(Year9),@Year10c = sum(Year10),@Year11c =sum(Year11),
       @Year12c=sum(Year12),
       @Year13C = Sum(Year13),@Year14c = sum(Year14),@Year15c =sum(Year15),
       @Year16c=sum(Year16),@Year17c=sum(Year17),@Year18c=sum(Year18),
       @Year19c=sum(Year19),@Year20c=sum(Year20)
from ##Performance
where PerfGroup = 1

Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1c,@Year2c,@Year3c,@Year4c,@Year5c,@Year6c,
 @Year7c,@Year8c,@Year9c,@Year10c,
 @Year11c,@Year12c,@Year13c,@Year14c,@Year15c,
 @Year16c,@Year17c,@Year18c,@Year19c,@Year20c)
end

Select @PerfGroup = 3,@RowName = 'Depreciation'
begin
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0)
end
Select @PerfGroup = 3,@RowName = 'Income Tax'
begin
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,0,0,0,0,0,0,
 0,0,0,0,0,0,0,0,0,0,0,0,0,0) 
end

Select @PerfGroup = 3,@RowName = 'Net Income'
begin
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1-@Year1c,@Year2-@Year2c,@Year3-@Year3c,@Year4-@Year4c,
 @Year5-@Year5c,@Year6-@Year6c,@Year7-@Year7c,@Year8-@Year8c,@Year9-@Year9c,
 @Year10-@Year10c,@Year11-@Year11c,@Year12-@Year12c,@Year13-@Year13c,
 @Year14-@Year14c,@Year15-@Year15c,@Year16-@Year16c,@Year17-@Year17c,
 @Year18-@Year18c,@Year19-@Year19c,@Year20-@Year20c) 
end

Select @PerfGroup = 4,@RowName = 'Net Inflows'
begin
Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1-@Year1c,@Year2-@Year2c,@Year3-@Year3c,@Year4-@Year4c,
 @Year5-@Year5c,@Year6-@Year6c,@Year7-@Year7c,@Year8-@Year8c,@Year9-@Year9c,
 @Year10-@Year10c,@Year11-@Year11c,@Year12-@Year12c,@Year13-@Year13c,
 @Year14-@Year14c,@Year15-@Year15c,@Year16-@Year16c,@Year17-@Year17c,
 @Year18-@Year18c,@Year19-@Year19c,@Year20-@Year20c) 
end
Select @PerfGroup = 4,@RowName = 'Accumulated Net Inflows'
begin
 
Select @Year1C = Sum(Year1),@Year2c = sum(Year2),@Year3c =sum(Year3),@Year4c=sum(Year4),
       @Year5C = Sum(Year5),@Year6c = sum(Year6),@Year7c =sum(Year7),@Year8c=sum(Year8),
       @Year9C = Sum(Year9),@Year10c = sum(Year10),@Year11c =sum(Year11),
       @Year12c=sum(Year12),
       @Year13C = Sum(Year13),@Year14c = sum(Year14),@Year15c =sum(Year15),
       @Year16c=sum(Year16),@Year17c=sum(Year17),@Year18c=sum(Year18),
       @Year19c=sum(Year19),@Year20c=sum(Year20)
from ##Performance
where PerfGroup = 4

Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,@Year1c,@Year1c +@Year2c,@Year1c +@Year2c+@Year3c,
 @Year1c +@Year2c+@Year3c+ @Year4c, @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c+@Year11c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c + @Year13c,
 @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c + @Year13c+ @Year14c,
  @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c + @Year13c+ @Year14c+@Year15c,
  @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c + @Year13c+ @Year14c+@Year15c+ @Year16c,
  @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c + @Year13c+ @Year14c+@Year15c+ @Year16c+@Year17c,
  @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c + @Year13c+ @Year14c+@Year15c+ @Year16c+@Year17c+@Year18c,
   @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c + @Year13c+ @Year14c+@Year15c+ @Year16c+@Year17c+@Year18c+@Year19c,
  @Year1c +@Year2c+@Year3c+ @Year4c + @Year5c + @Year6c+ @Year7c+@Year8c+@Year9c+@Year10c
 +@Year11c+@Year12c + @Year13c+ @Year14c+@Year15c+ @Year16c+@Year17c+@Year18c+@Year19c+@Year20c)
end

Select @PerfGroup = 5,@RowName = 'ROI'
begin
 
Select @Year1C = Sum(Year1),@Year2c = sum(Year2),@Year3c =sum(Year3),@Year4c=sum(Year4),
       @Year5C = Sum(Year5),@Year6c = sum(Year6),@Year7c =sum(Year7),@Year8c=sum(Year8),
       @Year9C = Sum(Year9),@Year10c = sum(Year10),@Year11c =sum(Year11),
       @Year12c=sum(Year12),
       @Year13C = Sum(Year13),@Year14c = sum(Year14),@Year15c =sum(Year15),
       @Year16c=sum(Year16),@Year17c=sum(Year17),@Year18c=sum(Year18),
       @Year19c=sum(Year19),@Year20c=sum(Year20)
from ##Performance
where PerfGroup = 4 and RowName = 'Net Inflows'

Insert Into ##Performance
(PerfGroup,RowName,Year1,Year2,Year3,Year4,Year5,Year6,Year7,Year8,Year9,Year10,
 Year11,Year12,Year13,Year14,Year15,Year16,Year17,Year18,Year19,Year20)
Values
(@PerfGroup,@RowName,(@Year1c/@Cost)*100.00,(@Year2c/@Cost)*100.000,(@Year3c/@Cost)*100.00,
(@Year4c/@Cost)*100.000,(@Year5c/@Cost)*100.000,
(@Year6c/@Cost)*100.000,(@Year7c/@Cost)*100.00000,(@Year8c/@Cost)*100.000,(@Year9c/@Cost)*100.000,
(@Year10c/@Cost)*100.00000,
 (@Year11c/@Cost)*100.0000,(@Year12c/@Cost)*100.000,(@Year13c/@Cost)*100.000,(@Year14c/@Cost)*100.000,
 (@Year15c/@Cost)*100.000,
 (@Year16c/@Cost)*100.000,(@Year17c/@Cost)*100.000,
(@Year18c/@Cost)*100.000,(@Year19c/@Cost)*100.000,(@Year20c/@Cost)*100.000)
end

Select @Year1C = Sum(Year1),@Year2c = sum(Year2),@Year3c =sum(Year3),@Year4c=sum(Year4),
       @Year5C = Sum(Year5),@Year6c = sum(Year6),@Year7c =sum(Year7),@Year8c=sum(Year8),
       @Year9C = Sum(Year9),@Year10c = sum(Year10),@Year11c =sum(Year11),
       @Year12c=sum(Year12),
       @Year13C = Sum(Year13),@Year14c = sum(Year14),@Year15c =sum(Year15),
       @Year16c=sum(Year16),@Year17c=sum(Year17),@Year18c=sum(Year18),
       @Year19c=sum(Year19),@Year20c=sum(Year20)
from ##Performance
where PerfGroup = 5 

declare @avgRoi float,@PayBack float
select @avgRoi = (@Year1c + @Year2c +@Year3c + @Year4c + @Year5c +@Year6c + @Year7c +@Year8c + @Year9c + @Year10c +
                               @Year11c + @Year12c +@Year13c + @Year14c + @Year15c +@Year16c + @Year17c +@Year18c + @Year19c + @Year20c)/@NumYear

Select @Year1C = Sum(Year1),@Year2c = sum(Year2),@Year3c =sum(Year3),@Year4c=sum(Year4),
       @Year5C = Sum(Year5),@Year6c = sum(Year6),@Year7c =sum(Year7),@Year8c=sum(Year8),
       @Year9C = Sum(Year9),@Year10c = sum(Year10),@Year11c =sum(Year11),
       @Year12c=sum(Year12),
       @Year13C = Sum(Year13),@Year14c = sum(Year14),@Year15c =sum(Year15),
       @Year16c=sum(Year16),@Year17c=sum(Year17),@Year18c=sum(Year18),
       @Year19c=sum(Year19),@Year20c=sum(Year20)
from ##Performance
where PerfGroup = 4 and RowName = 'Net Inflows'

select @roRet= 1.000 + (@roRet/100.00000)

select @npv = @Year1c/power(@roRet,1) + @Year2c/Power(@RoRet,2) + @Year3c/power(@roRet,3) + @Year4c/Power(@RoRet,4)
                        + @Year5c/power(@roRet,5) + @Year6c/Power(@RoRet,6) + @Year7c/power(@roRet,7) + @Year8c/Power(@RoRet,8)
                        + @Year9c/power(@roRet,9) + @Year10c/Power(@RoRet,10) + @Year11c/power(@roRet,11) + @Year12c/Power(@RoRet,12)
                        + @Year13c/power(@roRet,13) + @Year14c/Power(@RoRet,14) + @Year15c/power(@roRet,15) + @Year16c/Power(@RoRet,16)
                        + @Year17c/power(@roRet,17) + @Year18c/Power(@RoRet,18) + @Year19c/power(@roRet,19) + @Year20c/Power(@RoRet,20)

select @irr = @Cost/(@Year1c + @Year2c + @Year3c + @Year4c + @Year5c  + @Year6c + @Year7c + @Year8c + @Year9c + @Year10c +
 @Year11c + @Year12c + @Year13c + @Year14c + @Year15c  + @Year16c + @Year17c + @Year18c + @Year19c + @Year20c )


update ##Performance set MaintRate= @MaintRate,InsureRate = @InsureRate,ManageRate= @ManageRate,
   Cost = @Cost,avgROI = @AvgROI,npv = @npv,irr = @irr,PropName = @Property
   
select * from ##Performance


go

