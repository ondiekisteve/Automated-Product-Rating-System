/*
Modifications : Feb 23,2004

Calculation of VAT
Added Parameters : @DeductVAT,@VAT

Added Code :
if @DeductVAT = 1
   begin
       Exec CalculateVAT @InvoiceDate,@Amount,@vat out
   end
else
  select @vat = 0
*/
CREATE TRIGGER [dbo].[AuditfeesInvoice] on [dbo].[FeesInvoice]
--with Encryption
for insert
as

 declare @SchemeNo varchar(15), @FeesCode int,@primarykey varchar(50),
@InvoiceDate datetime,@PayCode Int,@TaxCode Int,@Amount float,@WithholdingTax float, @DeductWith bit,@DeductVAT bit,@vat float,
@VatMode Bit

Select @FeesCode = FeesCode,@SchemeNo = schemeNo,@InvoiceDate = InvoiceDate, @PayCode = PayCode,
           @TaxCode = TaxCode,@Amount = Amount,@DeductWith  = DeductWithholding,@DeductVat = DeductVat,@VatMode = VatMode
from Inserted

Select @Primarykey = @SchemeNo +' - '+cast(@feesCode as varchar(15)) +' - '+cast(@InvoiceDate as varchar(20)) +' - '+cast(@PayCode as varchar(20))
 
Insert Into Audit_Table
(TableName,UserName,TransDate,TransType,PrimaryKey)
Values
('Fees Invoice',user,getDate(),'INSERT', @primaryKey)
go

