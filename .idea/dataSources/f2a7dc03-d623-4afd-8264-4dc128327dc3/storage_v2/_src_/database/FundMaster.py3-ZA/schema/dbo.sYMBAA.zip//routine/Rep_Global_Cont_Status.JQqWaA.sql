CREATE PROCEDURE [dbo].[Rep_Global_Cont_Status]               
@AsAtDate Datetime,
@RepMode Int             
as              
        
IF EXISTS (SELECT name FROM sysindexes                   
      WHERE name = 'ContStat')                  
   DROP INDEX #Global_Cont_Status.ContStat              
                     
if object_id('tempdb..#Global_Cont_Status') is null              
              
begin              
create table #Global_Cont_Status              
(              
        [glcode] [int] IDENTITY(1,1) NOT NULL Primary Key ,              
        [SchemeNo] INT,              
        [SchemeName] [varchar](100) NOT NULL ,              
        [LastPeriod] [Varchar](40),              
        [BatchDate][Datetime],              
        [MonthsOut][Int],              
        [AsAtDate][Datetime],              
        [InvestSeparate][Int],              
        [RelSchemeNo][varchar](20),            
        [MonthName][varchar](30),            
        [Contribution][float], 
        [BatchTotal][float],
        [Diff][float],
        [ReceiptNo][varchar](50), 
        [DatePosted][datetime],          
        [SchemeMode][varchar](50)              
                      
)               
              
end           
          
CREATE INDEX ContStat                  
   ON #Global_Cont_Status (SchemeNo, SchemeName, glcode)                
              
Declare @SCHEMENO Int,@schemeName Varchar(100),@DatePaid Datetime,@BatchMonth Int,@BatchYear Int,              
@LastPeriod Varchar(40),@mwishoDate Datetime,@MonthsOut Int,              
@RelSchemeNo varchar(15),@InvestSeparate int,@BatchDate Datetime,@ContributionMode int,              
@EndDate Datetime,@MonthName varchar(30),@Contribution float,@SponsorCode Int  

Select @BatchMonth = datepart(Month,@AsAtDate),@BatchYear = datepart(Year,@AsAtDate)

Exec GetMonthName @BatchMonth,@LastPeriod Out              
              
select @LastPeriod = @LastPeriod+', '+cast(@BatchYear as Varchar(4))             

if @RepMode = 0
begin              
declare acsr Cursor for              
Select SchemeCode,SchemeName,RelSchemeNo,InvestSeparate,              
ContributionMode from Scheme              
WHERE SchemeName not like '%EST' and StatusCode = 1             
and SchemeMode = 0 and BasisCode = 0 and ActiveStatus = 1            
order  by SchemeCode              
              
Open acsr              
Fetch from acsr into @schemeNo,@SchemeName,@RelSchemeNo,@InvestSeparate,@ContributionMode              
while @@fetch_Status = 0              
begin              
   select @BatchYear = max(BatchYear) from Batches where schemeNo = @schemeNo  
     
   if @BatchYear is not null   
       select @BatchMonth = Max(BatchMonth) from Batches where schemeNo = @schemeNo and BatchYear = @BatchYear  
   else  
       select @BatchYear = 0,@BatchMonth = 0                
              
   if ((@BatchYear > 0) and (@BatchMonth > 0))             
      begin  
        select @DatePaid = max(batchDate)             
        from Batches where schemeNo = @schemeNo and BatchMonth = @BatchMonth and BatchYear = @BatchYear  
               
        select @Contribution = sum(ChequeAmount)             
        from Batches where schemeNo = @schemeNo and BatchMonth = @BatchMonth and BatchYear = @BatchYear             
            
        select @MonthName = MonthName+', '+cast(@BatchYear as varchar(4)) from MonthTable            
        where MonthNumber = @BatchMonth              
              
                      
        if @ContributionMode = 4              
           begin              
           select @EndDate = EndDate from schemeYears where schemeNo = @schemeNo and StartDate <= @DatePaid              
           and EndDate >= @DatePaid              
              
           select @DatePaid = @EndDate              
              
           select @BatchMonth = DatePart(Month,@DatePaid),@BatchYear = DatePart(Year,@DatePaid)              
                        
           end              
              
        Exec GetLastDate @BatchMonth,@BatchYear,@mwishoDate Out              
              
              
        Exec GetMonthName @BatchMonth,@LastPeriod Out              
              
        select @LastPeriod = @LastPeriod+', '+cast(@BatchYear as Varchar(4))              
              
        select @MonthsOut = (DateDiff(Month,@MwishoDate,@AsAtDate)) - 1              
              
        if @MonthsOut < 0              
       select @MonthsOut = 0              
              
        Insert Into #Global_Cont_Status(schemeName,LastPeriod,SchemeNo,BatchDate,MonthsOut,AsAtDate,InvestSeparate,              
                                        RelSchemeNo,MonthName,Contribution,SchemeMode)              
                           Values(@schemeName,@LastPeriod,@schemeNo,@DatePaid,@MonthsOut,@AsAtDate,@InvestSeparate,              
                                        @RelSchemeNo,@MonthName,@Contribution,'GROUP SCHEMES')              
        end              
    else              
       Insert Into #Global_Cont_Status(schemeName,LastPeriod,SchemeNo,BatchDate,MonthsOut,AsAtDate,InvestSeparate,              
                                        RelSchemeNo,MonthName,Contribution,SchemeMode)              
                           Values(@schemeName,'Never Posted',@schemeNo,' ',0,@AsAtDate,@InvestSeparate,              
        @RelSchemeNo,'',0,'GROUP SCHEMES')              
              
   select @schemeNo = '',@schemeName = '',@BatchMonth = 0,@BatchYear=0,@MonthsOut=0,@InvestSeparate=0,              
                                     @RelSchemeNo ='',@ContributionMode = 0,@Contribution = 0,@MonthName = ''              
   Fetch next from acsr into @schemeNo,@SchemeName,@RelSchemeNo,@InvestSeparate,@ContributionMode              
end              
Close Acsr              
Deallocate Acsr              
             
/* Umbrella */            
            
declare acsr Cursor for              
Select s.SchemeCode,sp.SponsorCode,sp.SponsorName,s.RelSchemeNo,s.InvestSeparate,              
s.ContributionMode from Scheme s            
  inner Join Sponsor sp on s.schemeCode = sp.SchemeNo             
WHERE s.SchemeName not like '%EST' and s.StatusCode = 1             
and s.SchemeMode = 1 and BasisCode = 0 and ActiveStatus = 1           
order  by SchemeCode              
              
Open acsr              
Fetch from acsr into @schemeNo,@SponsorCode,@SchemeName,@RelSchemeNo,@InvestSeparate,@ContributionMode              
while @@fetch_Status = 0              
begin              
   select @DatePaid = Max(BatchDate) from Batches where schemeNo = @schemeNo            
   and SponsorCode = @SponsorCode               
              
   if @DatePaid is not null              
      begin              
        select @BatchMonth = BatchMonth,@BatchYear = BatchYear,@Contribution = ChequeAmount              
        from Batches where schemeNo = @schemeNo and BatchDate = @DatePaid             
        and SponsorCode = @SponsorCode             
            
        select @MonthName = MonthName+', '+cast(@BatchYear as varchar(4)) from MonthTable            
        where MonthNumber = @BatchMonth              
              
                      
        if @ContributionMode = 4              
           begin              
           select @EndDate = EndDate from schemeYears where schemeNo = @schemeNo and StartDate <= @DatePaid              
           and EndDate >= @DatePaid              
              
           select @DatePaid = @EndDate              
              
           select @BatchMonth = DatePart(Month,@DatePaid),@BatchYear = DatePart(Year,@DatePaid)              
                        
           end              
              
        Exec GetLastDate @BatchMonth,@BatchYear,@mwishoDate Out              
              
              
        Exec GetMonthName @BatchMonth,@LastPeriod Out              
              
        select @LastPeriod = @LastPeriod+', '+cast(@BatchYear as Varchar(4))              
              
        select @MonthsOut = (DateDiff(Month,@MwishoDate,@AsAtDate)) - 1              
              
        if @MonthsOut < 0              
           select @MonthsOut = 0              
              
        Insert Into #Global_Cont_Status(schemeName,LastPeriod,SchemeNo,BatchDate,MonthsOut,AsAtDate,InvestSeparate,              
                                        RelSchemeNo,MonthName,Contribution,SchemeMode)              
                           Values(@schemeName,@LastPeriod,@schemeNo,@DatePaid,@MonthsOut,@AsAtDate,@InvestSeparate,              
                                        @RelSchemeNo,@MonthName,@Contribution,'UMBRELLA SCHEMES')              
        end              
    else              
       Insert Into #Global_Cont_Status(schemeName,LastPeriod,SchemeNo,BatchDate,MonthsOut,AsAtDate,InvestSeparate,              
                                        RelSchemeNo,MonthName,Contribution,SchemeMode)              
                           Values(@schemeName,'Never Posted',@schemeNo,' ',0,@AsAtDate,@InvestSeparate,              
                                        @RelSchemeNo,'',0,'UMBRELLA SCHEMES')             
              
   select @schemeNo = '',@schemeName = '',@BatchMonth = 0,@BatchYear=0,@MonthsOut=0,@InvestSeparate=0,              
                                        @RelSchemeNo ='',@ContributionMode = 0,@Contribution = 0,@MonthName = '',            
          @SponsorCode = 0              
   Fetch next from acsr into @schemeNo,@SponsorCode,@SchemeName,@RelSchemeNo,@InvestSeparate,@ContributionMode              
end              
Close Acsr              
Deallocate Acsr              
            
/* End Umbrella */            
              
Declare RelCsr Cursor for              
select RelSchemeNo,LastPeriod,BatchDate,MonthsOut              
       from #Global_Cont_Status               
       where InvestSeparate = 1              
Open RelCsr              
Fetch from RelCsr into @RelSchemeNo,@LastPeriod,@BatchDate,@MonthsOut              
while @@fetch_Status = 0              
begin              
   update #Global_Cont_Status set LastPeriod = @LastPeriod,BatchDate = @BatchDate,MonthsOut = @MonthsOut              
   where schemeNo = @RelSchemeNo              
              
   select @RelSchemeNo ='',@MonthsOut = 0              
              
   Fetch next from RelCsr into @RelSchemeNo,@LastPeriod,@BatchDate,@MonthsOut              
end              
Close RelCsr              
Deallocate RelCsr  
end
else
   Insert Into #Global_Cont_Status(schemeName,LastPeriod,SchemeNo,BatchDate,MonthsOut,AsAtDate,InvestSeparate,              
                                        RelSchemeNo,MonthName,Contribution,BatchTotal, Diff, ReceiptNo,DatePosted,SchemeMode)              
                           
                           select s.SchemeName,@LastPeriod,b.SchemeNo,b.BatchDate,0,@AsAtDate,0,b.SchemeNo,@LastPeriod,b.ChequeAmount,b.BatchTotal,
                           b.BatchTotal - b.ChequeAmount,b.ReceiptNo,b.DatePrepared,'GROUP SCHEMES'
                           from Batches b
                                inner join Scheme s on b.schemeNo = s.schemeCode 
                           where b.BatchMonth = @BatchMonth and b.BatchYear = @BatchYear order by s.SchemeName  
          
select * from #Global_Cont_Status order by SchemeMode,SchemeName
go

