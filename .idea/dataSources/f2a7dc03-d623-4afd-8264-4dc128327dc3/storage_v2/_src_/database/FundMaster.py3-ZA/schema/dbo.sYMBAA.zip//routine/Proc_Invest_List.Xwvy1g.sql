CREATE PROCEDURE [dbo].[Proc_Invest_List]    
@schemeNo int,    
@SecurityNo int   
--with Encryption    
as    
    
set nocount on    
    
if object_id('tempdb..#InvestList') is null    
    
begin    
create table #InvestList    
(    
 [InvCode][Int]primary key,    
 [InvestName] [varchar](100),    
)    
end    
    
declare @InvestCode int   
    
select @InvestCode = InvestCode from Investments where schemeNo = @schemeNo and invCode = @SecurityNo    
    
insert into #InvestList select InvCode,InvName from Investments 
where schemeNo = @schemeNo and InvestCode = @InvestCode

select * from #InvestList order by InvestName
go

