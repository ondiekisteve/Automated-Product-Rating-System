CREATE PROCEDURE [dbo].[Proc_Clean_Benefits]            
@SCHEMENO Int            
--with Encryption            
as   
  
set nocount on         
          
update Benefits set ActiveStatus = 0, IncludeRec = 0,EmpTransfer = 0,EmprTransfer = 0,      
       EmpCont = 0,EmprCont = 0,SpecialContr = 0,VolContr = 0,PreEmpCont = 0,      
       PreEmprCont = 0,PreAvc=0, DeferredAmt = 0      
where schemeNo = @schemeNo      
            
update UnRegisteredBenefits set ActiveStatus = 0, IncludeRec = 0,ExcessEmpCont = 0,ExcessEmprCont = 0,      
       ExcessVolContr = 0,ExcessSpecial = 0,DeferredAmt = 0       
where schemeNo = @schemeNo
go

