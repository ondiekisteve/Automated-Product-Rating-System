CREATE Procedure Rep_BTF_Payments      
@schemeNo Int,      
@StartDate datetime,      
@EndDate datetime      
--with Encryption      
as      
      
select p.SchemeNo,p.MemberNo, p.DependantCode,p.Amount,p.DatePaid,      
p.BeinPayment as Particulars,p.Payee, p.ChequeNo,d.sname+', '+d.fname+' '+oname as fullname,@StartDate AS StartDate, @EndDate as EndDate         
from DependantPaymentDet  p        
     inner join Dependants d on p.SchemeNo = d.SchemeNo  and p.MemberNo = d.MemberNo         
     and p.DependantCode = d.DependantCode and d.PayLumpInBTF = 1        
where p.DatePaid >= @StartDate  and p.DatePaid <= @EndDate and p.Amount > 0
go

