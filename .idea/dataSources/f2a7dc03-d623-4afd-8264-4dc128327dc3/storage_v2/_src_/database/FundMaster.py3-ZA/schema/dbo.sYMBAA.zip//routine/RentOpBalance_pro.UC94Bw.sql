CREATE PROCEDURE [dbo].[RentOpBalance_pro]
@SCHEMENO Int,
@PropCode Int,
@PayMonth Int,
@PayYear Int,
@sponsorcode  varchar(25),
@RentBalance float Out
as
declare @Amount float,@MaxYear Int,@MaxMonth Int,@ReceiptNo varchar(20),
@MaxrYear Int,@MaxrMonth Int,@LastAmount float,@RentPayable float,@PayDate datetime,
@Counter Int,@Mwisho Int,@PaymentFreq Int,@AiDate Datetime,@MinDate Datetime,
@RentPreBalance float,@PrePayment float,@LastDate Datetime,@Invoiced float,
@AcctPeriod Int,@SchemeMode Int

select @schemeMode = schemeMode from scheme where schemeCode = @schemeNo

if @schemeMode is null select @schemeMode = 0

Exec GetAccountingPeriodInaYear @schemeNo,@PayMonth,@PayYear,@AcctPeriod Out

if @PayMonth = 1
   select @PayMonth = 12,@PayYear = @PayYear - 1
else
   select @PayMonth = @PayMonth - 1

Exec GetLastDate @PayMonth,@PayYear,@LastDate Out

if @schemeMode = 1
begin
select @RentPreBalance = SUM(Balance),@PrePayment  = SUM(PrePayment)
from RentPreBalance where SchemeNo = @schemeNo
and PropertyCode = @PropCode
and AcctPeriod = @AcctPeriod - 1
and sponsorcode=@sponsorcode

if @RentPreBalance is null select @RentPreBalance = 0
if @PrePayment is null select @PrePayment = 0.0


select @Amount = sum(amount + ServiceCharge + Parking + Other) from RentReceipts where SchemeNo = @schemeNo
and PropertyCode = @PropCode
and PayDate <=  @LastDate and AcctPeriod = @AcctPeriod
and sponsorcode=@sponsorcode

if @Amount is null select @Amount = 0

select @Invoiced = sum(Rent + ServiceCharge + Parking) from RentInvoice where SchemeNo = @schemeNo
and PropertyCode = @PropCode and sponsorcode=@sponsorcode
and InvoiceDate < @LastDate and AcctPeriod = @AcctPeriod
end
else
begin
select @RentPreBalance = SUM(Balance),@PrePayment  = SUM(PrePayment)
from RentPreBalance where SchemeNo = @schemeNo
and PropertyCode = @PropCode
and AcctPeriod = @AcctPeriod - 1

if @RentPreBalance is null select @RentPreBalance = 0
if @PrePayment is null select @PrePayment = 0.0


select @Amount = sum(amount + ServiceCharge + Parking + Other) from RentReceipts where SchemeNo = @schemeNo
and PropertyCode = @PropCode
and PayDate <=  @LastDate and AcctPeriod = @AcctPeriod


if @Amount is null select @Amount = 0

select @Invoiced = sum(Rent + ServiceCharge + Parking) from RentInvoice where SchemeNo = @schemeNo
and PropertyCode = @PropCode
and InvoiceDate < @LastDate and AcctPeriod = @AcctPeriod
end


if @Invoiced is null select @Invoiced = 0

select @RentBalance = (@PrePayment + @Amount) - (@RentPreBalance + @Invoiced)

select @RentBalance = 0 - @RentBalance
go

