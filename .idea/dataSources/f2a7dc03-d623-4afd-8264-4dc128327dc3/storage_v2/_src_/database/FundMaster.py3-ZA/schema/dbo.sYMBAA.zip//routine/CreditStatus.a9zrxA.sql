CREATE PROCEDURE [dbo].[CreditStatus]
@SchemeNo varchar(15),
@BankCode varchar(15),
@sDate Datetime,
@eDate Datetime,
@Status int
--with Encryption
as

if @status = 0
     select s.SchemeName, b.BankName, c.TransDate,c.VoucherNo,c.ChequeNo,c.Description,c.Credit
     from cashBook c
     inner Join Scheme s on c.schemeNo = s.schemeCode 
     inner join SchemeBankBranch b on c.schemeNo = b.schemeNo and c.BankCode = b.BankCode
     where c.schemeNo = @SchemeNo and c.BankCode = @BankCode and c.TransDate >= @sDate
     and c.TransDate <= @eDate and c.Credit > 0 and (Len(lTrim(c.ChequeNo)) = 0 or (c.ChequeNo is null))
     order by c.TransDate
else
    select s.SchemeName, b.BankName, c.TransDate,c.VoucherNo,c.ChequeNo,c.Description,c.Credit
    from cashBook c
         inner Join Scheme s on c.schemeNo = s.schemeCode 
         inner join SchemeBankBranch b on c.schemeNo = b.schemeNo and c.BankCode = b.BankCode
    where c.schemeNo = @SchemeNo and c.BankCode = @BankCode and c.TransDate >= @sDate
     and c.TransDate <= @eDate and c.Credit > 0 and Len(lTrim(c.ChequeNo)) > 0
    order by c.ChequeNo
go

