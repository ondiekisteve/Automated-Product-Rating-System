CREATE FUNCTION [dbo].[fn_RoundingYaFundMasterTax](@SCHEMENO bigInt,@MonPension varchar(25))
returns Decimal(20,6)
as
begin
declare @a bigInt,@b bigInt,@MemberNo bigInt,@c Varchar(2),
@Yakwanza Varchar(1),@YaPili Varchar(1),@WholePart bigInt,@DecPart Varchar(2),
@newpension Decimal(20,6),@Rounder bigInt,@Rounded float,
@newPensionUp Decimal(20,3)

select @Rounder = RounderTax  from scheme where schemeCode = @schemeNo

if @Rounder is null select @Rounder = 0

if @Rounder = 0 /* Rounding not Defined */
   begin
   select @newpension = cast(@MonPension as float)
   select @newpension = round(@newpension,2)
   end
else if @Rounder = 1 /* Nearest shilling */
   begin
   select @newpension = cast(@MonPension as float)
   select @newpension = round(@newpension,0)
   end
else if @Rounder = 2 /* nearest 10 cents */
   begin
      if patIndex('%.%',@MonPension) > 0
      begin
         select @WholePart = Left(@MonPension,patIndex('%.%',@MonPension) - 1)

         select @a = len(@MonPension) - patIndex('%.%',@MonPension)

         select @c = left(right(@MonPension,@a),2)

         if @c is null select @c ='00'
           else if len(@c) = 1
         select @c = @c+'0'

        
         select @Yakwanza= left(@c,1),@YaPili = right(@c,1)
   
         
         if ((@Yakwanza = 9) and (@Yapili >= 5))
            begin
               select @wholePart  = @wholePart + 1
               Select @newpension = cast(@wholePart as float),@Yakwanza ='0',@Yapili = '0'
            end
         else
            begin
                 if @Yapili >= 5
                    select @Yakwanza = @Yakwanza + 1,@Yapili = 0
                 else if @Yapili < 5
                    select @Yakwanza = @Yakwanza,@Yapili = 0
            end
       select @DecPart = @Yakwanza + @Yapili

      if @Decpart <> '00'
         select @newpension = cast(@wholePart as float) + cast(@Decpart as float)/100.0000
      else if ((@Yakwanza = 0) and (@Yapili = 0))
            select @newPension = cast(@wholePart as float)
   end
   else
       Select @DecPart = '0.0',@wholepart = @MonPension,@newpension = cast(@MonPension as float)
   end
else if @Rounder = 3 /* Nearest five cents */
   begin
     if not patIndex('%.%',@MonPension) > 0
         begin
            Select @newPension = cast(@MonPension as Decimal(20,6))
         end
     else 
         begin
              select @WholePart = Left(@MonPension,patIndex('%.%',@MonPension) - 1)

              select @a = len(@MonPension) - patIndex('%.%',@MonPension)

              select @c = left(right(@MonPension,@a),2)

              if @c is null 
                 select @c ='00'
              else if len(@c) = 1
                 select @c = @c+'0'

              select @Yakwanza= left(@c,1),@YaPili = right(@c,1)
         
             if ((@Yakwanza = 9) and (@Yapili >= 8))
                begin
                     select @wholePart  = @wholePart + 1
                     Select @newpension = cast(@wholePart as float),@Yakwanza ='0',@Yapili = '0'
                end
             else if (@Yakwanza = 0)
                begin
                    if cast(@Yapili as bigInt) < 3
                       select @Yapili = 0
                    else if cast(@Yapili as bigInt) >= 3 and cast(@Yapili as bigInt) < 8
                       select @Yapili = 5
                    else if cast(@Yapili as bigInt) >= 8
                       select @Yakwanza = @Yakwanza + 1,@Yapili = 0
                end
             else
                begin
                    if cast(@Yapili as bigInt) < 3
                       select @Yapili = 0
                    else if cast(@Yapili as bigInt) >= 3 and cast(@Yapili as bigInt) < 8
                       select @Yapili = 5
                    else if cast(@Yapili as bigInt) >= 8
                       select @Yakwanza = @Yakwanza + 1,@Yapili = 0
                end

           select @DecPart = @Yakwanza + @Yapili

         if cast(@Decpart as bigInt) >  0
   select @newPension = cast(@wholePart as float) + cast(@Decpart as float)/100.0000 
         else if ((@Yakwanza = 0) and (@Yapili = 0))
            select @newPension = cast(@wholePart as float)
      end
 end
else if @Rounder = 4 /* Floor to the Nearest shilling */
   begin
   select @newpension = cast(@MonPension as float)
   
   select @rounded = round(@newpension,0)

   if @newpension > @rounded
      select @newpension = @rounded + 1
   else
      select @newpension = @rounded

   end
else if @Rounder = 5 /* Round up to the Nearest five cents */
   begin
     if not patIndex('%.%',@MonPension) > 0
         begin
            Select @newPension = cast(@MonPension as Decimal(20,6))
         end
     else 
         begin
              select @WholePart = Left(@MonPension,patIndex('%.%',@MonPension) - 1)

              select @a = len(@MonPension) - patIndex('%.%',@MonPension)

              select @c = left(right(@MonPension,@a),2)

              if @c is null 
                 select @c ='00'
              else if len(@c) = 1
                 select @c = @c+'0'

              select @Yakwanza= left(@c,1),@YaPili = right(@c,1)
         
             if ((@Yakwanza = 9) and (@Yapili >= 8))
                begin
                     select @wholePart  = @wholePart + 1
                     Select @newpension = cast(@wholePart as float),@Yakwanza ='0',@Yapili = '0'
                end
             else if (@Yakwanza = 0)
                begin
                    if cast(@Yapili as bigInt) < 3
                       select @Yapili = 0
                    else if cast(@Yapili as bigInt) >= 3 and cast(@Yapili as bigInt) < 8
                       select @Yapili = 5
                    else if cast(@Yapili as bigInt) >= 8
                       select @Yakwanza = @Yakwanza + 1,@Yapili = 0
                end
             else
                begin
                    if cast(@Yapili as bigInt) < 3
                       select @Yapili = 0
                    else if cast(@Yapili as bigInt) >= 3 and cast(@Yapili as bigInt) < 8
                       select @Yapili = 5
                    else if cast(@Yapili as bigInt) >= 8
                       select @Yakwanza = @Yakwanza + 1,@Yapili = 0
                end

           select @DecPart = @Yakwanza + @Yapili

         if cast(@Decpart as bigInt) >  0
   select @newPension = cast(@wholePart as float) + cast(@Decpart as float)/100.0000 
         else if ((@Yakwanza = 0) and (@Yapili = 0))
            select @newPension = cast(@wholePart as float)
      end
 end

 RETURN(@NewPension)
end
go

