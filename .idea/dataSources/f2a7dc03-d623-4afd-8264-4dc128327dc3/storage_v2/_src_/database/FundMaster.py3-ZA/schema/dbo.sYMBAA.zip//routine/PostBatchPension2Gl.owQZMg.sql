CREATE PROCEDURE [dbo].[PostBatchPension2Gl]        
@SCHEMENO Int,        
@TransDate datetime,  
@CurrCode Int        
as        
        
declare @DebitAcc Varchar(20),@CreditAcc Varchar(20),@InvoiceNo Int,@paymonth int,@payYear int,@transMode Int,       
@Description Varchar(100),@Rent float,@MonthName Varchar(30),@LastDate Datetime,@MaxTransNo Int,@BatchNo Int,  
@SpotRate float  
  
select @SpotRate = 1.0000        
  
select @Paymonth = datepart(month,@transdate),@payYear = datepart(year,@transdate)  
select @transMode = 1  
       
Exec GetMaxGLJvTransNo_Out @SchemeNo,0,@MaxTransNo Out    
    
select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeNo    
    
if @BatchNo is null select @BatchNo = 0    
select @BatchNo = @BatchNo + 1        
        
  
declare PostCsr cursor for        
select R.LPONo,R.PayDate,R.Description,sum(Rc.UnitPrice * rc.Quantity),R.DebitAcc,R.CreditAcc        
from Payables R         
     inner Join PayablesInvoice rc on r.SchemeNo = rc.schemeNo and r.lpoNo = rc.lpoNo        
     inner Join CreditorsRegister c on r.schemeNo = c.schemeNo and r.CreditorCode = c.DebtorCode        
     and c.DebtorType = 9        
where R.SchemeNo = @schemeNo and R.PayDate = @TransDate AND R.Posted = 0  
and r.VoucherType = 24        
group by R.LPONo,R.PayDate,R.Description,R.DebitAcc,R.CreditAcc        
        
open PostCsr        
fetch from PostCsr into @InvoiceNo,@TransDate,@Description,@Rent,@DebitAcc,@CreditAcc        
while @@fetch_Status = 0        
begin        
    IF @CreditAcc IS NOT NULL        
       BEGIN                                              
         Exec PostLedgerDebits_RecPay @SchemeNo,@DebitAcc,@InvoiceNo,@Rent,@PayMonth,@PayYear,        
         @Description,@TransMode,@TransDate,@MaxTransNo,@BatchNo,@CurrCode,@SpotRate        
        
        
         Exec PostLedgerCredits_RecPay @SchemeNo,@CreditAcc,@InvoiceNo,@Rent,@PayMonth,@PayYear,        
         @Description,@TransMode,@TransDate,@MaxTransNo,@BatchNo,@CurrCode,@SpotRate        
        
         update Payables Set Posted = 1        
         where SchemeNo = @SchemeNo and LPONo = @InvoiceNo        
       END        
            
   select @InvoiceNo = 0,@Description ='',@Rent = 0.0,@DebitAcc=' ',@CreditAcc= ' ',@MaxTransNo = @MaxTransNo + 1        
        
   fetch next from PostCsr into @InvoiceNo,@TransDate,@Description,@Rent,@DebitAcc,@CreditAcc        
end        
Close PostCsr        
Deallocate PostCsr
go

