CREATE PROCEDURE [dbo].[Proc_Unitization_Cash]
@schemeNo Int,
@TransDate datetime
--with Encryption
as

select u.Unit_Desc,t.TransNo,t.Particulars,sum(td.Credit + td.Debit) as Amount,T.TransSourceCat,case t.TransSourceCat when 0 then 'RECEIPTS'
                                                                               when 1 then 'PAYMENTS'
                                                         end as RecPay,@TransDate as TransDate                                     
from TBL_Unitization t   
     inner join Unit_Trusts_Type u on t.InvestCode = u.InvestCode and t.SchemeNo = u.SchemeNo  
     inner join tbl_Unitization_det td on t.schemeNo = td.schemeNo and t.TransNo = td.TransNo and td.CashTrans = 1   
     and td.AccountCode  in (select AccountCode from SchemeBankBranch where SchemeNo = @schemeNo)                                   
where t.TransSource = 0 and t.TransDate = @TransDate and t.SchemeNo = @schemeNo 
Group By u.Unit_Desc,t.TransNo,t.Particulars,T.TransSourceCat,t.TransSourceCat
order by u.Unit_Desc,t.TransSourceCat,t.TransNo
go

