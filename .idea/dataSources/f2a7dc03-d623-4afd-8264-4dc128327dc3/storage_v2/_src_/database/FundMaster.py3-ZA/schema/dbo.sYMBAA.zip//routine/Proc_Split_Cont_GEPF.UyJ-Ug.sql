CREATE PROCEDURE [dbo].[Proc_Split_Cont_GEPF]
@SCHEMENO Int,
@MemberNo Int,
@DoExit Datetime
--with Encryption 
as
declare @ContrMonth Int,@ContrYear Int,@ContrDay Int,@DaysInMonth Int,
@EmpCont float,@EmprCont float,@VolCont float,@SpecCont float,@Gepf smallInt

select @Gepf = Gepf from scheme where SchemeCode = @schemeNo

if @Gepf is null select @Gepf = 0

if @Gepf = 1
begin
Select @ContrMonth = DatePart(Month,@DoExit),@ContrYear = DatePart(Year,@DoExit),
@ContrDay = DatePart(Day,@DoExit)

Exec GetDaysInMonth @ContrMonth,@DaysInMonth Out

select @EmpCont  = EmpCont,@EmprCont  = EmprCont,@VolCont = VolContr,@SpecCont = SpecialContr
from Contributionssummary where schemeNo = @schemeNo and MemberNo = @MemberNo
and ContrMonth = @ContrMonth and ContrYear = @ContrYear

if @EmpCont is null select @EmpCont = 0.0
if @EmprCont is null select @EmprCont = 0.0
if @VolCont is null select @VolCont = 0.0
if @SpecCont is null select @SpecCont = 0.0

if (@EmpCont + @EmprCont + @VolCont + @SpecCont) > 0
   begin
       if @DaysInMonth > @ContrDay
          begin
              if @EmpCont > 0
                 begin
                    update Contributionssummary set EmpCont = EmpCont * (cast(@ContrDay as float)/cast(@DaysInMonth as float)),
                                                    ExcessEmpCont = EmpCont * (cast((@DaysInMonth - @ContrDay) as float)/cast(@DaysInMonth as float))
                                                    where schemeNo = @schemeNo and MemberNo = @MemberNo
                                                    and ContrMonth = @ContrMonth and ContrYear = @ContrYear
                 end
              if @EmprCont > 0
                 begin
                    update Contributionssummary set EmprCont = EmprCont * (cast(@ContrDay as float)/cast(@DaysInMonth as float)),
                                                    ExcessEmprCont = EmprCont * (cast((@DaysInMonth - @ContrDay) as float)/cast(@DaysInMonth as float))
                                                    where schemeNo = @schemeNo and MemberNo = @MemberNo
                                                    and ContrMonth = @ContrMonth and ContrYear = @ContrYear
                 end
             if @VolCont > 0
                 begin
                    update Contributionssummary set VolContr = VolContr * (cast(@ContrDay as float)/cast(@DaysInMonth as float)),
                                                    ExcessVolContr = VolContr * (cast((@DaysInMonth - @ContrDay) as float)/cast(@DaysInMonth as float))
                                                    where schemeNo = @schemeNo and MemberNo = @MemberNo
                                                    and ContrMonth = @ContrMonth and ContrYear = @ContrYear
                 end
              if @SpecCont > 0
                 begin
                    update Contributionssummary set SpecialContr = SpecialContr * (cast(@ContrDay as float)/cast(@DaysInMonth as float)),
                                                    ExcessSpecial = SpecialContr * (cast((@DaysInMonth - @ContrDay) as float)/cast(@DaysInMonth as float))
                                                    where schemeNo = @schemeNo and MemberNo = @MemberNo
                                                    and ContrMonth = @ContrMonth and ContrYear = @ContrYear
                 end
          end
   end

   if Exists (Select * from Contributionssummary where schemeNo = @schemeNo and MemberNo = @MemberNo and
   DatePaid > @DoExit)
       begin
          update Contributionssummary set Surplus = 1 where schemeNo = @schemeNo and MemberNo = @MemberNo and
          DatePaid > @DoExit

          update Members set Has_Surplus_Cont = 1 where schemeNo = @schemeNo and MemberNo = @MemberNo 
      end
end
go

