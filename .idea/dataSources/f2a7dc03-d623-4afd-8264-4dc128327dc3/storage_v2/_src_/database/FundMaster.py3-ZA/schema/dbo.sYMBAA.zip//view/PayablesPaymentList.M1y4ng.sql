CREATE VIEW [dbo].[PayablesPaymentList]      
--with Encryption      
as      
select p.schemeNo,p.LPONo,p.PaymentNo,p.PayDate,p.Amount,p.Posted,p.DebitAcc,p.BankCode,p.ExpenditureCode,  
       p.withTax,p.vat,b.BankName,e.ExpenditureDesc      
from PayablesPayment p  
     Inner Join SchemeBankBranch b on p.schemeNo = b.schemeNo and p.BankCode = b.BankCode  
     Inner Join ExpenditureItems e on p.ExpenditureCode = e.ExpenditureCode 
WHERE P.Tran_Status = 0
go

