CREATE PROCEDURE [dbo].[PortFolioDistributionPerManager]
@SCHEMENO Int,
@AsAtDate Datetime
--with Encryption
as

if object_id('tempdb..#Portfolio') is null

begin
create table #PortFolio
(
	
        [SchemeName][varchar](120) null,
        [Investment] [varchar](100) NOT NULL ,
        [InvestName][varchar](100),
        [InvestDesc][varchar](100),
        [Manager][varchar](100),
        [ManagerAddress][varchar](100),
        [Location][varchar](100),
        [ManagerPhone][varchar](50),
        [ManagerFax][varchar](30),
        [ManagerEmail][varchar](60),
        [ManagerTown][varchar](60),
        [amount] [float] not  NULL default 0.0,
        [Currency][varchar](30),
        [InvCode][Int] not null,
        [AsAtDate][Datetime]
        
              
) 

ALTER TABLE #PortFolio WITH NOCHECK ADD 

            
	CONSTRAINT [PK_PortFolio] PRIMARY KEY  NONCLUSTERED 
	(
	  [InvCode]      
	) 
end

declare @InvestCode Int,@Investment varchar(50),@Percentage float,@Total float,@Amount float,
@MaxPcnt float,@SchemeName varchar(120),@Curr varchar(15),@Currency varchar(30),
@InvName varchar(100),@InvDesc varchar(100),@Manager varchar(100),@InvCode int,
@Address varchar(80),@Phone varchar(100),@Fax varchar(30),@town varchar(100),@Location varchar(100),
@eMail varchar(100),@Shares varchar(20)

Select @Total = 0

Select @SchemeName = schemeName,@Curr = Currency from scheme where schemeCode = @schemeNo

Select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @Curr

Declare Acsr Cursor for
Select InvestCode,InvCode from
InvestMents 
where SchemeNo = @SchemeNo
and ((InvestCode > 1) and (InvestCode <= 8)) and InvStatus = 0

Open acsr

fetch from acsr into @InvestCode,@InvCode

while @@fetch_Status = 0
begin
     select @Investment = InvestDesc from InvestmentTypes where InvestCode = @InvestCode

     select @Amount = InitValue,@InvName = InvName,@InvDesc = Description
     from Investments where InvestCode = @InvestCode and SchemeNo = @schemeNo and InvCode = @InvCode
    
     if @InvestCode = 2 /*Quoted Equity */
        begin
           select @manager = i.ManagerName,
                  @Address = i.Address,
                  @Location = i.Building+' '+i.Road,
                  @Town = i.Town+' '+i.Country,
                  @Phone = i.Phone,
                  @fax = i.fax,
                  @eMail = i.email,
                  @shares = e.NoOfShares
           from
           Equity e
                  inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.Manager = i.simcode
           where e.SchemeNo = @schemeNo and e.EquityNo = @InvCode
           
           select @InvDesc = @InvDesc + ' -  ( '+ cast(@shares as varchar(20))+' Shares )'
        end
     else if @InvestCode = 3 /*Unquoted Equity */
        begin
           select @manager = i.ManagerName,
                  @Address = i.Address,
                  @Location = i.Building+' '+i.Road,
                  @Town = i.Town+' '+i.Country,
                  @Phone = i.Phone,
                  @fax = i.fax,
                  @eMail = i.email,
                  @shares = e.NoOfShares from
           Equity e
                  inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.Manager = i.simcode
           where e.SchemeNo = @schemeNo and e.EquityNo = @InvCode

           select @InvDesc = @InvDesc + ' -  ( '+ cast(@shares as varchar(20))+' Shares )'
        end 
    else if @InvestCode = 4 /*Government Paper*/
        begin
          select @manager = i.ManagerName,
                  @Address = i.Address,
                  @Location = i.Building+' '+i.Road,
                  @Town = i.Town+' '+i.Country,
                  @Phone = i.Phone,
                  @fax = i.fax,
                  @eMail = i.email from
           GovernmentSecurities e
                  inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.Manager = i.simcode
        where e.SchemeNo = @schemeNo and e.SecurityNo = @InvCode
        end 
    else if @InvestCode = 5 /*Fixed & Time Deposits*/
        begin
           select @manager = i.ManagerName,
                  @Address = i.Address,
                  @Location = i.Building+' '+i.Road,
            @Town = i.Town+' '+i.Country,
                  @Phone = i.Phone,
                  @fax = i.fax,
                  @eMail = i.email from
           CashDeposits e
                  inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.Manager = i.simcode
           where e.SchemeNo = @schemeNo and e.DepositNo = @InvCode
        end 
    else if @InvestCode = 11 /*Off-shore Investments*/
        begin
             select @manager = i.ManagerName,
                  @Address = i.Address,
                  @Location = i.Building+' '+i.Road,
            @Town = i.Town+' '+i.Country,
                  @Phone = i.Phone,
                  @fax = i.fax,
                  @eMail = i.email from
           Offshore e
                  inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.Manager = i.simcode
           where e.SchemeNo = @schemeNo and e.OffshoreNo = @InvCode
        end 
    else if @InvestCode = 7 /*Commercial Paper*/
        begin
           select @manager = i.ManagerName,
                  @Address = i.Address,
                  @Location = i.Building+' '+i.Road,
                  @Town = i.Town+' '+i.Country,
                  @Phone = i.Phone,
                  @fax = i.fax,
                  @eMail = i.email from
           CommercialPaper e
                  inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.Manager = i.simcode
           where e.SchemeNo = @schemeNo and e.PaperNo = @InvCode
        end 
   else if @InvestCode = 8 /*Cash & Demand Deposits*/
        begin
             select @manager = i.ManagerName,
                  @Address = i.Address,
                  @Location = i.Building+' '+i.Road,
                  @Town = i.Town+' '+i.Country,
                  @Phone = i.Phone,
                  @fax = i.fax,
                  @eMail = i.email from
           Investments e
                  inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.simCode = i.simcode
           where e.SchemeNo = @schemeNo and e.InvCode = @InvCode
        end 

    else if @InvestCode = 10 /*Other Investments*/
        begin
             select @manager = i.ManagerName,
                  @Address = i.Address,
                  @Location = i.Building+' '+i.Road,
                  @Town = i.Town+' '+i.Country,
                  @Phone = i.Phone,
                  @fax = i.fax,
                  @eMail = i.email from
           Investments e
                  inner Join InvestmentManagers i on e.schemeNo = i.schemeNo and e.simCode = i.simcode
           where e.SchemeNo = @schemeNo and e.InvCode = @InvCode
        end 

   Insert Into #Portfolio (SchemeName,Investment,Investname,InvestDesc,Manager,Amount,Currency,InvCode,
                           ManagerAddress,ManagerPhone,ManagerFax,ManagerEmail,ManagerTown,Location,AsAtDate)
                values(@SchemeName,@Investment,@InvName,@InvDesc,@Manager,@Amount,@Currency,@InvCode,
                       @Address,@phone,@fax,@email,@town,@location,@AsAtDate)
 
   fetch next from acsr into @InvestCode,@InvCode
end
Close Acsr
Deallocate Acsr



Select * from #PortFolio order by Manager,Investment
go

