CREATE FUNCTION [dbo].[Fn_Scheme_Cont](@SchemeNo INT)
returns INTEGER
AS
  BEGIN
      DECLARE @NoConts INT

      SELECT @NoConts = count(*)
      FROM   GapsInConts 
      WHERE  NumConts > 0 and schemeCode = @schemeNo

      RETURN( @NoConts )
  END
go

