CREATE TRIGGER [dbo].[AuditGovernSecurities] on [dbo].[GovernmentSecurities]  
--WITH ENCRYPTION  
 for update  
 as   
  
declare @SchemeNo varchar(15),@PaperNo int, @PrimaryKey varchar(100),@SqlStr varchar(1000),  
        @oPaperType int,@oTransDate Datetime, @OAmountInvested decimal(20,2),@ONominalValue decimal(20,2),  
        @OMaturityDate datetime,@oInterestRate float,@oManager varchar(15),@oInterestFreq Int,  
        @oInterestType Int,  
  
        @PaperType int,@TransDate Datetime, @AmountInvested decimal(20,2),@NominalValue decimal(20,2),  
        @MaturityDate datetime,@InterestRate float,@Manager varchar(15),@InterestFreq Int,  
        @InterestType Int,@InvestCode Int,@InvestTypeCode Int,@Term Bit  
  
select @schemeNo = schemeNo, @PaperNo = SecurityNo, @oPaperType = SecurityType ,  
       @oTransDate = TransDate,@oAmountInvested = AmountInvested, @oNominalValue = NominalValue,  
       @oMaturityDate = MaturityDate, @oInterestRate = InterestRate,@oManager = Manager,  
       @oInterestFreq = InterestFreq,@oInterestType = InterestRate from deleted  
  
select  @PrimaryKey = @SchemeNo + ' - ' + cast(@PaperNo as varchar(30))  
  
select @PaperType = SecurityType ,  
       @TransDate = TransDate,@AmountInvested = AmountInvested, @NominalValue = NominalValue,  
       @MaturityDate = MaturityDate, @InterestRate = InterestRate,@Manager = Manager,  
       @InterestFreq = InterestFreq,@InterestType = InterestRate from inserted  
  
select @InvestCode = InvestCode,@InvestTypeCode = InvestCodeDetail from  
Investments where SchemeNo = @schemeNo and InvCode = @PaperNo  
  
Select @Term = Term from InvestmentTypeDetail  
where InvestCode = @InvestCode and InvestTypeCode = @InvestTypeCode  
  
  
  
if @PaperType <> @OPaperType   
begin  
select @SqlStr =('update GovernmentSecurities set SecurityType = ''' + cast(@OPaperType as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','SecurityType', @OPaperType,@PaperType,@PrimaryKey,getdate(),user,' Security Type',@SqlStr)  
  
end  
  
if @TransDate <> @OTransDate   
begin  
select @SqlStr =('update GovernmentSecurities set TransDate = ''' + cast(@OTransDate as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','TransDate', @OTransDate,@TransDate,@PrimaryKey,getdate(),user,'Transaction Date',@SqlStr)  
  
end  
  
  
if @AmountInvested <> @OAmountInvested   
begin  
select @SqlStr =('update GovernmentSecurities set AmountInvested = ''' + cast(@OAmountInvested as varchar(30)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','AmountInvested', @OAmountInvested,@AmountInvested,@PrimaryKey,getdate(),user,'Amount Invested',@SqlStr)  
  
end  
  
if @NominalValue <> @oNominalValue   
begin  
select @SqlStr =('update GovernmentSecurities set NominalValue = ''' + cast(@ONominalvalue as varchar(30)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','NominalValue', @ONominalValue,@Nominalvalue,@PrimaryKey,getdate(),user,'Nominal Value',@SqlStr)  
  
end  
  
  
if @MaturityDate <> @oMaturityDate   
begin  
select @SqlStr =('update GovernmentSecurities set MaturityDate = ''' + cast(@OMaturityDate as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','MaturityDate', @OMaturityDate,@MaturityDate,@PrimaryKey,getdate(),user,'Maturity Date',@SqlStr)  
  
end  
  
if @InterestRate <> @oInterestRate   
begin  
select @SqlStr =('update GovernmentSecurities set InterestRate = ''' + cast(@OInterestRate as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','InterestRate', @OInterestRate,@InterestRate,@PrimaryKey,getdate(),user,'Interest Rate',@SqlStr)  
  
end  
  
  
if @Manager <> @oManager   
begin  
select @SqlStr =('update GovernmentSecurities set Manager = ''' + cast(@OManager as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','Manager', @OManager,@Manager,@PrimaryKey,getdate(),user,'Fund Manager',@SqlStr)  
  
end  
  
if @InterestFreq <> @oInterestFreq   
begin  
select @SqlStr =('update GovernmentSecurities set InterestFreq = ''' + cast(@OInterestFreq as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','InterestFreq', @OInterestFreq,@InterestFreq,@PrimaryKey,getdate(),user,'Interest Frequency',@SqlStr)  
  
end  
  
if @InterestType <> @oInterestType   
begin  
select @SqlStr =('update GovernmentSecurities set InterestType = ''' + cast(@OInterestType as varchar(15)) + ''' where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and SecurityNo = ' + cast(@PaperNo as varchar(15)))  
  
insert into Audit_Details(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)  
values('Government Paper','Interest Type', @OInterestType,@InterestType,@PrimaryKey,getdate(),user,'Interest Type',@SqlStr)  
  
end
go

