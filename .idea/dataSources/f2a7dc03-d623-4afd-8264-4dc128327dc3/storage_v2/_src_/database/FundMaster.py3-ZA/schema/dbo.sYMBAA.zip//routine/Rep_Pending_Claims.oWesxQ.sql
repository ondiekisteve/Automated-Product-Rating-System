CREATE PROCEDURE [dbo].[Rep_Pending_Claims]          
@ISchemeNo Varchar(15),          
@Global Int, /* 0 - Per Scheme, 1 - All Schemes */          
@AsAtDate Datetime,          
@EndDate Datetime,          
@RepMode Int,/* 0 - Pending Claims, 1 - Pending Payments, 2 - Payments, 3 - ALL Payments per day */          
@ExitMode Int /* 0 - Combined, 1 - Death In Service, 2 - Retirement, 3 - Early Exits */          
as          
          
if object_id('tempdb..#Pending_Claims') is null          
          
begin          
create table #Pending_Claims          
(          
        [glcode] [int] IDENTITY(1,1) NOT NULL ,          
        [SchemeNo][Varchar](15),          
        [SchemeName] [varchar](100) NOT NULL ,        
        [IDnumber] [varchar](20) NULL ,          
        [MemberNo][Int],          
        [FullName][Varchar](100),          
        [DoExit][Datetime],          
        [DoCalc][Datetime],          
        [ExitReason][Varchar](50),          
        [Benefit][float],          
        [Tax][float],          
        [PeriodOut][Varchar](100),          
        [AsatDate][Datetime],          
        [REPORTDESC][VARCHAR](100),          
        [DatePaid][Datetime],  
        PreparedBy varchar(100),  
        DatePrepared datetime,  
        CheckedBy varchar(100),  
        DateChecked datetime,  
        AuthorisedBy varchar(100),  
        DateAuthorised datetime,
        GrossDesc varchar(20),
        TaxDesc varchar(20)                        
)           
          
ALTER TABLE #Pending_Claims WITH NOCHECK ADD            
                      
 CONSTRAINT [PK_#Pending_Claims] PRIMARY KEY  NONCLUSTERED           
 (          
   [glcode]                
 )           
end          
          
Declare @SCHEMENO Int,@schemeName Varchar(100),@MemberNo Int,          
        @FullName Varchar(100),          
        @DoExit Datetime,          
        @DoCalc Datetime,          
        @ExitReason Varchar(50),          
        @Benefit float,          
        @Tax float,@Reason Int,@NumYears Int,@NumMonths Int,@NumDays Int,@PeriodOut Varchar(100),          
        @ActiveStatus Int,@FundCategory Varchar(40),@FundType Varchar(3),@TrivialPension Int,          
        @UnBenefit float,@REPORTDESC varchar(100),@DatePaid Datetime,@IDnumber varchar(20),  
        @PreparedBy varchar(100),@DatePrepared datetime,  
        @CheckedBy varchar(100),@DateChecked datetime,  
        @AuthorisedBy varchar(100),@DateAuthorised datetime             
          
if @Global = 0 /* Per Scheme */          
   declare acsr Cursor for          
   Select SchemeCode,SchemeName,FundCategory,FundType from Scheme          
   WHERE SchemeName not like '%EST' and SchemeCode = @iSchemeNo          
   order  by SchemeCode          
else if @Global = 1 /* All Schemes */          
   declare acsr Cursor for          
   Select SchemeCode,SchemeName,FundCategory,FundType from Scheme          
   WHERE SchemeName not like '%EST'          
   order  by SchemeCode          
          
Open acsr          
Fetch from acsr into @schemeNo,@SchemeName,@FundCategory,@FundType          
while @@fetch_Status = 0          
begin          
   if @RepMode = 0 /* Pending Claims */          
      begin          
         if @ExitMode = 0 /* All Pending Claims */          
            begin          
              --select @REPORTDESC = 'PENDING CLAIM PROCESSING' 
              select @REPORTDESC = 'CLAIMS PROCESSED'         
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
    order by b.DatePrepared            
           end          
         else if @ExitMode = 1 /* All Pending Death Claims */          
           begin          
              --select @REPORTDESC = 'PENDING DEATH CLAIM PROCESSING'
              select @REPORTDESC = 'CLAIMS PROCESSED'           
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared              
          end          
         else if @ExitMode = 2 /* All Pending Retirement Claims */          
          begin          
              --select @REPORTDESC = 'PENDING RETIREMENT CLAIM PROCESSING'
              select @REPORTDESC = 'CLAIMS PROCESSED'           
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared            
          end          
         else if @ExitMode = 3 /* All Pending Early Exit Claims */          
          begin          
              --select @REPORTDESC = 'PENDING EARLY EXITS CLAIM PROCESSING' 
              select @REPORTDESC = 'CLAIMS PROCESSED'          
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared          
         end          
      end          
   else if @RepMode = 1 /* Pending Payments */          
         begin          
         if @ExitMode = 0 /* All Pending Claims */          
            begin          
              --select @REPORTDESC = 'PENDING CLAIM PAYMENTS' 
              select @REPORTDESC = 'CLAIMS PROCESSED'          
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode       
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared         
           end          
         else if @ExitMode = 1 /* All Pending Death Claims */          
           begin          
              --select @REPORTDESC = 'PENDING DEATH CLAIM PAYMENTS'
              select @REPORTDESC = 'CLAIMS PROCESSED'           
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared            
           end          
         else if @ExitMode = 2 /* All Pending Retirement Claims */          
           begin          
              --select @REPORTDESC = 'PENDING RETIREMENT CLAIM PAYMENTS'
              select @REPORTDESC = 'CLAIMS PROCESSED'           
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared           
           end          
         else if @ExitMode = 3 /* All Pending Early Exit Claims */          
           begin          
              --select @REPORTDESC = 'PENDING EARLY EXITS CLAIM PAYMENTS'
              select @REPORTDESC = 'CLAIMS PROCESSED'           
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared               
           end          
      end          
   else if @RepMode = 2 /* Payments */          
      begin          
         if @ExitMode = 0 /* All Pending Claims */          
            begin          
              --select @REPORTDESC = 'CLAIM PAYMENTS'
              select @REPORTDESC = 'CLAIMS PROCESSED'           
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared             
          end          
         else if @ExitMode = 1 /* All Pending Death Claims */          
          begin          
              --select @REPORTDESC = 'DEATH CLAIM PAYMENTS' 
              select @REPORTDESC = 'CLAIMS PROCESSED'          
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared            
           end          
         else if @ExitMode = 2 /* All Pending Retirement Claims */          
           begin          
              --select @REPORTDESC = 'RETIREMENT CLAIM PAYMENTS' 
              select @REPORTDESC = 'CLAIMS PROCESSED'          
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
             where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
             order by b.DatePrepared        
           end          
         else if @ExitMode = 3 /* All Pending Early Exit Claims */          
           begin          
              --select @REPORTDESC = 'EARLY EXITS CLAIM PAYMENTS' 
              select @REPORTDESC = 'CLAIMS PROCESSED'          
              declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
             from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo and b.DoCalc >= @AsAtDate and b.DoCalc <= @EndDate   
            order by b.DatePrepared       
          end     
  
   else if @RepMode = 3 /* Daily Payments - Audit Trails */          
      begin  
         if @ExitMode = 0          
          --select @REPORTDESC = 'CLAIM PAYMENTS' 
          select @REPORTDESC = 'CLAIMS PROCESSED'          
          declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,  
              B.DoExit,B.DoCalc,          
              m.ReasonforExit,B.ActiveStatus,         
              R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,  
              b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked,   
              b.AuthorisedBy, b.DateAuthorised          
          from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
           inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
          where b.schemeNo = @schemeNo          
          and datepart(day,b.DatePrepared) =  datepart(day,@AsAtDate)   
          and datepart(Month,b.DatePrepared) =  datepart(Month,@AsAtDate)  
          and datepart(Year,b.DatePrepared) =  datepart(Year,@AsAtDate)  
          order by b.DatePrepared    
          end          
         else if @ExitMode = 1 /* All Pending Death Claims */          
          begin          
            --select @REPORTDESC = 'CLAIM PAYMENTS' 
            select @REPORTDESC = 'CLAIMS PROCESSED'          
            declare BCsr Cursor for          
              Select m.MemberNo,m.sName+', '+m.fName+' '+Onames as FullName,m.IDnumber as NRC,B.DoExit,B.DoCalc,          
            m.ReasonforExit,B.ActiveStatus,          
            R.ReasonDesc,b.AmountPayable, b.TaxPayable,0,b.DatePaid,   
            b.PreparedBy, b.DatePrepared,b.CheckedBy, b.DateChecked, b.AuthorisedBy, b.DateAuthorised          
            from TBL_Benefits_DC B         
              inner Join Members m on b.schemeNo = m.schemeNo and b.MemberNo = m.MemberNo          
              inner Join ReasonforExit r on b.Exitreason = r.ReasonCode          
            where b.schemeNo = @schemeNo          
            and datepart(day,b.DatePrepared) =  datepart(day,@AsAtDate)   
            and datepart(Month,b.DatePrepared) =  datepart(Month,@AsAtDate)  
            and datepart(Year,b.DatePrepared) =  datepart(Year,@AsAtDate)  
            order by b.DatePrepared      
           end          
         
      end          
          
   Open Bcsr          
   Fetch from Bcsr into @MemberNo,@FullName,@IDnumber,@DoExit,@DoCalc,@Reason,@ActiveStatus,@ExitReason,@Benefit,@Tax,@TrivialPension,          
                        @DatePaid,@PreparedBy,@DatePrepared,@CheckedBy,@DateChecked,@AuthorisedBy,@DateAuthorised          
   while @@fetch_Status = 0          
   begin          
      if @TrivialPension is null select @TrivialPension = 0          
          
      select @UnBenefit = EEmpCBal + EEmprCBal + EVolCBal + ESpecialCBAL from UnRegisteredBenefits          
      where schemeNo = @schemeNo and MemberNo = @MemberNo          
          
      if @UnBenefit is null select @UnBenefit = 0           
          
      if ((@FundType = 'DB') and (@TrivialPension = 0))          
         select @Benefit = ComLumGWTax,@Tax = wTaxPd from Pensioner          
         where schemeNo = @schemeNo and MemberNo = @MemberNo           
      else          
         begin                  
          if @ActiveStatus = 6          
             select @Benefit = AmountPaid,@Tax = TaxPaid from PartialPayment          
             where schemeNo = @SchemeNo and MemberNo = @MemberNo          
          else          
             select @Benefit = @Benefit + @UnBenefit          
         end          
          
      if @RepMode = 0          
         select @Benefit = 0,@Tax = 0          
          
      if @Benefit is null select @Benefit = 0          
      if @Tax is null select @Tax = 0          
          
      select @NumDays = DateDiff(Day,@DoCalc,@AsAtDate)          
          
      select @PeriodOut = cast(@NumDays as Varchar(4))          
                
      Insert Into #Pending_Claims(SchemeNo,SchemeName,MemberNo,fullName,DoExit,DoCalc,ExitReason,          
                                  Benefit,Tax,PeriodOut,AsatDate,ReportDesc,DatePaid,IDnumber,  
                                  PreparedBy,DatePrepared,CheckedBy,DateChecked,AuthorisedBy,DateAuthorised)          
                       Values(@SchemeNo,@SchemeName,@MemberNo,@FullName,@DoExit,@DoCalc,@ExitReason,@Benefit,@Tax,@PeriodOut,@AsatDate,          
                              @ReportDesc,@DatePaid,@IDnumber,@PreparedBy,@DatePrepared,@CheckedBy,@DateChecked,@AuthorisedBy,@DateAuthorised)          
          
      select @NumYears = 0,@NumMonths = 0,@NumDays = 0,@ExitReason = ' ',@FullName = '',@MemberNo = 0,          
      @Benefit = 0,@Tax = 0,@PreparedBy='',@CheckedBy='',@AuthorisedBy=''     
          
      Fetch next from Bcsr into @MemberNo,@FullName,@IDnumber,@DoExit,@DoCalc,@Reason,@ActiveStatus,@ExitReason,@Benefit,@Tax,@TrivialPension,          
                                @DatePaid,@PreparedBy,@DatePrepared,@CheckedBy,@DateChecked,@AuthorisedBy,@DateAuthorised           
   end          
   Close Bcsr          
   Deallocate Bcsr          
          
   select @schemeNo = '',@SchemeName = '',@FundCategory='',@FundType='',@PeriodOut='',@NumDays = 0          
   Fetch next from acsr into @schemeNo,@SchemeName,@FundCategory,@FundType          
end          
Close Acsr          
Deallocate Acsr

Update #Pending_Claims set GrossDesc  = 'GROSS',TaxDesc = 'TAX'           
          
select * from #Pending_Claims order by SchemeNo,ExitReason,MemberNo
go

