CREATE PROCEDURE [dbo].[GetLumpFactor]
@SCHEMENO Int,
@dateExit datetime,
@LumpFactor int out
--with Encryption
as

select @LumpFactor = 0

declare @doExit datetime,@lFactor int

declare Acsr cursor for
select startDate,LumpFactor
from LumpsumFactor
where SchemeNo = @schemeNo
Order by StartDate

Open Acsr

fetch from Acsr into @DoExit,@LFactor

while @@fetch_Status = 0
begin
   if @DoExit >= @DateExit
      begin
      if @LumpFactor = 0
         select @LumpFactor = @LFactor
      end
      
   fetch next from Acsr into @DoExit,@LFactor
end
Close Acsr
Deallocate Acsr
go

