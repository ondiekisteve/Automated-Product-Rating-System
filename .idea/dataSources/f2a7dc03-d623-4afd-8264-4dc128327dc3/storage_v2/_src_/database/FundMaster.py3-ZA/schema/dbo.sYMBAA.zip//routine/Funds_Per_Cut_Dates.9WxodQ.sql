CREATE PROCEDURE [dbo].[Funds_Per_Cut_Dates]            
@schemeCode Int,          
@StartDate datetime,          
@EndDate datetime              
--with Encryption                
as                
          
IF EXISTS (SELECT name FROM sysindexes                 
      WHERE name = 'FundList')                
   DROP INDEX #Fundlist.FundList            
                
if object_id('tempdb..#Fundlist') is null                
                
begin                
create table #FundList                
(                
 [ListingNo][Int] Identity(1,1) primary Key,              
 [SchemeCode] [Int],                
 [SchemeName][varchar](100) NOT NULL ,                
 [PlanType] [varchar](40)  NULL,                
 [FundCategory][varchar](40) null,                
 [ActiveMembers] [Int] null,        
 [ActiveMembersF] [Int] null,              
 [Pensioners][Int],         
 [PensionersF][Int],               
 [Deferred][Int],         
 [DeferredF][Int],                
 [DeferredMembers][Int],          
 [DeferredMembersF][Int],              
 [FundWorth][float] null,              
 [PoolName][varchar](120),          
 EECont Decimal(20,6),          
 ERCont Decimal(20,6),          
 ContTotal Decimal(20,6),          
 Withdrawals Decimal(20,6),        
 StartDate datetime,        
 EndDate datetime,      
 NewEntrants Int                    
)                   
end             
          
CREATE INDEX FundList                
   ON #FundList (SchemeCode, SchemeName, ListingNo)               
                
Declare @SCHEMENO Int,@SchemeName varchar(120),@FundType Varchar(50),@FundCategory varchar(20),                
@NumMembers Int,@FundWorth float,@AcctPeriod Int,@Balances float,@BalancesUn float,@Contributions float,                
@Pensioner Int,@Deferred Int,@DeferredMembers Int,@PoolName varchar(120),@PoolCode Int,          
@EECont Decimal(20,6),@ERCont Decimal(20,6),@Withdrawals Decimal(20,6),          
@EEArr Decimal(20,6),@ERArr Decimal(20,6),@EETransfer Decimal(20,6),@ERTransfer Decimal(20,6),@NewEntrants Int,    
@aflife smallint    
    
select @Aflife = Aflife from scheme where schemeCode = @schemeNo    
    
if @aflife is not null select @aflife = 0          
               
declare acsr Cursor for                
select s.SchemeCode, s.SchemeName, f.FundTypeDesc, case s.Fund_Cat             
                                               when 1 then 'Pension Fund'            
                                               when 2 then 'Provident Fund'            
                                               when 3 then 'Investment Pool'            
end as FundCategory,s.InvestmentScheme             
from scheme s             
     inner Join SchemePlanTypes f on s.FundTypeCode = f.FundTypeCode               
where s.PooledInvestment = 0 and f.FundTypeCode <> 8 and StatusCode <> 3      
and ActiveStatus = 1 and BasisCode <> 1         
open acsr                
Fetch from acsr into @SchemeNo,@SchemeName,@FundType,@FundCategory,@PoolCode                
while @@fetch_Status = 0                
begin                
   select @PoolName ='SEGREGATED'              
                       
   select @Pensioner = Count(*)     
   from Pensioner p     
        inner join members m on p.schemeNo = m.schemeNo and p.memberNo = m.memberNo and m.doCalc <= @EndDate              
   where p.Alive = 1 and p.SchemeNo = @SchemeNo                
                   
   if @Pensioner is null select @Pensioner = 0                
                
   select @Deferred = Count(*) from DeferredPensioner p     
        inner join members m on p.schemeNo = m.schemeNo and p.memberNo = m.memberNo and m.doCalc <= @EndDate                
   where p.Pensioner = 0 and p.SchemeNo = @SchemeNo                
                
   if @Deferred is null select @Deferred = 0                
                       
   if @Balances is null select @Balances = 0                
   if @BalancesUn is null select @BalancesUn = 0                
               
   select @EECont = sum(EmpCont + VolContr + ExcessEmpCont + ExcessVolContr),          
            @ERCont = sum(EmprCont + SpecialContr +  ExcessEmprCont + ExcessSpecial)           
   from                                             
   Contributionssummary where SchemeNo = @schemeNo and datepaid >= @startDate          
   and DatePaid <= @EndDate                
           
   select @EEArr = sum(ArEmpCont + ArVolContr),@ERArr = sum(ArEmprCont + ArSpecial)          
   from                                             
   ContributionArrears where SchemeNo = @schemeNo and datepaid >= @startDate          
   and DatePaid <= @EndDate         
        
   select @EETransfer = sum(EmpTransfer + AVCTransfer),          
          @ERTransfer = sum(EmprTransfer + AVCERTransfer)           
   from                                             
   MemberTransfer where SchemeNo = @schemeNo and Transferdate >= @startDate          
   and Transferdate <= @EndDate          
        
   if @EECont is null select @EECont = 0           
   if @ERCont is null select @ERCont = 0         
        
   if @EEArr is null select @EEArr = 0           
   if @ERArr is null select @ERArr = 0          
        
   if @EETransfer is null select @EETransfer = 0           
   if @ERTransfer is null select @ERTransfer = 0        
        
   Exec Proc_With_Per_Cut_Dates @schemeNo,@StartDate,@EndDate,@Withdrawals out        
        
   IF @Withdrawals IS null select @Withdrawals = 0.0         
        
   select @EECont = @EECont + @EETransfer + @EEArr,@ERCont = @ERCont + @ERTransfer + @ERArr          
       
   if @aflife = 0    
      select @NumMembers = Count(*) from Members where SchemeNo = @schemeNo   
      and djpens <= @EndDate                        
      and ((ReasonforExit = 0) or (ReasonforExit > 0 and DoCalc > @EndDate))   
      and ActiveStatus = 1   
   else             
      select @NumMembers = Count(*) from Members where SchemeNo = @schemeNo     
      and membStartDate <= @EndDate                        
      and ((ReasonforExit = 0) or (ReasonforExit > 0 and DoCalc > @EndDate))   
      and ActiveStatus = 1     
                          
   if @NumMembers is null select @NumMembers = 0                
                
   select @DeferredMembers = Count(*) from Members where SchemeNo = @schemeNo and ReasonforExit > 0                
   and ActiveStatus = 6 and DeferredPaid = 0 and InitialDoCalc <= @EndDate      
      
   if @Aflife = 0    
      select @NewEntrants = Count(*) from Members where SchemeNo = @schemeNo and djpens >= @StartDate                
      and djpens <= @EndDate and ReasonforExit <> -1   
   else    
      select @NewEntrants = Count(*) from Members where SchemeNo = @schemeNo and membStartDate >= @StartDate                
      and membStartDate <= @EndDate and ReasonforExit <> -1     
          
   if @NewEntrants is null select @NewEntrants = 0            
                
   if @DeferredMembers is null select @DeferredMembers = 0      
      
   if @NewEntrants is null select @NewEntrants = 0                
                
   Insert Into #FundList(SchemeCode,SchemeName,PlanType,FundCategory,ActiveMembers,FundWorth,                
                         Pensioners,Deferred,DeferredMembers,PoolName,EECont,ERCont,ContTotal,          
                         Withdrawals,StartDate,EndDate,NewEntrants)                
               Values(@SchemeNo,@SchemeName,@FundType,@FundCategory,@NumMembers,@Balances,                
                      @Pensioner,@Deferred,@DeferredMembers,@PoolName,@EECont,@ERCont,@EECont+@ERCont,          
                      @Withdrawals,@StartDate,@EndDate,@NewEntrants)                
                   
   select @NumMembers = 0,@BalancesUn = 0,@Balances = 0,@Contributions = 0,@Pensioner = 0,@Deferred = 0,                
   @DeferredMembers = 0,@EECont=0,@ERCont=0,@Withdrawals=0,@EETransfer=0,@ERTransfer=0,@ERArr = 0,@EEArr = 0,      
   @NewEntrants = 0                
                
   Fetch next from acsr into @SchemeNo,@SchemeName,@FundType,@FundCategory,@PoolCode                
end                
Close Acsr              
Deallocate Acsr                
            
            
             
/* Pooled Funds */                
declare acsr Cursor for                
select s.SchemeCode, s.SchemeName, f.FundTypeDesc, case s.Fund_Cat             
                                               when 1 then 'Pension Fund'            
                                               when 2 then 'Provident Fund'            
                                               when 3 then 'Investment Pool'            
end as FundCategory,s.InvestmentScheme             
from scheme s             
     inner Join SchemePlanTypes f on s.FundTypeCode = f.FundTypeCode               
where s.PooledInvestment = 1 and f.FundTypeCode <> 8 and StatusCode <> 3     
and ActiveStatus = 1 and BasisCode <> 1          
open acsr                
Fetch from acsr into @SchemeNo,@SchemeName,@FundType,@FundCategory,@PoolCode                
while @@fetch_Status = 0                
begin                
   select @PoolName = SchemeName from scheme where SchemeCode = @PoolCode              
              
   select @Pensioner = Count(*)     
   from Pensioner p     
        inner join members m on p.schemeNo = m.schemeNo and p.memberNo = m.memberNo and m.doCalc <= @EndDate              
   where p.Alive = 1 and p.SchemeNo = @SchemeNo               
                   
   if @Pensioner is null select @Pensioner = 0                
                
   select @Deferred = Count(*) from DeferredPensioner p     
        inner join members m on p.schemeNo = m.schemeNo and p.memberNo = m.memberNo and m.doCalc <= @EndDate               
   where p.Pensioner = 0 and p.SchemeNo = @SchemeNo              
                
   if @Deferred is null select @Deferred = 0                
                
                
                
   if @Balances is null select @Balances = 0                
   if @BalancesUn is null select @BalancesUn = 0                
               
   select @EECont = sum(EmpCont + VolContr + ExcessEmpCont + ExcessVolContr),          
          @ERCont = sum(EmprCont + SpecialContr +  ExcessEmprCont + ExcessSpecial)           
   from                     
   Contributionssummary where SchemeNo = @schemeNo and datepaid >= @startDate          
   and DatePaid <= @EndDate                
           
   select @EEArr = sum(ArEmpCont + ArVolContr),@ERArr = sum(ArEmprCont + ArSpecial)           
   from                                             
   ContributionArrears where SchemeNo = @schemeNo and datepaid >= @startDate          
   and DatePaid <= @EndDate     
      
   select @EETransfer = sum(EmpTransfer + AVCTransfer),          
          @ERTransfer = sum(EmprTransfer + AVCERTransfer)           
   from                                             
   MemberTransfer where SchemeNo = @schemeNo and Transferdate >= @startDate          
   and Transferdate <= @EndDate          
        
   if @EECont is null select @EECont = 0          
   if @ERCont is null select @ERCont = 0         
        
   if @EEArr is null select @EEArr = 0           
   if @ERArr is null select @ERArr = 0          
        
   if @EETransfer is null select @EETransfer = 0           
   if @ERTransfer is null select @ERTransfer = 0        
        
   Exec Proc_With_Per_Cut_Dates @schemeNo,@StartDate,@EndDate,@Withdrawals out        
        
   IF @Withdrawals IS null select @Withdrawals = 0.0         
        
   select @EECont = @EECont + @EETransfer + @EEArr,@ERCont = @ERCont + @ERTransfer + @ERArr         
                          
   if @aflife = 0    
      select @NumMembers = Count(*) from Members where SchemeNo = @schemeNo   
      and djpens <= @EndDate                        
      and ((ReasonforExit = 0) or (ReasonforExit > 0 and DoCalc > @EndDate))   
      and ActiveStatus = 1  
   else             
      select @NumMembers = Count(*) from Members where SchemeNo = @schemeNo   
      and membStartDate <= @EndDate                        
      and ((ReasonforExit = 0) or (ReasonforExit > 0 and DoCalc > @EndDate))   
      and ActiveStatus = 1  
              
   if @NumMembers is null select @NumMembers = 0                
                
   select @DeferredMembers = Count(*) from Members where SchemeNo = @schemeNo and ReasonforExit > 0                
   and ActiveStatus = 6 and DeferredPaid = 0 and InitialDoCalc <= @EndDate      
      
   if @Aflife = 0    
      select @NewEntrants = Count(*) from Members where SchemeNo = @schemeNo and djpens >= @StartDate                
      and djpens <= @EndDate and reasonforexit <> - 1    
   else    
      select @NewEntrants = Count(*) from Members where SchemeNo = @schemeNo and membStartDate >= @StartDate                
      and membStartDate <= @EndDate  and reasonforexit <> -1    
          
   if @NewEntrants is null select @NewEntrants = 0            
                
   if @DeferredMembers is null select @DeferredMembers = 0      
      
   if @NewEntrants is null select @NewEntrants = 0                 
                
   Insert Into #FundList(SchemeCode,SchemeName,PlanType,FundCategory,ActiveMembers,FundWorth,                
                         Pensioners,Deferred,DeferredMembers,PoolName,EECont,ERCont,ContTotal,          
                         Withdrawals,StartDate,EndDate,NewEntrants)                
               Values(@SchemeNo,@SchemeName,@FundType,@FundCategory,@NumMembers,@Balances,                
                      @Pensioner,@Deferred,@DeferredMembers,@PoolName,@EECont,@ERCont,@EECont+@ERCont,          
                      @Withdrawals,@StartDate,@EndDate,@NewEntrants)             
                   
   select @NumMembers = 0,@BalancesUn = 0,@Balances = 0,@Contributions = 0,@Pensioner = 0,@Deferred = 0,                
   @DeferredMembers = 0,@EECont=0,@ERCont=0,@Withdrawals=0,@EETransfer=0,@ERTransfer=0,@ERArr = 0,@EEArr = 0,      
   @NewEntrants = 0                  
                
   Fetch next from acsr into @SchemeNo,@SchemeName,@FundType,@FundCategory,@PoolCode                
end                
Close Acsr                
Deallocate Acsr                  
                
Select * from #FundList order by PoolName,SchemeName
go

