CREATE PROCEDURE [dbo].[Proc_MarketValue]    
@SCHEMENO Int,    
@EquityNo Int,    
@EndDate Datetime,    
@MarketValue Decimal(20,6) Out    
--with Encryption    
as    
    
Declare @PricePerShare Decimal(20,6),@LatestValue Decimal(20,6),@MaxPriceDate Datetime    
    
select @PricePerShare = PricePerShare    
from Equity    
where SchemeNo = @SchemeNo and EquityNo = @EquityNo   
  
select @MaxPriceDate = Max(PriceDate) from EquityValue where schemeNo = @schemeNo and EquityNo = @EquityNo    
and PriceDate <= @EndDate   
    
select @LatestValue = PricePerShare from EquityValue where schemeNo = @schemeNo and EquityNo = @EquityNo    
and PriceDate = @MaxPriceDate     
    
if @LatestValue is null   
   select @MarketValue = @PricePerShare  
Else  
   select @MarketValue = @LatestValue
go

