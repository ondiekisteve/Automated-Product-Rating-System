CREATE TRIGGER [dbo].[trg_Fin_Levels_rba] ON [dbo].[TBL_NET_ASSETS_LEVELS_RBA] 
FOR UPDATE
AS

declare @OldParentCode int,@OldChildCode int, @NewParentCode int,@NewChildCode int

select @OldParentCode = Parent_Level_Code,@OldChildCode = Child_Level_Code from deleted

select @NewParentCode = Parent_Level_Code,@NewChildCode = Child_Level_Code from Inserted

update glAccountCodes set Parent_Level_Code1 = @NewParentCode,Child_Level_Code1 = @NewChildCode
where Parent_Level_Code1 = @OldParentCode and Child_Level_Code1 = @OldChildCode
go

