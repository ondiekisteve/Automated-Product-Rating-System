CREATE PROCEDURE [dbo].[PensionLiabilityGridBen]                
@SCHEMENO Int,              
@Posted Int                
--with Encryption                
as                
                
if object_id('tempdb..#Liability') is null                
                
begin                
create table #Liability                
(        
        [LiabCounter][int] identity(1,1) primary key,        
        [Stopcode] [int],                 
        [SchemeNo] [varchar] (15) NOT NULL ,                
        [MemberNo][Int] not null,                
        [DependantCode][Int] not null,                
        [SurName][varchar](30) not null,                
        [OtherNames][Varchar](40) null,                
        [FullName][Varchar](50) null,                
        [Pension][float] not null,                
        [Months][int] null,                
        [StopPeriod][Varchar](25) null,                
        [StopReason][Varchar](60) null,                
        [TotalLiability][float] null,                
        [Reinstated][varchar](3) null,            
        [PenNo][varchar](15) null,                
        [PayMode][Int],                
        [ReInstate][int],              
        ReinMonth Int,              
        ReinYear Int,        
        RevLiab smallint                  
)                    
end                
                
                
declare @Total float              
                    
   Insert Into #Liability (StopCode,SchemeNo, MemberNo, DependantCode, SurName,               
                           OtherNames,FullName,Pension,Months,StopPeriod, StopReason, Reinstated,RevLiab,PenNo)      
      
   select ps.StopCode,ps.schemeNo, ps.MemberNo, ps.DependantCode, Upper(m.sName) as surName, m.fname +' '+m.Oname as OtherNames,                 
   Upper(m.sName) +', '+ m.fname +' '+m.Oname as FullName, sum(x.Net),count(*) as Months,      
   cast(ps.StopMonth as varchar(2))+', '+cast(ps.StopYear as varchar(4)), pz.Description , case ps.Reinstated                 
   when 0 then 'No'                
   when 1 then 'Yes'                
   end as Reinstate,ps.Rev_Liab,x.PenNo                
  from PensionStoppageBen ps        
     inner join PensionPayrollBen x on ps.SchemeNo = x.SchemeNo and ps.memberNo = x.MemberNo      
                and Ps.DependantCode = x.DependantCOde and x.Hold = 0            
     inner Join Dependants m  on   ps.SchemeNo = m.schemeNo and ps.MemberNo = m.MemberNo     
     and Ps.DependantCode = m.DependantCode                
     inner Join Pension_Stop_Setup pz on ps.StoppageType = pz.StopCode                
where ps.SchemeNo = @SchemeNo  and ps.ArrearsPaid = @Posted     
Group By ps.StopCode,ps.schemeNo, ps.MemberNo, ps.DependantCode,m.sName, m.fname, m.Oname,                 
ps.StopMonth,ps.StopYear ,ps.Reinstated,pz.Description,ps.Rev_Liab,x.PenNo      
Order by ps.MemberNo, Ps.DependantCode        
                         
Select @Total = sum(Pension) from #Liability                
                
update #Liability set TotalLiability = @Total       
               
Select * from #Liability order by MemberNo
go

