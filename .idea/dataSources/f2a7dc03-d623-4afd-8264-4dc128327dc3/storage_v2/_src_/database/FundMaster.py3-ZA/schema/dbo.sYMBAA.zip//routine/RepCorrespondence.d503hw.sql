CREATE PROCEDURE [dbo].[RepCorrespondence]
@SCHEMENO Int,
@Correspond int,
@Code varchar(15),
@sDate datetime,
@EDate datetime
--with Encryption
as

declare @Consultant varchar(100)

if @Correspond = 1
   Select @Consultant = TrusteeName from Trustees where SchemeNo = @SchemeNo and TrusteesCode = @code
else if @Correspond = 2
   Select @Consultant = SponsorName from Sponsor where SchemeNo = @SchemeNo and SponsorCode = @code
else if @Correspond = 3
   Select @Consultant = ConsultantName from Scheme_Consultants where SchemeNo = @SchemeNo and ConsultantCode = @code
else if @Correspond = 4
   Select @Consultant = ManagerName from InvestmentManagers where SchemeNo = @SchemeNo and simCode = @code
else if @Correspond = 5
   Select @Consultant = CustodianName from Custodians where SchemeNo = @SchemeNo and CustodianCode = @code
else if @Correspond = 6
   Select @Consultant = AdvisorName from LegalAdvisors where SchemeNo = @SchemeNo and AdvisorCode = @code
else if @Correspond = 7
   Select @Consultant = BankName from SchemeBankBranch where SchemeNo = @SchemeNo and Bankcode = @code
else if @Correspond = 8
   Select @Consultant = AgentName from EstateAgents where AgentCode = @code


Select s.SchemeName, upper(@Consultant) as Consultant, c.CorrDate,c.Document,c.Correspond,c.Action,c.Remarks
from Correspondense c
     inner Join scheme s on c.schemeNo = s.schemecode
where c.SchemeNo = @schemeNo and
      c.CorrespondCode = @correspond and
      c.ConsultantCode = @code and
      c.CorrDate >= @sDate and
      c.CorrDate <= @eDate
go

