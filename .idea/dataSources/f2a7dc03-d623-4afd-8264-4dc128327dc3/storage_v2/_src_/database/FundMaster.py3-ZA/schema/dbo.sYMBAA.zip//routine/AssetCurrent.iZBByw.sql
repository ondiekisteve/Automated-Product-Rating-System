CREATE PROCEDURE [dbo].[AssetCurrent]              
@SCHEMENO Int,              
@AssetMode int,          
@AssetSold int /* 0 - Current, 1 - Sold, 2 - Fully Depreciated */             
--with Encryption              
as              
Select a.SchemeNo,a.AssetNo,A.assetRefNo,a.AssetClass,a.AssetName,a.AssetDesc,a.OriginalCost as AssetCost,a.AssetDate,              
       case a.AssetClass              
           when 0 then 'Real Estate'              
           when 1 then 'Others'              
           end as ClassAsset,a.ClassCode,C.ClassName              
from Assets a            
     Inner Join TBL_Asset_Classes c on a.schemeNo = c.SchemeNo and a.ClassCode = c.ClassCode              
where a.SchemeNo = @SchemeNo and A.Retired = @AssetMode              
and A.AssetSold = @AssetSold and A.AssetMode = 0 AND A.WorkInProgress = 0
go

