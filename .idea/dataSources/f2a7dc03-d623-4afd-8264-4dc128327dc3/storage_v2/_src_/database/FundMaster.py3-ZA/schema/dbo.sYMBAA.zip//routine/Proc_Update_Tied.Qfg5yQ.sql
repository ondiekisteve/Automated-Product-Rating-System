CREATE PROCEDURE [dbo].[Proc_Update_Tied]        
@schemeNo int,        
@SecurityNo int,        
@TiedProp int out        
--with Encryption        
as        
        
set nocount on        
        
if object_id('tempdb..#AcctCodes') is null        
        
begin        
create table #AcctCodes        
(        
 [GlCode][Int] identity(1,1) primary key,        
 [AccountCode] [varchar](30)null,        
)        
end        
        
declare @InvestCode int,@AssetAcc varchar(30),@BankAcc varchar(30),@DebitAcc varchar(30),@CreditAcc varchar(30),        
        @CurrCode int,@CurrRevAcc varchar(30),@xCurrCode int,@FairValueAcc varchar(30),@GainLossAcc varchar(30),        
        @DepositAcc varchar(30)        
        
        
select @xCurrCode = CurrCode from scheme where schemeCode = @schemeNo        
        
select @InvestCode = InvestCode from Investments where schemeNo = @schemeNo and invCode = @SecurityNo        
    
/*        
if @InvestCode = 1 --- Property       
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@DebitAcc=DebitAcc,@CreditAcc=CreditAcc,        
            @FairValueAcc = RentPreAcc,@GainLossAcc = DepositAcc,@DepositAcc = ValuationAcc        
     from property where schemeNo = @schemeNo and PropertyCode = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
        
     insert into #AcctCodes select @FairValueAcc        
     insert into #AcctCodes select @GainLossAcc        
     insert into #AcctCodes select @DepositAcc        
            
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)         
   end        
else if @InvestCode = 2 ----Equity        
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@DebitAcc=AccrDividendsAcc,@CreditAcc=DividendsAcc,        
            @FairValueAcc = FairValueAcc,@GainLossAcc = GainLossOnSaleAcc        
     from Equity where schemeNo = @schemeNo and EquityNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
     insert into #AcctCodes select @FairValueAcc        
     insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end          
else if @InvestCode = 3  ---Private Equity        
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@DebitAcc=AccrDividendsAcc,@CreditAcc=DividendsAcc,        
            @FairValueAcc = FairValueAcc,@GainLossAcc = GainLossOnSaleAcc        
     from Equity where schemeNo = @schemeNo and EquityNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
     insert into #AcctCodes select @FairValueAcc        
     insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end           
else if @InvestCode = 4  ----Government Bonds        
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@DebitAcc=DebitAcc,@CreditAcc=CreditAcc,        
            @FairValueAcc = ValuationAcc--,@GainLossAcc = GainLossOnSaleAcc        
     from GovernmentSecurities where schemeNo = @schemeNo and SecurityNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
     insert into #AcctCodes select @FairValueAcc        
     --insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end        
else if @InvestCode = 5 -----Fixed Term Deposits        
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@DebitAcc=DebitAcc,@CreditAcc=CreditAcc,@CurrCode = CurrCode,        
            @FairValueAcc = CurrRevalAcc--,@GainLossAcc = GainLossOnSaleAcc        
     from CashDeposits where schemeNo = @schemeNo and DepositNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
     if @CurrCode <> @xCurrCode        
     insert into #AcctCodes select @FairValueAcc        
     --insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end        
else if @InvestCode = 7 -----Corporate Bonds/Commercial Paper       
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@DebitAcc=DebitAcc,@CreditAcc=CreditAcc,@CurrCode = CurrCode,        
            @FairValueAcc = CurrRevalAcc,@GainLossAcc = ValuationAcc        
     from CommercialPaper where schemeNo = @schemeNo and PaperNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
     if @CurrCode <> @xCurrCode        
     insert into #AcctCodes select @FairValueAcc        
     insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end        
else if @InvestCode = 8 ----call Deposits         
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@DebitAcc=DebitAcc,@CreditAcc=CreditAcc,@CurrCode = CurrCode,        
            @FairValueAcc = CurrRevalAcc--,@GainLossAcc = GainLossOnSaleAcc        
     from DemandDeposits where schemeNo = @schemeNo and DepositNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
     if @CurrCode <> @xCurrCode        
     insert into #AcctCodes select @FairValueAcc        
     --insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end        
else if @InvestCode = 9 ----Long Term Loans       
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@DebitAcc=InterestRecAcc,@CreditAcc=InterestAcc,@CurrCode = CurrCode,        
            @FairValueAcc = CurrRevAcc,@GainLossAcc = CapRepayRecAcc        
     from TBL_Loans where schemeNo = @schemeNo and MortgageNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc         insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
     if @CurrCode <> @xCurrCode        
     insert into #AcctCodes select @FairValueAcc        
     insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end        
else if ((@InvestCode >= 10)  and (@InvestCode <= 11)) -- Offshore Investments        
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@CurrCode = CurrCode,        
            @FairValueAcc = FairValueAcc, @DepositAcc = CurrRevalAcc,@GainLossAcc = GainLossOnSaleAcc        
     from Offshore where schemeNo = @schemeNo and OffshoreNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @FairValueAcc        
     if @CurrCode <> @xCurrCode        
     insert into #AcctCodes select @DepositAcc        
     insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end        
else if (@InvestCode = 12) ----Endowments         
   begin        
     select @AssetAcc  = AssetAcc,@BankAcc = BankAcc,@CurrCode = CurrCode,@debitAcc = PremiumAcc,@CreditAcc = BonusAcc,        
            @DepositAcc = CurrRevalAcc,@GainLossAcc = GainLossOnSaleAcc        
     from TBL_Endowments where schemeNo = @schemeNo and OffshoreNo = @SecurityNo        
        
     insert into #AcctCodes select @AssetAcc        
     insert into #AcctCodes select @BankAcc        
     insert into #AcctCodes select @DebitAcc        
     insert into #AcctCodes select @CreditAcc        
     if @CurrCode <> @xCurrCode        
     insert into #AcctCodes select @DepositAcc        
     insert into #AcctCodes select @GainLossAcc        
        
     update #AcctCodes set Accountcode ='0' where AccountCode is null        
        
     select @TiedProp = count(*) from #AcctCodes where AccountCode not in (select AccountCode from glAccountCodes        
                                                                           where AccountType = 2)        
   end      
*/   
  
Exec dbo.Proc_Auto_Tie @schemeNo,@SecurityNo /* Auto Tie Accounts */  
   
if @TiedProp is null select @TiedProp = 0      
        
IF @TiedProp = 0       
   select @TiedProp = 1      
else       
   select @TiedProp = 0
go

