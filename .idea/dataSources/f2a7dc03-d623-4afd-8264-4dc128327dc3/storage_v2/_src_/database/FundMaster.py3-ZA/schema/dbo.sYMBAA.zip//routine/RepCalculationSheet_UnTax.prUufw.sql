/*
MODIFICATIONS:
11/03/2004

Added :
           Fields:
           PreparedBy,CheckedBy,AuthorisedBy
           Variables:
           @PreparedBy,@CheckedBy,@AuthorisedBy
           Code:
           select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo
           Insert these extra fields in the Temp Table
*/
CREATE PROCEDURE [dbo].[RepCalculationSheet_UnTax]
@SCHEMENO Int,
@memberNo int,
@Mode Int
--with Encryption
as

set nocount on

if object_id('tempdb..#Calculation') is null

begin
create table #Calculation
(
           [SchemeNo] [varchar] (15) NOT NULL ,
	   [MemberNo] [int] NOT NULL ,
           [schemeName][varchar](100) null,
           [fullname][varchar](100)  null,
           [DJE][Datetime]  null,
           [djpens][datetime]  null,
	   [EmpOpeningBal] [float] NULL ,
           [EmprOpeningBal][float] NULL, 
	   [EmpContributions] [float]  NULL ,
           [EmprContributions] [float]  NULL , 
           [EmpClosing][float]  null,
           [EmprClosing][float]  null,
                [interest] [float]  NULL ,
                [DateOfExit][datetime]  null,
	        [curYear] [int]  NULL ,
	        [PastService] [varchar](100) NULL,
                [BenefitsDC] [float]   NULL ,
                [Vesting][float]null,
                [TaxfreeLumpsum][float] null,
                [WithHoldingTax][float]null,
                [comments][varchar](50)  null,
                [empInt][float]  null,
                [emprInt][float]  null,
                [AmountPayable][float]  null,
                [TaxableAmount][float] null,
                [LastYear][int]  null,
                [Reason][Varchar](50) null,
                [EndDate][Datetime],
                [PreparedBy][varchar](100),
                [CheckedBy][varchar](100),
                [AuthorisedBy][varchar](100)
       
     
) 

ALTER TABLE #Calculation WITH NOCHECK ADD             
	CONSTRAINT [PK_Calculation] PRIMARY KEY  NONCLUSTERED 
	(
		[SchemeNo],
		[memberNo]      
	) 
end


declare @fullname varchar(100)
declare @schemeName varchar(100)
declare @empopening float
declare @emprOpening float
declare @empContribution float
declare @emprContribution float
declare @empClosing float
declare @emprClosing float
declare @interest float
declare @DateOfExit datetime
declare @pastService int
declare @BenefitsDC Float
declare @vesting float
declare @taxfreelumpsum float
declare @withHoldingTax float
declare @dje datetime
declare @djpens datetime
declare @curYear int
declare @comments varchar(50)
declare @VestedCont float
declare @EmpInt float
declare @Emprint float
declare @GrandTotal float
declare @TaxAmount float
declare @Doexit datetime
declare @CurMonth int
declare @AcctPeriod int, @sDate datetime, @eDate datetime, @DoCalc datetime,@Reason Varchar(50),@rExit Int,
@EndDate Datetime,@DesignCode int,@Title varchar(20),@ServiceTime varchar(100),
@PreparedBy varchar(100),@CheckedBy varchar(100),@AuthorisedBy varchar(100),@NumYears Int,@NumMonths Int,@NumDays Int,@Approved bit,
@YaConversion Varchar(25),@Chapaa Decimal(20,6),@MwishoDate Datetime

select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo

select @Doexit = Doexit,@DoCalc = DoCalc,
@rExit = ReasonforExit,@DesignCode = DesignCode
from Members 
where SchemeNo = @schemeNo and MemberNo = @MemberNo

if @DoExit > @DoCalc
   select @doCalc = @DoExit

select @CurMonth = datepart(Month, @DoCalc)
select @curYear = datepart(Year,@DoCalc)
if @DesignCode is null select @DesignCode = 0

exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out
Select @eDate = EndDate,@sDate = StartDate from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod




select @MwishoDate = @eDate

select @EndDate = EndDate from schemeYears where SchemeNo = @SchemeNo and AcctPeriod = (@AcctPeriod - 1)

select @schemeName = schemeName from scheme where schemeCode = @schemeNo

select @Approved = UnRegInterest from ConfigYearEnd where SchemeNo = @schemeNo

if @Approved is null select @Approved = 0

if @Mode = 0
begin
declare GenCursor cursor for
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit, 
             		(Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,
            		 b.calcYear, b.interestrate, br.ExcessEmpCont,
                            br.Excessemprcont,b.withholdingTax, b.taxfreeLumpsum, b.vesting, 
                           b.comments,b.VestedCont
             from Members m
                       inner join UnregisteredBenefits br on m.schemeNo = br.schemeNO and m.memberNo = br.memberNo
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo
end
else if @Mode = 1
begin
     declare GenCursor cursor for
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit, 
             		(Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,
            		 b.calcYear, b.interestrate, br.ExcessEmpCont + br.ExcessVolcontr,
                            br.Excessemprcont + br.ExcessSpecial ,b.withholdingTax, b.taxfreeLumpsum, b.vesting, 
                           b.comments,b.VestedCont
             from Members m
                       inner join UnregisteredBenefits br on m.schemeNo = br.schemeNO and m.memberNo = br.memberNo
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo
end
 
open GenCursor

fetch from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @fullname, @curYear, @interest,
 @empclosing, @emprclosing, @withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont

while @@fetch_status =0

begin


        if @rExit > 0 select @eDate = @DoExit


        /* FOR AFFS */
        SELECT @EDate = @MwishoDate

        if @Mode = 0
        begin
        select @EmpOpening = mo.Excessemp - mo.EmpTax, @EmprOpening = mo.Excessempr - mo.EmprTax from
               UnregisteredBalances Mo where mo.schemeNo = @schemeNo and mo.memberNo = @MemberNo and mo.AcctPeriod = @AcctPeriod - 1
        
        if @EmpOpening is null select @EmpOpening = 0
        if @EmprOpening is null select @EmprOpening = 0

        select @empContribution = sum(cs.Excessempcont), @emprContribution = sum(cs.Excessemprcont)
        from UnregisteredContributionssummary cs                    
        where cs.SchemeNo = @schemeNo and cs.MemberNo = @memberNo and cs.AcctPeriod = @AcctPeriod  
        and  cs.Datepaid >= @sDate and cs.Datepaid <= @eDate and Surplus = 0
        end
        else if @Mode = 1
        begin
              select @EmpOpening = (mo.Excessemp + mo.ExcessVolContr)- (mo.EmpTax + mo.VolTax)
            , @EmprOpening = (mo.Excessempr + mo.ExcessSpecial) - (mo.EmprTax + mo.SpecTax) from
               UnregisteredBalances Mo where mo.schemeNo = @schemeNo and mo.memberNo = @MemberNo and mo.AcctPeriod = @AcctPeriod - 1
              if @EmpOpening is null select @EmpOpening = 0
               if @EmprOpening is null select @EmprOpening = 0

               select @empContribution = sum(cs.Excessempcont + cs.ExcessVolContr), @emprContribution = sum(cs.Excessemprcont + cs.ExcessSpecial)
                from UnregisteredContributionssummary cs                    
                where cs.SchemeNo = @schemeNo and cs.MemberNo = @memberNo and cs.AcctPeriod = @AcctPeriod  
                and  cs.Datepaid >= @sDate and cs.Datepaid <= @doCalc and Surplus = 0
        end

       

        if @EmpContribution is null select @EmpContribution = 0
        if @EmprContribution is null select @EmprContribution = 0

        Exec GetServiceTime @djpens,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out
        select @ServiceTime = cast(@NumYears as Varchar(2)) +' Years, '+ cast(@NumMonths as varchar(2))+'  months and '+cast(@NumDays as Varchar(2))+' days '

        select @pastService = (@NumYears * 12) + @NumMonths
       
        select @EmpInt = @empClosing - (@EmpOpening + @EmpContribution)

        select @EmprInt = @emprClosing - (@EmprOpening + @EmprContribution)

       
        if (@Vesting  = 100.00 )
               select @GrandTotal = @emprClosing + @EmpClosing
        else
               select @GrandTotal = @EmpClosing + @emprClosing * (@Vesting/100.000000)
        
        select  @TaxAmount = @EmpInt + @EmprInt

        if @TaxAmount < 0 select @TaxAmount = 0

        exec CalculateCorporateTax @TaxAmount, @WithholdingTax out

        if @Approved = 0 /* Scheme not Registered with KRA */
           SELECT @WithholdingTax = 0
        
        Select @Reason = ReasonDesc from ReasonforExit
        where ReasonCode = @rExit

       if @DesignCode > 0
          begin
          select @Title = Designation from Designation where DesignCode = @DesignCode

          select @FullName = upper(@Title) +'  '+@FullName
          end

        insert into #calculation (schemeNo, MemberNo, schemeName, fullname, dje, djpens, empopeningBal, emprOpeningBal,
                     empcontributions, emprContributions,empclosing, emprClosing,interest, dateofexit,
                     curYear, pastService, benefitsDC, TaxfreeLumpsum,withHoldingTax,Vesting, Comments, EmprInt, EmpInt, AmountPayable, TaxableAmount, LastYear,
                     Reason,EndDate,PreparedBy,CheckedBy,AuthorisedBy)
         
        values(@schemeNo, @memberNo,@schemeName, @fullname, @dje, @djpens, @empOpening, @emprOpening, @empcontribution, @emprContribution, @empclosing, @emprClosing,
                @interest, @dateofExit, @curYear, @ServiceTime, @GrandTotal, @taxfreeLumpsum, @withHoldingTax, @vesting, @comments, @EmprInt, @EmpInt, @GrandTotal - @WithholdingTax, @TaxAmount, @CurYear - 1,
               @Reason,@EndDate,@PreparedBy,@CheckedBy,@AuthorisedBy)


    
     fetch next from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @fullname, @curYear, @interest,
              @empclosing, @emprclosing, @withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont
end

close GenCursor
deallocate GenCursor


select * from #calculation
go

