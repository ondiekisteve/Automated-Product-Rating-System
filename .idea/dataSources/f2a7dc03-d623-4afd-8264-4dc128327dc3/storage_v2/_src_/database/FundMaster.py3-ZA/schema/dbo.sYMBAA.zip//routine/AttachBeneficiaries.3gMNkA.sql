CREATE PROCEDURE [dbo].[AttachBeneficiaries]
@SCHEMENO Int,
@MemberNo int,
@AttachNo int
--with Encryption
as

declare @AttachAmt float, @NumBenef int

select @AttachAmt = AttachAmount from CourtAttachments where 
SchemeNo = @SchemeNo and MemberNo = @MemberNo and AttachNo = @AttachNo

select @NumBenef = Count(*) from CourtAttachees where 
SchemeNo = @SchemeNo and MemberNo = @MemberNo and AttachNo = @AttachNo

if @NumBenef is null or @NumBenef = 0
   select @NumBenef = 1

select schemeNo, MemberNo, AttachNo,AttacheeNo, Attachee, (@AttachAmt/@NumBenef) as Attachment
from CourtAttachees where SchemeNo = @SchemeNo and MemberNo = @MemberNo and
AttachNo = @AttachNo
go

