CREATE PROCEDURE [dbo].[TestDistr]  
@ProcDate datetime  
--with encryption  
as  
  
if object_id('tempdb..#TestDistr') is null                                                          
  create table #TestDistr                                                          
  (                                                                                                         
    schemeNo int,                                                          
    schemeName varchar (100) not null,                                                          
    Balance float,  
    DrawDown float,  
    Reserve float,  
    TotalInc float,  
    TotalInt float,  
    Diff float,
    MemberBal float,
    ReserveBal float,
    DrawBal float                                                            
  )  
  
declare @schemeNo int,@schemeName varchar (100),@Balance float,@DrawDown float,@Reserve float,@TotalInt float,  
@AcctPeriod int,@MemberBal float,@ReserveBal float,@DrawBal float  
  
declare scsr cursor for  
select SchemeCode,SchemeName from scheme   
      Where schemeCode in (select schemeCode from Scheme where InvestmentScheme = 1328                
                           and PooledInvestment = 1)  
and SchemeCode in (select schemeNo from SchemeYears where EndDate = @ProcDate)  
  
open scsr  
fetch from scsr into @schemeNo,@schemeName  
while @@fetch_status = 0  
begin  
   select @AcctPeriod = AcctPeriod from schemeYears where schemeNo = @schemeNo and enddate  = @ProcDate  
     
   select @Balance = Balance,@DrawDown = DrawDown ,@Reserve = Reserve from distributionBalances  
   where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod  
  
   select @TotalInt = sum(EmpInt + EmprInt + VolInt + SpecInt),
   @MemberBal = sum(EmpCont + EmprCont + EmprVolCont + EmpVolCont + LockedIn + Transfer)  from memberOpeningBalances  
   where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod 

   select @ReserveBal = ReserveBalance from ReserveOpeningBalance where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod 

   Exec dbo.Proc_Get_DrawDown @schemeNo,@ProcDate,@DrawBal Out  

   if @Balance is null select @Balance = 0  
   if @DrawDown is null select @DrawDown = 0     
   if @Reserve is null select @Reserve = 0  
   if @TotalInt is null select @TotalInt = 0
   if @MemberBal is null select @MemberBal = 0
   if @DrawBal is null select @DrawBal = 0
   select @DrawBal = @DrawBal + @DrawDown
   if @ReserveBal is null select @ReserveBal = 0
     
     
   Insert into #TestDistr                                                           
  (                                                                                                         
    schemeNo,                                                          
    schemeName,                                                          
    Balance,  
    DrawDown,  
    Reserve,  
    TotalInc,  
    TotalInt,  
    Diff, MemberBal,ReserveBal,DrawBal)   
    Values(@schemeNo,@schemeName,@Balance,@DrawDown,@Reserve,@Balance + @DrawDown+ @Reserve,@TotalInt,@Balance-@TotalInt,@MemberBal,@ReserveBal,@DrawBal)                                               
        
   select @schemeNo = 0,@schemeName ='',@Balance =0,@DrawDown=0,@Reserve=0,@TotalInt=0,@AcctPeriod=0,@MemberBal=0,@ReserveBal=0,@DrawBal=0  
  
   fetch next from scsr into @schemeNo,@schemeName  
end  
close scsr  
deallocate scsr  
  
select * from #TestDistr order by schemeName
go

