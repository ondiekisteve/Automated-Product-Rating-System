CREATE PROCEDURE [dbo].[Proc_schAccess]
@uName VARCHAR(50)
--with Encryption
as

set nocount on

create table #tmpSchemeAcc
(
schCode varchar(15) not null,
schName varchar(120) not null,
allowed bit not null default 0
constraint pk_tmpSchemeAcc primary key (schName)
)

if @@error <> 0
begin
  set nocount off
  return
end

insert into #tmpSchemeAcc (schCode, schName) select schemeCode, schemeName from Scheme
update #tmpSchemeAcc
set allowed =
(select count(*) from schemeAccess sAcc
right join Scheme sTbl on sAcc.schemeCode = sTbl.schemeCode
where userName = @uName and sTbl.schemeName = #tmpSchemeAcc.schName)

if @@error <> 0 goto clean_up

select * from #tmpSchemeAcc

clean_up:
  drop table #tmpSchemeAcc
  set nocount off
  return
go

