CREATE PROCEDURE [dbo].[ShowFinancial]
@fincode varchar(15),
@finBrCode varchar(15)
--with Encryption
as

Select f.finName,fr.finBrName, fr.finCode, fr.finBrCode
from FinInstitutionsBranch fr
     inner Join FinInstitutions f on fr.finCode = F.finCode
where fr.finCode = @finCode and fr.finBrCode = @finBrCode
go

