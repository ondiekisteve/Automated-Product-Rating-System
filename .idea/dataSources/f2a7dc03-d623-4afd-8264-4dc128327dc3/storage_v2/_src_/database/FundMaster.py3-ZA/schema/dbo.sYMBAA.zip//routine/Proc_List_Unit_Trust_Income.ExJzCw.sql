CREATE PROCEDURE [dbo].[Proc_List_Unit_Trust_Income]      
@schemeNo Int,          
@StartDate Datetime,      
@EndDate Datetime      
--with Encryption      
as      
select TransDate,sum(Amount) as TotalIncome,sum(PerfFees) as TotalFees     
from TBL_Unit_Trust_Income      
where ischemeNo = @schemeNo and TransDate >= @StartDate and TransDate <= @EndDate     
Group by TransDate
go

