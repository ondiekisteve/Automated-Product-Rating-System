CREATE PROCEDURE [dbo].[changePass]    
@userName varchar(100),    
@oldPass varchar(100),   
@newPass varchar(100)    
--with Encryption    
as   
Exec DBO.proc_Change_Pass @newPass, @userName
go

