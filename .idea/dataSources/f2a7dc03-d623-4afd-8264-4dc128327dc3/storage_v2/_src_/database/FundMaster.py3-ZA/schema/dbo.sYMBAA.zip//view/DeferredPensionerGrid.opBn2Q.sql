CREATE VIEW [dbo].[DeferredPensionerGrid]  
--with encryption  
AS  
SELECT m.schemeNo, m.memberno, m.PayrollNo, m.IDNumber, m.SName, m.fname,   
    (m.FName + ' ' + m.ONames) AS OtherNames,   
    (m.SName + ', ' + m.FName + ' ' + m.ONames)   
    AS Fullname,p.PensionStartDate,p.Pensioner  
FROM Deferredpensioner p INNER JOIN  
    Members m ON p.SchemeNo = m.schemeNo AND   
    p.MemberNo = m.memberNo
go

