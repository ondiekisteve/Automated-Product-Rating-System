CREATE PROCEDURE [dbo].[Proc_RentPayable]
@SCHEMENO Int,
@ProperCode Int,
@UnitNo varchar(15),
@TenantCode Int,
@PayMonth int,
@PayYear int,
@GenMode Int
--with Encryption
as

declare @PropCode int, 
@Rent float,@MonthName varchar(30),
@Balance float,@cDate Datetime,@Advance float,
@Rem float,@cRent float,@Service float,@cService float,
@Processed bit,@TaxExempt Bit,@PropType Int,@vatRate float,@WithRate float,
@Threshold float,@VAT float,@WithholdingTax float,@vatService float,
@RentType Bit,@RentPerMeter float,@ServicePerMeter float,@Area float,@analyze bit,
@DeductMode Bit,@PayFreq Int,@StartDate Datetime,@AlMonth Int,@AlMonth2 Int,
@AlMonth3 Int,@AlMonth4 Int,@RentFactor Int,@Tumwe Int,@Check Int,
@RentI float,@ServiceI float,@VatI float,@WithI float,@VATServiceI float,@TenantName Varchar(120),
@DebtorCode Int,@Description Varchar(100),@Receipt Int,@Descr Varchar(120),
@RentPreBalance float,@PrePayment float,@LastDate Datetime,@Parking float,@Parkingi float,
@EndDate Datetime,@AcctPeriod Int

Exec GetAccountingPeriodInaYear @schemeNo,@PayMonth,@PayYear,@AcctPeriod Out

select @Receipt = Max(Receipt) from Receipts

if @Receipt is null select @Receipt = 0

Exec GetMonthName @PayMonth,@Description out

select @Description = @Description+', '+cast(@PayYear as Varchar(4))

Exec GetFirstDate @PayMonth,@PayYear, @cDate out

Exec GetLastDate @PayMonth,@PayYear,@LastDate Out

if @cDate > 'Dec 31,2003' select @Analyze = 0
else select @Analyze = 1

if @GenMode = 1 /* One Property */
begin  --- 1
      select @PropType = PropertyType from Property
      where SchemeNo = @schemeNo and PropertyCode = @ProperCode

     if Exists (select * from  RentInvoice where SchemeNo = @schemeNo and PropertyCode = @ProperCode and
                         PayMonth = @PayMonth and PayYear = @PayYear)
             begin
                     Raiserror ('Rent Receivable Processing  for %s already processed',16,1,@MonthName)
                     RollBack Tran
             end
           else
     begin -- 2
       IF @PropType <> 6
           begin
            /* Rent Receivable per Property Full Rent*/
            declare UnitCsr Cursor for
            select t.UnitNo, l.Rent, l.ServiceCharge,T.TenantCode,
            t.TaxExempt,l.RentMode,l.RentPerMeter,l.ServicePerMeter,l.Area,
            l.DeductionsMode,l.PaymentFreq,l.StartDate,l.ParkingFees
            from Tenants t
            Inner Join Leases l on 
                    t.SchemeNo = l.SchemeNo
                    and t.PropertyCode = l.PropertyCode 
           and t.UnitNo = l.UnitNo 
           and t.TenantCode = l.TenantCode 
                    and l.StartDate <= @cDate and l.EndDate >= @cDate
                    AND L.LeaseCancelled = 0
            inner Join Units u on  t.SchemeNo = u.SchemeNo
                    and t.PropertyCode =u.PropertyCode 
                    and t.UnitNo = u.UnitNo 
                    and u.UnitStatus = 1
             where t.SchemeNo = @SchemeNo 
             and t.PropertyCode = @ProperCode 
           
             Open UnitCsr

             fetch from UnitCsr into @UnitNo, @Rent,@Service, @TenantCode,@TaxExempt,
                @RentType,@RentPerMeter,@ServicePerMeter,@Area,
                                     @DeductMode,@PayFreq,@StartDate,@Parking
             while @@fetch_Status = 0
             begin
                if @Parking is null select @Parking = 0.0

                select @Receipt = @Receipt + 1

                if @PayFreq = 1 /* Monthly */
                   begin 
                   select @RentFactor = 1,@AlMonth = @PayMonth
                   end
                else
                   begin
                      if @PayFreq = 2 /* Quarterly */
                         begin
                          select @RentFactor = 3
                          select @AlMonth = DatePart(Month,@StartDate)
                          
                          if @AlMonth <> @PayMonth
                             select @AlMonth = @AlMonth + 3
  				else
				select @AlMonth=@AlMonth
                             if @AlMonth > 12
                                select @AlMonth = @AlMonth - 12
                                   
                         end
                      else if @PayFreq = 3 /* Half Yearly */
                         begin
                             select @RentFactor = 6
                             select @AlMonth = DatePart(Month,@StartDate)
                          
                             if @AlMonth <> @PayMonth
                                select @AlMonth = @AlMonth + 6
                                if @AlMonth > 12
                                   select @AlMonth = @AlMonth - 12
                         end
                     else if @PayFreq = 4 /* Annually */
                         begin
                             select @RentFactor = 12
                             select @AlMonth = DatePart(Month,@StartDate)
                         end
                   end

                if @RentType = 1 /* Rent Per Square Meter */
                   begin
                      select @Rent = @RentPerMeter * @Area,@Service = @ServicePerMeter * @Area,
                      @Parking = @Parking
                   end

                select @Tumwe = @RentFactor
                select @RentFactor = 1

                
                select @Rent = @Rent * @RentFactor,@Service = @Service * @RentFactor,
                @Renti = @Rent *  @Tumwe,@Servicei = @Service *  @Tumwe ,@ParkingI = @Parking *  @Tumwe

                /* Calculate V.A.T */
                if @PropType = 1 /* Commercial Properties */
                   begin
                       If @TaxExempt = 0
                          select @VAT = @Rent * @vatRate/100.00000,
                          @vatService = @Service * @vatRate/100.000,
                          @VatI = @Renti *@VATRate/100.00,@VatServiceI = @ServiceI*@VATRate/100.00
                       else
                          select @vat = 0,@vatService = 0
                   end
                else
                   select @vat = 0,@vatService = 0

                /* Calculate WithholdingTAX */
               if @Rent > @Threshold
                  begin
                     select @WithholdingTax = @Rent * (@WithRate/100.000000),
                     @WithI = @Renti*(@WithRate/100.000000)
                  end
               else
                  select @WithholdingTax = 0
               

               if @Vat is null select @Vat = 0
               if @WithholdingTax is null select @WithholdingTax = 0
               if @VatService is null select @VatService = 0
               if @VATi is null select @VATi = 0
               if @WithI is null select @WithI = 0
               if @VATServiceI is null select @VATServiceI = 0

               if @DeductMode = 0
                  begin
                       select @Rent = @Rent - (@Vat + @WithholdingTax),
                       @Service = @Service - @VatService,  
                       @RentI = @RentI - (@VATi+ @WithI),@ServiceI = @ServiceI - @VATServiceI
                  end

              if  ((@PayMonth =1 and  ((@AlMonth =1) or (@AlMonth =4) or (@AlMonth =7) or (@AlMonth =10)))
              or (@PayMonth =2 and  ((@AlMonth =2) or (@AlMonth =5) or (@AlMonth =8) or (@AlMonth =11)))
	      or (@PayMonth =3 and  ((@AlMonth =3) or (@AlMonth =6) or (@AlMonth =9) or (@AlMonth =12)))   
	      or (@PayMonth =4 and  ((@AlMonth =4) or (@AlMonth =7) or (@AlMonth =10) or (@AlMonth =1))) 
		or (@PayMonth =5 and  ((@AlMonth =8) or (@AlMonth =11) or (@AlMonth =2) or (@AlMonth =5))) 
		or (@PayMonth =6 and  ((@AlMonth =9) or (@AlMonth =12) or (@AlMonth =3) or (@AlMonth =6))) 
		or (@PayMonth =7 and  ((@AlMonth =7) or (@AlMonth =10) or (@AlMonth =1) or (@AlMonth =4)))

		or (@PayMonth =8 and  ((@AlMonth =11) or (@AlMonth =2) or (@AlMonth =5) or (@AlMonth =8)))
		or (@PayMonth =9 and  ((@AlMonth =9) or (@AlMonth =12) or (@AlMonth =3) or (@AlMonth =6))) 
		or (@PayMonth =10 and  ((@AlMonth =1) or (@AlMonth =4) or (@AlMonth =7) or (@AlMonth =10))) 
		or (@PayMonth =11 and  ((@AlMonth =11) or (@AlMonth =2) or (@AlMonth =5) or (@AlMonth =8)))
		or (@PayMonth =12 and  ((@AlMonth =12) or (@AlMonth =3) or (@AlMonth =6) or (@AlMonth =9))))
             
                 select @Check = 0
              else 
                 Select @Check = 1

              if @Check = 1
                 begin
                      select @Renti=0,@ServiceI=0,@VATi = 0,@WithI =0,@VATServiceI= 0,@Parkingi = 0
                 end

               select @AlMonth = @PayMonth

               if @AlMonth = @PayMonth 
                 begin
                   if @Check = 0 /* Start Rent Mode */
                    begin  
                        select @TenantName = TenantName from Tenants
                        where SchemeNo = @schemeNo and PropertyCode = @ProperCode
                        and TenantCode = @TenantCode

                       

                        if Exists ( select * from DebtorsRegister where DebtorType = 8
                                    and Debtor = @TenantName)
                                  select @DebtorCode = DebtorCode from DebtorsRegister where DebtorType = 8
                                  and Debtor = @TenantName
                        else  
                            begin
                                 Insert Into DebtorsRegister (SchemeNo,DebtorType,Debtor)
                                 Values(@SchemeNo,8,@TenantName)

                                  select @DebtorCode = DebtorCode from DebtorsRegister where DebtorType = 8
                                  and Debtor = @TenantName
                            end
                        
                         select @Descr = @TenantName+' - Rent receivable -'+@Description
                         
                         if not Exists ( select * from Receipts where SchemeNo = @schemeNo and 
                                         ReceiptDate = @cDate and Amount = @Rent + @Service + @Parking and Description = @Descr)
                            begin
                     Insert into Receipts (SchemeNo,Receipt,ReceiptDate,Description,Amount,DebtorCode,PropCode)
                                          Values (@SchemeNo,@Receipt,@cDate,@Descr,@Renti + @ServiceI + @ParkingI,@DebtorCode,@ProperCode)

                                     Insert into ReceiptsInvoice(SchemeNo,ReceiptNo,Particulars,Quantity,UnitPrice)
                                                           Values(@schemeNo,@Receipt,@Descr,1,@Renti + @ServiceI + @ParkingI)
                            end
                     end /* End Rent Mode */ 
  
               if @Rent>0 
                  IF NOT EXISTS (select * from RentInvoice where schemeNo = @schemeNo and PropertyCode = @ProperCode
                                 and UnitNo = @UnitNo and TenantCode = @TenantCode and 
                                 PayMonth = @PayMonth and PayYear = @PayYear)
                       Insert Into RentInvoice(schemeNo, PropertyCode, UnitNo, TenantCode, 
                             PayMonth, PayYear, Rent, ServiceCharge,Balance,InvoiceDate,
                             VAT,VATService,WithholdingTax,Analyze,
                             RentInvoiced,ServiceInvoiced,VATInvoiced,WithInvoiced,VATServiceInvoiced,
                             Parking,ParkingInvoiced,AcctPeriod)
                       Values (@SchemeNo, @ProperCode, @UnitNo, @TenantCode, @PayMonth, @PayYear,
                         @Rent,@Service,0,@cDate,@vat,@vatService,@WithholdingTax,@Analyze,
                          @Renti,@ServiceI,@VATI,@WithI,@VATServiceI,@Parking,@ParkingI,@AcctPeriod)
                 end
                 select @balance=0

                 select @rent=0
                 Select @Rem = 0
                 Select @Rent = 0,@Service = 0,@vat=0,@vatService =0,@withholdingTax = 0,
                 @Parking = 0.0

                 fetch next from UnitCsr into @UnitNo, @Rent, @Service,@TenantCode,@TaxExempt,
                                          @RentType,@RentPerMeter,@ServicePerMeter,@Area,
                                              @DeductMode,@PayFreq,@StartDate,@Parking
             end
             Close UnitCsr

             Deallocate UnitCsr
          


             /* End Full Rent */

             /* Start Partial Rent - Lease Starting within the Month */
            declare UnitCsr Cursor for
            select t.UnitNo, l.Rent, l.ServiceCharge,T.TenantCode,
            t.TaxExempt,l.RentMode,l.RentPerMeter,l.ServicePerMeter,l.Area,
            l.DeductionsMode,l.PaymentFreq,l.StartDate,l.ParkingFees
            from Tenants t
            Inner Join Leases l on 
                    t.SchemeNo = l.SchemeNo
                    and t.PropertyCode = l.PropertyCode 
                    and t.UnitNo = l.UnitNo 
                    and t.TenantCode = l.TenantCode 
                    and l.StartDate > @cDate and l.EndDate >= @LastDate
                    AND L.LeaseCancelled = 0
             inner Join Units u on  t.SchemeNo = u.SchemeNo
                    and t.PropertyCode =u.PropertyCode 
                    and t.UnitNo = u.UnitNo 
                    and u.UnitStatus = 1
             where t.SchemeNo = @SchemeNo 
             and t.PropertyCode = @ProperCode 
          
            
             Open UnitCsr

             fetch from UnitCsr into @UnitNo, @Rent,@Service, @TenantCode,@TaxExempt,
                                     @RentType,@RentPerMeter,@ServicePerMeter,@Area,
                                     @DeductMode,@PayFreq,@StartDate,@Parking
             while @@fetch_Status = 0
             begin
                select @Receipt = @Receipt + 1

                if @PayFreq = 1 
                   begin 
                   select @RentFactor = 1,@AlMonth = @PayMonth
                   end
                else
                   begin
                      if @PayFreq = 2
                         begin
                          select @RentFactor = 3
                          select @AlMonth = DatePart(Month,@StartDate)
                          
                          if @AlMonth <> @PayMonth
                             select @AlMonth = @AlMonth + 3
                             if @AlMonth > 12
            select @AlMonth = @AlMonth - 12
end
               else if @PayFreq = 3
                 begin
                                   select @RentFactor = 6
                                   select @AlMonth = DatePart(Month,@StartDate)
                          
                                   if @AlMonth <> @PayMonth
                                     select @AlMonth = @AlMonth + 6
                                     if @AlMonth > 12
                                        select @AlMonth = @AlMonth - 12
                         end
                     else if @PayFreq = 4
                         begin
                                   select @RentFactor = 12
                                   select @AlMonth = DatePart(Month,@StartDate)
                         end
                   end

                if @RentType = 1 /* Rent Per Square Meter */
                   begin
                      select @Rent = @RentPerMeter * @Area,@Service = @ServicePerMeter * @Area,@Parking = @Parking 
                   end

                select @Tumwe = @RentFactor
                select @RentFactor = 1

                
                /* Calculate Fraction of Rent */
                Select @Rent = @Rent * (cast((DateDiff(Day,@StartDate,@LastDate)) as float)  / cast(DatePart(Day,@LastDate) as float))
                Select @Service = @Service * (cast((DateDiff(Day,@StartDate,@LastDate)) as float)  / cast(DatePart(Day,@LastDate) as float))

                select @Rent = @Rent * @RentFactor,@Service = @Service * @RentFactor,@Parking = @Parking * @RentFactor,
                @Renti = @Rent *  @Tumwe,@Servicei = @Service *  @Tumwe ,@ParkingI = @Parking * @Tumwe 

                /* Calculate V.A.T */
                if @PropType = 1/*Commercial Properties */
                   begin
                       If @TaxExempt = 0
                          select @VAT = @Rent * @vatRate/100.00000,
                          @vatService = @Service * @vatRate/100.000,
                          @VatI = @Renti *@VATRate/100.00,@VatServiceI = @ServiceI*@VATRate/100.00
                       else
                          select @vat = 0,@vatService = 0
                   end
                else
                   select @vat = 0,@vatService = 0

                /* Calculate WithholdingTAX */
               if @Rent > @Threshold
                  begin
                     select @WithholdingTax = @Rent * (@WithRate/100.000000),
                     @WithI = @Renti*(@WithRate/100.000000)
                  end
               else
                  select @WithholdingTax = 0
               

               if @Vat is null select @Vat = 0
          if @WithholdingTax is null select @WithholdingTax = 0
               if @VatService is null select @VatService = 0
               if @VATi is null select @VATi = 0
               if @WithI is null select @WithI = 0
               if @VATServiceI is null select @VATServiceI = 0

               if @DeductMode = 0
                 select @Rent = @Rent - (@Vat + @WithholdingTax),
                       @Service = @Service - @VatService,  
                       @RentI = @RentI - (@VATi+ @WithI),@ServiceI = @ServiceI - @VATServiceI
 

              if @AlMonth = @PayMonth select @Check = 0
              else Select @Check = 1

              if @Check = 1
                 begin
                      select @Renti=0,@ServiceI=0,@VATi = 0,@WithI =0,@VATServiceI= 0,@ParkingI = 0.0
                end

               select @AlMonth = @PayMonth

               if @AlMonth = @PayMonth
                 begin
                     if @Check = 0 /* Start Rent Mode */    
                       begin
                        select @TenantName = TenantName from Tenants
                        where SchemeNo = @schemeNo and PropertyCode = @ProperCode
                        and TenantCode = @TenantCode

                    if Exists ( select * from DebtorsRegister where DebtorType = 8
              and Debtor = @TenantName)
                                  select @DebtorCode = DebtorCode from DebtorsRegister where DebtorType = 8
                                  and Debtor = @TenantName
                        else  
                            begin
                                 Insert Into DebtorsRegister (SchemeNo,DebtorType,Debtor)
                                 Values(@SchemeNo,8,@TenantName)

                                  select @DebtorCode = DebtorCode from DebtorsRegister where DebtorType = 8
                                  and Debtor = @TenantName
                            end
                        
                         select @Descr = @TenantName+' - Rent receivable -'+@Description
                         
                         if not Exists ( select * from Receipts where SchemeNo = @schemeNo and 
                                         ReceiptDate = @cDate and Amount = @Rent + @Service + @Parking and Description = @Descr)
                            begin
                                     Insert into Receipts (SchemeNo,Receipt,ReceiptDate,Description,Amount,DebtorCode,PropCode)
                                          Values (@SchemeNo,@Receipt,@cDate,@Descr,@Renti + @ParkingI + @ServiceI,@DebtorCode,@ProperCode)


                                     Insert into ReceiptsInvoice(SchemeNo,ReceiptNo,Particulars,Quantity,UnitPrice)
                                                           Values(@schemeNo,@Receipt,@Descr,1,@Renti + @ParkingI + @ServiceI)

                            end
                      end /* End Rent Mode */ 
     
               IF NOT EXISTS (select * from RentInvoice where schemeNo = @schemeNo and PropertyCode = @ProperCode
                                 and UnitNo = @UnitNo and TenantCode = @TenantCode and 
                                 PayMonth = @PayMonth and PayYear = @PayYear)
                 Insert Into RentInvoice(schemeNo, PropertyCode, UnitNo, TenantCode, 
                             PayMonth, PayYear, Rent, ServiceCharge,Balance,InvoiceDate,
                             VAT,VATService,WithholdingTax,Analyze,
                             RentInvoiced,ServiceInvoiced,VATInvoiced,WithInvoiced,VATServiceInvoiced,
                             Parking,ParkingInvoiced,AcctPeriod)
                 Values (@SchemeNo, @ProperCode, @UnitNo, @TenantCode, @PayMonth, @PayYear,
                         @Rent,@Service,0,@cDate,@vat,@vatService,@WithholdingTax,@Analyze,
                          @Renti,@ServiceI,@VATI,@WithI,@VATServiceI,@Parking,@ParkingI,@AcctPeriod)
                 end
                 select @balance=0
                 select @rent=0
                 Select @Rem = 0
                 Select @Rent = 0,@Service = 0,@vat=0,@vatService =0,@withholdingTax = 0,@Parking = 0

               fetch next from UnitCsr into @UnitNo, @Rent, @Service,@TenantCode,@TaxExempt,
                                              @RentType,@RentPerMeter,@ServicePerMeter,@Area,
                                              @DeductMode,@PayFreq,@StartDate,@Parking
             end
             Close UnitCsr

            Deallocate UnitCsr
             /* End Lease Starting within the Month */


             /* Start Partial Rent - Lease Ending within the Month */
            declare UnitCsr Cursor for
            select t.UnitNo, l.Rent, l.ServiceCharge,T.TenantCode,
            t.TaxExempt,l.RentMode,l.RentPerMeter,l.ServicePerMeter,l.Area,
            l.DeductionsMode,l.PaymentFreq,l.StartDate,l.ParkingFees,
            l.EndDate
            from Tenants t
            Inner Join Leases l on 
                    t.SchemeNo = l.SchemeNo
                    and t.PropertyCode = l.PropertyCode 
                    and t.UnitNo = l.UnitNo 
                    and t.TenantCode = l.TenantCode 
                    and l.StartDate < @cDate and l.EndDate <= @LastDate
                    AND L.LeaseCancelled = 0
             inner Join Units u on  t.SchemeNo = u.SchemeNo
                    and t.PropertyCode =u.PropertyCode 
                    and t.UnitNo = u.UnitNo 
                    and u.UnitStatus = 1
             where t.SchemeNo = @SchemeNo 
             and t.PropertyCode = @ProperCode 
          
            
             Open UnitCsr

             fetch from UnitCsr into @UnitNo, @Rent,@Service, @TenantCode,@TaxExempt,
                                     @RentType,@RentPerMeter,@ServicePerMeter,@Area,
                                     @DeductMode,@PayFreq,@StartDate,@Parking,@EndDate
             while @@fetch_Status = 0
             begin
                select @Receipt = @Receipt + 1

                if @PayFreq = 1 
                   begin 
                   select @RentFactor = 1,@AlMonth = @PayMonth
                   end
                else
                   begin
                      if @PayFreq = 2
                         begin
                          select @RentFactor = 3
                          select @AlMonth = DatePart(Month,@StartDate)
                          
                          if @AlMonth <> @PayMonth
                             select @AlMonth = @AlMonth + 3
                             if @AlMonth > 12

                                select @AlMonth = @AlMonth - 12
                         end
                      else if @PayFreq = 3
                         begin
                                   select @RentFactor = 6
                                   select @AlMonth = DatePart(Month,@StartDate)
                          
                                   if @AlMonth <> @PayMonth
                                     select @AlMonth = @AlMonth + 6
                                     if @AlMonth > 12
                                        select @AlMonth = @AlMonth - 12
                         end
                     else if @PayFreq = 4
                         begin
                                   select @RentFactor = 12
                                   select @AlMonth = DatePart(Month,@StartDate)
                         end
                   end

                if @RentType = 1 /* Rent Per Square Meter */
                   begin
                      select @Rent = @RentPerMeter * @Area,@Service = @ServicePerMeter * @Area,@Parking = @Parking 
                   end

                select @Tumwe = @RentFactor
                select @RentFactor = 1

                
                /* Calculate Fraction of Rent */
                Select @Rent = @Rent * (cast((DatePart(Day,@EndDate)) as float)  / cast(DatePart(Day,@LastDate) as float))
                Select @Service = @Service * (cast((DatePart(Day,@EndDate)) as float)  / cast(DatePart(Day,@LastDate) as float))

                select @Rent = @Rent * @RentFactor,@Service = @Service * @RentFactor,@Parking = @Parking * @RentFactor,
                @Renti = @Rent * @Tumwe,@Servicei = @Service * @Tumwe ,@ParkingI = @Parking * @Tumwe 

                /* Calculate V.A.T */
                if @PropType = 1/*Commercial Properties */
                   begin
                       If @TaxExempt = 0
                          select @VAT = @Rent * @vatRate/100.00000,
                          @vatService = @Service * @vatRate/100.000,
                          @VatI = @Renti *@VATRate/100.00,@VatServiceI = @ServiceI*@VATRate/100.00
                       else
                          select @vat = 0,@vatService = 0
                   end
                else
                   select @vat = 0,@vatService = 0

                /* Calculate WithholdingTAX */
               if @Rent > @Threshold
                  begin
                     select @WithholdingTax = @Rent * (@WithRate/100.000000),
                     @WithI = @Renti*(@WithRate/100.000000)
                  end
               else
                  select @WithholdingTax = 0
               

               if @Vat is null select @Vat = 0
          if @WithholdingTax is null select @WithholdingTax = 0
               if @VatService is null select @VatService = 0
        if @VATi is null select @VATi = 0
               if @WithI is null select @WithI = 0
               if @VATServiceI is null select @VATServiceI = 0

               if @DeductMode = 0
                 select @Rent = @Rent - (@Vat + @WithholdingTax),
                       @Service = @Service - @VatService,  
                       @RentI = @RentI - (@VATi+ @WithI),@ServiceI = @ServiceI - @VATServiceI
 

              if @AlMonth = @PayMonth select @Check = 0
              else Select @Check = 1

              if @Check = 1
                 begin
                      select @Renti=0,@ServiceI=0,@VATi = 0,@WithI =0,@VATServiceI= 0,@ParkingI = 0.0
                 end

               select @AlMonth = @PayMonth

               if @AlMonth = @PayMonth
                 begin
                     if @Check = 0 /* Start Rent Mode */    
                       begin
                        select @TenantName = TenantName from Tenants
                        where SchemeNo = @schemeNo and PropertyCode = @ProperCode
                        and TenantCode = @TenantCode



                        if Exists ( select * from DebtorsRegister where DebtorType = 8
                                    and Debtor = @TenantName)
                                  select @DebtorCode = DebtorCode from DebtorsRegister where DebtorType = 8
                                  and Debtor = @TenantName
                        else  
                            begin
                                 Insert Into DebtorsRegister (SchemeNo,DebtorType,Debtor)
                                 Values(@SchemeNo,8,@TenantName)

                                  select @DebtorCode = DebtorCode from DebtorsRegister where DebtorType = 8
                                  and Debtor = @TenantName
                            end
                        
                         select @Descr = @TenantName+' - Rent receivable -'+@Description
                         
                         if not Exists ( select * from Receipts where SchemeNo = @schemeNo and 
                                         ReceiptDate = @cDate and Amount = @Rent + @Service + @Parking and Description = @Descr)
                            begin
                                     Insert into Receipts (SchemeNo,Receipt,ReceiptDate,Description,Amount,DebtorCode,PropCode)
                                          Values (@SchemeNo,@Receipt,@cDate,@Descr,@Renti + @ParkingI + @ServiceI,@DebtorCode,@ProperCode)

                                     Insert into ReceiptsInvoice(SchemeNo,ReceiptNo,Particulars,Quantity,UnitPrice)
                                                           Values(@schemeNo,@Receipt,@Descr,1,@Renti + @ParkingI + @ServiceI)

                            end
                      end /* End Rent Mode */ 
     
                 if Exists (Select * from RentInvoice where schemeNo = @schemeNo and PropertyCode = @ProperCode
                            and UnitNo = @UnitNo and TenantCode = @TenantCode and PayMonth = @PayMonth
                            and PayYear = @PayYear)
                    update RentInvoice set Rent = Rent + @Rent,ServiceCharge = ServiceCharge + @Service,
              RentInvoiced = RentInvoiced + @Renti,ServiceInvoiced = ServiceInvoiced + @ServiceI,
                           AcctPeriod = @AcctPeriod
                    where schemeNo = @schemeNo and PropertyCode = @ProperCode
                          and UnitNo = @UnitNo and TenantCode = @TenantCode and PayMonth = @PayMonth
                          and PayYear = @PayYear
                 else
                    IF NOT EXISTS (select * from RentInvoice where schemeNo = @schemeNo and PropertyCode = @ProperCode
                                 and UnitNo = @UnitNo and TenantCode = @TenantCode and 
                                 PayMonth = @PayMonth and PayYear = @PayYear)
                    Insert Into RentInvoice(schemeNo, PropertyCode, UnitNo, TenantCode, 
                             PayMonth, PayYear, Rent, ServiceCharge,Balance,InvoiceDate,
                             VAT,VATService,WithholdingTax,Analyze,
                             RentInvoiced,ServiceInvoiced,VATInvoiced,WithInvoiced,VATServiceInvoiced,
                        Parking,ParkingInvoiced,AcctPeriod)
                    Values (@SchemeNo, @ProperCode, @UnitNo, @TenantCode, @PayMonth, @PayYear,
                         @Rent,@Service,0,@cDate,@vat,@vatService,@WithholdingTax,@Analyze,
                  @Renti,@ServiceI,@VATI,@WithI,@VATServiceI,@Parking,@ParkingI,@AcctPeriod)
                 end
                 select @balance=0
                 select @rent=0
                 Select @Rem = 0
                 Select @Rent = 0,@Service = 0,@vat=0,@vatService =0,@withholdingTax = 0,@Parking = 0

               fetch next from UnitCsr into @UnitNo, @Rent, @Service,@TenantCode,@TaxExempt,
                                              @RentType,@RentPerMeter,@ServicePerMeter,@Area,
                                              @DeductMode,@PayFreq,@StartDate,@Parking,@EndDate
             end
             Close UnitCsr

            Deallocate UnitCsr
            /* End Lease Ending within the Month */
             end   
            --Exec PostExpectedRent @schemeNo,@cDate,@Propercode,@PayMonth,@PayYear
       end
end
go

