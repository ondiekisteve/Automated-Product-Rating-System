CREATE PROCEDURE [dbo].[Proc_Loans_Valuation]
@schemeNo int,
@TransDate datetime,
@AsAtDate datetime,
@TransMode Int, /* 0 - AsAtDate, 1 - Between Cut Dates */
@InterestDue decimal(20,6) out,
@CapitalDue decimal(20,6) out,
@CarryValue decimal(20,6) out,
@MedicalLevy decimal(20,2) out
as

if object_id('tempdb..#Loan_Val') is null                    
                    
begin                    
create table #Loan_Val                    
(                   
        [OffNo] Int Identity(1,1) primary key,            
        [MortgageNo] [Int],
        [LoanName][varchar](120),
        DateApplied datetime,
        Loan decimal(20,2),
        CapRepaid decimal(20,2),
        LoanBF decimal(20,2),
        IntRateDesc varchar(255),
        IntCalcMode varchar(20),
        CapitalDue decimal(20,2),
        InterestDue decimal(20,2),
        MedicalLevy decimal(20,2),
        CarryValue decimal(20,2)                                     
)                              
end  

declare @CapRepaid decimal(20,6),
@MortgageNo Int,@LoanName varchar(120),@DateApplied datetime,@Loan decimal(20,2),@IntCalcMode varchar(20),
@MedLevy decimal(20,2),@IntRateDesc varchar(255)

select @MedLevy = Max(MedicalLevy) from TBL_Invest_TaxRates                                                
where schemeNo = @schemeNo and InvestCode = 9  

if @MedLevy is null select @MedLevy = 0

declare LoanCsr Cursor for
select i.InvCode,i.InvName,l.Loan,l.DateApplied, case l.IntCalcMode when 0 then 'Fixed' when 1 then 'Reducing Balance' end
from TBL_Loans l
     inner Join Investments i on l.schemeNo = i.schemeNo and l.MortgageNo = i.InvCode
where l.SchemeNo = @SchemeNo

Open LoanCsr
fetch from LoanCsr into @MortgageNo,@LoanName,@Loan,@DateApplied,@IntCalcMode
while @@fetch_status = 0
begin
  Exec Proc_Loans_Value @schemeNo,@MortgageNo,@TransMode,@TransDate,@AsAtDate,       
                        @CapRepaid Out,@InterestDue out,@CapitalDue out,@CarryValue Out,@IntRateDesc out
  
  if @MedLevy > 0
     select @MedicalLevy = @InterestDue * (@MedLevy/100.000)
  else
     select @MedicalLevy = 0.0

  Insert Into #Loan_Val(MortgageNo,LoanName,DateApplied,Loan,CapRepaid,LoanBF,
                        IntRateDesc,IntCalcMode,CapitalDue,InterestDue,MedicalLevy,CarryValue)
              Values(@MortgageNo,@LoanName,@DateApplied,@Loan,@CapRepaid,@Loan - @CapRepaid,
                     @IntRateDesc,@IntCalcMode,@CapitalDue,@InterestDue,@MedicalLevy,@CarryValue - @MedicalLevy)  

  select @MortgageNo=0,@LoanName='',@Loan=0,@IntCalcMode = '',@MedicalLevy = 0,@IntRateDesc=''
  fetch next from LoanCsr into @MortgageNo,@LoanName,@Loan,@DateApplied,@IntCalcMode
end
close LoanCsr
Deallocate LoanCsr

SELECT @InterestDue  = sum(InterestDue),@CapitalDue = sum(CapitalDue),
       @CarryValue = sum(CarryValue),@MedicalLevy = sum(MedicalLevy) from #Loan_Val
go

