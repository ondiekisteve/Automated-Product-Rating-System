CREATE PROCEDURE [dbo].[DefineInvestment]
@InvestDesc varchar(70)
--with Encryption
as

declare @InvestCode int

if (select count(*) from InvestmentTypes) >0
  select @InvestCode = Max(InvestCode) from InvestmentTypes
else
  select @InvestCode = 0

if (select count (*) from InvestmentTypes where InvestDesc = @InvestDesc) >0 
   begin
         raiserror('The Investment Type has already been Defined',16,1)
         return
   end
else
  begin
        Insert into InvestmentTypes (InvestCode, InvestDesc)
                        values (@InvestCode + 1, @InvestDesc)


 end
go

