/*                        















MODIFICATIONS:                        















11/03/2004                        















                        















Added :                        















           Fields:                        















           PreparedBy,CheckedBy,AuthorisedBy                        















           Variables:                        















           @PreparedBy,@CheckedBy,@AuthorisedBy                        















           Code:                        















           select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo                        















           Insert these extra fields in the Temp Table                        















*/

CREATE PROCEDURE [dbo].[Repcalculationsheet_un] @SCHEMENO INT,

                                                @memberNo INT,

                                                @Mode     INT,

                                                @Batch_Id INT /* 0 - Per Member, 1 - Batches */

--with Encryption                        

AS

    SET nocount ON



    IF Object_id('tempdb..#Calculation') IS NULL

      BEGIN

          CREATE TABLE #Calculation

            (

               [SchemeNo]          [VARCHAR] (15) NOT NULL,

               [MemberNo]          [INT] NOT NULL,

               [schemeName]        [VARCHAR](100) NULL,

               [fullname]          [VARCHAR](100) NULL,

               [DJE]               [DATETIME] NULL,

               [djpens]            [DATETIME] NULL,

               [EmpOpeningBal]     [FLOAT] NULL,

               [EmprOpeningBal]    [FLOAT] NULL,

               [EmpContributions]  [FLOAT] NULL,

               [EmprContributions] [FLOAT] NULL,

               [EmpClosing]        [FLOAT] NULL,

               [EmprClosing]       [FLOAT] NULL,

               [interest]          [FLOAT] NULL,

               [DateOfExit]        [DATETIME] NULL,

               [curYear]           [INT] NULL,

               [PastService]       [VARCHAR](100) NULL,

               [BenefitsDC]        [FLOAT] NULL,

               [Vesting]           [FLOAT]NULL,

               [TaxfreeLumpsum]    [FLOAT] NULL,

               [WithHoldingTax]    [FLOAT]NULL,

               [comments]          [VARCHAR](50) NULL,

               [empInt]            [FLOAT] NULL,

               [emprInt]           [FLOAT] NULL,

               [AmountPayable]     [FLOAT] NULL,

               [TaxableAmount]     [FLOAT] NULL,

               [LastYear]          [INT] NULL,

               [Reason]            [VARCHAR](50) NULL,

               [EndDate]           [DATETIME],

               [PreparedBy]        [VARCHAR](100),

               [CheckedBy]         [VARCHAR](100),

               [AuthorisedBy]      [VARCHAR](100),

               [DoBirth]           [DATETIME],

               [DoCalc]            [DATETIME],

               [DatePrepared]      [DATETIME],

               [DateChecked]       [DATETIME],

               [DateAuthorised]    [DATETIME],

               [PoolName]          [VARCHAR](120) NULL,

               [VestedCont]        [FLOAT]

            )



          ALTER TABLE #Calculation

            WITH NOCHECK ADD CONSTRAINT [PK_Calculation] PRIMARY KEY NONCLUSTERED ( [SchemeNo], [memberNo] )

      END



    DECLARE @fullname VARCHAR(100)

    DECLARE @schemeName VARCHAR(100)

    DECLARE @empopening FLOAT

    DECLARE @emprOpening FLOAT

    DECLARE @empContribution FLOAT

    DECLARE @emprContribution FLOAT

    DECLARE @empClosing FLOAT

    DECLARE @emprClosing FLOAT

    DECLARE @interest FLOAT

    DECLARE @DateOfExit DATETIME

    DECLARE @pastService INT

    DECLARE @BenefitsDC FLOAT

    DECLARE @vesting FLOAT

    DECLARE @taxfreelumpsum FLOAT

    DECLARE @withHoldingTax FLOAT

    DECLARE @dje DATETIME

    DECLARE @djpens DATETIME

    DECLARE @curYear INT

    DECLARE @comments VARCHAR(50)

    DECLARE @VestedCont FLOAT

    DECLARE @EmpInt FLOAT

    DECLARE @Emprint FLOAT

    DECLARE @GrandTotal FLOAT

    DECLARE @TaxAmount FLOAT

    DECLARE @Doexit DATETIME

    DECLARE @CurMonth INT

    DECLARE @AcctPeriod       INT,

            @sDate            DATETIME,

            @eDate            DATETIME,

            @DoCalc           DATETIME,

            @Reason           VARCHAR(50),

            @rExit            INT,

            @EndDate          DATETIME,

            @DesignCode       INT,

            @Title            VARCHAR(20),

            @ServiceTime      VARCHAR(100),

            @PreparedBy       VARCHAR(100),

            @CheckedBy        VARCHAR(100),

            @AuthorisedBy     VARCHAR(100),

            @NumYears         INT,

            @NumMonths        INT,

            @NumDays          INT,

            @Approved         BIT,

            @YaConversion     VARCHAR(25),

            @Chapaa           DECIMAL(20, 6),

            @MwishoDate       DATETIME,

            @OptionToUSe      INT,

            @DoBirth          DATETIME,

            @UnRegInterest    INT,

            @DatePrepared     DATETIME,

            @DateChecked      DATETIME,

            @DateAuthorised   DATETIME,

            @PooledInvestment SMALLINT,

            @InvestmentScheme INT,

            @PoolName         VARCHAR(120),

            @corpTax          FLOAT,

            @EeRate           FLOAT,

            @ErRate           FLOAT,

            @QualifyPeriod    INT,

            @FundType         INT



    IF @Batch_Id = 0

      DECLARE MemberCsr CURSOR FOR

        SELECT MemberNo

        FROM   Members

        WHERE  schemeNo = @schemeNo

               AND MemberNo = @MemberNo

    ELSE IF @Batch_Id > 0

      DECLARE MemberCsr CURSOR FOR

        SELECT MemberNo

        FROM   TBL_BATCH_MOVEMENTS_DET

        WHERE  schemeNo = @schemeNo

               AND batch_Id = @Batch_Id



    OPEN MemberCsr



    FETCH FROM MemberCsr INTO @memberNo



    WHILE @@FETCH_STATUS = 0

      BEGIN

          EXEC Employeroption

            @schemeNo,

            @MemberNo,

            @OptionToUse Out /* PROCEDURE DBO.to Incorporate Budget changes 2005 */



          SELECT @PreparedBy = PreparedBy,

                 @CheckedBy = CheckedBy,

                 @AuthorisedBy = AuthorisedBy,

                 @DatePrepared = DatePrepared,

                 @DateChecked = DateChecked,

                 @DateAuthorised = DateAuthorised

          FROM   tbl_benefits_dc

          WHERE  SchemeNo = @schemeNo

                 AND MemberNo = @MemberNo



          SELECT @Doexit = Doexit,

                 @DoCalc = DoCalc,

                 @rExit = ReasonforExit,

                 @DesignCode = DesignCode,

                 @DoBirth = Dob

          FROM   Members

          WHERE  SchemeNo = @schemeNo

                 AND MemberNo = @MemberNo



          IF @DoExit > @DoCalc

            SELECT @doCalc = @DoExit



          SELECT @CurMonth = Datepart(Month, @DoCalc)



          SELECT @curYear = Datepart(Year, @DoCalc)



          IF @DesignCode IS NULL

            SELECT @DesignCode = 0



          EXEC Getaccountingperiodinayear

            @schemeNo,

            @CurMonth,

            @curYear,

            @AcctPeriod out



          SELECT @eDate = EndDate,

                 @sDate = StartDate

          FROM   SchemeYears

          WHERE  SchemeNo = @schemeNo

                 AND AcctPeriod = @AcctPeriod



          SELECT @MwishoDate = @eDate



          SELECT @EndDate = EndDate

          FROM   schemeYears

          WHERE  SchemeNo = @SchemeNo

                 AND AcctPeriod = ( @AcctPeriod - 1 )



          SELECT @schemeName = schemeName,

                 @PooledInvestment = PooledInvestment,

                 @InvestmentScheme = InvestmentScheme,

                 @FundType = FundTypeCode

          FROM   scheme

          WHERE  schemeCode = @schemeNo



          IF @PooledInvestment = 1

            SELECT @PoolName = schemeNAME

            FROM   Scheme

            WHERE  schemeCode = @InvestmentScheme

          ELSE IF @PooledInvestment = 0

            SELECT @PoolName = ' '



          SELECT @Approved = UnRegInterest

          FROM   ConfigYearEnd

          WHERE  SchemeNo = @schemeNo



          IF @Approved IS NULL

            SELECT @Approved = 0



          IF @Mode = 0

            BEGIN

                DECLARE GenCursor CURSOR FOR

                  SELECT m.schemeNo,

                         m.memberNo,

                         m.dje,

                         m.djpens,

                         m.doexit,

                         m.DoCalc,

                         ( Upper(m.sname) + ' , ' + ( m.fname ) + '   ' + ( m.onames ) ) AS fullname,

                         b.calcYear,

                         b.interestrate,

                         br.EEmpCBal,

                         br.EemprcBal,

                         b.withholdingTax,

                         b.taxfreeLumpsum,

                         b.vesting,

                         b.comments,

                         b.VestedCont

                  FROM   Members m

                         INNER JOIN UnregisteredBenefits br

                                 ON m.schemeNo = br.schemeNO

                                    AND m.memberNo = br.memberNo

                         INNER JOIN Benefits b

                                 ON m.schemeNo = b.schemeNO

                                    AND m.memberNo = b.memberNo

                  WHERE  m.SchemeNo = @schemeNo

                         AND m.memberNo = @memberNo

            END

          ELSE IF @Mode = 1

            BEGIN

                DECLARE GenCursor CURSOR FOR

                  SELECT m.schemeNo,

                         m.memberNo,

                         m.dje,

                         m.djpens,

                         m.doexit,

                         m.DoCalc,

                         ( Upper(m.sname) + ' , ' + ( m.fname ) + '   ' + ( m.onames ) ) AS fullname,

                         b.calcYear,

                         b.interestrate,

                         br.EEmpCBal + br.EVolCBal,

                         br.EEmprCBal + br.ESpecialCBAL,

                         b.withholdingTax,

                         b.taxfreeLumpsum,

                         b.vesting,

                         b.comments,

                         b.VestedCont

                  FROM   Members m

                         INNER JOIN UnregisteredBenefits br

                                 ON m.schemeNo = br.schemeNO

                                    AND m.memberNo = br.memberNo

                         INNER JOIN Benefits b

                                 ON m.schemeNo = b.schemeNO

                                    AND m.memberNo = b.memberNo

                  WHERE  m.SchemeNo = @schemeNo

                         AND m.memberNo = @memberNo

            END

          ELSE IF @Mode = 2 /* Projections */

            BEGIN

                DECLARE GenCursor CURSOR FOR

                  SELECT m.schemeNo,

                         m.memberNo,

                         m.dje,

                         m.djpens,

                         m.Projectdoexit,

                         m.ProjectDoCalc,

                         ( Upper(m.sname) + ' , ' + ( m.fname ) + '   ' + ( m.onames ) ) AS fullname,

                         b.calcYear,

                         b.interestrate,

                         br.ExcessEmpCont + br.ExcessVolContr,

                         br.ExcessEmprCont + br.ExcessSpecial,

                         b.withholdingTax,

                         b.taxfreeLumpsum,

                         b.vesting,

                         b.comments,

                         b.VestedCont

                  FROM   Members m

                         INNER JOIN UnregisteredBenefits br

                                 ON m.schemeNo = br.schemeNO

                                    AND m.memberNo = br.memberNo

                         INNER JOIN Benefits b

                                 ON m.schemeNo = b.schemeNO

                                    AND m.memberNo = b.memberNo

                  WHERE  m.SchemeNo = @schemeNo

                         AND m.memberNo = @memberNo

            END



          OPEN GenCursor



          FETCH FROM GenCursor INTO @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @DoCalc, @fullname, @curYear, @interest, @empclosing, @emprclosing, @withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont



          WHILE @@FETCH_STATUS = 0

            BEGIN

                /* New Deferment Rules - Uhuru */

                IF ( @Mode = 2 )

                  EXEC Proc_get_defer_rate

                    @schemeNo,

                    @DoCalc,

                    @FundType,

                    @EeRate out,

                    @ErRate out,

                    @QualifyPeriod Out

                ELSE

                  SELECT @EeRate = EeRate,

                         @ErRate = ErRate

                  FROM   Benefits

                  WHERE  schemeNo = @schemeNo

                         AND MemberNo = @MemberNo



                IF @EeRate IS NULL

                  EXEC Proc_get_defer_rate

                    @schemeNo,

                    @DoCalc,

                    @FundType,

                    @EeRate out,

                    @ErRate out,

                    @QualifyPeriod Out



                IF @rExit > 0

                  SELECT @eDate = @DoExit



                /* FOR AFFS */

                SELECT @EDate = @MwishoDate



                IF @Mode = 0

                  BEGIN

                      IF @Approved = 0 /* Tax on the Scheme */

                        SELECT @EmpOpening = mo.Excessemp,

                               @EmprOpening = mo.Excessempr

                        FROM   UnregisteredBalances Mo

                        WHERE  mo.schemeNo = @schemeNo

                               AND mo.memberNo = @MemberNo

                               AND mo.AcctPeriod = @AcctPeriod - 1

                      ELSE IF @Approved = 1 /* Tax on the Members */

                        SELECT @EmpOpening = mo.Excessemp - EmpTax,

                               @EmprOpening = mo.Excessempr - EmprTax

                        FROM   UnregisteredBalances Mo

                        WHERE  mo.schemeNo = @schemeNo

                               AND mo.memberNo = @MemberNo

                               AND mo.AcctPeriod = @AcctPeriod - 1



                      IF @EmpOpening IS NULL

                        SELECT @EmpOpening = 0



                      IF @EmprOpening IS NULL

                        SELECT @EmprOpening = 0



                      SELECT @empContribution = Sum(cs.Excessempcont),

                             @emprContribution = Sum(cs.Excessemprcont)

                      FROM   UnregisteredContributionssummary cs

                      WHERE  cs.SchemeNo = @schemeNo

                             AND cs.MemberNo = @memberNo

                             AND cs.AcctPeriod = @AcctPeriod

                             AND cs.Datepaid >= @sDate

                             AND cs.Datepaid <= @eDate

                             AND Surplus = 0

                  END

                ELSE IF @Mode = 1

                  BEGIN

                      IF @Approved = 0 /* Tax on the Scheme */

                        SELECT @EmpOpening = ( mo.Excessemp + mo.ExcessVolContr ),

                               @EmprOpening = ( mo.Excessempr + mo.ExcessSpecial )

                        FROM   UnregisteredBalances Mo

                        WHERE  mo.schemeNo = @schemeNo

                               AND mo.memberNo = @MemberNo

     AND mo.AcctPeriod = @AcctPeriod - 1

                      ELSE IF @Approved = 1 /* Tax on Members */

                        SELECT @EmpOpening = ( mo.Excessemp + mo.ExcessVolContr ) - ( EmpTax + VolTax ),

                               @EmprOpening = ( mo.Excessempr + mo.ExcessSpecial ) - ( EmprTax + SpecTax )

                        FROM   UnregisteredBalances Mo

                        WHERE  mo.schemeNo = @schemeNo

                               AND mo.memberNo = @MemberNo

                               AND mo.AcctPeriod = @AcctPeriod - 1



                      IF @EmpOpening IS NULL

                        SELECT @EmpOpening = 0



                      IF @EmprOpening IS NULL

                        SELECT @EmprOpening = 0



                      SELECT @empContribution = Sum(cs.Excessempcont + cs.ExcessVolContr),

                             @emprContribution = Sum(cs.Excessemprcont + cs.ExcessSpecial)

                      FROM   UnregisteredContributionssummary cs

                      WHERE  cs.SchemeNo = @schemeNo

                             AND cs.MemberNo = @memberNo

                             AND cs.AcctPeriod = @AcctPeriod

                             AND cs.Datepaid >= @sDate

                             AND cs.Datepaid <= @doCalc

                             AND Surplus = 0

                  END

                ELSE IF @Mode = 2

                  BEGIN

                      IF @Approved = 0 /* Tax on the Scheme */

                        SELECT @EmpOpening = ( mo.Excessemp + mo.ExcessVolContr ),

                               @EmprOpening = ( mo.Excessempr + mo.ExcessSpecial )

                        FROM   UnregisteredBalances Mo

                        WHERE  mo.schemeNo = @schemeNo

                               AND mo.memberNo = @MemberNo

                               AND mo.AcctPeriod = @AcctPeriod - 1

                      ELSE IF @Approved = 1 /* Tax on Members */

                        SELECT @EmpOpening = ( mo.Excessemp + mo.ExcessVolContr ) - ( EmpTax + VolTax ),

                               @EmprOpening = ( mo.Excessempr + mo.ExcessSpecial ) - ( EmprTax + SpecTax )

                        FROM   UnregisteredBalances Mo

                        WHERE  mo.schemeNo = @schemeNo

                               AND mo.memberNo = @MemberNo

                               AND mo.AcctPeriod = @AcctPeriod - 1



                      IF @EmpOpening IS NULL

                        SELECT @EmpOpening = 0



                      IF @EmprOpening IS NULL

                        SELECT @EmprOpening = 0



                      SELECT @empContribution = Sum(cs.Excessempcont + cs.ExcessVolContr),

                             @emprContribution = Sum(cs.Excessemprcont + cs.ExcessSpecial)

                      FROM   UnregisteredContributionssummary cs

                      WHERE  cs.SchemeNo = @schemeNo

                             AND cs.MemberNo = @memberNo

                             AND cs.AcctPeriod = @AcctPeriod

                             AND cs.Datepaid >= @sDate

                             AND cs.Datepaid <= @doCalc

                             AND Surplus = 0

                  END



                IF @EmpContribution IS NULL

                  SELECT @EmpContribution = 0



                IF @EmprContribution IS NULL

                  SELECT @EmprContribution = 0



                EXEC Getservicetime

                  @djpens,

                  @dateofExit,

                  @NumYears out,

                  @NumMonths Out,

                  @NumDays Out



                SELECT @ServiceTime = Cast(@NumYears AS VARCHAR(2)) + ' Years, '

                                      + Cast(@NumMonths AS VARCHAR(2))

                                      + '  months and '

                                      + Cast(@NumDays AS VARCHAR(2)) + ' days '



                SELECT @pastService = ( @NumYears * 12 ) + @NumMonths



                SELECT @EmpInt = @empClosing - ( @EmpOpening + @EmpContribution )



                IF @EmpInt < 1.00

                  SELECT @EmpInt = 0.0



                SELECT @EmprInt = @emprClosing - ( @EmprOpening + @EmprContribution )



                IF @EmprInt < 1.00

                  SELECT @EmprInt = 0.0



                /*Jane requested for all members in NSSF to be paid employers unregistered*/

                IF @ErRate = 100 /* Over 1 Yr But Less than 3  - Uhuru */

                  SELECT @OptionToUse = 0



                IF @OptionToUse = 0

                  BEGIN

                      IF ( @Vesting = 100.00 )

                        SELECT @GrandTotal = @EmpClosing + @EmprClosing,

                               @VestedCont = @emprClosing * ( @Vesting / 100.000000 )

                      ELSE

                        SELECT @GrandTotal = @EmpClosing + @emprClosing * ( @Vesting / 100.000000 ),

                               @VestedCont = @emprClosing * ( @Vesting / 100.000000 )

                  END

                ELSE IF @OptionToUse = 1

                  BEGIN

                      IF @ErRate < 100

                        SELECT @GrandTotal = @EmpClosing + ( @emprClosing * ( @ErRate / 100.000000 ) ),

                               @VestedCont = @emprClosing * ( @ErRate / 100.000000 )

                      ELSE

                        SELECT @GrandTotal = @EmpClosing,

                               @VestedCont = 0

                  END

                ELSE IF @OptionToUse = 2

                  BEGIN

                      SELECT @GrandTotal = @EmpClosing + @emprClosing * ( @Vesting / 100.000000 ),

                             @VestedCont = @emprClosing * ( @Vesting / 100.000000 )

                  END



                IF @OptionToUse = 1

                  BEGIN

                      IF @ErRate < 100

                        SELECT @TaxAmount = @EmpInt + @EmprInt * ( @ErRate / 100.00 ) /* Uhuru */

                      ELSE

                        SELECT @TaxAmount = @EmpInt

                  END

                ELSE

                  SELECT @TaxAmount = @EmpInt + @EmprInt



                IF @TaxAmount < 0

                  SELECT @TaxAmount = 0



                EXEC Calculatecorporatetax

                  @TaxAmount,

                  @WithholdingTax out



                -- IF @Approved = 0 /* Scheme not Registered with KRA */

                --SELECT @WithholdingTax = 0

                SELECT @Reason = ReasonDesc

                FROM   ReasonforExit

                WHERE  ReasonCode = @rExit



                IF @DesignCode > 0

                  BEGIN

                      SELECT @Title = Designation

                      FROM   Designation

                      WHERE  DesignCode = @DesignCode



                      SELECT @FullName = Upper(@Title) + '  ' + @FullName

                  END



                INSERT INTO #calculation

                            (schemeNo,

                             MemberNo,

                             schemeName,

                             fullname,

                             dje,

                             djpens,

                             empopeningBal,

                             emprOpeningBal,

                             empcontributions,

                             emprContributions,

                             empclosing,

                             emprClosing,

                             interest,

                             dateofexit,

                             curYear,

                             pastService,

                             benefitsDC,

                             TaxfreeLumpsum,

                             withHoldingTax,

                             Vesting,

                             Comments,

                             EmprInt,

                             EmpInt,

                             AmountPayable,

                             TaxableAmount,

                             LastYear,

                             Reason,

                             EndDate,

                             PreparedBy,

                             CheckedBy,

                             AuthorisedBy,

                             DoBirth,

                             DoCalc,

                             DatePrepared,

                             DateChecked,

                             DateAuthorised,

                             PoolName,

                             VestedCont)

                VALUES      (@schemeNo,

                             @memberNo,

                             @schemeName,

                             @fullname,

                             @dje,

                             @djpens,

                             @empOpening,

                             @emprOpening,

                             @empcontribution,

                             @emprContribution,

                             @empclosing,

                             @emprClosing,

                             @interest,

                             @dateofExit,

                             @curYear,

                             @ServiceTime,

                             @GrandTotal,

                             @taxfreeLumpsum,

                             @withHoldingTax,

                             @vesting,

                             @comments,

                             @EmprInt,

                             @EmpInt,

                             @GrandTotal - @withHoldingTax,

                             @TaxAmount,

                             @CurYear - 1,--@WithholdingTax                       

                             @Reason,

                             @EndDate,

                             @PreparedBy,

                             @CheckedBy,

                             @AuthorisedBy,

                             @DoBirth,

                             @DoCalc,

                             @DatePrepared,

                             @DateChecked,

                             @DateAuthorised,

                             @PoolName,

                             @VestedCont)



                /* for the Britak Interface */

                UPDATE UnRegisteredBenefits

                SET    WithBenefit = @GrandTotal,

                       WithTax = @withHoldingTax

                WHERE  schemeNo = @schemeNo

                       AND MemberNo = @MemberNo



                UPDATE Benefits

                SET    WithBenefitUn = @GrandTotal,

                       WithTaxUn = @withHoldingTax

                WHERE  schemeNo = @schemeNo

                       AND MemberNo = @MemberNo



                UPDATE TBL_BENEFITS_DC

                SET    AmountPayableUn = @GrandTotal,

                       TaxPayableUn = @withHoldingTax

                WHERE  schemeNo = @schemeNo

                       AND MemberNo = @MemberNo

                       AND ExitReason = @rExit

                       AND docalc = @docalc

                       AND doexit = @dateofexit



                FETCH next FROM GenCursor INTO @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @DoCalc, @fullname, @curYear, @interest, @empclosing, @emprclosing, @withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont

            END



          CLOSE GenCursor



          DEALLOCATE GenCursor



          SELECT @MemberNo = 0



          FETCH next FROM memberCsr INTO @MemberNo

      END



    CLOSE memberCsr



    DEALLOCATE memberCsr



    SELECT *

    FROM   #calculation
go

