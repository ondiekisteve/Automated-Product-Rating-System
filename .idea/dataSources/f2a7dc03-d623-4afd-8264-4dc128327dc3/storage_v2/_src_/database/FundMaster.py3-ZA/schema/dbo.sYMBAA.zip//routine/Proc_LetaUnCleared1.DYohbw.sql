CREATE PROCEDURE [dbo].[Proc_LetaUnCleared1]                                                                            
@SCHEMENO Int,                                                                            
@BankCode Int,                                                
@StartDate datetime,                                                
@EndDate datetime,                                                
@RecMode Int,/* 0 - All Uncleared Effects, 1 - Within Cut Dates */                                                                                                        
@Cleared Int, /* 0 - Uncleared, 1 - Cleared, 2 - Reversed, 3 - All */                                   
@Pooled Int, /* 0 - Scheme Level, 1 - Aflife Pooled */    
@SortMode Int /* 0 - Amount, 1 - Date, 2 - ChequeNo, 3 - Particulars */                                                                           
--with Encryption                                                                            
as                                                                            
                                                                            
if object_id('tempdb..#ManualRecon') is null                                                                            
                                                                            
begin                                                                            
create table #ManualRecon                                                                            
(                                                                            
        [Counter] Int identity(1,1) Primary Key,                                                                          
        [SchemeNo] int NOT NULL ,                                                                            
        [BankCode] int not  NULL,                                                                            
        [TransNo] [Int],                                                                            
        [BankMonth][int] not null,                                                                            
        [BankYear][Int],                                                                            
        [ChequeNo][Varchar](20),                                                                            
        [Debit][float],                                                                            
        [Credit][float],                                              
        [Amount][float],                                                                            
        [BankDate][Datetime],                                                                            
        [Cleared][SMALLINT],                                                                            
        [TransDate][Datetime],                                                                            
        [Period][Varchar](30),                                                                            
        [Wapi][SmallInt],                                                                            
        [GANI][Varchar](10),                                                                          
        [Particulars][varchar](255),                                                                  
        [CashTransNo][Int],                                                  
        [Payee][varchar](120),                                                
        [RStatus][varchar](1),                                                
        [CBBalance][float],                                                
        [BKBalance][float],                                                
        [MVBalance][float]                                                
                                                                                    
)                                                                               
end                                       
                        
declare @TransDate Datetime,@TransNo Int,@ChequeNo Varchar(20),@CashbookNo Int,@RStatus varchar(1),          
@FirstDate datetime,@OpBalance float,@Receipts float,@Payments float,                                   
@CBBalance float,@BKBalance float,@BankMonth Int,@BankYear Int,@MVBalance float,                                              
@clDebit float,@ClCredit float,@upDebit float,@upCredit float,@SeparateCB smallint,@Operational smallint,@FundType int,@AccountCode varchar(30),                              
@InvestScheme int,@BKBalance1 float,@RelSchemeNo int,@BankCodeRel int,@OpBalanceRel float,@BKBalanceRel float,@ReceiptsRel float,@PaymentsRel float,      
@clDebitRel float,@ClCreditRel float,@upDebitRel float,@upCreditRel float      
      
select @OpBalanceRel = 0,@BKBalanceRel = 0,@ReceiptsRel=0,@PaymentsRel=0,@clDebitRel=0,@ClCreditRel=0,@upDebitRel=0,@upCreditRel=0                             
                              
select @FundType = FundTypeCode,@SeparateCB = SeparateCB from scheme where schemeCode = @schemeNo                              
                                        
select @Operational = Operational,@AccountCode = AccountCode   from schemeBankBranch where schemeNo = @schemeNo and BankCode = @BankCode       
      
if @FundType <> 8                   
   SELECT @RelSchemeNo = SchemeCode from Scheme where RelSchemeNo = @schemeNo and InvestSeparate = 1                  
else       
   SELECT @RelSchemeNo = 0       
      
if @RelSchemeNo > 0      
   select @BankCodeRel = BankCode from schemeBankBranch where schemeNo = @RelSchemeNo and AccountCode = @AccountCode      
else      
   select @BankCodeRel = 0                                          
                              
if @Operational is null select @Operational = 0                                            
if @SeparateCB is null select @SeparateCB = 0                                              
                                                          
select @BankMonth = datepart(month,@EndDate)                                                            
select @BankYear = datepart(year,@EndDate)                                                   
                                                
/* Get the cashbook Balance */                                   
Exec GetLastDate @BankMonth,@BankYear,@TransDate out                                                 
                                                
Exec GetFirstDate @BankMonth,@BankYear,@FirstDate Out                                                       
                                                                           
select @FirstDate = @FirstDate - 1                                                                            
                              
if (@FundType = 8)                                  
        begin                                                                            
            select @OpBalance = sum(DebitBalance) - sum(CreditBalance),@BKBalance = sum(drBankBalance) - sum(CrBankBalance)                                                                  
            from tbl_cashbook_Balances where ((SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @schemeNo AND ActiveStatus = 1)                                           
                                          and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @schemeNo AND ActiveStatus = 1)))            
            or (SchemeCode = @SchemeNo and BankCode = BankCode))                                               
            and PeriodEnding = @FirstDate            
            
            if @BKBalance is null select @BKBalance = 0                                         
       end                               
else                                   
       begin                                    
         if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                                  
                                  
            select @OpBalance = sum(DebitBalance) - sum(CreditBalance),@BKBalance = sum(drBankBalance) - sum(CrBankBalance)                                                                 
            from tbl_cashbook_Balances where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                       
                                          and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                           
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))                        
            and PeriodEnding = @FirstDate                                   
            end                                   
         else       
            begin                                    
            select @OpBalance = (DebitBalance) - (CreditBalance),                                              
            @BKBalance = (drBankBalance) - (CrBankBalance)                                                
            from TBL_Cashbook_Balances where schemeCode = @schemeNo                                                                            
            and BankCode = @BankCode and PeriodEnding = @FirstDate       
      
            if @RelSchemeNo > 0      
               select @OpBalanceRel = (DebitBalance) - (CreditBalance),                                              
               @BKBalanceRel = (drBankBalance) - (CrBankBalance)                                                
               from TBL_Cashbook_Balances where schemeCode = @RelschemeNo                                                                            
               and BankCode = @BankCodeRel and PeriodEnding = @FirstDate         
      
            end                                
       end                                         
                                    
                                                                          
if @OpBalance is null select @OpBalance = 0.0        
if @OpBalanceRel is null select @OpBalanceRel = 0.0       
      
select @OpBalance = @OpBalance + @OpBalanceRel                                          
                                                                            
select @FirstDate = @FirstDate + 1                               
                              
                              
if (@FundType = 8)                                  
        begin                                                                            
            select @Receipts = sum(Debit),@Payments = sum(Credit)                                                 
            from CashBook where ((SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @schemeNo AND ActiveStatus = 1)                                           
                                          and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                 and SchemeNo in (select schemeCode from Scheme                                                          
                                             where PooledInvestment = 1 and InvestmentScheme = @schemeNo AND ActiveStatus = 1)))            
            or ((SchemeCode = @schemeNo) and (BankCode = @BankCode)))                                                       
            and ChequeDate >= @FirstDate and ChequeDate <= @TransDate AND Tran_Status = 0 and Posted = 1                                     
       end                              
else                                   
       begin                                    
         if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                                  
                                  
            select @Receipts = sum(Debit),@Payments = sum(Credit)                                                                 
            from CashBook where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                                          and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
            and SeparateCB = 1))                                                                                      
            and ChequeDate >= @FirstDate and ChequeDate <= @TransDate AND Tran_Status = 0 and Posted = 1                                   
            end                                   
       else       
           begin                                    
            select @Receipts = sum(Debit),@Payments = sum(Credit)                                                  
            from CashBook                                                                            
            where schemeCode = @schemeNo and BankCode = @BankCode and ChequeDate >= @FirstDate and ChequeDate <= @TransDate                                                                 
            AND Tran_Status = 0 and Posted = 1       
      
            if @RelSchemeNo > 0      
               select @ReceiptsRel = sum(Debit),@PaymentsRel = sum(Credit)                                                  
               from CashBook                                                                            
               where schemeCode = @RelSchemeNo and BankCode = @BankCodeRel and ChequeDate >= @FirstDate and ChequeDate <= @TransDate                                                                 
               AND Tran_Status = 0 and Posted = 1       
          end                                 
       end                                                                          
            
if @OpBalance is null select @OpBalance = 0       
if @OpBalanceRel is null select @OpBalanceRel = 0      
if @BKBalance is null select @BKBalance = 0      
if @BKBalanceRel is null select @BKBalanceRel = 0                                                
if @Receipts is null select @Receipts = 0                                                
if @Payments is null select @Payments = 0       
if @ReceiptsRel is null select @ReceiptsRel = 0                                                
if @PaymentsRel is null select @PaymentsRel = 0       
      
select @OpBalance = @OpBalance + @OpBalanceRel,@Receipts = @Receipts + @ReceiptsRel,@Payments = @Payments + @PaymentsRel,      
@BKBalance = @BKBalance + @BKBalanceRel                                              
                                                
select @CBBalance = (@OpBalance + @Receipts) - @Payments,@MVBalance = @BKBalance                                                
                                              
/* Moving Balance */                               
if (@FundType = 8)                                  
        begin                                                             
            select @clDebit = sum(Debit),@ClCredit = sum(Credit)                                                                  
            from CashBook where ((SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @schemeNo AND ActiveStatus = 1)                                           
                                          and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @schemeNo AND ActiveStatus = 1)))                      
                                          or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                                       
            and (PeriodCleared = @TransDate) and Cleared = 1 AND Tran_Status = 0 and Posted = 1                                
                              
            select @upDebit = sum(Debit),@upCredit = sum(Credit)                                                                  
            from UnPresentedCheques where ((SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @schemeNo AND ActiveStatus = 1)                                           
              and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                 where PooledInvestment = 1 and InvestmentScheme = @schemeNo AND ActiveStatus = 1)))                      
               or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                                       
            and (PeriodCleared = @TransDate) and Cleared = 1 and Recon = 0                                                      
       end                              
else                                   
       begin                                    
         if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                                  
                                  
            select  @clDebit = sum(Debit),@ClCredit = sum(Credit)                      
            from CashBook where SchemeCode in (select schemeCode from Scheme                                                          
        where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                                          and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode               
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                                                             and SeparateCB = 1))                
  
    
      
                                                     
            and (PeriodCleared = @TransDate) and Cleared = 1 AND Tran_Status = 0 and Posted = 1            
                              
            select  @upDebit = sum(Debit),@upCredit = sum(Credit)                                                    
            from UnPresentedCheques where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                                          and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
            where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))                                                                                      
            and (PeriodCleared = @TransDate) and Cleared = 1 and Recon = 0                                    
            end                            
         else                              
            begin                                     
            select @clDebit = sum(Debit),@ClCredit = sum(Credit)                                              
            from Cashbook                                                                           
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                             
            (PeriodCleared = @TransDate) and Cleared = 1                                                                            
            AND Tran_Status = 0 and Posted = 1                                               
                                              
            select @upDebit = sum(Debit),@upCredit = sum(Credit)                                                                  
            from UnPresentedCheques                                                                            
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                
            (PeriodCleared = @TransDate) and Cleared = 1 and Recon = 0       
      
            if @RelSchemeNo > 0      
               begin      
                  select @clDebitRel = sum(Debit),@ClCreditRel = sum(Credit)                                              
                  from Cashbook                                                                           
                  where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                                             
                  (PeriodCleared = @TransDate) and Cleared = 1                                                                            
                  AND Tran_Status = 0 and Posted = 1                                               
                          
                  select @upDebitRel = sum(Debit),@upCreditRel = sum(Credit)                                                                  
                  from UnPresentedCheques                                                                            
                  where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                
                  (PeriodCleared = @TransDate) and Cleared = 1 and Recon = 0       
               end                             
            end                                  
       end                               
                                              
if @clDebit is null select @clDebit = 0                                                
if @ClCredit is null select @ClCredit = 0                                                
if @upDebit is null select @upDebit = 0                                        
if @upCredit is null select @upCredit = 0       
if @clDebitRel is null select @clDebitRel = 0                                        
if @ClCreditRel is null select @ClCreditRel = 0                                                
if @upDebitRel is null select @upDebitRel = 0                                        
if @upCreditRel is null select @upCreditRel = 0       
      
select @clDebit = @clDebit + @clDebitRel,@upDebit = @upDebit + @upDebitRel,      
       @ClCredit = @ClCredit + @ClCreditRel,@upCredit = @upCredit + @upCreditRel                                            
                                              
select @MVBalance = (@MVBalance + @upDebit + @clDebit) - (@ClCredit + @upCredit)                                                
                                             
/* End Get the cashbook Balance */                          
                                                                            
IF @CLEARED = 0                                               
BEGIN                                                                          
/* CASHBOOK */                              
if (@FundType = 8)                               
   begin                                                                            
      Declare Acsr Cursor for                                                                            
      Select CashbookNo from CashBook                                                                            
      where ((SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
            and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                             and SchemeNo in (select schemeCode from Scheme                                                          
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
      or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                               
      and (ChequeDate <= @TransDate) and Cleared = @Cleared and Tran_Status = 0 and Posted = 1                                                                                         
      order by ChequeNo                               
   end                              
else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                                  
                                  
            Declare Acsr Cursor for                              
            Select CashbookNo from CashBook                                                                
       where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                   
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))                                                                            
            and (ChequeDate <= @TransDate) and Cleared = @Cleared and Tran_Status = 0 and Posted = 1                                                                                         
            order by ChequeNo                                   
            end                                   
         else                              
            begin       
             if @RelSchemeNo > 0      
                Declare Acsr Cursor for                              
                Select CashbookNo from CashBook                                                                            
                where SchemeCode = @schemeNo and BankCode = @BankCode and              
                (ChequeDate <= @TransDate) and Cleared = @Cleared                                                     
                and Tran_Status = 0 and Posted = 1                                                                                         
                UNION       
                Select CashbookNo from CashBook                                                                            
                where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and              
                (ChequeDate <= @TransDate) and Cleared = @Cleared                                                     
                and Tran_Status = 0 and Posted = 1                                                                                          
             else                             
                Declare Acsr Cursor for                              
                Select CashbookNo from CashBook                                                                            
                where SchemeCode = @schemeNo and BankCode = @BankCode and              
                (ChequeDate <= @TransDate) and Cleared = @Cleared                                                     
                and Tran_Status = 0 and Posted = 1                                                                                         
                order by ChequeNo                               
            end                              
     end                               
Open Acsr                                                                            
Fetch from acsr into @CashbookNo                                                                            
while @@fetch_Status = 0                                                                            
begin                              
   if (@FundType = 8)                               
      begin                                                                            
           Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
           b.ChequeNo,SUM(b.Debit),SUM(b.Credit),SUM(b.Debit)- SUM(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
           m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
           case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
           @MVBalance                                                                           
           from Cashbook b                                                                            
                Inner Join MonthTable m on @bankMonth = m.MonthNumber                
           where ((b.SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
           and b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                             and SchemeNo in (select schemeCode from Scheme                                                          
                                  where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                       
           or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                       
           and                                                                             
           (b.ChequeDate <= @TransDate) and b.Cleared = @Cleared and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0                                                     
           and b.Posted = 1                                                                                                                    
           Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,                                                  
           b.Payee                              
       end                               
   else                           
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
          begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                                
                              
            Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
            b.ChequeNo,SUM(b.Debit),SUM(b.Credit),SUM(b.Debit)- SUM(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                                                                           
            from Cashbook b                                                                            
                Inner Join MonthTable m on @bankMonth = m.MonthNumber                                         
            where b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                 and b.BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                          
                 where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))   and                                                                             
           (b.ChequeDate <= @TransDate) and b.Cleared = @Cleared and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0                                                     
            and b.Posted = 1           
            Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,                                                  
            b.Payee                              
          end                              
       else                              
          begin       
                              
             Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
             b.ChequeNo,SUM(b.Debit),SUM(b.Credit),SUM(b.Debit)- SUM(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                     
             m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
             case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
             @MVBalance                                                                           
             from Cashbook b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
             where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                                                             
            (b.ChequeDate <= @TransDate) and b.Cleared = @Cleared and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0                                                     
             and b.Posted = 1                                                                                                      
             Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,                                                  
             b.Payee        
      
             if @RelSchemeNo > 0      
                Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
                b.ChequeNo,SUM(b.Debit),SUM(b.Credit),SUM(b.Debit)- SUM(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                     
                m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB', cast(@RelSchemeNo as varchar(4))+' - '+b.Description,b.CashTransNo,b.Payee,                                                
                case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
                @MVBalance                                                                           
                from Cashbook b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
                where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                                                             
                (b.ChequeDate <= @TransDate) and b.Cleared = @Cleared and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0                                                     
                and b.Posted = 1                                                                                                      
                Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,                                                  
                b.Payee                                 
        end                              
    end                   
                                                                            
   Select @CashbookNo = 0                  
   fetch next from acsr into @CashbookNo                                                                            
end                                                        
Close Acsr                                                                            
Deallocate Acsr                                                                            
                                                              
/* UNPRESENTED CHEQUES ON TAKE-ON */                            
if (@FundType = 8)                               
 begin                                                                
   Declare Acsr Cursor for                                                                         
   Select distinct(ChequeNo) from UnPresentedCheques                                                                            
   where ((SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
           and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                             and SchemeNo in (select schemeCode from Scheme                                                          
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                       
                      
   or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                      
   and                                                             
   (TransDate <= @TransDate) and Cleared = @Cleared and Recon = 0                                                
   and len(ltrim(rtrim(ChequeNo))) > 1                                                                     
   order by ChequeNo                             
 end                            
else                                   
 begin                                    
    if ((@Pooled = 1) and (@Operational = 1))                                  
       begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                             
                            
            Declare Acsr Cursor for                                                                            
            Select distinct(ChequeNo) from UnPresentedCheques                                                                            
            where SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
            and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                         and SchemeNo in (select schemeCode from Scheme                                                          
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                              and SeparateCB = 1)) and                                          
           (TransDate <= @TransDate) and Cleared = @Cleared and Recon = 0                                                
           and len(ltrim(rtrim(ChequeNo))) > 1                                                                            
           order by ChequeNo                            
       end                            
    else                            
       begin       
           if @RelSchemeNo > 0                           
              Declare Acsr Cursor for                                                                            
              Select distinct(ChequeNo) from UnPresentedCheques                                                                            
              where SchemeCode = @schemeNo and BankCode = @BankCode and                                                             
              (TransDate <= @TransDate) and Cleared = @Cleared and Recon = 0                                                
              and len(ltrim(rtrim(ChequeNo))) > 1                                                                            
              UNION      
              Select distinct(ChequeNo) from UnPresentedCheques                                                                            
              where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                             
              (TransDate <= @TransDate) and Cleared = @Cleared and Recon = 0                                                
              and len(ltrim(rtrim(ChequeNo))) > 1          
  else       
              Declare Acsr Cursor for                                                                            
              Select distinct(ChequeNo) from UnPresentedCheques                                                                            
              where SchemeCode = @schemeNo and BankCode = @BankCode and                                                             
              (TransDate <= @TransDate) and Cleared = @Cleared and Recon = 0                                                
              and len(ltrim(rtrim(ChequeNo))) > 1                                                                            
              order by ChequeNo                            
       end                                  
 end                                                                         
Open Acsr                                                                       
Fetch from acsr into @ChequeNo                                                                            
while @@fetch_Status = 0                                                                  
begin                                                                            
    if (@FundType = 8)                               
       begin                
          Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
          @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                            
          m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.Particulars,0,b.particulars,                                                
          case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
          @MVBalance                                                                            
          from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
          where ((b.SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
           and  b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                             
                             and SchemeNo in (select schemeCode from Scheme                                                          
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                             or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                      
                             and                                                                       
          (b.TransDate <= @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                            
          and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                        
          Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                             
       end                            
    else                                   
 begin                                    
    if ((@Pooled = 1) and (@Operational = 1))                                  
       begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                             
                            
            Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
            @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                    
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.Particulars,0,b.particulars,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                                                                        
            from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where b.SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
            and b.BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                             and SchemeNo in (select schemeCode from Scheme                                                  
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                              and SeparateCB = 1)) and                                                                             
            (b.TransDate <= @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                            
            and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                        
            Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                             
       end                            
    else                 
       begin                            
           Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
           @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
           m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.Particulars,0,b.particulars,                                                
           case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
  @MVBalance                                                                            
           from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
           where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                                                             
           (b.TransDate <= @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                            
           and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                        
           Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo       
      
           if @RelSchemeNo > 0       
              Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
              @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
              m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.Particulars,0,b.particulars,                                                
              case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
              @MVBalance                                                                            
              from UnPresentedCheques b                                                                            
                   Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
              where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                                                             
              (b.TransDate <= @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                            
              and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                        
              Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                             
       end                                  
 end                                                                                
                                                                             
 select @ChequeNo = ''                                 
 fetch next from acsr into @ChequeNo                                                                            
end                                                                            
Close Acsr     
Deallocate Acsr                                                                            
                                                                            
END                           
ELSE IF @CLEARED = 1                                                            
BEGIN                                         
/* CASHBOOK */                              
if (@FundType = 8)                               
   begin                                                                            
      Declare Acsr Cursor for                                                                            
      Select CashbookNo from CashBook                                 
      where ((SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                 
            and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                             and SchemeNo in (select schemeCode from Scheme                   
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                       
            or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                 
                         
      and (PeriodCleared = @TransDate) and Cleared = @Cleared and Tran_Status = 0 and Posted = 1                             
      order by ChequeNo                               
   end                              
else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                                  
          
            Declare Acsr Cursor for                              
            Select CashbookNo from CashBook                                                                
            where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                        
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))                                                                                      
            and (PeriodCleared = @TransDate) and Cleared = @Cleared and Tran_Status = 0 and Posted = 1                             
            order by ChequeNo                                    
            end                                   
         else                              
            begin       
             if @RelSchemeNo > 0                             
                Declare Acsr Cursor for                              
                Select CashbookNo from CashBook                                                                            
                where SchemeCode = @schemeNo and BankCode = @BankCode                                                                            
                and (PeriodCleared = @TransDate) and Cleared = @Cleared and Tran_Status = 0 and Posted = 1                            
                UNION      
       Select CashbookNo from CashBook                                                                            
                where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel                                                                            
                and (PeriodCleared = @TransDate) and Cleared = @Cleared and Tran_Status = 0 and Posted = 1       
             else      
                Declare Acsr Cursor for                              
                Select CashbookNo from CashBook                                                                            
                where SchemeCode = @schemeNo and BankCode = @BankCode                                                                            
                and (PeriodCleared = @TransDate) and Cleared = @Cleared and Tran_Status = 0 and Posted = 1                            
                order by ChequeNo                          
            end                              
     end                                                                              
Open Acsr                                                                            
Fetch from acsr into @CashbookNo                                                                            
while @@fetch_Status = 0                                                                            
begin                                                                            
                            
   if (@FundType = 8)                               
   begin                             
       Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                     
       b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                      
       m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
       case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
       @MVBalance                                                                            
       from Cashbook b                                      
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
       where ((b.SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
         and b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                             and SchemeNo in (select schemeCode from Scheme                                                          
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
         or                      
                             (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
         and                                                            
       (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared                                                                            
       and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1                                                                            
       Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee                            
   end                              
   else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
          begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                                  
                                  
            Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                     
            b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                     
            from Cashbook b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
            and b.BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                      
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))  and                                                            
           (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared             
            and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1                                                                            
            Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee              
                                
            end                                   
         else                              
            begin                              
             Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                     
             b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
             m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
             case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
             @MVBalance                                                                            
             from Cashbook b                                                                            
                 Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
             where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                     
             (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared                                                                            
             and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1                                                                            
             Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee      
      
             if @RelSchemeNo > 0      
                Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                     
                b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
                m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
                case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,             
                @MVBalance                                                                            
                from Cashbook b                                                                            
                 Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
                where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                     
                (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared                                                                            
                and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1                                                                            
               Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee      
                                            
            end                              
     end                                                                                     
                                                                            
   select @CashbookNo = 0                                                                    
   fetch next from acsr into @CashbookNo                                                                        
end                                                                            
Close Acsr                                                                            
Deallocate Acsr                                
                                                                            
/* UN-PRESENTED */                            
                            
if (@FundType = 8)                               
   begin                            
      Declare Acsr Cursor for                                                                            
      Select distinct(ChequeNo) from UnPresentedCheques                                                                            
      where ((SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
      and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                             and SchemeNo in (select schemeCode from Scheme                              
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                             or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                             and                                                                             
      (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                  
      and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                
      order by ChequeNo                             
   end                            
else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                                  
                                  
            Declare Acsr Cursor for                            
            Select distinct(ChequeNo) from UnPresentedCheques                                                                            
            where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                         
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                   where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1)) and                                                                             
           (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                                             
            and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
            order by ChequeNo                             
                                   
            end                                   
   else                              
            begin       
             if @RelschemeNo > 0      
                Declare Acsr Cursor for                                                                            
                Select distinct(ChequeNo) from UnPresentedCheques                                                                            
                where SchemeCode = @schemeNo and BankCode = @BankCode and                  
                (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                                             
                and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))      
                UNION      
                Select distinct(ChequeNo) from UnPresentedCheques                                                                            
                where SchemeCode = @RelschemeNo and BankCode = @BankCodeRel and                  
                (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                                             
                and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
             else                             
                Declare Acsr Cursor for                                                                            
                Select distinct(ChequeNo) from UnPresentedCheques                                                                            
                where SchemeCode = @schemeNo and BankCode = @BankCode and                  
                (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                
                and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
                order by ChequeNo                             
            end                              
     end                                
                                                                           
Open Acsr                                                                            
Fetch from acsr into @ChequeNo                                                                            
while @@fetch_Status = 0                                                                            
begin                                
                            
   if (@FundType = 8)                               
   begin                            
      Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
       @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                     
       m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                                
       case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
       @MVBalance                                                                            
      from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
      where ((b.SchemeCode in (select schemeCode from Scheme where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
       and b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                             and SchemeNo in (select schemeCode from Scheme                                 
                                              where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                      or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                               and                          
     (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                             
      and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
      Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                            
   end                            
   else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                            
             Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
             @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,     
             m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                           case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,    
  
    
                            
    @MVBalance                                                                            
             from UnPresentedCheques b                                                                            
                  Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
             where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                      and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                         and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1)) and                                                                             
            (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                             
             and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
             Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                            
            end                                   
         else                              
           begin                              
             Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
             @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
             m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                             
             case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
             @MVBalance                                              
            from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                                                             
            (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                             
            and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
            Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo       
      
            if @RelSchemeNo > 0       
                Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
                @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
                m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                                
                case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
                @MVBalance                                              
                from UnPresentedCheques b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
                where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                                                             
                (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared and Recon = 0                           
                and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
                Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                           
          end                              
     end                                
                                                                                   
  select @ChequeNo = ''                                                                          
  fetch next from acsr into @ChequeNo                                                                            
end                                                                            
Close Acsr                                                                            
Deallocate Acsr                                                                                             
END                             
                            
/* UMEFIKA HAPA */                             
                                              
ELSE IF @CLEARED = 2 -- Reversed                                
BEGIN                                             
/* CASH BOOK */                             
if (@FundType = 8)                               
   begin                                                                          
      Declare Acsr Cursor for                                                                            
      Select CashbookNo from CashBook                      
      where ((SchemeCode in (select schemeCode from Scheme                                                          
      where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
            and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
            or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                          and                       (PeriodCleared = @TransDate) and Cleared = @Cleared                                                    
      and Tran_Status = 0 and Posted = 1                                                                             
     --and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
     order by ChequeNo                       end                            
else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                            
            Declare Acsr Cursor for                                                                            
            Select CashbookNo from CashBook                                                                            
            where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                    and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1)) and                                                                   
            (PeriodCleared = @TransDate) and Cleared = @Cleared                                                    
            and Tran_Status = 0 and Posted = 1                                                                             
            --and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
            order by ChequeNo                            
            end                            
        else                            
           begin       
             if @RelSchemeNo > 0                           
             Declare Acsr Cursor for                                                                            
             Select CashbookNo from CashBook                                                                            
             where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                   
             (PeriodCleared = @TransDate) and Cleared = @Cleared                           
             and Tran_Status = 0 and Posted = 1      
             UNION      
             Select CashbookNo from CashBook                                                                            
             where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                                   
             (PeriodCleared = @TransDate) and Cleared = @Cleared                           
             and Tran_Status = 0 and Posted = 1       
             else      
             Declare Acsr Cursor for                                                                            
             Select CashbookNo from CashBook                                                                            
             where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                   
             (PeriodCleared = @TransDate) and Cleared = @Cleared                           
             and Tran_Status = 0 and Posted = 1                
           end                            
                            
    end                            
              
Open Acsr                                                                            
Fetch from acsr into @CashbookNo                                                  
while @@fetch_Status = 0                                                                            
begin                                                                            
                              
   if (@FundType = 8)                               
   begin                            
      Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
      b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
      m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
      case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
      @MVBalance                                                                            
      from Cashbook b            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                           
      where ((b.SchemeCode in (select schemeCode from Scheme                                                          
                       where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
        and b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
          or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                         and                                       
      (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared                                                                            
      and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1                                             
      Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee                      
   end                             
   else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                             
               Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
               b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                                                                            
               from Cashbook b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
               where b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                 and b.BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                         
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1)) and                                             
               (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared                                                                            
               and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1                                  
               Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee                            
            end                            
       else                            
            begin                            
               Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                    
               b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                                                                            
              from Cashbook b                                                                            
                  Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
              where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                             
                 (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared                                  
                  and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1                                             
              Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee       
      
              if @RelSchemeNo > 0      
                 Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                    
               b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                                                
              from Cashbook b                                                                            
                  Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
              where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                             
                 (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared                                  
                  and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1                                             
              Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee                            
                            
            end                            
    end                                                                           
                                                             
   select @CashbookNo = 0                                                                          
   fetch next from acsr into @CashbookNo                                                                            
end                                                                            
Close Acsr                                                                            
Deallocate Acsr                                                               
                                                                            
/* UN-PRESENTED */                              
if (@FundType = 8)                               
   begin                                                                          
      Declare Acsr Cursor for                                                                            
      Select distinct(ChequeNo) from UnPresentedCheques                                                                             
      where ((SchemeCode in (select schemeCode from Scheme                                                          
  where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
            and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
      or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                          and                                                                   
      (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                                            
      and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
      order by ChequeNo                   
   end                            
else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
       select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                            
            Declare Acsr Cursor for                                                                            
            Select distinct(ChequeNo) from UnPresentedCheques                                                               
            where SchemeCode in (select schemeCode from Scheme                                                          
                                                     where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                    and SeparateCB = 1)) and                                                                   
            (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                                            
             and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
             order by ChequeNo                            
            end                            
        else                            
           begin       
            if @RelSchemeNo > 0                           
            Declare Acsr Cursor for           
            Select distinct(ChequeNo) from UnPresentedCheques                        
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                             
           (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                                            
            and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
            UNION      
            Select distinct(ChequeNo) from UnPresentedCheques                        
            where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                                             
           (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                                            
            and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))        
            else       
            Declare Acsr Cursor for                                                                            
            Select distinct(ChequeNo) from UnPresentedCheques                        
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                             
           (PeriodCleared= @TransDate) and Cleared = @Cleared and Recon = 0                                                                            
            and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
            order by ChequeNo                            
           end                            
    end                            
         
Open Acsr                                                                            
Fetch from acsr into @ChequeNo                                                                            
while @@fetch_Status = 0                                                                            
begin                            
   if (@FundType = 8)                               
      begin                              
         Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
         @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
         m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                                
         case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
         @MVBalance                                                                            
         from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                       
         where ((B.SchemeCode in (select schemeCode from Scheme                                                          
                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
         and B.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))      
               or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                 
                                                          and                                                                             
         (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                            
         and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                  
         Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                            
      end                            
   else                            
      begin                            
         if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
               select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                       Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
               @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                                
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                
               from UnPresentedCheques b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                       
               where b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
               and b.BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1)) and                                                                             
               (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                            
               and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
               Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                            
           end                            
        else                            
           begin                            
               Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                
               @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                 
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                                
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                                                                            
               from UnPresentedCheques b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                       
               where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                                                             
               (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                            
               and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
                Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo       
      
               if @RelSchemeNo > 0       
                  Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                
                  @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
                  m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                      
                  case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
                  @MVBalance                                                                            
                  from UnPresentedCheques b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber    
                  where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                                                             
                  (b.PeriodCleared = @TransDate) and b.Cleared = @Cleared and Recon = 0                                                                            
                  and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
                  Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                          
           end                            
                            
      end                            
                            
                                                                           
  select @ChequeNo = ''                                                                          
  fetch next from acsr into @ChequeNo                                                                            
end                                                                            
Close Acsr                                                                            
Deallocate Acsr                                                                            
                                                                             
END                                                
ELSE IF @CLEARED = 3 -- ALL                                        
BEGIN                                                 
                            
if (@FundType = 8)                               
   begin                            
      Declare Acsr Cursor for                                                                            
      Select CashbookNo from CashBook                                                                            
      where ((SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
        and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                 or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                 and                                                                             
     (ChequeDate <= @TransDate) and Cleared = 0 and Tran_Status = 0 and Posted = 1                                                                                         
      order by ChequeNo                            
   end               
else                            
   begin                            
      if ((@Pooled = 1) and (@Operational = 1))                                  
         begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                                        
            Declare Acsr Cursor for                                                                            
        Select CashbookNo from CashBook                                                                            
            where SchemeCode in (select schemeCode from Scheme                                                          
                             where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                      
               and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
      and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
         and SeparateCB = 1)) and                                                                             
           (ChequeDate <= @TransDate) and Cleared = 0                                                     
           and Tran_Status = 0 and Posted = 1                                                                                         
           order by ChequeNo                            
         end                            
     else                            
         begin       
            if @RelSchemeNo > 0                           
            Declare Acsr Cursor for                                                                            
            Select CashbookNo from CashBook                                                                            
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                             
           (ChequeDate <= @TransDate) and Cleared = 0                                                     
            and Tran_Status = 0 and Posted = 1                                                                                         
            UNION      
            Select CashbookNo from CashBook                                                                            
            where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                                             
           (ChequeDate <= @TransDate) and Cleared = 0                                                     
            and Tran_Status = 0 and Posted = 1         
            else      
            Declare Acsr Cursor for                                                                            
            Select CashbookNo from CashBook                                                                            
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                             
           (ChequeDate <= @TransDate) and Cleared = 0                                                     
            and Tran_Status = 0 and Posted = 1                                                                                         
            order by ChequeNo                              
         end                            
   end                            
                                              
Open Acsr                                                                            
Fetch from acsr into @CashbookNo                                                                          
while @@fetch_Status = 0                                                                            
begin                             
   if (@FundType = 8)                            
      begin                            
         Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
         b.ChequeNo,SUM(b.Debit),SUM(b.Credit),SUM(b.Debit)-SUM(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                               
         m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
         case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                           
         @MVBalance                                                                           
         from Cashbook b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
         where ((b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
         and b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                            or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                          and                                                                             
         (b.ChequeDate <= @TransDate) and b.Cleared = 0 and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0                                                     
          and b.Posted = 1                                                                                       
         Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,                                               
         b.Payee                           
      end                            
   else                            
    begin                            
  if ((@Pooled = 1) and (@Operational = 1))                                  
         begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                            
            Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
            b.ChequeNo,SUM(b.Debit),SUM(b.Credit),SUM(b.Debit)-SUM(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                               
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                                                                           
           from Cashbook b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
             where b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
               and b.BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1)) and                                                                             
           (b.ChequeDate <= @TransDate) and b.Cleared = 0 and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0                                                     
            and b.Posted = 1                                                                                                                     
            Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,                                                  
            b.Payee                            
         end                            
     else                            
         begin                            
            Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
            b.ChequeNo,SUM(b.Debit),SUM(b.Credit),SUM(b.Debit)-SUM(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                               
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                                                                           
            from Cashbook b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                                                             
           (b.ChequeDate <= @TransDate) and b.Cleared = 0 and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0                                                     
            and b.Posted = 1                        
            --and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                        
            Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,                                                  
            b.Payee       
      
            if @RelSchemeNo > 0      
               Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
               b.ChequeNo,SUM(b.Debit),SUM(b.Credit),SUM(b.Debit)-SUM(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                               
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                                                                           
            from Cashbook b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                                                             
           (b.ChequeDate <= @TransDate) and b.Cleared = 0 and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0                                                     
            and b.Posted = 1                        
            --and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                        
            Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,                                                  
            b.Payee                           
                                      
         end                             
   end                            
                                                                        
   Select @CashbookNo = 0                                                                  
   fetch next from acsr into @CashbookNo                                                                            
end                                                        
Close Acsr                                                                            
Deallocate Acsr                                                           
                                                                            
                                                                            
/* UNPRESENTED CHEQUES ON TAKE-ON */                            
if (@FundType = 8)                               
   begin                            
     Declare Acsr Cursor for                                                                            
     Select distinct(ChequeNo) from UnPresentedCheques                                     
     where ((SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
     and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
 where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
             or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                          and                      
     (TransDate <= @TransDate) and Cleared = 0 and Recon = 0                                                                            
     and len(ltrim(rtrim(ChequeNo))) > 1                                                                            
     order by ChequeNo                            
                            
   end                            
else                                   
  begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                            
            Declare Acsr Cursor for                                                                            
            Select distinct(ChequeNo) from UnPresentedCheques                                                                             
            where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                       where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))                             
            and (TransDate <= @TransDate) and Cleared = 0 and Recon = 0 and len(ltrim(rtrim(ChequeNo))) > 1                                                                
            order by ChequeNo                            
            end                            
     else                            
           begin      
            if @RelSchemeNo > 0                            
            Declare Acsr Cursor for                                                 
            Select distinct(ChequeNo) from UnPresentedCheques                                     
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                             
            (TransDate <= @TransDate) and Cleared = 0 and Recon = 0                                                                            
            and len(ltrim(rtrim(ChequeNo))) > 1                              
            UNION      
            Select distinct(ChequeNo) from UnPresentedCheques                                     
            where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                             
            (TransDate <= @TransDate) and Cleared = 0 and Recon = 0                                                                            
            and len(ltrim(rtrim(ChequeNo))) > 1        
            else      
            Declare Acsr Cursor for                                                 
            Select distinct(ChequeNo) from UnPresentedCheques                                     
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                             
            (TransDate <= @TransDate) and Cleared = 0 and Recon = 0                                                                            
            and len(ltrim(rtrim(ChequeNo))) > 1                              
            order by ChequeNo                            
           end                            
    end                            
                                                                            
Open Acsr                                                                            
Fetch from acsr into @ChequeNo                                                                            
while @@fetch_Status = 0                                                                            
begin                                                                            
    if (@FundType = 8)                               
       begin                             
           Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
           @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
           m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.Particulars,0,b.particulars,                                                
           case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
           @MVBalance                                                                            
           from UnPresentedCheques b                                                     
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
        where ((b.SchemeCode in (select schemeCode from Scheme                        
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)               
and b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                              or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                          and                                                                             
          (b.TransDate <= @TransDate) and b.Cleared = 0 and Recon = 0                                                                            
           and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                 
           Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                             
       end                            
    else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                            
            Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                         
            @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                         
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.Particulars,0,b.particulars,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                                                                            
            from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1)) and                                                                             
            (b.TransDate <= @TransDate) and b.Cleared = 0 and Recon = 0                                                                            
            and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                 
            Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                             
                            
            end                            
    else                      
      begin                            
            Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
            @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                          
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.Particulars,0,b.particulars,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                                                                            
            from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                                                             
            (b.TransDate <= @TransDate) and b.Cleared = 0 and Recon = 0                                                                            
             and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                 
            Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo       
      
            if @RelSchemeNo > 0      
               Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
            @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                          
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.Particulars,0,b.particulars,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                                                                            
            from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                                                             
            (b.TransDate <= @TransDate) and b.Cleared = 0 and Recon = 0                                                                            
             and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                 
            Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                             
          end                            
    end                
        
   select @ChequeNo = ''                                                                          
   fetch next from acsr into @ChequeNo                                                                            
end                                                                            
Close Acsr                                                                          
Deallocate Acsr                                
                                 
/* CASH BOOK */                            
if (@FundType = 8)                               
   begin                                                                           
      Declare Acsr Cursor for                                                                            
      Select CashbookNo from CashBook                                                                            
    where ((SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
        and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                                          or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                          and                                                                             
     (PeriodCleared = @TransDate) and Cleared > 0                                                    
      and Tran_Status = 0 and Posted = 1                             
      --and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                        
      order by ChequeNo                             
   end                             
else                                   
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                            
            Declare Acsr Cursor for                                                          
            Select CashbookNo from CashBook                                                                                                                             
            where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))                             
            and (PeriodCleared = @TransDate) and Cleared > 0                                                    
            and Tran_Status = 0 and Posted = 1                                                                         
            --and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                          
            order by ChequeNo                       
            end                            
        else                            
           begin       
             if @RelSchemeNo > 0                           
             Declare Acsr Cursor for                                                                            
             Select CashbookNo from CashBook                                                                            
             where SchemeCode = @schemeNo and BankCode = @BankCode and                                          
             (PeriodCleared = @TransDate) and Cleared > 0                                                    
             and Tran_Status = 0 and Posted = 1                                                        
             UNION      
             Select CashbookNo from CashBook                                                                            
             where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                      
             (PeriodCleared = @TransDate) and Cleared > 0                                                    
             and Tran_Status = 0 and Posted = 1       
             else      
             Declare Acsr Cursor for                                                                            
             Select CashbookNo from CashBook                                                                            
             where SchemeCode = @schemeNo and BankCode = @BankCode and                                                      
             (PeriodCleared = @TransDate) and Cleared > 0                                                    
             and Tran_Status = 0 and Posted = 1                                                        
              --and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                          
             order by ChequeNo                                  
  end                            
    end                            
                                                                      
Open Acsr                                                                            
Fetch from acsr into @CashbookNo                                                                            
while @@fetch_Status = 0                                         
begin                             
                               
   if (@FundType = 8)                               
      begin                            
          Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
          b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
          m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
          case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
          @MVBalance                                                                            
          from Cashbook b                                                                         
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
          where ((b.SchemeCode in (select schemeCode from Scheme   
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
          and b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                         or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                          and                                                
          (b.PeriodCleared = @TransDate) and b.Cleared > 0                                                                
          and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1 -- len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
          Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee                            
      end                            
   else                                                                                     
    begin                                    
       if ((@Pooled = 1) and (@Operational = 1))                                  
          begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                             
                            
 Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
            b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                            
            m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
            case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
            @MVBalance                                                                            
            from Cashbook b                                                                         
            Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
            where b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
            and b.BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))  and                                                                             
           (b.PeriodCleared = @TransDate) and b.Cleared > 0                                 
            and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1 -- len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
            Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee                            
          end                            
       else                          
          begin                            
             Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
             b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                            
             m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
             case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
             @MVBalance                                                                            
             from Cashbook b                                                      
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
             where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                                                             
            (b.PeriodCleared = @TransDate) and b.Cleared > 0                                                                
             and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1 -- len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                       
             Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee       
      
             if @RelSchemeNo > 0       
                Insert Into #ManualRecon select b.SchemeCode,b.BankCode,@CashbookNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                             
             b.ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.ChequeDate as BankDate,b.Cleared,@TransDate as TransDate,                                            
             m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,0,'CB',b.Description,b.CashTransNo,b.Payee,                                                
             case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
             @MVBalance                                                                            
             from Cashbook b                                                      
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                                            
             where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                                                             
            (b.PeriodCleared = @TransDate) and b.Cleared > 0                                                                
             and b.CashbookNo = @CashbookNo AND B.Tran_Status = 0 and b.Posted = 1 -- len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                       
             Group By b.SchemeCode,b.BankCode,b.ChequeDate,b.Cleared,m.MonthName,b.Description,b.ChequeNo,b.CashTransNo,b.Payee       
                          
          end                            
    end                                           
   select @CashbookNo = 0                                                                          
   fetch next from acsr into @CashbookNo                                                                            
end                                                                            
Close Acsr                                                                            
Deallocate Acsr                                                                            
                                                                          
/* UN-PRESENTED */                                                   
if (@FundType = 8)                               
   begin                            
     Declare Acsr Cursor for                                                                            
     Select distinct(ChequeNo) from UnPresentedCheques                                                                            
     where ((SchemeCode in (select schemeCode from Scheme                                                          
         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
     and BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                  or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                     
                                                          and                                                                             
     (PeriodCleared= @TransDate) and Cleared > 0  and Recon = 0                                                                           
     and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
     order by ChequeNo                             
   end                            
else                                   
    begin                                    
   if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                                  
            select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                            
            Declare Acsr Cursor for                                                                            
            Select distinct(ChequeNo) from UnPresentedCheques                                                                 
            where SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
                  and BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                  where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1))                             
            and                                                                             
            (PeriodCleared= @TransDate) and Cleared > 0  and Recon = 0                                                                       
            and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
            order by ChequeNo                             
            end                            
        else                            
           begin       
            if @RelSchemeNo > 0                           
            Declare Acsr Cursor for                                                                        
            Select distinct(ChequeNo) from UnPresentedCheques                                                                            
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                             
           (PeriodCleared= @TransDate) and Cleared > 0  and Recon = 0                                                                           
            and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
            UNION      
            Select distinct(ChequeNo) from UnPresentedCheques                                                                   
            where SchemeCode = @RelSchemeNo and BankCode = @BankCodeRel and                                                                             
           (PeriodCleared= @TransDate) and Cleared > 0  and Recon = 0                                                                           
            and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))        
            else      
            Declare Acsr Cursor for                                                                        
            Select distinct(ChequeNo) from UnPresentedCheques                                                                            
            where SchemeCode = @schemeNo and BankCode = @BankCode and                                                                             
           (PeriodCleared= @TransDate) and Cleared > 0  and Recon = 0                                                                           
            and ((len(ltrim(rtrim(ChequeNo))) > 1) and (ltrim(rtrim(ChequeNo)) <> '0'))                                                                            
            order by ChequeNo                             
           end                            
    end                                                       
Open Acsr                                                                            
Fetch from acsr into @ChequeNo                                           
while @@fetch_Status = 0                                                                            
begin                           
     if (@FundType = 8)                               
       begin                             Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
         @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                    
         m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                                
         case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                               
         @MVBalance                                                                            
         from UnPresentedCheques b                                                                            
              Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                
         where ((b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)                                           
         and b.BankCode in (select BankCode from SchemeBankBranch where AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)))                      
                        or                      
                                          (SchemeCode = @schemeNo) and (BankCode = @BankCode))                                  
                                                         and                                                                
         (b.PeriodCleared = @TransDate) and b.Cleared > 0 and Recon = 0                                                                            
         and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
   Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                             
       end                            
    else                                   
       begin                                    
         if ((@Pooled = 1) and (@Operational = 1))                                  
            begin                        
               select @InvestScheme = InvestmentScheme from scheme where schemeCode = @SchemeNo                            
                              
               Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                       
               @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                    
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                                
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                                                                            
               from UnPresentedCheques b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                
               where b.SchemeCode in (select schemeCode from Scheme                                                          
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1)               
               and b.BankCode in (select BankCode from SchemeBankBranch where Operational = 1 and AccountCode = @AccountCode                                        
                                          and SchemeNo in (select schemeCode from Scheme                                      
                                                         where PooledInvestment = 1 and InvestmentScheme = @InvestScheme AND ActiveStatus = 1                                  
                                                         and SeparateCB = 1)) and                                                                             
               (b.PeriodCleared = @TransDate) and b.Cleared > 0 and Recon = 0                                                                            
               and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
               Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                            
            end                            
         else                            
            begin                            
               Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
               @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                    
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                                
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                                                                            
               from UnPresentedCheques b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                
      where b.SchemeCode = @schemeNo and b.BankCode = @BankCode and                                                                             
               (b.PeriodCleared = @TransDate) and b.Cleared > 0 and Recon = 0                                                                            
               and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
               Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo       
      
               if @RelSchemeNo > 0       
                  Insert Into #ManualRecon select b.SchemeCode,b.BankCode,b.TransNo,@BankMonth as BankMonth,@BankYear as BankYear,                                                                            
               @ChequeNo,sum(b.Debit),sum(b.Credit),sum(b.Debit)-sum(b.Credit),b.TransDate as BankDate,b.Cleared,@TransDate as TransDate,                                                                    
               m.MonthName+', '+cast(@BankYear as varchar(4)) as Period,1,'UP',b.PartIculars,0,b.Particulars,                                      
               case b.Cleared when 0 then ' ' when 1 then 'X' when 2 then 'R' end as rStatus,@CBBalance,@BKBalance,                                                
               @MVBalance                                                                            
               from UnPresentedCheques b                                                                            
                    Inner Join MonthTable m on @bankMonth = m.MonthNumber                                                
               where b.SchemeCode = @RelSchemeNo and b.BankCode = @BankCodeRel and                                                                             
               (b.PeriodCleared = @TransDate) and b.Cleared > 0 and Recon = 0                                                                            
               and len(ltrim(rtrim(b.ChequeNo))) > 1 and ltrim(rtrim(b.ChequeNo)) = ltrim(rtrim(@ChequeNo))                                                                            
               Group By b.SchemeCode,b.BankCode,b.TransDate,b.Cleared,m.MonthName,b.PartIculars,b.TransNo                           
            end                            
       end                                                                         
  select @ChequeNo = ''                              
  fetch next from acsr into @ChequeNo                                                             
end                                                                            
Close Acsr                                                                            
Deallocate Acsr                                                           
                                                                             
END                                                                                                 
    
if @SortMode = 0                                                                            
   select * from #ManualRecon order by Amount    
else if @SortMode = 1                                                                           
   select * from #ManualRecon order by BankDate     
else if @SortMode = 2                                                                           
   select * from #ManualRecon order by ChequeNo     
else if @SortMode = 3                                                                          
   select * from #ManualRecon order by Particulars    
    
    
/* 0 - Amount, 1 - Date, 2 - ChequeNo, */
go

