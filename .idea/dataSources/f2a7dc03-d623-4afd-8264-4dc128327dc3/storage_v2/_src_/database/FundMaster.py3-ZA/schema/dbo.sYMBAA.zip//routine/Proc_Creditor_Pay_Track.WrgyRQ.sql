CREATE PROCEDURE [dbo].[Proc_Creditor_Pay_Track]  
@SCHEMENO Int,  
@lpoNo Int  
as  
  
  
if object_id('tempdb..#PayTracking') is null  
  
begin  
create table #PayTracking  
(  
        [glcode] [int] IDENTITY(1,1) Primary Key,  
        [Creditor] [varchar](100) NOT NULL ,  
        [CreditDesc][Varchar](100),  
        [Credit][float],  
        [CreditDate][Datetime],  
        [PaymentDate][datetime],  
        [VoucherNo][Int],  
        [ChequeNo][Varchar](30),  
        [PayAmount][float],  
        [PayBalance][float]  
)   
   
end  
  
declare @Creditor varchar(100),@CreditDesc Varchar(100),@Credit float,@CreditDate Datetime,  
        @PaymentDate datetime,@VoucherNo Int,@ChequeNo Varchar(30),@PayAmount float,@PayBalance float,  
        @PaymentNo Int,@TotalPaid float  
  
select @Credit = sum(pt.Quantity * pt.UnitPrice),@CreditDate = p.PayDate,@CreditDesc = p.Description,  
@Creditor = c.Debtor from  
Payables p  
         inner Join PayablesInvoice pt on p.lpoNo = pt.LpoNo and p.schemeNo = pt.schemeNo  
         inner Join CreditorsRegister c on p.CreditorCode = c.DebtorCode and p.schemeNo = c.schemeNo  
where p.schemeNo = @schemeNo and p.lpoNo = @LpoNo  
Group By p.PayDate,c.Debtor,p.Description  
  
SELECT @TotalPaid = 0  

if Exists (select * from PayablesPayment where SchemeNo = @schemeNo and lpoNo = @LpoNo)
begin  
   DECLARE ACSR Cursor for  
   Select PaymentNo,PayDate,Amount   
   from PayablesPayment   
   where SchemeNo = @schemeNo and lpoNo = @LpoNo  
  
   Open acsr  
   fetch from acsr into @PaymentNo,@PaymentDate,@PayAmount  
   while @@fetch_Status = 0  
   begin  
     SELECT @TotalPaid = @PayAmount + @TotalPaid  
  
     Insert Into #PayTracking (Creditor,CreditDesc,Credit,CreditDate,  
                            PaymentDate,VoucherNo,ChequeNo,PayAmount,PayBalance)  
               Values(@Creditor,@CreditDesc,@Credit,@CreditDate,  
                      @PaymentDate,'-','-',@PayAmount,@Credit - @TotalPaid)  
  
     select @PaymentNo = 0,@PayAmount = 0  
     fetch next from acsr into @PaymentNo,@PaymentDate,@PayAmount  
   end  
   Close Acsr  
   Deallocate Acsr
end
else 
begin
  Insert Into #PayTracking (Creditor,CreditDesc,Credit,CreditDate,  
                            PaymentDate,VoucherNo,ChequeNo,PayAmount,PayBalance)  
               Values(@Creditor,@CreditDesc,@Credit,@CreditDate,  
                      getdate(),'-','-',0,@Credit)
end  
  
select * from #PayTracking order by PaymentDate
go

