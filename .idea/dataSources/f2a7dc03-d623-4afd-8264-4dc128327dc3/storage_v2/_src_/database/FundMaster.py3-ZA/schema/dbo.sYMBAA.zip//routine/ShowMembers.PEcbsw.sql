CREATE PROCEDURE [dbo].[ShowMembers]
@SCHEMENO Int
--with Encryption
as
Select MemberNo, upper(sName) as surName,
fName+' '+Onames as OtherNames
from Members
where SchemeNo =  @SchemeNo
Order By MemberNo
go

