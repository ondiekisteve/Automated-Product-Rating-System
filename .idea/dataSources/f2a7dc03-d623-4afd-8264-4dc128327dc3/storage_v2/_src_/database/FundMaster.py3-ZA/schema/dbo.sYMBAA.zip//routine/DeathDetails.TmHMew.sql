CREATE PROCEDURE [dbo].[DeathDetails]
@SCHEMENO Int,
@MemberNo int
--with Encryption
as
select m.schemeNo, m.MemberNo, m.dateofDeath, m.CauseOfDeath, m.DateCertificateReceived, m.CertificateNo, m.AmountofCover, m.MonPension,
       case m.DeathCertificateReceived when 1 then 'Yes'
  when 0 then 'No'
       end as CertificateReceived,
       case m.benPayType  when 1 then 'Lumpsum Payment'
                          when 0 then 'Monthly Pension'
       end as Beneficiaries, 
       D.DeathType
from DeathClaim m 
     inner Join DeathTypes d on m.DeathType = d.DeathCode
where m.SchemeNo = @schemeNo and m.MemberNo = @MemberNo
go

