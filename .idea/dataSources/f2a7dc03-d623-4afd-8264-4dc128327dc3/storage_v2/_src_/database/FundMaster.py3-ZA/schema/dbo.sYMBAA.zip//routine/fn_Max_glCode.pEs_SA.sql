CREATE FUNCTION [dbo].[fn_Max_glCode](@SchemeNo Int)                                 
returns Integer                    
as                      
begin         
 declare @GLCode Int      
       
 select @GLCode = Max(GLCode) + 1 from GLAccountCodes where schemeNo = @schemeNo      
                   
 RETURN(@GLCode)                      
end
go

