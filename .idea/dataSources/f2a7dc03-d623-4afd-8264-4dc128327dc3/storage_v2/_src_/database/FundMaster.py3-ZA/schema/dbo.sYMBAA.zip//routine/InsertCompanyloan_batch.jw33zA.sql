CREATE PROCEDURE [dbo].[InsertCompanyloan_batch]
@SCHEMENO Int,
@memberno int,
@LoanCode int,
@Amount float,
@DateApplied Datetime,
@Term float,
@InterestRate float,
@MonthlyInstal float,
@LoanDesc Varchar(100),
@DateIssued Datetime,
@DateReceived Datetime,
@LoanApplied float,
@DateProcessed Datetime,
@PreparedBy Varchar(100),
@CurrentSalary float,
@CurrentStation Varchar(100),
@LoanType Int,
@BatchDate Datetime
--with Encryption
as

Declare @Pay_Status smallInt,@BatchId Int

if Exists (select * from Member_Loan_Batch where schemeNo = @schemeNo and BatchDate = @BatchDate and BatchMode = 0)
   select @BatchId = BatchId from Member_Loan_Batch where schemeNo = @schemeNo and BatchDate = @BatchDate
   and BatchMode = 0
else
   begin
     select @BatchId = Max(BatchId) from Member_Loan_Batch

     if @BatchId is null select @BatchId = 0
     select @BatchId = @BatchId + 1
     
     Insert into Member_Loan_Batch(schemeNo,BatchId,BatchDate,Batch_Status,BatchMode)
                           Values(@schemeNo,@BatchId,@BatchDate,0,0)
   end


select @Pay_Status = 0

IF NOT Exists (Select MemberNo from Members where schemeNo = @schemeNo and MemberNo = @MemberNo)
   select @Pay_Status = 2
if Exists(select * from MemberCompanyLoan where SchemeNo = @SchemeNo and MemberNo = @MemberNo AND Paid = 0)
   select @Pay_Status = 1


Declare @Loan varchar(50), @fullname varchar(100),@MaxRepaymentStart int,@MaximumTerm int,
@Pay_StartDate Datetime,@Sal_To_Loan_Fraction float

select @MaxRepaymentStart = MaxRepaymentStart,@MaximumTerm = MaximumTerm,@Sal_To_Loan_Fraction = Sal_To_Loan_Fraction from Config_Member_Loans

if @MaxRepaymentStart is null select @MaxRepaymentStart = 60
if @MaximumTerm is null select @MaximumTerm = 18
if @Sal_To_Loan_Fraction is null select @Sal_To_Loan_Fraction = 3.00

select @Pay_StartDate = DateAdd(Day,@MaxRepaymentStart,@DateIssued)

select @Loan = LoanDesc from CompanyLoans where LoanCode = @Loancode


      Insert into MemberCompanyLoan (SchemeNo, MemberNo, LoanCode, Loan,Pay_StartDate,DateApplied,Term,InterestRate,MonthlyInstal,Paid,
                                 LoanDesc, DateIssued, DateReceived,LoanApplied,DateProcessed,Loan_Status,PreparedBy,DatePrepared,
                                 CurrentSalary,CurrentStation,LoanType,Pay_Status,BatchId)
       Values(@SchemeNo,@MemberNo,@LoanCode,@Amount,@Pay_StartDate,@DateApplied,@Term,@InterestRate,@MonthlyInstal,0,
                         @LoanDesc,@DateIssued, @DateReceived,@LoanApplied,@DateProcessed,0,@PreparedBy,GetDate(),
                         @CurrentSalary,@CurrentStation,@LoanType,@Pay_Status,@BatchId)
go

