CREATE VIEW [dbo].[DebtorsListing]      
--with Encryption      
as      
select DISTINCT d.SchemeNo,d.DebtorCode as RefNo,d.Debtor as FullName,t.DebtorDesc as RefType,  
D.DebtorStatus,d.DebtorType      
from DebtorsRegister d      
     Inner Join DebtorType t on d.DebtorType = t.DebtorType      
where d.Onekana = 0
go

