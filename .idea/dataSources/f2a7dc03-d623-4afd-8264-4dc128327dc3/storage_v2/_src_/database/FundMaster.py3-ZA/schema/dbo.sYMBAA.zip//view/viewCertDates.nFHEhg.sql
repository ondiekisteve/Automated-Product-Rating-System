CREATE VIEW [dbo].[viewCertDates]
--with encryption
AS
SELECT Distinct schemeNo,DatePrepared,ReturnDate
FROM pen_certExist
go

