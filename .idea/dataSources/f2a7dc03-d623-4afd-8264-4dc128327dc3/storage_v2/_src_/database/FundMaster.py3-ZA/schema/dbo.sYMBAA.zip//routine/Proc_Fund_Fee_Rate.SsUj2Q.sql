CREATE PROCEDURE [dbo].[Proc_Fund_Fee_Rate]
@FundFeeNo Int,
@SchemeNo Int,
@StartDate datetime,
@EndDate datetime,
@NVRate float,
@PerfRate float,
@AddEdit int
--with Encryption
as
if @AddEdit = 0
   Insert into TBL_Fund_Fee_Rate(schemeNo,StartDate,EndDate,NVRate,PerfRate)
                        Values(@schemeNo,@StartDate,@EndDate,@NVRate,@PerfRate)
else if @AddEdit = 1
   update TBL_Fund_Fee_Rate set startDate= @StartDate,EndDate = @EndDate,
                                NVRate = @NVRate,PerfRate = @PerfRate
   where FundFeeNo = @FundFeeNo
else if @AddEdit = 2
   Delete from TBL_Fund_Fee_Rate where FundFeeNo = @FundFeeNo
go

