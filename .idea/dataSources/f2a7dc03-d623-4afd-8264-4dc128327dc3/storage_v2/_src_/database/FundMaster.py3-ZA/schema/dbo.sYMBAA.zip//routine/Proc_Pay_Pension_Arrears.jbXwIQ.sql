CREATE PROCEDURE [dbo].[Proc_Pay_Pension_Arrears]
@schemeNo Int,
@Paymonth Int,
@PayYear Int
--with Encryption
as

declare @MemberNo varchar(30),@Pension float
declare xCsr cursor for
select PenNo,Pension 
from PensionArrears 
where schemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @PayYear

open xCsr
fetch from xCsr into @MemberNo,@Pension 
while @@FETCH_STATUS = 0
begin
   Update PensionPayroll set Arrears = @Pension
   where SchemeNo = @schemeNo and PenNo = @MemberNo 
   and PayMonth = @Paymonth and PayYear = @PayYear

   select @MemberNo=0,@Pension=0
   fetch next from xCsr into @MemberNo,@Pension 
end
close xCsr
deallocate xCsr
go

