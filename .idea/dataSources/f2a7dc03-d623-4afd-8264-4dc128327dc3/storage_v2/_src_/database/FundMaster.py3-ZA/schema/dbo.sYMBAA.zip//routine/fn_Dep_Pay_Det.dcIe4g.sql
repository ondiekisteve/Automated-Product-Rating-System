CREATE FUNCTION [dbo].[fn_Dep_Pay_Det](@SchemeNo Int,@MemberNo int, @DepCode Int)                             



returns float                



as                  



begin     



 declare @Amount float

 

 select @Amount = sum(Amount) 

 from dependantpaymentDet 

 where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode 



 if @Amount is null select @Amount = 0



 RETURN(@Amount)                  



end
go

