CREATE PROCEDURE [dbo].[repDebitMembers]
@forYear int,
@SCHEMENO Int
as
select
Members.SchemeNo,
Members.MemberNo,
scheme.schemename,
DatePart(Year,GetDate()) as currentyear,
datepart(month, Members.DOExit) as ExitMonth,
(upper(Members.SName) + ', ' + Members.FName + ' ' + Members.ONames) as FullName,
ReasonForExit.ReasonDesc,
(Benefits.EmpCont + Benefits.EmprCont + Benefits.VolContr + Benefits.SpecialContr) as TotBenefits
from Members
inner join ReasonForExit on ReasonForExit.ReasonCode = Members.ReasonForExit
inner join scheme on scheme.schemecode = @schemeno
left join Benefits on (Benefits.SchemeNo = Members.SchemeNo) and (Benefits.MemberNo = Members.MemberNo)
where (Members.SchemeNo = @SchemeNo) and (Members.ReasonForExit <> 0) and (datepart(year, Members.DOExit) = @forYear)
order by members.memberno
go

