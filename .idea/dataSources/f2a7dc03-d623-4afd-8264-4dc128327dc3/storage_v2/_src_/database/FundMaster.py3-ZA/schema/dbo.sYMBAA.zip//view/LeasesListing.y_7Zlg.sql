CREATE VIEW [dbo].[LeasesListing]                        
-- with Encryption                       
as                        
Select L.*, case L.PaymentFreq                         
          when 1 then 'Monthly'                        
          when 2 then 'Quarterly'                        
          when 3 then 'Semi-Annually'                        
          when 4 then 'Annually'                        
          else 'Not Defined'                        
          end as RentFrequency,      
          case L.LeaseCancelled                        
          when 0 then 'Active'                        
          when 1 then 'Cancelled'                                          
          else 'Not Defined'                        
          end as LeaseStatus,      
f.CurrencyDesc as CurrencyCode                        
from Leases l                    
     inner Join CurrencyType f on l.CurrCode = f.CurrCode
go

