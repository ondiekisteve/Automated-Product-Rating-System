CREATE TRIGGER [dbo].[Trg_Invest_Debit_Credit_Note] ON [dbo].[TBL_Invest_Debit_Credit_Note] 
FOR INSERT
AS

declare @SchemeNo Int,@InvCode Int,@DrCrNoteNo Int,@UserName varchar(60),@drCr smallint,@InvestCode Int

select @UserName = user

select @schemeNo = SchemeNo,@DrCrNoteNo = DrCrNoteNo,@InvCode = InvCode,@drCr = drCr from Inserted

select @InvestCode = InvestCode from Investments where SchemeNo = @SchemeNo and InvCode = @InvCode


if @InvestCode =  2
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,127,@DrCrNoteNo,2,@UserName
else if @InvestCode =  4
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,137,@DrCrNoteNo,2,@UserName
else if @InvestCode =  5
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,157,@DrCrNoteNo,2,@UserName
else if @InvestCode =  7
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,147,@DrCrNoteNo,2,@UserName
else if @InvestCode =  8
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,168,@DrCrNoteNo,2,@UserName
else if @InvestCode =  9
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,215,@DrCrNoteNo,2,@UserName
else if @InvestCode =  10
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,175,@DrCrNoteNo,2,@UserName
else if @InvestCode =  11
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,185,@DrCrNoteNo,2,@UserName
else if @InvestCode =  12
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@InvCode,@InvestCode,225,@DrCrNoteNo,2,@UserName
go

