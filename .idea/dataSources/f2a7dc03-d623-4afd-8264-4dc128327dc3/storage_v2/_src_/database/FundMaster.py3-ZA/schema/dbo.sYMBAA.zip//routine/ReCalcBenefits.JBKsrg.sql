CREATE procedure ReCalcBenefits @schemeNo int
as

declare @startDate datetime,@EndDate datetime,
@CurMonth int,@CurYear int

declare xcsr cursor for
select SchemeNo,Startdate,EndDate from schemeYears where schemeNo = @schemeNo

open xcsr
fetch from xcsr into @schemeNo,@startDate,@EndDate
while @@fetch_status = 0
begin
  select @CurMonth = datepart(Month,@EndDate),@CurYear = datePart(Year,@EndDate)

  update SchemeYears set YearClosed = 0 where schemeNo = @schemeNo and EndDate = @EndDate

  Exec CalcBenefits @schemeNo,@CurMonth,@CurYear,0

  Exec Proc_closeYear @schemeNo,@StartDate,@EndDate

  update SchemeYears set YearClosed = 0 where schemeNo = @schemeNo and EndDate = @EndDate 
 
  select @schemeNo=0,@CurMonth=0,@CurYear=0

  fetch next from xcsr into @schemeNo,@startDate,@EndDate
end
close xcsr
deallocate xcsr
go

