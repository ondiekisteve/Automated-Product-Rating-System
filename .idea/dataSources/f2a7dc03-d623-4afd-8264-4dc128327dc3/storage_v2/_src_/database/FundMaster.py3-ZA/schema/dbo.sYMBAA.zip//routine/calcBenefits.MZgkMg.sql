/*                        
  Oct 11,2011 at Aflife - Use of MemberOpeningBalances for Provisional balances other than Benefits                        
                          
  Added ProvOrFinal - 0 (provisional) , 1 - (Final)                        
                        
*/                        
                        
CREATE PROCEDURE [dbo].[calcBenefits]                                                                              
@SCHEMENO Int,                                                                              
@CurMonth int,                                                                              
@curyear int,                                                                              
@IntMode Int                                                                              
--with Encryption                                                                              
as                                                                              
                                                                              
declare @memberNo int                                                                              
declare @totEmp float                                                                              
declare @totEmpr float                                                                              
declare @totVol float                                                                              
declare @totSpecial float                                                                              
declare @CalculationMode int                                                                              
declare @hasBal bit                                                                              
declare @PretotEmp float                                                                              
declare @PretotEmpr float,@PretotAVC FLOAt,@totEmpTransfer float,                                                                              
@totEmprTransfer float,@BalanceofInt smallInt,@StartDate Datetime,@EndDate Datetime,@totBenef float,                                                                              
@ServiceTime Varchar(100),@RetSal float,                                                                              
@Lumpsum float, @UnReduced float,@DoExit Datetime,@xMonth Int,@xYear Int,                                                                              
@ProcessDate Datetime,@InterestRate float,@ShowInterest Int,                                                                              
@EmpInterest float,@EmprInterest float,@VolInterest float,@SpecInterest float,@DBBenefits float,                                                                              
@LoanBalance float,@Calc_Status smallInt,@gepf smallInt,@TotDeferred float,@DefInterest float,                                                              
@InitDoCalc datetime,@ActStatus smallInt,@LastDate datetime,@PeriodClosed smallint,                                                      
@funcResult int, @currYear int,@retCode int, @AcctPeriod int, @PeriodToUse int,@ActMode Int,@FundType Int,                                            
@DoCalc datetime,@ExitReason int,@IncludeWith smallint,@DateDec datetime,@OrigIntMode smallint,@Aflife smallint,            
@UserName varchar(50)                                                                              
                                                                    
set nocount off   
  
Select @ActMode = ActMode,@FundType = FundTypeCode,@ShowInterest = ShowInterest,@gepf = gepf,@Aflife = Aflife from Scheme where schemeCode = @schemeNo                  
  
if @FundType = 9 /* Beneficiary Trust Fund */  
   begin  
     Exec GetLastDate @CurMonth,@CurYear,@ProcessDate Out   
       
     Exec Proc_BTF_Balances @SchemeNo,@ProcessDate,@IntMode    
   end  
else  
   BEGIN                
--BEGIN TRY                
    --BEGIN TRANSACTION;             
            
select @UserName = user                                         
                                          
select @OrigIntMode = @IntMode                                                 
                                                  
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out                                                      
                                                      
Select @PeriodClosed = YearClosed                                                         
from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod                                                      
                                        
if @PeriodClosed is null select @PeriodClosed = 0                                        
                                                      
if @PeriodClosed >= 1                                               
   begin                                                      
     raiserror('You cannot process member balances for a closed period',16,1)                                                            
     return                             
   end                                                      
else                                                      
   begin        
         
   /* Reset Income Distribution to Zero */      
   Update SchemeYears set IncDistributed = 0 where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod                                                   
                                                                              
SELECT @DBBenefits = 0.0,@LoanBalance = 0.0,@Calc_Status = 0 /* Year End */                                       
                                                          
                                                            
Exec GetLastDate @CurMonth,@CurYear,@ProcessDate Out                                                               
                                                            
EXEC Proc_Get_Int_Rate @schemeNo,@ProcessDate,@IntMode,@InterestRate Out                                           
                                          
Exec DBO.Proc_Get_Int_Date @schemeNo,@ProcessDate,@DateDec Out                                                               
                                                          
Exec Proc_Clean_Benefits @SchemeNo                                                                               
                                       
Select @ActMode = ActMode,@FundType = FundTypeCode,@ShowInterest = ShowInterest,@gepf = gepf,@Aflife = Aflife from Scheme where schemeCode = @schemeNo                                                                              
                                         
if @gepf is null select @gepf = 1                             
if @Aflife is null select @Aflife = 0                                                                             
                                                
if @ShowInterest is null select @ShowInterest = 0                                                                              
                                                             
if @ActMode  is null select @ActMode = 0                                                                              
                                                          
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out          
        
/* Note the Interest Mode used and the InterestRate */        
Update schemeYears set IntMode = @IntMode,     
Interestrate = @InterestRate where schemeNo = @SCHEMENO and AcctPeriod  = @AcctPeriod          
                                                                        
/* 22/5/2006*/                                                                              
---Exec Proc_Load_Conts @SchemeNo,@AcctPeriod                                                                              
                                                                              
--Exec dbo.Proc_Clean_Uchafu @schemeNo,@AcctPeriod                                                                              
                                                                              
Select @StartDate = StartDate,@EndDate = EndDate                                                                               
from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod                         
                        
/* Delete provisional Balances */                        
delete from memberOpeningBalances where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and ProvOrFinal = 0                          
delete from UnRegisteredBalances where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and ProvOrFinal = 0                                             
                                                                            
Select @PeriodToUse = @AcctPeriod - 1                                                                              
                                                                              
select @CalculationMode = CalculationMode,@BalanceofInt = CalcBalanceofInterest,@IncludeWith = IncludeWith                                                                               
from ConfigYearEnd where SchemeNo = @schemeNo                                                                              
                                         
if @BalanceofInt is null select @BalanceofInt = 0                                            
if @IncludeWith is null select @IncludeWith = 0                                                 
                                                         
                                                                                                          
declare membersCsr cursor for                                          
select distinct MemberNo,InitialDoCalc,ActiveStatus,ReasonforExit,DoCalc from Members                   
where                                                                              
SchemeNo = @schemeNo and ((ReasonForExit = 0)                                                                             
or                                                    
(ReasonforExit > 0 and DoCalc >= @ProcessDate))                                                                  
order by MemberNo                        
                                                                                                           
open membersCsr                                                                              
                                                                            
fetch next from membersCsr                                                                       
into @memberNo,@InitDoCalc,@ActStatus,@ExitReason,@DoCalc                                                       
while (@@fetch_status = 0)                                                                              
begin                                                                              
                                                                              
  Update Members set ProjectReason = 0,ProjectDoCalc = 'Jan 01,1900' where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                              
                                            
  if ((@OrigIntMode = 1) and (@IncludeWith = 1))                                          
     begin                                            
        if ((@ExitReason > 0) and (@DoCalc >= @ProcessDate) and (@DoCalc <= @DateDec))                                          
        select @IntMode = 0                                          
        else                                          
            select @IntMode = @OrigIntMode                                          
     end                                          
  else                                          
     select @IntMode = @OrigIntMode                                           
     
                                                                     
  if exists(select * from memberOpeningBalances where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @PeriodToUse) select @hasBal = 1                                                                             
  else select @hasBal = 0                                                                              
                                                                              
if @CalculationMode = 1                                              
     begin          
         exec Proc_CalcMonthlyInterest @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,                                                                              
     @totEmpTransfer out, @totEmprTransfer out,@PreTotEmp out,@PreTotEmpr out,@PreTotAvc out                                                          
    end                                                                              
else if @CalculationMode = 0                                                                              
       begin                                                                              
 exec Proc_CalcMonthlyInterestSI   @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                                                               
                                           
  if @hasBal = 1                   
            Exec  Proc_CalcMonthlyInterestPre @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@PretotEmp output, @PretotEmpr output,@PreTotAvc output                                                                              
         else                                                                              
            begin                                                                              
                select @PreTotEmp =0,@PreTotEmpr =0,@PreTotAvc = 0                                                                              
            end                                                                              
    end                                                                              
  else  if @CalculationMode = 2                                          
         exec Proc_CalcMonthlyInterestAVG @schemeNo, @memberNo, @CurMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                                                                
  else  if @CalculationMode = 4                                                                              
        begin                                                                              
         exec Proc_CalcMonthlyInterestAVGComp_YE @schemeNo, @memberNo, @CurMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,                                                                            
  
         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out,@TotDeferred Out,@DefInterest out                                                         
        end                                                                              
else  if @CalculationMode = 5                                                                              
         exec Proc_CalcMonthlyInterestAVGCOMP_SI @schemeNo, @memberNo, @CurMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,                                                                             
 
         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out                                                                                 
  else if @CalculationMode = 6                                                                              
        exec Proc_CalcMonthlyInterestSI_Mon @schemeNo, @memberNo, @CurMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                                                                
  else if @CalculationMode = 7                                                                              
        exec Proc_CalcMonthlyInterestSI_NonPro @schemeNo, @memberNo, @CurMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                                                                
  else if @CalculationMode = 9                                                              
        exec Proc_CalcMonthlyInterest_Daily @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@Calc_Status,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,                       
       
          
         @totEmpTransfer out, @totEmprTransfer out,@PreTotEmp out,@PreTotEmpr out,@PreTotAvc out,@TotDeferred out                                                                    
 else if @CalculationMode = 11                                                                              
     begin                                                                              
         exec Proc_CalcMonthlyInterest_MonthDep @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,                                                                              
         @totEmpTransfer out, @totEmprTransfer out,@PreTotEmp out,@PreTotEmpr out,@PreTotAvc out                                                                              
    end                                                                        
 else if @CalculationMode = 12                                                                              
    begin                                                                              
        exec Proc_CalcMonthlyInterestSI_GEPF @schemeNo, @memberNo, @CurMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output                                                                                
                                                                                      
        Exec Proc_Member_Loans_DecDate @SCHEMENO,@MemberNo,@ProcessDate,@LoanBalance Out                                                         
   end                                                     
else if @CalculationMode = 13                                                              
        exec Proc_CalcMonthlyInterest_Daily_Mon @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@Calc_Status,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,                                                                 
 
    
       
       
          
            
              
         @totEmpTransfer out, @totEmprTransfer out,@PreTotEmp out,@PreTotEmpr out,@PreTotAvc out,@TotDeferred out                                                          
 else                                                                         
     begin                                                                              
         exec Proc_CalcMonthlyInterest @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,                                                                              
         @totEmpTransfer out, @totEmprTransfer out,@PreTotEmp out,@PreTotEmpr out,@PreTotAvc out                                                                              
    end                                                 
                                                            
  if @PreTotEmp is null select @PreTotEmp = 0                                                                              
  if @PreTotEmpr is null select @PreTotEmpr=0                                                           
 if  @PreTotAVC is null select @PreTotAVC=0                           
  if  @totEmpTransfer is null select @totEmpTransfer = 0                                                                            
  if  @totEmprTransfer is null select @totEmprTransfer = 0                                                                          
  if  @totDeferred is null select @totDeferred = 0                                                                              
  if  @DefInterest is null select @DefInterest = 0                                                                          
                                              
                                                                      
                                                                              
if @FundType = 2                                  
   Exec GetCapensal @schemeNo,@MemberNo,@ProcessDate                                   
/*                     
BEGIN                                                                              
    if @ActMode = 0                                                                              
       begin                                                                              
          Exec [DBO].[dbBenef_NRD] @schemeno,@memberno,@EndDate,@totBenef out,@serviceTime out                                                                              
                                                         
          Exec [DBO].[Proc_DBBenefits] @schemeno,@memberno, @DBBenefits out                                                                              
       end                                                                              
    else                                                                              
       begin                                                                              
           Select @RetSal = capensal from Members where schemeNo = @schemeNo and MemberNo = @MemberNo                                       
                                                                              
           Exec CalcPercentageBenefits_NSSF @schemeNo, @MemberNo,@RetSal, @EndDate, @Lumpsum out, @totBenef out,                                                                              
                @UnReduced out                                                                               
                                                                            
       select @RetSal = 0                                                                              
      end                                                                              
   END                                                                       
  */                                                                      
       if @totBenef is null select @totBenef  = 0                                                         
                                                              
       if ((@InitDoCalc < @ProcessDate) and (@ActStatus = 6))                                                              
          begin                         
              Insert Into MemberOpeningBalances (schemeNo,MemberNo,schemeYear,SchemeMonth,AcctPeriod,                                                                            
              EmpCont,EmprCont,EmpVolCont,EmprVolCont,PreEmpCont,PreEmprCont,PreAVC,Transfer,LockedIn,                                                                            
              EmpInt,EmprInt,VolInt,SpecInt,LoanBalance,EmpFees,EmprFees,DeferredAmt,DefInterest,ProvOrFinal,            
              UserName,TransDate)                                  
              Values(@schemeNo,@MemberNo,@CurYear,@CurMonth,@AcctPeriod,                                                                            
                     0,@totEmpr,0,@totSpecial,0,@PreTotEmpr,       
                     0,0,@totEmprTransfer,0,@EmprInterest,0,@SpecInterest,@loanbalance,                                               
                     0,0,@TotDeferred,@DefInterest,0,@UserName,GetDate())                          
                                                                        
              if not Exists(select MemberNo from Benefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))                                                                                       
                    insert into  Benefits                                                       
                   (SchemeNo, MemberNo, EmpCont, EmprCont, SpecialContr, VolContr, CalcYear,PreEmpCont,PreEmprCont,PreAvc,EmpTransfer,EmprTransfer,BenefitsDB,                                                                             
                    ProcessDate,CalcInterest,EmpInt,EmprInt,VolInt,SpecInt,BenefitsDB_Cash,LoanBalance,                                                      
                    IncludeRec,ActiveStatus,VestedCont,MACTIVE,DeferredAmt,DefInterest)                                                         values                                                                              
                   (@schemeNo, @memberNo, 0, @totEmpr, @totSpecial, 0 , datepart(year,getdate()),0,@PreTotEmpr,0,0,@totEmprTransfer,@totBenef,                                                                              
                    @ProcessDate,@InterestRate,0, @EmprInterest,0,@SpecInterest,@DBBenefits,@LoanBalance,1,1,0,1,                                                                          
                    @TotDeferred,@DefInterest )                                                                              
           else                                                                              
                   update Benefits set EmpCont = 0, EmprCont = @totEmpr, SpecialContr = @totSpecial,VolContr = 0,PreEmpCont = 0,PreEmprCont=@PreTotEmpr,                                                                              
                                   PreAvc = 0,EmpTransfer = 0,EmprTransfer = @totEmprTransfer,BenefitsDB = @totBenef,                 
                   ProcessDate = @ProcessDate,CalcInterest = @InterestRate,                                                                              
                         EmpInt = 0, EmprInt = @EmprInterest,VolInt = 0,SpecInt = @SpecInterest,                                                                              
                         BenefitsDB_Cash = @DBBenefits,loanbalance = @loanbalance,IncludeRec = 1,ActiveStatus = 1,                                                  
                         DeferredAmt = @TotDeferred,DefInterest = @DefInterest                                                                                
                   where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)                                                               
          end                                                              
       else                                                              
          begin                                                                             
              Insert Into MemberOpeningBalances (schemeNo,MemberNo,schemeYear,SchemeMonth,AcctPeriod,                                                                            
                           EmpCont,EmprCont,EmpVolCont,EmprVolCont,PreEmpCont,PreEmprCont,PreAVC,Transfer,LockedIn,                                                                            
                           EmpInt,EmprInt,VolInt,SpecInt,LoanBalance,EmpFees,EmprFees,DeferredAmt,DefInterest,ProvOrFinal,            
                           UserName,TransDate)                                                                            
              Values(@schemeNo,@MemberNo,@CurYear,@CurMonth,@AcctPeriod,            
                     @totEmp,@totEmpr,@totVol,@totSpecial,@PreTotEmp,@PreTotEmpr,                                                                            
                     @PreTotAvc,@totEmpTransfer,@totEmprTransfer,@EmpInterest,@EmprInterest,                        
                     @VolInterest,@SpecInterest,@loanbalance,                                                                            
                     0,0,@TotDeferred,@DefInterest,0,@UserName,GetDate())                         
                                                                
               if not Exists(select MemberNo from Benefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))                                                                                       
                  insert into  Benefits                                                                              
                   (SchemeNo, MemberNo, EmpCont, EmprCont, SpecialContr, VolContr, CalcYear,PreEmpCont,PreEmprCont,PreAvc,EmpTransfer,EmprTransfer,BenefitsDB,                                                                              
                    ProcessDate,CalcInterest,EmpInt,EmprInt,VolInt,SpecInt,BenefitsDB_Cash,LoanBalance,                                         
                    IncludeRec,ActiveStatus,VestedCont,MACTIVE,DeferredAmt,DefInterest)                                                                              
                    values                                                                              
                   (@schemeNo, @memberNo, @totEmp, @totEmpr, @totSpecial, @totVol , datepart(year,getdate()),@PreTotEmp,@PreTotEmpr,@PreTotAvc,@totEmpTransfer,@totEmprTransfer,@totBenef,                                                                   
                    @ProcessDate,@InterestRate,@EmpInterest, @EmprInterest,@VolInterest,@SpecInterest,@DBBenefits,@LoanBalance,1,1,0,1,                                                                          
                    @TotDeferred,@DefInterest )                                                                              
               else                                                                              
                   update Benefits set EmpCont = @totEmp, EmprCont = @totEmpr, SpecialContr = @totSpecial,VolContr = @totVol,PreEmpCont = @PreTotEmp,PreEmprCont=@PreTotEmpr,                                                      
                                    PreAvc = @PreTotAvc,EmpTransfer = @totEmpTransfer,EmprTransfer = @totEmprTransfer,BenefitsDB = @totBenef,                                                                              
                   ProcessDate = @ProcessDate,CalcInterest = @InterestRate,                                                                              
                   EmpInt = @EmpInterest, EmprInt = @EmprInterest,VolInt = @VolInterest,SpecInt = @SpecInterest,                                                                              
                         BenefitsDB_Cash = @DBBenefits,loanbalance = @loanbalance,IncludeRec = 1,ActiveStatus = 1,                                                                          
                         DeferredAmt = @TotDeferred,DefInterest = @DefInterest                                                                                
                   where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)                                                               
            end                                                                              
                                         
   select @EmpInterest  = 0,@EmprInterest =0,@VolInterest =0,@SpecInterest =0,@totEmp=0, @totEmpr=0, @totSpecial=0, @totVol=0,                                                                              
       @PreTotEmp=0,@PreTotEmpr=0,@PreTotAvc=0,@totEmpTransfer=0,@totEmprTransfer=0,@totBenef=0,@DBBenefits = 0,@loanbalance = 0,                                             
       @TotDeferred=0,@DefInterest=0,@ActStatus=1,@ExitReason = 0,@IntMode = 0                                                                                                       
  fetch next from membersCsr                                                                             
  into @memberNo,@InitDoCalc,@ActStatus,@ExitReason,@DoCalc                                                                               
                                                                              
end                           
                                                                              
close membersCsr                                                                              
deallocate membersCsr                                                                              
        
/* Reset Interest rates mode */                                      
                                      
select @IntMode = @OrigIntMode                                                                              
                                                                              
exec DBO.calcBenefits_Un @schemeNo, @curMonth,@CurYear,@IntMode                                                                              
                                    
exec DBO.calcBenefitsDeferred @schemeNo, @curMonth, @CurYear,@IntMode                                                                              
                                                                              
if @gepf = 1                                            
   Exec DBO.calcBenefits_Surplus @schemeNo, @curMonth, @CurYear,@IntMode /* GEPF */                                                            
                                                                              
Update Members set CompanyId = 1 where CompanyId is null and SchemeNo = @schemeNo                                                                 
Update Members set MemberClass = 'N/A' where MemberClass is null and SchemeNo = @schemeNo                                                                 
                                                     
Exec Proc_Sort_IncludeRec @SchemeNo,@ProcessDate                               
                            
if @Aflife = 1                                                    
   Exec Proc_Prov_Final_Diff_Early @SchemeNo,@ProcessDate                               
                                                 
end                 
/*                
COMMIT TRANSACTION;                
END TRY                
BEGIN CATCH                
  raiserror('The Transaction was cancelled',16,1)                
  ROLLBACK TRANSACTION;                
                
END CATCH;           
*/                                                  
 END                                               
set nocount off
go

