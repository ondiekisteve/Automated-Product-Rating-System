CREATE PROCEDURE [dbo].[repContSchedule]                      
@SCHEMENO Int,                      
@startDate Datetime,                      
@endDate Datetime,  
@SponsorCode Int                  
--with Encryption                      
 AS                      
                      
if object_id('tempdb..##ContSchedule') is null                      
                      
begin                      
create table #ContSchedule                      
(                      
   [schemeName] [varchar] (120) not null,                      
   [schemeNo][varchar](15)  not null,                
   [glcode] [int] IDENTITY(1,1),                      
   [MemberNo] int  not null,                      
   [fullname][varchar](100) null,               
   [IDNumber][varchar](20) null,              
   [PayrollNo][varchar](20) null,                     
   [EmpCont][float] not null,                      
   [EmprCont][float] not null,                      
   [VolContr][float] not null,                      
   [SpecialContr][float] not null,                      
   [nssfe][float] not null,                      
   [nssf][float] not null,                      
   [AugCont][float] null,                      
   [totContr][float] not null,                      
   [StartDate][Datetime],                      
   [EndDate][Datetime],                      
   [CheckNo][Varchar](15),                      
   [Transfer][float],                      
   [SponsorName][varchar](100),                      
   [PoolName][varchar](120)                
constraint pk_membList primary key (schemeNo, glcode)                      
)                      
                      
end                      
                      
   declare @schemeName varchar (120),                      
   @MemberNo varchar (15),                      
   @fullname varchar (100),@IDNumber varchar(20),@PayrollNo varchar(20),                      
   @EmpCont float,                     
   @EmprCont float,                      
   @VolContr float,                      
   @nssfe float,                      
   @nssf float,                     
   @totContr float,                      
   @SpecialContr float,                      
   @CheckNo varchar(15),@AugCont float,@Transfer float,@SponsorName varchar(100),@SchemeMode smallInt,                    
   @TransferUn float,@Arrears float,@PooledInvestment smallInt,@FundType varchar(2),                
   @SchemeCode Int,@PoolName varchar(120),@ArrearsR float,@TransferUnR float,@TransferR float                     
                         
  select @PoolName = schemeName,@SchemeMode = SchemeMode,@PooledInvestment = PooledInvestment,                
  @FundType = FundType from scheme where schemeCode = @schemeNo                      
                
if @SchemeMode is null select @SchemeMode = 0                
                
if @FundType = 'PF'                  
BEGIN                   
Declare MembListCsr cursor for                  
select schemeCode,schemeName,SchemeMode from Scheme                  
where PooledInvestment = 1 and InvestmentScheme = @schemeNo                  
                  
Open MembListCsr                  
Fetch from MembListCsr into @schemeCode,@schemeName,@SchemeMode                  
while @@fetch_Status = 0                  
begin                 
if @SchemeMode is null select @SchemeMode = 0                
                       
if @SchemeMode = 0                      
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.EmpCont + cs.ExcessEmpcont) AS EmpCont,                      
Sum(cs.EmprCont + cs.ExcessEmprCont) AS EmprCont,                      
Sum(cs.SpecialContr + cs.ExcessSpecial) AS SpecialContr,                      
Sum(cs.VolContr + cs.ExcessVolContr) AS VolContr,                      
Sum(cs.NssfE) AS NssfE,                      
Sum(cs.Nssf) AS NssF,                      
sum(cs.AugCont) as AugCont,                      
SUM(cs.EmpCont + cs.EmprCont + cs.SpecialContr +cs.VolContr + cs.NssfE + cs.Nssf                     
+ cs.ExcessEmpcont + cs.ExcessEmprCont + cs.ExcessVolContr + cs.ExcessSpecial + cs.AugCont) AS TotContr,       
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo,''                      
FROM Contributionssummary cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo                      
WHERE ((cs.Datepaid >= @startDate) and           
               (cs.Datepaid <= @endDate)) and Cs.SchemeNo = @schemeCode                            
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno                      
else if @schemeMode = 1                      
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.EmpCont + cs.ExcessEmpcont) AS EmpCont,                      
Sum(cs.EmprCont + cs.ExcessEmprCont) AS EmprCont,                      
Sum(cs.SpecialContr + cs.ExcessSpecial) AS SpecialContr,                      
Sum(cs.VolContr + cs.ExcessVolContr) AS VolContr,                      
Sum(cs.NssfE) AS NssfE,                      
Sum(cs.Nssf) AS NssF,                      
sum(cs.AugCont) as AugCont,                      
SUM(cs.EmpCont + cs.EmprCont + cs.SpecialContr +cs.VolContr + cs.NssfE + cs.Nssf + cs.ExcessEmpcont + cs.ExcessEmprCont + cs.ExcessVolContr + cs.ExcessSpecial + cs.AugCont) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo,                      
s.SponsorName                      
FROM Contributionssummary cs                      
           Inner Join  Members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo                      
           inner join Sponsor s on cs.schemeNo = s.SchemeNo and cs.SponsorCode = s.SponsorCode                     
WHERE  cs.SchemeNo = @schemeCode and ((cs.Datepaid >= @StartDate) and (cs.Datepaid <= @EndDate))                                
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo,s.SponsorName                      
order by cs.memberno                      
                      
                      
open ContrCsr                      
                      
fetch from ContrCsr into @schemeCode, @MemberNo, @EmpCont, @EmprCont, @SpecialContr, @VolContr, @nssfe, @nssf, @AugCont,@totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo,                      
                         @SponsorName                      
                      
while @@fetch_Status = 0                      
begin                      
      select @Transfer = sum(EmpTransfer + AVCTransfer),        
             @TransferR = sum(EmprTransfer + AVCErTransfer + DeferredAmt)        
      from MemberTransfer                      
      where SchemeNo = @schemeCode and MemberNo = @MemberNo and                      
      TransferDate >= @startDate and TransferDate <= @endDate                      
                      
      if @Transfer is null select @Transfer = 0         
      if @Transferr is null select @Transferr = 0                     
                    
      select @TransferUn = sum(EmpTransfer + AVCTransfer),        
      @TransferUnR = sum(EmprTransfer + AVCErTransfer + DeferredAmt)           
      from MemberTransferUn                      
      where SchemeNo = @schemeCode and MemberNo = @MemberNo and                      
      TransferDate >= @startDate and TransferDate <= @endDate                      
                      
      if @TransferUn is null select @TransferUn = 0                    
      if @TransferUnR is null select @TransferUnR = 0              
                    
      select @Arrears = sum(ArEmpCont + ArVolcontr + ArEmpCont_Un),        
             @Arrearsr = sum(ArEmprCont + ArSpecial + ArEmprCont_Un)        
      from ContributionArrears                      
      where SchemeNo = @schemeCode and MemberNo = @MemberNo and                      
      DatePaid >= @startDate and DatePaid <= @endDate                      
                      
      if @Arrears is null select @Arrears = 0          
      if @ArrearsR is null select @ArrearsR = 0       
      
                   
      insert into #ContSchedule (schemeNo, SchemeName, MemberNo, Fullname,IDNumber,PayrollNo, startDate, EndDate,        
                                 EmpCont, EmprCont, SpecialContr, Volcontr,nssf, nssfe, totContr,CheckNo,AugCont,                      
                                 Transfer,SponsorName,PoolName)                      
                      Values (@schemeCode, @schemeName, @memberNo, @fullname,@IDNumber,@PayrollNo, @StartDate, @endDate,         
                              @EmpCont + @Arrears, @EmprCont + @ArrearsR, @SpecialContr, @VolContr, @nssf, @nssfe,
                              @totContr + @Transfer + @TransferUn + @Transferr + @TransferUnr + @Arrears + @Arrearsr,                      
                              @CheckNo,@AugCont,@Transfer + @TransferUn + @Transferr + @TransferUnr,@SponsorName,@PoolName)                      
                       
      select @Transfer = 0,@SponsorName = '',@Arrears = 0,@TransferUn = 0,@IDNumber='',@PayrollNo='',        
             @Transferr = 0,@Arrearsr = 0,@TransferUnr = 0,@MemberNo = 0                     
fetch next from ContrCsr into @schemeCode, @MemberNo, @EmpCont, @EmprCont, @SpecialContr, @VolContr, @nssfe, @nssf, @AugCont,@totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo,                      
                              @SponsorName                      
end                      
           
Close ContrCsr                      
Deallocate ContrCsr                      
                      
/* Members with Transfers but without Contributions */                      
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS EmpCont,                      
SUM(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM MemberTransfer cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo                      
WHERE ((cs.TransferDate >= @startDate) and                      
               (cs.TransferDate <= @endDate)) and Cs.SchemeNo = @schemeCode                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno                      
Open ContrCsr                      
fetch from ContrCsr Into @schemeCode, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
while @@fetch_Status = 0                      
begin            
          
   select @TransferUn = sum(EmpTransfer + EmprTransfer + AVCTransfer + AVCErTransfer + DeferredAmt)           
      from MemberTransferUn                      
      where SchemeNo = @schemeCode and MemberNo = @MemberNo and                      
      TransferDate >= @startDate and TransferDate <= @endDate                      
                      
      if @TransferUn is null select @TransferUn = 0            
                    
   if @schemeMode = 1                      
      select @SponsorName = S.SponsorName from Sponsor s                      
      Inner join Members m on s.SponsorCode = m.SponsorCode                      
      and s.SchemeNo = m.SchemeNo and m.MembernO = @memberNo                      
      where s.SchemeNo = @schemeCode                      
   else                      
      select @SponsorName = ''            
          
                       
                      
   insert into #ContSchedule (schemeNo, SchemeName, MemberNo, Fullname,IDNumber,PayrollNo, startDate, EndDate, EmpCont, EmprCont, SpecialContr, Volcontr,nssf, nssfe, totContr,CheckNo,AugCont,                      
                                 Transfer,SponsorName,PoolName)                      
   Values (@schemeCode, @schemeName, @memberNo, @fullname,@IDNumber,@PayrollNo, @StartDate, @endDate, 0, 0,0,0,0,0, @totContr + @TransferUn,                      
                              @CheckNo,0,@EmpCont + @TransferUn,@SponsorName,@PoolName)                      
                       
   select @SponsorName = '',@totContr = 0,@EmpCont = 0,@IDNumber='',@PayrollNo='',@TransferUn = 0                      
   fetch next from ContrCsr Into @schemeCode, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
end                      
Close ContrCsr                      
Deallocate ContrCsr                      
                    
/* Members with Un Registered Transfers but without Contributions */                      
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                    
Sum(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS EmpCont,                      
SUM(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM MemberTransferUn cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo    WHERE ((cs.TransferDate >= @startDate) and                      
               (cs.TransferDate <= @endDate)) and Cs.SchemeNo = @schemeCode                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno                      
Open ContrCsr                      
fetch from ContrCsr Into @schemeCode, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
while @@fetch_Status = 0                      
begin                      
   if @schemeMode = 1                      
      select @SponsorName = S.SponsorName from Sponsor s                      
      Inner join Members m on s.SponsorCode = m.SponsorCode                      
      and s.SchemeNo = m.SchemeNo and m.MembernO = @memberNo                      
      where s.SchemeNo = @schemeCode                      
   else                      
      select @SponsorName = ''                      
                      
   insert into #ContSchedule (schemeNo, SchemeName, MemberNo, Fullname,IDNumber,PayrollNo,startDate, EndDate, EmpCont, EmprCont, SpecialContr, Volcontr,nssf, nssfe, totContr,CheckNo,AugCont,                      
                                 Transfer,SponsorName,PoolName)                      
   Values (@schemeCode, @schemeName, @memberNo, @fullname,@IDNumber,@PayrollNo,@StartDate, @endDate, 0, 0,0,0,0,0, @totContr,                      
                              @CheckNo,0,@EmpCont,@SponsorName,@PoolName)                      
                       
   select @SponsorName = '',@totContr = 0,@EmpCont = 0,@IDNumber='',@PayrollNo=''                      
   fetch next from ContrCsr Into @schemeCode, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
end                      
Close ContrCsr                      
Deallocate ContrCsr                     
                    
/* Members with Arrears but without Contributions */                      
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.ArEmpCont + cs.ArVolContr + cs.ArEmpCont_Un) AS EmpCont,                      
SUM(cs.ArEmprCont + cs.ArSpecial + cs.ArEmprCont_Un) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM ContributionArrears cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo                      
WHERE ((cs.DatePaid >= @startDate) and                      
   (cs.DatePaid <= @endDate)) and Cs.SchemeNo = @schemeCode                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno                      
Open ContrCsr                      
fetch from ContrCsr Into @schemeCode, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
while @@fetch_Status = 0                      
begin                   
   if @schemeMode = 1                      
      select @SponsorName = S.SponsorName from Sponsor s                      
      Inner join Members m on s.SponsorCode = m.SponsorCode                      
      and s.SchemeNo = m.SchemeNo and m.MembernO = @memberNo                      
      where s.SchemeNo = @schemeCode                      
   else                      
      select @SponsorName = ''                      
                      
   insert into #ContSchedule (schemeNo, SchemeName, MemberNo, Fullname,IDNumber,PayrollNo, startDate, EndDate, EmpCont, EmprCont, SpecialContr, Volcontr,nssf, nssfe, totContr,CheckNo,AugCont,                      
                                 Transfer,SponsorName,PoolName)                      
   Values (@schemeCode, @schemeName, @memberNo, @fullname,@IDNumber,@PayrollNo, @StartDate, @endDate, 0, 0,0,0,0,0, @totContr,                      
                              @CheckNo,0,@EmpCont,@SponsorName,@PoolName)                      
                       
   select @SponsorName = '',@totContr = 0,@EmpCont = 0,@IDNumber='',@PayrollNo=''                      
   fetch next from ContrCsr Into @schemeCode, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
end                      
Close ContrCsr                      
Deallocate ContrCsr                
                
select @schemeCode=0,@schemeName='',@SchemeMode=0                  
Fetch next from MembListCsr into @schemeCode,@schemeName,@SchemeMode                  
end                  
Close MembListCsr                  
Deallocate MembListCsr                  
                  
END                
                
----------------------------------------------------------------------------------                  
ELSE if @FundType <> 'PF'                  
BEGIN                   
select @schemeName = @PoolName                
                
if @SchemeMode = 0                      
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.EmpCont + cs.ExcessEmpcont) AS EmpCont,                      
Sum(cs.EmprCont + cs.ExcessEmprCont) AS EmprCont,                      
Sum(cs.SpecialContr + cs.ExcessSpecial) AS SpecialContr,                      
Sum(cs.VolContr + cs.ExcessVolContr) AS VolContr,                      
Sum(cs.NssfE) AS NssfE,                      
Sum(cs.Nssf) AS NssF,                      
sum(cs.AugCont) as AugCont,                      
SUM(cs.EmpCont + cs.EmprCont + cs.SpecialContr +cs.VolContr + cs.NssfE + cs.Nssf                     
+ cs.ExcessEmpcont + cs.ExcessEmprCont + cs.ExcessVolContr + cs.ExcessSpecial + cs.AugCont) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo,''                      
FROM Contributionssummary cs      
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo                      
WHERE ((cs.Datepaid >= @startDate) and                      
               (cs.Datepaid <= @endDate)) and Cs.SchemeNo = @SchemeNo                              
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno                      
else if @schemeMode = 1                      
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.EmpCont + cs.ExcessEmpcont) AS EmpCont,                   
Sum(cs.EmprCont + cs.ExcessEmprCont) AS EmprCont,                      
Sum(cs.SpecialContr + cs.ExcessSpecial) AS SpecialContr,                      
Sum(cs.VolContr + cs.ExcessVolContr) AS VolContr,                      
Sum(cs.NssfE) AS NssfE,                      
Sum(cs.Nssf) AS NssF,                      
sum(cs.AugCont) as AugCont,                      
SUM(cs.EmpCont + cs.EmprCont + cs.SpecialContr +cs.VolContr + cs.NssfE + cs.Nssf + cs.ExcessEmpcont + cs.ExcessEmprCont + cs.ExcessVolContr + cs.ExcessSpecial + cs.AugCont) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo,                      
s.SponsorName                      
FROM Contributionssummary cs                      
           Inner Join  Members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo                      
           inner join Sponsor s on cs.schemeNo = s.SchemeNo and cs.SponsorCode = s.SponsorCode                      
WHERE  cs.SchemeNo = @schemeNo and ((cs.Datepaid >= @StartDate) and (cs.Datepaid <= @EndDate))   
and cs.SponsorCode = @sponsorCode                              
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo,s.SponsorName                      
order by cs.memberno                      
                      
                      
open ContrCsr                      
                      
fetch from ContrCsr into @schemeNo, @MemberNo, @EmpCont, @EmprCont, @SpecialContr, @VolContr, @nssfe, @nssf, @AugCont,@totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo,                      
                         @SponsorName                      
                      
while @@fetch_Status = 0                      
begin                      
      select @Transfer = sum(EmpTransfer + AVCTransfer),        
             @TransferR = sum(EmprTransfer + AVCErTransfer + DeferredAmt)        
      from MemberTransfer                      
      where SchemeNo = @schemeNo and MemberNo = @MemberNo and                      
      TransferDate >= @startDate and TransferDate <= @endDate                      
                      
      if @Transfer is null select @Transfer = 0         
      if @Transferr is null select @Transferr = 0                     
                    
      select @TransferUn = sum(EmpTransfer + AVCTransfer),        
      @TransferUnR = sum(EmprTransfer + AVCErTransfer + DeferredAmt)           
      from MemberTransferUn                      
      where SchemeNo = @schemeNo and MemberNo = @MemberNo and                      
      TransferDate >= @startDate and TransferDate <= @endDate                      
                      
      if @TransferUn is null select @TransferUn = 0                    
      if @TransferUnR is null select @TransferUnR = 0              
                    
      select @Arrears = sum(ArEmpCont + ArVolcontr + ArEmpCont_Un),        
             @Arrearsr = sum(ArEmprCont + ArSpecial + ArEmprCont_Un)        
      from ContributionArrears                      
      where SchemeNo = @schemeNo and MemberNo = @MemberNo and                      
      DatePaid >= @startDate and DatePaid <= @endDate                      
                      
      if @Arrears is null select @Arrears = 0          
      if @ArrearsR is null select @ArrearsR = 0       
      
                                            
      insert into #ContSchedule (schemeNo, SchemeName, MemberNo, Fullname,IDNumber,PayrollNo, startDate, EndDate, EmpCont, EmprCont, SpecialContr, Volcontr,nssf, nssfe, totContr,CheckNo,AugCont,                      
                                 Transfer,SponsorName)                      
                      Values (@schemeNo, @schemeName, @memberNo, @fullname,@IDNumber,@PayrollNo, @StartDate, @endDate,         
                              @EmpCont + @Arrears, @EmprCont + @ArrearsR, @SpecialContr, @VolContr, @nssf, @nssfe, 
                              @totContr + @Transfer + @TransferUn + @Transferr + @TransferUnr + @Arrears + @Arrearsr,                      
                              @CheckNo,@AugCont,@Transfer + @TransferUn + @Transferr + @TransferUnr,@SponsorName)                      
                       
      select @Transfer = 0,@SponsorName = '',@Arrears = 0,@TransferUn = 0 ,@IDNumber = '',@PayrollNo = '',        
      @Transferr = 0,@Arrearsr = 0,@TransferUnr = 0,@MemberNo = 0                      
fetch next from ContrCsr into @schemeNo, @MemberNo, @EmpCont, @EmprCont, @SpecialContr, @VolContr, @nssfe, @nssf, @AugCont,@totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo,                      
                              @SponsorName                      
end                      
                      
Close ContrCsr                      
Deallocate ContrCsr                      
                      
/* Members with Transfers but without Contributions */   
if @SchemeMode = 0  
begin                     
declare ContrCsr cursor for                      
SELECT                   
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS EmpCont,                      
SUM(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM MemberTransfer cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo                      
WHERE ((cs.TransferDate >= @startDate) and                      
               (cs.TransferDate <= @endDate)) and Cs.SchemeNo = @SchemeNo                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno     
end  
else  
begin                     
declare ContrCsr cursor for                      
SELECT                   
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS EmpCont,                      
SUM(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM MemberTransfer cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo and ms.SponsorCode = @SponsorCode                     
WHERE ((cs.TransferDate >= @startDate) and                      
               (cs.TransferDate <= @endDate)) and Cs.SchemeNo = @SchemeNo                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno     
end  
                   
Open ContrCsr                      
fetch from ContrCsr Into @schemeNo, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
while @@fetch_Status = 0                      
begin                      
   if @schemeMode = 1                      
      select @SponsorName = S.SponsorName from Sponsor s                      
      Inner join Members m on s.SponsorCode = m.SponsorCode                      
      and s.SchemeNo = m.SchemeNo and m.MembernO = @memberNo                      
      where s.SchemeNo = @schemeNo                      
   else                      
      select @SponsorName = ''           
    select @TransferUn = sum(EmpTransfer + EmprTransfer + AVCTransfer + AVCErTransfer + DeferredAmt) from MemberTransferUn                      
      where SchemeNo = @schemeNo and MemberNo = @MemberNo and                      
      TransferDate >= @startDate and TransferDate <= @endDate                      
                      
      if @TransferUn is null select @TransferUn = 0                       
                      
   insert into #ContSchedule (schemeNo, SchemeName, MemberNo, Fullname,IDNumber,PayrollNo, startDate, EndDate, EmpCont, EmprCont, SpecialContr, Volcontr,nssf, nssfe, totContr,CheckNo,AugCont,                      
                                 Transfer,SponsorName)                      
   Values (@schemeNo, @schemeName, @memberNo, @fullname,@IDNumber,@PayrollNo, @StartDate, @endDate, 0, 0,0,0,0,0, @totContr + @TransferUn,                      
                              @CheckNo,0,@EmpCont + @TransferUn,@SponsorName)                      
                       
   select @SponsorName = '',@totContr = 0,@EmpCont = 0,@IDNumber='',@PayrollNo='',@TransferUn = 0                     
   fetch next from ContrCsr Into @schemeNo, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
end                      
Close ContrCsr                      
Deallocate ContrCsr                      
                    
/* Members with Un Registered Transfers but without Contributions */   
if @SchemeMode = 0  
begin                     
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                    
Sum(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS EmpCont,                      
SUM(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM MemberTransferUn cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo    WHERE ((cs.TransferDate >= @startDate) and                      
               (cs.TransferDate <= @endDate)) and Cs.SchemeNo = @SchemeNo                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno   
end  
else  
begin                     
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                    
Sum(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS EmpCont,                      
SUM(cs.EmpTransfer + cs.EmprTransfer + cs.DeferredAmt) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM MemberTransferUn cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo and ms.SponsorCode = @SponsorCode     
WHERE ((cs.TransferDate >= @startDate) and                      
               (cs.TransferDate <= @endDate)) and Cs.SchemeNo = @SchemeNo                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno   
end  
                     
Open ContrCsr                      
fetch from ContrCsr Into @schemeNo, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
while @@fetch_Status = 0                      
begin                      
   if @schemeMode = 1                      
      select @SponsorName = S.SponsorName from Sponsor s                      
      Inner join Members m on s.SponsorCode = m.SponsorCode                      
      and s.SchemeNo = m.SchemeNo and m.MembernO = @memberNo                      
      where s.SchemeNo = @schemeNo                      
   else                      
      select @SponsorName = ''                      
                      
   insert into #ContSchedule (schemeNo, SchemeName, MemberNo, Fullname,IDNumber,PayrollNo, startDate, EndDate, EmpCont, EmprCont, SpecialContr, Volcontr,nssf, nssfe, totContr,CheckNo,AugCont,                      
                                 Transfer,SponsorName)                      
   Values (@schemeNo, @schemeName, @memberNo, @fullname,@IDNumber,@PayrollNo,@StartDate, @endDate, 0, 0,0,0,0,0, @totContr,                      
            @CheckNo,0,@EmpCont,@SponsorName)                      
                       
   select @SponsorName = '',@totContr = 0,@EmpCont = 0,@IDNumber='',@PayrollNo=''                     
   fetch next from ContrCsr Into @schemeNo, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
end                      
Close ContrCsr                      
Deallocate ContrCsr                     
                    
/* Members with Arrears but without Contributions */   
if @schemeMode = 0  
begin                     
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.ArEmpCont + cs.ArVolContr + cs.ArEmpCont_Un) AS EmpCont,                      
SUM(cs.ArEmprCont + cs.ArSpecial + cs.ArEmprCont_Un) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM ContributionArrears cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo                      
WHERE ((cs.DatePaid >= @startDate) and                      
               (cs.DatePaid <= @endDate)) and Cs.SchemeNo = @SchemeNo                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno      
end  
else  
begin                     
declare ContrCsr cursor for                      
SELECT                      
cs.SchemeNo,                      
cs.MemberNo,                      
Sum(cs.ArEmpCont + cs.ArVolContr + cs.ArEmpCont_Un) AS EmpCont,                      
SUM(cs.ArEmprCont + cs.ArSpecial + cs.ArEmprCont_Un) AS TotContr,                      
UPPER(ms.Sname) + ' , ' + (ms.fname) + '  ' + (ms.onames) as FullName,ms.IDNumber,ms.PayrollNo, ms.CheckNo                      
FROM ContributionArrears cs                       
           Inner Join  members ms on cs.SchemeNo = ms.SchemeNo and cs.MemberNo = ms.MemberNo  
                       and ms.SponsorCode = @SponsorCode                      
WHERE ((cs.DatePaid >= @startDate) and                      
               (cs.DatePaid <= @endDate)) and Cs.SchemeNo = @SchemeNo                       
and cs.MemberNo not in (Select Distinct MemberNo from #ContSchedule )                               
GROUP BY cs.SchemeNo, cs.MemberNo, ms.sname,ms.fname,ms.onames,ms.IDNumber,ms.PayrollNo,ms.CheckNo                      
order by cs.memberno      
end  
                  
Open ContrCsr                      
fetch from ContrCsr Into @schemeNo, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
while @@fetch_Status = 0                      
begin                      
   if @schemeMode = 1            
      select @SponsorName = S.SponsorName from Sponsor s                      
      Inner join Members m on s.SponsorCode = m.SponsorCode                      
   and s.SchemeNo = m.SchemeNo and m.MembernO = @memberNo                      
      where s.SchemeNo = @schemeNo                      
   else                      
      select @SponsorName = ''            
                      
   insert into #ContSchedule (schemeNo, SchemeName, MemberNo, Fullname,IDNumber,PayrollNo, startDate, EndDate, EmpCont, EmprCont, SpecialContr, Volcontr,nssf, nssfe, totContr,CheckNo,AugCont,                      
                                 Transfer,SponsorName)                      
   Values (@schemeNo, @schemeName, @memberNo, @fullname,@IDNumber,@PayrollNo, @StartDate, @endDate, 0, 0,0,0,0,0, @totContr,                      
                              @CheckNo,0,@EmpCont,@SponsorName)                      
                       
   select @SponsorName = '',@totContr = 0,@EmpCont = 0,@IDNumber='',@PayrollNo=''                      
   fetch next from ContrCsr Into @schemeNo, @MemberNo, @EmpCont, @totContr, @fullname,@IDNumber,@PayrollNo,@CheckNo                      
end                      
Close ContrCsr                      
Deallocate ContrCsr                
                
END                     
                      
if @schemeMode = 0                       
   select * from #ContSchedule Order by schemeNo,memberNo                      
else                       
   select * from #ContSchedule Order by schemeNo,SponsorName,memberNo
go

