CREATE VIEW [dbo].[BenefSmmryMonthly]
--with encryption
AS
SELECT I.InterestRate, C.SchemeNo, C.MemberNo, C.ContrYear, 
    C.ContrMonth, C.EmpCont, C.EmprCont, C.VolContr, 
    C.SpecialContr
FROM ContributionsSummary C INNER JOIN
    InterestRates_Monthly i ON C.SchemeNo = I.SchemeNo AND 
    ((C.ContrYear = I.IntrYear) AND (C.ContrMonth = I.intrMonth))
go

