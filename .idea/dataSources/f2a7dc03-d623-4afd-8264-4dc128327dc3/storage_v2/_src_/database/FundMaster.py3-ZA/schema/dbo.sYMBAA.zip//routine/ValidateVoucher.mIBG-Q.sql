CREATE PROCEDURE [dbo].[ValidateVoucher]    
@schemeNo varchar(15),    
@VoucherNo int    
--with Encryption    
as    
declare @BankCode varchar(15), @Debit float, @Credit float    
    
select @Debit = sum(Debit),@Credit = sum(Credit) from SchemeGeneralLedger where schemeCode like @schemeNo and VoucherNo = @VoucherNo    
    
if @Debit is null select @Debit = 0    
if @Credit is null select @Credit = 0    
    
if @Debit = 0    
   begin    
      Update SchemeGeneralLedger set Tran_Status = -1 where schemeCode like @schemeNo and VoucherNo = @VoucherNo    
      Update CashBook set Tran_Status = -1  where schemeCode like @schemeNo and VoucherNo = @VoucherNo    
      Update PaymentVoucher set Tran_Status = -1 where schemeNo like @schemeNo and VoucherNo = @VoucherNo    
   end    
if @Credit = 0    
   begin    
      Update SchemeGeneralLedger set Tran_Status = -1 where schemeCode like @schemeNo and VoucherNo = @VoucherNo    
      Update CashBook set Tran_Status = -1  where schemeCode like @schemeNo and VoucherNo = @VoucherNo    
      Update PaymentVoucher set Tran_Status = -1 where schemeNo like @schemeNo and VoucherNo = @VoucherNo    
   end    
    
if @Debit <> @Credit    
   begin    
     Update SchemeGeneralLedger set Tran_Status = -1 where schemeCode like @schemeNo and VoucherNo = @VoucherNo    
     Update CashBook set Tran_Status = -1  where schemeCode like @schemeNo and VoucherNo = @VoucherNo    
     Update PaymentVoucher set Tran_Status = -1 where schemeNo like @schemeNo and VoucherNo = @VoucherNo    
   end
go

