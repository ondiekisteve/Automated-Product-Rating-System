CREATE PROCEDURE [dbo].[Proc_GetTenantsBalances] -- exec Proc_GetTenantsBalances 1328, 'Mar 31 2011 12:00:00:000AM', 17, 2, 0               
@SchemeNo int,                
@AsAtDate datetime,                
@PropCode int,                
@RepMode int, /*0 - FormerTenants(Expired leases), 1 - Current Tenants, 2 - ALL*/                
@GenMode int /*0 - All Properties 1 - Single property*/                
                
as                
                
if object_id('tempdb..#TenantsBalances') is null                                                                                    
                                                                                    
begin                                                                                    
create table #TenantsBalances                                                                                    
(                                                                                    
       [RentCode][Int] identity(1,1) PRIMARY KEY,                                                                                    
       [SchemeName][varchar](100),                                                                                    
       [PropertyName][varchar](100),                                                                                    
       [UnitNo][varchar](50),                                                                                    
       [UnitCode][int],                                                                                    
       [TenantName][varchar](100),                                                                                 
       [SumReceipt][float],                                                                                    
       [SumInvoiced][float],                                                                                                                                                                                                                           
       [Balance][float],                                                                                                                                                       
       [AsAtDate][Datetime],                                                                                                                                              
       [Tenantcode][int],                                                                                       
       [RepMode][int],                
       [RepModeDesc][varchar](50),
       [Prepayment][float],
       [ServiceBalance][float],
       [Preservice][float]                
)                 
                
end                
                
delete #TenantsBalances                                                                                   
                                                               
declare                                                    
@SumReceipt float,                
@SumInvoiced float,                                                           
@Balance float,                                                 
@schemeName varchar(100),                                  
@PropertyName varchar(100),                                                                                    
@tenantname varchar(100),                
@tenantcode int,                                        
@leasedate datetime,                                    
@AcctPeriodBalance Int,@UnitCode int, @UnitNo varchar(15),@DateCancelled datetime,                
@leasestart datetime, @leaseend datetime                
                
select @schemeName = schemeName from scheme where schemecode = @schemeno                 
                
If @GenMode = 0 /*All properties*/                
begin                
  declare PropCsr Cursor for                                    
  select PropertyCode,PropertyName from Property where SchemeNo = @SchemeNo --and IncomeMode = 0                                    
  Open PropCsr                                                  
       fetch from PropCsr into @PropCode, @PropertyName                             
       while @@fetch_Status = 0                                    
       begin   
       
       if @RepMode = 0/*former tenants*/                
        begin                
        declare GetTenantCsr cursor for       
      
               Select t.TenantCode, t.TenantName, t.UnitNo, t.UnitCode from                  
               ViewTenants t      
                        inner join Leases l on t.schemeNo = l.schemeNo and t.TenantCode = l.TenantCode    
                                             and t.UnitCode = l.UnitCode and l.leaseCancelled = 1      
               where t.SchemeNo = @schemeNo and t.PropertyCode = @PropCode and t.tenant_status = 0      
                
        open GetTenantCsr                
                
       fetch from GetTenantCsr into @TenantCode, @TenantName, @UnitNo, @UnitCode                
        while @@fetch_status = 0                
        begin                
            select @leasestart = startdate,@leaseEnd = EndDate,@DateCancelled = datecancelled                
            from leases where SchemeNo = @schemeNo and PropertyCode = @PropCode                                                                 
            and UnitCode = @UnitCode and TenantCode = @TenantCode                
                 
            select @SumInvoiced = sum(rent+vat+withholdingTax + parking + ServiceCharge) from rentinvoice                                                                                     
            where SchemeNo = @schemeNo and PropertyCode = @PropCode  and TenantCode = @TenantCode                 
            and InvoiceDate>=@leasestart and invoiceDate <= @DateCancelled                
            if @SumInvoiced is null Select @SumInvoiced = 0.0                
                
            select @SumReceipt = sum(amount + Parking + Other + ServiceCharge)       
            from rentreceipts       
            where SchemeNo = @schemeNo and                                   
            PropertyCode = @PropCode and UnitCode = @unitcode                                       
            and TenantCode = @TenantCode and PayDate >= @leasestart and PayDate <= @DateCancelled                
            if @SumReceipt is null Select @SumReceipt = 0.0                
                
            Select @Balance = @SumInvoiced - @SumReceipt                
            if @Balance is null Select @Balance = 0.0                
                
            Insert into #TenantsBalances(SchemeName,PropertyName,UnitNo,UnitCode,TenantName,SumReceipt,SumInvoiced,Balance,                                                                                                                                   
  
     
                
                                         AsAtDate,Tenantcode,RepMode,RepModeDesc)                
            values (@SchemeName,@PropertyName,@UnitNo,@UnitCode,@TenantName,@SumReceipt,@SumInvoiced,@Balance,                                                                                                                                                 
  
    
      
                    @AsAtDate,@Tenantcode,@RepMode,'EXPIRED LEASES')                
                
            select @TenantCode = 0, @TenantName = '', @UnitNo = '', @UnitCode = 0,@SumInvoiced = 0.0,                
                   @leasestart = null,@leaseEnd = null,@DateCancelled = null,@SumReceipt = 0.0, @Balance = 0.0                
                
           fetch next from GetTenantCsr into @TenantCode, @TenantName, @UnitNo, @UnitCode                
        end                
        Close GetTenantCsr                
        Deallocate GetTenantCsr                
                
     end/*end former tenants*/                
   else if @RepMode = 1                
     begin/*current tenants*/                
        exec UnitsAnalysis @SchemeNo,@PropCode                
                
        declare GetTenantCsr cursor  for       
               Select t.TenantCode, t.TenantName, t.UnitNo, t.UnitCode from          
               ViewTenants t      
                        inner join Leases l on t.schemeNo = l.schemeNo and t.TenantCode = l.TenantCode      
                        and l.leaseCancelled = 0 and t.UnitCode = l.UnitCode     
               where t.SchemeNo = @schemeNo and t.PropertyCode = @PropCode and t.tenant_status = 1              
        and t.Tenantcode in (Select tenantcode from ##PropUnits)                 
        open GetTenantCsr                
                
        fetch from GetTenantCsr into @TenantCode, @TenantName, @UnitNo, @UnitCode                
        while @@fetch_status = 0                
        begin                
  select @leasestart = startdate,@leaseEnd = EndDate,@DateCancelled = datecancelled                
  from leases where SchemeNo = @schemeNo and PropertyCode = @PropCode                                                                 
  and UnitCode = @UnitCode and TenantCode = @TenantCode                
                
    select @SumInvoiced = sum(rent+vat+withholdingTax + Parking + ServiceCharge) from rentinvoice                                                                                     
    where SchemeNo = @schemeNo and PropertyCode = @PropCode  and TenantCode = @TenantCode                 
  and InvoiceDate>=@leasestart and invoiceDate <= @AsAtDate                
  if @SumInvoiced is null Select @SumInvoiced = 0.0                
                
  select @SumReceipt = sum(amount + Parking + Other + ServiceCharge)       
  from rentreceipts       
  where SchemeNo = @schemeNo and                                   
  PropertyCode = @PropCode and UnitCode = @unitcode                                       
  and TenantCode = @TenantCode and PayDate >= @leasestart and PayDate <= @AsAtDate                
  if @SumReceipt is null Select @SumReceipt = 0.0                
                
  Select @Balance = @SumInvoiced - @SumReceipt                
  if @Balance is null Select @Balance = 0.0                
                
  Insert into #TenantsBalances(SchemeName,PropertyName,UnitNo,UnitCode,TenantName,SumReceipt,SumInvoiced,Balance,                                                                                     
         AsAtDate,Tenantcode,RepMode,RepModeDesc)                
  values (@SchemeName,@PropertyName,@UnitNo,@UnitCode,@TenantName,@SumReceipt,@SumInvoiced,@Balance,                                                                                                                                
         @AsAtDate,@Tenantcode,@RepMode,'CURRENT TENANTS')                
                
  select @TenantCode = 0, @TenantName = '', @UnitNo = '', @UnitCode = 0,@SumInvoiced = 0.0,                
  @leasestart = null,@leaseEnd = null,@DateCancelled = null,@SumReceipt = 0.0, @Balance = 0.0                
                
        fetch next from GetTenantCsr into @TenantCode, @TenantName, @UnitNo, @UnitCode                
        end                
        Close GetTenantCsr                
        Deallocate GetTenantCsr                
                
     end /*end current tenants*/  
 else if @RepMode = 2               
     begin/* All Tenants */ 
         print @PropCode 
         print @PropertyName              
         print ('**************************************************************************')   
                
         Insert into #TenantsBalances(SchemeName,PropertyName,UnitNo,UnitCode,TenantName,SumReceipt,SumInvoiced,Balance,                                                                                     
         AsAtDate,Tenantcode,RepMode,RepModeDesc,Prepayment,ServiceBalance,Preservice)
         Select @SchemeName,@PropertyName,u.UnitNo, u.UnitCode, t.TenantName, 0,0,r.Balance * SpotRate,@AsAtDate,t.tenantcode,
                @RepMode,'ALL TENANTS',r.Prepayment*spotRate,r.ServiceBalance,r.PreService
         from rentprebalance r
              inner join Units u on r.schemeNo = u.SchemeNo and r.PropertyCode = u.PropertyCode and r.UnitCode = u.UnitCode
              inner join tenants t on r.schemeNo = t.SchemeNo and r.PropertyCode = t.PropertyCode and r.tenantcode = t.tenantCode
         where r.schemeNo = @schemeNo and r.propertyCode = @PropCode and r.BalanceDate = @AsAtDate
                           
     end /*end all tenants*/               
                
       select @PropCode = 0,@PropertyName = ''                
       fetch next from PropCsr into @PropCode,@PropertyName                
       end                
  Close PropCsr                
  Deallocate PropCsr                
                
end/*End All Properties*/                
else                
begin/*Single property*/                
select @PropertyName = PropertyName from Property where SchemeNo = @SchemeNo and PropertyCode = @PropCode                 
                
          if @RepMode = 0/*former tenants*/                
     begin                
        declare GetTenantCsr cursor for       
      
               Select t.TenantCode, t.TenantName, t.UnitNo, t.UnitCode from                  
               ViewTenants t      
                        inner join Leases l on t.schemeNo = l.schemeNo and t.TenantCode = l.TenantCode     
                               and t.UnitCode = l.UnitCode and l.leaseCancelled = 1      
               where t.SchemeNo = @schemeNo and t.PropertyCode = @PropCode and t.tenant_status = 0       
               
        open GetTenantCsr                
                
        fetch from GetTenantCsr into @TenantCode, @TenantName, @UnitNo, @UnitCode                
        while @@fetch_status = 0             
        begin                
           select @leasestart = startdate,@leaseEnd = EndDate,@DateCancelled = datecancelled                
           from leases where SchemeNo = @schemeNo and PropertyCode = @PropCode                                                                 
           and UnitCode = @UnitCode and TenantCode = @TenantCode                
                
           select @SumInvoiced = sum(rent+vat+withholdingTax + parking + ServiceCharge) from rentinvoice                                                                    
           where SchemeNo = @schemeNo and PropertyCode = @PropCode  and TenantCode = @TenantCode                 
           and InvoiceDate>=@leasestart and invoiceDate <= @DateCancelled                
        
           if @SumInvoiced is null Select @SumInvoiced = 0.0                
                
           select @SumReceipt = sum(amount + Other + Parking + ServiceCharge) from rentreceipts where SchemeNo = @schemeNo and                                   
           PropertyCode = @PropCode and UnitCode = @unitcode                                       
           and TenantCode = @TenantCode and PayDate >= @leasestart and PayDate <= @DateCancelled                
                 
           if @SumReceipt is null Select @SumReceipt = 0.0                
                
           Select @Balance = @SumInvoiced - @SumReceipt                
           if @Balance is null Select @Balance = 0.0                
                
  Insert into #TenantsBalances(SchemeName,PropertyName,UnitNo,UnitCode,TenantName,SumReceipt,SumInvoiced,Balance,                                                                                                                                             
  
    
       
        
         
         AsAtDate,Tenantcode,RepMode,RepModeDesc)                
  values (@SchemeName,@PropertyName,@UnitNo,@UnitCode,@TenantName,@SumReceipt,@SumInvoiced,@Balance,          
         @AsAtDate,@Tenantcode,@RepMode,'EXPIRED LEASES')                
                
  select @TenantCode = 0, @TenantName = '', @UnitNo = '', @UnitCode = 0,@SumInvoiced = 0.0,                
  @leasestart = null,@leaseEnd = null,@DateCancelled = null,@SumReceipt = 0.0, @Balance = 0.0                
                
        fetch next from GetTenantCsr into @TenantCode, @TenantName, @UnitNo, @UnitCode                
        end                
        Close GetTenantCsr                
        Deallocate GetTenantCsr                
                
     end/*end former tenants*/                
   else                
     begin/*current tenants*/                
        exec UnitsAnalysis @SchemeNo,@PropCode                
                
        declare GetTenantCsr cursor for Select t.TenantCode, t.TenantName, t.UnitNo, t.UnitCode from                  
               ViewTenants t      
                  inner join Leases l on t.schemeNo = l.schemeNo and t.TenantCode = l.TenantCode      
                  and t.UnitCode = l.UnitCode  and l.leaseCancelled = 0      
               where t.SchemeNo = @schemeNo and t.PropertyCode = @PropCode and t.tenant_status = 1              
        and t.Tenantcode in (Select tenantcode from ##PropUnits)                            
        open GetTenantCsr                
                
        fetch from GetTenantCsr into @TenantCode, @TenantName, @UnitNo, @UnitCode                
        while @@fetch_status = 0                
      begin                
  select @leasestart = startdate,@leaseEnd = EndDate,@DateCancelled = datecancelled                
  from leases where SchemeNo = @schemeNo and PropertyCode = @PropCode                                                           
  and UnitCode = @UnitCode and TenantCode = @TenantCode                
                
    select @SumInvoiced = sum(rent+vat+withholdingTax + ServiceCharge + Parking) from rentinvoice                             
    where SchemeNo = @schemeNo and PropertyCode = @PropCode  and TenantCode = @TenantCode                 
  and InvoiceDate>=@leasestart and invoiceDate <= @AsAtDate                
  if @SumInvoiced is null Select @SumInvoiced = 0.0                
                
  select @SumReceipt = sum(amount + Parking + Other + ServiceCharge) from rentreceipts where SchemeNo = @schemeNo and                                   
  PropertyCode = @PropCode and UnitCode = @unitcode                                       
  and TenantCode = @TenantCode and PayDate >= @leasestart and PayDate <= @AsAtDate                
  if @SumReceipt is null Select @SumReceipt = 0.0                
                
  Select @Balance = @SumInvoiced - @SumReceipt                
  if @Balance is null Select @Balance = 0.0                
                
  Insert into #TenantsBalances(SchemeName,PropertyName,UnitNo,UnitCode,TenantName,SumReceipt,SumInvoiced,Balance,                                                                                                                                             
         AsAtDate,Tenantcode,RepMode,RepModeDesc)                
  values (@SchemeName,@PropertyName,@UnitNo,@UnitCode,@TenantName,@SumReceipt,@SumInvoiced,@Balance,                                                                                                                                                       
         @AsAtDate,@Tenantcode,@RepMode,'CURRENT TENANTS')                
                
  select @TenantCode = 0, @TenantName = '', @UnitNo = '', @UnitCode = 0,@SumInvoiced = 0.0,                
  @leasestart = null,@leaseEnd = null,@DateCancelled = null,@SumReceipt = 0.0, @Balance = 0.0                
                
        fetch next from GetTenantCsr into @TenantCode, @TenantName, @UnitNo, @UnitCode                
        end                
        Close GetTenantCsr                
        Deallocate GetTenantCsr                
                
     end /*end current tenants*/                
                
end/*End Single Property*/                
                
Select * from #TenantsBalances
go

