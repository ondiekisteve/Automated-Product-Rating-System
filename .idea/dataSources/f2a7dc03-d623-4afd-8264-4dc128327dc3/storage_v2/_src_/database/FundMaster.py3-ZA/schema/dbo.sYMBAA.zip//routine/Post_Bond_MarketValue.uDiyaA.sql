CREATE PROCEDURE [dbo].[Post_Bond_MarketValue]                                                                               
@schemeNo int,                                   
@InvestCode int,                                                                         
@TransDate Datetime,                                                                                
@TransMode Int, /* 1 - Certify,2-Authorize,3-Post,4-Rollback */                                  
@UserName varchar(60)                                                                                
--with Encryption                                                                                
as                                                                                
                                                                             
Declare @Withholding float,@Medical float,@WithholdingTax float,@MedicalLevy float,                                                      
@CreditAcc Varchar(30),@DebitAcc varchar(30),@PayMonth Int,@PayYear Int,@MaxTransNo Int,@Tax float,@BatchNo Int,                                                    
@CStatus smallInt,@CurrCode Int,@sDate varchar(20),@Income float,@BondName varchar(200),                                  
@dCurrCode int,@CurrRate float,@InvName varchar(120),@Bondvaluation smallint  
  
select @Bondvaluation = Bondvaluation from Scheme  where SchemeCode = @schemeNo                               
                                                             
Exec DateToStr @TransDate,@sDate out          
        
IF @TransMode = 4 /* Fix for AFLIFE while on holiday */        
   Update GovCommMarketValue set Status = 2 where SchemeNo = @schemeNo and InvestCode = @InvestCode                                  
   and EndDate = @TransDate        
               
                                 
if Exists (select SchemeNo from GovCommMarketValue where SchemeNo = @schemeNo and InvestCode = @InvestCode                                  
           and EndDate = @TransDate and Status = 3)                                  
BEGIN                                  
   raiserror('The Change in Market Value for the bonds as at %s has already been posted to the General Ledger',16,1,@sDate)                                  
   return                                  
END                                  
else                                  
BEGIN                                  
                                              
select @dCurrCode = CurrCode from Scheme where schemeCode = @schemeNo                                                  
                                              
Exec Proc_Check_Periods @schemeNo,@TransDate,@CStatus Out                                                  
                                                  
if @CStatus = 1                                                  
begin                                                  
  raiserror('The Accounting Period for the Transaction does not Exist',16,1)                                                  
  return                                                
end                                                  
else if @CStatus = 2                                                  
begin                                                  
  raiserror('The Accounting Period for the Transaction has already been closed',16,1)                                                  
  return                                                  
end                                                  
else if @CStatus = 3                                                  
begin                                                  
  raiserror('The Fiscal Year for the Transaction has already been closed',16,1)                                                  
  return                                                  
end                                                  
else                                                  
begin                                                     
       
  if @TransMode = 1                                   
     begin   
       if @Bondvaluation = 2                                 
          Update GovCommMarketValue set Status = @TransMode where SchemeNo = @schemeNo and InvestCode = @InvestCode                                
          and EndDate = @TransDate  
       else if @Bondvaluation  = 3   
          Update TBL_Bond_Valuation_Rates set Status = @TransMode where SchemeNo = @schemeNo and ValuationDate = @TransDate                               
     end                     
  else if @TransMode = 2                                  
     begin                                  
        if @Bondvaluation = 2                                 
          Update GovCommMarketValue set Status = @TransMode where SchemeNo = @schemeNo and InvestCode = @InvestCode                                
          and EndDate = @TransDate  
       else if @Bondvaluation  = 3   
          Update TBL_Bond_Valuation_Rates set Status = @TransMode where SchemeNo = @schemeNo and ValuationDate = @TransDate                            
     end                                  
  else if @TransMode = 3                                  
     begin                        
        /*select @TaxCreditAcc = TaxCreditAcc,@MedLevyCreditAcc = MedLevyCreditAcc                         
        from Pension_Setup where schemeNo = @schemeNo                        
                               
        select @MedLevyDebitAcc = MedLevyAcc,@WithTaxDebitAcc= WithTaxAcc                                  
        from TBL_Invest_TaxRates where schemeNo = @schemeNo and InvestCode = @InvestCode                        
        */                                            
        select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeNo                                 
                                                      
        if @BatchNo is null select @BatchNo = 0                                                      
        select @BatchNo = @BatchNo + 1                                                        
                                                        
        select @PayMonth = DatePart(Month,@TransDate),@PayYear = DatePart(Year,@TransDate)                                
                          
                                                        
select @MaxTransNo = Max(glTransNo) from SchemeGeneralLedger where schemeCode = @schemeNo                                   
if @MaxTransNo is null select @MaxTransNo = 0                                                        
select @MaxTransNo = @MaxTransNo + 1                                  
                                                                                                                                                                                   
if @InvestCode = 4  /* Treasury Bills and Bonds */                                                             
   begin                                                                                             
    Declare PostCsr Cursor for                                                                               
    select i.InvName,t.ChangeInValue,p.ValuationAcc,p.AssetAcc,@dCurrCode,t.WithTax, t.MedicalLevy                                                                        
    from GovCommMarketValue t                                                     
        inner join GovernmentSecurities p on t.schemeNo = p.schemeNo and t.invCode = p.SecurityNo               
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                 
    where t.schemeNo = @schemeNo /*and t.InvestCode = @InvestCode*/ and t.EndDate = @TransDate                                                               
   end                                                    
else if @InvestCode = 7  /* Commercial Paper */                                                             
   begin                                             
    Declare PostCsr Cursor for                                                                               
    select i.InvName,t.ChangeInValue,p.ValuationAcc,p.AssetAcc,p.CurrCode,t.WithTax, t.MedicalLevy                                                                        
    from GovCommMarketValue t                                                     
        inner join CommercialPaper p on t.schemeNo = p.schemeNo and t.invCode = p.PaperNo               
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                 
    where t.schemeNo = @schemeNo /*and t.InvestCode = @InvestCode*/ and t.EndDate = @TransDate                                              
  end                                                                    
                                                          
                 
Open PostCsr                                                        
Fetch from PostCsr Into @BondName,@Income,@CreditAcc,@DebitAcc,@CurrCode,@WithholdingTax,@MedicalLevy                       
while @@fetch_Status = 0                                                        
begin                   
   select @InvName = @BondName                  
                                 
   Exec Proc_Get_Forex_Rate @schemeNo,@CurrCode,@TransDate,@CurrRate Out                    
                                                                                                                  
   select @BondName = 'Change in Market Value for '+ @InvName                                                     
                 
   if @Income < 0              
      begin              
         select @Income = 0 - @Income              
              
         Exec PostLedgerCredits_RecPay @SchemeNo,@DebitAcc,0,@Income,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                          
                                                        
         Exec PostLedgerDebits_RecPay @SchemeNo,@CreditAcc,0,@Income,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode               
      end              
   else if @Income > 0              
      begin              
              
         Exec PostLedgerCredits_RecPay @SchemeNo,@CreditAcc,0,@Income,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                          
                                                        
         Exec PostLedgerDebits_RecPay @SchemeNo,@DebitAcc,0,@Income,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode               
      end            
          
   if @WithholdingTax > 0              
      begin              
         Exec PostLedgerCredits_RecPay @SchemeNo,'2050',0,@WithholdingTax,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                          
                                                        
         Exec PostLedgerDebits_RecPay @SchemeNo,'6901',0,@WithholdingTax,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode               
      end          
   else if @WithholdingTax < 0          
      begin          
         select @WithholdingTax = 0 - @WithholdingTax          
          
         Exec PostLedgerCredits_RecPay @SchemeNo,'6901',0,@WithholdingTax,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
 @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                          
                                                        
         Exec PostLedgerDebits_RecPay @SchemeNo,'2050',0,@WithholdingTax,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode           
      end            
          
   if @MedicalLevy > 0              
      begin             
         Exec PostLedgerCredits_RecPay @SchemeNo,'2025',0,@MedicalLevy,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                          
                                                        
         Exec PostLedgerDebits_RecPay @SchemeNo,'6120',0,@MedicalLevy,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode               
      end           
   else if @MedicalLevy < 0              
      begin           
         select @MedicalLevy = 0 - @MedicalLevy          
            
         Exec PostLedgerCredits_RecPay @SchemeNo,'6120',0,@MedicalLevy,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                          
                                                        
         Exec PostLedgerDebits_RecPay @SchemeNo,'2025',0,@MedicalLevy,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                          
         @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode               
      end                                                         
                                                                                                 
   select @BondName='',@Income=0,@MaxTransNo = @MaxTransNo + 1,@CreditAcc='',@DebitAcc='',                                                       
   @CurrCode=0,@CurrRate = 0,@WithholdingTax=0,@MedicalLevy=0                                  
                                                        
   Fetch next from PostCsr Into @BondName,@Income,@CreditAcc,@DebitAcc,@CurrCode,@WithholdingTax,@MedicalLevy                                                        
end                                                        
Close PostCsr                                                        
Deallocate PostCsr                                                                 
   
   if @Bondvaluation = 2                                 
       Update GovCommMarketValue set Status = @TransMode ,PostedBy = @UserName,DatePosted = getDate()              
       where SchemeNo = @schemeNo and InvestCode = @InvestCode                                  
       and EndDate = @TransDate    
   else if @Bondvaluation  = 3   
       Update TBL_Bond_Valuation_Rates set Status = @TransMode,PostedBy = @UserName,DatePosted = getDate()
       where SchemeNo = @schemeNo and ValuationDate = @TransDate 
                             
end                                  
else if @TransMode = 4                                  
     begin          
       if @InvestCode = 4  /* Treasury Bills and Bonds */                                                             
   begin                                                                                             
    Declare PostCsr Cursor for                                                                               
    select i.InvName,t.ChangeInValue,p.ValuationAcc,p.AssetAcc,@dCurrCode,t.WithTax, t.MedicalLevy                                                                        
    from GovCommMarketValue t                                                     
        inner join GovernmentSecurities p on t.schemeNo = p.schemeNo and t.invCode = p.SecurityNo               
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                 
    where t.schemeNo = @schemeNo /*and t.InvestCode = @InvestCode*/ and t.EndDate = @TransDate                                                    
   end                                                    
else if @InvestCode = 7  /* Commercial Paper */                                                             
   begin                                                                                                           
    Declare PostCsr Cursor for                                                                               
    select i.InvName,t.ChangeInValue,p.ValuationAcc,p.AssetAcc,p.CurrCode,t.WithTax, t.MedicalLevy                                                                        
    from GovCommMarketValue t                                                     
        inner join CommercialPaper p on t.schemeNo = p.schemeNo and t.invCode = p.PaperNo               
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                 
    where t.schemeNo = @schemeNo /*and t.InvestCode = @InvestCode*/ and t.EndDate = @TransDate                                                
  end                                                                    
                                                          
                 
Open PostCsr                                                        
Fetch from PostCsr Into @BondName,@Income,@CreditAcc,@DebitAcc,@CurrCode,@WithholdingTax,@MedicalLevy                                                                         
while @@fetch_Status = 0                                                        
begin                   
   select @InvName = @BondName                  
                                                                                                                                       
   select @BondName = 'Change in Market Value for '+ @InvName                                                     
                 
   Update SchemeGeneralLedger set Tran_Status = -1 where schemeCode = @schemeNo and GLDate = @TransDate and Description like @BondName                            
                                                                                                 
   select @BondName='',@Income=0,@MaxTransNo = @MaxTransNo + 1,@CreditAcc='',@DebitAcc='',                                                       
   @CurrCode=0,@CurrRate = 0,@WithholdingTax=0,@MedicalLevy=0                                  
                                                        
   Fetch next from PostCsr Into @BondName,@Income,@CreditAcc,@DebitAcc,@CurrCode,@WithholdingTax,@MedicalLevy                                                        
end                                                        
Close PostCsr                                                        
Deallocate PostCsr             
                                  
   if @Bondvaluation = 2                                 
       Delete from GovCommMarketValue where SchemeNo = @schemeNo and InvestCode = @InvestCode                                 
       and EndDate = @TransDate    
   else if @Bondvaluation  = 3   
       Delete from TBL_Bond_Valuation_Rates where SchemeNo = @schemeNo                                 
       and ValuationDate = @TransDate                                      
   end                                   
end                                                  
END
go

