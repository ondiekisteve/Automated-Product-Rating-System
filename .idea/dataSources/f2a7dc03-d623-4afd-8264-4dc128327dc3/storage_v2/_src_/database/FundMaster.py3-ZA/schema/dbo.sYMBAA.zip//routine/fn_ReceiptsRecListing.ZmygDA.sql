CREATE FUNCTION [dbo].[fn_ReceiptsRecListing](@SCHEMENO Int,@Posted Int,@AcctPeriod Int)              
returns @tbl_var table(RecNo Int identity(1,1) primary key,      
                       SchemeNo Int not null,              
                       Particulars varchar(120) not null,              
                       Transdate Datetime,              
                       ReceiptNo Int,      
                       TransNo_FK Int,      
                       ReceiptType SmallInt,                      
                       Amount Decimal(20,6),              
                       Posted smallInt,              
                       ChequeNo Varchar(20),              
                       ReceivedFrom Varchar(120),  
                       StartNo Int,  
                       EndNo Int             
                       )              
as              
 begin              
  declare @StartDate Datetime,@EndDate Datetime,@StartNo Int,@EndNo Int              
             
  if @AcctPeriod = 0              
     select @AcctPeriod = Max(AcctPeriod) from SchemeYears where SchemeNo = @schemeNo              
              
  select @StartDate = StartDate,@EndDate = EndDate from SchemeYears where SchemeNo = @schemeNo              
  and AcctPeriod = @AcctPeriod      
      
             
  /* Thru Receivables */            
  Insert Into @tbl_Var              
  Select r.SchemeNo,rc.Description,r.TransDate,r.RecTransNo,r.TransNo_FK,r.ReceiptType,sum(rci.Amount),  
         r.Posted,rc.ChequeNo,              
         r.ReceivedFrom,0,0              
  from tbl_Receipts_Register r              
     inner Join ReceiptsRec rc on r.schemeNo = rc.SchemeNo and r.TransNo_Fk = rc.TransNo                  
     inner Join ReceiptsRecInvoice rci on r.schemeNo = rci.SchemeNo and r.TransNo_fk = rci.TransNo_fk                      
  where r.SchemeNo = @schemeNo and r.Transdate >= @StartDate and r.TransDate <= @EndDate and r.Posted = @Posted  
  and r.Tran_Status = 0           
  Group By r.SchemeNo,rc.Description,r.TransDate,r.RecTransNo,r.Posted,rc.ChequeNo,r.ReceivedFrom,r.TransNo_FK,r.ReceiptType               
        
  /* Thru Direct Receipts */              
  Insert Into @tbl_Var              
  Select r.SchemeNo,r.PaymentDesc,tr.TransDate,tr.RecTransNo,Tr.TransNo_FK,tr.ReceiptType,sum(rc.InvoiceAmount),tr.Posted,r.ChequeNo,              
         r.Payee,0,0              
  from tbl_Receipts_Register tr      
     inner join DirectPayment r on tr.schemeNo = r.SchemeNo and tr.TransNo_FK = r.PaymentNo              
     inner Join DirectPaymentInvoice rc on tr.schemeNo = rc.SchemeNo and tr.TransNo_FK = rc.PaymentNo              
  where tr.SchemeNo = @SchemeNo and tr.Posted = @Posted              
  and tr.TransDate >= @StartDate and tr.TransDate <= @EndDate and tr.Tran_Status = 0              
  Group By r.SchemeNo,r.PaymentDesc,tr.TransDate,tr.RecTransNo,tr.Posted,r.ChequeNo,r.Payee,Tr.TransNo_FK,tr.ReceiptType          
    
  select @StartNo = Min(ReceiptNo),@EndNo = Max(ReceiptNo) from @tbl_Var  
  
  update @tbl_Var set StartNo = @StartNo,EndNo = @EndNo  
  return              
 end
go

