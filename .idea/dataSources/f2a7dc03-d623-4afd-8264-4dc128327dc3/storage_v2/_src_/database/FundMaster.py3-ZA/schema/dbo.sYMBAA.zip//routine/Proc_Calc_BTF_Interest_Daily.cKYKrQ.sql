CREATE Procedure [dbo].[Proc_Calc_BTF_Interest_Daily]                                          
@SCHEMENO Int,                                          
@memberNo int,      
@DependantCode int,                                          
@Proc_Date datetime,                                                      
@IntMode Int,                             
@useBalances int,                                                     
@totBalance float output,                
@Interest float out                                                           
--with Encryption                                          
as                                          
                                          
set nocount on                                          
                                          
if object_id('tempdb..#Balances') is null                                          
                                          
begin                                          
create table #Balances                                          
(                                          
        [EmpCode][Int] Identity(1,1) Primary Key,                            
        [StartDate][datetime],                                          
        [DatePaid] [Datetime],                                           
        [OpenBal] [float],                            
        [BalWithInt][float],                                          
        [Payment] [Float],                                          
        [ClosingBal][float]                                              
)                                           
                                                
end                                          
                                          
Declare @AcctPeriod int,@PeriodtoUse int, @sDate datetime, @EndDate datetime, @IntDays int,                            
@DateYaLast datetime,@CBalance decimal(20,6),@CurrInterest float,@DrawNo int,@newPower float,                            
@PayYear int,@PayMonth Int,@DatePaid datetime,@AmountPaid float,@StartDate datetime,@SMonthDate datetime,                
@IncomeAllocMode smallint,@BalancePrin float,@TotPay float,@MinDrawNo Int,@aflife smallint,      
@CurMonth int, @currYear int        
      
select @CurMonth = DATEPART(month,@proc_date), @currYear = datepart(Year,@Proc_Date)               
                    
/* Select income allocation Mode */                    
select @IncomeAllocMode = IncomeAllocMode from ConfigYearEnd where schemeNo = @schemeNo                                         
                            
/* Interest starts after how many days to allow for clearance of Cheques */                                    
                                    
select @IntDays = intDays,@aflife = aflife from Scheme where schemeCode = @schemeNo                                    
                                    
if @IntDays is null select @IntDays = 0                                         
                                          
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @currYear, @AcctPeriod out                                          
                                          
Select @sDate = StartDate,@DateYaLast = EndDate                                          
from SchemeYears where SchemeNo = @schemeNo  and AcctPeriod = @AcctPeriod                                          
                                                      
exec getLastDate @CurMonth,@CurrYear,@EndDate out                             
                            
EXEC Proc_Get_Int_Rate @schemeNo,@EndDate,@IntMode,@currInterest Out       
                                
if @currInterest is null select @currInterest = 0       
       
print @currInterest      
              
select @DateYaLast = @EndDate                              
                                          
Select @PeriodToUse = @AcctPeriod - 1                                          
                                          
if @useBalances = 1                                          
  begin                                          
    Select @SMonthDate = @sDate                                          
   end                                     
else                                          
begin                      
     select @SMonthDate = DOCalc from DeathClaim where schemeNo = @schemeNo and MemberNo = @MemberNo                                                     
   end                       
                                          
/* Initialize all variables to Zero */                                          
Select @CBalance  = 0,@StartDate = @SMonthDate                                           
                                                                  
if @useBalances = 1                                          
  begin                                                                              
  select @totBalance = Balance from TBL_BTF_Balances where schemeNo = @schemeNo and MemberNo = @MemberNo                            
  and AcctPeriod = @PeriodToUse AND DependantCode = @DependantCode                               
                            
  if @totBalance is null select @totBalance = 0.0                                              
  end                                          
else                                          
  begin                                                                                              
  select @totBalance = Amount from DependantPayment where schemeNo = @schemeNo and MemberNo = @MemberNo                            
  AND DependantCode = @DependantCode                              
                            
  if @totBalance is null select @totBalance = 0.0                                       
  end                                          
                                  
 select @CBalance = @totBalance                 
                 
 select @TotPay = sum(Amount)from DependantPaymentDet       
 where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                           
 DependantCode = @DependantCode and DatePaid >= @sDate and DatePaid <= @DateYaLast                 
                 
 if @TotPay is null select @TotPay = 0                
                 
 select @BalancePrin  = @totBalance - @TotPay        
       
                 
                                         
  /* Load Payments */                             
 if Exists(select MemberNo       
           from DependantPaymentDet       
           where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                           
           DependantCode = @DependantCode and DatePaid >= @sDate and DatePaid <= @DateYaLast)                            
   begin                                                
     declare PenCsr cursor for                                          
     Select Datepaid,Amount                                          
     from DependantPaymentDet       
     where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                           
     DependantCode = @DependantCode and DatePaid >= @sDate and DatePaid <= @DateYaLast       
     Order by DatePaid                                        
                                          
     Open PenCsr                                           
                                          
     Fetch from PenCsr into @DatePaid,@AmountPaid                                          
                                          
     while @@fetch_Status = 0                                          
     begin                        
                                     
        select @newPower = power((1.0000000000 + (@currInterest/100.000)), ((datediff(day,@SMonthDate,@DatePaid)+1)/365.00))                                          
                              
        select @totBalance = @totBalance * @newPower                            
                            
        Insert into #Balances(StartDate,DatePaid,OpenBal,BalWithInt,Payment,ClosingBal)                            
               Values(@StartDate,@DatePaid,@CBalance,@totBalance,@AmountPaid,@totBalance - @AmountPaid)                            
                                         
        /* Reduce AmountPaid from the Balance */                            
        select @totBalance = @totBalance - @AmountPaid                             
                            
        select @CBalance = @totBalance,@SMonthDate = @DatePaid,@PayMonth=0,@PayYear=0,@AmountPaid=0,@newPower = 0                            
                                  
        Fetch next from PenCsr into @DatePaid,@AmountPaid                                          
     end                                          
     Close PenCsr                                          
     Deallocate PenCsr                             
                            
     /* Calculate Interest from the Last Payment date to the End of the Year/Period */                            
     if @SMonthDate < @EndDate                            
        begin                            
          select @newPower = power((1.0000000000 + (@currInterest/100.000)), ((datediff(day,@SMonthDate,@EndDate)+1)/365.00))                                          
                              
          select @totBalance = @totBalance * @newPower                            
                            
          Insert into #Balances(StartDate,DatePaid,OpenBal,BalWithInt,Payment,ClosingBal)                            
                    Values(@StartDate,@EndDate,@CBalance,@totBalance,0,@totBalance)                                     
      end                            
  end                             
else                             
  begin       
                                 
    select @newPower = power((1.0000000000 + (@currInterest/100.000)), ((datediff(day,@SMonthDate,@EndDate)+1)/365.00))                                          
                              
    select @totBalance = @totBalance * @newPower                            
                            
    Insert into #Balances(StartDate,DatePaid,OpenBal,BalWithInt,Payment,ClosingBal)                            
                    Values(@StartDate,@EndDate,@CBalance,@totBalance,0,@totBalance)                            
  end                
                  
  select @Interest = @totBalance - @BalancePrin                 
                  
  if @Interest < 0 select @Interest = 0
go

