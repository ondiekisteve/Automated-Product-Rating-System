CREATE PROCEDURE [dbo].[PensionLiabilityGrid]                                      
@SCHEMENO Int,                              
@Posted Integer                                      
--with Encryption                                      
as            
if object_id('tempdb..#Liability') is null                                      
                                      
begin                                      
create table #Liability                                      
(                                      
        [StopCode] [int] Primary Key,                                       
        [SchemeNo] [varchar] (15) NOT NULL ,                                      
        [MemberNo][Int] not null,                                      
        [SurName][varchar](30)  null,                                      
        [OtherNames][Varchar](40) null,                                      
        [FullName][Varchar](150) null,                                      
        [Pension][float]  null,                                      
        [Months][int] null,                                      
        [StopPeriod][Varchar](25) null,                                      
        [StopReason][Varchar](100) null,                                      
        [TotalLiability][float] null,                                      
        [Reinstated][varchar](3) null,                                      
        [PenNo][varchar](15) not null,      
        RevLiab smallint,  
        Reinstate smallint,  
        PayMode smallint                                      
)                                       
                                       
end                                      
                                      
                                      
declare @Total float                                    
Insert Into #Liability (StopCode,SchemeNo, MemberNo, PenNo, SurName, OtherNames,FullName,                                
                        StopReason, Reinstated, StopPeriod, Pension,Months,RevLiab,Reinstate,PayMode)       
      
select DISTINCT ps.StopCode,ps.schemeNo, ps.MemberNo, p.PenNo, Upper(m.sName),m.fname +' '+m.Onames , Upper(m.sName) +', '+ m.fname +' '+m.Onames,      
 pz.Description, case ps.Reinstated                                       
              when 0 then 'No'                                      
              when 1 then 'Yes'                                      
end as Reinstate,       
mt.monthName+', ' +cast(ps.StopYear as varchar(4)),           
isnull((Select Sum(Net)from PensionPayroll where schemeNo = ps.schemeno and MemberNo = m.memberno and PayYear >= ps.stopyear and Hold = 0),0),      
isnull((Select count(*)from PensionPayroll where schemeNo = ps.schemeno and MemberNo = m.memberno and PayYear >= ps.stopyear and Hold = 0),0),      
ps.Rev_Liab,ps.Reinstated,ps.PayMode                                
from PensionStoppage ps                                      
     inner Join Pension_Stop_Setup pz on ps.StoppageType = pz.StopCode      
     inner Join members m on ps.schemeno = m.schemeno and ps.memberno = m.memberno      
     inner Join Pensioner p on ps.schemeno = p.schemeno and ps.memberno = p.memberno      
     inner Join MonthTable mt on ps.StopMonth = mt.MonthNumber      
where ps.SchemeNo = @SchemeNo and ps.ArrearsPaid = @Posted                                     
Order by ps.MemberNo             
                                      
Select @Total = sum(Pension) from #Liability                                                                      
update #Liability set TotalLiability = @Total        
                                    
Select * from #Liability where Pension >= 0  order by Months,Memberno
go

