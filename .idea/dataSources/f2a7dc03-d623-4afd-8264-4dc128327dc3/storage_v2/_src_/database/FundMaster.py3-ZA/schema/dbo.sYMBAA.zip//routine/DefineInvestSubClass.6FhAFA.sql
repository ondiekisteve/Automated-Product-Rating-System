CREATE PROCEDURE [dbo].[DefineInvestSubClass]
@InvestCode int,
@InvestDesc varchar(50)
--with Encryption
as
if Exists(select * from InvestmentTypeDetail where InvestCode = @InvestCode and InvestDesc = @InvestDesc)
begin
   raiserror('Investment SubClass %s already Exists',16,1,@InvestDesc)
end
else
Insert into InvestmentTypeDetail (InvestCode, InvestDesc)
                   Values(@InvestCode, @InvestDesc)
go

