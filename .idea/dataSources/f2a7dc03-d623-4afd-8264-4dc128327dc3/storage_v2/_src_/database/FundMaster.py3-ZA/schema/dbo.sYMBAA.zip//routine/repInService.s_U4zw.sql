CREATE PROCEDURE [dbo].[repInService]                  
@SCHEMENO Int,                  
@AsAtDate Datetime,            
@NumOfYears int                  
--with Encryption                  
as                  
                  
set nocount on                  
set concat_null_yields_null off                  
                  
declare @retCode int, @funcResult int, @currYear int, @yearClosed bit,                  
@MemberNo Int,@salOne float,@salTwo float,@salThree float,@salFour float,@salFive float,            
@empCont float,@emprCont float,@PreSalary float,@PostSalary float,@Year1 int,                  
@Year2 int,@Year3 int,@Year4 int,@Year5 int,@AcctPeriod Int,@glcode int,                  
@ProcDate1 Datetime,@ProcDate2 Datetime,@ProcDate3 Datetime,@ProcDate4 Datetime,            
@EmpContUn float,@EmprContUn float,@PooledInvestment smallInt,@FundType varchar(2),            
@SchemeCode Int,@PoolName varchar(120),@schemeName varchar(120)                   
                  
select @AcctPeriod = AcctPeriod from schemeYears where SchemeNo = @schemeNo and                   
StartDate <= @AsAtDate and EndDate >= @AsAtDate                  
                  
select @ProcDate1 = EndDate from schemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod - 1                  
                  
select @ProcDate2 = EndDate from schemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod - 2                  
            
select @ProcDate3 = EndDate from schemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod - 3                  
            
select @ProcDate4 = EndDate from schemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod - 4                  
                  
Select @Year1 = DatePart(Year,@ProcDate4),@Year2 = DatePart(Year,@ProcDate3),@Year3 = DatePart(Year,@ProcDate2),            
@Year4 = DatePart(Year,@ProcDate1),@Year5 = DatePart(year,@AsAtDate)                  
                  
if object_id('tempdb..#inService') is not null drop table #inService                  
create table #inService                  
(                 
glcode int IDENTITY(1,1) PRIMARY KEY ,                 
SchemeName Varchar(120) not null,                
SchemeNO Int not null,                 
memberNo int not null,                  
CheckNo varchar(15) not null,                  
fullName varchar(100) not null,        
IDnumber varchar(20),                  
DOB datetime,                  
DJE datetime,                  
DJPenS datetime,                  
Sex varchar(6),                  
salOne float default 0,                  
salTwo float default 0,                  
salThree float default 0,            
salFour float default 0,            
salFive float default 0,                  
empCont float default 0,                  
emprCont float default 0,                  
Year1 int default 0,                  
Year2 int default 0,                  
Year3 int default 0,                  
Year4 int default 0,            
Year5 int default 0,            
PreSalary float,                  
PostSalary float,                  
AsAtDate Datetime,                  
SponsorName varchar(100),                
PoolName varchar(120)                
)                  
                  
                       
select @PoolName = schemeName,@PooledInvestment = PooledInvestment,@FundType = FundType                
from scheme where schemeCode = @schemeNo                       
                
if @FundType = 'PF'                
BEGIN                 
Declare MembInserviceCsr cursor for                
select schemeCode,schemeName from Scheme                
where PooledInvestment = 1 and InvestmentScheme = @schemeNo                
                
Open MembInserviceCsr                
Fetch from MembInserviceCsr into @schemeCode,@schemeName                
while @@fetch_Status = 0                
begin                
                  
insert into #inService                  
(SchemeNO,SchemeName,PoolName,memberNo, CheckNo,fullName,IDNumber, DOB, DJE, DJPenS, Sex)                  
select                  
@schemeCode,@schemeName,@PoolName,m.MemberNo,m.PayrollNo,                 
UPPER(m.sName) + ', ' + m.fName + ' ' + m.oNames as fullName,m.IDNumber,                  
m.DOB,                  
m.DJE,                  
M.DJPenS,                  
case Sex when 'M' then 'M' when 'F' then 'F' end                  
from Members m                  
     inner Join Scheme s on m.schemeNo = s.SchemeCode                  
where m.SchemeNo = @schemeCode and ((m.ReasonForExit = 0)                                     
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 0) and (m.InitialDoCalc <= @AsAtDate))     
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 0) and (m.InitialDoCalc > @AsAtDate))   
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 1) and (m.InitialDoCalc > @AsAtDate))           
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 1) and (m.InitialDoCalc <= @AsAtDate) and (m.DoCalc > @AsAtDate))     
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 1) and (m.InitialDoCalc >= @AsAtDate) and (m.DoCalc > @AsAtDate))               
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus <> 6) and (m.DoCalc > @AsAtDate)))                          
             and m.Post_Status = 2 and m.membStartDate <= @AsAtDate and m.ActiveStatus <> 3 /* Suspension */                  
                  
declare InserviceCsr Cursor for                  
Select glcode,MemberNo from #inService                  
order by MemberNo                  
open InserviceCsr                  
fetch from InserviceCsr into @glcode,@MemberNo                  
while @@fetch_Status = 0                  
begin                  
  /* select @PreSalary  = Salary from Contributionssummary                  
   where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and ContrMonth = 6 and ContrYear = 2004                  
                  
                  
   select @PostSalary  = Salary from Contributionssummary                  
   where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and ContrMonth = 7 and ContrYear = 2004                  
  */                
                
   if  @PreSalary is null select @PreSalary = 0.0                  
   if  @PostSalary is null select @PostSalary = 0.0            
            
--Five Years                  
If @NumOfYears = 5            
begin                  
   select @salFive = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)                  
            
   select @salFour = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate1)            
            
   select @salThree = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate2)            
                  
   select @salTwo = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate3)                  
                  
   select @salOne = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate4)                  
end            
            
--Four Years            
If @NumOfYears = 4            
begin                   
   select @salFive = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)            
            
   select @salFour = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate1)            
                  
   select @salThree = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate2)                  
                  
   select @salTwo = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate3)                  
end            
            
--Three years            
If @NumOfYears = 3            
begin             
   select @salFive = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)            
                  
   select @salFour = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate1)                  
                  
   select @salThree = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate2)                  
end            
            
--Two Years            
If @NumOfYears = 2            
begin                 
   select @salFive = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)                  
                  
   select @salFour = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate1)                
end            
            
--One Year            
If @NumOfYears = 1            
begin                     
   select @salFive = Salary from AnnualSalary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)                  
end            
                  
   select @empCont = sum(EmpCont + Volcontr),@EmprCont = sum(EmprCont + SpecialContr)                   
   from ContributionsSummary where SchemeNo = @schemeCode and MemberNo = @MemberNo          
                     
   select @empContUn = sum(ExcessEmpCont + ExcessVolcontr),@EmprContUn = sum(ExcessEmprCont + ExcessSpecial)                   
   from UnRegisteredContributionsSummary where SchemeNo = @schemeCode and MemberNo = @MemberNo                  
                     
   if @EmpCont is null select @EmpCont = 0                  
   if @EmprCont is null select @EmprCont = 0                  
                     
   if @EmpContUn is null select @EmpContUn = 0                  
   if @EmprContUn is null select @EmprContUn = 0                  
            
   if @salFive is null select @salFive = 0   
   if @salFour is null select @salFour = 0  
   if @salThree is null select @salThree = 0   
   if @salTwo is null select @salTwo = 0    
   if @salOne is null select @salOne = 0                   
                  
   select @EmpCont = @EmpCont + @EmpContUn,@EmprCont = @EmprCont + @EmprContUn                   
                     
   update #inService                  
   set SalOne = @SalOne,SalTwo = @SalTwo,SalThree = @SalThree,SalFour = @SalFour,SalFive = @SalFive,            
   EmpCont = @EmpCont,EmprCont = @EmprCont,Year1 = @Year1,Year2 = @Year2,Year3 = @Year3,Year4 = @Year4,            
   Year5 = @Year5,PreSalary = @PreSalary,PostSalary = @PostSalary,AsAtDate = @AsAtDate                  
   where glcode = @glcode and MemberNo = @MemberNo                  
                  
   select @salFive = 0,@salFour = 0,@salThree = 0,@salTwo = 0,@salOne = 0,@empCont = 0,@EmprCont = 0,            
   @empContUn = 0,@EmprContUn = 0,@MemberNo = 0,@PreSalary = 0.0,@PostSalary = 0.0,@glcode =0                  
                  
   fetch next from InserviceCsr into @glcode,@MemberNo                  
end                  
Close InserviceCsr                  
Deallocate InserviceCsr                  
                
select @schemeCode=0,@schemeName=''                
Fetch next from MembInserviceCsr into @schemeCode,@schemeName                
end                
Close MembInserviceCsr                
Deallocate MembInserviceCsr                
                
END                
                
ELSE if @FundType <> 'PF'                
BEGIN                
insert into #inService                  
(SchemeNO,SchemeName,memberNo, CheckNo,fullName,IDNumber, DOB, DJE, DJPenS, Sex)                  
select                  
@SchemeNO,s.SchemeName,m.MemberNo,m.PayrollNo,                  
UPPER(m.sName) + ', ' + m.fName + ' ' + m.oNames as fullName,m.IDNumber,                  
m.DOB,                  
m.DJE,                  
m.DJPenS,                  
case Sex when 'M' then 'M' when 'F' then 'F' end                  
from Members M                  
     inner Join Scheme s on m.schemeNo = s.SchemeCode                  
where m.SchemeNo = @schemeNo and ((m.ReasonForExit = 0)                                     
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 0) and (m.InitialDoCalc <= @AsAtDate))     
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 0) and (m.InitialDoCalc > @AsAtDate))   
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 1) and (m.InitialDoCalc > @AsAtDate))           
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 1) and (m.InitialDoCalc <= @AsAtDate) and (m.DoCalc > @AsAtDate))     
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 1) and (m.InitialDoCalc >= @AsAtDate) and (m.DoCalc > @AsAtDate))               
             OR ((m.ReasonForExit > 0) AND (m.ActiveStatus <> 6) and (m.DoCalc > @AsAtDate)))                          
             and m.Post_Status = 2 and m.membStartDate <= @AsAtDate and m.ActiveStatus <> 3 /* Suspension */              
                  
declare InserviceCsr Cursor for                  
Select glcode,MemberNo from #inService                  
order by MemberNo                  
open InserviceCsr                  
fetch from InserviceCsr into @glcode,@MemberNo                  
while @@fetch_Status = 0                  
begin                            
   if  @PreSalary is null select @PreSalary = 0.0                  
   if  @PostSalary is null select @PostSalary = 0.0                  
                  
--Five Years                  
If @NumOfYears = 5            
begin                  
   select @salFive = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)                  
            
   select @salFour = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate1)            
            
   select @salThree = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate2)            
                  
   select @salTwo = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate3)                  
                  
   select @salOne = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate4)                  
end            
            
--Four Years            
If @NumOfYears = 4            
begin                   
   select @salFive = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)            
            
   select @salFour = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate1)            
                  
   select @salThree = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate2)                  
                  
   select @salTwo = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate3)                  
end            
            
--Three years            
If @NumOfYears = 3            
begin             
   select @salFive = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)            
                  
   select @salFour = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate1)   
              
   select @salThree = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate2)                 
end            
            
--Two Years            
If @NumOfYears = 2            
begin                 
   select @salFive = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)                  
                  
   select @salFour = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@ProcDate1)                
end            
            
--One Year            
If @NumOfYears = 1            
begin                     
   select @salFive = Salary from AnnualSalary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
   and CurYear = DatePart(Year,@AsAtDate)                  
end                  
                  
   select @empCont = sum(EmpCont + Volcontr),@EmprCont = sum(EmprCont + SpecialContr)                   
   from ContributionsSummary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
                     
   select @empContUn = sum(ExcessEmpCont + ExcessVolcontr),@EmprContUn = sum(ExcessEmprCont + ExcessSpecial)                   
   from UnRegisteredContributionsSummary where SchemeNo = @SchemeNo and MemberNo = @MemberNo                  
                     
   if @EmpCont is null select @EmpCont = 0                  
   if @EmprCont is null select @EmprCont = 0                  
                     
   if @EmpContUn is null select @EmpContUn = 0                  
   if @EmprContUn is null select @EmprContUn = 0            
            
   if @salFive is null select @salFive = 0   
   if @salFour is null select @salFour = 0  
   if @salThree is null select @salThree = 0   
   if @salTwo is null select @salTwo = 0    
   if @salOne is null select @salOne = 0                 
                        
   select @EmpCont = @EmpCont + @EmpContUn,@EmprCont = @EmprCont + @EmprContUn                   
                     
   update #inService              
   set SalOne = @SalOne,SalTwo = @SalTwo,SalThree = @SalThree,SalFour = @SalFour,SalFive = @SalFive,            
   EmpCont = @EmpCont,EmprCont = @EmprCont,Year1 = @Year1,Year2 = @Year2,Year3 = @Year3,Year4 = @Year4,            
   Year5 = @Year5,PreSalary = @PreSalary,PostSalary = @PostSalary,AsAtDate = @AsAtDate                  
   where glcode = @glcode and MemberNo = @MemberNo                  
                  
   select @salFive = 0,@salFour = 0,@salThree = 0,@salTwo = 0,@salOne = 0,@empCont = 0,@EmprCont = 0,            
   @empContUn = 0,@EmprContUn = 0,@MemberNo = 0,@PreSalary = 0.0,@PostSalary = 0.0,@glcode =0                  
                  
   fetch next from InserviceCsr into @glcode,@MemberNo                  
end                  
Close InserviceCsr                  
Deallocate InserviceCsr                
END                
                  
select * from #inService order by SchemeNO,MemberNo
go

