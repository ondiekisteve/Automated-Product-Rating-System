CREATE PROCEDURE [dbo].[Proc_GovernmentValue]    
@SCHEMENO Int,    
@SecurityNo Int,    
@EndDate Datetime,    
@MarketValue Decimal(20,6) Out,  
@Cost Decimal(20,6) Out    
--with Encryption    
as    
    
Declare @AmountInvested Decimal(20,6),    
@LatestValue Decimal(20,6),@Acquired Decimal(20,6),@Sale Decimal(20,6)    
  
select @AmountInvested = e.AmountInvested    
from GovernmentSecurities e    
     Inner Join Investments i on e.schemeNo = i.schemeNo and e.SecurityNo = i.InvCode    
     and i.DateComm <= @EndDate    
where e.SchemeNo = @SchemeNo and e.SecurityNo = @SecurityNo    
  
select @Acquired = sum(e.Cost)    
from GovernmentAcquisition e   
     Inner Join Investments i on e.schemeNo = i.schemeNo and e.SecurityNo = i.InvCode    
     and i.DateComm <= @EndDate     
where e.SchemeNo = @SchemeNo and e.SecurityNo = @SecurityNo and e.TransDate <= @EndDate   
  
select @Sale = sum(e.SellingPrice)    
from SaleGovComm e  
     Inner Join Investments i on e.schemeNo = i.schemeNo and e.PaperNo = i.InvCode    
     and i.DateComm <= @EndDate      
where e.SchemeNo = @SchemeNo and e.PaperNo = @SecurityNo  and e.TransDate <= @EndDate  
  
if @Sale is null select @Sale = 0.0  
if @Acquired is null select @Acquired = 0.0  
if @AmountInvested is null select @AmountInvested = 0.0  
  
select @Cost = (@AmountInvested + @Sale)- @Acquired  
  
select @LatestValue = MarketValue from GovCommMarketValue where schemeNo = @schemeNo and InvCode = @SecurityNo    
and EndDate = (Select Max(EndDate) from GovCommMarketValue where schemeNo = @schemeNo and InvCode = @SecurityNo    
and EndDate <= @EndDate)     
    
    
if @LatestValue > 0    
   select @MarketValue = @LatestValue    
else    
   select @MarketValue = @AmountInvested
go

