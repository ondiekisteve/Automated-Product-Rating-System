CREATE PROCEDURE [dbo].[actDatesGrid]
@SCHEMENO Int
--with Encryption
as
select *
from ActurialValuation
where SchemeNo = @SchemeNo
go

