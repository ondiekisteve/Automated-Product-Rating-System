CREATE PROCEDURE [dbo].[Proc_Invest_Allocation]
@schemeNo Int,
@InvCode Int,
@AllocMode Int,/* 0 - Current Scheme, 1 - Globally */
@AsAtDate datetime
--with encryption
as

if object_id('tempdb..#Invest_Alloc') is null                     
begin                
create table #Invest_Alloc                
(                
        PayCode int IDENTITY(1,1) Primary Key,
        SchemeName varchar(120),          
        InvestName varchar(120),
        InvName varchar(120),          
        Amount float,
        PercAlloc float,
        InvestClass varchar(100)                              
)                       
end   

declare @InvestNo Int,@InvestCode Int,@InvestName varchar(120),@Amount float,@InvName varchar(120),
        @schemeName varchar(120),@InCode Int,@schemeCode Int,@TotalAmt float,@PercAlloc float,
        @PayCode Int,@InvestClass varchar(100)

select @InvestNo = InvestNo,@InvestCode = InvestCode from Investments
where schemeNo = @schemeNo and InvCode = @InvCode

select @InvestClass = InvestDesc from InvestmentTypes where InvestCode = @InvestCode

select @InvestName = InvestName from TBL_Invest_Names where InvestNo = @InvestNo

if @AllocMode = 0
begin
   select @schemeName = schemename from scheme where schemeCode = @schemeNo

   select @schemeCode = @schemeNo

   if @InvestCode = 4
      BEGIN
      /* Primary Auction */
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NominalValue
      from Investments i
           inner join GovernmentSecurities g on i.schemeNo = g.schemeNo and i.InvCode = g.SecurityNo
                                            and g.MaturityDate >= @AsAtDate and g.TransDate <= @AsAtDate
                                            and g.FromSecondary = 0
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      
      /* Secondary Market */
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NominalValue
      from Investments i
           inner join GovernmentSecurities g on i.schemeNo = g.schemeNo and i.InvCode = g.SecurityNo
                                            and g.MaturityDate >= @AsAtDate and g.DateBought <= @AsAtDate
                                            and g.FromSecondary = 1
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr

      END
   else if @InvestCode = 2 /* Quoted Equity */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NoOfShares * g.PricePerShare
      from Investments i
           inner join Equity g on i.schemeNo = g.schemeNo and i.InvCode = g.EquityNo
                                            and g.DateInvested <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 3 /* Un-Quoted Equity */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NoOfShares * g.PricePerShare
      from Investments i
           inner join Equity g on i.schemeNo = g.schemeNo and i.InvCode = g.EquityNo
                                            and g.DateInvested <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
  else if @InvestCode = 5 /* Fixed Term Deposits */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.Amount
      from Investments i
           inner join CashDeposits g on i.schemeNo = g.schemeNo and i.InvCode = g.DepositNo
                                            and g.MaturityDate >= @AsAtDate and g.TransDate <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 7
      BEGIN
      /* Primary Auction */
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NominalValue
      from Investments i
           inner join CommercialPaper g on i.schemeNo = g.schemeNo and i.InvCode = g.PaperNo
                                            and g.MaturityDate >= @AsAtDate and g.TransDate <= @AsAtDate
                                            and g.FromSecondary = 0
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      /* Secondary Market */
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NominalValue
      from Investments i
           inner join CommercialPaper g on i.schemeNo = g.schemeNo and i.InvCode = g.PaperNo
                                            and g.MaturityDate >= @AsAtDate and g.DateBought <= @AsAtDate
                                            and g.FromSecondary = 1
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 8 /* Fixed Term Deposits */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.Amount
      from Investments i
           inner join DemandDeposits g on i.schemeNo = g.schemeNo and i.InvCode = g.DepositNo
                                            and g.DateInvested <= @AsAtDate and g.Redeem = 0
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo


      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
     END
   else if @InvestCode = 9 /* Long Term Loans */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.Loan
      from Investments i
           inner join TBL_Loans g on i.schemeNo = g.schemeNo and i.InvCode = g.MortgageNo
                                            and g.DateApplied <= @AsAtDate and g.MaturityDate >= @AsAtDate
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo



      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 10 /* Offshore Fixed Interest */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.UnitsBought * g.CostPerUnit
      from Investments i
           inner join Offshore g on i.schemeNo = g.schemeNo and i.InvCode = g.OffshoreNo
                                            and g.DateInvested <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 11 /* Offshore Equity */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.UnitsBought * g.CostPerUnit
      from Investments i
           inner join Offshore g on i.schemeNo = g.schemeNo and i.InvCode = g.OffshoreNo
                                            and g.DateInvested <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
    else if @InvestCode = 12 /* Endowments */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.AmountPaid
      from Investments i
           inner join tbl_endowments g on i.schemeNo = g.schemeNo and i.InvCode = g.OffshoreNo
                                            and g.DateBought <= @AsAtDate and g.MaturityDate >= @AsAtDate
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END

   
   select @TotalAmt = sum(Amount) from #Invest_Alloc

   declare pcsr cursor for 
   Select PayCode,Amount 
   from #Invest_Alloc 
   open pcsr
   fetch from pcsr into @PayCode,@Amount
   while @@fetch_status = 0
   begin
     if @Amount > 0
        select @PercAlloc = (@Amount/@TotalAmt) * 100.0000
     else
        select @PercAlloc = 0.0

     update #Invest_Alloc set PercAlloc = @PercAlloc
     where PayCode = @PayCode

     select @PayCode=0,@Amount=0
     fetch next from pcsr into @PayCode,@Amount
   end
   close pcsr
   deallocate pcsr

   SELECT * FROM #Invest_Alloc
end
else if @AllocMode = 1
begin
   declare scsr cursor for
   select distinct SchemeNo from Investments where InvestNo = @InvestNo

   open scsr
   fetch from scsr into @schemeCode
   while @@fetch_status = 0
   begin 

   select @schemeName = schemename from scheme where schemeCode = @schemeCode

   if @InvestCode = 4
      BEGIN
      /* Primary Auction */
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NominalValue
      from Investments i
           inner join GovernmentSecurities g on i.schemeNo = g.schemeNo and i.InvCode = g.SecurityNo
                                            and g.MaturityDate >= @AsAtDate and g.TransDate <= @AsAtDate
                                            and g.FromSecondary = 0
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      
      /* Secondary Market */
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NominalValue
      from Investments i
           inner join GovernmentSecurities g on i.schemeNo = g.schemeNo and i.InvCode = g.SecurityNo
                                            and g.MaturityDate >= @AsAtDate and g.DateBought <= @AsAtDate
                                            and g.FromSecondary = 1
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr

      END
   else if @InvestCode = 2 /* Quoted Equity */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NoOfShares * g.PricePerShare
      from Investments i
           inner join Equity g on i.schemeNo = g.schemeNo and i.InvCode = g.EquityNo
                                            and g.DateInvested <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 3 /* Un-Quoted Equity */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NoOfShares * g.PricePerShare
      from Investments i
           inner join Equity g on i.schemeNo = g.schemeNo and i.InvCode = g.EquityNo
                                            and g.DateInvested <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
  else if @InvestCode = 5 /* Fixed Term Deposits */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.Amount
      from Investments i
           inner join CashDeposits g on i.schemeNo = g.schemeNo and i.InvCode = g.DepositNo
                                            and g.MaturityDate >= @AsAtDate and g.TransDate <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 7
      BEGIN
      /* Primary Auction */
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NominalValue
      from Investments i
           inner join CommercialPaper g on i.schemeNo = g.schemeNo and i.InvCode = g.PaperNo
                                            and g.MaturityDate >= @AsAtDate and g.TransDate <= @AsAtDate
                                            and g.FromSecondary = 0
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      /* Secondary Market */
      declare icsr cursor for
      select i.InvCode,i.Invname,g.NominalValue
      from Investments i
           inner join CommercialPaper g on i.schemeNo = g.schemeNo and i.InvCode = g.PaperNo
                                            and g.MaturityDate >= @AsAtDate and g.DateBought <= @AsAtDate
                                            and g.FromSecondary = 1
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 8 /* Fixed Term Deposits */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.Amount
      from Investments i
           inner join DemandDeposits g on i.schemeNo = g.schemeNo and i.InvCode = g.DepositNo
                                            and g.DateInvested <= @AsAtDate and g.Redeem = 0
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo


      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
     END
   else if @InvestCode = 9 /* Long Term Loans */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.Loan
      from Investments i
           inner join TBL_Loans g on i.schemeNo = g.schemeNo and i.InvCode = g.MortgageNo
                                            and g.DateApplied <= @AsAtDate and g.MaturityDate >= @AsAtDate
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo



      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 10 /* Offshore Fixed Interest */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.UnitsBought * g.CostPerUnit
      from Investments i
           inner join Offshore g on i.schemeNo = g.schemeNo and i.InvCode = g.OffshoreNo
                                            and g.DateInvested <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   else if @InvestCode = 11 /* Offshore Equity */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.UnitsBought * g.CostPerUnit
      from Investments i
           inner join Offshore g on i.schemeNo = g.schemeNo and i.InvCode = g.OffshoreNo
                                            and g.DateInvested <= @AsAtDate 
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
    else if @InvestCode = 12 /* Endowments */
      BEGIN
      declare icsr cursor for
      select i.InvCode,i.Invname,g.AmountPaid
      from Investments i
           inner join tbl_endowments g on i.schemeNo = g.schemeNo and i.InvCode = g.OffshoreNo
                                            and g.DateBought <= @AsAtDate and g.MaturityDate >= @AsAtDate
      where i.schemeNo = @schemeCode and i.InvestNo = @InvestNo

      open icsr
      fetch from icsr into @InCode,@InvName,@Amount
      while @@fetch_status = 0
      begin

      Insert into #Invest_Alloc (SchemeName,InvestName,InvName,Amount,PercAlloc,InvestClass)                
                          Values(@schemeName,@InvestName,@InvName,@Amount,0,@InvestClass)


      select @InvName='',@Amount=0,@InCode=0
      fetch next from icsr into @InCode,@InvName,@Amount
      end
      close icsr
      deallocate icsr
      END
   select @schemeCode = 0,@schemeName =''
   fetch next from scsr into @schemeCode
   END
   close scsr
   deallocate scsr

   select @TotalAmt = sum(Amount) from #Invest_Alloc

   declare pcsr cursor for 
   Select PayCode,Amount 
   from #Invest_Alloc 
   open pcsr
   fetch from pcsr into @PayCode,@Amount
   while @@fetch_status = 0
   begin
     if @Amount > 0
        select @PercAlloc = (@Amount/@TotalAmt) * 100.0000
     else
        select @PercAlloc = 0.0

     update #Invest_Alloc set PercAlloc = @PercAlloc
     where PayCode = @PayCode

     select @PayCode=0,@Amount=0
     fetch next from pcsr into @PayCode,@Amount
   end
   close pcsr
   deallocate pcsr

   SELECT * FROM #Invest_Alloc
end
go

