CREATE PROCEDURE [dbo].[RepTransfers]
@SCHEMENO Int,
@CurMonth Int,
@CurYear Int

as

Declare @LastDate Datetime

Exec GetLastDate @CurMonth,@CurYear,@LastDate Out

Select m.MemberNo,m.PayrollNo,Upper(m.sName)+', '+m.fName+' '+m.Onames as FullName,
(t.EmpTransfer + t.EmprTransfer)* (t.PercentageLocked/100.0000) as LockedIn,
(t.EmpTransfer + t.EmprTransfer) -(t.EmpTransfer + t.EmprTransfer)* (t.PercentageLocked/100.0000) as UnLocked,
b.LockedInValue as LockedInInt,b.TransferValue as UnlockedInt
from MemberTransfer t
     Inner Join Members m on t.schemeNo = m.schemeNo and t.MemberNo = m.MemberNo
     Inner Join Benefits b on t.schemeNo = b.schemeNo and t.MemberNo = b.MemberNo
     and b.TransferValue > 0
go

