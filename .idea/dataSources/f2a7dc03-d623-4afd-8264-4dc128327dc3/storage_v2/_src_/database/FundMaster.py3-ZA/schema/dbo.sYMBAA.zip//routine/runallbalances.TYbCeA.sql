CREATE procedure dbo.runallbalances  
@schemeno int  
as  
  
declare @acctperiod int, @curyear smallint, @curmonth smallint, @enddate datetime, @startdate datetime  
  
declare namcsr cursor for  
select startdate, enddate, acctperiod, schemeyear from schemeyears  
 where schemeno = @schemeno and schemeyear in (2009, 2010)
/*and acctperiod >0 and acctperiod < (  
Select max(acctperiod) from schemeyears where schemeno =@schemeno)  and schemeyear > 2001  */
order by acctperiod  
  
open namcsr  
fetch from namcsr into @startdate, @enddate, @acctperiod, @curyear  
  
while @@fetch_status = 0  
begin  
exec calcbenefits @schemeno,12, @curyear, 0  
  
exec proc_closeyear @schemeno, @startdate, @enddate  
  
Update schemeyears set yearclosed = 0 where schemeno = @schemeno and acctperiod = @acctperiod  
  
  
select @acctperiod = 0, @curyear = 0  
fetch next from namcsr into @startdate, @enddate, @acctperiod, @curyear  
end  
close namcsr  
deallocate namcsr


go

