CREATE PROCEDURE [dbo].[PortFolioIncome]                      
@SCHEMENO Int,                      
@StartDate Datetime,                      
@EndDate Datetime,
@RepMode Int /*0 - Locally, 1 - Globally */                    
                      
--with Encryption                      
as                      
                      
if object_id('tempdb..#PortfolioIncome') is null                      
                      
begin                      
create table #PortfolioIncome                      
(                      
        [InvestCode][Integer]Identity (1,1) Primary Key,                      
        [SchemeName][varchar](120) null,                      
        [Investment] [varchar](100) NOT NULL,
        [IncomeLine][varchar](100),                      
        [amount] Decimal(20,6) not  NULL default 0.0,                      
        [Percentage] [Float] null default 0.0,                      
        [Total][Float]null default 0.0,                      
        [Currency][varchar](30),                      
        [Period][varchar](30),                      
        [AmountInvested] Decimal(20,6),                    
        [StartDate][Datetime],                    
        [EndDate][Datetime]                                        
)                       
                      
end                      
                      
declare @InvestCode Int,@Investment varchar(50),@Percentage float,@Total Decimal(20,6),                      
@AmountInvested Decimal(20,6),@SchemeName varchar(120),@Curr varchar(15),@Currency varchar(30),@Period varchar(20),                      
@Amount Decimal(20,6),
@IncomeLine varchar(100),@Counter Int                     
                      
Select @Total = 0                    
                                      
Select @SchemeName = schemeName,@Curr = Currency from scheme where schemeCode = @schemeNo                      
                      
Select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @Curr                      
                                          
Declare Xcsr Cursor for                      
Select Distinct(InvestCode) from                      
InvestMents                       
where SchemeNo = @SchemeNo                    
                      
Open Xcsr                      
                      
fetch from Xcsr into @InvestCode                      
                      
while @@fetch_Status = 0                      
begin                      
     select @Investment = InvestDesc from InvestmentTypes where InvestCode = @InvestCode                      
                      
            if @InvestCode = 1 /*Rental Income */                    
               begin
 
               Exec Proc_Property_Value @SCHEMENO,@EndDate,@AmountInvested Out
               if @AmountInvested is null select @AmountInvested = 0 
                   
               select @Amount = sum(c.Rent + c.ServiceCharge + c.parking)                       
               from RentInvoice c                        
               where c.SchemeNo = @schemeNo and c.InvoiceDate >= @StartDate and c.InvoiceDate <= @EndDate                   
                                
               select @IncomeLine = 'Rental Income'
               if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0

               select @Amount = sum(Valuation - PrevValue) from TBL_Property_Valuation
               where schemeNo = @schemeNo and ValuationDate >= @StartDate and ValuationDate <= @EndDate                        
                               
               select @IncomeLine = 'Change In Market Value'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
             
               end                    
            else if @InvestCode = 2 /*Quoated Equity*/                      
               begin  
               Exec Proc_Equity_Value @SCHEMENO,@EndDate,@EndDate,0,@AmountInvested Out 
                  
               select @Amount = sum(a.Dividend*b.NoofShares)                       
               from EquityDividends a                      
                     inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                               
               where a.SchemeNo = @schemeNo and a.RecordDate >= @StartDate and a.RecordDate <= @EndDate                     
               
               select @IncomeLine = 'Dividends Income'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0
                  
               select @Amount = sum(Income)                       
               from SaleEquity a                      
               inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                          
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate

               select @IncomeLine = 'Profit/Loss on Sale of Equity'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 

               select @Amount = sum((a.PricePershare * a.NoOfshares) - (a.PrevPrice * a.NoOfShares))                       
               from EquityValue a                      
                     inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                               
               where a.SchemeNo = @schemeNo and a.PriceDate >= @StartDate and a.PriceDate <= @EndDate 
  
               select @IncomeLine = 'Change in Market Value'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 

               select @Amount = sum(Income * exRate)                      
               from tbl_Invest_Receivable a                      
                     inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.EquityNo and b.EquityType = @InvestCode                              
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate 
  
               select @IncomeLine = 'Accrued Interest - Preferential Shares'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 
    

               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.EquityNo and b.EquityType = @InvestCode                              
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0        
              end 
           else if @InvestCode = 3 /* Un Quoated Equity*/                      
               begin  
               Exec Proc_Equity_Value @SCHEMENO,@EndDate,@EndDate,0,@AmountInvested Out 
                  
               select @Amount = sum(a.Dividend*b.NoofShares)                       
               from EquityDividends a                      
                     inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                               
               where a.SchemeNo = @schemeNo and a.RecordDate >= @StartDate and a.RecordDate <= @EndDate                     
               
               select @IncomeLine = 'Dividends Income'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0
                  
               select @Amount = sum(Income)                       
               from SaleEquity a                      
               inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                          
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate

               select @IncomeLine = 'Profit/Loss on Sale of Equity'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 

               select @Amount = sum((a.PricePershare * a.NoOfshares) - (a.PrevPrice * a.NoOfShares))                       
               from EquityValue a                      
                     inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                               
               where a.SchemeNo = @schemeNo and a.PriceDate >= @StartDate and a.PriceDate <= @EndDate 
  
               select @IncomeLine = 'Change in Market Value'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 

               select @Amount = sum(Income * exRate)                      
               from tbl_Invest_Receivable a                      
                     inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.EquityNo and b.EquityType = @InvestCode                              
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate 
  
               select @IncomeLine = 'Accrued Interest - Preferential Shares'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 
    

               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.EquityNo and b.EquityType = @InvestCode                              
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0        
              end                                          
            else if @InvestCode = 4 /*Government Paper */                   
              begin  
               Exec Rep_Investment_Value @schemeNo,@EndDate,@EndDate,0,0,@AmountInvested Out 
                   
               select @Amount = sum(c.Income)                       
               from TBL_Invest_Receivable c                                   
               where c.SchemeNo = @schemeNo and c.TransDate >= @StartDate and c.TransDate <= @EndDate      
               and InvestCode = 4        
        
               select @IncomeLine = 'Accrued Interest'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0

               
               select @Amount = sum(c.ChangeInValue)                       
               from GovCommMarketValue c                                   
               where c.SchemeNo = @schemeNo and c.EndDate >= @StartDate and c.EndDate <= @EndDate      
               and InvestCode = 4        
        
               select @IncomeLine = 'Change In Market Value'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0
                    
              end                  
            else if @InvestCode = 5 /*Fixed and Time Deposits */                  
              begin 
               Exec Rep_Investment_Value @schemeNo,@EndDate,@EndDate,2,0,@AmountInvested Out   
                     
               select @Amount = sum(c.Income * c.ExRate)                       
               from TBL_Invest_Receivable c                                   
               where c.SchemeNo = @schemeNo and c.TransDate >= @StartDate and c.TransDate <= @EndDate      
               and InvestCode = 5 

               select @IncomeLine = 'Accrued Interest'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                    
                                    
               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join CashDeposits b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.DepositNo                               
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                    
             end                  
            else if @InvestCode = 7 /*Commercial Paper */                  
             begin 
               Exec Rep_Investment_Value @schemeNo,@EndDate,@EndDate,1,0,@AmountInvested Out
                     
               select @Amount = sum(c.Income * c.ExRate)                       
               from TBL_Invest_Receivable c                                   
               where c.SchemeNo = @schemeNo and c.TransDate >= @StartDate and c.TransDate <= @EndDate      
               and InvestCode = 7                  
                  
                                     
               select @IncomeLine = 'Accrued Interest'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                    
                                    
               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join CommercialPaper b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.PaperNo                               
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 

               select @Amount = sum(c.ChangeInValue)                       
               from GovCommMarketValue c                                   
               where c.SchemeNo = @schemeNo and c.EndDate >= @StartDate and c.EndDate <= @EndDate      
               and InvestCode = 7        
        
               select @IncomeLine = 'Change In Market Value'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0            
             end                  
            else if @InvestCode = 8 /*Cash and Demand Deposits */                  
             begin 
               Exec Rep_Investment_Value @schemeNo,@EndDate,@EndDate,3,0,@AmountInvested Out 
                     
               select @Amount = sum(c.Income * c.ExRate)                       
               from TBL_Invest_Receivable c                                   
               where c.SchemeNo = @schemeNo and c.TransDate >= @StartDate and c.TransDate <= @EndDate      
               and InvestCode = 8                     
                      
               select @IncomeLine = 'Accrued Interest'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                    
                                    
               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join DemandDeposits b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.DepositNo                               
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                  
            end
        else if @InvestCode = 9 /*Long Term Loans */                  
             begin 
               Exec Rep_Investment_Value @schemeNo,@EndDate,@EndDate,1,0,@AmountInvested Out
                     
               select @Amount = sum(c.Income * c.ExRate)                       
               from TBL_Invest_Receivable c                                   
               where c.SchemeNo = @schemeNo and c.TransDate >= @StartDate and c.TransDate <= @EndDate      
               and InvestCode = 9                  
                  
                                     
               select @IncomeLine = 'Accrued Interest'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                    
                    
               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join TBL_Loans b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.MortgageNo                               
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0            
             end                    
       else if (@InvestCode = 10) /* Offshore Fixed Interest */   
            begin                     
               /*select @Amount = sum(Income)                       
               from SaleEquity a                      
               inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                          
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate

               select @IncomeLine = 'Profit/Loss on Sale of Equity'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               */
               select @Amount = 0 


               select @Amount = sum(((a.CurrentValue * a.NoOfUnits) - (a.PrevPrice * a.NoOfUnits)) * a.SpotRate)                       
               from OffshoreValue a                      
                     inner Join Offshore b on a.SchemeNo = b.schemeNo                      
                     and a.OffshoreNo = b.OffshoreNo and b.OffshoreForex = @InvestCode                               
               where a.SchemeNo = @schemeNo and a.ValueDate >= @StartDate and a.ValueDate <= @EndDate 
  
               select @IncomeLine = 'Change in Market Value'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 

               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join Offshore b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.OffshoreNo and b.OffshoreForex = @InvestCode                              
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                      
            end 
         else if (@InvestCode = 11) /* Offshore Equity */   
            begin                     
               /*select @Amount = sum(Income)                       
               from SaleEquity a                      
               inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                          
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate

               select @IncomeLine = 'Profit/Loss on Sale of Equity'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               */
               select @Amount = 0 


               select @Amount = sum(((a.CurrentValue * a.NoOfUnits) - (a.PrevPrice * a.NoOfUnits)) * a.SpotRate)                       
               from OffshoreValue a                      
                     inner Join Offshore b on a.SchemeNo = b.schemeNo                      
                     and a.OffshoreNo = b.OffshoreNo and b.OffshoreForex = @InvestCode                               
               where a.SchemeNo = @schemeNo and a.ValueDate >= @StartDate and a.ValueDate <= @EndDate 
  
               select @IncomeLine = 'Change in Market Value'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 

               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join Offshore b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.OffshoreNo and b.OffshoreForex = @InvestCode                              
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                     
            end 
         else if (@InvestCode = 12) /* Endowments */   
            begin                     
               /*select @Amount = sum(Income)                       
               from SaleEquity a                      
               inner Join Equity b on a.SchemeNo = b.schemeNo                      
                     and a.EquityNo = b.EquityNo and b.EquityType = @InvestCode                          
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate

               select @IncomeLine = 'Profit/Loss on Sale of Equity'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               */
               select @Amount = 0 

               select @Amount = sum(a.Amount * a.SpotRate)                       
               from TBL_Endowment_Prem a                                                         
               where a.SchemeNo = @schemeNo and a.TransDate >= @StartDate and a.TransDate <= @EndDate 
               and a.BonusOrPremium = 1
  
               select @IncomeLine = 'Bonus'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0 

               select @Amount = sum((CurrRate - PrevRate) * NoOfUnits)                      
               from TBL_Invest_Curr_Reval a                      
                     inner Join TBL_Endowments b on a.SchemeNo = b.schemeNo                      
                     and a.InvCode = b.OffshoreNo                              
               where a.SchemeNo = @schemeNo and a.RevalDate >= @StartDate and a.RevalDate <= @EndDate 
  
               select @IncomeLine = 'Currency Revaluation'
		if @Amount is null select @Amount = 0
               Insert Into #PortfolioIncome (Investment,IncomeLine,Amount,currency,AmountInvested,StartDate,EndDate)                      
                  Values(@Investment,@IncomeLine,@Amount,@Currency,@AmountInvested,@StartDate,@EndDate) 
               
               select @Amount = 0                                      
            end                                                
     Select @Amount = 0,@AmountInvested = 0                      
                      
   fetch next from Xcsr into @InvestCode                      
end                      
Close Xcsr                      
Deallocate Xcsr                      
                      
select @Total = sum(Amount) from #PortfolioIncome
                       
update #PortfolioIncome set Total = @Total,schemeName = @SchemeName,Period = @Period                      
                    
Select @Investment = ' '                      
select @Amount = 0                      
                      
declare Xcsr cursor for                      
Select InvestCode, Amount                      
from #PortfolioIncome where amount <> 0                      
                      
Open Xcsr                      
                      
fetch from Xcsr Into @Counter,@Amount                      
                      
while @@fetch_Status = 0                      
begin                      
  Select @Percentage = (@Amount/@Total)*100.0000000                      
                      
  update #PortfolioIncome set Percentage = @Percentage                      
  where InvestCode = @Counter                      
                      
  Select @Percentage = 0,@Counter = 0                     
                      
  fetch from Xcsr Into @Counter,@Amount                      
end                       
Close Xcsr                      
Deallocate Xcsr                      
                      
Select * from #PortfolioIncome WHERE (Amount + AmountInvested) <> 0
go

