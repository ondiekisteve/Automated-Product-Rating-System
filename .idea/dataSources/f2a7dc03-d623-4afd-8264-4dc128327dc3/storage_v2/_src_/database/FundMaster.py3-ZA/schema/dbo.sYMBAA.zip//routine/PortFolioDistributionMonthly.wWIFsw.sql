CREATE PROCEDURE [dbo].[PortFolioDistributionMonthly]
@SCHEMENO Int,
@AsAtDate Datetime
--with Encryption
as

if object_id('tempdb..#Portfolio') is null

begin
create table #PortFolio
(
	
        [SchemeName][varchar](120) null,
	[Investment] [varchar](100) NOT NULL ,
	[amount] [float] not  NULL default 0.0,
        [Percentage] [Float] null default 0.0,
        [MaxPcntofAsset][float] null default 0.0,
        [Total][Float]null default 0.0,
        [Currency][varchar](30)
        
              
) 

ALTER TABLE #PortFolio WITH NOCHECK ADD 

            
	CONSTRAINT [PK_PortFolio] PRIMARY KEY  NONCLUSTERED 
	(
	  [Investment]      
	) 
end

declare @InvestCode Int,@Investment varchar(50),@Percentage float,@Total float,@Amount float,
@MaxPcnt float,@SchemeName varchar(120),@Curr varchar(15),@Currency varchar(30),@Mwezi Int,@Mwaka Int,
@FirstDate Datetime,@LastDate Datetime

select @Mwezi = DatePart(Month,@AsAtDate),@Mwaka = DatePart(Year,@AsAtDate)

Exec GetFirstDate @Mwezi,@Mwaka,@FirstDate Out
Exec GetLastDate @Mwezi,@Mwaka,@LastDate Out

Select @Total = 0

Select @SchemeName = schemeName,@Curr = Currency from scheme where schemeCode = @schemeNo

Select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @Curr

Declare Acsr Cursor for
Select Distinct(InvestCode) from
InvestMents where SchemeNo = @SchemeNo
and InvStatus = 0

Open acsr

fetch from acsr into @InvestCode

while @@fetch_Status = 0
begin
     select @Investment = InvestDesc,@MaxPcnt = MaxPcntofAsset 
     from InvestmentTypes where InvestCode = @InvestCode

     select @Amount = sum(InitValue) 
     from Investments 
     where InvestCode = @InvestCode 
     and SchemeNo = @schemeNo
    
     if @Amount is null select @Amount = 0

     Select @Total = @Total + @Amount

   

     Insert Into #PortFolio (Investment,Amount, MaxPcntofAsset,currency)
                  Values(@Investment,@Amount,@MaxPcnt,@Currency)

     Select @Amount = 0

   fetch next from acsr into @InvestCode
end
Close Acsr
Deallocate Acsr


update #PortFolio set Total = @Total,schemeName = @SchemeName

Select @Investment = ' '
select @Amount = 0

declare Acsr cursor for
Select Investment, Amount
from #PortFolio

Open Acsr

fetch from acsr Into @Investment,@Amount

while @@fetch_Status = 0
begin
  Select @Percentage = (@Amount/@Total)*100.0000000

  update #PortFolio set Percentage = @Percentage
  where Investment = @Investment

  Select @Percentage = 0

  fetch from acsr Into @Investment,@Amount
end
Close Acsr
Deallocate Acsr


Select * from #PortFolio
go

