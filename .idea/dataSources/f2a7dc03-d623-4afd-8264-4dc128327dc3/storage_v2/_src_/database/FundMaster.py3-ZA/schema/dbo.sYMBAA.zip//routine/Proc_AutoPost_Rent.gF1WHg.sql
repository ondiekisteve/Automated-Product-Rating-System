CREATE PROCEDURE [dbo].[Proc_AutoPost_Rent]                                                                                     
@SchemeNo Int,                                                                                      
@PropCode Int,                                                                                      
@ReceiptNo varchar(20),                                                                            
@RecTransNo Int                                                                                      
--with Encryption                                                                                      
as                                                                                      
declare @PayCode Int,@ChequeNo varchar(20),@PayDate Datetime,@Amount float,@Particulars varchar(120),                                                                                      
@CashTransNo Int,@PayMonth Int,@PayYear Int,@CreditAcc Varchar(20),@DebitAcc varchar(20),                                                                                      
@PropName varchar(120),@bankCode Int,@TransType Int,@CurrCode Int,@CurrRate float,                                                                    
@UnitNo varchar(30),@TenantCode Int,@RentBalance float,@RentPayable float,@RentPreAcc varchar(30),                                                                  
@BatchNo Int,@Deposit float,@Legal float,@DepositAcc varchar(30),@LegalFeesAcc varchar(30),@Yonze float,                                                    
@TransCode int,@Prepayment float,@Debit float,@unitcode int,@Penalty float,                                          
@PenaltyAcc varchar(30),@Sawa smallint,@OffSetUnAlloc smallint,@LeaseNo Int,@Aflife smallint,@Service float,@LCurrCode int,            
@ClearingAcc varchar(30),@PayCurrCode Int,@LeaseExRate float,@AmountCl float,@CurrRateCL float,        
@Serv_Charge_Debit_Acc varchar(30),@AmountClServ float,@SingleMultiple smallint    
                    
select @Aflife = Aflife from scheme where schemeCode = @schemeNo                     
 if @Aflife is null select @Aflife = 0     
     
                                        
                                        
select @Sawa = 1,@TransType = 192                                               
                                                                  
select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeNo                                                                     
select @TransCode = TransCode from TBL_Budget_Trans_Codes where TransType = 192                                                    
       and TransGroup = 1 /*Rent Receipts*/                                                    
                                                    
if @TransCode is null select @TransCode = 1                                                                                                                            
if @BatchNo is null select @BatchNo = 0                       
                                                                         
select @BatchNo = @BatchNo + 1                                                                                    
                                                                              
select @bankCode = r.BankCode,@CurrRate = r.ExRate,@OffSetUnAlloc = r.OffSetUnAlloc,@LeaseNo = r.LeaseNo,            
@PayCurrCode = r.PayCurrCode,@LeaseExRate = r.LeaseExRate,@TenantCode = r.TenantCode,@PayDate = r.PayDate,    
@ChequeNo = r.ChequeNo,@Particulars = t.TenantName+'-'+r.Comments,@TenantCode = r.TenantCode,@unitcode = r.UnitCode,    
@CurrCode = CurrCode,@SingleMultiple = r.SingleMultiple            
from RentReceipts r     
     inner Join Tenants t on r.schemeNo = t.schemeNo and r.PropertyCode = t.PropertyCode                       
     and r.TenantCode = t.TenantCode                                                                                      
where r.schemeNo = @SchemeNo and r.PropertyCode = @PropCode AND r.ReceiptNo = @ReceiptNo 

print @bankCode
print ('****************')    
                                                                              
if @LeaseNo is null select @LeaseNo = 0            
if @LeaseExRate is null select @LeaseExRate = 1.000  
if @SingleMultiple is null select @SingleMultiple = 0            
            
/* Get the Lease Currency */            
select @LCurrCode = CurrCode from Leases where LeaseNo = @LeaseNo            
            
/* Get the Clearing Account for Rentals not paid in the Lease Currency */            
select @ClearingAcc = ClearingAcc,@Serv_Charge_Debit_Acc = Serv_Charge_Debit_Acc         
from Pension_Setup         
where schemeNo = @schemeNo                       
                  
If exists(select receiptno from Cashbook where schemecode = @schemeNo and BankCode = @bankCode                            
          and ReceiptNo = @ReceiptNo)                              
   begin                       
     UPDATE RENTRECEIPTS SET RecExists = 1                                                           
     WHERE SCHEMENO = @SCHEMENO AND PROPERTYCODE = @PropCode AND RECEIPTNO = @ReceiptNo                              
   end                              
else                              
   begin                                                                         
if @CurrRate is null select @CurrRate = 1.0000                                    
if @OffSetUnAlloc is null select @OffSetUnAlloc = 0                                                                              
                                                                              
select @DebitAcc = AccountCode from SchemeBankBranch where schemeNo = @schemeNo and BankCode = @BankCode 
                                     
select @CreditAcc  = DebitAcc,@PropName = PropertyName,                                
@RentPreAcc = RentPreAcc,@DepositAcc=DepositAcc,@LegalFeesAcc = LegalFeesAcc,@PenaltyAcc = AccrPenaltyAcc                                                      
from Property where schemeNo = @schemeNo                                                               
and PropertyCode = @PropCode             
            
/* Credit the Rent Receivable Account Per Tenant */            
select @CreditAcc = RentDebitAcc from Tenants where TenantCode = @TenantCode and SchemeNo = @schemeNo                                              
                                                                                  
                                                                                    
if ((len(ltrim(rtrim(@CreditAcc))) = 0) or (len(ltrim(rtrim(@DebitAcc))) = 0))                                             
begin                                                                                      
   raiserror ('The Credit/Debit Accounts for the Rent receipt for %s have not been specified',16,1,@PropName)                                                                                      
   Return                                                                                      
end                                                                                      
else                                                                                      
begin                                                                                      
                                                               
Select @CashTransNo = Max(CashTransNo) from Cashbook where schemeCode = @SchemeNo                       
                      
IF @CashTransNo is null select @CashTransNo = 0                      
                                                                                  
select @CashTransNo = @CashTransNo + 1                                                                           
  
if @SingleMultiple = 0                                                                                      
select                                           
@Amount = sum((r.Receipt + r.Parking + r.ServiceCharge + r.Other) * r.CrossSpotRate),             
@Service = sum(ServiceCharge),@Deposit = sum(r.Deposit * r.CrossSpotRate),                                                      
@Legal = sum(r.LegalFees * r.CrossSpotRate),@Penalty = sum(r.Penalty* r.CrossSpotRate)                                                                                      
from RentReceipts r                                                                                                                                       
where r.schemeNo = @SchemeNo and r.PropertyCode = @PropCode AND r.ReceiptNo = @ReceiptNo and PayDate = @PayDate  
else if @SingleMultiple = 1                                                                                     
select                                           
@Amount = sum((r.Receipt + r.Parking + r.ServiceCharge + r.Other) * r.CrossSpotRate),             
@Service = sum(ServiceCharge),@Deposit = sum(r.Deposit * r.CrossSpotRate),                                                      
@Legal = sum(r.LegalFees * r.CrossSpotRate),@Penalty = sum(r.Penalty* r.CrossSpotRate)                                                                                      
from RentReceipts r                                                                                                                                       
where r.schemeNo = @SchemeNo and r.ReceiptNo = @ReceiptNo and PayDate = @PayDate    
    
                                                                                                                                                                    
select @PayMonth = DatePart(Month,@PayDate),@PayYear = DatePart(Year,@PayDate)                                                                      
                                            
Exec Proc_Det_RentBalance @SCHEMENO,@PropCode,@LeaseNo,@TenantCode,@PayDate,@RentBalance Out,@RentPayable Out                                                                     
                                              
if @RentPayable is null select @RentPayable = 0                                              
if @RentBalance is null select @RentBalance = 0                                              
                                                                               
/*                                                                                     
if @RentBalance < 1 its a prepayment else a normal payment                                                                    
*/                                                    
                                        
if @Legal > 0 and len(@LegalFeesAcc) = 0                                        
   select @Sawa = 0                                        
                                        
                                           
if @Deposit > 0 and len(@DepositAcc) = 0                                        
   select @Sawa = 0                                        
                                        
if @Penalty > 0 and len(@PenaltyAcc) = 0                                        
   select @Sawa = 0                                        
                    
if @Aflife = 1                    
   begin             
       if @PayCurrCode <> @LCurrCode            
          begin               
             if @Amount > 0 /* Hit the Clearing Account */            
                begin            
                Exec PostLedgerCreditsRec @SCHEMENO,@ClearingAcc,@ReceiptNo,@Amount,@PayMonth,@PayYear,@Particulars,                                                                   
                @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1              
                   
                /* Reverse Entry in the Clearing Account */            
                select @AmountCl = @Amount/@LeaseExRate /* Get Amount in Lease Currency */             
                select @CurrRateCL = (@Amount*@CurrRate)/@AmountCl /* Get Exchange rate for the Amount in Lease Currency */        
            
                /* Credit Rental Debtors Account */        
                if @Service = 0            
                   Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@AmountCl,@PayMonth,@PayYear,@Particulars,                                                                   
                   @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@LCurrCode,@CurrRateCL,@BatchNo,0,@TransType,1         
                else        
                   begin        
                   if (@Amount > @Service)        
                      select @AmountClServ = (@Amount - @Service)/@LeaseExRate /* Get Amount in Lease Currency */        
                   else        
                      select @AmountClServ = 0        
                          
                   /* Credit Rental Debtors Account in Invoice Currency */        
                   if @AmountClServ > 0        
                      Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@AmountClServ,@PayMonth,@PayYear,@Particulars,                                                                   
                      @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@LCurrCode,@CurrRateCL,@BatchNo,0,@TransType,1         
        
                   /* Credit Rental Debtors Account in functional currency (ZMK) */        
                   Exec PostLedgerCreditsRec @SCHEMENO,@Serv_Charge_Debit_Acc,@ReceiptNo,@Service,@PayMonth,@PayYear,@Particulars,                                                              
                   @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1        
                           
                   end             
            
                /* Debit Clearing Account  */            
                Exec PostLedgerDebitsRec @SCHEMENO,@ClearingAcc,@ReceiptNo,@AmountCl,@PayMonth,@PayYear,@Particulars,                                                                                    
                @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@LCurrCode,@CurrRateCL,@BatchNo,0,@TransType,1            
                end                                                                             
              if @Legal > 0                                                      
                begin                                      
                Exec PostLedgerCreditsRec @SCHEMENO,@LegalFeesAcc,@ReceiptNo,@Legal,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                  
                end             
            
              select @AmountCl = 0,@CurrRateCL = 0            
                                                                                 
              if @Deposit > 0                                                      
              begin                                              
                 Exec PostLedgerCreditsRec @SCHEMENO,@ClearingAcc,@ReceiptNo,@Deposit,@PayMonth,@PayYear,@Particulars,                                                                                            
                      @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1             
            
                 /* Reverse Entry in the Clearing Account */            
                 select @AmountCl = @Deposit/@LeaseExRate /* Get Amount in Lease Currency */             
                 select @CurrRateCL = (@Deposit*@CurrRate)/@AmountCl /* Get Exchange rate for the Amount in Lease Currency */            
                            
                /* Credit Rental Debtors Account */            
                 Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@AmountCl,@PayMonth,@PayYear,@Particulars,                                                                   
                 @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@LCurrCode,@CurrRateCL,@BatchNo,0,@TransType,1             
            
                /* Debit Clearing Account  */            
                 Exec PostLedgerDebitsRec @SCHEMENO,@ClearingAcc,@ReceiptNo,@AmountCl,@PayMonth,@PayYear,@Particulars,                                                                                    
                 @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@LCurrCode,@CurrRateCL,@BatchNo,0,@TransType,1                                                                                           
              end                                           
                          
              select @AmountCl = 0,@CurrRateCL = 0            
                                  
              if @Penalty > 0                                                      
               begin                                                      
                  Exec PostLedgerCreditsRec @SCHEMENO,@PenaltyAcc,@ReceiptNo,@Penalty,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1             
            
            
                 /* Reverse Entry in the Clearing Account */            
        select @AmountCl = @Penalty/@LeaseExRate /* Get Amount in Lease Currency */             
                 select @CurrRateCL = (@Penalty*@CurrRate)/@AmountCl /* Get Exchange rate for the Amount in Lease Currency */            
                            
                /* Credit Rental Debtors Account */            
                 Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@AmountCl,@PayMonth,@PayYear,@Particulars,                                                                   
                 @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@LCurrCode,@CurrRateCL,@BatchNo,0,@TransType,1             
            
                /* Debit Clearing Account  */            
                 Exec PostLedgerDebitsRec @SCHEMENO,@ClearingAcc,@ReceiptNo,@AmountCl,@PayMonth,@PayYear,@Particulars,                                                                                    
                 @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@LCurrCode,@CurrRateCL,@BatchNo,0,@TransType,1                                                                                          
               end                                                                                   
                         
             if @Legal is null select @Legal = 0                                      
             if @Deposit is null select @Deposit = 0                                           
             if @Penalty is null select @Penalty = 0                                                  
                                                   
             select @Yonze = @Legal + @Deposit + @Amount + @Penalty                                                       
                                                      
             Exec PostLedgerDebitsRec @SCHEMENO,@DebitAcc,@ReceiptNo,@Yonze,@PayMonth,@PayYear,@Particulars,                                                                                    
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                      
                                                                    
             Exec PostReceiptToCashBook @SCHEMENO,@BankCode,@ReceiptNo,@PayMonth,@PayYear,@Particulars,@Yonze,@TransCode,@ChequeNo,                                                                                      
                  @PayDate,@CashTransNo,@CurrCode,@CurrRate             
                          
          end            
       else            
          begin                  
          if @Amount > 0                    
             Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@Amount,@PayMonth,@PayYear,@Particulars,                                                                   
             @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                      
                                                      
          if @Legal > 0                                                      
              begin                                                      
                Exec PostLedgerCreditsRec @SCHEMENO,@LegalFeesAcc,@ReceiptNo,@Legal,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
              end                                                                                 
           if @Deposit > 0                                                      
              begin                                              
                 Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@Deposit,@PayMonth,@PayYear,@Particulars,                                                                                            
                      @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
              end                                           
                                                
          if @Penalty > 0                                                      
             begin                                                      
               Exec PostLedgerCreditsRec @SCHEMENO,@PenaltyAcc,@ReceiptNo,@Penalty,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
             end                                                                                   
          if @Legal is null select @Legal = 0                                      
          if @Deposit is null select @Deposit = 0                                           
          if @Penalty is null select @Penalty = 0                                                  
                                                   
          select @Yonze = @Legal + @Deposit + @Amount + @Penalty                                                       
          
          PRINT('HAPO VIPI') 
          print @DebitAcc
          print ('&&&&&&&&&&&&&&&&&&&&&&&&&&&')                                           
          Exec PostLedgerDebitsRec @SCHEMENO,@DebitAcc,@ReceiptNo,@Yonze,@PayMonth,@PayYear,@Particulars,                                                                                    
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                      
                                                                    
          Exec PostReceiptToCashBook @SCHEMENO,@BankCode,@ReceiptNo,@PayMonth,@PayYear,@Particulars,@Yonze,@TransCode,@ChequeNo,                                                                                      
                  @PayDate,@CashTransNo,@CurrCode,@CurrRate             
                          
      end              
   end                    
else                    
  begin                                                                   
    if @RentBalance < 0                                                                    
       begin                                                                                      
      --Credit Prepayments             
      if len(@RentPreAcc) = 0                                        
         select @Sawa = 0                                        
                                              
      if @Sawa = 1                                        
         begin                          
            Exec PostLedgerCreditsRec @SCHEMENO,@RentPreAcc,@ReceiptNo,@Amount,@PayMonth,@PayYear,@Particulars,              
            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                      
                                                    
           if @Legal > 0                                                      
              begin                                                      
                Exec PostLedgerCreditsRec @SCHEMENO,@LegalFeesAcc,@ReceiptNo,@Legal,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
              end                                                        
                                                            
           if @Deposit > 0                                                      
              begin                                              
                 Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@Deposit,@PayMonth,@PayYear,@Particulars,                                                                                            
          @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
              end                                           
                                                
          if @Penalty > 0                                                      
             begin                                                      
               Exec PostLedgerCreditsRec @SCHEMENO,@PenaltyAcc,@ReceiptNo,@Penalty,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
             end                                                       
                                                        
      if @Legal is null select @Legal = 0                                      
      if @Deposit is null select @Deposit = 0                                           
      if @Penalty is null select @Penalty = 0                                                  
                                                   
      select @Yonze = @Legal + @Deposit + @Amount + @Penalty                                                       
                                                      
      Exec PostLedgerDebitsRec @SCHEMENO,@DebitAcc,@ReceiptNo,@Yonze,@PayMonth,@PayYear,@Particulars,                                                                                    
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                      
                                                                    
      Exec PostReceiptToCashBook @SCHEMENO,@BankCode,@ReceiptNo,@PayMonth,@PayYear,@Particulars,@Yonze,@TransCode,@ChequeNo,                                                                                      
                  @PayDate,@CashTransNo,@CurrCode,@CurrRate                                   
                                    
      if @OffSetUnAlloc = 1                                    
        begin                                    
           Exec Proc_Adjust_UnAllocated @schemeNo,@PayDate,@BankCode,@Yonze                                    
        end                                          
                                        
      end                                                                  
end                                         
else if ((@RentBalance >= 0)  and (@RentBalance < @Amount ))                                     
  begin                                                   
     select @Debit = @Amount - @RentBalance                                                  
                                                  
     --Credit Debtors                                          
     if len(@CreditAcc) = 0                                   select @Sawa = 0                                 
                                        
     if len(@RentPreAcc) = 0                                        
         select @Sawa = 0                                        
                                        
     if len(@DebitAcc) = 0                                        
         select @Sawa = 0                                        
                                        
     if @Sawa = 1                                        
         begin                                         
                                                      
     Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@RentBalance,@PayMonth,@PayYear,@Particulars,                                                                                
                               @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                             
                                                                    
     --Credit Prepayments                                                
     Exec PostLedgerCreditsRec @SCHEMENO,@RentPreAcc,@ReceiptNo,@Debit,@PayMonth,@PayYear,@Particulars,                                                                                            
            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
                                                      
                                                      
     if @Legal > 0                                                      
          begin                             
           Exec PostLedgerCreditsRec @SCHEMENO,@LegalFeesAcc,@ReceiptNo,@Legal,@PayMonth,@PayYear,@Particulars,                                                   
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
           end                                                   
                                                            
      if @Deposit > 0                                                      
         begin                                                      
           Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@Deposit,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                           
         end                                                   
                                                  
     if @Penalty > 0                                                      
         begin                                                
           Exec PostLedgerCreditsRec @SCHEMENO,@PenaltyAcc,@ReceiptNo,@Penalty,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
         end                                                       
                                                        
      if @Legal is null select @Legal = 0                                                  
      if @Deposit is null select @Deposit = 0                                           
      if @Penalty is null select @Penalty = 0                                                  
              
      select @Yonze = @Legal + @Deposit + @Amount + @Penalty                                                      
                                                                                     
      Exec PostLedgerDebitsRec @SCHEMENO,@DebitAcc,@ReceiptNo,@Yonze,@PayMonth,@PayYear,@Particulars,                                                                                       
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                  
                                              
      Exec PostReceiptToCashBook @SCHEMENO,@BankCode,@ReceiptNo,@PayMonth,@PayYear,@Particulars,@Yonze,@TransCode,@ChequeNo,                                                                                      
                  @PayDate,@CashTransNo,@CurrCode,@CurrRate                                    
                                    
      if @OffSetUnAlloc = 1                                    
        begin                                    
           Exec Proc_Adjust_UnAllocated @schemeNo,@PayDate,@BankCode,@Yonze                                    
        end                                           
     end                                                 
                                                                              
  end                    
else if ((@RentBalance >= 0) and (@RentBalance >= @Amount))                                                  
  begin                                                  
     --Credit Debtors                                          
                                          
     if len(@CreditAcc) = 0                                        
         select @Sawa = 0                                        
                                        
     if len(@DebitAcc) = 0                                        
         select @Sawa = 0                                        
                                        
                                             
     if @Sawa = 1                                        
        begin                                                                        
     Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@Amount,@PayMonth,@PayYear,@Particulars,                                                                                            
                               @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                     
     if @Legal > 0                                                      
          begin                                 
           Exec PostLedgerCreditsRec @SCHEMENO,@LegalFeesAcc,@ReceiptNo,@Legal,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
         end                                                        
                                                            
      if @Deposit > 0                                                      
         begin                                                      
           Exec PostLedgerCreditsRec @SCHEMENO,@CreditAcc,@ReceiptNo,@Deposit,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                 
         end                                                   
                                                  
     if @Penalty > 0                                                      
         begin                                                      
           Exec PostLedgerCreditsRec @SCHEMENO,@PenaltyAcc,@ReceiptNo,@Penalty,@PayMonth,@PayYear,@Particulars,                                                                                            
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                          
         end                                                       
                                                        
      if @Legal is null select @Legal = 0                                                  
      if @Deposit is null select @Deposit = 0                                      
      if @Penalty is null select @Penalty = 0                 
                                                   
      select @Yonze = @Legal + @Deposit + @Amount + @Penalty                                                     
                                                          
     Exec PostLedgerDebitsRec @SCHEMENO,@DebitAcc,@ReceiptNo,@Yonze,@PayMonth,@PayYear,@Particulars,                      
                            @PayDate,@CashTransNo,0,@Chequeno,@ReceiptNo,1,0,@CurrCode,@CurrRate,@BatchNo,0,@TransType,1                                                                                                
                                                                              
     Exec PostReceiptToCashBook @SCHEMENO,@BankCode,@ReceiptNo,@PayMonth,@PayYear,@Particulars,@Yonze,@TransCode,@ChequeNo,                                                                                      
                  @PayDate,@CashTransNo,@CurrCode,@CurrRate                                     
                                    
     if @OffSetUnAlloc = 1                                    
        begin                                    
           Exec Proc_Adjust_UnAllocated @schemeNo,@PayDate,@BankCode,@Yonze                                    
        end                                                       
     end                                                                                         
    end                     
 end                                                                                            
end                                                          
                                           
  if @Sawa = 1                                        
     begin   
       if @SingleMultiple = 0   
          begin                                                                                                                          
     UPDATE RENTRECEIPTS SET POSTED = 3                                                          
     WHERE SCHEMENO = @SCHEMENO AND PROPERTYCODE = @PropCode AND RECEIPTNO = @ReceiptNo  
     and PayDate = @PayDate   
                                                             
                                                      
           UPDATE RENTBALANCE SET POSTED = 1                                                           
           WHERE SCHEMENO = @SCHEMENO AND PROPERTYCODE = @PropCode AND RECEIPTNO = @ReceiptNo  
  
         end   
      else  
         begin  
           UPDATE RENTRECEIPTS SET POSTED = 3                                                          
     WHERE SCHEMENO = @SCHEMENO AND RECEIPTNO = @ReceiptNo  
     and PayDate = @PayDate  
                                                             
                                      
           UPDATE RENTBALANCE SET POSTED = 1                                                           
           WHERE SCHEMENO = @SCHEMENO AND RECEIPTNO = @ReceiptNo  
  
         end                                      
     end                                  
                                
 end
go

