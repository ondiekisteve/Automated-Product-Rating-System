CREATE PROCEDURE [dbo].[ShowPensionArrears]
@SCHEMENO Int,
@PayMonth int,
@PayYear int
--with Encryption
as


Select p.*,case p.Paytype
           when 1 then 'Credit to Bank Account'
           when 2 then 'Financial Institutions'
           end as PaymentMethod,
       M.MonthName +', '+cast(@PayYear as varchar(4)) as MonthName,
       s.SchemeName
from 
PensionArrears p
    inner join MonthTable m on m.MonthNumber = @PayMonth
    inner join Scheme s on p.SchemeNo = s.schemeCode
where p.SchemeNo = @schemeNo and p.PayMonth = @PayMonth and p.PayYear = @PayYear
go

