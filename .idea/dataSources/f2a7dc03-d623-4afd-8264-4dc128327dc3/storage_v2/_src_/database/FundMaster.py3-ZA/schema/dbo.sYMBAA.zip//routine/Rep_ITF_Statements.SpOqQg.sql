/* Last Modified on 27/4/2005 AT AFFS*/              
              
---tested and Verified  --- Last Modified 09 December 2004              
              
CREATE PROCEDURE [dbo].[Rep_ITF_Statements]      
@SchemeNo Int,      
@Proc_Date Datetime,      
@SponsorCode Int,    
@RangeStart Int,    
@RangeEnd Int     
--with Encryption              
as                      
set nocount on              
              
if object_id('tempdb..#AVGBenefits') is null              
              
begin              
create table #AVGBenefits              
(              
        [glcode] [int] IDENTITY(1,1) PRIMARY KEY,              
        [SchemeNo]  INT NOT NULL ,              
        [schemeName][varchar](100) not null,              
        [MemberNo] [int] NOT NULL ,              
        [fullname][varchar](100) not null,              
        [dje][datetime] null,              
        [djpens][datetime] null,              
        [ContrMonth][varchar](15) not null,              
        [ContrYear][Int]not null,              
        [Salary][float] null,              
        [EmpCont] [float]  NULL ,              
        [EmprCont] [float]  NULL ,               
        [midBalance] [float]  NULL,              
        [MonInTerest][float] null,               
        [interest][float]null,              
        [EmpInterest][float]null,              
        [EmprInterest][float]null,              
        [InterestRate][float]null,              
        [GrandTotal][float] null,              
        [GrandEmpr][float] null,              
        [GrandEmp][float] null,                 
        [EmpOpening][float] null,              
        [EmprOpening][float] null,              
        [Currency][Varchar](50),              
        [Expenses][float],              
        [ClosingBalance][float],              
        [ClosingEmp][float],              
        [ClosingEmpr][float],              
        [EmpArrears][float],              
        [EmprArrears][float],              
        [DoCalc][Datetime],              
        [DoBirth][Datetime],              
        [EndDate][Datetime],              
        [RetirementAge][Int],              
        [CurrentAge][Int],              
        [NormalRetDate][Datetime],              
        [SAdmin][Varchar](100),              
        [AdminAddress] [Varchar](100),              
        [AdminTown] [Varchar](100),              
        [AdminDivision] [Varchar](100),              
        [Telephone][Varchar](150),              
        [EMail][Varchar](50),              
        [AdminFees][float],              
        [NetClosingBalance][float],              
        [StartDate][Datetime],              
        [CalcAdminFees][Int],              
        [OpeningBal][float],      
        [OpeningBalR][float],              
        [PayrollNo][varchar](30),              
        [SponsorName][Varchar](100),      
        [TotalBalance][float]                   
)                               
end              
              
              
if object_id('tempdb..#Balances') is null              
              
begin              
create table #Balances              
(              
        [EmpCode][Int] Identity(1,1) PRIMARY KEY,              
        [DatePaid] [Datetime] not null,               
        [EmpCont] [float] not  NULL default 0.0,              
        [EmprCont] [Float] null default 0.0,              
        [EmprVolCont][float] not null default 0.0,              
        [EmpVolCont][float] not null default 0.0,                
        [InterestRate][float] null             
)                          
end              
              
Declare @AcctPeriod int,@PeriodtoUse int, @eDate datetime, @sDate datetime, @TopDate datetime, @Loops int,               
@FiscalType Int,@startMonth int,@empCont float,@emprCont float,@specialContr float,@volContr float,              
@CempCont float,@CemprCont float,@CspecialContr float,@CvolContr float, @monthPower float,@currMonth int,              
@currInterest float,@oneHundred float,@curdate varchar(25), @MidDate datetime,              
@TempEmp float,@TempEmpr float, @TempVol float, @TempSpecial float, @TempEmp1 float,              
@TempEmpr1 float, @TempVol1 float, @TempSpecial1 float,@xMonth int,@xYear int,@RunBalance float,              
@AnnualAvg float,@DoCalc Datetime,@Reason int,@TotInt float,@UseBalances bit,@totEmpCont float,              
@totEmprCont float,@totVolContr float,@totSpecialContr float,@dob datetime,@dje datetime,@djpens datetime,@DoExit Datetime,              
@EmpInt float,@EmprInt float,@VolInt float,@SpecInt float,@NextDate Datetime,@CurMonth int,@CurrYear int,              
@YearsWorked int,@Vesting float,@ContrMonth varchar(15),@StartYear int,@TaxRelief float,@Salary float,@MidBalance float,              
@TaxableAmount float,@Tax float,@TotalPayable float,@ReasonforExit varchar(40),@SchemeName varchar(100),@FullName varchar(60),              
@Comments varchar(60),@vestedCont float,@MaxDate Datetime,@CheckMode bit,              
@ArEmpCont float,@ArEmprCont float,@ArVolCont float,@ArSpecial float,@ArDate Datetime,              
@trEmpCont float,@trEmprCont float,@trDate Datetime,@InTerest float,@NewPower float,              
@EmpOpening float,@EmprOpening float,@Taxtype Int,@FiscalMode smallInt,              
@sumEmp float,@sumEmpr float, @sumVol float,@sumSpec float, @ChekiInt float,@CurrCode varchar(3),@Currency varchar(50),              
@SMonthDate Datetime,@EMonthDate Datetime,@fMonth Int,@fYear Int,@FirstDate Datetime,@OptionToUse Int,              
@NumYearsIn Int,@NumMonthsIn Int,@NumDaysIn Int,@Month Int,@Year Int,@InterestRate float,              
@LastMonthDate Datetime,@StartMonthDate Datetime,@EmpFeesPre float,@EmprFeesPre float,              
@EmpFeesPost float,@EmprFeesPost float,@IntMode Int,@MemberNo Int,@EndDate datetime,@RetirementAge Int,              
@CurrentAge Int,@NormalRetDate Datetime,@NumDays Int,@NumMonths Int,@DoBirth Datetime,              
@Admin Varchar(100),@AdminAddress Varchar(100),@AdminTown Varchar(100),@AdminDivision Varchar(100),              
@Email Varchar(50),@Telephone Varchar(100),@AdminFees float,              
@AdminEmp float,@AdminEmpr Float,@AdminVol float,              
@AdminSpec float,@EmpArrears float,@EmprArrears float,@FeesReg float,@FeesUnReg float,              
@ActiveStatus Int,@DateKutoka Datetime,@DistrEmp float,@DistrEmpr float,@DistrAVC float,@DistrSpec float /* Reserve Distribution */,              
@CalcAdminFees Int,@YaMwisho Datetime,@ShowAdmin smallInt,@OpeningBal float,@PayrollNo varchar(30),@FundType varchar(2),              
@SponsorName varchar(100),@sex varchar(2),@MemberClass varchar(3),@CompanyId int ,@StatusCode Int,            
@DateClosed Datetime,@Comp_si Int,@YearEnd Int,@CalcYear Int,@CalcMonth Int,      
@Income_Id int,@totempTransfer float, @totEmprTransfer float,@cempTransfer float, @cEmprTransfer float,      
@OpeningBalR float,@DesignCode int,@Title varchar(15)

      
      
select @CalcMonth = DatePart(Month,@Proc_Date),@CalcYear = DatePart(Year,@Proc_Date),
@EmpFeesPre = 0,@EmprFeesPre = 0      
      
select @Income_Id = Max(Income_Id) from tbl_itf_income where schemeNo = @schemeNo and TransDate <= @Proc_Date      
AND SPONSORCODE = @SPONSORCODE            
      
select @FundType = FundType,@StatusCode = StatusCode,@DateClosed = DateClosed,            
@schemeName = schemeName,@CurrCode = Currency  from scheme where SchemeCode = @schemeNo              
            
if @StatusCode is null select @StatusCode = 0            
              
/* For Britak Prior to 2004 use 1/12 other than root 12 */              
IF @CalcYear <= 2004              
   SELECT @Comp_Si = 1              
              
select @CalcAdminFees = Calc_Admin_Fees from ConfigYearEnd where schemeNo = @schemeNo              
              
if @CalcAdminFees is null select @CalcAdminFees = 0              
              
select @Admin = ConsultantName,@AdminAddress = Address,@AdminTown = Town,@AdminDivision = AdminDivision,              
@Telephone = Phone,@Email = Email              
from Scheme_Consultants where SchemeNo = @SchemeNo and ConsultantType = 'Administrator'              
              
if @Telephone is null select @Telephone = '  '              
if @Email is null select @Email = '  '              
              
if len(ltrim(rtrim(@Email))) = 0               
   Select @Telephone = 'Tel  : '+@Telephone               
else              
  Select @Telephone = 'Tel  : '+@Telephone  + ',    E mail : '+@Email              
              
if @AdminDivision is null select @AdminDivision = 'Benefit Administration Services'              
              
select @IntMode = @YearEnd              
              
select @sumEmp = 0,@sumEmpr = 0, @sumVol = 0,@sumSpec = 0,@ChekiInt = 0              
                
select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @CurrCode              
            
if @StatusCode = 3            
   begin            
     if @CalcYear > DatePart(Year,@DateClosed)            
        begin            
            select @IntMode = 0            
        end            
else if @CalcYear = DatePart(Year,@DateClosed) and @CalcMonth >= DatePart(Month,@DateClosed)              
        begin          
            select @IntMode = 0             
        end            
   end            
             
Exec GetLastDate @CalcMonth,@CalcYear,@EndDate Out    
              
if @sponsorCode > 0      
declare CertCsr cursor for               
select distinct b.memberNo,m.sex,m.MemberClass,m.CompanyId,m.dob,M.ActiveStatus,M.DoCalc,m.PayrollNo,m.SponsorCode,  
m.DesignCode              
from Members m       
     inner join TBL_ITF_Distribution b on m.SchemeNo = b.schemeNo and m.memberNo = b.memberNo       
     and b.Income_Id <= @Income_Id                                
where m.SchemeNo = @schemeNo and m.memberno = b.MemberNo and               
((m.ReasonForExit = 0)  or ((m.ReasonforExit > 0) and (m.DoCalc > @Proc_Date))) and m.SponsorCode = @sponsorCode    
and m.MemberNo >= @RangeStart and m.MemberNo <= @RangeEnd    
else    
declare CertCsr cursor for               
select distinct b.memberNo,m.sex,m.MemberClass,m.CompanyId,m.dob,M.ActiveStatus,M.DoCalc,m.PayrollNo,m.SponsorCode,  
m.DesignCode            
from Members m       
     inner join TBL_ITF_Distribution b on m.SchemeNo = b.schemeNo and m.memberNo = b.memberNo       
     and b.Income_Id <= @Income_Id                                
where m.SchemeNo = @schemeNo and m.memberno = b.MemberNo and               
((m.ReasonForExit = 0)  or ((m.ReasonforExit > 0) and (m.DoCalc > @Proc_Date)))    
and m.MemberNo >= @RangeStart and m.MemberNo <= @RangeEnd    
              
              
order by b.memberNo              
              
Open CertCsr              
              
fetch from CertCsr Into @MemberNo,@sex,@MemberClass,@CompanyId,@DoBirth,@ActiveStatus,@DateKutoka,@PayrollNo,@SponsorCode,  
@DesignCode              
              
while @@fetch_Status = 0              
begin              
      
            
if @Sex is null select @sex = 'M'              
IF @MemberClass is null select @MemberClass = 'N/A'              
if @CompanyId is null select @CompanyId = 1              
              
if @Sex = 'M'              
   Select @NormalRetDate = DateAdd(Year,MRetAge,@DoBirth) from RetirementAges where schemeNo = @schemeNo              
   and ClassId = @MemberClass and CompanyId = @CompanyId              
else if @Sex = 'F'              
   Select @NormalRetDate = DateAdd(Year,fRetAge,@DoBirth) from RetirementAges where schemeNo = @schemeNo              
   and ClassId = @MemberClass and CompanyId = @CompanyId              
  if @SponsorCode > 0              
   select @SponsorName = SponsorName from Sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode              
else              
   select @SponsorName = '' 

if @ActiveStatus is null select @ActiveStatus = 1              
              
if ((@DateKutoka > @EndDate) and (@ActiveStatus = 6))              
   select @ActiveStatus = 1              
              
if @ActiveStatus <> 6              
   select @AdminFees = EmpFees + EmprFees + VolFees + SpecialFees from FeesDistribution where schemeNo = @schemeNo and MemberNo = @MemberNo              
   and FeesCode = 3 and PaymentDate = @EndDate              
else if @ActiveStatus = 6              
   select @AdminFees = EmprFees + SpecialFees from FeesDistribution where schemeNo = @schemeNo and MemberNo = @MemberNo              
   and FeesCode = 3 and PaymentDate = @EndDate              
      
             
if @AdminFees is null select @AdminFees = 0              
              
Exec GetServiceTime @DoBirth,@NormalRetDate,@RetirementAge Out,@NumMonths Out,@NumDays Out              
Exec GetServiceTime @DoBirth,@EndDate,@CurrentAge Out,@NumMonths Out,@NumDays Out              
              
Select @Reason = ReasonforExit,@DoCalc = DoCalc,@dob =dob,@dje= dje,@djpens = djpens,@DoExit = DoExit,              
@FullName = Upper(SName)+', '+upper(fName)+' '+upper(oNames) from Members              
where SchemeNo = @schemeNo and MemberNo = @MemberNo  

  
  
if @DesignCode > 0                        
   begin                        
       select @Title = Designation from Designation where DesignCode = @DesignCode                        
                        
        select @FullName = upper(@Title) +'  '+@FullName                        
  end             
              
Select @CurMonth = @CalcMonth              
Select @CurrYear = @CalcYear 
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @currYear, @AcctPeriod out 
              
Select @sDate = StartDate,@YaMwisho = EndDate, @FiscalMode = FiscalMode               
from SchemeYears where SchemeNo = @schemeNo  and AcctPeriod = @AcctPeriod              
              
Select @FiscalType = 0/* Fiscal Year Starting in January 1st*/              
                
exec getLastDate @CurMonth,@CurrYear,@eDate out              
              
if @YaMwisho = @eDate              
   select @ShowAdmin = 1              
else              
   select @ShowAdmin = 0              
              
Select @PeriodToUse = @AcctPeriod - 1              
              
select @EMonthDate = @eDate               
              
if exists(select * from MemberOpeningBalances where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @PeriodToUse)              
begin              
   Select @UseBalances = 1              
end              
              
Select @UseBalances = 1              
              
if @useBalances = 1              
   begin              
     Select @SMonthDate = @sDate              
   end              
else              
   begin              
     Select @sDate = Min(DatePaid) from Contributionssummary              
     where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
              
     select @fMonth = DatePart(Month,@sDate),@fYear = DatePart(Year,@sDate)              
              
     Exec GetFirstDate @fMonth,@fYear,@FirstDate Out              
              
     Select @SMonthDate = @FirstDate              
   end 

/* Initialize all variables to Zero */              
Select @CempCont  = 0              
Select @CemprCont = 0              
Select @CspecialContr = 0              
Select @CvolContr = 0         
Select @CEmpTransfer = 0,@CEmprTransfer = 0           
Select @CvolContr = 0             
Select @TempEmp  = 0              
Select @TempEmpr = 0              
Select @TempSpecial= 0              
Select @TempVol = 0              

select @TempEmp1 = 0              
select @TempEmpr1 = 0              
select @TempVol1 = 0               
select @TempSpecial1 = 0              
Select @RunBalance = 0              
Select @CheckMode = 0              
              
if @useBalances = 1              
   begin              
           
         select @totEmpCont = EmpCont + Transfer, @totEmprCont = EmprCont + LockedIn,              
         @totVolContr = EmpVolCont,               
         @totSpecialContr = EmprVolCont,        
         @AdminEmp = EmpFees,@AdminEmpr = EmprFees,              
         @AdminVol = VolFees,@AdminSpec = SpecFees              
         from MemberOpeningBalances              
         where SchemeNo = @schemeNo               
         and memberNo = @memberNo              
         and AcctPeriod = @PeriodToUse 

         select @DistrEmp = sum(o.EmpCont), @DistrEmpr = sum(o.EmprCont), @DistrAVC = sum(o.AVC),@DistrSpec = sum(o.AVCER)                                        
         from memb_reservefund_distr o                                        
         Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo
         where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse              
                  
         IF @DistrEmp is null select @DistrEmp = 0              
         IF @DistrEmpr is null select @DistrEmpr = 0              
         IF @DistrAVC is null select @DistrAVC = 0              
         IF @DistrSpec is null select @DistrSpec = 0              
   end              
else              
  select @totEmpCont = 0, @totEmprCont = 0,              
  @totVolContr = 0, @totSpecialContr = 0,@totEmpTransfer = 0, @totEmprTransfer = 0              
              
  if @totEmpCont is null select @totEmpCont = 0              
  if @totEmprCont is null select @totEmprCont = 0              
  if @totVolContr is null select @totVolContr = 0              
  if @totSpecialContr is null select @totSpecialContr = 0         
  if @totEmpTransfer is null select @totEmpTransfer = 0              
  if @totEmprTransfer is null select @totEmprTransfer = 0            
              
  if @AdminEmp is null  select @AdminEmp = 0.0              
  if @AdminEmpr is null  select @AdminEmpr = 0.0              
  if @AdminVol is null  select @AdminVol = 0.0              
  if @AdminSpec is null  select @AdminSpec = 0.0              
              
  IF @DistrEmp is null select @DistrEmp = 0              
   IF @DistrEmpr is null select @DistrEmpr = 0              
   IF @DistrAVC is null select @DistrAVC = 0              
   IF @DistrSpec is null select @DistrSpec = 0              
              
  select @totEmpCont = (@totEmpCont + @DistrEmp)- @AdminEmp,              
  @totEmprCont = ( @totEmprCont + @DistrEmpR )- @AdminEmpr,              
  @totVolContr = (@totVolContr + @DistrAVC) - @AdminVol,              
  @totSpecialContr = (@totSpecialContr + @DistrSpec) - @AdminSpec              
              
select @EmpOpening = @totEmpCont + @totVolContr,              
@EmprOpening = @totEmprCont + @totSpecialContr        
         
select @OpeningBal = @EmpOpening, @OpeningBalR = @EmprOpening 

     
      
  /*Initialize the Opening Balances */              
  select @cEmpCont = @totEmpCont              
  select @cEmprCont = @totEmprCont              
  select @cSpecialContr = @totSpecialContr              
  select @cVolContr = @totVolContr        
  select @cEmpTransfer = @totEmpTransfer              
  select @cEmprTransfer = @totEmprTransfer              
              
select @sumEmp = @totEmpCont, @sumEmpr = @totEmprCont,@sumVol = @totVolContr,@sumSpec = @totSpecialContr              
      
select @monthPower = 1.0000000000/12.0000000000000              
select @oneHundred = 100.0000000000              
              
/* Contributions */       
   Insert Into #Balances select Distinct(c.DatePaid), sum(c.EmpCont) , sum(c.EmprCont) , sum(c.SpecialContr)              
                              , sum(VolContr), 0.0              
   from ContributionsSummary c                   
   WHERE  c.SchemeNo = @SchemeNo and c.MemberNo = @MemberNo               
   and c.DatePaid >= @sDate  and c.DatePaid <= @eDate and c.AcctPeriod = @acctPeriod              
   Group by c.DatePaid              
   order by c.DatePaid                 
            
              
/* add Any Contribution Arrears */              
     Insert into #Balances Select distinct(c.DatePaid),sum(c.ArEmpCont),Sum(c.ArEmprCont),sum(c.ArSpecial),sum(c.ArVolContr),              
     0.0              
     from ContributionArrears c                    
     where c.SchemeNo = @SchemeNo and c.MemberNo = @MemberNo              
     and c.DatePaid >= @sDate  and c.DatePaid <= @eDate and c.AcctPeriod = @acctPeriod              
     Group by c.DatePaid              
     order by c.DatePaid                     
           
/*End of Contributions Arrears */              
              
/* add Any Transfers*/              
              
     Insert into #Balances Select distinct(c.TransferDate),sum(c.EmpTransfer),Sum(c.EmprTransfer),sum(c.avcerTransfer),Sum(c.AVCTransfer),              
     0.0               
     from MemberTransfer c              
                  
     where c.SchemeNo = @SchemeNo and c.MemberNo = @MemberNo              
     and c.TransferDate >= @sDate  and c.TransferDate <= @eDate and c.AcctPeriod = @acctPeriod              
     Group by c.TransferDate             
     order by c.TransferDate                     
/* for a Member without  Contributions */              
              
   declare @MwanzoDate datetime,@MwishoDate datetime              
   select @MwanzoDate = @sDate,@MwishoDate = @eDate              
   while @Mwanzodate<= @MwishoDate              
   begin              
        Select @xMonth = DatePart(Month,@MwanzoDate)              
        Select @xYear = DatePart(Year,@MwanzoDate)                            
        Exec GetLastDate @xMonth,@xYear,@LastMonthDate Out              
                      
        if Not Exists (Select * from #Balances where DatePaid >= @MwanzoDate and DatePaid <= @LastMonthDate)              
           begin              
             
               Insert Into #Balances               
               select @MwanzoDate, 0,0,0,0,ProvRate              
               from  InTerestRates where SchemeNo = @SchemeNo and              
               DatePart(Year,@Mwanzodate) = IntrYear                   
           end              
        select @MwanzoDate = DateAdd(Month,1,@MwanzoDate)              
   end              
              
              
if @FiscalType = 0 /* Fiscal Year Starting in January */              
   begin              
        while @SMonthDate <= @EMonthDate              
        begin              
                Select @ContrMonth = MonthName from MonthTable where MonthNumber = DatePart(Month,@SMonthDate)              
              
                      
      
               /* Pick all the Contributions in a given Month */              
                        Select @xMonth = DatePart(Month,@SMonthDate)              
                        Select @xYear = DatePart(Year,@SMonthDate)              
              
                        Exec GetFirstDate @xMonth,@xYear,@StartMonthDate Out              
                        Exec GetLastDate @xMonth,@xYear,@LastMonthDate Out       
      
                        select @Income_Id = Max(Income_Id) from tbl_itf_income where schemeNo = @schemeNo        
                        and TransDate >= @StartMonthDate and TransDate <= @LastMonthDate      
                        AND SPONSORCODE = @SPONSORCODE              
             

              
                        /* Contributions for the Month */              
                  select @empCont = sum(EmpCont), @emprCont = sum(EmprCont), @specialContr = sum(EmprVolCont),               
                               @volContr = sum(EmpVolCont)              
                  from #Balances               
                  where DatePaid  >= @StartMonthDate and DatePaid <= @LastMonthDate              
              
                       
                                           
                        if @empCont is null select @empCont = 0              
                        if @emprCont is null select @emprCont = 0              
                        if @specialContr is null select @specialContr = 0              
                        if @volContr is null select @volContr = 0              
              
                        select @cEmpCont = (@cEmpCont + @empCont) - @EmpFeesPre              
                        select @cEmprCont = (@cEmprCont + @emprCont)- @EmprFeesPre              
                        select @cSpecialContr = (@cSpecialContr + @specialContr)              
                        select @cVolContr = (@cVolContr + @volContr)

                        Select @ContrMonth = MonthName from MonthTable where MonthNumber = DatePart(Month,@SMonthDate)              
              
                        Select @Salary = Salary from Contributionssummary              
                        where SchemeNo = @schemeNo and MemberNo = @MemberNo and               
                        ContrMonth = DatePart(Month,@SMonthDate) and ContrYear = DatePart(Year,@SMonthDate)              
              
                        if @salary is null select @Salary = 0              
               
                              
                              
                                    
                        Select @EmpInt = sum(EmpInt + eeTransferInt),@EmprInt = sum(EmprInt + ErTransferInt),      
                        @VolInt = sum(AVCInt),@SpecInt = sum(AVCERInt)      
                        from TBL_Itf_Distribution      
                        where schemeNo = @schemeNo and MemberNo = @MemberNo      
                        and Income_Id = @Income_Id      
      
                        if @EmpInt is null select @EmpInt = 0      
                        if @EmprInt is null select @EmprInt = 0      
                        if @VolInt is null select @VolInt = 0      
                        if @SpecInt is null select @SpecInt = 0      
                                     
                                
                        insert into #AVGBenefits(SchemeNo,SchemeName,Dje,DjPens,FullName,memberNo,               
                        ContrMonth, ContrYear,              
                        Salary, Empcont, Emprcont,              
                        MidBalance,MonInTerest,              
                        interestrate,              
                        EmpInTerest, EmprInTerest,ClosingBalance,Expenses,EndDate,              
                        RetirementAge,CurrentAge,NormalRetDate,DoBirth,SAdmin,AdminAddress,AdminTown,AdminDivision,Telephone,Email,              
                        EmpArrears,EmprArrears,ClosingEmp,ClosingEmpr,OpeningBal,OpeningBalr,TotalBalance)              
                        values(@schemeNo, @SchemeName, @dje,@djPens,@FullName,              
                        @memberNo, @contrMonth, DatePart(Year,@SMonthDate),              
                        @salary,(@Empcont + @volContr),(@emprCont + @specialContr),              
                        0,@EmpInt + @EmprInt + @VolInt + @SpecInt,               
                        0,              
                        @EmpInt + @VolInt, @EmprInt + @SpecInt,               
                       (@cEmpCont + @cEmprCont + @cVolContr + @cSpecialContr + @EmpInt + @EmprInt + @VolInt + @SpecInt),              
                        0,@EndDate,              
                        @RetirementAge,@CurrentAge,@NormalRetDate,@DoBirth,@Admin,@AdminAddress,@AdminTown,@AdminDivision,@Telephone,@Email,              
                        0,0,               
                        (@cEmpCont +  @cVolContr +  @EmpInt +  @VolInt ),              
                        (@cEmprCont + @cSpecialContr + @EmprInt + @SpecInt),@OpeningBal,@OpeningBalr,      
                        @cEmpCont +  @cVolContr +  @EmpInt +  @VolInt + @cEmprCont + @cSpecialContr + @EmprInt + @SpecInt)              
                
                        /* Add Contributions paid after 15 th Less Expenses paid after 15 th */              
                        select @cEmpCont = (@cEmpCont + @EmpInt)              
                        select @cEmprCont = (@cEmprCont + @EmprInt)              
                        select @cVolContr = @cVolContr + @VolInt              
                        select @cSpecialContr = @cSpecialContr + @SpecInt              
                        select @OpeningBal = @cEmpCont +  @cVolContr ,@OpeningBalR = @cEmprCont + @cSpecialContr              
              
                        select @EmpFeesPost = 0.0,@EmprFeesPost = 0.0,@TempEmp = 0,@TempEmpr=0.0,@TempVol=0.0,              
                        @TempSpecial = 0.0,@NewPower = 0.0,@EmpInt = 0.0,@EmprInt = 0.0,@VolInt = 0.0,@SpecInt = 0.0,              
                        @EmpFeesPre = 0.0,@EmprFeesPre = 0.0,@EmpArrears = 0,@EmprArrears = 0              
                                        
                        Select @Salary = 0              
                        Select @SMonthDate = DateAdd(Month,1,@SMonthDate)               
                end              
                              
       end              
             
   select @Interest = sum(MonInTerest) from #AVGBenefits where schemeNo = @SchemeNo and MemberNo = @MemberNo              
              
                 
              
   select @AdminFees = 0.0              
              
              
              
   update #AVGBenefits set interest  = @Interest,GrandEmp = @cEmpCont + @cVolContr,              
   GrandEmpr = @cEmprCont + @cSpecialContr,GrandTotal = @cEmpCont + @cVolContr + @cEmprCont + @cSpecialContr,              
   EmpOpening = @EmpOpening,EmprOpening = @EmprOpening,Currency = @Currency,AdminFees = @AdminFees,              
   NetClosingBalance = (@cEmpCont + @cVolContr + @cEmprCont + @cSpecialContr) - @AdminFees,              
   StartDate = @sDate,CalcAdminFees = @CalcAdminFees,PayrollNo = @PayrollNo,SponsorName = @SponsorName              
   where schemeNo = @SchemeNo and MemberNo = @MemberNo              
                
   Delete from #Balances              
                 
  select @Interest = 0,@cEmpCont =0, @cVolContr=0,@cEmprCont =0,@cSpecialContr=0,@EmpOpening=0,@EmprOpening=0,              
  @RetirementAge = 0,@CurrentAge = 0,@AdminFees = 0.0,@totEmpCont = 0, @totEmprCont = 0,              
  @totVolContr = 0, @totSpecialContr = 0,@AdminEmp = 0.0,              
  @AdminEmpr = 0.0,@AdminVol = 0.0,@AdminSpec = 0.0,@ActiveStatus = 0,@PayrollNo='',@SponsorCode=0,@SponsorName='',              
  @sex='',@MemberClass='N/A',@CompanyId =0,@MemberNo=0,@sex='',@MemberClass='',@CompanyId=0,@ActiveStatus=0,@PayrollNo=0,@SponsorCode=0,      
         @AdminFees = 0,@totEmpCont=0,@totVolContr=0, @totEmprCont=0,@totSpecialContr=0,@AdminEmp=0,       
         @AdminVol =0,@AdminEmpr=0,@AdminSpec=0, @DistrEmp =0,@DistrEmpr=0,@DistrAVC=0,@DistrSpec=0,            
         @EmpOpening =0,@EmprOpening=0,@OpeningBal=0,@cEmpCont=0,@cEmprCont=0,@cSpecialContr=0,@cVolContr=0,      
         @sumEmp =0,@sumEmpr=0,@sumVol=0,@sumSpec=0,@Income_Id =0,@OpeningBalR =0,@DesignCode = 0             
              
  Fetch next from CertCsr into @MemberNo,@sex,@MemberClass,@CompanyId,@DoBirth,@ActiveStatus,@DateKutoka,@PayrollNo,  
                               @SponsorCode,@DesignCode              
end              
Close CertCsr              
Deallocate CertCsr              
              
Select *  from #AVGBenefits WHERE (GrandEmpr + GrandEmp)> 0  order by SponsorName,MemberNo
go

