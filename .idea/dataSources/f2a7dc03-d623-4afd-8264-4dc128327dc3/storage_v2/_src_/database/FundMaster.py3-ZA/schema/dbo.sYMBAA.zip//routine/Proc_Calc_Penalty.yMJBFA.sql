CREATE PROCEDURE [dbo].[Proc_Calc_Penalty]  
@schemeNo int,  
@SponsorCode Int,  
@Proc_Date datetime,  
@Expected float out,  
@Received float out,  
@Penalty float out,  
@ClosingBal float out  
--with encryption  
as  
  
declare @StartDate datetime,@AcctPeriod Int,@CurMonth Int,@CurYear Int,@MidDate datetime,  
@NextMonth Int,@NextYear Int,@Yakwanza datetime,@Outstanding float,@OpenBal float,  
@PrevMonth Int,@PrevYear Int,@PrevDate datetime,@PenaltyRate float 
  
select @StartDate = StartDate,@AcctPeriod = AcctPeriod from schemeYears   
where schemeNo = @schemeNo and StartDate <= @Proc_Date and EndDate >= @Proc_Date  
  
select @CurMonth = datepart(Month,@Proc_Date),@CurYear = datepart(Year,@Proc_Date)  
  
Exec GetFirstDate @CurMonth,@CurYear, @Yakwanza out  

select @PenaltyRate = PenaltyRate from scheme where schemeCode = @schemeNo

if @PenaltyRate is null select @PenaltyRate = 3.0000
  
/* Get Prev Date */  
if @CurMonth = 1  
   select @PrevMonth = 12,@PrevYear = @CurYear - 1  
else  
   select @PrevMonth = @CurMonth - 1,@PrevYear = @CurYear  
  
Exec GetFirstDate @PrevMonth,@PrevYear,@PrevDate Out  
  
/* Get Next Date */  
if @CurMonth = 12  
   select @NextMonth = 1,@NextYear = @CurYear + 1  
else  
   select @NextMonth = @CurMonth + 1,@NextYear = @CurYear  
  
Exec GetMidMonthDate @NextMonth,@NextYear,@MidDate Out  
  
select @Expected = EmpCont + EmprCont from TBL_ExpectedBatches where schemeNo = @schemeNo    
and BatchDate = @Yakwanza and SponsorCode = @SponsorCode  
  
select @Received = sum(TotalEmp + TotalEmpr) from Batches where schemeNo = @schemeNo    
and BatchDate >= @StartDate and BatchDate <= @MidDate and SponsorCode = @SponsorCode   
  
if @StartDate = @Yakwanza  
   select @OpenBal = 0  
else  
   select @OpenBal = ClosingBal from TBL_Debt_Analysis where schemeNo = @schemeNo    
   and CheckDate = @PrevDate and SponsorCode = @SponsorCode  
  
if @OpenBal is null select @OpenBal = 0  
  
if @Received is null select @Received = 0  
if @Expected is null select @Expected = 0  
  
if (@Expected + @OpenBal) > @Received   
   select @Outstanding = (@OpenBal + @Expected) - @Received  
else  
   select @Outstanding = 0  
  
if @Outstanding > 0  
   select @Penalty = ((@Outstanding * (@PenaltyRate/100.000)) * (1.000/12.000))  
else  
   select @Penalty = 0  
  
select @ClosingBal = @Outstanding + @Penalty
go

