CREATE PROCEDURE [dbo].[DBUnregisteredContributions]
@SCHEMENO Int,
@CurMonth int,
@CurYear int,
@PayDate datetime
--with Encryption
as

declare @Members int, @EmpCont float, @EmprCont float, @MaxRegCont float, @MaxAnnCont float,
        @MonthName varchar(15), @AcctPeriod int

Exec GetMonthName @CurMonth, @MonthName out

select @EmpCont = sum(EmpCont + VolContr) from ContributionsSummary where
                  SchemeNo = @SchemeNo and ContrMonth = @CurMonth and ContrYear = @CurYear

if @EmpCont is null select @EmpCont = 0

Select @EmprCont = EmprCont from dbContribution where SchemeNo = @schemeNo and ContrMonth = @CurMonth and 
                   ContrYear = @CurYear

if @EmprCont is null select @EmprCont = 0

Select @EmprCont = @EmpCont + @EmprCont

Exec GetActiveMembers @SchemeNo,@Members out

Select @MaxAnnCont = MaxAnnCont from Scheme where schemeCode = @schemeNo

Select @MaxRegCont = (@Members * @MaxAnnCont)/12.0000000000


if @EmprCont > @MaxRegCont
   begin
      if Exists (select * from dbContributionUnregistered where SchemeNo = @SchemeNo and ContrMonth = @CurMonth and ContrYear = @CurYear)
         begin
             raiserror('An entry already exists for %s, %d',16,1,@MonthName, @CurYear)
             return
         end
      else
         begin
             exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out

             insert into dbContributionUnregistered (SchemeNo, ContrMonth, ContrYear,EmprCont, AcctPeriod, PayDate)
  Values    (@SchemeNo, @CurMonth, @CurYear, @EmprCont - @MaxRegCont, @AcctPeriod, @PayDate) 
             
             update dbContribution set EmprCont = EmprCont - (@EmprCont - @MaxRegCont) where SchemeNo = @SchemeNo and ContrMonth = @CurMonth and
  ContrYear = @CurYear
         end
   end
go

