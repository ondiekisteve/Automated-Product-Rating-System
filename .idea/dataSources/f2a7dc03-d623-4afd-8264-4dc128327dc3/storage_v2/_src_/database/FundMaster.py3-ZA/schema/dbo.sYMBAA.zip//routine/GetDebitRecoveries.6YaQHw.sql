CREATE PROCEDURE [dbo].[GetDebitRecoveries]
@SCHEMENO Int,
@PayMonth int,
@PayYear int,
@Deduct int
--with Encryption
as

if object_id('tempdb..#DebitRecoveries') is null

begin
create table #DebitRecoveries
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[DrDesc] [varchar](100) NOT NULL ,
	[Debit] [Decimal](12,2) not  NULL default 0.0,
        [Total] [Decimal](12,2) null default 0.0 
) 

ALTER TABLE #DebitRecoveries WITH NOCHECK ADD 

            
	CONSTRAINT [PK_DebitRecover] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end

declare @Desc varchar(50),@Debit decimal(20,2),@SDate datetime,@eDate datetime,@MonthName varchar(30),@YaConversion Varchar(25),@Chapaa decimal(20,2)


Exec GetFirstDate @PayMonth,@PayYear,@sDate out
Exec GetLastDate @PayMonth,@PayYear,@eDate out
Exec GetMonthName @PayMonth,@MonthName out

Select @MonthName = @MonthName+', '+cast(@PayYear as varchar(4))
   
     if @Deduct = 0
        begin
           select @Desc = 'Court Attachments for '+@MonthName
        end
     else
        begin
            Select @Desc = Deduction from Deductions where DeductCode = @Deduct

            select @Desc = @Desc +' for '+@MonthName
   	end
     
       
        select @Debit = sum(paye) from ##PayeMonthly 
        where Refund = 0

       select @YaConversion = cast(@Debit as Varchar(25))
                     Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
                     select @Debit = @Chapaa
                     select @Chapaa = 0

       insert into #DebitRecoveries (drDesc,Debit)
       Values(@Desc,@Debit)	
        

update #DebitRecoveries set total = @Debit
              
select *  from #DebitRecoveries
go

