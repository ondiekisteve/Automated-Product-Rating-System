CREATE PROCEDURE [dbo].[AnnualRentAnalysis_All]        
@SCHEMENO Int,        
@ProperCode Int,        
@startDate Datetime,    
@EndDate Datetime        
--with Encryption        
as        
        
if object_id('tempdb..#AnnualRentAnalysis_All') is null        
        
begin        
create table #AnnualRentAnalysis_All        
(        
        [SchemeName] [varchar](100) NOT NULL ,        
        [PropName] [varchar](80)not null,        
        [Period] [varchar](20) null,        
        [RentPayable][float] default 0.0,        
        [RentPaid][float] default 0.0,        
        [Balance][float] default 0.0,        
        [Expenditure][float] default 0.0,        
        [OpeningBalance][float] default 0.0,        
        [Net][float] default 0.0,    
        [startDate][datetime],    
        [EndDate][Datetime],  
        [DR][float] default 0.0 ,  
        [CR][float] default 0.0      
)         
        
ALTER TABLE #AnnualRentAnalysis_All WITH NOCHECK ADD          
                    
 CONSTRAINT [PK_AnnualRentAnalysis_All] PRIMARY KEY  NONCLUSTERED         
 (        
   [PropName]              
 )         
end        
        
declare @schemeName varchar(100),@PropName varchar(60),@RentPayable float,@PropCode int,        
@RentPaid float,@Expenditure float,@OpBalance float,@Period varchar(20),@MonthName varchar(30),        
@OpenBal float,@DR float,@CR float,@YaPrevious Datetime,@YaLast Datetime,@AcctPeriod Int    
    
select @AcctPeriod = AcctPeriod from schemeYears where schemeNo = @schemeNo and StartDate <= @StartDate    
and  EndDate >= @StartDate      
    
    
select @YaPrevious = EndDate from schemeYears where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod - 1    
    
select @schemeName = schemeName from scheme where schemeCode = @schemeNo        
        
        
declare Acsr cursor for        
Select Distinct(PropertyCode) from RentInvoice        
where SchemeNo = @schemeNo and InvoiceDate >= @StartDate and InvoiceDate <= @EndDate        
and PropertyCode = @ProperCode        
        
order by PropertyCode        
        
Open acsr        
        
fetch from Acsr into @PropCode        
        
while @@fetch_Status = 0        
begin        
       if Exists(select balanceDate from RentPreBalance where schemeNo = @schemeNo and     
          PropertyCode = @PropCode and AcctPeriod = @AcctPeriod)    
            select @Yalast = Max(BalanceDate) from RentPreBalance where schemeNo = @schemeNo and     
            PropertyCode = @PropCode and AcctPeriod = @AcctPeriod    
       else    
            begin    
                
            select @Yalast = @Yaprevious    
            end     
    
       Select @PropName = PropertyName from Property        
       where SchemeNo = @schemeNo and PropertyCode = @PropCode    
    
       select @OpenBal = SUM(Balance - PrePayment) from RentPreBalance where schemeNo = @schemeNo    
       and PropertyCode = @PropCode and BalanceDate = @YaLast    
       if @OpenBal is null select @OpenBal = 0        
        
       Select @RentPayable = sum(RentInvoiced + vatInvoiced + WithInvoiced)        
       from RentInvoice where SchemeNo = @schemeNo and         
       PropertyCode = @PropCode and InvoiceDate > @YaLast and InvoiceDate <= @EndDate    
    
       if @RentPayable is null select @RentPayable = 0     
    
       Select @RentPaid = sum(amount) from RentReceipts where SchemeNo = @schemeNo and         
              PropertyCode = @PropCode and ((PayDate > @YaLast) and (PayDate <= @EndDate))    
    
       if @RentPaid is null select @RentPaid = 0         
        
       Select @Expenditure = sum(Expense) from EstateExpenditure where        
              SchemeNo = @schemeNo and PropertyCode = @PropCode         
              and ((ExpenseDate > @YaLast) and (ExpenseDate <= @EndDate))        
                
                      
        
       if @RentPayable is null select @RentPayable = 0        
       if @RentPaid is null select @RentPaid = 0        
       if @Expenditure is null select @Expenditure = 0        
       if @OpenBal is null select @OpenBal = 0         
        
        select @DR=sum(Amount) from TBL_Debit_Credit_Notes  
        where sourcecode=@PropCode and drcr=0 and ((Transdate > @startdate) and (Transdate <= @EndDate))   
          
        select @CR=sum(Amount) from TBL_Debit_Credit_Notes  
        where sourcecode=@PropCode and drcr=1 and ((Transdate > @startdate) and (Transdate <= @EndDate))   
        if @dr is null select @dr=0  
        if @cr is null select @cr=0  
       
       Insert Into #AnnualRentAnalysis_All (SchemeName,PropName,StartDate,EndDate,RentPayable,    
                        RentPaid,Expenditure,Net,Balance,OpeningBalance,DR,CR)        
                        Values(@SchemeName,@PropName,@StartDate,@EndDate,@RentPayable,@RentPaid,@Expenditure,        
                               (@OpenBal + @RentPayable-@DR+@CR) - @Expenditure,(@RentPayable + @OpenBal) - @RentPaid-@DR+@CR,@OpenBal,@dr,@cr)        
               
       select @RentPayable = 0        
       select @RentPaid = 0        
       select @Expenditure = 0        
       select @OpenBal = 0        
       fetch next from Acsr into @PropCode        
end          
Close Acsr        
Deallocate Acsr        
        
Select * from #AnnualRentAnalysis_All
go

