CREATE PROCEDURE [dbo].[AttachBeneficiaryHistory]
@SCHEMENO Int,
@MemberNo int,
@AttachNo int,
@AttacheeNo int
--with Encryption
as

select c.SchemeNo, c.MemberNo, c.AttachNo, c.AttacheeNo, c.Attachment,
       c.PayYear, c.PayMonth, m.MonthName
from AttachmentPayroll c
     inner Join MonthTable m on c.PayMonth = m.MonthNumber
where c.SchemeNo = @schemeNo and c.MemberNo = @MemberNo and c.AttachNo = @AttachNo and
      c.AttacheeNo = @AttacheeNo
go

