CREATE PROCEDURE [dbo].[PensionPaymentHistory]  
@SCHEMENO Int,  
@memberNo int,
@DepCode Int,
@TransType Int,
@StartDate datetime  
--with Encryption  
as  

if @TransType = 0  
   select s.SchemeName, p.schemeNo, p.penNo as MemberNo, p.payMonth, p.payYear, 
   p.gross, p.tax, p.net, (upper(mm.sname) +' ,'+mm.fname +'  '+mm.onames) as fullname,  m.monthname  
   from pensionpayroll p  
   inner join Members mm on p.schemeNo = mm.schemeNo and p.memberNo = mm.memberNo  
   inner join MonthTable m on p.payMonth = m.monthNumber  
   inner Join Scheme s on p.SchemeNo = s.schemeCode  
   Where p.SchemeNo = @schemeNo and p.memberNo = @memberNo  
   order by p.payYear, p.payMonth
else if @TransType = 1
   select s.SchemeName, p.schemeNo, p.PenNo as memberNo,  
   p.payMonth, p.payYear, p.gross, p.tax, p.net,  
  (upper(mm.sname) +' ,'+mm.fname +'  '+mm.oname) as fullname,  m.monthname  
   from pensionpayrollBen p  
   inner join Dependants mm on p.schemeNo = mm.schemeNo and p.memberNo = mm.memberNo  
   and p.DependantCode = mm.DependantCode  
   inner join MonthTable m on p.payMonth = m.monthNumber  
   inner Join Scheme s on p.SchemeNo = s.schemeCode  
   Where p.SchemeNo = @schemeNo and p.memberNo = @memberNo and p.DependantCode = @DepCode  
   order by p.payYear, p.payMonth
go

