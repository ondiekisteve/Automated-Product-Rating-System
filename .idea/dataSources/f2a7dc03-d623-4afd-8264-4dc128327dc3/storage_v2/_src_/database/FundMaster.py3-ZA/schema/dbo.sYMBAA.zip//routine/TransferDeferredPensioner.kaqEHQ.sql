/*
Modifications : Calculation of Arrears on Monthly Pension
Added: Variables : @Period varchar(30),@Arrears float
                        /* New Code */
/*
Exec CalcPensionArrears @schemeNo,@MemberNo,@Period out,@Arrears out

update Pensioner set Arrears = @Arrears where SchemeNo = @schemeNo and MemberNo = @MemberNo
*/

*/

CREATE PROCEDURE [dbo].[TransferDeferredPensioner]
@SCHEMENO Int,
@memberNo int,
@GcomLum float,
@Tax float,
@AnnPension float,
@accrPen float
--with Encryption
as
declare @sName varchar(50), @PenNo varchar(50),@CheckNo varchar(15),@Reduced Bit,@Pcnt float,@Period varchar(30),@Arrears float,@TaxArrears float

select @Reduced = Reduced from Benefits where SchemeNo = @schemeNo and MemberNo = @MemberNo

select @sName = sName,@CheckNo = CheckNo from Members where SchemeNo = @schemeNo and MemberNo = @MemberNo
exec GetPenNo @schemeNo,@sName,1,@PenNo out

if (select count(*) from Pensioner where SchemeNo = @schemeNo and memberNo = @memberNo) >0
   begin
	update Pensioner set ComLumgwTax = @GcomLum,wTaxPd = @Tax,ComLumNWTax = (@GComLum-@tax), AccrPen = @AnnPension,
        GAPComPen = @AnnPension, MonPension = @AnnPension/12.0000000000
             where SchemeNo = @SchemeNo and MemberNo = @MemberNo
  end
else
 begin
     if @Reduced = 0
        select @Pcnt = (@GcomLum/@accrPen)*100.0000000000
     else
       select @Pcnt = 0

     if @SchemeNo = '1005'
           insert into Pensioner (schemeNo, memberNo, PenNo, pcntofPenCol, ComlumGWTax,WTaxPd,ComLumNWTax,GAPComPen,AccrPen, payType, monPension,
     PaypointCode, PayCode)
                    Values(@schemeNo, @MemberNo, @PenNo, @Pcnt, @GcomLum, @tax, (@GComLum-@tax), @AnnPension,
   @AccrPen,4, @Annpension/12.0000000000, '1005','1')
    else  if @SchemeNo <> '1005'
            begin
                    if Len(@MemberNo) = 1
                             Select @PenNo = '000'+cast(@MemberNo as varchar(10))
                   else if Len(@MemberNo) = 2
                             Select @PenNo = '00'+cast(@MemberNo as varchar(10))
                   else if Len(@MemberNo) = 3
                             Select @PenNo = '0'+cast(@MemberNo as varchar(10))
                   else Select @PenNo = cast(@MemberNo as varchar(10))
   
                   insert into Pensioner (schemeNo, memberNo, PenNo, pcntofPenCol, ComlumGWTax,WTaxPd,ComLumNWTax,GAPComPen,AccrPen, payType, monPension)
                    Values(@schemeNo, @MemberNo, @penNo,@Pcnt, @GcomLum, @tax, (@GComLum-@tax), @AnnPension,
   @AccrPen,1, @Annpension/12.0000000000)
           end
 end

/* New Code */
Exec CalcPensionArrears @schemeNo,@MemberNo,@Period out,@Arrears out,@TaxArrears out

update Pensioner set Arrears = @Arrears,ArrTax = @TaxArrears where SchemeNo = @schemeNo and MemberNo = @MemberNo
go

