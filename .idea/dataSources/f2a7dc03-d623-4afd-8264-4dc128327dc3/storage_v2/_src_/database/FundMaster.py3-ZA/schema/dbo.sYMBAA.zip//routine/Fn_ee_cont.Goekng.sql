
CREATE FUNCTION [dbo].[Fn_ee_cont](@schemeNo   INT,
                                   @MemberNo   INT,
                                   @AcctPeriod INT,
                                   @Registered INT)
returns FLOAT
AS
  BEGIN
      DECLARE @Cont     FLOAT,
              @Arrears  FLOAT,
              @Transfer FLOAT

      IF @Registered = 0
        SELECT @Cont = Sum(EmpCont)
        FROM   contributionssummary
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod
      ELSE
        SELECT @Cont = Sum(ExcessEmpCont)
        FROM   Unregisteredcontributionssummary
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod

      --Select * from ContributionArrears
      IF @Registered = 0
        SELECT @Arrears = Sum(ArEmpCont)
        FROM   CONTRIBUTIONaRREARS
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod
      ELSE
        SELECT @Arrears = Sum(ArEmpCont_Un)
        FROM   CONTRIBUTIONaRREARS
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod

      --select * from MemberTransfer
      IF @Registered = 0
        SELECT @Transfer = Sum(EmpTransfer)
        FROM   MemberTransfer
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod
      ELSE
        SELECT @Transfer = Sum(EmpTransfer)
        FROM   MemberTransferUn
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod

      IF @Cont IS NULL
        SELECT @Cont = 0

      IF @Arrears IS NULL
        SELECT @Arrears = 0

      IF @Transfer IS NULL
        SELECT @Transfer = 0

      SELECT @Cont = @Cont + @Arrears + @Transfer

      RETURN ( @Cont )
  END

go

