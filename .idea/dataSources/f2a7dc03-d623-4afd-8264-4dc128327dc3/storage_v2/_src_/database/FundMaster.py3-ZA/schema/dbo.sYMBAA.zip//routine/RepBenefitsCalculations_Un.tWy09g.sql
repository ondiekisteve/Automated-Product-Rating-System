CREATE PROCEDURE [dbo].[RepBenefitsCalculations_Un]  
@SCHEMENO Int,  
@CalcMonth int,  
@CalcYear int  
--with encryption  
as  
if object_id('tempdb..#BenCalcUn') is null  
  
begin  
create table #BenCalcUn  
(  
             [EmpCode][Int] identity(1,1) Primary Key,  
             [SchemeNo] [varchar] (15) NOT NULL ,  
             [memberNo][int] not null,  
             [PayrollNo][Varchar](20),  
             [schemeYear][int] not null,  
             [fullname][varchar] (50) not null,  
             [opEmpExcess][float] null,  
             [opEmprExcess][float] null,  
             [ExcessEmpcont][float] null,  
             [ExcessEmprcont][float] null,  
             [cEmpExcess][float] null,  
             [cEmprExcess][float] null,  
             [empInt][float] null,  
             [emprInt][float] null,  
             [EmpTax][float] null,  
             [EmprTax][float] null,  
             [ClosingBal][float] null,  
             [EndingPeriod][Varchar](30) null,  
             [SchemeName][varchar](120) null,  
             [ReportDesc][Varchar](100)       
)          
end  
  
declare @MemberNo int  
declare @cEmpExcess float  
declare @cEmprExcess float  
declare @totalBalance float  
declare @fullname varchar(100)  
declare @opEmpExcess float  
declare @opEmprExcess float  
declare @opVolExcess float  
declare @ExcessEmpCont float  
declare @ExcessEmprCont float  
declare @EmpInt float  
declare @EmprInt float  
declare @EmpTax float  
declare @ClosingBal float  
declare @EmprTax float  
declare @AcctPeriod int,@TaxRate float  
declare @curperiod varchar(30), @ExcesSpecial float, @ExcessVol float, @cExcessVol float, @CurYear int,@SchemeName varchar(120),  
@MwishoDate Datetime,@Approved bit,@BalanceofInt smallInt,@StartDate Datetime,@EndDate Datetime,  
@PayrollNo Varchar(20),@ReportDesc Varchar(100), @DoCalc Datetime,@ActiveStatus Int,@DisplayMode smallInt  
  
select @ReportDesc = 'MEMBER BALANCES - NORMAL UN-REGISTERED'  
  
  
  
exec GetAccountingPeriodInAYear @schemeNo, @calcMonth, @calcYear, @AcctPeriod out  
Select @StartDate = StartDate,@EndDate = EndDate from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod  
Select @BalanceofInt = CalcBalanceofInterest from ConfigYearEnd where SchemeNo = @schemeNo  
if @BalanceofInt is null select @BalanceofInt = 0  
  
Exec GetLastDate @CalcMonth,@CalcYear,@MwishoDate out  
  
  
select @CurYear = @CalcYear  
  
Select @SchemeName = SchemeName,@DisplayMode = DisplayMode from scheme where schemeCode = @schemeNo  
  
if @DisplayMode is null select @DisplayMode = 0  
  
Select @Approved = UnregInterest from ConfigYearEnd where SchemeNo = @schemeNo  
  
if @Approved is null select @Approved = 0  
  
exec GetAccountingPeriodInAYear @schemeNo, @CalcMonth, @calcYear, @AcctPeriod out  
  
exec GetEndingPeriod @calcMonth, @curPeriod out  
select @curPeriod = @curPeriod +' '+ cast(@CalcYear as varchar(4))  
  
select @CalcYear = @CurYear  
  
  
  
declare BenefitsCsr cursor for  
select distinct b.schemeNo, b.memberNo, b.ExcessEmpCont, b.ExcessEmprCont + b.DeferredAmt,  
                b.EmpTax,b.EmprTax + b.DefTax,  
          (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,M.ActiveStatus  
from UnregisteredBenefits b  
         inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo and m.ActiveStatus <> 3 and   
         m.ReasonForExit <> -1  
where b.SchemeNo = @schemeNo AND B.IncludeRec = 1   
order by b.memberNo  
  
open BenefitsCsr  
  
fetch from BenefitsCsr into @schemeNo, @MemberNo, @cEmpExcess, @cEmprExcess,@EmpTax,@EmprTax,@fullname,@PayrollNo,@DoCalc,@ActiveStatus  
  
while @@fetch_status = 0  
begin  
    select @opEmpExcess = ExcessEmp-(EmpTax + EmpfEES_Un), @opEmprExcess = ExcessEmpr + DeferredAmt -(EmprTax + EmprFees_Un + DefTax)  
    from UnregisteredBalances where SchemeNo = @schemeNo   
    and MemberNo = @memberNo and AcctPeriod = @AcctPeriod - 1  
      
    if @opEmpExcess is null select @opEmpExcess = 0  
    if @opEmprExcess is null select @opEmprExcess = 0  
    if @ExcessVol is null select @excessVol = 0  
     
    Exec RepMemberCertificateContributions_Un @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @ExcessEmpCont out,   
    @ExcessEmprCont out, @ExcessVol out, @ExcesSpecial  out  
  
    if @cEmpExcess = 0  
       select @opEmpExcess = 0,@ExcessEmpCont = 0,@ExcessVol = 0,@EmpTax = 0  
  
    select @EmpInt =  (@cEmpExcess - (@opEmpExcess  + @ExcessEmpcont))  
   
    if @EmpInt < 0 select @EmpInt = 0  
      
    select @Emprint =  (@cEmprExcess - (@opEmprExcess + @ExcessEmprcont))  
  
    if @EmprInt < 0 select @EmpInt = 0  
  
    if @Approved = 0 /* Scheme Not registered with KRA */  
        select @EmpTax = 0,@EmprTax = 0  
  
  
    select @cEmpExcess = @cEmpExcess - @EmpTax  
    select @cEmprExcess = @cEmprExcess - @EmprTax  
  
    select @ClosingBal = (@cEmpExcess + @cEmprExcess)  
  
    if @PayrollNo is null select @PayrollNo = @MemberNo  
  
   if @DisplayMode = 0  
    select @PayrollNo = cast(@MemberNo as Varchar(20))  
  
       insert into #BenCalcUn (schemeNo, MemberNo, schemeYear, fullname, opEmpExcess, opEmprExcess, ExcessEmpCont, ExcessEmprCont,   
               cEmpExcess, cEmprExcess ,empInt, emprInt, EmpTax, closingBal, EmprTax, EndingPeriod,SchemeName,PayrollNo,ReportDesc)  
  
                     values(@schemeNo, @MemberNo, @calcYear,@fullname, @opEmpExcess, @opEmprExcess,@ExcessEmpCont, @ExcessEmprCont,  
       @cEmpExcess, @cEmprExcess, @empInt, @EmprInt, @EmpTax,@closingBal, @EmprTax, @CurPeriod,@SchemeName,@PayrollNo,@ReportDesc)  
                               
   select @opEmpExcess = 0,@opEmprExcess = 0,@opVolExcess = 0,  
          @cEmpExcess = 0,@cEmprExcess = 0,@ClosingBal = 0,@EmpTax = 0,@EmprTax = 0,  
          @EmprInt = 0,@empInt = 0,@ExcessEmprcont = 0,@ExcessEmpcont = 0,@PayrollNo = ''  
       
fetch next from BenefitsCsr into @schemeNo, @MemberNo, @cEmpExcess, @cEmprExcess,@EmpTax,@EmprTax,@fullname,@PayrollNo,@DoCalc,@ActiveStatus  
end  
close BenefitsCsr  
Deallocate BenefitsCsr  
  
select * from #BenCalcUn where ClosingBal > 0 order by MemberNo
go

