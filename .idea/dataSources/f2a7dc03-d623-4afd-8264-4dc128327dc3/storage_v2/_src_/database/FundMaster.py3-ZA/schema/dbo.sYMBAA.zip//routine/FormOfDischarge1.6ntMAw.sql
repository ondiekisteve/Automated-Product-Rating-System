CREATE PROCEDURE [dbo].[FormOfDischarge1]    
@SCHEMENO Int,    
@memberNo int,    
@Mode Int    
--with Encryption    
as    
    
set nocount on    
    
if object_id('tempdb..#DischargeForm') is null    
    
begin    
create table #DischargeForm    
(    
    [SchemeNo] [varchar] (15) NOT NULL ,    
    [MemberNo] [int] NOT NULL ,    
           [schemeName][varchar](100) not null,    
           [Address][Varchar](120),    
           [fullname][varchar](100) not null,    
           [djpens][datetime] not null,    
           [DateOfExit][datetime] not null,    
           [ExitReason][Varchar](50),    
    [PastService] [Varchar](100) not NULL,    
           [Vesting][float]null,    
           [WithHoldingTax][Decimal](12,2) not null,    
           [EmpBenefit][float] not null,    
           [EmprBenefit][float] not null,    
           [TotalBenefit][float] not null,    
           [EmpVesting][float] not null,    
           [Benefit][Decimal](12,2) not null,    
           [Administrator][Varchar](100),    
           [CurDay][Int],    
           [CurMonth][Varchar](20),    
           [CurYear][Int],    
           [BenefitDesc][Varchar](50),    
           [GrossLumpsum][float],    
           [TaxFreeLumpsum][float],    
           [TaxableLumpsum][float],    
           [TaxOnLumpsum][float],    
           [NetLumpsum][float],    
           [Bakisha][Int],    
           [CorporateTrustee][Int],    
           [PurchasePrice][Decimal](12,2),    
           [Tuachane][Varchar](2000),    
           [BenefitTaxed][float],    
           [Beneficiary][varchar](100),    
           [DoCalc][Datetime],    
           [Unvested][float]     
)     
    
ALTER TABLE #DischargeForm WITH NOCHECK ADD                 
 CONSTRAINT [PK_DischargeForm] PRIMARY KEY  NONCLUSTERED     
 (    
  [SchemeNo],    
  [memberNo]          
 )     
end    
    
    
declare @fullname varchar(100),@schemeName varchar(100),@ExitReason varchar(50),    
@DateOfExit datetime,@vesting float,@withHoldingTax Decimal(20,6),@Benefit Decimal(20,6),@EmpClosing Decimal(20,6),@EmprClosing Decimal(20,6),    
@djpens datetime,@VestedCont float,@NumDays Int,@NumMonths Int,@NumYears Int,@ServiceTime Varchar(100),    
@Administrator Varchar(100),@cMonth Int,@MonthName varchar(20),@Address Varchar(120),    
@ExEmpCont float,@ExEmprCont float,@ExTax float,@GrossLumpsum float,@TaxFreeLumpsum float,    
@TaxableLumpsum float,@TaxOnLumpsum float,@NetLumpsum float,@BenefitDesc Varchar(50),    
@TransferOpen float,@TransferCBal float,@YaConversion varchar(25),@Chapaa Decimal(20,6),    
@FundType Varchar(2),@Avc float,@OptionToUse Int,@CorporateTrustee Int,@Bakisha Int,    
@FundCategory Varchar(50),@PurchasePrice Decimal(20,6),@Tuachane Varchar(2000),    
@EmpFeesReg FLOAT,@EmprFeesReg FLOAT,@EmpFeesUnReg FLOAT,@EmprFeesUnReg FLOAT,@doCalc Datetime,    
@DeferredBenefit smallInt,@BenefitTaxed float,@Beneficiary varchar(100),@TrivialPension smallInt,    
@GrossLumpsumUn float,@UnvestedReg float,@UnvestedUnReg float,@EmpFees float,@EmprFees float,    
@EmpFeesUn float,@EmprFeesUn float,@EmpIntUn float,@EmprIntUn float    
    
Exec dbo.EmployerOption @schemeNo,@MemberNo,@Bakisha Out     
    
    
if @Bakisha <> 1    
   select @Bakisha = 0    
      
if @Bakisha = 1    
   select @Tuachane = 'We confirm that the Employer portion has been deferred in the Scheme. The amount deferred plus interest accrued from the date of exit  to the date of retirement, will  be payable at retirement date.'      
else    
   select @Tuachane = 'We confirm that no further monies will be payable from the Pension Scheme in respect of the above mentioned Member'    
    
    
select @cMonth = DatePart(Month,GetDate())    
    
Exec GetMonthName @CMonth,@MonthName Out    
    
Exec EmployerOption @schemeNo,@MemberNo,@OptionToUse Out    
    
select @schemeName = schemeName,@Address = Address +', '+ Town,@FundType = FundType,    
@CorporateTrustee = CorporateTrustee,@FundCategory = FundCategory from scheme where schemeCode = @schemeNo    
    
if @CorporateTrustee is null select @CorporateTrustee = 0    
    
if @CorporateTrustee = 1    
   select @Tuachane = 'I further confirm that the above amount accurately reflects my benefit entitlement and that no further monies are payable to me.'    
    
if @CorporateTrustee = 0    
select @Administrator = ConsultantName from scheme_Consultants    
where SchemeNo = @schemeNo and ConsultantType = 'Administrator'    
else    
select @Administrator = TrusteeName from Trustees    
where SchemeNo = @schemeNo    
    
    
if @Mode = 0 /* Withdrawals */    
begin    
declare GenCursor cursor for    
             select m.djpens,m.doexit,m.DoCalc,     
               (Upper(m.sname) + ' , '+ upper(m.fname) + '   '+upper(m.onames)) as fullname,r.ReasonDesc,     
               b.empCBal + b.VolCBal + b.PreEmpCBal + b.PreAVCCBal + b.EmpTransferCBal,     
                         (b.EmprCBal + b.SpecialCBal + b.PreEmprCBal + B.EmpRTransferCBal), b.withholdingTax,b.vesting,    
                         b.PurchasePrice,b.TaxFreeLumpsum,b.DeferredBenefit,b.TrivialPension,    
                         B.EmpFees,b.EmprFees    
             from Members m    
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo    
                       inner join ReasonforExit r on m.ReasonforExit = r.ReasonCode    
             where m.SchemeNo = @schemeNo and m.memberNo = @memberNo    
end    
else if @Mode = 1 /* Retirements */    
begin    
     if @FundCategory <> 'Provident Fund'    
   declare GenCursor cursor for    
            select m.djpens,m.doexit,m.DoCalc,    
               (Upper(m.sname) + ' , '+ upper(m.fname) + '   '+upper(m.onames)) as fullname,r.ReasonDesc,    
              b.empCBal + b.VolCBal + b.PreEmpCBal + b.PreAVCCBal + b.EmpTransferCBal,     
                        b.EmprCBal + b.SpecialCBal + b.PreEmprCBal + B.EmpRTransferCBal, b.withholdingTax,b.vesting,    
                        b.PurchasePrice,b.TaxFreeLumpsum,b.DeferredBenefit,b.TrivialPension,    
                        B.EmpFees,b.EmprFees    
            from Members m    
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo    
                       inner join ReasonforExit r on m.ReasonforExit = r.ReasonCode    
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo    
     else if @FundCategory = 'Provident Fund'    
           declare GenCursor cursor for    
           select m.djpens,m.doexit, m.DoCalc,    
               (Upper(m.sname) + ' , '+ upper(m.fname) + '   '+upper(m.onames)) as fullname,r.ReasonDesc,    
               b.empCBal + b.VolCBal + b.PreEmpCBal + b.PreAVCCBal + b.EmpTransferCBal,     
                         (b.EmprCBal + b.SpecialCBal + b.PreEmprCBal + B.EmpRTransferCBal), b.withholdingTax,b.vesting,    
                         b.PurchasePrice,b.TaxFreeLumpsum,b.DeferredBenefit,b.TrivialPension,B.EmpFees,b.EmprFees    
             from Members m    
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo    
                       inner join ReasonforExit r on m.ReasonforExit = r.ReasonCode    
             where m.SchemeNo = @schemeNo and m.memberNo = @memberNo    
end    
else if @Mode = 2 /* Death In Service */    
begin    
declare GenCursor cursor for    
          select m.djpens,m.doexit,m.DoCalc,     
               (Upper(m.sname) + ' , '+ upper(m.fname) + '   '+upper(m.onames)) as fullname,r.ReasonDesc,    
    b.empCBal + b.VolCBal + b.PreEmpCBal + b.PreAVCCBal + b.EmpTransferCBal,     
                         (b.EmprCBal + b.SpecialCBal + b.PreEmprCBal + B.EmpRTransferCBal), b.withholdingTax,b.vesting,    
                 b.PurchasePrice,b.TaxFreeLumpsum,b.DeferredBenefit,b.TrivialPension,B.EmpFees,b.EmprFees    
         from Members m    
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo    
                       inner join ReasonforExit r on m.ReasonforExit = r.ReasonCode    
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo    
end    
open GenCursor    
    
fetch from GenCursor into @djpens, @dateofExit,@DoCalc, @fullname,@ExitReason,    
 @EmpClosing,@emprClosing,@withHoldingTax,@vesting,@PurchasePrice,@TaxFreeLumpsum,@DeferredBenefit,    
 @TrivialPension,@EmpFees,@EmprFees     
    
while @@fetch_status = 0     
begin    
    if @EmpFees is null select @EmpFees = 0.0    
    if @EmprFees is null select @EmprFees = 0.0    
    
    select @EmpClosing = @EmpClosing - @EmpFees,@emprClosing=@emprClosing - @EmprFees     
    
    if @TrivialPension is null select @TrivialPension = 1    
    
    select @Beneficiary = @fullname    
    if @Mode = 2 /* Death Claims */    
       select @Beneficiary = sName +', '+fName+' '+Oname from Dependants where schemeNo = @schemeNo and MemberNo = @MemberNo    
       and Administrator = 1    
    
    if (@Mode = 1)    
       begin    
             
         IF @FundCategory <> 'Provident Fund'    
           begin     
           if @FundType = 'DB'    
              begin    
                  select @GrossLumpsum = ComLumGWTax,@TaxFreeLumpsum = @TaxFreeLumpsum,    
                  @TaxableLumpsum = ComLumGWTAX - @TaxFreeLumpsum,@TaxOnLumpsum  = wTaxPd,@NetLumpsum = ComLumNWTax    
                  from Pensioner where SchemeNo = @schemeNo and MemberNo = @MemberNo    
    
                  select @Avc = VolCBal + SpecialCBal + PreAVCCBAL from Benefits    
                  where SchemeNo = @schemeNo and MemberNo = @MemberNo    
    
                  if @Avc is null select @Avc = 0    
    
                  select @GrossLumpsum = @GrossLumpsum + @Avc    
                  select @BenefitTaxed = @GrossLumpsum    
              end    
           else if @FundType <> 'DB'    
               begin    
                  select @GrossLumpsum = CommLumpsum,@TaxFreeLumpsum = @TaxFreeLumpsum,    
                  @TaxOnLumpsum  = WithholdingTax,@NetLumpsum = CommLumpsum - WithholdingTax,    
                  @TaxableLumpsum = CommLumpsum - @TaxFreeLumpsum    
                  from Benefits where SchemeNo = @schemeNo and MemberNo = @MemberNo    
     
                  select @GrossLumpsumUn = CommLumpsum    
                  from UnRegisteredBenefits where SchemeNo = @schemeNo and MemberNo = @MemberNo    
    
                  if @GrossLumpsumUn is null select @GrossLumpsumUn = 0    
                  select @BenefitTaxed = @GrossLumpsum    
    
                  select @GrossLumpsum = @GrossLumpsum + @GrossLumpsumUn    
               end    
        end    
     Else if @FundCategory = 'Provident Fund'    
          begin    
            select @GrossLumpsum = 0,@TaxFreeLumpsum = @TaxFreeLumpsum,    
            @TaxableLumpsum = 0,@TaxOnLumpsum  = 0,@NetLumpsum = 0    
          end    
    
           if @GrossLumpsum < 480000     
              select @TaxableLumpsum = 0,@TaxOnLumpsum = 0     
    
         if @FundCategory <> 'Provident Fund'    
           Select @BenefitDesc = 'Commuted Pension'    
         else    
           Select @BenefitDesc = 'Retirement Benefit'    
         end    
   else if @Mode = 0    
       begin    
           select @GrossLumpsum = 0,@TaxFreeLumpsum = @TaxFreeLumpsum,    
           @TaxableLumpsum = 0,@TaxOnLumpsum  = 0,@NetLumpsum = 0    
    
           IF @OptionToUse = 1    
              begin    
              Select @ExEmpCont  = EEmpCBal + EVolCBal,@ExEmprCont = EEmprCBal + ESpecialCBal,    
              @EmpIntUn = EmpInt,@EmprIntUn = EmprInt,    
              @EmpFeesUn = EmpFees_Un, @EmprFeesUn = EmprFees_Un    

              from UnRegisteredBenefits where SchemeNo = @schemeNo and MemberNo = @MemberNo    
    
              if @EmpIntUn is null select @EmpIntUn = 0    
              if @EmprIntUn is null select @EmprIntUn = 0    
    
              select @ExTax = @EmpIntUn * (30.00/100.00)     
              end    
           else    
              begin    
              Select @ExEmpCont  = EEmpCBal + EVolCBal,@ExEmprCont = EEmprCBal + ESpecialCBal,    
              @EmpIntUn = EmpInt,@EmprIntUn = EmprInt,@EmpFeesUn = EmpFees_Un, @EmprFeesUn = EmprFees_Un    
              from UnRegisteredBenefits where SchemeNo = @schemeNo and MemberNo = @MemberNo    
    
              if @EmpIntUn is null select @EmpIntUn = 0    
              if @EmprIntUn is null select @EmprIntUn = 0    
    
              if ((@Vesting < 100) and (@Vesting > 0))    
                 select @ExTax = (@EmpIntUn * (30.00/100.00)) + ((@EmprIntUn * (@Vesting/100.00)) * (30.00/100.00))    
              else if @Vesting = 0    
             select @ExTax = (@EmpIntUn * (30.00/100.00))    
              else if @Vesting = 100    
                 select @ExTax = (@EmpIntUn * (30.00/100.00)) + (@EmprIntUn * (30.00/100.00))    
              end    
    
              
    
    
           Select @BenefitDesc = 'Withdrawal benefits'    
    
           IF @ExEmpCont is null select @ExEmpCont = 0.0    
           if @ExEmprCont is null select @ExEmprCont = 0.0    
           if @ExTax is null select @ExTax = 0.0    
           IF @EmpFeesUn is null select @EmpFeesUn = 0.0    
           if @EmprFeesUn is null select @EmprFeesUn = 0.0    
    
           select @ExEmpCont = @ExEmpCont - @EmpFeesUn,@ExEmprCont = @ExEmprCont - @EmprFeesUn     
          
               
           if @DeferredBenefit = 0    
              begin    
                 if @OptionToUse = 0    
                     begin    
                         select @BenefitTaxed = @empClosing + (@emprClosing * (@Vesting/100.000))    
                         print @EmpClosing    
                         print @ExEmpCont    
                          
                         select @emprClosing = (@emprClosing * (@Vesting/100.000)) + (@ExEmprCont * (@Vesting/100.000)),    
                         @EmpClosing = @empClosing + @ExEmpCont    
    
                             
    
                         SELECT @Benefit = @emprClosing + @empClosing    
    
                         if @Vesting < 100    
                            begin    
                               select @UnVestedReg = ((100 - @Vesting)/100.00) * @emprClosing    
                             
                               select @UnVestedUnReg = ((100 - @Vesting)/100.00) * @ExEmprCont    
    
                               if @UnVestedReg is null select @UnVestedReg = 0.0    
                               if @UnVestedUnReg is null select @UnVestedUnReg = 0.0    
    
                               select @UnVestedReg = @UnVestedReg + @UnVestedUnReg    
                            end    
    
                     end    
                 else if @OptionToUse = 1    
                     begin    
                         select @emprClosing = 0.0,@BenefitTaxed = @EmpClosing,@Benefit = @empClosing + @ExEmpCont,    
                         @EmpClosing = @empClosing + @ExEmpCont    
                             
    
                         select @UnVestedReg = 0.0    
                     end    
                 else if @OptionToUse = 2    
                     begin    
                        select @BenefitTaxed = @empClosing + (@emprClosing * (@Vesting/100.000))    
                                                    
                        select @emprClosing = (@emprClosing * (@Vesting/100.000)) + (@ExEmprCont * (@Vesting/100.000)),    
                        @EmpClosing = @empClosing + @ExEmpCont    
                        SELECT @Benefit = @emprClosing + @empClosing    
    
                            
    
                        if @Vesting < 100    
                            begin    
                               select @UnVestedReg = ((100 - @Vesting)/100.00) * @emprClosing    
                             
                               select @UnVestedUnReg = ((100 - @Vesting)/100.00) * @ExEmprCont    
    
                               if @UnVestedReg is null select @UnVestedReg = 0.0    
                               if @UnVestedUnReg is null select @UnVestedUnReg = 0.0    
    
                               select @UnVestedReg = @UnVestedReg + @UnVestedUnReg    
                            end    
                 end    
             end    
         else if @DeferredBenefit = 1    
             begin    
                 IF @OptionToUse = 1    
                    select @EmprFeesReg=0,@EmprFeesUnReg=0    
                 ELSE    
                    select @EmprFeesReg=0,@EmprFeesUnReg=0     
    
                 select @EmpClosing = 0.0,@emprClosing = (@emprClosing + @ExEmprCont)    
                 select @BenefitTaxed = @emprClosing    
             end    
       end    
 else if @Mode = 2    
       begin    
           select @GrossLumpsum = 0,@TaxFreeLumpsum = @TaxFreeLumpsum,    
           @TaxableLumpsum = 0,@TaxOnLumpsum  = 0,@NetLumpsum = 0    
    
          
           Select @ExEmpCont  = EEmpCBal + EVolCBal,@ExEmprCont = EEmprCBal + ESpecialCBal,    
           @EmpIntUn = EmpInt,@EmprIntUn = EmprInt,@EmpFeesUn = EmpFees_Un, @EmprFeesUn = EmprFees_Un    
           from UnRegisteredBenefits where SchemeNo = @schemeNo and MemberNo = @MemberNo    
    
              if @EmpIntUn is null select @EmpIntUn = 0    
              if @EmprIntUn is null select @EmprIntUn = 0    
    
              if ((@Vesting < 100) and (@Vesting > 0))    
                 select @ExTax = (@EmpIntUn * (30.00/100.00)) + ((@EmprIntUn * (@Vesting/100.00)) * (30.00/100.00))    
              else if @Vesting = 0    
                 select @ExTax = (@EmpIntUn * (30.00/100.00))    
              else if @Vesting = 100    
                 select @ExTax = (@EmpIntUn * (30.00/100.00)) + (@EmprIntUn * (30.00/100.00))    
            IF @ExEmpCont is null select @ExEmpCont = 0.0    
           if @ExEmprCont is null select @ExEmprCont = 0.0    
           if @ExTax is null select @ExTax = 0.0    
    
           select @BenefitTaxed = @empClosing + (@emprClosing * (@Vesting/100.000))    
                                                    
           select @emprClosing = (@emprClosing * (@Vesting/100.000)) + (@ExEmprCont * (@Vesting/100.000)),    
           @EmpClosing = @empClosing + @ExEmpCont    
    
               
    
           SELECT @Benefit = @emprClosing + @empClosing    
    
           Select @BenefitDesc = 'Death benefits'    
       end    
    
        if @withHoldingTax is null select @withHoldingTax  = 0    
        if @EmpClosing is null select @EmpClosing = 0    
        if @emprClosing is null select @emprClosing = 0    
        if @vesting is null select @vesting = 100.00    
        if @VestedCont is null select @VestedCont = @emprClosing    
    
        if @ExEmpCont is null select @ExEmpCont  =  0    
        if @ExEmprCont is null select @ExEmprCont =  0    
        if @ExTax is null select @ExTax = 0    
    
        IF @OptionToUse = 1    
           select @EmprFeesReg=0,@EmprFeesUnReg=0    
        else if @OptionToUse <> 1 and @vesting = 0    
           select @EmprFeesReg=0,@EmprFeesUnReg=0    
    
   if @DeferredBenefit = 0    
      begin    
        select @EmpClosing = (@EmpClosing)    
        select @emprClosing = (@emprClosing)    
     end    
   else if @DeferredBenefit = 1    
   begin    
       select @EmpClosing = 0.0,@emprClosing = @emprClosing    
   end    
    
        
     select @Benefit = (@emprClosing + @EmpClosing)    
    
     Exec GetServiceTime @djpens,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out    
    
     select @ServiceTime = cast(@NumYears as Varchar(2)) +' Years, '+ cast(@NumMonths as varchar(2))+'  months and '+cast(@NumDays as Varchar(2))+' days '    
    
     
            
 if ((@Mode = 1) and (@FundCategory <> 'Provident Fund'))     
    select @Benefit = @NetLumpsum       
     
    
 /* rounding  Benefit*/    
    select @YaConversion = cast(@Benefit as Varchar(25))    
    Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out    
    select @Benefit = @Chapaa    
    select @Chapaa = 0    
    
 /* rounding  Tax */    
    select @WithHoldingTax = @WithHoldingTax + @ExTax    
    select @YaConversion = cast(@WithHoldingTax as Varchar(25))    
    Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out    
    select @WithHoldingTax = @Chapaa    
    select @WithHoldingTax = round(@WithHoldingTax,0)    
    select @Chapaa = 0    
     
    
   if ((@Mode = 1) and (@FundCategory <> 'Provident Fund'))     
       select @Benefit  = @Benefit    
   Else    
       select @Benefit  = @Benefit - @withHoldingTax    
    
 if @PurchasePrice is null select @PurchasePrice = 0.0    
    
 if @UnVestedReg is null select @UnVestedReg = 0.0    
    
 insert into #DischargeForm (schemeNo, MemberNo, schemeName, fullname,djpens,    
 DateOfExit,ExitReason,PastService,Vesting,    
 WithHoldingTax,EmpBenefit,EmprBenefit,Benefit,Administrator,    
 TotalBenefit,EmpVesting,CurDay,CurMonth,CurYear,Address,GrossLumpsum,TaxFreeLumpsum,    
 TaxableLumpsum,TaxOnLumpsum,NetLumpsum,BenefitDesc,Bakisha,CorporateTrustee,PurchasePrice,Tuachane,BenefitTaxed,    
 Beneficiary,DoCalc,UnVested)    
       values(@schemeNo, @memberNo,@schemeName, @fullname, @djpens,@DateOfExit,@ExitReason,@ServiceTime,@Vesting,    
 @WithHoldingTax,@EmpClosing,@emprClosing,@Benefit,@Administrator,    
 @EmpClosing+@emprClosing,100.000,DatePart(Day,GetDate()),@MonthName,DatePart(Year,GetDate()),@Address,    
 @GrossLumpsum,@TaxFreeLumpsum,@TaxableLumpsum,@TaxOnLumpsum,@NetLumpsum,@BenefitDesc,@Bakisha,@CorporateTrustee,    
 @PurchasePrice,@Tuachane,@BenefitTaxed,@Beneficiary,@DoCalc,@UnVestedReg)    
    
     fetch next from GenCursor into @djpens, @dateofExit,@DoCalc, @fullname,@ExitReason,    
 @EmpClosing,@emprClosing,@withHoldingTax,@vesting,@PurchasePrice,@TaxFreeLumpsum,@DeferredBenefit,@TrivialPension,    
 @EmpFees,@EmprFees    
end     
    
close GenCursor    
deallocate GenCursor    
    
select * from #DischargeForm
go

