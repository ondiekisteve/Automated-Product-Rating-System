CREATE PROCEDURE [dbo].[contRatesGrid]
@SCHEMENO Int
--with Encryption 
as
select EmprContRate, EmpContRate, ContrYear
from ContributionRates
where SchemeNo = @SchemeNo
go

