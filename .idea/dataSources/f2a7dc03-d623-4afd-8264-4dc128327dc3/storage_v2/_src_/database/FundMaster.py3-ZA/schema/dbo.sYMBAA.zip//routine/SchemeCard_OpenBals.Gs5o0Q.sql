CREATE PROCEDURE [dbo].[SchemeCard_OpenBals]        
@schemeNo int,        
@SponsorCode Int,        
@AcctPeriod int,        
@RepMode int,/*0-registered, 1- Unregistered*/        
@memberBalances Decimal(20,6) out,        
@SurplusBalances Decimal(20,6) out        
--with encryption        
as        
        
declare @NormBalance Decimal(20,6),@DefBalance Decimal(20,6),@DistrBalance Decimal(20,6),@DefDistrBalance Decimal(20,6),        
@DeferredBal Decimal(20,6),@sDate datetime,@PeriodToUse int,@AdminFeesOpen Decimal(20,6),@ResDistr Decimal(20,6),@ResBalance Decimal(20,6),        
@NormBalanceUn Decimal(20,6),@DeferredBalUn Decimal(20,6),@AdminFeesOpenUn Decimal(20,6),        
@DefBalanceUn Decimal(20,6),@ResBalanceUn Decimal(20,6),@ResDistrUn Decimal(20,6)         
        
select @sDate = StartDate from schemeYears where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod        
select @PeriodToUse = @AcctPeriod - 1        
        
if @RepMode = 0                        
   begin        
      IF @SPONSORCODE = 0      
      BEGIN                                  
      select @NormBalance = sum(o.EmpCont + o.EmpVolCont + o.EmprCont + o.EmprVolCont + o.Transfer + o.LockedIn),         
      @DeferredBal = sum(DeferredAmt),@AdminFeesOpen = sum(o.EmpFees + o.EmprFees + o.VolFees + o.SpecFees)                                           
      from MemberOpeningBalances o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo --and ((m.ReasonforExit = 0)                                          
      --or (m.ReasonforExit > 0 and m.DoCalc >= @sDate))                                          
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse        
              
      if @NormBalance is null select @NormBalance = 0.0        
      if @DeferredBal is null select @DeferredBal = 0.0        
      if @AdminFeesOpen is null select @AdminFeesOpen = 0.0        
        
      /*  
      select @DefBalance = sum(o.EmprCont + o.EmprVolCont + o.LockedIn + o.DeferredAmt)- sum(o.EmprFees + o.SpecFees)                                           
      from MemberOpeningBalances o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo                                           
      and (m.ReasonforExit > 0 and m.DoCalc < @sDate) and m.ActiveStatus = 6                                          
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse   
      */        
        
      if @DefBalance is null select @DefBalance = 0.0          
        
      select @DistrBalance = sum(o.EmpCont + o.EmprCont + o.AVC + o.AVCER)                                          
      from memb_reservefund_distr o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo --and ((m.ReasonforExit = 0)                                          
      --or (m.ReasonforExit > 0 and m.DoCalc >= @sDate))              
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse                                          
               
      if @DistrBalance is null select @DistrBalance = 0.0          
      /*                             
      select @DefDistrBalance = sum(o.EmpCont + o.EmprCont + o.AVC + o.AVCER)                                          
      from memb_reservefund_distr o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo                                           
      and (m.ReasonforExit > 0 and m.DoCalc < @sDate) and m.ActiveStatus = 6              
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse  
      */        
        
      if @DefDistrBalance is null select @DefDistrBalance = 0.0         
        
      /* Reserve */        
      select @ResBalance = ReserveBalance - ReserveDistributed                                         
      from ReserveOpeningBalance                          
      where SchemeNo = @schemeNo and AcctPeriod = @PeriodToUse                   
          
      /*            
      select @ResDistr = ReserveDistributed                                          
      from ReserveOpeningBalance                                          
      where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod     
      */       
        
      if @ResBalance is null select @ResBalance = 0          
      if @ResDistr is null select @ResDistr = 0      
      END      
      else /*Umbrella*/      
      BEGIN                                  
      select @NormBalance = sum(o.EmpCont + o.EmpVolCont + o.EmprCont + o.EmprVolCont + o.Transfer + o.LockedIn),         
      @DeferredBal = sum(DeferredAmt),@AdminFeesOpen = sum(o.EmpFees + o.EmprFees + o.VolFees + o.SpecFees)                                           
      from MemberOpeningBalances o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo /*and ((m.ReasonforExit = 0)                                          
      or (m.ReasonforExit > 0 and m.DoCalc >= @sDate))*/ and m.SponsorCode = @SponsorCode                                          
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse        
              
      if @NormBalance is null select @NormBalance = 0.0        
      if @DeferredBal is null select @DeferredBal = 0.0        
      if @AdminFeesOpen is null select @AdminFeesOpen = 0.0        
        
      /*  
      select @DefBalance = sum(o.EmprCont + o.EmprVolCont + o.LockedIn + o.DeferredAmt)- sum(o.EmprFees + o.SpecFees)                                           
      from MemberOpeningBalances o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo                                           
      and (m.ReasonforExit > 0 and m.DoCalc < @sDate) and m.ActiveStatus = 6 and m.SponsorCode = @SponsorCode                                         
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse   
      */        
        
      if @DefBalance is null select @DefBalance = 0.0          
        
      select @DistrBalance = sum(o.EmpCont + o.EmprCont + o.AVC + o.AVCER)                                          
      from memb_reservefund_distr o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo /*and ((m.ReasonforExit = 0)                                          
      or (m.ReasonforExit > 0 and m.DoCalc >= @sDate))*/ and m.SponsorCode = @SponsorCode              
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse                                          
               
      if @DistrBalance is null select @DistrBalance = 0.0          
        
      /*                            
      select @DefDistrBalance = sum(o.EmpCont + o.EmprCont + o.AVC + o.AVCER)                                          
      from memb_reservefund_distr o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo                                           
      and (m.ReasonforExit > 0 and m.DoCalc < @sDate) and m.ActiveStatus = 6  and m.SponsorCode = @SponsorCode            
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse   
      */       
        
      if @DefDistrBalance is null select @DefDistrBalance = 0.0         
        
      /* Reserve */        
      select @ResBalance = ReserveBalance - ReserveDistributed                                        
      from ReserveOpeningBalance                                          
      where SchemeNo = @schemeNo and AcctPeriod = @PeriodToUse and SponsorCode = @SponsorCode                  
          
      /*            
      select @ResDistr = ReserveDistributed                                          
      from ReserveOpeningBalance                                          
      where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod  and SponsorCode = @SponsorCode     
      */     
        
      if @ResBalance is null select @ResBalance = 0          
      if @ResDistr is null select @ResDistr = 0      
      END                                         
              
      SELECT @memberBalances = (@NormBalance + @DeferredBal + @DefBalance + @DistrBalance + @DefDistrBalance) - @AdminFeesOpen,        
      @SurplusBalances = @ResBalance - @ResDistr           
          
  end         
ELSE IF @RepMode = 1 /* Un Registered */        
  begin      
      if @SponsorCode = 0      
      BEGIN        
      select @NormBalance = sum(o.excessEmp + o.ExcessEmpr + o.ExcessVolContr + o.ExcessSpecial) - sum(o.EmpTax + o.EmprTax + o.VolTax + o.SpecTax),                                          
      @AdminFeesOpen = sum(o.EmpFees_Un + o.EmprFees_Un + o.VolFees_Un + o.SpecFees_Un),@DeferredBal = sum(DeferredAmt)                                           
      from UnRegisteredBalances o                              
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo /*and ((m.ReasonforExit = 0)                                          
      or (m.ReasonforExit > 0 and m.DoCalc >= @sDate)) */                                         
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse         
                      
              
      if @NormBalance is null select @NormBalance = 0.0        
      if @DeferredBal is null select @DeferredBal = 0.0        
      if @AdminFeesOpen is null select @AdminFeesOpen = 0.0        
        
      /*select @DefBalance = sum(o.ExcessEmpr + o.ExcessSpecial + o.DeferredAmt) - sum(o.EmprTax + o.SpecTax + defTax + o.EmprFees_Un + o.SpecFees_Un)                                          
      from UnRegisteredBalances o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo                                          
            and (m.ReasonforExit > 0 and m.DoCalc < @sDate) and m.ActiveStatus = 6                                          
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse  
      */        
        
      if @DefBalance is null select @DefBalance = 0.0          
        
      select @DistrBalance = sum(o.EmpCont_Un + o.EmprCont_Un + o.AVC_Un + o.AVCER_Un)                                          
      from memb_reservefund_distr o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo             
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse                                          
               
      if @DistrBalance is null select @DistrBalance = 0.0 
                                                             
      if @DefDistrBalance is null select @DefDistrBalance = 0.0        
        
      select @ResBalance = ReserveBalance  - ReserveDistributed                                       
      from Un_ReserveOpeningBalance                                          
      where SchemeNo = @schemeNo and AcctPeriod = @PeriodToUse                   
          
      /*           
      select @ResDistr = ReserveDistributed                                          
      from Un_ReserveOpeningBalance                                          
      where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod     
      */       
        
      if @ResBalance is null select @ResBalance = 0          
      if @ResDistr is null select @ResDistr = 0       
      END      
      else /*Deferred*/      
      BEGIN        
      select @NormBalance = sum(o.excessEmp + o.ExcessEmpr + o.ExcessVolContr + o.ExcessSpecial) - sum(o.EmpTax + o.EmprTax + o.VolTax + o.SpecTax),                                          
      @AdminFeesOpen = sum(o.EmpFees_Un + o.EmprFees_Un + o.VolFees_Un + o.SpecFees_Un),@DeferredBal = sum(DeferredAmt)                                           
      from UnRegisteredBalances o                              
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo /*and ((m.ReasonforExit = 0)                                          
      or (m.ReasonforExit > 0 and m.DoCalc >= @sDate))*/                                          
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse and m.SponsorCode = @SponsorCode         
    
              
      if @NormBalance is null select @NormBalance = 0.0        
      if @DeferredBal is null select @DeferredBal = 0.0        
      if @AdminFeesOpen is null select @AdminFeesOpen = 0.0        
      /*  
      select @DefBalance = sum(o.ExcessEmpr + o.ExcessSpecial + o.DeferredAmt) - sum(o.EmprTax + o.SpecTax + defTax + o.EmprFees_Un + o.SpecFees_Un)                                          
      from UnRegisteredBalances o        
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo                                          
            and (m.ReasonforExit > 0 and m.DoCalc < @sDate) and m.ActiveStatus = 6                                          
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse and m.SponsorCode = @SponsorCode   
      */      
        
      if @DefBalance is null select @DefBalance = 0.0          
        
      select @DistrBalance = sum(o.EmpCont_Un + o.EmprCont_Un + o.AVC_Un + o.AVCER_Un)                                          
      from memb_reservefund_distr o                                          
      Inner Join Members m on o.schemeNo = m.schemeNo and o.MemberNo = m.MemberNo and m.SponsorCode = @SponsorCode             
      where o.SchemeNo = @schemeNo and o.AcctPeriod = @PeriodToUse                                          
               
      if @DistrBalance is null select @DistrBalance = 0.0                                  
      if @DistrBalance is null select @DistrBalance = 0.0          
                                  
      if @DefDistrBalance is null select @DefDistrBalance = 0.0        
        
      select @ResBalance = ReserveBalance - ReserveDistributed                                        
      from Un_ReserveOpeningBalance                                          
      where SchemeNo = @schemeNo and AcctPeriod = @PeriodToUse and SponsorCode = @SponsorCode                   
          
      /*            
      select @ResDistr = ReserveDistributed                                          
      from Un_ReserveOpeningBalance                                          
      where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod and SponsorCode = @SponsorCode    
      */      
        
      if @ResBalance is null select @ResBalance = 0          
      if @ResDistr is null select @ResDistr = 0       
      END                                         
              
      SELECT @memberBalances = (@NormBalance + @DeferredBal + @DefBalance + @DistrBalance + @DefDistrBalance) - @AdminFeesOpen,           
      @SurplusBalances = @ResBalance - @ResDistr        
  end
go

