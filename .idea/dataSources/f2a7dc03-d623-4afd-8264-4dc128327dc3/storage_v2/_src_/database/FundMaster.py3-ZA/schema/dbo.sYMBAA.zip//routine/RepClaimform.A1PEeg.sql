










































CREATE PROCEDURE RepClaimform
@SCHEMENO Int,
@Administered int
--with Encryption
as

if @Administered = 0
   Select upper(SchemeName) as SchemeName, Building+', '+Road as Building,
   Address+', '+town+' '+Country as AddRess,'Tel :'+Telephone as Telephone
   from scheme where schemeCode = @SchemeNO
else
   Select Upper(ConsultantName) as SchemeName,Building+', '+Road as Building,
   Address+', '+town+' '+Country as AddRess,'Tel :'+phone as Telephone
   from scheme_Consultants where SchemeNo = @SchemeNo and ConsultantType ='Administrator'


go

