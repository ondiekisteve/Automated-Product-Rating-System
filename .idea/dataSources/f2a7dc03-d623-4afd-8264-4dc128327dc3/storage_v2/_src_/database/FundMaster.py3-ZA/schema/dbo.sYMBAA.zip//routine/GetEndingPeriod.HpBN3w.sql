CREATE PROCEDURE [dbo].[GetEndingPeriod]
@curMonth int,
@CurPeriod Varchar (25) out
--with Encryption
as

select @curPeriod = CASE MonthNumber 

        WHEN 1 THEN '31st January'

        WHEN  2 THEN '28 th February'

        WHEN 3 THEN '31st March'

        WHEN  4 THEN '30th April'

        WHEN 5 THEN '31st May'

        WHEN 6 THEN '30th June'

        WHEN 7 THEN '31st July'

        WHEN 8 THEN '31st August'

        WHEN 9 THEN '30 th September'

        WHEN 10 THEN '31st October'

        WHEN 11 THEN '30 th November'

        WHEN 12 THEN '31st December'        
end
FROM  MonthTable
Where MonthNumber = @CurMonth
go

