CREATE PROCEDURE [dbo].[repMemTotContributions]
@SCHEMENO Int,
@memberno int
--with Encryption
 AS
SELECT schemeno,memberNo, SUM(EmpCont + EmprCont + SpecialContr + VolContr + NssfE + Nssf + ExcessEmpCont + ExcessEmprCont + ExcessVolContr + ExcessSpecial) AS TotContr
FROM Contributionssummary
WHERE (schemeNO = @schemeNo) and 
               (memberno = @memberno)
GROUP BY  MemberNo, SchemeNo
go

