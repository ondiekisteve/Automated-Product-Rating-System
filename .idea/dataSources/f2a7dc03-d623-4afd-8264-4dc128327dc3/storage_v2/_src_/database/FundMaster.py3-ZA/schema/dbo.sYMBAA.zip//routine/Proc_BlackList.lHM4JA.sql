CREATE PROCEDURE [dbo].[Proc_BlackList]
@ListCounter Int,
@schemeNo Int,
@MembOrSponsorCode Int,
@MembOrSponsor Int,
@StartDate datetime,
@EndDate datetime,
@ReasonCode Int,
@BlackListReason varchar(120),
@Reinstated Int,
@DateReinstated datetime,
@AddEdit int
--with Encryption
as
if @AddEdit = 0
   begin
      Insert Into TBL_BlackList_History (SchemeNo,MembOrSponsorCode,MembOrSponsor,
                                         StartDate,EndDate,ReasonCode,BlackListReason,Reinstated,
                                         DateReinstated)
                                   Values(@SchemeNo,@MembOrSponsorCode,@MembOrSponsor,
                                          @StartDate,@EndDate,@ReasonCode,@BlackListReason,@Reinstated,
                                          @DateReinstated)
   end
else if @AddEdit = 1
   begin
     Update TBL_BlackList_History set StartDate = @StartDate,EndDate = @EndDate, ReasonCode = @ReasonCode,
                                      BlackListReason = @BlackListReason,Reinstated = @Reinstated,
                                      DateReinstated = @DateReinstated
     where ListCounter = @ListCounter
   end
else if @AddEdit = 2
   begin
     Delete from TBL_BlackList_History where ListCounter = @ListCounter
   end
go

