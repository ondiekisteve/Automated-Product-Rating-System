CREATE PROCEDURE [dbo].[Proc_Fund_Valuation]      
@Proc_Date Datetime,      
@RangeStart Int,      
@RangeEnd Int,      
@IntMode Int      
--with Encryption      
as      
declare @SCHEMENO Int,@ValuationBalance Decimal(20,6),@ValMonth Int,@ValYear Int,      
@BalCF Decimal(20,6),@BalBF Decimal(20,6),@Premiums Decimal(20,6),@WithDrawals Decimal(20,6),@Population int,      
@AcctPeriod Int,@Expenses Decimal(20,6),@StartDate Datetime,@Interest Decimal(20,6),@Val_Status smallInt,      
@MonthName Varchar(30),@RelSchemeNo Int      
      
      
select @ValMonth = DatePart(Month,@Proc_Date),@ValYear = DatePart(Year,@Proc_Date)      
      
Exec GetMonthName @ValMonth,@MonthName Out      
      
select @MonthName = @MonthName+', '+cast(@ValYear as Varchar(4))      
      
SELECT @Val_Status = Max(Valuation_Status) FROM tbl_FundValuation      
where ValMonth = @ValMonth and ValYear = @ValYear      
      
if @Val_Status = 1      
   begin      
      Raiserror('You cannot Process the Valuation report for %s as the Period is Closed',16,1,@MonthName)      
      Return      
   end      
      
/* Member Level Schemes */   
/*     
declare ValuationCsr Cursor for      
Select Distinct schemeCode from Scheme where BasisCode = 0 and StatusCode = 1      
and PooledInvestment = 1      
and cast(SchemeCode as Integer) >= @RangeStart and cast(SchemeCode as Integer) <= @RangeEnd      
open ValuationCsr      
Fetch from ValuationCsr Into @schemeNo      
while @@fetch_Status = 0      
begin      
        
  select @AcctPeriod = AcctPeriod,@StartDate = StartDate       
  from schemeYears where schemeNo = @schemeNo and StartDate <= @Proc_Date      
  and EndDate >= @Proc_Date      
      
  select @BalCF = FUNDBALANCE_PROV,@BalBF = FUNDBALANCE       
  FROM SCHEMEYEARS WHERE SCHEMENO = @SCHEMENO AND ACCTPERIOD = @ACCTPERIOD - 1      
      
  if @BalCF is null select @BalCF = 0      
  if @BalBF is null select @BalBF = 0      
      
  select @Population = count(m.MemberNo)      
  from Members m inner join MemberStatus a on m.ActiveStatus = a.StatusCode      
  where (m.SchemeNo =  @schemeNo)  and ((m.ReasonForExit = 0)       
  OR ((M.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 0)))      
  and m.djpens <= @Proc_Date      
      
  if @Population is null select @Population = 0      
      
      
  Exec Proc_Valuation_Balance @schemeNo,@Proc_Date,0,0,@IntMode,2,@ValuationBalance Out,@Premiums Out,      
                            @Expenses Out,@WithDrawals out,@Interest Out,@BalBF Out     
      
  if @ValuationBalance is null select @ValuationBalance =0      
  if @Premiums is null select @Premiums = 0.0      
  if @Expenses is null select @Expenses = 0.0      
  if @WithDrawals is null select @WithDrawals = 0.0      
  if @Interest is null select @Interest = 0.0     
    
  SELECT @WithDrawals = @WithDrawals + @Expenses      
      
  if Exists (Select AcctPeriod from tbl_FundValuation where schemeNo = @schemeNo and ValMonth = @ValMonth and ValYear = @ValYear)      
            update tbl_FundValuation set BalCF = @BalCF,BalBf = @BalBF,Premiums = @Premiums,      
            WithDrawals = @WithDrawals,Population = @Population,ClosingBal = @ValuationBalance,      
            Expenses = @Expenses,Interest = @Interest      
            where schemeNo = @schemeNo and ValMonth = @ValMonth and ValYear = @ValYear      
  else      
     Insert into tbl_FundValuation(SchemeNo,FiscalYear,AcctPeriod,BalCF,BalBF,Premiums,WithDrawals,Population,ClosingBal,ValYear,ValMonth,      
                                   Expenses,Interest)      
              Values(@schemeNo,@AcctPeriod,@ValMonth,@BalCF,@BalBF,@Premiums,@WithDrawals,@Population,@ValuationBalance,@ValYear,@ValMonth,      
                     @Expenses,@Interest)      
        
  select @ValuationBalance = 0,@AcctPeriod = 0,@BalCF=0,@BalBF=0,@Premiums=0,@WithDrawals=0,@Population=0,      
  @Expenses = 0.0,@Interest = 0.0      
        
  Fetch next from ValuationCsr Into @schemeNo      
end      
Close ValuationCsr      
Deallocate ValuationCsr  
*/      
    
/* Fund Level Schemes */      
      
declare ValuationCsr Cursor for      
Select Distinct schemeCode from Scheme where BasisCode = 1 and ActiveStatus = 1      
and cast(SchemeCode as Integer) >= @RangeStart and cast(SchemeCode as Integer) <= @RangeEnd      
open ValuationCsr      
Fetch from ValuationCsr Into @schemeNo      
while @@fetch_Status = 0      
begin  
  
  select @RelSchemeNo = RelSchemeNo from scheme where schemeCode = @schemeNo  
      
  select @AcctPeriod = AcctPeriod,@StartDate = StartDate       
  from schemeYears where schemeNo = @schemeNo and StartDate <= @Proc_Date      
  and EndDate >= @Proc_Date       
       
  select @BalCF = FUNDBALANCE_PROV,@BalBF = FUNDBALANCE       
  FROM SCHEMEYEARS WHERE SCHEMENO = @SCHEMENO AND ACCTPERIOD = @ACCTPERIOD - 1      
      
  if @BalCF is null select @BalCF = 0      
  if @BalBF is null select @BalBF = 0      
    
  /* Receipts */     
  select @Premiums = sum(Receipt + UnReceipt)      
  from TBL_FundAdministration where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and TransDate <= @Proc_Date      
      
  if @Premiums is null select @Premiums = 0.0      
     
  /* Payments */    
  select @WithDrawals = sum(Payment + UnPayment)      
  from TBL_FundAdministration where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and TransDate <= @Proc_Date  
  and PaymentType = 0      
      
      
  if @WithDrawals is null select @WithDrawals = 0.0      
    
  /* Expenses */  
  select @Expenses = sum(Payment + UnPayment)      
  from TBL_FundAdministration where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and TransDate <= @Proc_Date  
  and PaymentType = 1   
     
  if @Expenses is null select @Expenses = 0.0      
      
  /* Population */  
  select @Population = count(m.MemberNo)      
  from Members m inner join MemberStatus a on m.ActiveStatus = a.StatusCode      
  where (m.SchemeNo =  @RelSchemeNo)  and ((m.ReasonForExit = 0)       
  OR ((M.ReasonForExit > 0) AND (m.ActiveStatus = 6) and (m.DeferredPaid = 0)))      
  and m.djpens <= @Proc_Date      
      
  if @Population is null select @Population = 0   
         
      
  Exec SchemeCard_Avg_COMP_Admin_Balance @schemeNo,@Proc_Date,0,@ValuationBalance Out,@Interest Out      
      
  if @ValuationBalance is null   
      select @ValuationBalance =0      
  if @Interest is null   
      select @Interest =0      
      
  if Exists (Select AcctPeriod from tbl_FundValuation where schemeNo = @schemeNo and ValMonth = @ValMonth and ValYear = @ValYear)      
            update tbl_FundValuation set BalCF = @BalCF,BalBf = @BalBF,Premiums = @Premiums,      
            WithDrawals = @WithDrawals,Population = @Population,ClosingBal = @ValuationBalance,      
            Expenses = @Expenses,Interest = @Interest      
            where schemeNo = @schemeNo and ValMonth = @ValMonth and ValYear = @ValYear      
  else      
     begin
         if @ValYear is null select @ValYear = 0
         if @AcctPeriod is null select @AcctPeriod = 0
  
          if ((@ValYear > 0) and (@AcctPeriod > 0))  
             begin  
                   Insert into tbl_FundValuation(SchemeNo,FiscalYear,AcctPeriod,BalCF,BalBF,Premiums,WithDrawals,Population,ClosingBal,ValYear,ValMonth,Expenses,      
                                   Interest)      
                   Values(@schemeNo,@AcctPeriod,@ValMonth,@BalCF,@BalBF,@Premiums,@WithDrawals,@Population,@ValuationBalance,@ValYear,@ValMonth,@Expenses,      
                     @Interest)  
             end  
     end      
        
  select @ValuationBalance = 0,@AcctPeriod = 0,@BalCF=0,@BalBF=0,@Premiums=0,@WithDrawals=0,@Population=0,@Expenses = 0.0,@Interest = 0.0      
      
  Fetch next from ValuationCsr Into @schemeNo      
end      
Close ValuationCsr      
Deallocate ValuationCsr
go

