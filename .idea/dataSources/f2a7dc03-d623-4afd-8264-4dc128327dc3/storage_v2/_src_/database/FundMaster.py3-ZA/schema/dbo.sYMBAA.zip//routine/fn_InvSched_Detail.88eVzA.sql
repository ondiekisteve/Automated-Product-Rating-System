CREATE FUNCTION [dbo].[fn_InvSched_Detail](@InvSchedHeader int)    
returns @tbl_var table(InvSchedHeader int not null,  
                       InvSchedDetail int not null primary Key,    
                       InvSchedHeaderDesc varchar(40) not null unique    
                       )    
as    
 begin  
  /* Default */
    
  if @InvSchedHeader = 0   
     insert into @tbl_var values(@InvSchedHeader, 0,'None')  
  /* Local Equities */  
  else if @InvSchedHeader = 1 
     begin   
     insert into @tbl_var values(@InvSchedHeader, 1,'Investments Value')   
     insert into @tbl_var values(@InvSchedHeader, 2,'Dividends')  
     insert into @tbl_var values(@InvSchedHeader, 3,'Capital Gains')  
     insert into @tbl_var values(@InvSchedHeader, 4,'Exchange Gains/Loss') 
     end
  /* Local Bond */  
  else if @InvSchedHeader = 2
     begin    
     insert into @tbl_var values(@InvSchedHeader, 1,'Investments Value')   
     insert into @tbl_var values(@InvSchedHeader, 2,'Interests')  
     insert into @tbl_var values(@InvSchedHeader, 3,'Capital Gains')
     insert into @tbl_var values(@InvSchedHeader, 4,'Exchange Gains/Loss')
     end   
  /* Local Fixed Interest */  
  else if @InvSchedHeader = 3
     begin    
     insert into @tbl_var values(@InvSchedHeader, 1,'Investments Value')   
     insert into @tbl_var values(@InvSchedHeader, 2,'Interests')  
     insert into @tbl_var values(@InvSchedHeader, 3,'Exchange Gains/Loss') 
     end
  /* Property */  
  else if @InvSchedHeader = 4 
     begin  
     insert into @tbl_var values(@InvSchedHeader, 1,'Investments Value')   
     insert into @tbl_var values(@InvSchedHeader, 2,'Rental Income')  
     insert into @tbl_var values(@InvSchedHeader, 3,'Exchange Gains/Loss')
     end 
  /* Offshore Equity */  
  else if @InvSchedHeader = 5
     begin   
     insert into @tbl_var values(@InvSchedHeader, 1,'Investments Value') 
     insert into @tbl_var values(@InvSchedHeader, 2,'Dividends')   
     insert into @tbl_var values(@InvSchedHeader, 3,'Capital Gains')  
     insert into @tbl_var values(@InvSchedHeader, 4,'Exchange Gains/Loss')
     end 
  /* Offshore Fixed Interest */  
  else if @InvSchedHeader = 6 
     begin 
     insert into @tbl_var values(@InvSchedHeader, 1,'Investments Value') 
     insert into @tbl_var values(@InvSchedHeader, 2,'Interests')   
     insert into @tbl_var values(@InvSchedHeader, 3,'Capital Gains')  
     insert into @tbl_var values(@InvSchedHeader, 4,'Exchange Gains/Loss')
     end 
  /* Cash */  
  else if @InvSchedHeader = 7
     begin  
     insert into @tbl_var values(@InvSchedHeader, 1,'Investments Value')   
     insert into @tbl_var values(@InvSchedHeader, 2,'Interests')  
     insert into @tbl_var values(@InvSchedHeader, 3,'Exchange Gains/Loss') 
     end
  
  return    
 end
go

