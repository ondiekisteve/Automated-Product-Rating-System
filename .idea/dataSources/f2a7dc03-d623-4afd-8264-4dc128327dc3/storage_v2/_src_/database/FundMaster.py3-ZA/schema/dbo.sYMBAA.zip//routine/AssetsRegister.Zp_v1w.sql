CREATE PROCEDURE [dbo].[AssetsRegister]
@SCHEMENO Int
--with Encryption
as

if object_id('tempdb..#AssetReg') is null

begin
create table #AssetReg
(
	[AssetNo] [int] NOT NULL ,
	[AssetClass] [int] NOT NULL ,
	[SchemeName] [varchar](120) not  NULL,
        [AssetName] [varchar](80),
        [AssetDesc][varchar](80),
        [AssetCost][float],
        [AssetDate][Datetime],
        [CurrValue][float],
        [Percentage][float]    
) 

ALTER TABLE #AssetReg WITH NOCHECK ADD 

            
	CONSTRAINT [PK_AssetReg] PRIMARY KEY  NONCLUSTERED 
	(
	  [AssetNo],
          [AssetClass]      
	) 
end


declare @AssetNo int,@AssetClass int,@SchemeName varchar(120),
        @AssetName Varchar(80),@AssetDesc varchar(80),@AssetCost float,@AssetDate Datetime,
        @CurrValue float,@Percentage float
declare Acsr cursor for
Select a.AssetNo,a.AssetClass,s.SchemeName, a.AssetName,a.AssetDesc,a.AssetCost,a.AssetDate
from Assets a
     inner join scheme s on a.schemeNo = s.SchemeCode
where a.SchemeNo = @schemeNo and a.Retired = 0

open acsr

fetch from acsr into @AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate

while @@fetch_Status = 0
begin
   if Exists(Select * from Depreciation where SchemeNo = @SchemeNo and PropertyCode = @AssetNo)
      begin
           Select @CurrValue = Value from Depreciation
           where SchemeNo = @SchemeNo and PropertyCode = @AssetNo and 
           PayCode = (Select Max(PayCode) from Depreciation where SchemeNo = @schemeNo and PropertyCode = @AssetNo) 
      end
   else
      select @CurrValue = @AssetCost


   if @CurrValue < @AssetCost
      Select @Percentage = ((@AssetCost - @CurrValue)/@AssetCost)*100.00000000
   else if @CurrValue > @AssetCost
      Select @Percentage = ((@CurrValue - @AssetCost)/@AssetCost)*100.0000000
   else
      Select @Percentage = 0.0

   insert into #AssetReg (AssetNo,AssetClass,SchemeName, AssetName,AssetDesc,AssetCost,AssetDate,CurrValue,Percentage)
               Values(@AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate,@CurrValue,@Percentage)  

     Select @CurrValue = 0

   fetch next from acsr into @AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate
end
Close Acsr
Deallocate Acsr


Select * from #AssetReg
go

