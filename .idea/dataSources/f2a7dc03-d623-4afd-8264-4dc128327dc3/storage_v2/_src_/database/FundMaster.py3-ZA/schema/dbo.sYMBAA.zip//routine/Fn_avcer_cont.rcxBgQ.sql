
CREATE FUNCTION [dbo].[Fn_avcer_cont](@schemeNo   INT,
                                      @MemberNo   INT,
                                      @AcctPeriod INT,
                                      @Registered INT)
returns FLOAT
AS
  BEGIN
      DECLARE @Cont     FLOAT,
              @Arrears  FLOAT,
              @Transfer FLOAT

      IF @Registered = 0
        SELECT @Cont = Sum(SpecialContr)
        FROM   contributionssummary
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod
      ELSE
        SELECT @Cont = Sum(ExcessSpecial)
        FROM   Unregisteredcontributionssummary
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod

      IF @Registered = 0
        SELECT @Arrears = Sum(ArSpecial)
        FROM   CONTRIBUTIONaRREARS
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod
      ELSE
        SELECT @Arrears = 0

      IF @Registered = 0
        SELECT @Transfer = Sum(avcERTransfer)
        FROM   MemberTransfer
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod
      ELSE
        SELECT @Transfer = Sum(avcERTransfer)
        FROM   MemberTransferUn
        WHERE  schemeNo = @schemeNo
               AND MemberNo = @MemberNo
               AND AcctPeriod = @AcctPeriod

      IF @Cont IS NULL
        SELECT @Cont = 0

      IF @Arrears IS NULL
        SELECT @Arrears = 0

      IF @Transfer IS NULL
        SELECT @Transfer = 0

      SELECT @Cont = @Cont + @Arrears + @Transfer

      RETURN ( @Cont )
  END

go

