CREATE PROCEDURE [dbo].[Import_Mukuba_POB]
@schemeNo int,
@DrawerNo varchar(20),
@PayDate datetime,
@Amount float,
@Month int,
@Year int,
@UserName varchar(50)
--with Encryption
as
declare @memberNo int,@DepCode int,@startDate datetime,@BankCode int,@from int,@to int

exec getFirstDate @month,@Year,@startDate out

select @MemberNo = memberno,@DepCode = 0 from pensioner where schemeNo = @schemeNo and Penno = @DrawerNo

if @MemberNo is null
   begin
     select @MemberNo = memberno,@DepCode = DependantCode 
     from penBeneficiary where schemeNo = @schemeNo and Penno = @DrawerNo

     if @MemberNo is null
        select @MemberNo = memberno,@DepCode = DependantCode 
        from MemBeneficiary where schemeNo = @schemeNo and Penno = @DrawerNo
   end 

IF @MemberNo is null select @MemberNo = 1
if @DepCode is null select @DepCode = 1

if @MemberNo > 1
begin                              
   select @From = LPONo,@To = LPONo from Payables                           
   where schemeNo = @schemeNo and MemberNo = @memberno and DependantCode = @DepCode and
   PayDate = @startDate and VoucherType = 22 and VoucherSubType = 10  and PayType = 4             
                             
                               
   if @From > 0                                  
      begin                                  
      Exec Proc_MassVouchers @SCHEMENO,@From,@To,@BankCode,0,0,0,@PayDate,@startDate,@UserName,' ',4,0   
      end
end
go

