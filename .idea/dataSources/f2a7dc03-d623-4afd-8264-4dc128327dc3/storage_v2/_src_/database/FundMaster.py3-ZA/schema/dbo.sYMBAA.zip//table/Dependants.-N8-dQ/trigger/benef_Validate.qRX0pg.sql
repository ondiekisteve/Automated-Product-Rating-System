create TRIGGER [dbo].[benef_Validate] on [dbo].[Dependants]          
--with encryption          
for insert       
as          
declare @currSum float          
declare @cSum varchar(50),@HasGuardian bit,@SchemeNo varchar(15),@MemberNo int,@DepCode Int,@Dob datetime          
          
select @SchemeNo = schemeNo,@MemberNo = MemberNo from Inserted          
          
select @currSum = sum(PcntBenefit) from Dependants          
where MemberNo = @MemberNo and SchemeNo = @SchemeNo      
        
              
select @HasGuardian = HasGuardian,@schemeNo = schemeNo,@MemberNo = MemberNo,@DepCode = DependantCode,          
       @Dob = Dob from Inserted          
          
          
if @currSum > 100          
begin          
  raiserror('Total Beneficiaries Entitlement cannot exceed 100 percent', 16, 1)          
  rollback transaction          
end    
    
/*          
          
         
declare @depType smallint          
declare @membSex char(1)          
declare @mStatus tinyint          
select @depType = DependantType from inserted          
select @mStatus = MStatus from inserted          
if (@depType = 1) or (@depType = 2)          
begin          
  if not ((@mStatus = 2) or (@mStatus = 3))          
  begin          
    raiserror('Member has a spouse. Marital status must be married or separated.', 16, 1)          
    rollback transaction          
  end          
end          
select @depType = DependantType from inserted          
          
          
select @membSex = Sex from Members          
where          
(Members.SchemeNo = (select SchemeNo from inserted)) and          
(Members.MemberNo = (select MemberNo from inserted))          
if ((@depType = 1) and (@membSex = 'F')) or ((@depType = 2) and (@membSex = 'M'))          
begin          
  raiserror('Member cannot be married to self.', 16, 1)          
  rollback transaction          
end          
*/          
         
declare @schemeJoin datetime          
select @schemeJoin = DJPenS from Members, inserted          
where          
(Members.SchemeNo = inserted.SchemeNo) and          
(Members.MemberNo = inserted.MemberNo)          
if @schemeJoin > (select DoApmt from inserted)          
begin          
  raiserror('Beneficiary''s DATE OF APPOINTMENT must be greater than member''s DATE OF JOINING SCHEME', 16, 1)          
  rollback transaction          
end          
          
/*         
declare @cancelDate datetime          
select @cancelDate = DOCancellation from inserted          
if @cancelDate is not null          
begin          
  if @cancelDate > (select DOApmt from inserted)          
  begin          
    raiserror('Beneficiary''s DATE OF CANCELLATION must be greater than beneficiary''s DATE OF APPOINTMENT', 16, 1)          
    rollback transaction          
  end          
end          
          
*/          
          
if (select DOB from inserted) > getdate()          
begin          
  raiserror('DATE OF BIRTH cannot be greater than today', 16, 1)          
  rollback transaction          
end          
if (select DOApmt from inserted) > getdate()          
begin          
  raiserror('DATE OF APPOINTMENT cannot be greater than today', 16, 1)          
  rollback transaction          
end          
if (select DOCancellation from inserted) > getdate()          
begin          
  raiserror('DATE OF CANCELLATION cannot be greater than today', 16, 1)          
  rollback transaction          
end          
          
/*          
if ((@DepType <> 11) and (@DepType <> 12) and ((datediff(Month,@Dob,Getdate())/12) <18) and (@HasGuardian = 0))          
   select @HasGuardian = 1          
          
if @HasGuardian = 0          
   update Dependants set Guardian = 0 where DependantCode = @DepCode and MemberNo = @MemberNo and SchemeNo = @schemeNo          
else          
   update Dependants set Guardian = 1 where DependantCode = @DepCode and MemberNo = @MemberNo and SchemeNo = @schemeNo          
          
if ((@DepType <> 11) and (@DepType <> 12) and ((datediff(Month,@Dob,Getdate())/12) <18) and (@HasGuardian = 0))          
begin       
  raiserror('The Beneficiary is less than 18 and therefore Cannot be a Guardian', 16, 1)          
  rollback transaction          
end             
*/
go

