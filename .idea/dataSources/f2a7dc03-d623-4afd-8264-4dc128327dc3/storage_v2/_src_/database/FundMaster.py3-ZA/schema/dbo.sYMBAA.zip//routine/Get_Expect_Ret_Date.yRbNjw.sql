CREATE PROCEDURE [dbo].[Get_Expect_Ret_Date]
@SCHEMENO Int,
@MemberNo Int,
@RetDate Datetime Out
--with Encryption
as
declare @CompanyId SmallInt,@Dob Datetime,@Sex varchar(1),@RetirementAge Int
select @CompanyId = CompanyId,@Dob = Dob,@Sex = Sex 
from Members where schemeNo = @schemeNo and MemberNo = @MemberNo

if @Sex is null select @Sex = 'M'

IF @Sex = 'M'
   SELECT @RetirementAge = MRetAge from RetirementAges
   where schemeNo = @schemeNo and CompanyId = @CompanyId 
else
   SELECT @RetirementAge = FRetAge from RetirementAges
   where schemeNo = @schemeNo and CompanyId = @CompanyId 

Select @RetDate = DateAdd(Year,@RetirementAge,@Dob)
go

