CREATE VIEW [dbo].[V_TBL_BATCH_MOVEMENTS]        
AS        
Select Batch_Id,SchemeNo,BatchDate,BatchDesc,Status,Posted,Checked,Authorised,HasPaypoint,GrossBenefit,        
case Posted when 0 then 'No' when 1 then 'Yes' end as BPosted,        
case Checked when 0 then 'No' when 1 then 'Yes' end as BChecked,        
case Authorised when 0 then 'No' when 1 then 'Yes' end as BAuthorised,  
case BenefitSchedHasTax when 0 then 'Gross and Tax' when 1 then 'Gross Only' end as BenefitSchedMode,
User_No        
from TBL_BATCH_MOVEMENTS
go

