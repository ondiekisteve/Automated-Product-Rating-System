CREATE PROCEDURE [dbo].[RepClosingBalance]
@SCHEMENO Int,
@curMonth int,
@schemeYear int
--with Encryption
as

if object_id('tempdb..#ClosingBalances') is null

begin
create table #ClosingBalances
(
	[SchemeNo] [varchar] (15) NOT NULL ,
             [memberNo][int] not null,
             [schemeYear][int] not null,
             [fullname][varchar] (50) not null,
             [opEmpBal][float] null,
             [opEmprBal][float] null,
             [empcont][float] null,
             [emprcont][float] null,
             [cEmpBal][float] null,
             [cEmprBal][float] null,
             [empInt][float] null,
             [emprInt][float] null,
             [grandTotal][float] null,
             [withdrawal][float] null,
             [surplus][float] null,
             [EndingPeriod][varchar](30) null
)        

ALTER TABLE #ClosingBalances WITH NOCHECK ADD 

            
	CONSTRAINT [PK_ClosingBalances] PRIMARY KEY  NONCLUSTERED 
	(
		[SchemeNo],
		[memberNo],
                           [schemeYear]      
	) 
end

declare @memberNo int
declare @cEmpBal float
declare @cEmprBal float
declare  @opEmpBal float
declare @opEmprBal float
declare @empcont float
declare @emprcont float
declare @fullname varchar(50)
declare @withdrawal float
declare @surplus float
declare @totSurplus float
declare @curPeriod varchar(30)
declare @AcctPeriod int
declare @EmpVolCont float
declare @EmprVolCont float

select @totSurplus = 0

exec GetEndingPeriod @curMonth, @curPeriod out
select @curPeriod = @curPeriod +' '+ cast(@schemeYear as varchar(4))

exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @schemeYear, @AcctPeriod out

declare ClosingCsr cursor for

SELECT m.schemeNo, m.memberNo, m.schemeYear, (m.empCont + m.empVolcont + m.PreEmpCont + m.PreAvc) as cEmpBal
             , (m.emprCont + m.emprVolcont + m.PreEmprCont)  as cEmprBal,
                upper(mm.sname) + ','+mm.fname+' '+mm.onames as Fullname
              FROM MemberOpeningBalances  m
               inner join members mm on m.schemeNo = mm.schemeNo 
        and m.memberNo = mm.memberNo      
where m.SchemeNo = @schemeNo and m.AcctPeriod = @AcctPeriod

order by  m.schemeNo, m.memberNo


open ClosingCsr

fetch from ClosingCsr into @schemeNo, @memberNo, @schemeYear, @cEmpBal, @cEmprBal, @fullname 


while @@fetch_status = 0
begin
      
      exec RepMemberCertificateContributions @schemeNo, @MemberNo, @curMonth, @schemeYear, @EmpCont out, @EmprCont out, @EmpVolCont out, @EmprVolCont out
     
      Select @EmpCont = @EmpCont + @EmpVolCont
      Select @EmprCont = @EmprCont + @EmprVolCont

      select @opEmpBal = 0
      select @opEmprBal = 0   

      select @opEmpBal = empcont + empVolCont + PreEmpCont + PreAvc  from memberOpeningbalances 
      where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @AcctPeriod-1
      
      if @opEmpBal is null 
         begin
                 select @opEmpBal = 0
         end

      select @opEmprBal = emprcont + emprVolCont + PreEmprCont  from memberOpeningbalances 
      where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @AcctPeriod-1
      
         if @opEmprBal is null 
         begin
                 select @opEmprBal = 0
         end
      
       select @withdrawal = (EmpcBal + EmprcBal + VolCBal + SpecialCBal + PreEmpCBal + PreEmprCBal + PreAVCCBal) 
       from Benefits 
       where ((SchemeNo = @schemeNo) and (MemberNo = @MemberNo) and (CalcYear = @schemeYear))
      
      if @withdrawal is null select @withdrawal =0

      if @withdrawal = 0
          select @surplus = 0
      else
          select @surplus = ((@cEmpBal + @cEmprBal) - @withdrawal)

      insert into #ClosingBalances (schemeNo, memberNo, schemeYear, fullname, opempbal,opEmprBal, empcont, emprCont, cEmpBal, cEmprBal, empInt, emprInt, grandtotal, withdrawal, surplus, EndingPeriod)

                      values(@schemeNo, @memberNo, @schemeYear, @fullname, @opEmpbal, @opEmprBal, @empCont, @emprCont, @cEmpBal, @cEmprBal, (@cEmpBal- (@opEmpBal+@empCont)), (@cEmprBal - (@opEmprBal + @emprCont)), (@cEmpBal + @cEmprBal),@withdrawal, @surplus, @curPeriod)
     
     select @totSurplus = @totSurplus + @SurPlus
     
     select @withdrawal = 0
     select @surplus = 0
     Select @EmpCont = 0
     Select @EmprCont = 0

fetch next from closingCsr into @schemeNo, @memberNo, @schemeYear, @cEmpBal, @cEmprBal, @fullname

end

close ClosingCsr
deallocate ClosingCsr


     if (select count(*) from surplus where SchemeNo = @schemeNo and schemeYear = @schemeYear)  = 0
          insert into surplus(schemeNo, schemeYear, surplus) values(@schemeNo, @schemeYear, @Totsurplus)
     else
         update surplus set surplus = @totsurplus where SchemeNo = @schemeNo and schemeYear = @schemeYear


select * from #closingBalances
go

