CREATE PROCEDURE [dbo].[RepBenefitsCalculations_DB_NSSF]
@SCHEMENO Int,
@CalcMonth int,
@CalcYear int
 --with Encryption
as

if object_id('tempdb..#BenefitsCalculation') is null

begin
create table #BenefitsCalculation
(
        [EmpCode][Int] Identity(1,1) Primary Key,
        [SchemeNo] [varchar] (15) NOT NULL ,
        [schemeName][varchar](100) not null,
        [MemberNo] [int] NOT NULL ,
        [PayrollNo][Varchar](20),
        [fullname][varchar](100) not null, 
        [djPens][datetime] not null,
        [Salary][float] not null,
        [Gratuity][float],
        [Reduced][float],
        [UnReduced][float],
        [RetDate][Datetime] not null, 
        [PastService][varchar](40) null,
        [EndingPeriod][Varchar](30) null
      
)      
end

declare @schemeName varchar(100)
declare @MemberNo int
declare @fullname varchar(100) 
declare @Gratuity float,@Reduced float,@UnReduced float,@Years int,@Months int,@AcctPeriod int
declare @MonthName varchar(15)
declare @schemeYear int
declare @Salary float
declare @ExpectRet datetime
declare @djpens datetime
declare @PastService varchar(30)
declare @curPeriod varchar(30),
@MwishoDate Datetime,@BalanceofInt smallInt,@StartDate Datetime,@EndDate Datetime,@PayrollNo Varchar(20),@days Int,
@GratuityJuu float,@ReducedJuu float,@UnReducedJuu float

Exec GetLastDate @CalcMonth,@CalcYear,@MwishoDate out

select @MonthName = MonthName from MonthTable where MonthNumber = @CalcMonth
select @SchemeName = schemeName from Scheme where schemeCode = @schemeNo

exec GetEndingPeriod @calcMonth, @curPeriod out
select @curPeriod = @curPeriod +' '+ cast(@CalcYear as varchar(4))

Exec GetAccountingPeriodInAYear @schemeNo,@CalcMonth,@CalcYear,@AcctPeriod out

Select @StartDate = StartDate,@EndDate = EndDate from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod
Select @BalanceofInt = CalcBalanceofInterest from ConfigYearEnd where SchemeNo = @schemeNo
if @BalanceofInt is null select @BalanceofInt = 0

if @BalanceofInt = 1 /* Balance of Interest on withdrawals */
begin
declare BenCsr cursor for 
select distinct m.schemeNo, m.memberNo, e.ExpectRet,
          (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname, m.djpens, m.CapenSal,m.PayrollNo
from Members m
         inner join ExpectRet e on m.SchemeNo = e.schemeNo and m.memberNo = e.memberNo 
where m.SchemeNo = @schemeNo and 
        ((m.ReasonForExit = 0)
        or 
        ((m.ReasonforExit > 0) and (m.DoExit >= @StartDate and m.DoExit < @EndDate))
        or
        (m.ReasonforExit > 0 and m.DoExit >= @EndDate))
order by m.memberNo
END
ELSE if @BalanceofInt = 0 /* Balance of Interest on withdrawals */
begin
declare BenCsr cursor for 
select distinct m.schemeNo, m.memberNo, e.ExpectRet,
          (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname, m.djpens, m.CapenSal,m.PayrollNo 
from Members m
         inner join ExpectRet e on m.SchemeNo = e.schemeNo and m.memberNo = e.memberNo 
where m.SchemeNo = @schemeNo and 
        ((m.ReasonForExit = 0)
        or 
        (m.ReasonforExit > 0 and m.DoExit >= @EndDate))
order by m.memberNo
END

open BenCsr

fetch from BenCsr into @schemeNo, @MemberNo, @ExpectRet, @fullname, @djpens,@Salary,@PayrollNo

while @@fetch_status = 0
begin
  Exec GetPercentageTime @djpens, @ExpectRet,@Years out,@Months out,@Days Out

  Exec CalcPercentageBenefits_NSSF @schemeNo,@MemberNo, @Salary,@ExpectRet, @Gratuity out,@Reduced out,@UnReduced out,
  @GratuityJuu out,@ReducedJuu out,@UnReducedJuu out
    
  Select @PastService = Cast(@Years as Varchar(3))+ ' Years and '+cast(@Months as varchar(3))+' Months'

  if @PayrollNo is null select @PayrollNo = @MemberNo
  insert into #BenefitsCalculation (schemeNo, schemeName, memberNo, fullname, Gratuity, Reduced, UnReduced, RetDate, Salary, djpens, PastService, EndingPeriod)
  values(@schemeNo, @schemeName, @memberNo,@fullname, @Gratuity,@Reduced,@UnReduced,  @ExpectRet, @Salary, @djpens, @PastService, @CurPeriod)
  
  select @PayrollNo = ''
  fetch next from BenCsr into @schemeNo, @MemberNo, @ExpectRet, @fullname, @djpens,@Salary,@PayrollNo
end

close BenCsr
deallocate BenCsr   

select * from #BenefitsCalculation order by MemberNo
go

