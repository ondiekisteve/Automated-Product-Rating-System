CREATE PROCEDURE [dbo].[Proc_Get_Hanging_Accounts]
@schemeNo Int,
@RBA Int
--with Encryption
as
if @RBA = 0
   Select AccountCode,ltrim(rtrim(GLAccount)) as AccountName from GLAccountCodes where SchemeNo = @schemeNo
   and AccountType = 2 and Parent_Level_Code not in (select Parent_Level_Code from tbl_Net_Assets where schemeNo = @schemeNo)
go

