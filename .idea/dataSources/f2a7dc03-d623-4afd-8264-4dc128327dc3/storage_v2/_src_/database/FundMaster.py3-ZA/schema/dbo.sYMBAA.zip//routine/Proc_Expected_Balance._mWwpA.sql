CREATE PROCEDURE [dbo].[Proc_Expected_Balance]  
@BatchNo Int,
@SponsorCode Int 
as  
declare @Expected float,@Received float  
  
select @Expected = EmpCont + EmprCont + AVC + AVCER from TBL_ExpectedBatches  
where BatchNo = @BatchNo  and SponsorCode = @SponsorCode
  
select @Received = sum(ReceiptAmount) from TBL_ExpectedContributions_Rec  
where BatchNo_FK = @batchNo and SponsorCode = @SponsorCode  
  
if @Expected is null select @Expected = 0  
if @Received is null select @Received = 0  
  
select @Expected as Expected,@Received as Received,@Expected - @Received as variance
go

