/*                                          
MODIFICATIONS:                                          
11/03/2004                                          
                                          
Added :                                          
           Fields:                                          
           PreparedBy,CheckedBy,AuthorisedBy                                          
           Variables:                                          
           @PreparedBy,@CheckedBy,@AuthorisedBy                                          
           Code:                                          
           select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo                                          
           Insert these extra fields in the Temp Table                                          
*/                                          
                                          
CREATE PROCEDURE [dbo].[RepCalculationSheet_Deferred]                                          
@SCHEMENO Int,                                          
@memberNo int,                                          
@Mode Int,                                          
@RegMode Int                                          
--with Encryption                                          
as                                          
                                          
set nocount on                                          
                                          
if object_id('tempdb..#Calculation') is null                                          
                                          
begin                                          
create table #Calculation                                          
(                                          
    [SchemeNo] Int NOT NULL ,                                          
    [MemberNo] [int] NOT NULL ,                                          
           [schemeName][varchar](100) not null,                                          
           [fullname][varchar](100) not null,                                          
           [DJE][Datetime] not null,                                          
           [djpens][datetime] not null,                                          
    [EmpOpeningBal] [Decimal](20,2) NULL ,                                          
           [EmprOpeningBal][Decimal] (20,2) NULL,                                           
    [EmpContributions] [Decimal] (20,2)  NULL ,                                          
           [EmprContributions] [Decimal] (20,2)  NULL ,                                           
           [EmpClosing][Decimal] (20,2) Not null,                                          
           [EmprClosing][Decimal] (20,2) Not null,                                          
           [interest] [Decimal] (20,2)  NULL ,                                          
           [DateOfExit][datetime] not null,                                          
    [curYear] [int]  ,                                          
    [PastService] [Varchar](100) not NULL,                                          
                [BenefitsDC] [Decimal] (20,2)  NOT NULL ,                                          
                [Vesting][Decimal] (20,2)null,                                          
                [TaxfreeLumpsum][Decimal] (20,2)null,                                          
                [WithHoldingTax][Decimal] (20,2)null,                                          
                [comments][varchar](50) null,                                          
                [empInt][Decimal] (20,2) not null,                                          
                [emprInt][Decimal] (20,2) not null,                                          
                [AmountPayable][Decimal] (20,2) not null,                                          
                [TaxableAmount][Decimal] (20,2) not null,                           
                [Reason][Varchar](50) null,                                                        [EndDate][Datetime],                                          
                [PreparedBy][varchar](100),                                          
                [CheckedBy][varchar](100),               
                [AuthorisedBy][varchar](100),                                          
                [ClosingBalance][Decimal] (20,2),                                          
                [Bonus][Decimal] (20,2),                 
                [TransferCBal][decimal](12,2),                                          
                [TransferOpBal][decimal](12,2),                                          
                [TransferCont][decimal](12,2),                                          
                [TransferInt][decimal](12,2),                                          
                [TransferDesc][Varchar](20),                                          
                [AdditionDesc][Varchar](50),                                          
                [DoCalc][Datetime],                                          
                [VestedCont][float],                                          
                [AuditedBy][Varchar](100),                                          
                [DateAudited][Datetime],                                          
                [doBirth][Datetime],                                          
                [TransferCBalE][decimal](12,2),                                          
                [TransferOpBalE][decimal](12,2),                                          
                [TransferContE][decimal](12,2),                                
                [TransferIntE][decimal](12,2),                                          
                [LockedTransfer][decimal](12,2),                                          
                [DatePrepared][Datetime],                                          
                [DateChecked][Datetime],                                          
                [DateAuthorised][Datetime],                                      
                [PoolName][varchar](120) null,                    
                [TotalInterest][float],                    
                [CorporateTax][float],                    
                [NetInterest][float],            
                [Perc_Paid][float],            
                [TotalDue][float]                                          
)                                           
                                          
ALTER TABLE #Calculation WITH NOCHECK ADD                                                       
 CONSTRAINT [PK_Calculation] PRIMARY KEY  NONCLUSTERED                                           
 (                                          
  [SchemeNo],                                          
  [memberNo]                                                
 )                                           
end                                          
                                          
                                          
declare @fullname varchar(100)                                          
declare @schemeName varchar(100)                                          
declare @empopening Decimal(20,6)                                          
declare @emprOpening Decimal(20,6)                                          
declare @empContribution Decimal(20,6)                                          
declare @emprContribution Decimal(20,6)                                          
declare @empClosing Decimal(20,6)                                          
declare @emprClosing Decimal(20,6)                                          
declare @interest Decimal(20,6)                                          
declare @DateOfExit datetime                                         
declare @pastService int                                          
declare @BenefitsDC Decimal(20,6)                            
declare @vesting Decimal(20,6)                                          
declare @taxfreelumpsum Decimal(20,6)                                          
declare @withHoldingTax Decimal(20,6)                                      
declare @dje datetime                                          
declare @djpens datetime                                          
declare @curYear int                                          
declare @comments varchar(50)                                          
declare @VestedCont Decimal(20,6)                                          
declare @EmpInt Decimal(20,6)                                          
declare @Emprint Decimal(20,6)                                          
declare @GrandTotal Decimal(20,6)                                          
declare @TaxAmount Decimal(20,6)                                          
declare @Doexit datetime            
declare @CurMonth int                                          
declare @AcctPeriod int,  @eDate datetime, @sDate datetime, @DoCalc datetime, @sMonth int, @datePaid datetime                                          
declare @Year int, @Month int, @Days int,@Reason Varchar(50), @rExit Int,@EndDate Datetime,@taxType Int,@DesignCode Int,@Title varchar(20),                                          
@PreparedBy varchar(100),@CheckedBy varchar(100),@AuthorisedBy varchar(100),@Bonus Decimal(20,6),@ClosingBalance Decimal(20,6),                                          
@NumDays Int,@NumMonths Int,@NumYears Int,@ServiceTime Varchar(100),@TransferCBal Decimal(20,6),                                          
@TransferOpBal Decimal(20,6),@TransferInt Decimal(20,6),@TransferDesc varchar(20),                                          
@AdditionDesc varchar(50),@DeductNSSF smallInt,@ConversionDate Datetime,@NSSF2Deduct float,@MwishoDate Datetime,                                          
@mMonth Int,@mYear Int,@YaConversion varchar(25),@Chapaa Decimal(20,6),@Pre90 FLOAT,                                          
@TransferCont Decimal(20,6),@TransferSeparate bit,@HasFrozen smallInt,@FrozenDate Datetime,                                          
@OptionToUSe Int,@AuditedBy vARCHAR(100),@DateAudited Datetime,@ActiveStatus Int,@DoBirth Datetime,                                          
@BenefitMode Int,@ArEmpCont float,@ArEmprCont float,                                          
@TransferCBalE Decimal(20,6),@TransferOpBalE Decimal(20,6),@TransferIntE Decimal(20,6),@TransferContE Decimal(20,6),                                          
@LockedTransfer Decimal(20,6),@DatePrepared Datetime,@DateChecked Datetime,@DateAuthorised Datetime,                                        
@zambia smallInt,@TaxEmployee Decimal(20,6),@PooledInvestment smallInt,@InvestmentScheme Int,@PoolName varchar(120),                                  
                                              
@TaxRateDiff smallint,@TaxRet smallint,@TaxPension smallint,@TaxWith smallint,@TaxDeath smallint,@TaxMedical smallint,                                          
@Employee float,@Employer float,@TaxEmployer float,@DeferredPaid smallInt,@TaxFree_Portion float,                    
@TotalInterest float,@TotalTax float,@NetInterest float,@AmountPayable float,@Perc_Paid float,@AmountPaid float,@TotalDue float,            
@ErRate float,@MaxDate datetime,@AcctPeriod1 Int,@zMonth Int,@zYear Int                            
                                
                                
SELECT @TaxFree_Portion = SUM(TaxFree_Portion),@Perc_Paid = sum(Perc_Paid),@AmountPaid = sum(AmountPaid),@MaxDate = Max(DatePaid),            
@ErRate = sum(ErRate)                   
FROM PARTIALPAYMENT WHERE SCHEMENO = @schemeNo AND MEMBERNO = @MemberNo                                 
                                
if @TaxFree_Portion is null select @TaxFree_Portion = 0                  
IF @Perc_Paid is null select @Perc_Paid = 0             
if @AmountPaid is null select @AmountPaid = 0            
                                                                         
select @LockedTransfer = 0.0                                          
                                          
Select @BenefitMode = BenefitMode from ConfigDeathInService where SchemeNo = @schemeNo                                          
                       
select @HasFrozen = HasFrozen,@FrozenDate  = FrozenDate,@zambia = Zambia,@PooledInvestment = PooledInvestment,                                  
 @InvestmentScheme = InvestmentScheme,@TaxRateDiff=TaxRateDiff,@TaxRet=TaxRet,                                                    
 @TaxPension=TaxPension,@TaxWith = TaxWith,@TaxDeath = TaxDeath ,@TaxMedical = TaxMedical                                  
 from Scheme where schemeCode = @schemeNo                                      
                                      
if @PooledInvestment = 1                                                
select @PoolName = schemeNAME FROM Scheme where schemeCode = @InvestmentScheme                                                 
else if @PooledInvestment = 0                                                
select @PoolName = ' '                                        
                                          
if @HasFrozen is null select @HasFrozen = 0                                        
if @zambia is null select @zambia = 0                                         
                                          
select @DeductNSSF = DeductNSSF,@ConversionDate= ConversionDate,                                          
@TransferSeparate = TransferSeparate                                          
from ConfigWithdrawal where SchemeNo = @schemeNo                                          
                                          
if @DeductNSSF is null select @DeductNSSF = 0                                          
if @TransferSeparate is null select @TransferSeparate = 0                                          
                                          
if @DeductNSSF = 1                                          
   SELECT @NSSF2Deduct = sum(nssfe) from Contributionssummary where                                          
   SchemeNo = @schemeNo and MemberNo = @MemberNo and DatePaid <= @ConversionDate                                          
                                          
if @NSSF2Deduct is null select @NSSF2Deduct = 0.0                                          
                             
                                          
if @DeductNSSF = 1                                          
   select @AdditionDesc = 'Less: NSSF (Employer) at Conversion Date'                                          
else                                          
   select @AdditionDesc = 'Additional Benefit'                                          
                                          
select @TransferDesc = 'Trans Values'                                          
                                          
                                          
select @schemeName = schemeName from scheme where schemeCode = @schemeNo                                          
                                          
if @RegMode = 0                                          
begin                                          
if @Mode = 0 /* Normal Registered */                                          
begin                                          
declare GenCursor cursor for                                          
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                           
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,                                          
       b.calcYear, b.interestrate, b.empCBal + b.PreEmpCBal, b.emprCBal + B.PreEmprCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting, b.comments,                                          
             (b.EmprCBal + b.PreEmprCBal)* (b.Vesting/100.0000),b.Bonus,                                          
                         b.EmpTransferCBal,b.EmprTransferCBal + b.DeferredCBal,B.PreEmpCBal + B.PreEmprCBal,                                          
                     m.ActiveStatus,0,0                                          
             from Members m                                          
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                               --inner join ##LoadMembers l on m.schemeNo = l.schemeNO and m.memberNo = l.memberNo         
  
                                 
where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                          
end                                          
else if @Mode = 1 /* Registered Combined */                                          
begin                                          
declare GenCursor cursor for                                          
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                            
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,                                          
               b.calcYear, b.interestrate, b.empCBal + b.VolCBal + b.PreEmpCBal+ b.PreAVCCBal,                     
                         b.emprCBal + b.SpecialCBal + PreEmprCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting,                                          
                         b.comments,(b.EmprCBal + b.SpecialCBal + b.PreEmprCBal)* (b.Vesting/100.000),                           
                         b.Bonus,b.EmpTransferCBal,b.EmprTransferCBal + b.DeferredCBal,B.PreEmpCBal + B.PreEmprCBal + B.PreAVCCBal,                                          
                         m.ActiveStatus,0,0                                          
             from Members m                                           
               inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                          
                       --inner join ##LoadMembers l on m.schemeNo = l.schemeNO and m.memberNo = l.memberNo                                          
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                          
end                                          
                                          
else if @Mode = 2 /* Registered Combined Projections*/                                          
begin                                          
declare GenCursor cursor for                                          
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.Projectdoexit,                                           
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,                                          
               b.calcYear, b.interestrate, b.empCBal + b.VolCBal + b.PreEmpCBal+ b.PreAVCCBal,                                           
                         b.emprCBal + b.SpecialCBal + PreEmprCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting,                                           
                         b.comments,(b.EmprCBal + b.SpecialCBal + b.PreEmprCBal)* (b.Vesting/100.00),                                          
                         b.Bonus,b.EmpTransferCBal,b.EmprTransferCBal + b.DeferredCBal,B.PreEmpCBal + B.PreEmprCBal + B.PreAVCCBal,                                          
                         m.ActiveStatus,0,0                                          
             from Members m                                          
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                          
                       --inner join ##LoadMembers l on m.schemeNo = l.schemeNO and m.memberNo = l.memberNo                                          
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                          
                         
end       
end                                          
else if @RegMode = 1                                          
begin                                          
if @Mode = 0 /* Normal Registered */                                          
begin                                       
                                  
declare GenCursor cursor for                                          
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                              
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,                                          
              b.calcYear, b.interestrate, ub.EEMPCBAL, ub.EEMPRCBAL, ub.withholdingTax,                     
              b.taxfreeLumpsum, b.vesting, b.comments,                                          
             (ub.EEMPRCBAL)* (b.Vesting/100.0000),b.Bonus,0,0,0,                                          
              m.ActiveStatus,Ub.EmprInt + Ub.SpecInt,ub.CEmprTax + Ub.CSpecTax                                          
             from Members m                                          
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                          
                       inner join UnRegisteredBenefits ub on m.schemeNo = ub.schemeNO and m.memberNo = ub.memberNo                                          
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                           
end                                          
else if @Mode = 1 /* Registered Combined */                                          
begin                                          
declare GenCursor cursor for                                          
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                           
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,                                          
    b.calcYear, b.interestrate, ub.EEMPCBAL + ub.EVOLCBAL,                                           
                         ub.EEMPRCBAL + ub.ESPECIALCBAL, ub.withholdingTax, 0.0, b.vesting,                                          
          b.comments,(ub.EEMPRCBAL + ub.ESPECIALCBAL)* (b.Vesting/100.000),                                          
                         b.Bonus,0,0,0,                                          
                         m.ActiveStatus,Ub.EmprInt + Ub.SpecInt,ub.CEmprTax + Ub.CSpecTax                    
             from Members m                                          
               inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                          
               inner join UnRegisteredBenefits ub on m.schemeNo = ub.schemeNO and m.memberNo = ub.memberNo                                          
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                          
                                          
                                          
end                                          
                                          
else if @Mode = 2 /* Registered Combined Projections*/                                          
begin                                          
declare GenCursor cursor for                                          
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                           
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,                                          
               b.calcYear, b.interestrate, ub.EEMPCBAL + ub.EVOLCBAL,                                           
  ub.EEMPRCBAL + ub.ESPECIALCBAL, ub.withholdingTax, 0.0, b.vesting,                                          
                         b.comments,(ub.EEMPRCBAL + ub.ESPECIALCBAL)* (b.Vesting/100.000),                                          
                         b.Bonus,0,0,0,                                      
                         m.ActiveStatus,Ub.EmprInt + Ub.SpecInt,ub.CEmprTax + Ub.CSpecTax                                          
             from Members m                                          
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                          
                       inner join UnRegisteredBenefits ub on m.schemeNo = ub.schemeNO and m.memberNo = ub.memberNo                                          
      where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                          
                                                 
end                                          
end                            
open GenCursor                                          
                                           
fetch from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @fullname,@curYear, @interest,                                          
 @EmpClosing,@emprClosing,@withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont,@Bonus,@TransferCBal,                      
 @TransferCBalE,@Pre90,@ActiveStatus,@TotalInterest,@TotalTax                                          
                                                     
while @@fetch_status =0                                          
begin                                                  
                               
     select @taxfreeLumpsum = @taxfreeLumpsum * ((100.00 - @TaxFree_Portion)/100.000)                                
                              
     select @Employee = @EmpClosing +  @TransferCBal, @Employer = @emprClosing + @TransferCBalE             
                                          
     if @Zambia = 1                                        
        select @OptionToUse = 1                                        
     else                                        
        Exec EmployerOption @schemeNo,@MemberNo,@OptionToUse Out /* PROCEDURE DBO.to Incorporate Budget changes 2005 */                                          
                                          
     Select @OptionToUse = 0                                          
                                          
     select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy,                                         
     @AuditedBy = AuditedBy,@DateAudited = DateAudited,                                          
     @DatePrepared = DatePrepared,@DateChecked = DateChecked,@DateAuthorised  = DateAuthorised                                           
     from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo                            
                                          
     if @Mode < 2                                          
        Select @DoCALC = DOCalc,@Doexit = Doexit,@rExit=ReasonforExit,@DesignCode = DesignCode,@DoBirth = dob             
        from Members             
        where SchemeNo = @schemeNo and MemberNo = @MemberNo                                          
     else                                          
        Select @DoCALC = ProjectDOCalc,@Doexit = ProjectDoexit,@rExit=ProjectReason,@DesignCode = DesignCode,@DoBirth = dob             
        from Members             
        where SchemeNo = @schemeNo and MemberNo = @MemberNo                 
            
                                                               
    if @DesignCode is null select @DesignCode = 0                                          
    if @DoCalc is null select @DoCalc= @DoExit                                          
                                          
                                          
    if @DoExit > @DoCalc                                          
       select @DoCalc = @DoExit                                          
                                          
    select @CurMonth = datepart(Month, @DoCalc)                                          
    select @curYear = datepart(Year, @DoCalc)                                          
                                          
    exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out             
            
    if @MaxDate is not null            
       begin            
         select @zMonth = datepart(Month,@MaxDate),@zYear = datepart(Year,@MaxDate)            
         exec GetAccountingPeriodInAYear @schemeNo, @zMonth, @zYear, @AcctPeriod1 out            
       end            
    else select @AcctPeriod1 = @AcctPeriod                                         
                                          
    select @EndDate = EndDate from SchemeYears where SchemeNo = @SchemeNo and AcctPeriod = (@AcctPeriod - 1)                                          
                                          
    Select @eDate = EndDate,@sDate = StartDate from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod                                          
                                          
    Select @MwishoDate = @eDate                                          
                                          
                                          
     if @HasFrozen = 0                                          
        select @Pre90 = 0                                          
     else if @HasFrozen = 1                                          
      begin                                          
           if @FrozenDate <= 'Dec 31,1990'                                          
              Select @Pre90 = @Pre90                                          
           else                                          
              select @Pre90 = 0                                          
       end                                          
                                          
     if @Bonus is null select @Bonus = 0                                          
                                          
                                           
     select @eDate = @DoExit                                          
                                       if @RegMode = 0                                          
     begin                    
      if @Mode = 0                                          
         begin                                         
                Select @EmpOpening = empCont + PreEmpCont, @EmprOpening = EmprCont + PreEmprCont,                          
                       @TransferOpBal = Transfer, @TransferOpBalE = lockedIn + DeferredAmt                                          
                from MemberOpeningBalances                                           
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                          
                                               
                select @empContribution = sum(empcont)                                           
                from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                               and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                select @emprContribution = sum(emprcont)                                           
                from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                                
                select @ArEmpCont = sum(Arempcont)                                           
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
         and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                              
                select @ArEmprCont = sum(Aremprcont)                                           
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                if @ArEmpCont is null select @ArEmpCont = 0                                          
                if @ArEmprCont is null select @ArEmprCont = 0                                          
                                          
                Select @TransferCont = sum(EmpTransfer),@TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                          
                where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                          
                                          
                IF @TransferCont IS NULL select @TransferCont = 0                                          
                IF @TransferContE IS NULL select @TransferContE = 0                                          
                                                         
        end                                          
      else if @Mode = 1                                          
         begin                              
      Select @EmpOpening = empCont + EmpVolCont + PreEmpCont + PreAVC,                                           
                 @EmprOpening = EmprCont + EmprVolCont + PreEmprCont,@TransferOpBal = Transfer,                           
                 @TransferOpBalE = LockedIn + DeferredAmt                                         
                 from MemberOpeningBalances                                           
                 where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                          
                                               
                select @empContribution = sum(empcont + VolContr)                                           
                from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                          
                                          
                select @emprContribution = sum(emprcont + SpecialContr)                                           
                from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                          
                                          
                select @ArEmpCont = sum(Arempcont)                                           
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                select @ArEmprCont = sum(Aremprcont)                                
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                if @ArEmpCont is null select @ArEmpCont = 0                                          
         if @ArEmprCont is null select @ArEmprCont = 0               
                                          
                Select @TransferCont = sum(EmpTransfer),@TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                          
                where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                          
                                          
                IF @TransferCont IS NULL select @TransferCont = 0                                    
                IF @TransferContE IS NULL select @TransferContE = 0                                          
                                          
                                          
                                             
        end                                          
     else if ((@Mode = 2)  and (@ActiveStatus <> 6)) /* Projections */                                          
         begin                                          
                 Select @EmpOpening = empCont + EmpVolCont + PreEmpCont + PreAVC,                                           
                 @EmprOpening = EmprCont + EmprVolCont + PreEmprCont,@TransferOpBal = Transfer,                           
                 @TransferOpBalE = LockedIn + DeferredAmt                                         
                 from MemberOpeningBalances                                           
                 where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                          
                      
                 select @empContribution = sum(empcont + VolContr)                                           
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                          
                                          
                 select @emprContribution = sum(emprcont + SpecialContr)                                           
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                          
                                          
                 select @ArEmpCont = sum(Arempcont)                        
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                select @ArEmprCont = sum(Aremprcont)                                           
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                if @ArEmpCont is null select @ArEmpCont = 0                                       
                if @ArEmprCont is null select @ArEmprCont = 0                        
                                          
  Select @TransferCont = sum(EmpTransfer), @TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                          
                 where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                 and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                          
                            
                 if @TransferCont IS NULL select @TransferCont = 0                                          
                 if @TransferContE IS NULL select @TransferContE = 0                                          
                                          
                 /*                                          
                 if @TransferSeparate = 0                                          
                   begin                                    
                   select @empContribution = @empContribution + @TransferCont                                          
                   select @TransferCont = 0                                          
                   end                                          
     */                                          
        end                                          
     else if ((@Mode = 2)  and (@ActiveStatus = 6)) /* Projections for Deferred Members */                                          
     begin                                          
                                          
                 select @EmpClosing = 0.0                                          
                 Select @EmpOpening = 0.0,                                           
                 @EmprOpening = EmprCont + EmprVolCont + PreEmprCont,@TransferOpBal = Transfer,                           
                 @TransferOpBalE =LockedIn + DeferredAmt                                         
                 from MemberOpeningBalances                                           
                 where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                          
                                               
                 select @empContribution = 0.0                                           
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                          
                                          
                 select @emprContribution = sum(emprcont + SpecialContr)                                           
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                           
                 select @ArEmpCont = sum(Arempcont)                                           
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
        select @ArEmprCont = sum(Aremprcont)                                           
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                           
                if @ArEmpCont is null select @ArEmpCont = 0                                          
            if @ArEmprCont is null select @ArEmprCont = 0                                          
                                          
                 Select @TransferCont = sum(EmpTransfer), @TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                          
                 where SchemeNo = @schemeNo and MemberNo = @memberNo             
                 and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc        
                                          
                 IF @TransferCont IS NULL select @TransferCont = 0                                          
                 IF @TransferConte IS NULL select @TransferConte = 0                                          
        end                                          
  end                        
  else if @RegMode = 1                                          
     begin                                         
      if @Mode = 0                                          
         begin                                          
                Select @EmpOpening = ExcessEmp, @EmprOpening = ExcessEmpr,@TransferOpBal = 0.0, @TransferOpBalE = 0.0                                          
                from UnRegisteredBalances                                   
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                          
        
                select @empContribution = sum(Excessempcont),@emprContribution = sum(Excessemprcont)                                            
                from UnRegisteredContributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                if @ArEmpCont is null select @ArEmpCont = 0                                          
                if @ArEmprCont is null select @ArEmprCont = 0                                          
                                          
                IF @TransferCont IS NULL select @TransferCont = 0                                          
                IF @TransferContE IS NULL select @TransferContE = 0                                          
                                                         
        end                                          
      else if @Mode = 1                                          
         begin                      
                                                        
                Select @EmpOpening = ExcessEmp, @EmprOpening = ExcessEmpr,@TransferOpBal = 0.0, @TransferOpBalE = 0.0                                          
                from UnRegisteredBalances                                           
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                          
                                               
                select @empContribution = sum(Excessempcont),@emprContribution = sum(Excessemprcont)                                            
         from UnRegisteredContributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
        
                if @ArEmpCont is null select @ArEmpCont = 0                                          
                if @ArEmprCont is null select @ArEmprCont = 0                                          
                                          
                IF @TransferCont IS NULL select @TransferCont = 0                                          
                IF @TransferContE IS NULL select @TransferContE = 0                                          
                                             
        end                                          
     else if ((@Mode = 2)  and (@ActiveStatus <> 6)) /* Projections */                                          
         begin                                          
                Select @EmpOpening = ExcessEmp, @EmprOpening = ExcessEmpr,@TransferOpBal = 0.0, @TransferOpBalE = 0.0                                          
                from UnRegisteredBalances                                 
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                
                                               
                select @empContribution = sum(Excessempcont),@emprContribution = sum(Excessemprcont)                                            
                from UnRegisteredContributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                          
                if @ArEmpCont is null select @ArEmpCont = 0                                          
                if @ArEmprCont is null select @ArEmprCont = 0                                          
                                          
                 IF @TransferCont IS NULL select @TransferCont = 0                                          
          IF @TransferContE IS NULL select @TransferContE = 0                                          
                                          
                 /*                                          
                 if @TransferSeparate = 0                                          
                   begin                                          
                   select @empContribution = @empContribution + @TransferCont                                 
                   select @TransferCont = 0                                          
                   end                                          
                 */                                          
        end                                          
     else if ((@Mode = 2)  and (@ActiveStatus = 6)) /* Projections for Deferred Members */                                          
         begin                                          
                                          
                 select @EmpClosing = 0.0                                          
                 Select @EmpOpening = 0.0,                                           
                 @EmprOpening = EmprCont + EmprVolCont + PreEmprCont,@TransferOpBal = Transfer,                           
                 @TransferOpBalE =LockedIn + DeferredAmt                                          
                 from MemberOpeningBalances                                           
                 where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                          
                                               
                 select @empContribution = 0.0                                           
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                          
                                          
                 select @emprContribution = sum(emprcont + SpecialContr)                                           
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
           and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                           
                 select @ArEmpCont = sum(Arempcont)                                     
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                          
                select @ArEmprCont = sum(Aremprcont)                                           
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                          
                                           
                if @ArEmpCont is null select @ArEmpCont = 0                                          
                if @ArEmprCont is null select @ArEmprCont = 0                                          
                         
                 Select @TransferCont = sum(EmpTransfer), @TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                          
                 where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
                 and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                          
                                          
                 IF @TransferCont IS NULL select @TransferCont = 0                                          
                 IF @TransferConte IS NULL select @TransferConte = 0                                          
        end                                          
  end                                          
                                          
                                          
        select @EmpContribution = @EmpContribution + @ArEmpCont,@EmprContribution = @EmprContribution + @ArEmprCont                                          
                                          
        if @TransferOpBal is null select @TransferOpBal = 0                                          
        if @TransferCont is null select @TransferCont = 0                                
        if @TransferContE is null select @TransferContE = 0                                          
                              
        select @datepaid = max(datePaid)                                            
        from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                           
        and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @MwishoDate and Surplus = 0                                          
                                                 
        if @emprContribution is null select @emprContribution = 0                       
                                            
        if @empContribution is null select @empContribution = 0                                          
                                           
        if @empOpening is null select @empOpening = 0                                          
                                                  
        if @emprOpening is null select @emprOpening = 0                                          
                                          
        Exec GetServiceTime @djpens,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out                                          
                                          
        IF ((DatePart(Month,@dateofExit) = 2) and (@NumDays >= 28))                                          
           select @NumMonths = @NumMonths + 1,@NumDays = @NumDays - 28                                          
                                          
        if @NumMonths = 12                                          
           select @NumYears = @NumYears + 1,@NumMonths = 0                                          
                                       
        select @ServiceTime = cast(@NumYears as Varchar(2)) +' Years, '+ cast(@NumMonths as varchar(2))+'  months and '+cast(@NumDays as Varchar(2))+' days '                                          
        select @PastService = (@NumYears * 12)+@NumMonths                                          
                     
        select @Year = datePart(Year, @DateOfExit)                                          
                                          
        select @Month = datePart(Month, @DateOfExit)                                          
                                          
        exec getMonthDays @Year, @Month, @Days out                                          
                                          
        select @sMonth = @pastService % 12                                          
                                                 
        select @EmpInt = @empClosing - (@EmpOpening + @EmpContribution)                                          
                                          
        select @EmprInt = @emprClosing - (@EmprOpening + @EmprContribution)                                          
                                                    
                                                 
                                                 
       if ((@Mode = 2)and (@ActiveStatus = 6))                                          
          begin                          
               select @GrandTotal =  @EmprClosing + @TransferCBalE                                          
          end                                          
       else                                          
        begin                                          
         if @OptionToUse = 0                       
           begin                                          
             if (@Vesting  = 100.00 )                                          
               select @GrandTotal =  @EmprClosing + @TransferCBalE,                                          
               @LockedTransfer = @TransferCBalE                                          
             else                                      
               select @GrandTotal =   @VestedCont + (@TransferCBalE * (@Vesting/100.000)),                                          
               @LockedTransfer = @TransferCBalE * (@Vesting/100.000)                                          
           end                                          
         else if @OptionToUse = 1                                          
           begin                                         
              if @Zambia = 1                                        
                 select @GrandTotal =  @EmprClosing + @TransferCBalE,@VestedCont = 0,@LockedTransfer = 0                                        
              else                                         
                 select @GrandTotal =  0, @VestedCont = 0,@LockedTransfer = 0                                          
           end                                          
         else if @OptionToUse = 2           
           begin                                          
             select @GrandTotal =  @VestedCont + (@TransferCBalE * (@Vesting/100.000)),                                          
             @LockedTransfer = @TransferCBalE * (@Vesting/100.000)                                          
           end                                          
        end                                          
                                                 
       if @TransferCBal is null select @TransferCBal = 0                                          
                                          
       select @ClosingBalance = @GrandTotal                                          
                                          
      if @DeductNSSF = 1                                          
         SELECT @Bonus = 0 - @NSSF2Deduct                                          
                                          
      select @GrandTotal = @GrandTotal + @Bonus                                          
                                           
      Select @TransferInt = @TransferCBal - (@TransferOpBal + @TransferCont)                                          
      Select @TransferIntE = @TransferCBalE - (@TransferOpBalE + @TransferContE)            
            
    /* Pro-rate the 50% */   
    if @zambia = 1  
       BEGIN  
           select @TotalDue  = @GrandTotal,@AmountPaid = 0  
       END   
    else  
       BEGIN           
   if ((@ErRate > 0) and (@AcctPeriod = @AcctPeriod1)) /* Transfer within the same Year */            
      begin            
      select @AmountPaid = @GrandTotal - (@GrandTotal * (@ErRate/100.00))             
      select @TotalDue = @GrandTotal - (@GrandTotal * (@ErRate/100.00))             
      end            
   else  if ((@ErRate > 0) and (@AcctPeriod > @AcctPeriod1)) /* Transfer in another Year */            
      begin            
      select @AmountPaid = 0             
      select @TotalDue = @GrandTotal             
      end             
   else            
      begin            
      select @AmountPaid = 0             
      select @TotalDue = @GrandTotal            
      end             
       END                                   
                                          
      if @rExit = 8 /* Transfers */                                          
         begin                                          
            select @TaxAmount = 0,@TaxFreeLumpsum = 0,@WithHoldingTax = 0,@TotalInterest = 0,@TotalTax=0                                          
         end                                          
      else if @rExit = 1 /* Death in Service cases */                                          
         begin                                          
            if @BenefitMode = 1/* Gratuity Only */                                          
               Exec GetTaxFreeLumpsumD @schemeNo,@DoCalc,@TaxFreeLumpsum out                                  
                    
              select  @TaxAmount = @TotalDue - (@Pre90  + @TaxFreeLumpsum)                                          
                                          
              if @TaxAmount < 0 select @TaxAmount = 0                                          
                                          
              Exec GetTaxType @SchemeNo,@MemberNo,@TaxType Out                                          
                                          
              exec CalculateTax @SchemeNo,@TaxAmount,@DoCalc, @TaxType,@WithHoldingTax out                                          
                                          
            if @BenefitMode = 2/* Insured */                                  
               select @TaxAmount = 0,@TaxFreeLumpsum = 0,@WithHoldingTax = 0                                          
         end                                          
      else                                          
         begin                                        
            if @Pre90 is null select @Pre90 = 0                                        
            if @TaxFreeLumpsum is null select @TaxFreeLumpsum = 0                                        
                                        
            if @RegMode = 0                                          
              select  @TaxAmount = @TotalDue - (@Pre90  + @TaxFreeLumpsum)                                                  
     else                                          
               select  @TaxAmount = 0                                         
                                  
            if @TaxAmount < 0 select @TaxAmount = 0                                          
                                          
              Exec GetTaxType @SchemeNo,@MemberNo,@TaxType Out                                          
                                          
            if @RegMode = 0                                         
              begin                                         
              if @Zambia = 0                                        
                exec CalculateTax @SchemeNo,@TaxAmount,@DoCalc, @TaxType,@WithHoldingTax out                                         
              else                                        
                Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,0,@TaxAmount,@TaxEmployee Out,@WithHoldingTax Out                                         
              end                                         
            else                                           
               select  @WithHoldingTax = 0                                          
         end                                          
                                          
      if @RegMode = 0                                          
        update Benefits set WithholdingTax = @WithHoldingTax where SchemeNo = @schemeNo and MemberNo = @MemberNo             
                                          
       select @Reason = ReasonDesc                                           
       from ReasonforExit where ReasonCode = @rExit                          
                          
       if @rExit = 1                           
          select @Reason = 'Death-in-Deferment'                                          
                                  
         if @DesignCode > 0                                          
          begin                                    
          select @Title = Designation from Designation where DesignCode = @DesignCode                                          
                                          
          select @FullName = upper(@Title) +'  '+@FullName                                          
          end                                          
                                      
        /* rounding  Grand Total*/                                          
              select @YaConversion = cast(@GrandTotal as Varchar(25))                                          
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out                                          
              select @GrandTotal = @Chapaa                                          
              select @Chapaa = 0                                          
                                          
        /* rounding  Grand Total*/                                          
              select @YaConversion = cast(@WithholdingTax as Varchar(25))                                          
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out                                          
              select @WithholdingTax = @Chapaa                                          
              select @WithholdingTax = round(@WithholdingTax,0)                                          
              select @Chapaa = 0                                          
                                  
                                  
        /* Zambia Taxation */                                                    
if ((@Zambia = 1) and (@TaxRateDiff = 1))                               
begin                                  
   select @DoCalc = ' '                                  
                                  
   select @DoCalc = DoCalc from Members where SchemeNo = @SchemeNo and MemberNo = @MemberNo                                  
                                                    
   if @rExit = 1                                               
      begin               
        if @TaxDeath = 1                                                    
           Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,@Employee,@Employer,@TaxEmployee Out,@TaxEmployer Out                                                    
      end                                                    
   else if @rExit > 1 and @rExit < 5                                                    
      begin                                                    
        if @TaxRet = 1                                                    
           Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,@Employee,@Employer,@TaxEmployee Out,@TaxEmployer Out                               
      end                                                    
   else if @rExit = 5                                                    
      begin                                                    
        if @TaxMedical = 1                                                    
           Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,@Employee,@Employer,@TaxEmployee Out,@TaxEmployer Out                                                    
                                                    
      end                                                    
   else if @rExit > 5 and @rExit <> 8                                  
      begin                                                    
         if @TaxWith = 1                                                    
           begin                                                    
           Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,@Employee,@Employer,@TaxEmployee Out,@TaxEmployer Out                                          
                                                    
           select @TaxFreeLumpsum = 0.0                                          
                                                     
           if ((@ActiveStatus = 6) and (@DeferredPaid = 0))                                          
              select @TaxAmount = @Employee                                          
           else
              if @zambia = 0                                          
                 select @TaxAmount = @Employee + @Employer
              else
                 select @TaxAmount  = @Employer                                                    
           end                                                    
                      
      end                                                    
                                                    
   if @TaxEmployee is null select @TaxEmployee = 0                                                    
   if @TaxEmployer is null select @TaxEmployer = 0                                                    
   if @TaxEmployee + @TaxEmployer = 0                                                    
   select @TaxFreeLumpsum = 0.0,@TaxAmount =0.0                                                    
                             
   if ((@ActiveStatus = 6) and (@DeferredPaid = 0))                                          
      select @WithHoldingTax = @TaxEmployee                                            
   else 
      begin 
      if @zambia = 0                                                     
         select @WithHoldingTax = @TaxEmployee + @TaxEmployer  
      else
         select @withHoldingTax  = @TaxEmployer
      
      end                                                  
end                                                    
else                                                    
begin                                             
  if @WithHoldingTax > 0                                                    
     select @TaxEmployee = @WithHoldingTax/2.00,@TaxEmployer = @WithHoldingTax/2.00                                                    
end                                   
                                          
 if @TaxAmount is null select @TaxAmount = 0                                       
 if @GrandTotal is null select @GrandTotal = 0                           
 if @WithholdingTax is null select @WithholdingTax = 0                                       
 if @EmprInt is null select @EmprInt = 0                                        
 if @EmpInt is null select @EmpInt = 0                                       
 if @emprClosing is null select @emprClosing = 0                                      
 if @empClosing is null select @empClosing = 0                    
                    
                   
 select @TotalInterest = @TotalInterest * (100.00 - @Perc_Paid)/100.00,                  
        @TotalTax = @TotalTax * (100.00 - @Perc_Paid)/100.00                  
                   
  Select @NetInterest =  @TotalInterest - @TotalTax             
            
  /* Pro-rate the 50% */            
    if ((@Perc_Paid > 0) and (@AcctPeriod > @AcctPeriod1)) /* Transfer in another Year */            
       begin            
          select @Perc_Paid = 100             
       end             
    else if ((@Perc_Paid > 0) and (@AcctPeriod = @AcctPeriod1)) /* Transfer in another Year */            
       begin            
          select @Perc_Paid = @Perc_Paid      
      
          print @TotalDue    
          print @rExit        
         
          if @rExit <> 8         
             select @TotalDue = @TotalDue * (@Perc_Paid/100.000)     
          else if @rExit = 8    
             select @TotalDue = @TotalDue * (@Perc_Paid/100.000)                
       end          
    else            
       begin            
          select @Perc_Paid = 100             
       end 
   

       
                                      
        insert into #calculation (schemeNo, MemberNo, schemeName, fullname, dje, djpens, empopeningBal, emprOpeningBal,                                          
                     empcontributions, emprContributions,empclosing, emprClosing,interest, dateofexit,                                          
                     curYear, pastService, benefitsDC, TaxfreeLumpsum,withHoldingTax,Vesting, Comments, EmprInt, EmpInt, AmountPayable, TaxableAmount,                                          
                     Reason,EndDate,PreparedBy,CheckedBy,AuthorisedBy,ClosingBalance,Bonus,TransferInt,TransferCBal,TransferOpBal,                                          
                     TransferDesc,AdditionDesc,DoCalc,VestedCont,TransferCont,AuditedBy,DateAudited,DoBirth,                                          
                     TransferIntE,TransferCBalE,TransferOpBalE,TransferContE,LockedTransfer,                                          
                     DatePrepared,DateChecked,DateAuthorised,PoolName,TotalInterest,CorporateTax,NetInterest,Perc_Paid,TotalDue)                                          
                                                   
                                          
         values(@schemeNo, @memberNo,@schemeName, @fullname, @dje, @djpens, @empOpening, @emprOpening, @empcontribution, @emprContribution, @empclosing, @emprClosing,                                          
                @interest, @dateofExit, @curYear, @ServiceTime, @GrandTotal, @taxfreeLumpsum, @withHoldingTax, @vesting, @comments, @EmprInt, @EmpInt, @TotalDue - (@WithholdingTax + @TotalTax), @TaxAmount,                                          
                @Reason,@EndDate,@PreparedBy,@CheckedBy,@AuthorisedBy,@ClosingBalance,@Bonus,@TransferInt,@TransferCBal,@TransferOpBal,                                          
                @TransferDesc,@AdditionDesc,@DoCalc,@VestedCont,@TransferCont,@AuditedBy,@DateAudited,@DoBirth,                                          
                @TransferIntE,@TransferCBalE,@TransferOpBalE,@TransferContE,@LockedTransfer,                                          
                @DatePrepared,@DateChecked,@DateAuthorised,@PoolName,@TotalInterest,@TotalTax,@NetInterest,@Perc_Paid,@TotalDue)                              
                                          
      /* for the Britak Sun Interface */               
      IF @RegMode = 0               
         Update Benefits set WithBenefit = @GrandTotal,WithTax = @withHoldingTax                
         where schemeNo = @schemeNo and MemberNo = @MemberNo              
      else if @RegMode = 1                       begin                 
         Update Benefits set WithBenefitUn = @GrandTotal,WithTaxUn = @withHoldingTax                
         where schemeNo = @schemeNo and MemberNo = @MemberNo              
              
         Update UnRegisteredBenefits set WithBenefit = @GrandTotal,WithTax = @withHoldingTax                
         where schemeNo = @schemeNo and MemberNo = @MemberNo              
         end              
                             
     if @OptionToUse = 1                                          
        Exec CalcPartialPayment  @schemeNo,@MemberNo                                          
                                          
     select @OptionToUse = 0,@EmpClosing = 0,@emprClosing=0,@withHoldingTax=0, @taxfreeLumpsum=0, @vesting=0,@VestedCont=0,@Bonus=0,@TransferCBal=0,                                          
              @TransferCBalE=0,@Pre90=0,@ActiveStatus=0,@TaxAmount = 0                                          
                                          
     fetch next from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @fullname,@curYear, @interest,                                          
              @EmpClosing,@emprClosing,@withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont,@Bonus,@TransferCBal,                                          
              @TransferCBalE,@Pre90,@ActiveStatus,@TotalInterest,@TotalTax                                          
                                  
end                                          
                                          
close GenCursor                                          
deallocate GenCursor                                          
                                          
select * from #calculation
go

