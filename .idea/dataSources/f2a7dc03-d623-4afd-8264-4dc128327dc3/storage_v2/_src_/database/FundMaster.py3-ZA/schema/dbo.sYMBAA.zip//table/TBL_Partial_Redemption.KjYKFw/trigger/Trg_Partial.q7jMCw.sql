CREATE TRIGGER [dbo].[Trg_Partial] ON [dbo].[TBL_Partial_Redemption] 
FOR INSERT
AS

declare @schemeno int,@invcode int,@investcode int,@PayCode int,@userName varchar(50),@TransDate datetime,@PostingMode smallint


Select @TransDate = TransDate,@schemeNo = SchemeNo,
@PayCode = PayCode,@invcode = invcode,@investcode = investcode,@PostingMode = PostingMode from Inserted

select @userName = user

if @PostingMode is null select @PostingMode = 0

if @PostingMode = 0
begin
if @investcode = 4 /* Government Paper */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,135,@PayCode,0,@UserName
else if @investcode = 5 /* FXD */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,155,@PayCode,0,@UserName
else if @investcode = 7 /*  Corporate Bonds */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,148,@PayCode,0,@UserName
else if @investcode = 8 /* CALL DEP */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,167,@PayCode,0,@UserName
else if @investcode = 9 /* Long Term Loans */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,217,@PayCode,0,@UserName
end
else if @PostingMode = 1
begin
if @investcode = 4 /* Government Paper */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,135,@PayCode,2,@UserName
else if @investcode = 5 /* FXD */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,155,@PayCode,2,@UserName
else if @investcode = 7 /*  Corporate Bonds */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,148,@PayCode,2,@UserName
else if @investcode = 8 /* CALL DEP */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,167,@PayCode,2,@UserName
else if @investcode = 9 /* Long Term Loans */
   Exec Proc_Auto_Insert_InvPosting @schemeNo ,@invcode,@investcode,217,@PayCode,2,@UserName
end
go

