CREATE PROCEDURE [dbo].[GetDebitPayables]
@SCHEMENO Int,
@MemberNo int
--with Encryption
as

if object_id('tempdb..#DebitPayables') is null

begin
create table #DebitPayables
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[DrDesc] [varchar](100) NOT NULL ,
	[Debit] [Decimal](12,2) not  NULL default 0.0,
        [Total] [Decimal](12,2) null default 0.0 
) 

ALTER TABLE #DebitPayables WITH NOCHECK ADD 

            
	CONSTRAINT [PK_DebitPayables] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end


declare @Desc varchar(50),@Debit decimal(20,2),@CreditorCode Int,@LPONO Int,@YaConversion Varchar(25),@Chapaa decimal(20,2)

 	     
select @Debit = Amount,@LPoNo = LPONo from 
PayablesPayment
where  SchemeNo = @schemeNo and PaymentNo = @MemberNo


select @Desc = Description,@CreditorCode = CreditorCode from Payables where SchemeNo = @schemeNo and LPONo = @LPONo

select @Desc = Debtor + ' : '+@Desc from CreditorsRegister
where SchemeNo = @schemeNo and DebtorCode = @CreditorCode


              select @YaConversion = cast(@Debit as Varchar(25))
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
              select @Debit = @Chapaa
              select @Chapaa = 0

            

insert into #DebitPayables (drDesc,Debit)
                 Values(@Desc,@Debit)

update #DebitPayables set total = @Debit
              
select *  from #DebitPayables
go

