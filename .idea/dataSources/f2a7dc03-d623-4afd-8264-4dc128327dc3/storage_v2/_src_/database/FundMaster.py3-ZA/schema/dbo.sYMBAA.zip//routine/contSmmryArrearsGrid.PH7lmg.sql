CREATE PROCEDURE [dbo].[contSmmryArrearsGrid]
@SCHEMENO Int,
@MemberNo int
--with Encryption
as
select cs.MemberNo, cs.SchemeNo, cs.ContrYear, cs.ContrMonth,cs.ArSpecial, cs.ArVolContr,cs.ArEmprCont, cs.ArEmpCont,
       cs.AugCont, 
         monthTable.MonthName, (cs.ArSpecial + cs.ArVolContr + cs.ArEmpCont + cs.ArEmprCont + cs.ArEmpCont_Un + cs.ArEmprCont_Un ) as totArrears,
         cs.DatePaid
from ContributionArrears as cs 
          inner join monthTable on monthTable.MonthNumber = cs.ContrMonth
where (cs.MemberNo = @MemberNo) and (cs.SchemeNo = @SchemeNo)
order by cs.ContrYear, cs.ContrMonth
go

