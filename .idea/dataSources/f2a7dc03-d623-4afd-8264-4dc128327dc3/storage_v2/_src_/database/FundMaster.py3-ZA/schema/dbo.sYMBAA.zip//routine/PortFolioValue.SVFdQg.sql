CREATE PROCEDURE [dbo].[PortFolioValue]      
@SCHEMENO Int,  
@AsAt Datetime,
@FundValue Decimal(20,2) OUT       
--with Encryption        
as        
        
if object_id('tempdb..#Portfolio') is null        
        
begin        
create table #PortFolio        
(        
         
        [SchemeName][varchar](120) null,        
        [Investment] [varchar](100) NOT NULL ,        
        [amount] [float] not  NULL default 0.0,        
        [Percentage] [Float] null default 0.0,        
        [MaxPcntofAsset][float] null default 0.0,        
        [Total][Float]null default 0.0,        
        [Currency][varchar](30),  
        [AsAtDate][datetime],  
        [TargetAlloc][float]                     
)         
        
ALTER TABLE #PortFolio WITH NOCHECK ADD          
                    
 CONSTRAINT [PK_PortFolio] PRIMARY KEY  NONCLUSTERED         
 (        
   [Investment]              
 )         
end        
        
declare @InvestCode Int,@Investment varchar(50),@Percentage float,@Total decimal(20,2),@Amount decimal(20,2),        
@MaxPcnt float,@SchemeName varchar(120),@Curr varchar(15),@Currency varchar(30),@TargetAlloc float        
        
Select @Total = 0        
        
Select @SchemeName = schemeName,@Curr = Currency from scheme where schemeCode = @schemeNo        
        
Select @Currency = CurrencyDesc from CurrencyType where CurrencyCode = @Curr        
        
Declare XCsr Cursor for        
Select Distinct(InvestCode) from        
InvestMents where SchemeNo = @SchemeNo        
and InvStatus = 0        
        
Open XCsr        
        
fetch from XCsr into @InvestCode        
        
while @@fetch_Status = 0        
begin        
     select @Investment = InvestDesc,@MaxPcnt = MaxPcntofAsset         
     from InvestmentTypes where InvestCode = @InvestCode   
  
     select @TargetAlloc = TargetAlloc from TBL_Invest_TaxRates  
     where InvestCode = @InvestCode and schemeNo = @SchemeNo  
  
     if @TargetAlloc is null select @TargetAlloc = 0       
       
     if @InvestCode = 1 /* Property*/  
        Exec Proc_Property_Value @SCHEMENO,@AsAt,@Amount Out                                                                                   
     else if @InvestCode = 2 /* Equities*/  
        Exec Proc_Equity_Value @SCHEMENO,@AsAt,@AsAt,0,@Amount Out                                    
     else if @InvestCode = 4 /* Government Paper */  
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,0,0,@Amount Out  
     else if @InvestCode = 5 /* Fixed Term Deposits */  
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,2,0,@Amount Out                                                                               
     else if @InvestCode = 7 /* Fixed Term Deposits */  
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,1,0,@Amount Out   
     else if @InvestCode = 8 /* Call Deposits */  
        Exec Rep_Investment_Value @schemeNo,@AsAt,@AsAt,3,0,@Amount Out   
            
     if @Amount is null select @Amount = 0        
        
     Select @Total = @Total + @Amount        
        
     Insert Into #PortFolio (Investment,Amount, MaxPcntofAsset,currency,AsAtDate,TargetAlloc)        
                  Values(@Investment,@Amount,@MaxPcnt,@Currency,@AsAt,@TargetAlloc)        
        
     Select @Amount = 0,@TargetAlloc = 0        
        
   fetch next from XCsr into @InvestCode        
end        
Close XCsr        
Deallocate XCsr        
        
Select @FundValue = sum(Amount) from #PortFolio
go

