
CREATE TRIGGER [dbo].[MembDelete]
ON [dbo].[Members]
FOR DELETE
AS
    /* Declare */
    BEGIN TRAN

    DECLARE @schemeNo INT,
            @MemberNo INT

    SELECT @schemeNo = SchemeNo,
           @MemberNo = MemberNo
    FROM   Deleted

    IF EXISTS (SELECT MemberNo
               FROM   Contributionssummary
               WHERE  schemeNo = @SchemeNo
                      AND MemberNo = @MemberNo)
      BEGIN
          RAISERROR ('You cannot delete a member who has other records',16,1)

          ROLLBACK TRAN
      END
    ELSE
      COMMIT TRAN
go

