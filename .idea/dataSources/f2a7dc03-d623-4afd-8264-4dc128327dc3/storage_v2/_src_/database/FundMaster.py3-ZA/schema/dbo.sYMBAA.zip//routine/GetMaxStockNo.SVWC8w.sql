








































CREATE PROCEDURE GetMaxStockNo
@schemeNo Int
--with Encryption
as
declare @MaxCode Int

Select @MaxCode = Max(ItemCode) from Stock
where SchemeNo = @schemeNo

if @MaxCode is null select @MaxCode = 0

Select @MaxCode = @MaxCode + 1

Select @MaxCode as MaxCode


go

