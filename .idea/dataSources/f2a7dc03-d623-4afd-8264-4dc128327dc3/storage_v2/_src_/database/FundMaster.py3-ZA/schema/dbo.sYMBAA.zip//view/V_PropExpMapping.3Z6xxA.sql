CREATE VIEW [dbo].[V_PropExpMapping]    
as    
    
select p.PropExpCode,p.schemeNo,p.PropertyCode,p.ExpenseCode,p.AccountCode,P.TransCode,    
ltrim(rtrim(g.glAccount)) as glAccount,    
e.Expense    
from TBL_Property_Exp_Mapping p    
     inner join glAccountCodes g on p.AccountCode = g.AccountCode    
     inner join ExpenditureTypes e on p.ExpenseCode = e.ExpenseCode
go

