--EXEC positionreport 1213,8,1,'mar 31,2007'

CREATE PROCEDURE [dbo].[positionreport] 
@schemeno int,
@acctperiod int,
@yearend int,
@calcdate datetime
as
if object_id('tempdb..#positionreport') is null
begin
create table #positionreport
(
schemeno int,
acctperiod int,
Asdate datetime,
Schemename varchar(350),
eeopeningbal decimal(20,2),
eropeningbal decimal(20,2),
avcopeningbal decimal(20,2),
eeconts decimal(20,2),
erconts decimal(20,2),
avcconts decimal(20,2),
eeint decimal(20,2),
erint decimal(20,2),
avcint decimal(20,2),
FundValue decimal(20,2)
)
end
else 
delete #positionreport

declare @eeopeningbal decimal(20,2), @eropeningbal decimal(20,2),@avcopeningbal decimal(20,2),
@eeclosingbal decimal(20,2),@erclosingbal decimal(20,2),@avcclosingbal decimal(20,2),@eeconts decimal(20,2),@fundValue DECIMAL(20,2),
@ArEmpCont decimal(20,2), @ArEmprCont decimal(20,2),@ArVolContr decimal(20,2),@EmpTransfer decimal(20,2), @EmprTransfer decimal(20,2),@AVCTransfer decimal(20,2),
@erconts decimal(20,2),@avcconts decimal(20,2), @eeint decimal(20,2), @erint decimal(20,2),@avcint decimal(20,2),@periodtouse int,
@schemename varchar(200)

select @periodtouse = @acctperiod - 1

select @schemename = Schemename from scheme where schemecode = @schemeno

select @eeopeningbal = sum(empcont), @eropeningbal = sum(emprcont), @avcopeningbal = sum(empvolcont) from memberopeningbalances where schemeno = @schemeno and acctperiod = @periodtouse
if @eeopeningbal is null select @eeopeningbal = 0.00
if @eropeningbal is null select @eropeningbal = 0.00
if @avcopeningbal is null select @avcopeningbal = 0.00

if @yearend = 1
begin
select @eeconts = sum(empcont),@erconts = sum(emprcont), @avcconts = sum(volcontr) from contributionssummary where schemeno = @schemeno and acctperiod = @acctperiod
if @eeconts is null select @eeconts = 0.00
if @erconts is null select @erconts = 0.00
if @avcconts is null select @avcconts = 0.00

select  @ArEmpCont = sum(ArEmpCont), @ArEmprCont = Sum(ArEmprCont) , @ArVolContr = sum(ArVolContr) from contributionarrears where schemeno = @schemeno and acctperiod = Acctperiod
if @ArEmpCont is null select @ArEmpCont = 0.00
if @ArEmprCont is null select @ArEmprCont = 0.00
if @ArVolContr is null select @ArVolContr = 0.00

select @EmpTransfer = sum(EmpTransfer), @EmprTransfer = sum(EmprTransfer) ,@AVCTransfer = Sum(AVCTransfer) from membertransfer where schemeno = @schemeno and acctperiod = @acctperiod
if @EmpTransfer is null select @EmpTransfer = 0.00
if @EmprTransfer is null select @EmprTransfer = 0.00
if @AVCTransfer is null select @AVCTransfer = 0.00

select @eeconts = @eeconts + @ArEmpCont + @EmpTransfer
select @erconts = @erconts + @ArEmprCont + @EmprTransfer
select @avcconts = @avcconts + @ArVolContr + @AVCTransfer

select @eeclosingbal = sum(empcont), @erclosingbal = sum(emprcont), @avcclosingbal = sum(empvolcont) from memberopeningbalances where schemeno = @schemeno and acctperiod = @acctperiod
if @eeclosingbal is null select @eeclosingbal = 0.00
if @erclosingbal is null select @erclosingbal = 0.00
if @avcclosingbal is null select @avcclosingbal = 0.00

select @eeint = @eeclosingbal - (@eeopeningbal+@eeconts)
select @erint = @erclosingbal - (@eropeningbal+@erconts)
select @avcint = @avcclosingbal - (@avcopeningbal+@avcconts)
end
else if @yearend = 0/*yearend = 0 not year end*/
begin
select @eeconts = sum(empcont),@erconts = sum(emprcont), @avcconts = sum(volcontr) from contributionssummary where schemeno = @schemeno and acctperiod = @acctperiod and datepaid <=@calcdate
if @eeconts is null select @eeconts = 0.00
if @erconts is null select @erconts = 0.00
if @avcconts is null select @avcconts = 0.00

select  @ArEmpCont = sum(ArEmpCont), @ArEmprCont = Sum(ArEmprCont) , @ArVolContr = sum(ArVolContr) from contributionarrears where schemeno = @schemeno and acctperiod = Acctperiod and datepaid <=@calcdate
if @ArEmpCont is null select @ArEmpCont = 0.00
if @ArEmprCont is null select @ArEmprCont = 0.00
if @ArVolContr is null select @ArVolContr = 0.00

select @EmpTransfer = sum(EmpTransfer), @EmprTransfer = sum(EmprTransfer) ,@AVCTransfer = Sum(AVCTransfer) from membertransfer where schemeno = @schemeno and acctperiod = @acctperiod and Transferdate <=@calcdate
if @EmpTransfer is null select @EmpTransfer = 0.00
if @EmprTransfer is null select @EmprTransfer = 0.00
if @AVCTransfer is null select @AVCTransfer = 0.00

select @eeconts = @eeconts + @ArEmpCont + @EmpTransfer
select @erconts = @erconts + @ArEmprCont + @EmprTransfer
select @avcconts = @avcconts + @ArVolContr + @AVCTransfer

select @eeclosingbal = @eeopeningbal+ @eeconts
select @erclosingbal = @eropeningbal+ @erconts
select @avcclosingbal = @avcopeningbal+ @avcconts

select @eeint = 0, @erint = 0, @avcint =0

end


select @fundValue = @eeclosingbal+@erclosingbal+@avcclosingbal

insert into #positionreport(schemeno, acctperiod,Asdate, Schemename, eeopeningbal, eropeningbal, avcopeningbal, eeconts, erconts, avcconts,
eeint, erint, avcint,FundValue)
values(@schemeno, @acctperiod, @calcdate, @Schemename, @eeopeningbal, @eropeningbal, @avcopeningbal, @eeconts, @erconts, @avcconts,
@eeint, @erint, @avcint,@fundValue)

select * from #positionreport
go

