/*

14/04/2013

For floating Rate Bonds the following code has been added

if @InterestType = 1                                                                                                    
      begin                                                                                                              
        exec Proc_Get_Float_Rate @schemeNo,@securityNo,@DateDue,@IntRate out
        
        if ((@IntRate is null) or (@IntRate = 0)) 
           select @IntRate = @OrigRate
           
           select @InterestRate = @IntRate                                                                                                      
      end    
      

to ensure the income due is reset using the floating interest rates and not the original interest rate

*/
CREATE PROCEDURE [dbo].[Proc_Income_Due_Second] /* Exec Proc_Income_Due_Second 1328,248,12,0 */  
@schemeNo int,  
@securityNo int,  
@AcquisitionNo int,  
@TransMode Int /* 0 - Add, 1 - Delete */  
--with Encryption  
as  

  
declare @OrigFace float,@LastCoupon datetime,@FaceValue float,@TransDate datetime,@InterestRate float,  
@sumAcquire float,@DueCounter BigInt,@NumDays Int,@DaysInaYear float,@DaysInaYearMode int,@IncomeDue float,@GovComm int,  
@MedLevy float,@WithTax float,@MediLevy float,@WithiTax float,@InterestType smallint,@DateDue datetime,
@IntRate float,@OrigRate float  


select @IntRate = 0
  
if Exists(select schemeNo from GovernmentSecurities where SchemeNo = @schemeNo and SecurityNo  = @securityNo)  
   begin  
   SELECT @OrigFace = NominalValue,@InterestRate = InterestRate,@DaysInaYearMode = DaysInaYearMode,@InterestType = InterestType   
   from GovernmentSecurities where SchemeNo = @schemeNo and SecurityNo = @securityNo  
     
   select @MedLevy = Max(MedicalLevy),@WithTax = Max(WithholdingTax) from TBL_Invest_TaxRates                                            
   where schemeNo = @schemeNo and InvestCode = 4                          
                        
   if @MedLevy is null select @MedLevy = 0                                            
   if @WithTax is null select @WithTax = 0   
     
   end  
else  
   begin  
   SELECT @OrigFace = NominalValue,@InterestRate = InterestRate,@DaysInaYearMode = DaysInaYearMode,@InterestType = InterestType   
   from CommercialPaper where SchemeNo = @schemeNo and PaperNo = @securityNo  
  
   select @MedLevy = Max(MedicalLevy),@WithTax = Max(WithholdingTax) from TBL_Invest_TaxRates                                    
   where schemeNo = @schemeNo and InvestCode = 5     
  
   if @MedLevy is null select @MedLevy = 0                                            
   if @WithTax is null select @WithTax = 0  
     
   select @WithTax = 0  
       
   end
   
select @OrigRate = @InterestRate     
     
select @TransDate = TransDate,@LastCoupon = LastCoupon,@FaceValue = FaceValue   
from GovernmentAcquisition  
where SchemeNo = @schemeNo  and SecurityNo = @securityNo AND AcquisitionNo = @AcquisitionNo  
  
if @TransDate >= 'Jan 1,2013'  
   select @MedLevy = 0    
        
IF @DaysInaYearMode = 0    
   select @DaysInaYear = 365.00    
else IF @DaysInaYearMode = 1    
   select @DaysInaYear = 364.00    
else IF @DaysInaYearMode = 2    
   select @DaysInaYear = 360.00   
  
select @sumAcquire = sum(FaceValue)   
from  GovernmentAcquisition   
where SchemeNo = @schemeNo and SecurityNo = @securityNo and TransDate  < @TransDate   
  
if @sumAcquire is null select @sumAcquire = 0  
if @OrigFace is null select @OrigFace = 0  
  
select @OrigFace = @OrigFace + @sumAcquire  
  
declare IncCursor cursor for  
select DueCounter,NumDays,DateDue from GovCommIncomeDue  
where SchemeNo = @schemeNo and SecurityNo = @SecurityNo and DateDue >= @LastCoupon  
order by DueCounter  
  
open IncCursor  
fetch from IncCursor into @DueCounter,@NumDays,@DateDue 
while @@FETCH_STATUS =0  
begin
   
   if @InterestType = 1                                                                                                    
      begin                                                                                                              
        exec Proc_Get_Float_Rate @schemeNo,@securityNo,@DateDue,@IntRate out
        
        if ((@IntRate is null) or (@IntRate = 0)) 
           select @IntRate = @OrigRate
           
           select @InterestRate = @IntRate                                                                                                      
      end    
                 
   if @TransMode = 0 /* New */  
      select @IncomeDue = ((@OrigFace + @FaceValue) * (@InterestRate/100.00)) * CAST(@NumDays as float)/@DaysInaYear  
   else  /* Deleting an Acquisition should take the Income due back to what it was */  
      select @IncomeDue = ((@OrigFace) * (@InterestRate/100.00)) * CAST(@NumDays as float)/@DaysInaYear  
        
   if @IncomeDue > 0  
      begin  
         if @MedLevy > 0  
            select @MediLevy = @IncomeDue * @MedLevy/100.00  
         else  
            select @MediLevy  = 0  
        
        
         if @WithTax > 0  
            select @WithiTax = @IncomeDue * @WithTax/100.00  
         else  
            select @WithiTax  = 0  
      end  
     
   Update GovCommIncomeDue set Income = @IncomeDue, WithTax = @WithiTax,MedLevy = @MediLevy   
   where DueCounter  = @DueCounter and SchemeNo = @schemeNo and SecurityNo = @securityNo   
  
   select @DueCounter=0,@NumDays=0,@IncomeDue = 0,@NumDays = 0,@MediLevy = 0,@WithiTax = 0,@IntRate = 0  
   fetch next from IncCursor into @DueCounter,@NumDays,@DateDue  
end  
close IncCursor  
deallocate IncCursor
go

