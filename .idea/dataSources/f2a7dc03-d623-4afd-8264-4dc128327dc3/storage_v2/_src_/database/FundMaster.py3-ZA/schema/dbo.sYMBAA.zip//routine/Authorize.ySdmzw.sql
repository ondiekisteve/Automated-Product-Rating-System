CREATE PROCEDURE [dbo].[Authorize]          
@SCHEMENO Int,          
@Mode int,          
@Reason int          
--with Encryption          
as          
if object_id('tempdb..##Authorise') is null          
          
begin          
create table ##Authorise          
(          
        [AuthCode]int identity(1,1) Primary Key,        
        [AuthorNo] Int not null,          
        [schemeno] [varchar](15) NOT NULL ,          
        [MemberNo] int NOT NULL,      
        [PayrollNo][varchar](30),      
        [IDNumber][varchar](20),          
        [DatePrepared] [Datetime] NULL,          
        [DateChecked] [Datetime] null,          
        [Surname][varchar](50) not null,          
        [Othernames][varchar](80) not null,          
        [Claim_No][Integer] not null,        
        [Confirmed][bit],        
        [Posted][bit]              
)             
end          
          
delete from ##Authorise     
    
Declare @Over50 SMALLINT    
    
select @Over50 = Over50Pensionable from ConfigRetirement where SchemeNo = @schemeNo    
         
          
if @Mode = 1 /* Certification */           
  begin          
  if @Reason = 1 begin          
     Insert into ##Authorise         
            Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber,l.datePrepared, l.dateChecked, upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames,          
                   m.Claim_No,l.Confirmed,l.Posted          
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Checked = 0          
     where ((M.reasonforExit = 6) or ((M.reasonforExit >= 8) and (M.reasonforExit <= 25))) and m.SchemeNo = @SchemeNo          
               
     end          
  else if @Reason = 2 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared,l.dateChecked, upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames,          
                             m.Claim_No,l.Confirmed,l.Posted           
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Checked = 0          
     where m.ReasonforExit = 1 and m.SchemeNo = @SchemeNo          
     end          
  else if @Reason = 3 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared,l.dateChecked, upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames,          
                             m.Claim_No,l.Confirmed,l.Posted           
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Checked = 0          
     where m.ReasonforExit >=2 and M.reasonforExit <= 4 and m.SchemeNo = @SchemeNo          
          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames,          
                             m.Claim_No,l.Confirmed,l.Posted           
      from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Checked = 0          
       Inner Join Pensioner p on m.schemeNo = p.schemeNo and m.MemberNo = p.MemberNo          
     where ((M.reasonforExit = 6) or ((M.reasonforExit >= 8) and (M.reasonforExit <= 25))) and m.SchemeNo = @SchemeNo          
               
     end          
 else if @Reason = 4 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames,          
                             m.Claim_No,l.Confirmed,l.Posted           
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Checked = 0          
     where m.ReasonforExit =5  and m.SchemeNo = @SchemeNo          
     end          
 else if @Reason = 5 begin          
     Insert into ##Authorise Select l.Memberno,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.RevDate as DatePrepared,l.Revdate, upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames,          
                             l.Claim_No,0,0          
         from Members m          
               Inner Join Pen_Revise L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Processed = 0          
        where m.SchemeNo = @SchemeNo          
     end          
  end          
else if @Mode = 2 /* Authorize */          
  begin          
  if @Reason = 1 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted            
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Authorised = 0   
       and l.Checked = 1         
     where ((M.reasonforExit = 6) or ((M.reasonforExit >= 8) and (M.reasonforExit <= 25))) and m.SchemeNo = @SchemeNo          
               
     end          
  else if @Reason = 2 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted          
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Authorised = 0  
       and l.Checked = 1          
     where m.ReasonforExit = 1 and m.SchemeNo = @SchemeNo          
     end          
  else if @Reason = 3 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared,l.dateChecked, upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted          
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Authorised = 0  
       and l.Checked = 1          
     where m.ReasonforExit >=2 and M.reasonforExit <= 4 and m.SchemeNo = @SchemeNo          
          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted           
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Authorised = 0  
       and l.Checked = 1          
       Inner Join Pensioner p on m.schemeNo = p.schemeNo and m.MemberNo = p.MemberNo          
     where ((M.reasonforExit = 6) or ((M.reasonforExit >= 8) and (M.reasonforExit <= 25))) and m.SchemeNo = @SchemeNo          
               
     end          
 else if @Reason = 4 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted           
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Authorised = 0  
       and l.Checked = 1            
     where m.ReasonforExit =5  and m.SchemeNo = @SchemeNo          
 end            
          
  else if @Reason = 5 begin          
         Insert into ##Authorise Select l.MemberNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.RevDate as DatePrepared, l.RevDate, upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
         ,l.Claim_No,0,0          
         from Members m          
               Inner Join Pen_Revise L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Processed = 0          
        where m.SchemeNo = @SchemeNo          
     end          
end          
          
else if @Mode = 3 /* Audit */          
  begin          
  if @Reason = 1 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted            
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Audited = 0 and  
       l.Authorised = 1         
     where ((M.reasonforExit = 6) or ((M.reasonforExit >= 8) and (M.reasonforExit <= 25))) and m.SchemeNo = @SchemeNo          
               
     end          
  else if @Reason = 2 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted          
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Audited = 0 and  
       l.Authorised = 1                 
     where m.ReasonforExit = 1 and m.SchemeNo = @SchemeNo          
     end          
  else if @Reason = 3 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared,l.dateChecked, upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted          
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Audited = 0 and  
       l.Authorised = 1                 
     where m.ReasonforExit >=2 and M.reasonforExit <= 4 and m.SchemeNo = @SchemeNo          
          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted           
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Audited = 0 and  
       l.Authorised = 1                 
       Inner Join Pensioner p on m.schemeNo = p.schemeNo and m.MemberNo = p.MemberNo          
     where ((M.reasonforExit = 6) or ((M.reasonforExit >= 8) and (M.reasonforExit <= 25))) and m.SchemeNo = @SchemeNo          
               
     end          
 else if @Reason = 4 begin          
     Insert into ##Authorise Select l.AuthorNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.datePrepared, l.dateChecked,upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
     ,m.Claim_No,l.Confirmed,l.Posted           
     from Members m          
       Inner Join LumpAuthorization L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Audited = 0 and  
       l.Authorised = 1                   
     where m.ReasonforExit =5  and m.SchemeNo = @SchemeNo          
 end            
          
  else if @Reason = 5 begin          
         Insert into ##Authorise Select l.MemberNo,l.schemeNo, l.MemberNo,m.PayrollNo,m.IdNumber, l.RevDate as DatePrepared, l.RevDate, upper(m.Sname) as surname, m.fname +' '+m.Onames as Othernames          
         ,l.Claim_No,0,0          
         from Members m          
               Inner Join Pen_Revise L on m.schemeNo = l.schemeNo and m.MemberNo = l.MemberNo and l.Processed = 0          
        where m.SchemeNo = @SchemeNo          
     end            
end
go

