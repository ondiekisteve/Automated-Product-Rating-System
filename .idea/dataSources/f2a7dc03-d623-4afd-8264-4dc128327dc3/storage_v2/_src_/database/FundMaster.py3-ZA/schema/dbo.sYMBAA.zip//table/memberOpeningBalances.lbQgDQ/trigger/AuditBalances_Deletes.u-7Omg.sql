CREATE TRIGGER [dbo].[AuditBalances_Deletes] on [dbo].[memberOpeningBalances]
--with encryption 
for Delete 
as
declare @SchemeNo varchar(15),@MemberNo int,@SchemeYear Int,@SchemeMonth int,@AcctPeriod Int,@PrimaryKey varchar(100),
@SqlStr varchar(1000),@InsertDesc Varchar(200)

select @SchemeNo = SchemeNo, @MemberNo = MemberNo,@SchemeYear  = SchemeYear,@SchemeMonth = SchemeMonth,@AcctPeriod = AcctPeriod from Deleted

select @InsertDesc = 'Member No '+ cast(@MemberNo as Varchar(20))+ ' Registered Balances'

select @PrimaryKey = @SchemeNo +' - '+ cast(@MemberNo as varchar(15))+' - '+ cast(@SchemeMonth as varchar(15))+' - '+ cast(@SchemeYear as varchar(15))+' - '+ cast(@AcctPeriod as varchar(15))

select @SqlStr =('Delete from Members where SchemeNo = ' +@SchemeNo +' and MemberNo = ' + cast(@MemberNo as varchar(15)))

insert into Audit_Deletes(TableName,INSERTDESC,PrimaryKey,TransDate,UserName,ReverseQuery)
values ('Member Opening Balances',@InsertDesc,@PrimaryKey,getdate(),user,@SqlStr)
go

