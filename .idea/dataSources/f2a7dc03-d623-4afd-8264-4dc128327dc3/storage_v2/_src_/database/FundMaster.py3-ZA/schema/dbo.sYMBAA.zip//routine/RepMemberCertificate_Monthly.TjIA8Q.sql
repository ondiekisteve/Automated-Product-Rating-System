/* Last Modified on 27/4/2005 AT AFFS*/                    
                                            
---tested and Verified  --- Last Modified 09 December 2004                                            
CREATE PROCEDURE [dbo].[RepMemberCertificate_Monthly]                                            
@SCHEMENO Int,                                            
@curMonth int,                                            
@CurYear int,                                            
@rangestart int,                                            
@rangeend int,                                            
@YearEnd Int,                                          
@Registered Int, /* 0 - Registered, 1 - UnRegistered */                                        
@SponsorCode Int                                             
--with Encryption                                            
as                                            
                                            
set nocount on                                            
                                            
if object_id('tempdb..#MemberCertificate') is null                                            
                                            
begin                                            
create table #MemberCertificate                                            
(                                            
             [MembNo][Int] identity(1,1) Primary Key,                                                 
             [SchemeNo] [varchar] (15) NOT NULL ,                                            
             [MemberNo] int NOT NULL ,                                            
             [Fullname] [varchar](100) NOT NULL ,                                            
             [curYear][int] not null,                                             
             [SumAssured] DECIMAL(20,2)  NULL ,                                            
             [EmpOpBal] DECIMAL(20,2)not  NULL ,                                            
             [EmprOpBal]DECIMAL(20,2) not null,                                 
             [AVCOpBal]DECIMAL(20,2) not null,                                
             [AVCerOpBal]DECIMAL(20,2) not null,                                            
             [Empcont]DECIMAL(20,2) not null,                                            
             [EmprCont] DECIMAL(20,2)  not null ,                                            
             [EmpVolCont]DECIMAL(20,2) null,                                            
             [EmprVolCont]DECIMAL(20,2)  null,                                            
             [EmpTotal]DECIMAL(20,2),                                            
             [EmprTotal]DECIMAL(20,2),                                            
             [EmpInt]DECIMAL(20,2)  NULL ,                                            
             [EmprInt]DECIMAL(20,2)  null,                                            
             [ClosingBal] DECIMAL(20,2)  NULL,                                            
             [EmpCBal]DECIMAL(20,2)  null,                                            
             [EmprCBal]DECIMAL(20,2)  null,                                            
             [EmpTransfer]DECIMAL(20,2) not null,                                            
             [EmprTransfer]DECIMAL(20,2) not null,                                            
             [SchemeName][varchar](100) not null,                                            
             [RetirementAge][int] not null,                                            
             [EndingPeriod] [varchar](25) null,                                            
             [StartDate][Datetime],                                            
             [PayrollNo][varchar](20),                                       
             [IDNumber][varchar](20),                                           

             [Dob][Varchar](20),                                            
             [djpens][Varchar](20),                                            
             [Dje][Varchar](20),                             
             [CurrentAge][Varchar](4),                                            
             [AnnualSalary]DECIMAL(20,2),                                            
             [PreparedBy][varchar](100),                                            
             [ExpectRet][Varchar](20),            
             [PayPoint][Varchar](50),                                            
             [Signatory][Varchar](50),                                            
             [SignatoryTitle][Varchar](50),                      
             [Period][Varchar](30),                                            
             [SummaryDesc][Varchar](400),                                       
             [EndDate][Datetime],                                            
             [TakeOnEmp]DECIMAL(20,2),                                            
             [TakeOnEmpr]DECIMAL(20,2),                                            
             [MinStartDate][Datetime],                                            
             [OpenDesc][Varchar](400),                                            
             [Comments][Varchar](255),                                            
             [Signing][Varchar](200),                                            
             [SchemeDesc][Varchar](100),                                     
             [JoiningDesc][Varchar](100),                                            
             [SAdmin][Varchar](100),                                            
      [AdminAddress] [Varchar](100),                                            
             [AdminTown] [Varchar](100),                                            
             [AdminDivision] [Varchar](100),                                            
             [Telephone][Varchar](100),                                            
             [EMail][Varchar](50),                                            
      [Mwezi][Int],                                            
             [Mwaka][Int],                                            
             [MweziFull][Varchar](30),                                            
             [Employee][Decimal](20,2),                                            
             [Employer][Decimal](20,2),                                            
             [Malipo][Decimal](20,2),                                            
             [TotalCont][Decimal](20,2),                                            
             [TotalOpening][Decimal](20,2),                                            
             [Sponsor][Varchar](120),                                          
             ArEmpCont float,                                          
             ArEmprCont float,                                          
             eTransfer float,                                          
             ErTransfer float,                                   
             AVCEmpCont float,                                          
             AVCEmprCont float,                                        
             ReportDesc Varchar(40),                                            
             InterestRate float,                                
             CommenceDate varchar(20),                                
             Trustees varchar(255),                                
             Auditors varchar(255),                                
             PensionFund varchar(1000),                                
             CurrencyUsed varchar(50),                            
             PoolName varchar(120),              
             AnnuityRate float,          
             PinNo varchar(20),          
             PayPointDesc varchar(20),          
             PinNoDesc varchar(20)                                           
)                                               
end                                            
                                         
declare @memberNo int,@fullname varchar(100),@AnnualSalary float,@EmpOpBal float,@EmprOpBal float,                                            
@EmpCont float,@EmprCont float,@EmpVolCont float,@EmprVolCont float,@EmpCBal float,@EmprCBal float,                                            
@EmpInt float,@EmprInt float,@ClosingBal float,@AmtCov int,@MemberClass varchar(3),@schemeName varchar(100),                                            
@RetAge int,@EmpTransfer float, @EmprTransfer float,@DeathCover Varchar(3),@SumAssured float,@MaxYear int,                                            
@curPeriod varchar(30),@AcctPeriod int, @PeriodToUse int,@StartDate datetime,@PayrollNo varchar(30),                                  
@Dob Datetime,@djpens datetime,@CurrentAge Int,@PreparedBy varchar(100),@ExpectRet Datetime,@LastDate Datetime,                                  
@EndDate Datetime,@PayPoint Varchar(50),@Signatory Varchar(50),@SignatoryTitle Varchar(50),@Period Varchar(30),@SummaryDesc Varchar(400),                                            
@MinAcctPeriod Int,@TakeOnEmp float,@TakeOnEmpr float,@MinStartDate Datetime,@OpenDesc Varchar(400),@ConvertedDate varchar(15),                                            
@Comments Varchar(255),@Signing Varchar(200),@SchemeDesc Varchar(100),@JoiningDesc Varchar(100),@dje Datetime,                                @Admin Varchar(100),@AdminAddress Varchar(100),@AdminTown Varchar(100),@AdminDivision Varchar(100),              
@DJEConvertedDate Varchar(20),@DOBConvertedDate Varchar(20),@showDob bit,@showDje bit,@ShowPayrollNo Bit,                                  
@showDJPENS bit,@DJPENSconvertedDate Varchar(20),@AgeToStr Varchar(4),@ExpectconvertedDate Varchar(20),                                            
@Telephone Varchar(100),@Email Varchar(50),@EmpTotal float,@EmprTotal float,                                            
@Mwezi Int ,@Mwaka Int,@MweziFull Varchar(30),@Employee Decimal(20,6),@Employer Decimal(20,6),@Malipo Decimal(20,6),                                            
@Sponsor Varchar(100), @ArEmpCont FLOAT,@ArEmprCont FLOAT,@ArVolCont FLOAT, @ArSpecial FLOAT,@TelPosta smallInt,                                          
@ETransfer float,@ErTransfer float,@NumYears Int,@NumMonths Int,@NumDays Int,@Counter Int,                                          
@ReportDesc varchar(40),@SchemeMode smallInt,@IDNumber varchar(20),@InterestRate float,@YearClosed smallInt,                                  
@AVCEmpCont float,@AVCEmprCont float,@CommenceDate Datetime,@Trustees varchar(255),@Auditors varchar(255),                                
@TrusteeName varchar(100),@sCommenceDate varchar(20),@PensionFund varchar(1000),@CurrencyUsed varchar(50),                                
@Currency varchar(3),@AVCOpBal float,@AVCerOpBal float,@Zambia smallInt,@Cheki smallInt,                            
@PooledInvestment smallInt,@InvestmentScheme Int,@PoolName varchar(120),@AnnuityRate float,@MStatus int,@Sex char(2),          
@PinNo varchar(20),@PayPointDesc varchar(20),@PinNoDesc varchar(20),@KCM smallint,@AFLIFE smallint,@HiyoDate datetime                                     
                              
select @Cheki = 0                              
                                         
if @Registered = 0                                          
   Select @ReportDesc = 'REGISTERED'                                    
else                                          
   Select @ReportDesc = 'UN REGISTERED'                                            
                                                                   
select @showDob = showDob,@showDje = showDje,@ShowPayrollNo = ShowPayrollNo,@showDJPENS = showDJPENS                                            
from ConfigYearEnd where schemeNo = @schemeNo                                            
                                            
if @showDob is null select @showDob = 1                        
if @showDje is null select @showDje = 1                                            
if @ShowPayrollNo is null select @ShowPayrollNo = 1                                            
if @showDJPENS is null select @showDJPENS = 1                                   
                                            
select @Telephone = 'Tel :'+@Telephone+' E-mail :'+@EMAIL                                            
                                            
if @AdminDivision is null select @AdminDivision = 'Benefit Administration Services'                                           
                                            
select @SchemeDesc = 'Name of Scheme',@JoiningDesc = 'Date of Joining Scheme'                                            
                                            
Select @MinAcctPeriod = AcctPeriod from SchemeYears where schemeNo = @schemeNo                                            
and DatePart(Year,EndDate) = 1999                                            
                                            
Select @MinStartDate = EndDate + 1 from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @MinAcctPeriod                       
                                            
select @Signatory  = 'Approved By',@SignatoryTitle = 'Fund Secretary'                                            
                                            
if not Exists (Select * from RetirementAges where schemeNo = @schemeNo)                                            
   begin                                            
      raiserror ('The Retirement Ages have not been defined for this scheme',16,1)                                            
      return                                 
   end                                            
                                            
SELECT @SummaryDesc = 'N.B. The Accumulated benefits include contributions plus interest based on the Net Returns on the Investments as advised by the Fund Actuary and approved by the Board of Trustees.'                                          
                                            
                                            
--select @SummaryDesc = 'Note : Subject to the Rules relating to termination of employment, entitlement to a percentage of the Employer''s Contribution will be subject to the Vesting Scales in the Scheme.'                                            
                                            
--select @SummaryDesc = 'Note : That your entitlement to the Employers'' contribution is dependent on the vesting scale of the scheme.'                                            
                                            
                                            
Exec DateToStr @MinStartDate,@ConvertedDate Out                                            
                                            
select @OpenDesc = 'N.B. '+@ConvertedDate +' Opening Balances apply to members who were contributing then. Nil opening balances apply to members who''s contributions have not been forwarded to the Fund by the Sponsor                           
and those recruited after '+@ConvertedDate                                            
                                            
select @Comments = 'Issued in duplicate, copy to be noted and returned to the Fund secretary. Queries if any should be raised within Ninety(90) days from the date of this statement failure to which the statement will be deemed correct',                  
  
                             
@Signing = 'Member''s Signature :____________________________________________________                 Date :___________________'                                            
                                            
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out                                            
                                  
select @PreparedBy = '_________________________________ Fund Administrator '--Upper(sName)+', '+fName+' '+Oname from users where UserName = user                                            
                                            
Select @PeriodToUse = @AcctPeriod- 1                                            
                                   
select @StartDate = StartDate,@EndDate = EndDate,@YearClosed = YearClosed                                   
from schemeYears where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod                                            
                                  
if @YearClosed is null select @YearClosed = 0                                  
                                        
Exec GetLastDate @CurMonth,@CurYear,@EndDate Out                                   
                                  
if @YearClosed = 0                                  
   select @InterestRate = ProvRate from InterestRates where schemeNo = @schemeNo and IntrYear = DatePart(Year,@EndDate)                                  
else                                  
   select @InterestRate = InterestRate from InterestRates where schemeNo = @schemeNo and IntrYear = DatePart(Year,@EndDate)                                  
                                           
Exec GetServiceTime @StartDate,@EndDate,@NumYears Out,@NumMonths Out,@NumDays Out                                           
if ((@NumYears = 1) and (@NumMonths = 0))                                          
   select @NumMonths = 12                                          
                          
select @Period = cast(@StartDate as Varchar(14)) + ' -  '+cast(@EndDate as Varchar(14))                                            
                                            
exec GetEndingPeriod @curMonth, @curPeriod out                                            
                                            
Exec GetLastDate @CurMonth,@CurYear,@LastDate Out                                            
                                            
select @curPeriod = @curPeriod +' '+ cast(@CurYear as varchar(4))                                            
                                        
Select @schemeName  = schemeName, @DeathCover = deathCover,@TelPosta = TelPosta,                                        
@SchemeMode = SchemeMode,@CommenceDate = DateCommenced,@Currency = Currency,@Zambia = Zambia,                            
@PooledInvestment = PooledInvestment,@InvestmentScheme = InvestmentScheme,@KCM = KCM,@AFLIFE = AFLIFE                                
from Scheme where schemeCode = @schemeNo                                            
                            
if @PooledInvestment is null select @PooledInvestment = 0                                       
if @SchemeMode is null select @SchemeMode = 0                                
if @Zambia is null select @Zambia = 0 
if @AFLIFE is null select @AFLIFE = 0                            
                            
if @PooledInvestment = 1                          
begin                                        
   select @PoolName = schemeNAME FROM Scheme where schemeCode = @InvestmentScheme                          
   select @Admin = ConsultantName,@AdminAddress = Address,@AdminTown = Town,@AdminDivision = AdminDivision,                                            
   @Telephone = Phone,@EMAIL = Email                                            
   from Scheme_Consultants where SchemeNo = @InvestmentScheme and ConsultantType = 'Administrator'                          
                          
   select @Auditors = ConsultantName+' '+Building+' '+road+', '+Address+' '+Town+' Tel :'+Phone+' facsimile :'+fax                                   
   from Scheme_Consultants where SchemeNo = @InvestmentScheme and ConsultantType = 'Auditor'                          
                          
   if @Auditors is null select @Auditors = ''                          
end                                         
else if @PooledInvestment = 0                          
begin                                        
   select @PoolName = ' '                                
   select @Admin = ConsultantName,@AdminAddress = Address,@AdminTown = Town,@AdminDivision = AdminDivision,                                            
   @Telephone = Phone,@EMAIL = Email                                            
   from Scheme_Consultants where SchemeNo = @SchemeNo and ConsultantType = 'Administrator'                          
                     
   select @Auditors = ConsultantName+' '+Building+' '+road+', '+Address+' '+Town+' Tel :'+Phone+' facsimile :'+fax                                   
   from Scheme_Consultants where SchemeNo = @SchemeNo and ConsultantType = 'Auditor'                          
                          
   if @Auditors is null select @Auditors = ''                          
end                          
                                
select @CurrencyUsed = CurrencyDesc from CurrencyType where CurrencyCode = @Currency           
                                 
/*01 Sep 2008 - KCM Zambia*//*Pinno is the GangNo and Department is the Paypoint for KCM*/          
If @KCM = 1 select @PayPointDesc = 'Paypoint',@PinNoDesc = 'GangNo'          
else select @PayPointDesc = '',@PinNoDesc = ''          
                                
Exec DateToStr @CommenceDate,@sCommenceDate Out                                 
                                
select @PensionFund = 'The Fund was established by Trust Deed on '+@sCommenceDate+' and has been managed by African Life Financial Services (Zambia) Limited.                                                              
The main objective of the Fund is the provision of benefits to members on retirement. Additionally the Fund endeavours to provide benefits to  
dependants of members and pensioners upon their death.'                                      
                                          
select @EmpOpBal = 0                                            
select @EmprOpBal = 0                                            
select @EmpInt = 0                                            
select @EmprInt = 0,@Paypoint = ' ',@TakeOnEmpr=0,@TakeOnEmp=0,                                            
@EmpOpBal = 0, @EmprOpBal=0, @EmpCont=0, @EmprCont=0, @EmpVolCont=0, @EmprVolCont=0,                                             
@EmpInt=0 , @EmprInt=0,@EmpCBal=0, @EmprCBal=0, @EmpTransfer=0, @EmprTransfer=0,                                
@AVCOpBal = 0,@AVCerOpBal=0                                            
                                          
if @Registered = 0                                        
begin                                        
  if @schemeMode = 0                                          
     declare CertCsr cursor for                                             
     select distinct b.schemeNo, b.memberNo,                                            
     (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.MemberClass,                                            
     m.PayrollNo,m.IDNumber,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,m.SponsorCode,m.MStatus,m.Sex,m.PinNo                                          
     from Benefits b inner join Members m on b.schemeNo = m.schemeNo and b.memberNo = m.memberNo and                                             
                         ((m.ReasonForExit = 0) or ((m.ReasonforExit > 0) and (m.ActiveStatus = 6))  or ((m.ReasonforExit > 0) and (m.DoExit > @EndDate))) and m.ActiveStatus <> 3                                            
                        inner Join ExpectRet e on b.schemeNo = e.schemeNo and b.memberNo = e.memberNo                                            
     where b.schemeNo = @schemeNo and b.memberno between @rangestart and @rangeend                                          
     Group by b.schemeNo, b.memberNo,m.sname,m.fname,m.onames,m.MemberClass,                                            
     m.PayrollNo,m.IDNumber,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,m.SponsorCode,m.MStatus,m.Sex,m.PinNo                                             
     order by b.memberNo                                        
  else if @schemeMode = 1                                         
     declare CertCsr cursor for                                             
     select distinct b.schemeNo, b.memberNo,                         
     (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.MemberClass,                                            
     m.PayrollNo,m.IDNumber,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,m.SponsorCode,m.MStatus,m.Sex,m.PinNo                                          
     from Benefits b inner join Members m on b.schemeNo = m.schemeNo and b.memberNo = m.memberNo and                                             
                         ((m.ReasonForExit = 0) or ((m.ReasonforExit > 0) and (m.ActiveStatus = 6)) or ((m.ReasonforExit > 0) and (m.DoExit > @EndDate))) and m.ActiveStatus <> 3                                         
                          and m.SponsorCode = @SponsorCode                                           
      inner Join ExpectRet e on b.schemeNo = e.schemeNo and b.memberNo = e.memberNo                                            
     where b.schemeNo = @schemeNo and b.memberno between @rangestart and @rangeend                                          
     Group by b.schemeNo, b.memberNo,m.sname,m.fname,m.onames,m.MemberClass,                                            
     m.PayrollNo,m.IDNumber,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,m.SponsorCode,m.MStatus,m.Sex,m.PinNo                                             
     order by b.memberNo                                        
end         
else if @Registered = 1                                         
begin                            
     if @schemeMode = 0                                          
        declare CertCsr cursor for                                             
        select distinct b.schemeNo, b.memberNo,                                            
        (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.MemberClass,                                            
        m.PayrollNo,m.IDNumber,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,m.SponsorCode,m.MStatus,m.Sex,m.PinNo                                   
        from UnRegisteredBenefits b inner join Members m on b.schemeNo = m.schemeNo and b.memberNo = m.memberNo and                                             
                         ((m.ReasonForExit = 0) or ((m.ReasonforExit > 0) and (m.ActiveStatus = 6)) or ((m.ReasonforExit > 0) and (m.DoExit > @EndDate))) and m.ActiveStatus <> 3                                            
                        inner Join ExpectRet e on b.schemeNo = e.schemeNo and b.memberNo = e.memberNo                                            
        where b.schemeNo = @schemeNo and b.memberno between @rangestart and @rangeend                                          
        Group by b.schemeNo, b.memberNo,m.sname,m.fname,m.onames,m.MemberClass,                                            
        m.PayrollNo,m.IDNumber,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,m.SponsorCode,m.MStatus,m.Sex,m.PinNo                                      
        order by b.memberNo                                         
     else                                        
        declare CertCsr cursor for                                             
        select distinct b.schemeNo, b.memberNo,                                            
        (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.MemberClass,                                            
        m.PayrollNo,m.IDNumber,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,m.SponsorCode,m.MStatus,m.Sex,m.PinNo                                          
        from UnRegisteredBenefits b inner join Members m on b.schemeNo = m.schemeNo and b.memberNo = m.memberNo and                                             
                         ((m.ReasonForExit = 0) or ((m.ReasonforExit > 0) and (m.ActiveStatus = 6)) or ((m.ReasonforExit > 0) and (m.DoExit > @EndDate))) and m.ActiveStatus <> 3                                        
                         and m.SponsorCode = @SponsorCode                                            
                        inner Join ExpectRet e on b.schemeNo = e.schemeNo and b.memberNo = e.memberNo                                            
        where b.schemeNo = @schemeNo and b.memberno between @rangestart and @rangeend                                          
        Group by b.schemeNo, b.memberNo,m.sname,m.fname,m.onames,m.MemberClass,                                            
        m.PayrollNo,m.IDNumber,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,m.SponsorCode,m.MStatus,m.Sex,m.PinNo                                             
        order by b.memberNo                                        
end                              
                                           
Open CertCsr                                            
                                            
fetch from CertCsr into @schemeNo, @MemberNo, @fullname, @memberClass,@PayrollNo,@IDNumber,@AnnualSalary,@dob,@djpens,@dje,                                       
@ExpectRet,@Paypoint,@SponsorCode,@MStatus,@Sex,@PinNo                                            
                                            
while @@fetch_status = 0                                            
begin                                            
  select @Sponsor = SponsorName from Sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode                                           
  if @Sponsor is null select @Sponsor = ''                                          
              
  Exec DateToStr @dje,@djeConvertedDate Out                                            
  Exec DateToStr @dob,@dobConvertedDate Out                 
  Exec DateToStr @djpens,@djpensConvertedDate Out                                            
  Exec DateToStr @ExpectRet,@ExpectconvertedDate out                                            
                                            
  if @Registered = 0                                          
  select @empOpBal = (empCont + Transfer), @EmprOpBal = (emprCont + LockedIn),                                
  @AVCOpBal = empVolCont ,@AVCerOpBal =  emprVolCont                                             
  from MemberOpeningBalances where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @PeriodToUse                                          
  else if @Registered = 1                                            
  select @empOpBal = (Excessemp ) - (EmpTax), @EmprOpBal = (Excessempr) - (EmprTax),                                
  @AVCOpBal = ExcessVolContr - VolTax ,@AVCerOpBal =  ExcessSpecial - SpecTax                                              
  from UnRegisteredBalances where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @PeriodToUse                                          
                              
  if @empOpBal is null select @empOpBal = 0                                            
  if @emprOpBal is null select @emprOpBal = 0                                 
  if @AVCOpBal is null select @AVCOpBal = 0                                            
  if @AVCerOpBal is null select @AVCerOpBal = 0                                           
                                            
  select @CurrentAge = Datediff(day,@Dob,@Lastdate)/365                                            
              
  if @Sex = 'F'              
    begin              
       if @MStatus = 2              
         begin              
           select @AnnuityRate = AnnuitySpouse from AnnuityPackage where schemeno = @Schemeno and Gender = 1              
           and Age = @CurrentAge            
            
           If @AnnuityRate is null select @AnnuityRate = AnnuitySpouse from AnnuityPackage where schemeno = @Schemeno and Gender = 1              
           and Age = 45              
         end               
 else              
         begin              
           select @AnnuityRate = Annuity from AnnuityPackage where schemeno = @Schemeno and Gender = 1              
           and Age = @CurrentAge            
            
           If @AnnuityRate is null select @AnnuityRate = Annuity from AnnuityPackage where schemeno = @Schemeno and Gender = 1             
           and Age = 45              
         end               
    end              
  else if @Sex = 'M'              
    begin              
       if @MStatus = 2              
         begin              
        select @AnnuityRate = AnnuitySpouse from AnnuityPackage where schemeno = @Schemeno and Gender = 0              
           and Age = @CurrentAge            
            
           If @AnnuityRate is null select @AnnuityRate = AnnuitySpouse from AnnuityPackage where schemeno = @Schemeno and Gender = 0              
           and Age = 45               
         end               
 else              
         begin              
           select @AnnuityRate = Annuity from AnnuityPackage where schemeno = @Schemeno and Gender = 0              
           and Age = @CurrentAge            
            
           If @AnnuityRate is null select @AnnuityRate = Annuity from AnnuityPackage where schemeno = @Schemeno and Gender = 0              
           and Age = 45             
         end               
    end              
            
                              
  if @Registered = 0                                          
  exec RepMemberCertificateContributions @schemeNo, @MemberNo, @curMonth, @curYear,@EmpCont out,                                            
  @EmprCont out, @EmpVolCont out, @EmprVolCont out                                          
  else                                          
  exec RepMemberCertificateContributions @schemeNo, @MemberNo, @curMonth, @curYear,@EmpCont out,                                            
@EmprCont out, @EmpVolCont out, @EmprVolCont out                                          
                                             
                                          
if @Registered = 0                                          
begin                                           
if @YearEnd = 0                                            
select @EmpCBal = EmpCont + VolContr + EmpTransfer, @EmprcBal = EmprCont + SpecialContr + EmprTransfer                                            
   from Benefits where SchemeNo = @schemeNo and MemberNo = @MemberNo                                             
else if @YearEnd = 1                                            
   select @EmpCBal = EmpCont + EmpVolCont + Transfer, @EmprcBal = EmprCont + EmprVolCont + LockedIn                                            
   from MemberOpeningBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod                                           
end                                          
else                                          
begin                                           
if @YearEnd = 0                                            
   select @EmpCBal = ExcessEmpCont + ExcessVolContr, @EmprcBal = ExcessEmprCont + ExcessSpecial                                            
   from UnRegisteredBenefits where SchemeNo = @schemeNo and MemberNo = @MemberNo                                            
else if @YearEnd = 1                                            
   select @EmpCBal = ExcessEmp + ExcessVolContr, @EmprcBal = ExcessEmpr + ExcessSpecial                                            
   from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod                                           
end                                           
                                          
                                          
if @Registered = 0                                          
   exec RepMemberCertificateTransfer @schemeNo, @MemberNo, @AcctPeriod, @EmpTransfer out,@EmprTransfer out                                            
                                          
if @EmpTransfer is null select @EmpTransfer = 0                                            
if @EmprTransfer is null select @EmprTransfer = 0                                            
                                            
select  @AmtCov = amtCov from AmountOfCover where schemeNo = @schemeNo and ClassId = @MemberClass                                            
                                             
if @AmtCov is null select @AmtCov = 0                                          
                                             
Select @RetAge = MRetAge from RetirementAges where schemeNo = @schemeNo and ClassId = @MemberClass                                            
                                        
IF @empVolcont Is null select @empVolcont = 0                                            
if @EmpTransfer is null select @EmpTransfer = 0                                            
                                            
if ((@empCBal  is null) or (@empCBal = 0))                                             
   begin                                            
          select @empCBal = 0                                            
                                                     
          select @EmpInt = 0                                               
   end                                            
else                                            
  select @EmpInt = (@empCBal - (@empcont + @empVolcont + @empopBal + @EmpTransfer + @avcopBal ))                                            
                                            
if (@emprCBal  is null) or (@emprCBal = 0)                                            
   begin                                            
          select @emprCBal = 0                                            
   end                                            
else                                            
          select @EmprInt =  (@emprCBal - (@emprcont + @emprVolcont + @empropBal + @EmprTransfer + @avcEropBal ))                                            
                                
if @Zambia = 0                                                      
   Select @TakeOnEmp = EmpCont + PreEmpCont + PreAvc + EmpVolCont,@TakeOnEmpr = EmprCont + PreEmprCont + EmprVolCont                                            
   from MemberOpeningBalances where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @MinAcctPeriod                                            
                                            
if @TakeOnEmp is null select @TakeOnEmp = 0                                            
if @TakeOnEmpr is null select @TakeOnEmpr = 0                                            
                                            
                                            
if @ShowDje = 0                                            
   select @DJEConvertedDate = '  '                                            
                                            
--if @DJEConvertedDate = '01/01/1980'                                         
   --select @DJEConvertedDate = '  '                                            
                                            
if @ShowDob = 0                                            
   begin                                            
   select @DOBConvertedDate = '  '                                            
   select @AgeToStr = '  '                                            
   end                                            
else                  
  select @AgeToStr = Cast (@CurrentAge as Varchar(4))                                            
                                            
/*                                            
if @DOBConvertedDate = '01/01/1960'                                            
  begin                                            
    select @DOBConvertedDate = '  '                                            
       select @AgeToStr = '  '                                            
       select @ExpectconvertedDate = ' '                                            
  end
*/                                            
                                            
if @ShowPayrollNo = 0                                            
   select @PayrollNo = '  '                                            
                                            
if @ShowDJPENS = 0                                            
   select @DJPENSConvertedDate = '  '                        
                                            
   --if @DJPENSConvertedDate = '01/01/1980'                                            
   --select @DJPENSConvertedDate = '  '                                            
                                            
   select @EmpTotal = @EmpOpBal + @EmpCont + @EmpVolCont + @avcOpBal, @EmprTotal = @EmprOpBal + @avcErOpBal + @EmprCont + @EmprVolCont                                          
                                      
   /* MAMBO */                                       
   select @Counter = DatePart(Month,@StartDate),@Mwaka = datePart(Year,@StartDate)                              
   while @Counter <= (@NumMonths + DatePart(Month,@StartDate)) - 1                                       
   begin                                
   if @Counter > 12                              
      select @Mwezi = @Counter - 12                                
   else                                          
      select @Mwezi = @Counter                                         
                                          
   Exec GetMonthName @mwezi,@MweziFull Out                                            
                                            
   select @MweziFull = @MweziFull +', '+Cast(@Mwaka as Varchar(4))

   Exec GetLastDate @Mwezi,@Mwaka,@HiyoDate Out

   EXEC Proc_Get_Int_Rate @schemeNo,@HiyoDate,1,@InterestRate Out                            
                                        
   if @Registered = 0                                          
      Select @Employee = sum(EmpCont),@AVCEmpCont = sum(VolContr),                                  
      @Employer = sum(EmprCont),@AVCEmprCont = sum(SpecialContr),                                  
      @Malipo = sum(Salary)                                            
      from Contributionssummary where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                             
      AcctPeriod = @AcctPeriod and DatePart(Year,DatePaid) = @Mwaka and DatePart(Month,DatePaid) = @Mwezi                                          
   else                                             
      Select @Employee = sum(ExcessEmpCont),@AVCEmpCont = sum(ExcessVolContr),                                  
      @Employer = sum(ExcessEmprCont),@AVCEmprCont = sum(ExcessSpecial),@Malipo = 0.0                                            
      from UnRegisteredContributionssummary where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                             
      AcctPeriod = @AcctPeriod and DatePart(Year,DatePaid) = @Mwaka and DatePart(Month,DatePaid) = @Mwezi                                          
                                  
  if @Employee is null select @Employee = 0                                            
  if @Employer is null Select @Employer = 0                                    
  if @AVCEmpCont is null select @AVCEmpCont = 0                                            
  if @AVCEmprCont is null Select @AVCEmprCont = 0                                  
                                         
  if @Malipo is null Select @Malipo = 0                                            
                                            
  if @Registered = 0                                          
     Select @ArEmpCont = sum(ArEmpCont) ,@ArEmprCont = sum(ArEmprCont),@ArVolCont = sum(ArVolContr),                                             
     @ArSpecial = sum(ArSpecial)                                            
     from ContributionArrears where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                             
   AcctPeriod = @AcctPeriod and DatePart(Year,DatePaid) = @Mwaka and DatePart(Month,DatePaid) = @Mwezi                                       
  else                                          
     Select @ArEmpCont = sum(ArEmpCont_Un) ,@ArEmprCont = sum(ArEmprCont_Un),@ArVolCont = 0.0,                                             
     @ArSpecial = 0.0                                            
     from ContributionArrears where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                             
     AcctPeriod = @AcctPeriod and DatePart(Year,DatePaid) = @Mwaka and DatePart(Month,DatePaid) = @Mwezi                                             
                                              
                                           
                                          
  if @ArEmpCont is null select @ArEmpCont = 0                                            
  if @ArEmprCont is null Select @ArEmprCont = 0                                            
  if @ArVolCont is null Select @ArVolCont = 0                                            
  if @ArSpecial is null select @ArSpecial = 0                                            
                                          
  if @Registered = 0                                          
     Select @ETransfer = sum(EmpTransfer + AvcTransfer) ,@ErTransfer = sum(EmprTransfer + AVCErTransfer)                          from MemberTransfer where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                             
     AcctPeriod = @AcctPeriod and DatePart(Year,TransferDate) = @Mwaka and DatePart(Month,TransferDate) = @Mwezi                                           
  else                                            
     Select @ETransfer = sum(EmpTransfer + AvcTransfer) ,@ErTransfer = sum(EmprTransfer + AVCErTransfer)                                           
     from MemberTransferUn where SchemeNo = @SchemeNo and MemberNo = @MemberNo and                                             
     AcctPeriod = @AcctPeriod and DatePart(Year,TransferDate) = @Mwaka and DatePart(Month,TransferDate) = @Mwezi                                      
                                          
  if @ETransfer is null select @ETransfer = 0                                              
  if @ErTransfer is null Select @ErTransfer = 0                                           
                                          
  --Select @Employee = @Employee + @ArEmpCont + @ArVolCont + @ETransfer,                                          
  --@Employer = @Employer + @ArEmprCont + @ArSpecial + @ErTransfer            
          
/*Pinno is the GangNo and Department is the Paypoint for KCM*/                                       
   If @KCM = 0 select @Paypoint = '',@PinNo = ''                                          
          
   insert into #MemberCertificate (schemeNo, MemberNo, fullname, curYear, SumAssured, EmpOpBal, EmprOpBal, EmpCont, EmprCont,                                             
   EmpVolCont, EmprVolCont, EmpInt,EmprInt, ClosingBal,                                            
   SchemeName, RetirementAge, EmpCBal, EmprCBal, EmpTransfer, EmprTransfer, EndingPeriod,                                            
   PayrollNo,IDNumber,AnnualSalary,dob,djpens,CurrentAge,PreparedBy,StartDate,ExpectRet,Paypoint,Period,Signatory,SignatoryTitle,                                            
   SummaryDesc,EndDate,TakeOnEmp,TakeOnEmpr,MinStartDate,OpenDesc,Comments,Signing,dje,SchemeDesc,JoiningDesc,                                            
   SAdmin,AdminAddress,AdminTown,AdminDivision,Telephone,EMAIL,EmpTotal,EmprTotal,Mwezi,Mwaka,Employee,Employer,MweziFull,Malipo,TotalCont,                                            
   TotalOpening,Sponsor,ArEmpCont,ArEmprCont,eTransfer,ErTransfer,ReportDesc,InterestRate,AVCEmpCont,AVCEmprCont,                                
   Auditors,CommenceDate,PensionFund,CurrencyUsed,avcOpBal,avcErOpBal,PoolName,AnnuityRate,PinNo,PayPointDesc,PinNoDesc)                                  
                                            
   values(@schemeNo, @Memberno, @fullname, @curYear, @SumAssured, @EmpOpBal, @EmprOpBal, @EmpCont, @EmprCont, @EmpVolCont, @EmprVolCont,                                             
          @EmpInt , @EmprInt,  @empCBal + @emprCBal, @SchemeName,           
          @RetAge, @EmpCBal, @EmprCBal, @EmpTransfer, @EmprTransfer, @curPeriod,                                            
          @PayrollNo,@IDNumber,@AnnualSalary,@dobConvertedDate,@djpensConvertedDate,@AgeToStr,@PreparedBy,@StartDate,@ExpectconvertedDate,                                            
          @Paypoint,@Period,@Signatory,@SignatoryTitle,@SummaryDesc,@EndDate,@TakeOnEmp,@TakeOnEmpr,@MinStartDate,@OpenDesc,                                            
          @Comments,@Signing,@djeConvertedDate,@SchemeDesc,@JoiningDesc,                                            
          @Admin,@AdminAddress,@AdminTown,@AdminDivision,@Telephone,@Email,@EmpTotal,@EmprTotal,@Mwezi,@Mwaka,@Employee,@Employer,@MweziFull,@Malipo,                    
          @Employee+@Employer + @AVCEmpCont + @AVCEmprCont + @eTransfer + @ErTransfer + @ArEmpCont + @ArEmprCont,                                            
          @EmpOpBal + @EmprOpBal + @avcOpBal + @avcErOpBal,@Sponsor,@ArEmpCont + @ArVolCont, @ArEmprCont + @ArSpecial,@eTransfer,                                  
          @ErTransfer,@ReportDesc,@InterestRate,@AVCEmpCont,@AVCEmprCont,@Auditors,@sCommenceDate,@PensionFund,@CurrencyUsed,                                
          @avcOpBal,@avcErOpBal,@PoolName,@AnnuityRate,@PinNo,@PayPointDesc,@PinNoDesc)                                            
                                            
   select @Counter = @Counter + 1                              
                                 
   if ((@Cheki = 0) and (@Counter > 12))                              
      begin                              
        select @Cheki = 1,@Mwaka = @Mwaka + 1                              
      end                                       
 end                                          
                                           
select @EmpOpBal = 0                                            
select @EmprOpBal = 0         
select @EmpInt = 0                                            
select @EmprInt = 0,@Paypoint = ' ',@TakeOnEmpr=0,@TakeOnEmp=0,                                            
@EmpOpBal = 0, @EmprOpBal=0, @EmpCont=0, @EmprCont=0, @EmpVolCont=0, @EmprVolCont=0,                                             
@EmpInt=0 , @EmprInt=0,@EmpCBal=0, @EmprCBal=0, @EmpTransfer=0, @EmprTransfer=0,@EmpTotal = 0,@EmprTotal=0,                                            
@Mwezi= 0,@Mwaka=0,@Employee=0,@Employer=0,@MweziFull= '',@Malipo = 0,@Sponsor = '',                                            
@ArEmpCont = 0,@ArEmprCont = 0,@ArVolCont = 0, @ArSpecial = 0,@eTransfer=0,@ErTransfer=0,@Paypoint = '',                                          
@SponsorCode = 0,@AVCEmpCont=0,@AVCEmprCont=0,@avcOpBal = 0,@avcErOpBal=0,@Cheki = 0,@MStatus = 6,@Sex = '',@PinNo = ''          
                                            
fetch next from CertCsr into @schemeNo, @MemberNo, @fullname, @memberClass,@PayrollNo,@IDNumber,@AnnualSalary,@dob,@djpens,@dje,                                            
@ExpectRet,@Paypoint,@SponsorCode,@MStatus,@Sex,@PinNo          
                                            
end                                     
                                            
close certCsr                                            
Deallocate CertCsr                                            
                                
select @Counter = 0                          
if @PooledInvestment = 1                                        
   Declare TCsr Cursor for                                
   select TrusteeName from Trustees                                 
   where schemeNo = @InvestmentScheme and CurrentT = 1                                
   Order by TrusteesCode                                          
else if @PooledInvestment = 0                           
   Declare TCsr Cursor for                                
   select TrusteeName from Trustees                                 
   where schemeNo = @schemeNo and CurrentT = 1                                
   Order by TrusteesCode                                     
                                
Open TCsr                                
fetch from TCsr into @TrusteeName                                
while @@fetch_Status = 0                                
begin                                
  if @Counter = 0                                
  select @Trustees = @TrusteeName                                
  else                  
  select @Trustees = @Trustees+'               '+@TrusteeName                                
                                
  select @TrusteeName = ''                                
  select @Counter = @Counter + 1                                
  fetch next from TCsr into @TrusteeName                                
end                                
Close TCsr                             
Deallocate TCsr                                 
                           
update #MemberCertificate set Trustees = @Trustees                                        

if @AFLIFE = 1
   select * from #MemberCertificate where ClosingBal > 0 order by left(fullname,20),Mwaka,Mwezi 
else                                            
   select * from #MemberCertificate where ClosingBal > 0 order by Pinno desc,MemberNo,Mwaka,Mwezi
go

