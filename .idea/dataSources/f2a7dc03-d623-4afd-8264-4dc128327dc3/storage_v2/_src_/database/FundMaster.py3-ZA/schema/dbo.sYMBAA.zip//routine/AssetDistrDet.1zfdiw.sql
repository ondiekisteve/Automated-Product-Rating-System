








































CREATE PROCEDURE AssetDistrDet
@SCHEMENO Int,
@AssetDate Datetime,
@AssetMode Int
--with Encryption
as
Select A.*, I.InvestDesc, i.MaxPcntofAsset
from AssetAllocationDet a
     Inner Join InvestmentTypes i
           on a.AssetClass = i.InvestCode
where a.AssetMode = @AssetMode and a.SchemeNo = @SchemeNo
and a.AssetDate = @AssetDate


go

