CREATE PROCEDURE [dbo].[p_B4_June_2002]
@schemeNo Int
as

Delete from B4Jun2002
 
declare @MEMBERNO INT,@DatePaid Datetime,@cYear Int,@cMonth Int,@FullName varchar(120),@MinDate Datetime,
@AcctPeriod Int,@StartAcct int

declare acsr cursor for
Select m.MemberNo,m.sName+' '+m.fName+' '+m.Onames,Min(c.DatePaid) from Members m
inner Join Contributionssummary c on m.schemeNo = c.schemeNo and m.MemberNo = c.MemberNo
AND C.DatePaid <= 'Jun 30,2002'
where m.schemeNo = 1208 and M.REASONFOREXIT = 0 
GROUP BY M.mEMBERNO,m.sName,m.fName,m.Onames ORDER BY m.MemberNo

OPEN ACSR
FETCH FROM ACSR INTO @MemberNo,@fullName,@MinDate
while @@fetch_Status = 0
begin
    select @cYear = Datepart(Year,@minDate),@cMonth = DatePart(Month,@minDate)

    select @AcctPeriod = AcctPeriod from schemeYears 
    where schemeNo = @schemeNo and @MinDate >= StartDate and @MinDate <= endDate

    select @StartAcct = @AcctPeriod



    while @acctPeriod <= 32
    begin
       if @AcctPeriod > 0
        begin
          if not Exists(select MEMBERNO From Contributionssummary where schemeNo = @schemeNo and MemberNo = @MemberNo
                     and AcctPeriod = @AcctPeriod)
          begin
             insert into B4Jun2002(MemberNo,FullName,cMonth,cYear)
                      Values(@MemberNo,@FullName,@cMonth,@cYear)
          end
        end
       select @cMonth = DatePart(Month,EndDate),@cYear = DatePart(Year,EndDate) from SchemeYears
       where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod + 1

       select @AcctPeriod = @AcctPeriod + 1 
    end 
  select @AcctPeriod = 0,@cYear = 0,@cMonth = 0,@StartAcct = 0,@MinDate = getdate(),@MemberNo = 0,@FullName =''
  FETCH next FROM ACSR INTO @MemberNo,@fullName,@MinDate
end
Close ACSR
Deallocate Acsr

select * from B4Jun2002 order by MemberNo
go

