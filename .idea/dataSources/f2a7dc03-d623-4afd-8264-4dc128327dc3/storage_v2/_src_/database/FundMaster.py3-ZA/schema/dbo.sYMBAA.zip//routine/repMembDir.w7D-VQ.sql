CREATE PROCEDURE [dbo].[repMembDir]            

@SCHEMENO Int,            

@ProcDate Datetime            

--with Encryption            

as            

            

set nocount on            

set concat_null_yields_null off            

            

declare @retCode int, @funcResult int, @currYear int, @yearClosed bit,@SchemeName varchar(120),            

@AcctPeriod Int,@Employee float,@Employer float,@AVC float,@AVCEr float,            

@fullName varchar(100),@DOB datetime,@DJE datetime,@djpens datetime,@annSal float,            

@EmployeeCont float,@EmployerCont float,@AVCCont float,@AVCErCont float,            

@EmployeeContUn float,@EmployerContUn float,@AVCContUn float,@AVCErContUn float,            

@EmployeeUn float,@EmployerUn float,@AVCUn float,@AVCErUn float,@Transfer float,            

@MemberNo Int,@PreEmployee float,@PreEmployer float,@PreAVC float,@Deficit float,            

@SchemeMode SmallInt,@SponsorName varchar(100),@PooledInvestment smallInt,@SchemeCode Int,        

@PoolName varchar(120),@FundType varchar(2),@IDNumber varchar(20),@PayrollNo varchar(20)           

            

Select @AcctPeriod = AcctPeriod from SchemeYears where SchemeNo = @schemeNo and StartDate <= @procDate            

and EndDate >= @ProcDate            

            

if object_id('tempdb..##membDir') is not null drop table ##membDir            

            

--Select @SchemeName = SchemeName,@SchemeMode = SchemeMode from scheme where schemeCode = @SchemeNo           

            

create table ##membDir            

(         

  glcode int IDENTITY(1,1) PRIMARY KEY ,        

  memberNo int not null,            

  CheckNo Int not null,            

  fullName varchar(50) not null,      

  IDNumber varchar(20),      

  PayrollNo varchar(20),            

  DOB datetime,            

  DJE datetime,            

  djpens datetime,            

  annSal float default 0,            

  EmployeeOp float default 0,            

  EmployerOp float default 0,            

  AVCOp float default 0,            

  AVCErOp float default 0,            

  Employee float default 0,            

  Employer float default 0,            

  AVC float default 0,            

  AVCEr float default 0,            

  PreEmployee float default 0,            

  PreEmployer float default 0,            

  PreAVC float default 0,            

  Deficit float default 0,            

  Frozen float default 0,            

  Transfer float default 0,            

  Total float default 0,            

  schemeName varchar(120) null,            

  Period Datetime,            

  SponsorName varchar(100),        

  PoolName varchar(120)            

              

)            

            

if @@error <> 0            

begin            

  select @retCode = 1            

  goto just_go            

end            

            

if not exists(select count(MemberNo) from Members where SchemeNo = @schemeNo)            

begin            

  raiserror('There are no members in the scheme', 16, 1)            

  select @retCode = 1            

  goto just_go            

end            

            

Delete from ##membDir            

        

select @PoolName = schemeName,@SchemeMode = schemeMode,@PooledInvestment = PooledInvestment,@FundType = FundType        

from scheme where schemeCode = @schemeNo         

        

            

if @FundType = 'PF'        

BEGIN        

Declare MembDirCsr cursor for        

select schemeCode,schemeName,SchemeMode from Scheme        

where PooledInvestment = 1 and InvestmentScheme = @schemeNo        

Open MembDirCsr        

Fetch from MembDirCsr into @schemeCode,@schemeName,@SchemeMode        

while @@fetch_Status = 0        

begin        

if @schemeMode is null select @schemeMode = 0        

        

if @schemeMode = 0 /* Single Mode */            

begin            

declare Acsr Cursor for           

select CheckNo, MemberNo, upper(sName) + ', ' + fName + ' ' + oNames as fullName,IDNumber,PayrollNo, DOB, DJE, djpens,  
CAPenSal,            
' '          
from Members where SchemeNo = @schemeCode and ((ReasonForExit = 0)                                       

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 0) and (InitialDoCalc <= @ProcDate))       

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 0) and (InitialDoCalc > @ProcDate))     

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 1) and (InitialDoCalc > @ProcDate))             

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 1) and (InitialDoCalc <= @ProcDate) and (DoCalc > @ProcDate))       

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 1) and (InitialDoCalc >= @ProcDate) and (DoCalc > @ProcDate))                 

      OR ((ReasonForExit > 0) AND (ActiveStatus <> 6) and (DoCalc > @ProcDate)))                            

      and Post_Status = 2 and djpens <= @ProcDate                        

order by memberNo            

end            

else if @schemeMode = 1 /* Umbrella Mode */            

begin            

declare Acsr Cursor for            

select m.CheckNo, m.MemberNo, upper(m.sName) + ', ' + m.fName + ' ' + m.oNames as fullName,m.IDNumber,m.PayrollNo, m.DOB, m.DJE, m.djpens,m.CAPenSal,            

s.SponsorName            

from Members m             

     inner join Sponsor s ON M.schemeNo = s.schemeNo and m.SponsorCode = s.SponsorCode            

where m.SchemeNo = @schemeCode and ((M.ReasonForExit = 0)                                       

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 0) and (M.InitialDoCalc <= @ProcDate))       

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 0) and (M.InitialDoCalc > @ProcDate))     

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 1) and (M.InitialDoCalc > @ProcDate))             

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 1) and (M.InitialDoCalc <= @ProcDate) and (M.DoCalc > @ProcDate))       

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 1) and (M.InitialDoCalc >= @ProcDate) and (M.DoCalc > @ProcDate))                 

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus <> 6) and (M.DoCalc > @ProcDate)))                            

      and M.Post_Status = 2 and M.djpens <= @ProcDate                                 

order by m.memberNo            

end        

           

open acsr            

fetch from acsr into @MemberNo,@MemberNo,@fullName,@IDNumber,@PayrollNo,@dob,@dje,@djpens,@AnnSal,@SponsorName            

while @@fetch_Status = 0            

begin                                                      

  select @Employee  = EmpCont,@Employer =EmprCont,@AVC = EmpVolCont,@AVCEr = EmprVolCont,            

  @PreEmployee = PreEmpCont,@PreEmployer = PreEmprCont,@PreAVC = PreAvc,            

  @Transfer = Transfer            

  from MemberOpeningBalances where SchemeNo = @schemeCode and MemberNo = @MemberNo            

  and AcctPeriod = @AcctPeriod - 1            

            

  if @Employee is null select  @Employee = 0            

  if @Employer is null select @Employer = 0            

  if @AVC is null select @AVC = 0            

  if @AVCEr is null select @AVCEr = 0            

  if @PreEmployee is null select @PreEmployee = 0            

  if @PreEmployer is null select @PreEmployer = 0            

  if @PreAVC is null select @PreAVC = 0            

  if @Transfer is null select @Transfer = 0            

            

  select @EmployeeUn  = ExcessEmp,@EmployerUn =ExcessEmpr,@AVCUn = ExcessVolContr,@AVCErUn = ExcessSpecial            

  from UnRegisteredBalances where SchemeNo = @schemeCode and MemberNo = @MemberNo            

  and AcctPeriod = @AcctPeriod - 1            

            

  if @EmployeeUn  is null select @EmployeeUn = 0     

  if @EmployerUn is null select @EmployerUn = 0            

  if @AVCUn is null select @AVCUn = 0            

  if @AVCErUn is null select @AVCErUn = 0            

              

  select @Employee = @Employee + @EmployeeUn,@Employer = @Employer + @EmployerUn,            

  @Avc = @Avc + @AvcUn,@AvcEr = @AvcEr + @AvcErUn            

            

  select @EmployeeCont = sum(EmpCont),@EmployerCont = sum(EmprCont),@AVCCont  = sum(VolContr),            

  @AVCErCont = sum(SpecialContr),@Deficit = sum(AugCont)            

  from Contributionssummary where SchemeNo = @schemeCode and MemberNo = @MemberNo            

  and AcctPeriod = @AcctPeriod            

            

  if @EmployeeCont is null select @EmployeeCont = 0            

  if @EmployerCont is null select @EmployerCont = 0            

  if @AVCCont is null select @AVCCont = 0             

  if @AVCErCont is null select @AVCErCont = 0            

  if @Deficit is null select @Deficit = 0            

            

  select @EmployeeContUn = sum(ExcessEmpCont),@EmployerContUn = sum(ExcessEmprCont),            

  @AVCContUn  = sum(ExcessVolContr),@AVCErContUn = sum(ExcessSpecial)            

  from UnRegisteredContributionssummary where SchemeNo = @schemeCode and MemberNo = @MemberNo            

  and AcctPeriod = @AcctPeriod            

            

  if @EmployeeContUn is null select @EmployeeContUn = 0            

  if @EmployerContUn is null select @EmployerContUn = 0            

  if @AVCContUn is null select @AVCContUn = 0            

  if @AVCErContUn is null select @AVCErContUn = 0            

              

  select @EmployeeCont = @EmployeeCont + @EmployeeContUn            

  select @EmployerCont = @EmployerCont + @EmployerContUn            

  select @AVCCont = @AVCCont + @AVCContUn            

  select @AVCErCont = @AVCErCont + @AVCErContUn            

            

              

  Insert Into ##membDir(            

  memberNo,            

  CheckNo,            

  fullName,IDNumber,PayrollNo,            

  DOB,            

  DJE,            

  djpens,            

  annSal,            

  EmployeeOp,            

  EmployerOp,            

  AVCOp,            

  AVCErOp,            

  Employee,            

  Employer,            

  AVC,            

  AVCEr,            

  PreEmployee,            

  PreEmployer,            

  PreAVC,       

  Frozen,            

  Transfer,            

  Total,            

  schemeName,            

  Period,            

  Deficit,SponsorName,PoolName)            

  Values(@MemberNo,@MemberNo,@FullName,@IDNumber,@PayrollNo,@dob,@dje,@djpens,@AnnSal,@Employee,@Employer,@avc,@avcer,            

         @EmployeeCont,@EmployerCont,@avcCont,@avcerCont,@PreEmployee,@PreEmployer,@PreAvc,@PreEmployee+@PreEmployer+@PreAvc,@Transfer,          

         @Employee+@Employer+@avc+@avcer+@PreEmployee+@PreEmployer+@PreAvc+@Transfer+@EmployeeCont+@EmployerCont+@avcCont+@avcerCont,            

         @SchemeName,@ProcDate,@Deficit,@SponsorName,@PoolName)            

            

  select @EmployeeContUn = 0,@EmployerContUn = 0,@AVCContUn = 0,@AVCContUn = 0,            

         @EmployeeCont = 0,@EmployerCont = 0,@AVCCont = 0,@AVCCont = 0,            

         @Employee = 0,@Employer = 0,@AVC = 0,@AVCEr = 0,@PreEmployee = 0,@PreEmployer = 0,            

         @PreAVC = 0,@Transfer = 0,@EmployeeUn = 0,@EmployerUn = 0,@AVCUn = 0,@AVCErUn = 0,            

         @Deficit = 0,@SponsorName='',@IDNumber='',@PayrollNo=''            

            

            

  fetch next from acsr into @MemberNo,@MemberNo,@fullName,@IDNumber,@PayrollNo,@dob,@dje,@djpens,@AnnSal,@SponsorName            

end            

Close Acsr            

Deallocate Acsr            

        

        

select @schemeCode=0,@schemeName='',@SchemeMode=0        

Fetch next from MembDirCsr into @schemeCode,@schemeName,@SchemeMode        

end        

Close MembDirCsr        

Deallocate MembDirCsr        

            

END        

ELSE if @FundType <> 'PF'        

BEGIN        

select @schemeName = @PoolName        

if @schemeMode = 0 /* Single Mode */            

begin            

declare Acsr Cursor for            

select CheckNo, MemberNo, upper(sName) + ', ' + fName + ' ' + oNames as fullName,IDNumber,PayrollNo, DOB, DJE, djpens,CAPenSal,            

' '            

from Members where SchemeNo = @schemeNo and ((ReasonForExit = 0)                                       

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 0) and (InitialDoCalc <= @ProcDate))       

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 0) and (InitialDoCalc > @ProcDate))     

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 1) and (InitialDoCalc > @ProcDate))             

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 1) and (InitialDoCalc <= @ProcDate) and (DoCalc > @ProcDate))       

      OR ((ReasonForExit > 0) AND (ActiveStatus = 6) and (DeferredPaid = 1) and (InitialDoCalc >= @ProcDate) and (DoCalc > @ProcDate))                 

      OR ((ReasonForExit > 0) AND (ActiveStatus <> 6) and (DoCalc > @ProcDate)))                            

      and Post_Status = 2 and djpens <= @ProcDate          

order by memberNo            

end            

else if @schemeMode = 1 /* Umbrella Mode */            

begin            

declare Acsr Cursor for            

select m.CheckNo, m.MemberNo, upper(m.sName) + ', ' + m.fName + ' ' + m.oNames as fullName,m.IDNumber,m.PayrollNo, m.DOB, m.DJE, m.djpens,m.CAPenSal,            

s.SponsorName            

from Members m             

     inner join Sponsor s ON M.schemeNo = s.schemeNo and m.SponsorCode = s.SponsorCode            

where m.SchemeNo = @schemeNo and ((M.ReasonForExit = 0)                                       

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 0) and (M.InitialDoCalc <= @ProcDate))       

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 0) and (M.InitialDoCalc > @ProcDate))     

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 1) and (M.InitialDoCalc > @ProcDate))             

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 1) and (M.InitialDoCalc <= @ProcDate) and (M.DoCalc > @ProcDate))       

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus = 6) and (M.DeferredPaid = 1) and (M.InitialDoCalc >= @ProcDate) and (M.DoCalc > @ProcDate))                 

      OR ((M.ReasonForExit > 0) AND (M.ActiveStatus <> 6) and (M.DoCalc > @ProcDate)))                            

      and M.Post_Status = 2 and M.djpens <= @ProcDate                

order by m.memberNo            

end            

            

open acsr            

fetch from acsr into @MemberNo,@MemberNo,@fullName,@IDNumber,@PayrollNo,@dob,@dje,@djpens,@AnnSal,@SponsorName            

while @@fetch_Status = 0            

begin                                                      

  select @Employee  = EmpCont,@Employer =EmprCont,@AVC = EmpVolCont,@AVCEr = EmprVolCont,            

  @PreEmployee = PreEmpCont,@PreEmployer = PreEmprCont,@PreAVC = PreAvc,            

  @Transfer = Transfer            

  from MemberOpeningBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo            

  and AcctPeriod = @AcctPeriod - 1            

            

  if @Employee is null select  @Employee = 0            

  if @Employer is null select @Employer = 0            

  if @AVC is null select @AVC = 0            

  if @AVCEr is null select @AVCEr = 0            

  if @PreEmployee is null select @PreEmployee = 0            

  if @PreEmployer is null select @PreEmployer = 0            

  if @PreAVC is null select @PreAVC = 0            

  if @Transfer is null select @Transfer = 0            

            

  select @EmployeeUn  = ExcessEmp,@EmployerUn =ExcessEmpr,@AVCUn = ExcessVolContr,@AVCErUn = ExcessSpecial            

  from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo            

  and AcctPeriod = @AcctPeriod - 1            

            

  if @EmployeeUn  is null select @EmployeeUn = 0             

  if @EmployerUn is null select @EmployerUn = 0      

  if @AVCUn is null select @AVCUn = 0            

  if @AVCErUn is null select @AVCErUn = 0            

              

  select @Employee = @Employee + @EmployeeUn,@Employer = @Employer + @EmployerUn,            

  @Avc = @Avc + @AvcUn,@AvcEr = @AvcEr + @AvcErUn          

            

  select @EmployeeCont = sum(EmpCont),@EmployerCont = sum(EmprCont),@AVCCont  = sum(VolContr),            

  @AVCErCont = sum(SpecialContr),@Deficit = sum(AugCont)            

  from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @MemberNo            

  and AcctPeriod = @AcctPeriod            

            

  if @EmployeeCont is null select @EmployeeCont = 0            

  if @EmployerCont is null select @EmployerCont = 0            

  if @AVCCont is null select @AVCCont = 0             

  if @AVCErCont is null select @AVCErCont = 0            

  if @Deficit is null select @Deficit = 0            

            

  select @EmployeeContUn = sum(ExcessEmpCont),@EmployerContUn = sum(ExcessEmprCont),            

  @AVCContUn  = sum(ExcessVolContr),@AVCErContUn = sum(ExcessSpecial)            

  from UnRegisteredContributionssummary where SchemeNo = @schemeNo and MemberNo = @MemberNo            

  and AcctPeriod = @AcctPeriod            

            

  if @EmployeeContUn is null select @EmployeeContUn = 0            

  if @EmployerContUn is null select @EmployerContUn = 0            

  if @AVCContUn is null select @AVCContUn = 0            

  if @AVCErContUn is null select @AVCErContUn = 0            

              

  select @EmployeeCont = @EmployeeCont + @EmployeeContUn            

  select @EmployerCont = @EmployerCont + @EmployerContUn            

  select @AVCCont = @AVCCont + @AVCContUn            

  select @AVCErCont = @AVCErCont + @AVCErContUn            

            

              

  Insert Into ##membDir(            

  memberNo,            

  CheckNo,            

  fullName,IDNumber,PayrollNo,            

  DOB,            

  DJE,            

  djpens,            

  annSal,            

  EmployeeOp,            

  EmployerOp,            

  AVCOp,            

  AVCErOp,            

  Employee,            

  Employer,            

  AVC,            

  AVCEr,            

  PreEmployee,            

  PreEmployer,            

  PreAVC,            

  Frozen,            

  Transfer,            

  Total,            

  schemeName,            

  Period,            

  Deficit,SponsorName,PoolName)            

  Values(@MemberNo,@MemberNo,@FullName,@IDNumber,@PayrollNo,@dob,@dje,@djpens,@AnnSal,@Employee,@Employer,@avc,@avcer,            

         @EmployeeCont,@EmployerCont,@avcCont,@avcerCont,@PreEmployee,@PreEmployer,@PreAvc,@PreEmployee+@PreEmployer+@PreAvc,@Transfer,            

         @Employee+@Employer+@avc+@avcer+@PreEmployee+@PreEmployer+@PreAvc+@Transfer+@EmployeeCont+@EmployerCont+@avcCont+@avcerCont,            

         @SchemeName,@ProcDate,@Deficit,@SponsorName,'')            

            

  select @EmployeeContUn = 0,@EmployerContUn = 0,@AVCContUn = 0,@AVCContUn = 0,            

         @EmployeeCont = 0,@EmployerCont = 0,@AVCCont = 0,@AVCCont = 0,            

         @Employee = 0,@Employer = 0,@AVC = 0,@AVCEr = 0,@PreEmployee = 0,@PreEmployer = 0,            

         @PreAVC = 0,@Transfer = 0,@EmployeeUn = 0,@EmployerUn = 0,@AVCUn = 0,@AVCErUn = 0,            

         @Deficit = 0,@SponsorName='',@PoolName ='',@IDNumber = '',@PayrollNo = ''          

            

            

  fetch next from acsr into @MemberNo,@MemberNo,@fullName,@IDNumber,@PayrollNo,@dob,@dje,@djpens,@AnnSal,@SponsorName            

end            

Close Acsr            

Deallocate Acsr        

            

END        

            

if @SchemeMode = 0            

   select * from ##membDir order by CheckNo            

else if @SchemeMode = 1            

   select * from ##membDir order by SponsorName,CheckNo            

            

select @retCode = 0            

            

just_go:            

  set concat_null_yields_null on            

  set nocount off            

  return @retCode
go

