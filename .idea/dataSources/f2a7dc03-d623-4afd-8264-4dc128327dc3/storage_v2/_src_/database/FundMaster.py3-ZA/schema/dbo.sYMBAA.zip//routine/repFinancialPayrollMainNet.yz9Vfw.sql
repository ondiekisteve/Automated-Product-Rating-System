CREATE PROCEDURE [dbo].[repFinancialPayrollMainNet]
@SCHEMENO Int,
@paymonth int,
@payyear int,
@FinCode varchar(15)
--with Encryption
as


Exec FinancialPayroll @schemeNo,@PayMonth,@PayYear

select p.*,
 s.AccountNo as SchemeAcctNo, s.AccountName as SchemeAccnt
from ##FinancialPayroll p
     Inner join SchemeBankBranch s on p.SchemeNo = s.SchemeNo and s.BankCode = (select BankCode from Pension_setup where SchemeNo = @SchemeNo)
where (p.SchemeNo = @SchemeNo)  And p.PAYStatus = 'Pay'
      and p.FinCode = @finCode
        
order by p.PenNo
go

