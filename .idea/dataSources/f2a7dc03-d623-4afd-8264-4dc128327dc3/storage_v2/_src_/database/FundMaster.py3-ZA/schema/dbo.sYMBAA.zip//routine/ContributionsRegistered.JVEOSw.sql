CREATE PROCEDURE [dbo].[ContributionsRegistered]
@SCHEMENO Int,
@CurYear int
--with Encryption
as
if object_id('tempdb..##GeneralReg') is null

begin
create table ##GeneralReg
(
	[MemberNo] [int] NOT NULL ,
	[fullname] [varchar](100) NOT NULL ,
	[EmpOpening] [float] NULL,
        [EmprOpening] [Float] null,
        [AVCOpening] [float] NULL,
        [AVCEROpening] [Float] null,
        [EmpCont][float] null,
        [EmprCont] [float] null,
        [AVCCont][float] null,
        [AVCERCont] [float] null,
        [Total][float] null,
        [Period][varchar](30),
        [SchemeName][varchar](120)    
) 

ALTER TABLE ##GeneralReg WITH NOCHECK ADD 

            
	CONSTRAINT [PK_GeneralReg] PRIMARY KEY  NONCLUSTERED 
	(
          
	  [MemberNo]      
	) 
end

Delete from ##GeneralReg 

declare @MemberNo int,@fullName varchar(100),@EmpOpen float,@EmprOpen float,
@Empcont float,@EmprCont float,@Total float,@SchemeName varchar(120),
@EndDate Datetime,@AcctPeriod int,@StartMonth int,@RepDesc varchar(25),
@avcCont float,@avcerCont float,@avcOpen float,@avcerOpen float


Select @EndDate = EndDate from schemeYears where schemeNo = @SchemeNo and 
DatePart(Year, EndDate) = @CurYear

Select @StartMonth = DatePart(Month,@EndDate)

if @StartMonth = 12 Select @RepDesc = '31st December,'
else if @StartMonth = 6 select @RepDesc = '30th June,'

Exec GetAccountingPeriodInAYear @SchemeNo,@StartMonth,@CurYear,@AcctPeriod out

Select @SchemeName = SchemeName from scheme where SchemeCode = @SchemeNo

Declare Acsr cursor for
Select m.MemberNo, Upper(m.sname)+', '+m.fname+' '+m.Onames as FullName,
sum(c.EmpCont) as EmployeeCont,sum(c.EmprCont) as EmployerCont,
sum(c.VolContr),sum(c.SpecialContr)
from Members m
     inner Join Contributionssummary c on 
           m.SchemeNo = c.SchemeNo and m.MemberNo= c.MemberNo and c.AcctPeriod = @AcctPeriod
where m.SchemeNo = @SchemeNo and m.ReasonforExit = 0
Group by m.MemberNo,m.sname,m.fname,m.onames


Open Acsr

fetch from Acsr into @MemberNo,@fullname,@EmpCont,@EmprCont,@avcCont,@avcerCont

While @@fetch_Status = 0
begin
   Select @EmpOpen = EmpCont, @EmprOpen = EmprCont,@avcOpen = EmpVolCont, @AVCerOpen = EmprVolCont
   from MemberOpeningBalances
   where SchemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1

   if @EmpOpen is null select @EmpOpen = 0
   if @EmprOpen is null select @EmprOpen = 0
   if @avcOpen is null select @avcOpen = 0
   if @AVCerOpen is null select @AVCerOpen = 0
   
   
   Insert into ##GeneralReg (MemberNo,fullname,Empcont,EmprCont, EmpOpenING,EmprOpening, total,
                             Period, SchemeName,avccont,avcerCont, avcOpenING,avcerOpening)
               Values(@MemberNo,@fullname,@Empcont,@EmprCont,@EmpOpen,@EmprOpen,
                      @EmpCont + @EmprCont + @EmpOpen + @EmprOpen + @avccont+@avcerCont+ @AVCOpen+@AVCerOpen, @RepDesc+' '+ cast(@curYear as varchar(4)), @SchemeName,
                      @avccont,@avcerCont, @AVCOpen,@AVCerOpen)

   Select @EmpOpen = 0
   Select @EmprOPEN = 0,@avccont = 0,@avcerCont=0, @avcOpen=0,@AVCerOpen=0
   fetch from Acsr into @MemberNo,@fullname,@EmpCont,@EmprCont,@avcCont,@avcerCont
end
Close Acsr
Deallocate Acsr

Select * from ##GeneralReg order by MemberNo
go

