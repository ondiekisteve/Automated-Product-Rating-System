CREATE PROCEDURE [dbo].[SetiVat]  
@SCHEMENO Int,  
@PayCode Int  
--with Encryption  
as  
  
declare @InvoiceDate datetime,@Amount float,@Vat float,@VatMode bit,  
@DeductVat bit,@FeesCode Int,@TaxableAmount float  
  
Exec Proc_Post_Fees_To_Reserve @SchemeNo,@PayCode  
  
select @InvoiceDate = InvoiceDate,@Amount = Amount,@TaxableAmount = TaxableAmount,@VatMode = VatMode,  
@DeductVat = DeductVat,@FeesCode = FeesCode  
from FeesInvoice where SchemeNo = @schemeNo and PayCode = @PayCode  
  
if @DeductVAT = 1  
   begin  
       Exec CalculateVATInc @InvoiceDate,@TaxableAmount,@VatMode,@vat out  
   end  
else  
  select @vat = 0  
  
if @VatMode = 1  
   select @Amount = @Amount - @Vat  
  
update FeesInvoice set vat = @Vat,Amount = @Amount  
where SchemeNo = @SchemeNo and FeesCode = @FeesCode and PayCode = @PayCode
go

