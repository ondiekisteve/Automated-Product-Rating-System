CREATE VIEW [dbo].[DeferredPensionerMane]
--with encryption
AS
SELECT p.schemeNo, p.memberNo, p.InitPension, 
               p.CurPension
FROM DeferredPensioner  p
go

