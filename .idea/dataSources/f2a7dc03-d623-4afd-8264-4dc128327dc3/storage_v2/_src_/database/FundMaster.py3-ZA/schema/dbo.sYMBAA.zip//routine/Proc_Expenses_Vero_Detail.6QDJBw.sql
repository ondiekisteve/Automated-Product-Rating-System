CREATE PROCEDURE [dbo].[Proc_Expenses_Vero_Detail]              
@SCHEMENO Int,              
@PayCode int              
--with Encryption              
as              
              
if object_id('tempdb..#Fee_Distr') is null              
begin              
create table #Fee_Distr              
(              
 [MemberNo] [int] NOT NULL,              
 [Employee] [Decimal](12,2) NOT NULL ,              
        [Employer] [Decimal](12,2) NOT NULL                 
)               
              
ALTER TABLE #Fee_Distr WITH NOCHECK ADD                
                          
 CONSTRAINT [PK_#Fee_Distr] PRIMARY KEY  NONCLUSTERED               
 (              
   [MemberNo]                    
 )               
end              
              
declare @MemberNo Int,@Employee Decimal(20,6),@Employer Decimal(20,6),              
                      @EmpOpen Decimal(20,6), @EmprOpen Decimal(20,6),              
                      @EmpArrears Decimal(20,6),@EmprArrears Decimal(20,6),              
                      @EmpTransfer Decimal(20,6),@EmprTransfer Decimal(20,6),              
                      @AcctPeriod Int,              
                      @MemberGlobal Decimal(20,6),@SurplusGlobal Decimal(20,6),@MemberRegGlobal Decimal(20,6),              
                      @MemberUnRegGlobal Decimal(20,6),@SurplusRegGlobal Decimal(20,6),              
                      @SurplusUnRegGlobal Decimal(20,6),@EmpRegGlobal Decimal(20,6),              
                      @EmprRegGlobal Decimal(20,6),@EmpUnRegGlobal Decimal(20,6),              
                      @EmprUnRegGlobal Decimal(20,6),@MemberFees Decimal(20,6),@SurplusFees Decimal(20,6),              
                      @description varchar(250),@TransDate datetime,@fee decimal (12,2),@SurplusFeesReg Decimal(20,6),              
                      @FeesCode int,@EmpExpense float,@EmprExpense float,@RegMemberFees float,              
                      @UnRegMemberFees float,@TotalInterest float,              
                      @EmpRegMemberFees float,@EmprRegMemberFees float,              
                      @EmpUnRegMemberFees float,@EmprUnRegMemberFees float,@RegTotal float,@UnRegTotal float,          
                      @SponsorCode Int,@AppDate datetime            
            
select  @RegTotal = 0,@UnRegTotal = 0             
              
select @fee = amount,@TransDate = InvoiceDate,@AppDate = AppDate,@description = Description, @FeesCode = FeesCode,          
@SponsorCode = SponsorCode              
from feesInvoice where PayCode=@paycode           
          
if @SponsorCode is null select @SponsorCode = 0             
              
select @EmpExpense  = 0.0,@EmprExpense = 0.0,@RegMemberFees = 0.0,              
                      @UnRegMemberFees =0.0,@TotalInterest = 0.0,              
                      @EmpRegMemberFees =0.0,@EmprRegMemberFees =0.0,              
                      @EmpUnRegMemberFees =0.0,@EmprUnRegMemberFees =0.0              
              
Select @AcctPeriod = AcctPeriod from schemeYears where schemeNo = @schemeNo and StartDate <= @AppDate  and              
EndDate >=@AppDate              
              
/* ACTIVE MEMBERS REG */           
if @SponsorCode = 0             
declare Membercsr Cursor for              
select MemberNo               
from Members               
where schemeNo = @schemeNo and (((ReasonforExit = 0) and (djpens <= @AppDate))              
                 or              
                 ((ReasonforExit > 0) and (djpens <= @AppDate) and (DoCalc >= @AppDate)))          
else if @SponsorCode > 0             
declare Membercsr Cursor for              
select MemberNo               
from Members               
where schemeNo = @schemeNo and (((ReasonforExit = 0) and (djpens <= @AppDate))              
                 or              
                 ((ReasonforExit > 0) and (djpens <= @AppDate) and (DoCalc >= @AppDate)))           
and SponsorCode = @SponsorCode           
           
open Membercsr              
Fetch from Membercsr into @MemberNo              
while @@fetch_Status = 0              
begin              
   select @EmpOpen = (EmpCont + EmpVolCont) - (EmpFees + VolFees),              
   @EmprOpen = (EmprCont + EmprVolCont) - (EmprFees + SpecFees)              
   from MemberOpeningBalances              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1              
              
   select @Employee = sum(EmpCont + VolContr), @Employer = sum(EmprCont + SpecialContr)              
   from Contributionssummary              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and DatePaid <= @AppDate              
              
   select @EmpArrears = sum(ArEmpCont), @EmprArrears = sum(ArEmprCont)              
   from ContributionArrears              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and DatePaid <= @AppDate              
              
   select @EmpTransfer = sum(EmpTransfer + AvcTransfer), @EmprTransfer = sum(EmprTransfer + AvcERTransfer)              
   from MemberTransfer              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and TransferDate <= @AppDate              
              
   if @EmpOpen is null select @EmpOpen = 0              
   if @EmprOpen is null select @EmprOpen = 0              
   if @Employee is null select @Employee = 0              
   if @Employer is null select @Employer = 0              
   if @EmpArrears is null select @EmpArrears = 0              
   if @EmprArrears is null select @EmprArrears = 0              
   if @EmpTransfer is null select @EmpTransfer = 0              
   if @EmprTransfer is null select @EmprTransfer = 0              
              
   select @Employee = @Employee + @EmpOpen + @EmpArrears + @EmpTransfer,              
          @Employer = @Employer + @EmprOpen + @EmprArrears + @EmprTransfer              
              
              
   Insert into #Fee_Distr(MemberNo,Employee,Employer)              
               Values(@MemberNo,@Employee,@Employer)              
              
   select @Employee = 0, @EmpOpen = 0,@EmpArrears =0,@EmpTransfer=0,              
          @Employer = 0,@EmprOpen=0,@EmprArrears =0,@EmprTransfer=0,              
          @MemberNo = 0              
              
   Fetch next from Membercsr into @MemberNo              
end              
Close Membercsr              
Deallocate Membercsr              
/* END ACTIVE MEMBERS */              
              
/* DEFERRED MEMBERS */          
if @SponsorCode = 0              
declare Membercsr Cursor for              
select MemberNo               
from Members               
where schemeNo = @schemeNo and ((ReasonforExit > 0) and (djpens <= @AppDate)               
                               and (DoCalc < @AppDate) AND (ActiveStatus = 6))             
else if @SponsorCode > 0              
declare Membercsr Cursor for              
select MemberNo               
from Members               
where schemeNo = @schemeNo and ((ReasonforExit > 0) and (djpens <= @AppDate)               
                               and (DoCalc < @AppDate) AND (ActiveStatus = 6))           
and SponsorCode = @SponsorCode          
           
open Membercsr              
Fetch from Membercsr into @MemberNo              
while @@fetch_Status = 0              
begin              
   select @EmprOpen = (EmprCont + EmprVolCont) - (EmprFees + SpecFees)              
   from MemberOpeningBalances              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1              
              
   select @Employer = sum(EmprCont + SpecialContr)              
   from Contributionssummary              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and DatePaid <= @AppDate              
              
   select @EmprArrears = sum(ArEmprCont)              
   from ContributionArrears              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and DatePaid <= @AppDate              
              
   select @EmprTransfer = sum(EmprTransfer + avcErTransfer)              
   from MemberTransfer              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and TransferDate <= @AppDate              
              
   if @EmpOpen is null select @EmpOpen = 0              
   if @EmprOpen is null select @EmprOpen = 0              
   if @Employee is null select @Employee = 0              
   if @Employer is null select @Employer = 0              
   if @EmpArrears is null select @EmpArrears = 0              
   if @EmprArrears is null select @EmprArrears = 0              
   if @EmpTransfer is null select @EmpTransfer = 0              
   if @EmprTransfer is null select @EmprTransfer = 0              
              
   select @Employee = 0.0,              
          @Employer = @Employer + @EmprOpen + @EmprArrears + @EmprTransfer              
 if (@Employee + @Employer > 0)              
      begin              
      Delete from #Fee_Distr where MemberNo = @MemberNo              
              
      Insert into #Fee_Distr(MemberNo,Employee,Employer)              
               Values(@MemberNo,@Employee,@Employer)              
      end              
              
              
   select @Employee = 0, @EmpOpen = 0,@EmpArrears =0,@EmpTransfer=0,              
          @Employer = 0,@EmprOpen=0,@EmprArrears =0,@EmprTransfer=0,              
          @MemberNo = 0              
              
   Fetch next from Membercsr into @MemberNo              
end              
Close Membercsr              
Deallocate Membercsr              
              
/* END DEFERRED MEMBERS */              
              
              
/* Get Ratios */              
Exec Proc_Expenses_Vero_Global @schemeNo,@TransDate,@AppDate,@SponsorCode,@MemberGlobal out,@SurplusGlobal out,@MemberRegGlobal out,              
                               @MemberUnRegGlobal out,@SurplusRegGlobal out,@SurplusUnRegGlobal out,@EmpRegGlobal out,              
                               @EmprRegGlobal out,@EmpUnRegGlobal out,@EmprUnRegGlobal out              
              
Select @MemberFees  = (@MemberGlobal/(@MemberGlobal + @SurplusGlobal)) * @Fee              
Select @SurplusFees = @Fee - @MemberFees              
             
select @RegMemberFees = @MemberFees * (@MemberRegGlobal/(@MemberRegGlobal + @MemberUnRegGlobal))              
select @UnRegMemberFees = @MemberFees - @RegMemberFees              
              
select @EmpRegMemberFees = @RegMemberFees * (@EmpRegGlobal/(@EmpRegGlobal + @EmprRegGlobal))              
select @EmprRegMemberFees = @RegMemberFees - @EmpRegMemberFees              
              
select @EmpUnRegMemberFees = @UnRegMemberFees * (@EmpUnRegGlobal/(@EmpUnRegGlobal + @EmprUnRegGlobal))              
select @EmprUnRegMemberFees = @UnRegMemberFees - @EmpUnRegMemberFees              
             
/* Post Surplus */              
if (@SurplusFees > 0) and (@SurplusRegGlobal > 0)              
begin               
   select @SurplusFeesReg = @SurplusFees * (@SurplusRegGlobal/@SurplusGlobal)              
   Exec InsertSurplus @SchemeNo,@TransDate,@Description,@SurplusFeesReg,1,0,0,0,0,2,@SponsorCode              
end              
if (@SurplusFees > 0) and (@SurplusUnRegGlobal > 0)              
begin              
    select @SurplusFeesReg = @SurplusFees * (@SurplusUnRegGlobal/@SurplusGlobal)              
    Exec InsertSurplus @SchemeNo,@TransDate,@Description,@SurplusFeesReg,1,0,0,0,1,2,@SponsorCode              
end              
              
/* Distribute the Fees and Update Fees Distribution */              
declare distr cursor for              
select memberno,employee,Employer from #Fee_Distr              
open distr              
fetch from distr into @memberno,@employee,@employer              
while @@Fetch_status =0              
begin              
   if @employee >0              
      select @empExpense = @EmpRegMemberFees * (@employee/@EmpRegGlobal)              
   else               
      select @empExpense = 0              
              
   if @employer > 0               
      select @emprExpense = @EmprRegMemberFees * (@employer/@EmprRegGlobal)              
   else               
      select @emprExpense = 0              
              
   select @TotalInterest = @TotalInterest + @emprExpense + @empExpense              
              
   if not Exists (select MemberNo from FeesDistribution where schemeNo = @schemeNo and MemberNo = @MemberNo              
              and PayCode = @PayCode and PaymentDate = @TransDate)              
   Insert Into FeesDistribution(SchemeNo,MemberNo,FeesCode,PayCode,EmpAmount,EmprAmount, DistrMode,PaymentDate,SponsorCode)              
                         Values(@SchemeNo,@MemberNo,@FeesCode,@PayCode,@empExpense,@emprExpense,0,@TransDate,@SponsorCode)              
   else              
       update FeesDistribution set EmpAmount = @empExpense,EmprAmount = @empExpense,SponsorCode = @SponsorCode              
       where schemeNo = @schemeNo and MemberNo = @MemberNo              
       and PayCode = @PayCode and PaymentDate = @TransDate              
              
   select @employee = 0,@employer = 0,@empExpense = 0.0,@emprExpense=0.0              
   fetch next from distr into @memberno,@employee,@employer              
end              
Close distr              
Deallocate distr              
              
delete from #Fee_Distr              
            
select @TotalInterest = 0.0            
             
/* ACTIVE MEMBERS - UNREGISTERED */          
if @SponsorCode = 0              
declare Membercsr Cursor for              
select MemberNo               
from Members               
where schemeNo = @schemeNo and (((ReasonforExit = 0) and (djpens <= @AppDate))              
                 or              
                 ((ReasonforExit > 0) and (djpens <= @AppDate) and (DoCalc >= @AppDate)))              
else if @SponsorCode > 0              
declare Membercsr Cursor for              
select MemberNo               
from Members               
where schemeNo = @schemeNo and (((ReasonforExit = 0) and (djpens <= @AppDate))              
             or              
                 ((ReasonforExit > 0) and (djpens <= @AppDate) and (DoCalc >= @AppDate)))          
and SponsorCode = @SponsorCode             
          
open Membercsr              
Fetch from Membercsr into @MemberNo              
while @@fetch_Status = 0              
begin              
   select @EmpOpen = (ExcessEmp + ExcessVolContr) - (EmpFees_un + VolFees_Un + EmpTax + VolTax),               
          @EmprOpen = (ExcessEmpr + ExcessSpecial) - (EmprFees_un + SpecFees_un + EmprTax + SpecTax)              
   from UnRegisteredBalances              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1              
              
   select @Employee = sum(ExcessEmpCont + ExcessVolContr), @Employer = sum(ExcessEmprCont + ExcessSpecial)              
   from UnregisteredContributionssummary              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and DatePaid <= @AppDate              
              
   select @EmpTransfer = sum(EmpTransfer + AVCTransfer), @EmprTransfer = sum(EmprTransfer + AVCERTransfer)              
   from MemberTransferUn              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and TransferDate <= @AppDate              
              
   if @EmpOpen is null select @EmpOpen = 0              
   if @EmprOpen is null select @EmprOpen = 0              
   if @Employee is null select @Employee = 0              
   if @Employer is null select @Employer = 0              
   select @EmpArrears = 0              
   select @EmprArrears = 0              
   if @EmpTransfer is null select @EmpTransfer = 0              
   if @EmprTransfer is null select @EmprTransfer = 0              
              
   select @Employee = @Employee + @EmpOpen + @EmpArrears + @EmpTransfer,              
          @Employer = @Employer + @EmprOpen + @EmprArrears + @EmprTransfer              
              
   IF (@Employee + @Employer) > 0               
      Insert into #Fee_Distr(MemberNo,Employee,Employer)              
         Values(@MemberNo,@Employee,@Employer)              
              
   select @Employee = 0, @EmpOpen = 0,@EmpArrears =0,@EmpTransfer=0,              
          @Employer = 0,@EmprOpen=0,@EmprArrears =0,@EmprTransfer=0,              
          @MemberNo = 0              
              
   Fetch next from Membercsr into @MemberNo              
end         
Close Membercsr              
Deallocate Membercsr              
/* END ACTIVE MEMBERS */              
              
/* DEFERRED MEMBERS */           
if @SponsorCode = 0             
declare Membercsr Cursor for              
select MemberNo               
from Members               
where schemeNo = @schemeNo and ((ReasonforExit > 0) and (djpens <= @AppDate) and (DoCalc < @AppDate)               
AND (ActiveStatus = 6))              
else if @SponsorCode > 0             
declare Membercsr Cursor for              
select MemberNo               
from Members               
where schemeNo = @schemeNo and ((ReasonforExit > 0) and (djpens <= @AppDate) and (DoCalc < @AppDate)               
AND (ActiveStatus = 6)) and SponsorCode = @SponsorCode           
open Membercsr              
Fetch from Membercsr into @MemberNo              
while @@fetch_Status = 0              
begin              
   select @EmprOpen = (ExcessEmpr + ExcessSpecial) - (EmprFees_un + SpecFees_un)              
   from UnRegisteredBalances              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1              
              
   select @Employer = sum(ExcessEmprCont + ExcessSpecial)              
   from UnregisteredContributionssummary              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and DatePaid <= @AppDate              
              
   select @EmprTransfer = sum(EmprTransfer + AVCERTransfer)              
   from MemberTransferUn              
   where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod              
   and TransferDate <= @AppDate              
              
   if @EmpOpen is null select @EmpOpen = 0              
   if @EmprOpen is null select @EmprOpen = 0              
   if @Employee is null select @Employee = 0              
   if @Employer is null select @Employer = 0              
   select @EmpArrears = 0              
   select @EmprArrears = 0              
   if @EmpTransfer is null select @EmpTransfer = 0              
   if @EmprTransfer is null select @EmprTransfer = 0              
              
   select @Employee = 0.0,              
          @Employer = @Employer + @EmprOpen + @EmprArrears + @EmprTransfer              
   if @Employee + @Employer > 0              
      begin              
         Delete from #Fee_Distr where MemberNo = @MemberNo              
              
         Insert into #Fee_Distr(MemberNo,Employee,Employer)              
               Values(@MemberNo,@Employee,@Employer)              
      end              
              
   select @Employee = 0, @EmpOpen = 0,@EmpArrears =0,@EmpTransfer=0,              
          @Employer = 0,@EmprOpen=0,@EmprArrears =0,@EmprTransfer=0              
              
   select @MemberNo = 0,@Employee=0,@Employer=0              
   Fetch next from Membercsr into @MemberNo              
end              
Close Membercsr              
Deallocate Membercsr              
              
/*update unregistered*/             
select * from #Fee_Distr             
declare distr cursor for              
select memberno,employee,Employer from #Fee_Distr              
open distr              
fetch from distr into @memberno,@employee,@employer              
while @@Fetch_status =0              
begin              
   if @employee >0              
      select @empExpense = @EmpUnRegMemberFees * (@employee/@EmpUnRegGlobal)               
   else               
      select @empExpense = 0              
   if @employer > 0               
      select @emprExpense = @EmprUnRegMemberFees * (@employer/@EmprUnRegGlobal)              
   else               
      select @emprExpense = 0              
              
  select @TotalInterest = @TotalInterest + @emprExpense + @empExpense             
            
   if not Exists (select MemberNo from FeesDistribution where schemeNo = @schemeNo and MemberNo = @MemberNo              
              and PayCode = @PayCode and PaymentDate = @TransDate)              
   Insert Into FeesDistribution(SchemeNo,MemberNo,FeesCode,PayCode,EmpAmount_Un,EmprAmount_Un, DistrMode,PaymentDate,          
                                SponsorCode)       
                         Values(@SchemeNo,@MemberNo,@FeesCode,@PayCode,@empExpense,@emprExpense,0,@TransDate,@SponsorCode)              
   else              
       update FeesDistribution set EmpAmount_Un = @empExpense,EmprAmount_Un = @emprExpense              
       where schemeNo = @schemeNo and MemberNo = @MemberNo              
       and PayCode = @PayCode and PaymentDate = @TransDate              
              
   select @memberno=0,@employee=0,@employer=0,@empExpense = 0,@emprExpense=0              
   fetch next from distr into @memberno,@employee,@employer              
end              
Close distr              
Deallocate distr
go

