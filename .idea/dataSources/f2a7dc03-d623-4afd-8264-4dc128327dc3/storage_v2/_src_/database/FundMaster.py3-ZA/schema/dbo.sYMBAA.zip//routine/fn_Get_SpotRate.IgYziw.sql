CREATE FUNCTION [dbo].[fn_Get_SpotRate](@AccountCode Int,@TransDate Datetime)                             
returns float                
as                  
begin     
 declare @SpotRate float     
 
 select @SpotRate = Max(SpotRate) from TBL_GL_Balances 
 where PeriodEnding = @TransDate and AccountCode = @AccountCode   
                   
 RETURN(@SpotRate)                  
end
go

