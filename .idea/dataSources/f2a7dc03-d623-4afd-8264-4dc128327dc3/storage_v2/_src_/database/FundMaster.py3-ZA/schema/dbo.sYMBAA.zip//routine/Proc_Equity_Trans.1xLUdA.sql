CREATE PROCEDURE [dbo].[Proc_Equity_Trans]                      
@schemeNo Int,                      
@AsAtDate datetime,                      
@TransMode Int,                      
@TransType Int /* 0 - Report, 1 - Report & Buy or Sell */                      
--with Encryption                      
as                      
                      
if object_id('tempdb..#Equity_Trans') is null                                                        
                                                        
begin                                                        
create table #Equity_Trans                                                        
(                                                        
 [glcode] [int] IDENTITY(1,1) PRIMARY KEY ,                                                        
 [EquityNo] [Int],                      
 [EquityName][varchar](100),               
 [Particulars][varchar](200),                                                       
 [Acquisition] [Decimal](20,2),                                                        
 [Sale] [Decimal](20,2),                      
 [NetMovement][Decimal](20,2),                      
 [AsAtDate][Datetime],              
 [UnitType][Int],                                                         
)                                                                                       
end                      
                      
Declare @EquityNo Int,@EquityName varchar(120),@Acquisition Decimal(20,6),@Sale Decimal(20,6),                      
@NetMovement Decimal(20,6),@UnitType Int,@DepositNo int,@Particulars varchar(255),@sAsAtDate varchar(20),                
@IntOrWith int,@BuySell smallInt                 
                
Exec DateToStr @AsAtDate,@sAsAtDate out                     
                      
IF @TransMode = 0 /* Equities */                      
begin                      
select @UnitType = 1                      
/* Acquisition - Sell cash Buy units in Equity */                      
declare EqCsr Cursor for                      
Select i.InvName,e.EquityNo,e.NoofShares * e.PricePerShare                      
from EquityAcquisition e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.EquityNo = i.InvCode               
     inner join Equity x on e.schemeNo = x.SchemeNo and e.EquityNo = x.EquityNo                     
where e.schemeNo = @schemeNo and e.DateAcquired = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Equity Acquisition-'+@EquityName,@Acquisition,0.0,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                      
                      
                      
/* Placement - Sell cash Buy units in Equity */                      
declare EqCsr Cursor for                      
Select i.InvName,e.EquityNo,e.NoofShares * e.PricePerShare                      
from Equity e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.EquityNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.DateInvested = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Equity Placement for '+@EquityName,@Acquisition,0.0,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0           
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                      
                      
/* Sale - Buy cash sell units in Equity*/                      
declare EqCsr Cursor for                      
Select i.InvName,e.EquityNo,e.NoofShares * e.PricePerShare                      
from SaleEquity e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.EquityNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.TransDate = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
          Values(@EquityNo,@EquityName,'Sale of '+@EquityName+' shares',0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                 
              
/* Dividends - Buy cash sell units in Equity*/                      
declare EqCsr Cursor for                      
Select i.InvName,e.EquityNo,e.NoofShares * e.Dividend                      
from EquityDividends e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.EquityNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.DatePaid = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Equity Dividends for '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                      
end                      
else if @TransMode = 1 /* Government Paper */                      
begin                      
select @UnitType = 2                      
/* Placement - Sell cash Buy units in Government Paper */                      
declare EqCsr Cursor for                      
Select i.InvName,e.SecurityNo,e.AmountInvested                      
from GovernmentSecurities e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.SecurityNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.TransDate = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Placement of '+@EquityName,@Acquisition,0.0,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                       
end                      
Close EqCsr                      
Deallocate EqCsr                      
                      
                      
/* Redemption - Buy cash Sell units in Government Paper*/                      
declare EqCsr Cursor for                      
Select i.InvName,e.SecurityNo,e.NominalValue                      
from GovernmentSecurities e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.SecurityNo = i.InvCode                      
     and i.DateRedeemed = @AsAtDate                      
where e.schemeNo = @schemeNo and e.Redeem = 1                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Redemption of '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                      
          
/* Income - Buy cash Sell units in Government Paper*/                      
declare EqCsr Cursor for              
Select i.InvName,e.SecurityNo,(e.Interest - (e.MedicalLevy + e.WithholdingTax))                     
from GovernmentIncome e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.SecurityNo = i.InvCode                                 
where e.schemeNo = @schemeNo and e.SecurityDate = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Income from '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr           
                      
end                      
                      
else if @TransMode = 2 /* Commercial Paper */                      
begin                      
select @UnitType = 5                      
/* Placement - Sell cash Buy units in Commercial Paper*/                      
declare EqCsr Cursor for                      
Select i.InvName,e.PaperNo,e.AmountInvested * e.SpotRate                      
from CommercialPaper e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.PaperNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.TransDate = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Placement of '+@EquityName,@Acquisition,0.0,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      

end                      
Close EqCsr                      
Deallocate EqCsr                      
                      
                      
/* Redemption - Buy cash Sell units in Commercial Paper */                      
declare EqCsr Cursor for                      
Select i.InvName,e.PaperNo,e.AmountInvested * e.SpotRate                     
from CommercialPaper e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.PaperNo = i.InvCode                      
     and i.DateRedeemed = @AsAtDate                      
where e.schemeNo = @schemeNo and e.Redeem = 1                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Redemption of '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr         
Deallocate EqCsr          
          
/* Income - Buy cash Sell units in Commercial Paper*/                      
declare EqCsr Cursor for                      
Select i.InvName,e.PaperNo,(e.Interest - (e.MedicalLevy + e.WithholdingTax)) * e.SpotRate                     
from CommercialIncome e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.PaperNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.PaperDate = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Income from '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition              
end                      
Close EqCsr                      
Deallocate EqCsr                        
                   
end                      
                      
                      
else if @TransMode = 3 /* Cash and Deposits */                      
begin                      
select @UnitType = 4                      
/* Placement - Sell cash Buy units in Cash and Deposits */                      
declare EqCsr Cursor for                      
Select i.InvName,e.DepositNo,e.Amount * e.SpotRate                      
from cashDeposits e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.DepositNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.TransDate = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Placement of '+@EquityName,@Acquisition,0.0,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                      
                      
                      
/* Redemption - Buy cash Sell units in Cash and Deposits */                      
declare EqCsr Cursor for                      
Select i.InvName,e.DepositNo,e.Amount * e.RemSpotRate                      
from cashDeposits e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.DepositNo = i.InvCode                      
     and i.DateRedeemed = @AsAtDate                      
where e.schemeNo = @schemeNo and e.Redeem = 1                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                  Values(@EquityNo,@EquityName,'Redemption of '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr           
          
/* Income - Buy cash Sell units in Cash Deposits*/                      
declare EqCsr Cursor for                      
Select i.InvName,e.DepositNo,(e.Interest - (e.MedicalLevy + e.WithholdingTax)) * e.SpotRate                     
from cashRollover e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.DepositNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.RolloverDate = @AsAtDate and e.intorwith = 0                      
           
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Income from '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                 
end           
             
/* Offshore */              
else if @TransMode = 4 /* Offshore */                      
begin              
select @UnitType = 6                      
/* Acquisition - Sell cash Buy units in offshore */                      
declare EqCsr Cursor for                      
Select i.InvName,e.EquityNo,(e.NoofShares * e.PricePerShare) * e.SpotRate                     
from EquityAcquisition e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.EquityNo = i.InvCode               
     inner join Offshore x on e.schemeNo = x.SchemeNo and e.EquityNo = x.OffshoreNo                     
where e.schemeNo = @schemeNo and e.DateAcquired = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Offshore Acquisition',@Acquisition,0.0,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                      
                      
                      
/* Placement - Sell cash Buy units in offshore */                      
declare EqCsr Cursor for                      
Select i.InvName,e.OffshoreNo,(e.UnitsBought * e.CostPerUnit)* e.SpotRate                     
from Offshore e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.OffshoreNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.DateInvested = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'offshore Placement',@Acquisition,0.0,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                
              
/* Sale - Buy cash sell units in Offshore */                      
declare EqCsr Cursor for                      
Select i.InvName,e.OffshoreNo,(e.UnitsSold * e.PricePerUnit) * e.SpotRate                      
from OffshoreMangondo e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.OffshoreNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.IncomeDate = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Offshore Sale',0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr              
end         
else if @TransMode = 6 /* Cash and Call Deposits */                      
begin                      
select @UnitType = 7                      
/* Placement - Sell cash Buy units in Cash and Deposits */                      
declare EqCsr Cursor for                      
Select i.InvName,e.DepositNo,e.Amount * e.SpotRate                      
from DemandDeposits e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.DepositNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.DateInvested = @AsAtDate                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Placement of '+@EquityName,@Acquisition,0.0,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                      
                                  
/* Redemption - Buy cash Sell units in Cash and Deposits */                      
declare EqCsr Cursor for                      
Select i.InvName,e.DepositNo,e.Amount * e.RemSpotRate                      

from DemandDeposits e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.DepositNo = i.InvCode                      
     and i.DateRedeemed = @AsAtDate                      
where e.schemeNo = @schemeNo and e.Redeem = 1                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                  Values(@EquityNo,@EquityName,'Redemption of '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr           
          
/* Income - Buy cash Sell units in Cash Deposits*/                      
declare EqCsr Cursor for                      
Select i.InvName,e.DepositNo,(e.Interest - (e.MedicalLevy + e.WithholdingTax)) * e.SpotRate                      
from DemandRollover e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.DepositNo = i.InvCode                      
where e.schemeNo = @schemeNo and e.RolloverDate = @AsAtDate and e.intorwith = 0                      
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Income from '+@EquityName,0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr                 
end                        
              
/* Property */              
else if @TransMode = 5 /* Property */                      
begin              
select @UnitType = 3                      
               
/* Receipts - Buy cash sell units in Property */                      
declare EqCsr Cursor for                      
Select i.InvName,e.PropertyCode,sum(e.Amount * e.ExchangeRate)                      
from RentReceipts e                      
     inner join Investments i on e.schemeNo = i.SchemeNo and e.PropertyCode = i.InvCode                      
where e.schemeNo = @schemeNo and e.PayDate = @AsAtDate               
Group by InvName,PropertyCode                     
                      
Open EqCsr                      
Fetch from EqCsr into @EquityName,@EquityNo,@Acquisition                      
while @@fetch_Status = 0                      
begin                      
   Insert into #Equity_Trans(EquityNo,EquityName,Particulars,Acquisition,Sale,UnitType)                      
                   Values(@EquityNo,@EquityName,'Rent Receipts',0.0,@Acquisition,@UnitType)                       
                         
   select @EquityName='',@EquityNo=0,@Acquisition=0                      
   Fetch next from EqCsr into @EquityName,@EquityNo,@Acquisition                      
end                      
Close EqCsr                      
Deallocate EqCsr              
end                          
select @Acquisition = sum(Acquisition),@Sale = sum(Sale) from #Equity_Trans                      
                      
update #Equity_Trans set NetMovement = @Acquisition - @Sale,AsAtDate = @AsAtDate                      
                      
                      
select * from #Equity_Trans order by EquityNo,acquisition,Sale              
                      
if @TransType = 1 /* Buy/Sell Units */                      
begin                      
   select @NetMovement = @Acquisition - @Sale               
                  
   Exec Proc_Unit_Trusts_Details_BuySell @SCHEMENO,@UnitType,@AsAtDate,@NetMovement                 
end
go

