CREATE PROCEDURE [dbo].[Proc_Ex_Rate]    
@baseCur Int,    
@Cur Int,    
@Transdate datetime,    
@ExRate FLOAT Out    
--with encryption    
as    
    
Declare @maxdate datetime    
select @maxdate = max(ExchangeDate) from CurrencyRates where TransCurrCode = @Cur    
and BaseCurrCode = @baseCur and ExchangeDate <= @Transdate      
    
if @maxdate is not null    
   select @ExRate = ExchangeRate     
   from CurrencyRates where TransCurrCode = @Cur    
   and BaseCurrCode = @baseCur and ExchangeDate = @maxdate     
else    
   select @ExRate = 1.0000
go

