CREATE PROCEDURE [dbo].[repMembBenefsList]
@SCHEMENO Int
--with Encryption
as
if object_id('tempdb..#MemberListing') is null

begin
create table #MemberListing
(
	[SchemeNo] [varchar] (15) NOT NULL ,
             [schemeName][varchar] (120) not null,
	[MemberNo] [int] NOT NULL ,
	[fullname] [varchar](100) NOT NULL ,
              [idnumber][varchar](15),
	[dob] [datetime]  NULL ,
             [dje] [datetime]  NULL ,
             [djpens][datetime] null,
	[sex] [varchar](6) not  NULL ,
             [salary][float] null,
	[capenSal] [float]  NULL,
             [sumAssured][float] null       
) 

ALTER TABLE #MemberListing WITH NOCHECK ADD 

            
	CONSTRAINT [PK_#MemberListing] PRIMARY KEY  NONCLUSTERED 
	(
		[SchemeNo],
		[MemberNo]      
	) 
end

if object_id('tempdb..#DependantListing') is null

begin
create table #DependantListing
(
	[SchemeNo] [varchar] (15) NOT NULL ,
	[MemberNo] [int] NOT NULL ,
	[FName] [varchar](40) NULL,
             [SName] [varchar](40) NULL,
             [OName] [varchar](40) NULL,
	[depdob] [datetime]  NULL ,
             [pcntBenef] [int]  NULL ,
             [depSex][varchar] (10) not null,
	[typeDesc] [varchar](30)  NULL     
) 

end

declare @memberNo int
declare @idnumber varchar(15)
declare @dob datetime
declare @dje datetime
declare @djpens datetime
declare @fullname varchar(100)
declare @sex varchar(6)
declare @capensal float
declare @sumAssured float
declare @AmtCov int
declare @Memberclass varchar(3)
declare @AnnSal float
declare @ContMode int
declare @curYear int
declare @schemeName varchar(120)

declare @FName varchar(35), @SName varchar(40), @OName varchar(40), @bDoB datetime, @pcntBenef float, @depSex varchar(10),  @typeDesc varchar(30)

select @CurYear = Max(schemeYear) from schemeYears where SchemeNo =  @schemeNo

select @SchemeName = schemeName from scheme where schemeCode = @schemeNo

declare MembCsr cursor for 
select
m.SchemeNo,
m.MemberNo,
m.IDNumber,
m.DOB,
m.DJE,
m.DJPenS,
m.CAPenSal,
m.memberClass,
UPPER(m.Sname) + ' , ' + (m.fname) + '  ' + (m.onames) as FullName,
case m.Sex
  when 'M' then 'Male'
  when 'F' then 'Female'
else
  'Unknown'
end as MembSex
from Members m

inner Join Scheme s on m.SchemeNo = s.schemeCode

where (m.SchemeNo = @SchemeNo) and (m.ReasonForExit = 0)
order by m.MemberNo

open MembCsr

fetch from MembCsr into @schemeNo, @MemberNo, @idNumber, @dob, @dje, @djpens, @capenSal, @Memberclass, @fullname, @sex


while @@fetch_status = 0
begin
     declare BenefCsr cursor for
       select
       Dependants.schemeno, Dependants.MemberNo, Dependants.FName,
       Dependants.SName, Dependants.OName, Dependants.DOB, Dependants.pcntBenefit,
       case Dependants.Sex
       when 'M' then 'Male'
       when 'F' then 'Female'
       else 'Unknown'
       end as DepSex,
       DependantType.TypeDesc
       from Dependants inner join
        DependantType on
        Dependants.DependantType = DependantType.TypeCode
        where (Dependants.schemeNo=@schemeNo) and
       (Dependants.MemberNo=@memberno)
       order by Dependants.memberno
       
       Open BenefCsr
        fetch from BenefCsr into @schemeNo, @MemberNo, @FName, @SName, @OName, @bDoB,  @pcntBenef,  @depSex,  @typeDesc
 
        select @amtCov = amtCov  from AmountOfCover where SchemeNo = @schemeNo and ClassId = @MemberClass 

            -- exec getAnnualSalary    @schemeNo,  @MemberNo, @Annsal out
      
        exec RepMemberCertificateAnnualSalary @schemeNo, @MemberNo,  @curYear , @AnnSal out

        insert into #MemberListing (schemeNo, SchemeName, MemberNo, idNumber, dob, dje, djpens, capensal, salary, fullname, sex, sumAssured)
                       values(@schemeNo, @schemeName, @MemberNo, @idNumber, @dob, @dje, @djpens, @Annsal, @Annsal/12, @fullname, @sex, @Annsal * @amtCov) 
       select @AnnSal = 0
      
      while @@fetch_Status = 0
      begin
       insert into #DependantListing (SchemeNo, MemberNo, FName, SName, OName, depdob, pcntBenef, depSex, typeDesc)
       values(@schemeNo, @MemberNo, @FName, @SName, @OName, @bDoB,  @pcntBenef,  @depSex,  @typeDesc)
   
      fetch next from BenefCsr into @schemeNo, @MemberNo, @FName, @SName, @OName, @bDoB,  @pcntBenef,  @depSex,  @typeDesc
     end

fetch next from MembCsr into @schemeNo, @MemberNo, @idNumber, @dob, @dje, @djpens, @capenSal, @Memberclass, @fullname, @sex

close BenefCsr
deallocate BenefCsr

end

close MembCsr
deallocate MembCsr

select m.*, d.* from #MemberListing m
                       inner join #DependantListing d on
                       d.SchemeNo = m.SchemeNo and
                       d.MemberNo = m.MemberNo
go

