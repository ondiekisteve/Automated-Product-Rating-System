CREATE PROCEDURE [dbo].[repCustodian]
@SCHEMENO Int
--with Encryption
as
SELECT schemeno, CustodianCode, PIN, ITXRefNum, custodianName,
Address, Road, Building, Town, Country, Phone,
Fax, EMail, ContactName, DOApmt, ProfessionalBody,
DateofIncorporation, CertOfIncorpNum, CountryofIncorp
FROM Scheme_custodians
where schemeno = @schemeno
go

