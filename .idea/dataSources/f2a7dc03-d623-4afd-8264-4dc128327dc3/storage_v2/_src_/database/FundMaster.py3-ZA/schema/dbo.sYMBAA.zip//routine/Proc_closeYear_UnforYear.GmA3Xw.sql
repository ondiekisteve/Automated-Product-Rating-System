--> CHECKED AND VERIFIED ON 22ND JANUARY 2002 by the SysTech Development Team

/*
This PROCEDURE DBO.is used to close the current scheme year and enter opening balances
for the current year into the opening balances table
*/

CREATE PROCEDURE [dbo].[Proc_closeYear_UnforYear]
@SCHEMENO Int,
@StartDate Datetime,
@EndDate datetime
--with Encryption
as

set nocount on

declare @retCode int
declare @funcResult int
declare @totEmpCont float
declare @totEmprCont float
declare @totSpecialContr float
declare @totVolContr float
declare @currYear int
declare @memberNo int
declare @yearClosed bit
declare @hasBal bit
declare @CalculationMode int
declare @CurMonth int,@CurYear int

declare @AcctPeriod int


Select @AcctPeriod = AcctPeriod  
from schemeYears 
where SchemeNo = @schemeNo 
and StartDate = @StartDate 
and EndDate = @EndDate

Select @CurMonth = datepart(Month, @EndDate)
Select @CurrYear = datepart(Year, @EndDate)

select @CalculationMode = CalculationMode from scheme where schemeCode = @schemeNo

begin tran

declare csr_Memb cursor for
select Distinct(m.MemberNo),m.DoExit
           from Members  m
                  inner Join Contributionssummary c  on
                  m.SchemeNo = c.SchemeNo and  m.MemberNo = c.MemberNo and  c.AcctPeriod = @AcctPeriod
          where m.SchemeNo = @schemeNo and datepart(year, m.DoExit) = @currYear

open csr_Memb
fetch next from csr_Memb into @memberNo,@EndDate

while @@fetch_status = 0
begin
  Select @CurMonth = datepart(Month, @EndDate),@CurrYear = datepart(Year,@EndDate)

  if exists(select * from UnregisteredBalances where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @AcctPeriod - 1) select @hasBal = 1
  else select @hasBal = 0
  
  if @CalculationMode = 0
     begin
               exec  Proc_CalcMonthlyInterestSI_Un
               @schemeNo,  @memberNo,
               @curMonth,
               @currYear,  @hasBal,
               @totEmpCont output,
               @totEmprCont output, 
               @totSpecialContr output,
               @totVolContr output
     end
  else if @CalculationMode = 1
     begin
             exec Proc_CalcMonthlyInterest_Un
             @schemeNo, @memberNo,
             @curMonth,
             @currYear,@hasBal,
             @totEmpCont output,
             @totEmprCont output ,
             @totSpecialContr output,
             @totVolContr output
     end
  else  if @CalculationMode = 2
     begin
              exec Proc_CalcMonthlyInterestAVG_Un
              @schemeNo, @memberNo,
              @curMonth,
              @currYear,  @hasBal,
              @totEmpCont output,
              @totEmprCont output ,
              @totSpecialContr output,      
              @totVolContr output
     end
   else  if @CalculationMode = 4
     begin
              exec Proc_CalcMonthlyInterestAVGComp_Un 0,
              @schemeNo, @memberNo,
              @curMonth,
              @currYear,  @hasBal,
              @totEmpCont output,
              @totEmprCont output ,
              @totSpecialContr output,      
              @totVolContr output
     end

    else  if @CalculationMode = 5
     begin
              exec Proc_CalcMonthlyInterestAVGComp_SI_Un
              @schemeNo, @memberNo,
              @curMonth,
              @currYear,  @hasBal,
              @totEmpCont output,
              @totEmprCont output ,
              @totSpecialContr output,      
              @totVolContr output
     end
  if not exists(select * from UnregisteredBalances where SchemeNo = @schemeNo and MemberNo = @memberNo and AcctPeriod = @AcctPeriod)
     begin
            if  (@totEmpCont > 0 or @totEmprCont > 0 or @totSpecialContr > 0 or @totVolContr > 0)
                 insert into UnregisteredBalances
                  (SchemeNo, MemberNo, schemeYear, SchemeMonth, ExcessEmp, ExcessEmpr, ExcessVolContr, AcctPeriod)

                  values
                  (@schemeNo, @memberNo, @currYear, @curMonth, @totEmpCont, @totEmprCont, @totVolContr, @AcctPeriod)
       
        select @totEmpCont = 0 ,@totEmprCont = 0, @totSpecialContr = 0, @totVolContr = 0
     end
 else
     begin
          update UnregisteredBalances set ExcessEmp =@totEmpCont, ExcessEmpr =@totEmprCont,  ExcessVolContr =@totVolContr,  ExcessSpecial = @totSpecialContr
           where SchemeNo = @SchemeNo and MemberNo = @MemberNo  and AcctPeriod = @AcctPeriod
    end
  fetch next from csr_Memb into @memberNo,@EndDate
end
Close Csr_Memb
Deallocate Csr_Memb

commit tran
go

