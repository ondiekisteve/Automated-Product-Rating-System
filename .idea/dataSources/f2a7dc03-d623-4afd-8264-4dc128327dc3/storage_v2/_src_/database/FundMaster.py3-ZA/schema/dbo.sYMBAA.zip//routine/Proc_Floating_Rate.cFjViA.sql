CREATE PROCEDURE [dbo].[Proc_Floating_Rate]          
@schemeNo Int,          
@SecurityNo Int,          
@InvMode Int /* 0 - Gov, 1 - Comm, 2 - Fixed, 3 - demand*/          
--with Encryption as          
as          
declare @InterestType Int,@DueCounter Int,@NumDays Int,@DateDue datetime,          
@CouponRate Decimal(9,4),@StartDate datetime          
          
if @InvMode = 0          
   BEGIN          
   select @InterestType = InterestType,@CouponRate = InterestRate from GovernmentSecurities          
   where schemeNo = @SchemeNo and SecurityNo = @SecurityNo          
          
   IF @InterestType is null select @InterestType = 0          
          
   if @InterestType = 1 /* Floating */          
      begin          
         declare IntCsr Cursor for          
         select DueCounter,NumDays,DateDue          
         from GovCommIncomeDue where schemeNo = @schemeNo and SecurityNo = @SecurityNo          
         and RateUpdated = 0          
                   
         Open IntCsr          
         Fetch from IntCsr Into @DueCounter,@NumDays,@DateDue          
         while @@fetch_Status = 0          
         begin           
            Insert Into TBL_GOV_COMM_FloatRate(SchemeNo,SecurityNo,DueCounter_FK,StartDate,InterestRate,RateUpdated)          
                                     Values(@SchemeNo,@SecurityNo,@DueCounter,@DateDue,@CouponRate,0)          
          
            select @DueCounter=0,@NumDays=0          
            Fetch next from IntCsr Into @DueCounter,@NumDays,@DateDue          
         end          
         Close IntCsr          
         Deallocate IntCsr          
      end          
   END          
else if @InvMode = 1 /* Commercial Paper */          
   BEGIN          
   select @InterestType = InterestType,@CouponRate = InterestRate from CommercialPaper          
   where schemeNo = @SchemeNo and PaperNo = @SecurityNo          
          
   IF @InterestType is null select @InterestType = 0          
          
   if @InterestType = 1 /* Floating */          
      begin          
         declare IntCsr Cursor for          
         select DueCounter,NumDays,DateDue          
         from GovCommIncomeDue where schemeNo = @schemeNo and SecurityNo = @SecurityNo          
         and RateUpdated = 0          
                   
         Open IntCsr          
         Fetch from IntCsr Into @DueCounter,@NumDays,@DateDue          
         while @@fetch_Status = 0          
         begin           
            Insert Into TBL_GOV_COMM_FloatRate(SchemeNo,SecurityNo,DueCounter_FK,StartDate,InterestRate,RateUpdated)          
                                     Values(@SchemeNo,@SecurityNo,@DueCounter,@DateDue,@CouponRate,0)          
          
            select @DueCounter=0,@NumDays=0          
            Fetch next from IntCsr Into @DueCounter,@NumDays,@DateDue          
         end          
         Close IntCsr          
         Deallocate IntCsr          
      end          
   END       
else if @InvMode = 2 /* Term Deposits */          
   BEGIN          
   select @InterestType = InterestType,@CouponRate = InterestRate from cashDeposits          
   where schemeNo = @SchemeNo and DepositNo = @SecurityNo          
          
   IF @InterestType is null select @InterestType = 0          
          
   if @InterestType = 1 /* Floating */          
      begin          
         declare IntCsr Cursor for          
         select DueCounter,NumDays,DateDue          
         from GovCommIncomeDue where schemeNo = @schemeNo and SecurityNo = @SecurityNo          
         and RateUpdated = 0          
                   
         Open IntCsr          
         Fetch from IntCsr Into @DueCounter,@NumDays,@DateDue          
         while @@fetch_Status = 0          
         begin           
            Insert Into TBL_GOV_COMM_FloatRate(SchemeNo,SecurityNo,DueCounter_FK,StartDate,InterestRate,RateUpdated)          
                                     Values(@SchemeNo,@SecurityNo,@DueCounter,@DateDue,@CouponRate,0)          
          
select @DueCounter=0,@NumDays=0          
            Fetch next from IntCsr Into @DueCounter,@NumDays,@DateDue          
         end          
         Close IntCsr          
       Deallocate IntCsr          
      end          
   END
go

