CREATE PROCEDURE [dbo].[ImportUnpresentedCheques]          
@SchemeNo Int,          
@BankCode Int,          
@TransDate Datetime,          
@Particulars varchar(100),          
@ChequeNo varchar(20),          
@Debit float,          
@Credit float,      
@Recon int,  
@SchemeCode Int               
as          
declare @gSchemeNo Int,@AccountCode varchar(30)

select @AccountCode = AccountCode from SchemeBankBranch where schemeNo = @schemeNo and BankCode = @BankCode   
  
if @SchemeCode is null 
   select @SchemeCode = @SchemeNo
else
   begin
     select @BankCode = BankCode from SchemeBankBranch where schemeNo = @SchemeCode and AccountCode = @AccountCode
   end        
        
if @ChequeNo is not null select @chequeNo = ltrim(rtrim(@ChequeNo))          
          
if @Particulars is null select @Particulars=''          
          
Exec Proc_Parent_Scheme @gSchemeNo Out          
          
Insert Into UnPresentedCheques(SchemeNo,BankCode,TransDate,BankMonth,BankYear,ChequeNo,          
                               Debit,Credit,Particulars,Cleared,SchemeCode,Recon)          
                       Values(@gSchemeNo,@BankCode,@TransDate,datepart(month,@TransDate),          
                              datepart(Year,@TransDate),@ChequeNo,@Debit,@Credit,@Particulars,0,@SchemeCode,@Recon)
go

