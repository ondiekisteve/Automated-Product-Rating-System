CREATE PROCEDURE [dbo].[Proc_Rep_MemberLoans_All_Summary]
@SCHEMENO Int,
@StartDate Datetime,
@EndDate Datetime,
@AsAtDate Datetime,
@RepMode Int /*0 - All Loans, 
               1 - Outstanding Loans, 
               2 -  Loans Repaid ,
               3- Serviced Loans,
               4 - Loans not commenced repayment after 60 days */
--with Encryption
as

if object_id('tempdb..#Rep_MemberLoans') is null

begin
create table #Rep_MemberLoans
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[Sponsor] [varchar](100) NOT NULL ,
	[MemberNo] [Varchar](100) not  NULL,
        [FullName] [Varchar](100) null,
        [Loan][float] not null,
        [LoanRepaid][float] not null,
        [LoanBalance][float] not null,
        [DateApplied][Datetime],
        [DateIssued][Datetime],
        [DateReceived][Datetime],
        [LoanApplied][float]
) 

ALTER TABLE #Rep_MemberLoans WITH NOCHECK ADD 

            
	CONSTRAINT [PK_Rep_MemberLoans] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end

declare @MemberNo Int,@LoanCode Int,@DateApplied Datetime,@Loan float,@Term float,
@FullName Varchar(100),@SponsorCode Int,@Sponsor Varchar(100),@LoanRepaid float,
@DateIssued Datetime,@DateReceived Datetime,@LoanApplied float,@LoanNo Int

declare acsr Cursor for
Select l.MemberNo,l.LoanCode,l.DateApplied,l.Loan,l.Term,l.DateIssued,l.DateReceived,l.LoanApplied,
m.fName+' '+m.Onames+' '+m.sName,m.SponsorCode,l.LoanNo
FROM MemberCompanyLoan l
     inner Join Members m on l.schemeNo = m.schemeNo and l.MemberNo = m.MemberNo
WHERE l.schemeNo = @SCHEMENO and l.DateIssued >= @StartDate and l.DateIssued <= @EndDate
AND L.LoanType = 0

Open acsr
fetch from acsr into @MemberNo,@LoanCode,@DateApplied,@Loan,@Term,@DateIssued,@DateReceived,@LoanApplied,@FullName,@SponsorCode,@LoanNo
while @@fetch_Status = 0
begin

  select @LoanRepaid = sum(Amount) 
  FROM Member_Loan_Repayment
  WHERE schemeNo = @SCHEMENO and MemberNo = @MemberNo and LoanNo = @LoanNo
  and DatePaid <= @AsAtDate

  if @LoanRepaid is null select @LoanRepaid = 0

  select @Sponsor = SponsorName from sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode
 
  if @RepMode = 0
     insert into #Rep_MemberLoans (sponsor,MemberNo,fullName,Loan,LoanRepaid,LoanBalance,DateIssued,DateReceived,LoanApplied)
                      Values(@Sponsor,@MemberNo,@FullName,@Loan,@LoanRepaid,@Loan-@LoanRepaid,@DateIssued,@DateReceived,@LoanApplied)
  else if @RepMode = 1
     begin
      if @LoanRepaid = 0
         insert into #Rep_MemberLoans (sponsor,MemberNo,fullName,Loan,LoanRepaid,LoanBalance,DateIssued,DateReceived,LoanApplied)
                      Values(@Sponsor,@MemberNo,@FullName,@Loan,@LoanRepaid,@Loan-@LoanRepaid,@DateIssued,@DateReceived,@LoanApplied)
     end
 else if @RepMode = 2
     begin
      if @LoanRepaid = @Loan
         insert into #Rep_MemberLoans (sponsor,MemberNo,fullName,Loan,LoanRepaid,LoanBalance,DateIssued,DateReceived,LoanApplied)
                      Values(@Sponsor,@MemberNo,@FullName,@Loan,@LoanRepaid,@Loan-@LoanRepaid,@DateIssued,@DateReceived,@LoanApplied)
     end
 else if @RepMode = 3
     begin
      if ((@LoanRepaid < @Loan) and (@LoanRepaid > 0.0))
         insert into #Rep_MemberLoans (sponsor,MemberNo,fullName,Loan,LoanRepaid,LoanBalance,DateIssued,DateReceived,LoanApplied)
                      Values(@Sponsor,@MemberNo,@FullName,@Loan,@LoanRepaid,@Loan-@LoanRepaid,@DateIssued,@DateReceived,@LoanApplied)
     end
 else if @RepMode = 4
     begin
         if Not Exists (select * FROM Member_Loan_Repayment
                        WHERE schemeNo = @SCHEMENO and MemberNo = @MemberNo and LoanNo = @LoanNo
                        and DatePaid <= DateAdd(Day,60,@DateIssued))
         begin
             insert into #Rep_MemberLoans (sponsor,MemberNo,fullName,Loan,LoanRepaid,LoanBalance,DateIssued,DateReceived,LoanApplied)
             Values(@Sponsor,@MemberNo,@FullName,@Loan,@LoanRepaid,@Loan-@LoanRepaid,@DateIssued,@DateReceived,@LoanApplied)
         end

     end

  select @Sponsor = '',@SponsorCode = 0,@LoanCode = 0,@Loan = 0,@LoanRepaid = 0,@LoanApplied = 0
  fetch next from acsr into @MemberNo,@LoanCode,@DateApplied,@Loan,@Term,@DateIssued,@DateReceived,@LoanApplied,@FullName,@SponsorCode,@LoanNo
end
Close Acsr
Deallocate Acsr

select * from #Rep_MemberLoans order by MemberNo
go

