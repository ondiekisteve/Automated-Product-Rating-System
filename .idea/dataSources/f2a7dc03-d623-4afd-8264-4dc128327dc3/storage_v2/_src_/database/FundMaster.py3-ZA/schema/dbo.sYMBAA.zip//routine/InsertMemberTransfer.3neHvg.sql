CREATE PROCEDURE [dbo].[InsertMemberTransfer] /* Member Transfering to a another scheme within the database */        
@SCHEMENO Int,        
@memberNo int,        
@EmpTransfer float,        
@EmprTransfer float,        
@TransferDate datetime,        
@NewSchemeNo Int        
--with Encryption        
as        
        
declare @NewMemberNo Int,@AcctPeriod Int,@PayrollNo Varchar(20),@SponsorCode Int,@EndDate datetime,      
 @SchemeName varchar(100),@ActiveStatus smallint,@EmpPortion float        
        
select @NewMemberNo = Max(MemberNo) from Members where schemeNo = @NewSchemeNo        
        
if @NewMemberNo is null select @NewMemberNo = 0        
select @NewMemberNo = @NewMemberNo + 1        
        
select @SponsorCode = SponsorCode from Sponsor where SchemeNo = @NewSchemeNo        
        
select @PayrollNo = cast(@NewMemberNo as Varchar(20))      
      
select @TransferDate = DoCalc,@ActiveStatus = ActiveStatus 
from Members where MemberNo = @memberNo  and SCHEMENO = @SCHEMENO 

if @ActiveStatus is null select @ActiveStatus = 1    
      
select @SchemeName = SchemeName from Scheme where SchemeCode = @SchemeNo      
         
/* sp_helptext Proc_InsertMember */        
 select @EndDate = max(EndDate) from SchemeYears where Schemeno = @NewSchemeNo        
        
If @EndDate < @TransferDate        
   begin        
 raiserror('The Transfer Date is greater than Maximum Fiscal Year of the new Scheme.',16,1)        
 return        
   end        
Else    
  begin    
   select @AcctPeriod = AcctPeriod from schemeYears where schemeNo = @NewSchemeNo        
   and StartDate <= @TransferDate and EndDate >= @TransferDate   
  
   print @AcctPeriod  
   print @NewSchemeNo  
   print @TransferDate

   if @ActiveStatus = 6
      begin
        select @EmpPortion = EmprcBal + SpecialCBal + EmprTransferCBal + PreEmprCBal
        from Benefits where schemeNo = @schemeNo and MemberNo = @MemberNo

        insert into MemberTransfer(schemeNo, Scheme, MemberNo, EmpTransfer, EmprTransfer, TransferDate, AcctPeriod,         
                           TransferType,PrevSchemeNo,PrevMemberNo)        
           values(@NewschemeNo, @SchemeName, @NewMemberNo, 0,@EmpPortion, @TransferDate,        
                  @AcctPeriod, 0,@SchemeNo,@MemberNo)
      end
   else    
      begin  
           insert into MemberTransfer(schemeNo, Scheme, MemberNo, EmpTransfer, EmprTransfer, TransferDate, AcctPeriod,         
                           TransferType,PrevSchemeNo,PrevMemberNo)        
           values(@NewschemeNo, @SchemeName, @NewMemberNo, @EmpTransfer,@EmprTransfer, @TransferDate,        
                  @AcctPeriod, 0,@SchemeNo,@MemberNo) 
      end       
        
        
Insert Into Members (SchemeNo,                      
                       MemberNo,                      
                       CompanyId,memberClasS,FName ,SName,ONames,IDNumber,PassPort,Address,Building,Road,                      
                       TownAddress,Sex,DOB,MStatus,DJE,DJPenS,PayrollNo,ReasonForExit,CAPenSal,                      
                       AVC,Dept,Sect,Grade,ActiveStatus,DesignCode,SponsorCode,checkNo,DatesConfirmed,                      
                              Email,MobileNo)                      
           select @NewschemeNo,                      
                       @NewMemberNo,                      
                       CompanyId,memberClasS,FName ,SName,ONames,IDNumber,PassPort,Address,Building,Road,                      
                       TownAddress,Sex,DOB,MStatus,DJE,DJPenS,@PayrollNo,0,CAPenSal,                      
                       AVC,Dept,Sect,Grade,1,DesignCode,@SponsorCode,checkNo,DatesConfirmed,                      
                              Email,MobileNo from members where Memberno = @MemberNo and         
    SchemeNo = @SchemeNo                     
                    
INSERT INTO NETLOGIN(USERNAME,PASSWORD,IDNUMBER,ROLE,SCHEMENO,MEMBERNO,EMAIL)                    
 select Email,@NewschemeNo,IDNumber,1,@NewschemeNo,@NewMemberNo,Email from members         
 where Memberno = @MemberNo and SchemeNo = @SchemeNo   
  
end
go

