CREATE PROCEDURE [dbo].[repContributionsSchemes1]                                
@SCHEMENO Int,              
@AcctPeriod Int                                   
--with Encryption                                   
as      
IF EXISTS (SELECT name FROM sysindexes       
      WHERE name = 'ContrHistory')      
   DROP INDEX #RepContrHistory.ContrHistory      
                                  
if object_id('tempdb..#RepContrHistory') is null                                  
 begin                                  
    CREATE TABLE [#RepContrHistory]                                  
   (RepCounter Int Identity(1,1) primary Key,        
    [SchemeNo] Int,                                  
    [DatePaid][datetime] null,                                  
    [contrMonth][int] null,                                  
    [contrYear][int] null,                                  
    [salary][float] null default (0.00),                                  
    [EmpCont][float] null default(0.00),                                  
    [EmprCont][float] null default(0.00),                                  
    [SpecialContr][float] null default(0.00),                                  
    [VolContr][float]  null default(0.00),                                  
    [Excess][float] null default(0.00),                                  
    [DeferredAmt][float] null default (0.00),                                
    [Nssf][float]  null default(0.00),                                  
    [AugCont][float] null default(0.00),                                  
    [TotalContr][float] null default(0.00),                                  
    [AcctPeriod][int],                                  
    [monthname][varchar](50),                                      
    [schemeName][varchar](120)null,                                  
    [Arrears][float]null default(0.00),                                  
    [Descr][varchar](20) null,                  
    [Sponsor][varchar](120),        
    [PoolName][varchar](120)                                  
   )                                  
 end                   
      
set nocount off      
CREATE INDEX ContrHistory      
   ON #RepContrHistory (SchemeNo, contrYear, contrMonth)      
    
IF EXISTS (SELECT name FROM sysindexes       
      WHERE name = 'RepContr')      
   DROP INDEX #RepcontrYear.RepContr      
           
     
if object_id('tempdb..#RepcontrYear') is null                                  
 begin                                  
    CREATE TABLE #RepcontrYear    
  (                                                              
    [contrMonth][int],                                  
    [contrYear][int]                                  
   )                                  
 end     
    
CREATE INDEX RepContr      
   ON #RepcontrYear (contrYear, contrMonth)      
      
                 
declare @Sponsor varchar(120),@ContrMonth int,@ContrYear int,@Datepaid datetime,@monthname varchar(3),            
 @TransferDate datetime,@TransferDateUn datetime,@SchemeName varchar(120),@ArrearsDatepaid datetime,        
 @StartYear Int,@EndYear Int,@startMonth Int,@endMonth Int,@salary float,@EmpCont float,@EmprCont float,                                  
 @SpecialContr float,@VolContr float,@Excess float,@DeferredAmt float,@Nssf float,@AugCont float,@EmpTransfer float,@EmprTransfer float,  
 @AVCTransfer float,@AVCERTransfer float,@TotalContr float,@Arrears float,@Finalsalary float,@FinalEmpCont float,@FinalEmprCont float,                                  
 @FinalSpecialContr float,@FinalVolContr float,@FinalExcess float,@FinalDeferredAmt float,@FinalNssf float,@FinalAugCont float,                                  
 @FinalTotalContr float,@FinalArrears float,@memberno int,@FinalEmpTransfer float,@FinalEmprTransfer float,@FinalAVCTransfer float,  
 @FinalAVCERTransfer float            
  
 select @salary = 0.0,@EmpCont = 0.0,@EmprCont = 0.0,                                  
 @SpecialContr = 0.0,@VolContr = 0.0,@Excess = 0.0,@DeferredAmt = 0.0,@Nssf = 0.0,@AugCont = 0.0,                                  
 @EmpTransfer = 0.0,@EmprTransfer = 0.0,@AVCTransfer = 0.0,@AVCERTransfer = 0.0,@TotalContr = 0.0,  
 @Arrears = 0.0,@Finalsalary = 0.0,@FinalEmpCont = 0.0,@FinalEmprCont = 0.0,@FinalSpecialContr = 0.0,  
 @FinalVolContr = 0.0,@FinalExcess = 0.0,@FinalDeferredAmt = 0.0,@FinalNssf = 0.0,@FinalAugCont = 0.0,                                  
 @FinalTotalContr = 0.0,@FinalArrears = 0.0,@FinalEmpTransfer = 0.0,@FinalEmprTransfer = 0.0,@FinalAVCTransfer =0.0,  
 @FinalAVCERTransfer = 0.0  
                  
select @Sponsor = sponsorName from sponsor where schemeNo = @schemeNo                
                
select @SchemeName = SchemeName from Scheme where SchemeCode = @SchemeNo            
          
select @StartYear = datepart(Year,StartDate),@startMonth = datepart(month,startDate),    
@EndYear = datepart(Year,EndDate),@endMonth = datepart(Month,EndDate) from SchemeYears         
where schemeno = @SchemeNo and AcctPeriod = @AcctPeriod       
    
if @StartYear = @endYear    
begin    
   while @StartMonth <= @EndMonth    
   begin    
     insert into #RepcontrYear(ContrMonth,ContrYear)    
                  Values(@StartMonth,@StartYear)    
          
     select @StartMonth = @StartMonth + 1    
   end    
end     
else if @StartYear <> @endYear     
begin    
   while @StartMonth <= 12    
   begin    
      insert into #RepcontrYear(ContrMonth,ContrYear)    
                  Values(@StartMonth,@StartYear)    
      select @StartMonth = @StartMonth + 1    
   end    
   select @StartMonth = 1    
      
   while @StartMonth <= @EndMonth    
   begin    
 insert into #RepcontrYear(ContrMonth,ContrYear)    
                  Values(@StartMonth,@EndYear)    
      select @StartMonth = @StartMonth + 1    
   end    
end          
                    
if @Sponsor is null select @Sponsor = ''                    
                                 
delete #RepContrHistory        
    
declare RepContrCsr Cursor for                
select distinct ContrMonth,ContrYear from #RepcontrYear     
order by ContrYear,ContrMonth               
    
Open RepcontrCsr                
fetch from RepcontrCsr into @ContrMonth,@ContrYear                
                
while @@fetch_status = 0                
BEGIN       
    
select @monthname = left(monthname,3) from MonthTable where MonthNumber = @ContrMonth          
              
/* ContributionsSummary */  
if exists(select * from ContributionsSummary         
where schemeNo = @schemeNo and ContrYear = @ContrYear and ContrMonth = @ContrMonth)                
begin  
  
Declare ContrCsr cursor for  
select distinct Datepaid from ContributionsSummary where schemeNo = @schemeNo and ContrYear = @ContrYear   
 and ContrMonth = @ContrMonth  
  
Open ContrCsr  
fetch from contrCsr into @Datepaid  
  
while @@fetch_status = 0  
begin  
select @salary = sum(salary),@EmpCont = sum(EmpCont),@EmprCont = sum(EmprCont),@SpecialContr = sum(SpecialContr),                                    
       @VolContr = sum(VolContr),@Excess = sum((ExcessEmprCont + ExcessEmpcont + ExcessVolContr + ExcessSpecial)),                                    
       @Nssf = sum((NssfE + nssf)),@AugCont = sum(AugCont),@TotalContr = sum((empcont + emprcont + specialContr +   
       volContr + nssf + nssfe + excessEmpcont + excessEmprcont + ExcessVolContr + ExcessSpecial + AugCont))  
FROM ContributionsSummary WHERE schemeNo = @schemeNo and ContrYear = @ContrYear and ContrMonth = @ContrMonth 
and DatePaid = @DatePaid
 
  
select @Finalsalary = @Finalsalary + @salary,@FinalEmpCont = @FinalEmpCont + @EmpCont,@FinalEmprCont = @FinalEmprCont + @EmprCont,                                  
       @FinalSpecialContr = @FinalSpecialContr + @SpecialContr,@FinalVolContr = @FinalVolContr + @VolContr,@FinalExcess = @FinalExcess + @Excess,  
       @FinalDeferredAmt = 0.0,@FinalNssf = @FinalNssf + @Nssf,@FinalAugCont = @FinalAugCont + @AugCont,                                  
       @FinalTotalContr = @FinalTotalContr + @TotalContr,@FinalArrears = 0.0 

        
     insert into #RepContrHistory                                  
     SELECT                                    
     @SchemeNo,                                    
     @DatePaid,                                    
     @contrMonth,                                    
     @contrYear,                                    
     @Finalsalary,                                    
     @FinalEmpCont,                                    
     @FinalEmprCont,                                    
     @FinalSpecialContr,                                    
     @FinalVolContr,                                    
     @FinalExcess,                                    
     0,                                
     @FinalNssf,@FinalAugCont,                                    
     @FinalTotalContr,@AcctPeriod,                                    
     @monthname,                                   
     @schemeName,0,' ',@Sponsor,''   
  
 select @salary = 0.0,@EmpCont = 0.0,@EmprCont = 0.0,                                  
 @SpecialContr = 0.0,@VolContr = 0.0,@Excess = 0.0,@DeferredAmt = 0.0,@Nssf = 0.0,@AugCont = 0.0,                                  
 @TotalContr = 0.0,@MemberNo = 0  
fetch next from ContrCsr into @Datepaid  
end  
Close ContrCsr  
Deallocate ContrCsr          
  
end  
  
select @salary = 0.0,@EmpCont = 0.0,@EmprCont = 0.0,                                  
 @SpecialContr = 0.0,@VolContr = 0.0,@Excess = 0.0,@DeferredAmt = 0.0,@Nssf = 0.0,@AugCont = 0.0,                                  
 @TotalContr = 0.0,@Arrears = 0.0,@Finalsalary = 0.0,@FinalEmpCont = 0.0,@FinalEmprCont = 0.0,                                  
 @FinalSpecialContr = 0.0,@FinalVolContr = 0.0,@FinalExcess = 0.0,@FinalDeferredAmt = 0.0,@FinalNssf = 0.0,@FinalAugCont = 0.0,                                  
 @FinalTotalContr = 0.0,@FinalArrears = 0.0  
  
/*ContributionArrears*/  
if exists(select * from ContributionArrears         
where schemeNo = @schemeNo and datepart(Year,Datepaid) = @ContrYear and datepart(month,Datepaid) = @ContrMonth)                
begin  
  
Declare ContrCsr cursor for  
select distinct Datepaid from ContributionArrears where schemeNo = @schemeNo 
and datepart(Year,Datepaid) = @ContrYear and datepart(month,Datepaid) = @ContrMonth 
  
Open ContrCsr  
fetch from contrCsr into @ArrearsDatepaid  
  
while @@fetch_status = 0  
begin  
select @salary = sum(salary),@EmpCont = sum(ArEmpCont),@EmprCont = sum(ArEmprCont),@SpecialContr = sum(ArSpecial),                                    
       @VolContr = sum(ArVolContr),@Excess = sum((ArEmprcont_un + ArEmpcont_un ))
FROM ContributionArrears WHERE schemeNo = @schemeNo and datePaid = @ArrearsDatepaid 

if @salary is null select @salary = 0
if @EmpCont is null select @EmpCont = 0
if @EmprCont is null select @EmprCont = 0
if @SpecialContr is null select @SpecialContr = 0
if @VolContr is null select @VolContr = 0
if @Excess is null select @Excess = 0

select @TotalContr = @EmpCont + @EmprCont + @SpecialContr + @VolContr + @Excess  

if @TotalContr > 0
   insert into #RepContrHistory                                  
   SELECT                                    
   @SchemeNo,                                    
   @ArrearsDatepaid,                                   
   @contrMonth,                                    
   @contrYear,                                    
   @salary,                                    
   @EmpCont,                                    
   @EmprCont,                                    
   @SpecialContr,                               
   @VolContr,                                    
   @Excess,                                  
   0,                                  
   0 AS Nssf,0,                                    
   @TotalContr,@AcctPeriod,                                    
   @monthname,                                    
   @schemeName,1,' [Arrears]',@Sponsor,''                                 
   
   select @salary = 0.0,@EmpCont = 0.0,@EmprCont = 0.0,                                  
   @SpecialContr = 0.0,@VolContr = 0.0,@Excess = 0.0,@DeferredAmt = 0.0,@Nssf = 0.0,@AugCont = 0.0,                                  
   @TotalContr = 0.0,@MemberNo = 0 

fetch next from ContrCsr into @ArrearsDatepaid  
end  
Close ContrCsr  
Deallocate ContrCsr  
  
end  
                         
select  @DeferredAmt = 0.0,@EmpTransfer = 0.0,@EmprTransfer = 0.0,@AVCTransfer = 0.0,@AVCERTransfer = 0.0,@TotalContr = 0.0,  
        @FinalDeferredAmt = 0.0,@FinalEmpTransfer = 0.0,@FinalEmprTransfer = 0.0,@FinalAVCTransfer =0.0,@FinalAVCERTransfer = 0.0,  
 @FinalTotalContr = 0.0              
  
/*Transfers*/  
if exists(select * from MemberTransfer         
where schemeNo = @schemeno and AcctPeriod = @AcctPeriod and datepart(month,TransferDate) = @ContrMonth              
and datepart(year,TransferDate) = @ContrYear)                
begin  
  
Declare ContrCsr cursor for  
select distinct TransferDate FROM MemberTransfer                                    
  WHERE schemeNo = @schemeno and AcctPeriod = @AcctPeriod and datepart(month,TransferDate) = @ContrMonth              
  and datepart(year,TransferDate) = @ContrYear  
  
Open ContrCsr  
fetch from contrCsr into @TransferDate  
  
while @@fetch_status = 0  
begin  
select @EmpTransfer = sum(EmpTransfer),@EmprTransfer = sum(EmprTransfer),                                  
       @AVCTransfer = sum(AVCERTransfer),@AVCERTransfer = sum(AVCTransfer),                                 
       @DeferredAmt = sum(DeferredAmt),
       @TotalContr = sum((EmpTransfer + EmprTransfer + AVCTransfer + AVCERTransfer + DeferredAmt))  
from MemberTransfer                                    
WHERE schemeNo = @schemeno and Memberno = @Memberno and AcctPeriod = @AcctPeriod and datepart(month,TransferDate) = @ContrMonth              
 and datepart(year,TransferDate) = @ContrYear and TransferDate = @TransferDate 
  
if @EmpTransfer is null select @EmpTransfer = 0
if @EmprTransfer is null select @EmprTransfer = 0
if @AVCTransfer is null select @AVCTransfer = 0
if @AVCERTransfer is null select @AVCERTransfer = 0
if @DeferredAmt is null select @DeferredAmt = 0


select @TotalContr = @EmpTransfer + @EmprTransfer + @AVCTransfer + @AVCERTransfer + @DeferredAmt  

if @TotalContr > 0 
  insert into #RepContrHistory                                  
  SELECT                                    
  @SchemeNo,                                     
  @TransferDate,                                    
  @ContrMonth,                                  
  @ContrYear,                                    
  0,--salary                                    
  @EmpTransfer,                                    
  @EmprTransfer, --+ DeferredAmt,                                  
  @AVCTransfer,                                    
  @AVCERTransfer,                                
  0,-- Excess,                                 
  @DeferredAmt,                                   
  0 AS Nssf,0,                                    
  @FinalTotalContr,                                  
  @AcctPeriod,                                    
  @monthname,                                    
  @SchemeName,2,' [Transfer]',@Sponsor,''   
 
 select @DeferredAmt = 0.0,@EmpTransfer = 0.0,@EmprTransfer = 0.0,@AVCTransfer = 0.0,@AVCERTransfer = 0.0,@TotalContr = 0.0,  
 @MemberNo = 0  
fetch next from ContrCsr into @TransferDate  
end           
Close ContrCsr  
Deallocate ContrCsr            
  
end          
  
select  @DeferredAmt = 0.0,@EmpTransfer = 0.0,@EmprTransfer = 0.0,@AVCTransfer = 0.0,@AVCERTransfer = 0.0,@TotalContr = 0.0,  
        @FinalDeferredAmt = 0.0,@FinalEmpTransfer = 0.0,@FinalEmprTransfer = 0.0,@FinalAVCTransfer =0.0,@FinalAVCERTransfer = 0.0,  
 @FinalTotalContr = 0.0              
  
/*TransfersUn*/  
if exists(select * from MemberTransferUn         
where schemeNo = @schemeno and AcctPeriod = @AcctPeriod and datepart(month,TransferDate) = @ContrMonth              
and datepart(year,TransferDate) = @ContrYear)                
begin  
  
Declare ContrCsr cursor for  
select distinct TransferDate FROM MemberTransferUn                                    
  WHERE schemeNo = @schemeno and AcctPeriod = @AcctPeriod and datepart(month,TransferDate) = @ContrMonth              
  and datepart(year,TransferDate) = @ContrYear  
  
Open ContrCsr  
fetch from contrCsr into @TransferDate  
  
while @@fetch_status = 0  
begin  
select @EmpTransfer = sum(EmpTransfer),@EmprTransfer = sum(EmprTransfer),                                  
       @AVCTransfer = sum(AVCERTransfer),@AVCERTransfer = sum(AVCTransfer),                                 
       @DeferredAmt = sum(DeferredAmt),@TotalContr = sum((EmpTransfer + EmprTransfer + AVCTransfer + AVCERTransfer + DeferredAmt))  
from MemberTransferUn                                    
WHERE schemeNo = @schemeno and Memberno = @Memberno and AcctPeriod = @AcctPeriod and datepart(month,TransferDate) = @ContrMonth              
 and datepart(year,TransferDate) = @ContrYear  
  
if @EmpTransfer is null select @EmpTransfer = 0
if @EmprTransfer is null select @EmprTransfer = 0
if @AVCTransfer is null select @AVCTransfer = 0
if @AVCERTransfer is null select @AVCERTransfer = 0
if @DeferredAmt is null select @DeferredAmt = 0


select @TotalContr = @EmpTransfer + @EmprTransfer + @AVCTransfer + @AVCERTransfer + @DeferredAmt  

if @TotalContr > 0 
  insert into #RepContrHistory                                  
  SELECT                                    
  @SchemeNo,                                     
  @TransferDate,                                    
  @ContrMonth,                                  
  @ContrYear,                                    
  0,--salary                                    
  @EmpTransfer,                                    
  @EmprTransfer, --+ DeferredAmt,                                  
  @AVCTransfer,                                    
  @AVCERTransfer,                                
  0,-- Excess,                                 
  @DeferredAmt,                                   
  0 AS Nssf,0,                                    
  @FinalTotalContr,                                  
  @AcctPeriod,                                    
  @monthname,                                    
  @SchemeName,2,' [Transfer]',@Sponsor,'' 

 select @DeferredAmt = 0.0,@EmpTransfer = 0.0,@EmprTransfer = 0.0,@AVCTransfer = 0.0,@AVCERTransfer = 0.0,@TotalContr = 0.0,  
        @MemberNo = 0  
fetch next from ContrCsr into @TransferDate  
end           

Close ContrCsr  
Deallocate ContrCsr            
  
end  
  
 select @salary = 0.0,@EmpCont = 0.0,@EmprCont = 0.0,                                  
 @SpecialContr = 0.0,@VolContr = 0.0,@Excess = 0.0,@DeferredAmt = 0.0,@Nssf = 0.0,@AugCont = 0.0,                                  
 @EmpTransfer = 0.0,@EmprTransfer = 0.0,@AVCTransfer = 0.0,@AVCERTransfer = 0.0,@TotalContr = 0.0,  
 @Arrears = 0.0,@Finalsalary = 0.0,@FinalEmpCont = 0.0,@FinalEmprCont = 0.0,@FinalSpecialContr = 0.0,  
 @FinalVolContr = 0.0,@FinalExcess = 0.0,@FinalDeferredAmt = 0.0,@FinalNssf = 0.0,@FinalAugCont = 0.0,                                  
 @FinalTotalContr = 0.0,@FinalArrears = 0.0,@FinalEmpTransfer = 0.0,@FinalEmprTransfer = 0.0,@FinalAVCTransfer =0.0,  
 @FinalAVCERTransfer = 0.0  
                   
/*finalize totals n execess*/                                  
update #RepContrHistory set TotalContr = 0,Excess = 0 where excess is null                        
update #RepContrHistory set  DeferredAmt = 0 where DeferredAmt  is null                                   
update #RepContrHistory set TotalContr = (empcont + emprcont + specialContr + volContr + Excess+DeferredAmt),                          
        emprcont = (emprcont + DeferredAmt)              
              
select @ContrMonth = 0,@ContrYear = 0              
fetch next from RepcontrCsr into @ContrMonth,@ContrYear              
END                      
Close RepcontrCsr              
Deallocate RepcontrCsr         
     
delete from #RepContrHistory where TotalContr = 0 or TotalContr is null                         
select * from  #RepContrHistory  order by ContrYear,ContrMonth, arrears   
--select sum(TotalContr) from  #RepContrHistory
go

