CREATE PROCEDURE [dbo].[PensionerReconciliationAll]                            
@SCHEMENO Int,                            
@PayMonth int,                            
@PayYear int                            
--with Encryption                            
as                            
                          
                          
IF EXISTS (SELECT name FROM sysindexes                                     
      WHERE name = 'ReconAll')                           
                                   
DROP INDEX ##ReconciliationAll.Recon                           
                            
if object_id('tempdb..##ReconciliationAll') is not null drop Table ##ReconciliationAll                             
                            
begin                            
create table ##ReconciliationAll                            
(                            
 [SchemeName] [varchar] (120) NOT NULL ,                            
 [ReconCode] [int] IDENTITY(1,1)  primary key,                            
 [PrevPension] [float] NOT NULL ,                            
 [CurPension] [float] not  NULL default 0.0 ,                            
             [NewEntrants] [float]  not NULL default 0.0,                            
             [Increase][float] not null default 0.0,                            
             [Decrease][float]  null default 0.0,                            
             [Exits] [float] not NULL default 0.0,                            
             [Total] [float] NULL  default 0.0,                            
             [Period][varchar](30) not null,                            
             [prevPeriod][varchar](30) not null ,                            
             [suspension][float] null,                         
             [Prevsuspension][float] null,                          
             [Deductions][float] null ,                            
             [Net][float] null,                                       
             [PrevPensionNo][int] null,          
             [CurPensionNo][int] null,          
             [NewEntrantsNo][int] null,          
             [IncreaseNo][int] null,          
             [DecreaseNo][int] null,          
             [ExitsNo][int] null,          
             [PrevsuspensionNo][int] null,          
             [suspensionNo][int] null,          
             [DeductionsNo][int] null,
             [Arrears][float]          
)                              
end                            
                            
CREATE INDEX ReconAll                                    
   ON ##ReconciliationAll (SchemeName,ReconCode)                           
                            
delete from ##ReconciliationAll                            
                            
declare @SchemeName varchar(100), @PrevPension float, @NewEntrants float, @curPension float,                            
        @Increase float, @Exits float, @Total float, @Net Float, @MemberNo int, @MonthName varchar(30),                             
        @PrevMonth varchar(30), @startMonth int,@StartYear int, @NetExit float, @NetIncrease float, @cNet float, @pNet float,                            
        @PrevPensionB float,@curPensionB float,@NewEntrantsB int,@IncreaseB Float,@ExitsB float,@TotalB float,                            
        @Decrease float,@NetDecrease float,@dNet float,@DecreaseB float, @Suspension float,@Paye float,@Deductions float,@Attachments float,                            
        @SuspensionB float, @DeductionsB float,@NetB float,@PrevSuspension float, @PrevSuspensionB float,          
        @PrevPensionNo int,@CurPensionNo int,@NewEntrantsNo int,@IncreaseNo int,@DecreaseNo int,@ExitsNo int,          
        @PrevsuspensionNo int,@suspensionNo int,@suspensionbNo int,@PrevPensionbNo int,@PrevsuspensionBNo int,          
        @DeductionsNo int,@DeductionsBNo int,@Arrears float         
                            
if @PayMonth = 1                             
   begin                            
    select @StartYear = @PayYear - 1                            
    select @StartMonth = 12                            
   end                            
else                            
  begin                
   select @StartYear = @PayYear                            
   select @StartMonth =@PayMonth -1                            
  end                       
                          
select @SchemeName = schemeName from  scheme where schemecode =  @SchemeNo                            
                
select @MonthName = MonthName from MonthTable where MonthNumber  = @PayMonth                            
select @PrevMonth = MonthName from MonthTable where MonthNumber  = @StartMonth                            
                            
select @MonthName = @MonthName +', '+ cast(@PayYear as varchar(4))                            
select @PrevMonth = @PrevMonth +', '+ cast(@StartYear as varchar(4))           
          
Select @PrevPensionNo = 0,@PrevPensionbNo = 0          
                            
select @PrevPension = Sum(Gross + Arrears),@PrevPensionNo = count(*) from PensionPayroll                             
where SchemeNo = @SchemeNo and PayMonth = @StartMonth and PayYear = @StartYear and (Gross + Arrears) > 0                          
                            
select @PrevPensionb = Sum(Gross + Arrears),@PrevPensionbNo = count(*) from PensionPayrollBen                            
where SchemeNo = @SchemeNo and PayMonth = @StartMonth and PayYear = @StartYear and (Gross + Arrears) > 0           
          
if @PrevPensionNo is null Select @PrevPensionNo = 0          
if @PrevPensionbNo is null Select @PrevPensionbNo = 0          
          
Select @PrevPensionNo = @PrevPensionNo + @PrevPensionbNo                         
                                              
select @NewEntrants = 0                            
select @Increase = 0                            
select @exits =0                            
select @NetIncrease = 0                            
select @Decrease = 0                            
select @NetDecrease= 0                            
          
Select @PrevsuspensionNo = 0,@suspensionNo = 0,@suspensionbNo = 0,@PrevsuspensionBNo = 0          
    
/*                   
select @suspension = Sum(Net),@suspensionNo = count(*) from PensionPayroll                             
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and Hold = 0 and Gross > 0                    
and memberno in (select memberno from pensionstoppage where SchemeNo = @SchemeNo and StopMonth = @PayMonth and StopYear = @payYear)                           
                            
if @suspension is null select @suspension = 0                            
if @suspensionNo is null select @suspensionNo = 0          
                            
select @suspensionB = Sum(Net),@suspensionbNo = count(*) from PensionPayrollBen                            
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and Hold = 0 and Gross > 0                        
and memberno in (select memberno from pensionstoppage where SchemeNo = @SchemeNo and StopMonth = @PayMonth and StopYear = @payYear)                          
                            
if @suspensionB is null select @suspensionB = 0                       
if @suspensionbNo is null select @suspensionbNo = 0          
          
Select @suspensionNo = @suspensionNo + @suspensionbNo          
                      
select @Prevsuspension = Sum(Net),@PrevsuspensionNo = count(*) from PensionPayroll                             
where SchemeNo = @SchemeNo and PayMonth = @StartMonth and PayYear = @StartYear and Hold = 0 and Gross > 0                        
and memberno not in (select memberno from pensionstoppage where SchemeNo = @SchemeNo and StopMonth = @PayMonth and StopYear = @payYear)                           
                            
if @Prevsuspension is null select @Prevsuspension = 0          
if @PrevsuspensionNo is null select @PrevsuspensionNo = 0          
                            
select @PrevsuspensionB = Sum(Net),@PrevsuspensionBNo = count(*) from PensionPayrollBen                            
where SchemeNo = @SchemeNo and PayMonth = @StartMonth and PayYear = @StartYear and Hold = 0  and Gross > 0                      
and memberno not in (select memberno from pensionstoppage where SchemeNo = @SchemeNo and StopMonth = @PayMonth and StopYear = @payYear)                            
                            
if @PrevsuspensionB is null select @PrevsuspensionB = 0                      
if @PrevsuspensionBNo is null select @PrevsuspensionBNo = 0     
    
*/ 

select @Arrears = Sum(Arrears)from PensionPayroll                             
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and Hold = 1 and (Gross + Arrears) > 0    
    
select @suspension = Sum(Net + Arrears),@suspensionNo = count(*) from PensionPayroll                             
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and Hold = 0 and (Gross + Arrears) > 0                    
                            
if @suspension is null select @suspension = 0                            
if @suspensionNo is null select @suspensionNo = 0          
                            
select @suspensionB = Sum(Net + Arrears),@suspensionbNo = count(*) from PensionPayrollBen                            
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and Hold = 0 and (Gross + Arrears) > 0                        
                           
if @suspensionB is null select @suspensionB = 0                       
if @suspensionbNo is null select @suspensionbNo = 0          
          
Select @suspensionNo = @suspensionNo + @suspensionbNo          
                      
                        
if @Prevsuspension is null select @Prevsuspension = 0          
if @PrevsuspensionNo is null select @PrevsuspensionNo = 0          
                            
                        
if @PrevsuspensionB is null select @PrevsuspensionB = 0                      
if @PrevsuspensionBNo is null select @PrevsuspensionBNo = 0     
-----------------------         
          
select @PrevsuspensionNo = @PrevsuspensionNo + @PrevsuspensionBNo          
                           
                            
select @Attachments = Sum(Attachment) from AttachmentPayroll                             
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and Attachment > 0                           
                            
if @Attachments is null select @Attachments = 0                         
                            
select @Deductions = Sum(Amount),@DeductionsNo = count(*) from MemberDeductionsPayment                             
where SchemeNo = @SchemeNo and DeductMonth = @PayMonth and DeductYear = @payYear and Amount > 0                            
                            
if @Deductions is null select @Deductions = 0                            
                            
select @DeductionsB = Sum(Tax),@DeductionsBNo = count(*) from pensionPayrollBen                             
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and (Gross + Arrears) > 0 and Tax > 0                           
                            
if @DeductionsB is null select @DeductionsB = 0           
if @DeductionsNo is null Select @DeductionsNo = 0                           
if @DeductionsBNo is null Select @DeductionsBNo = 0          
          
Select @DeductionsNo = @DeductionsNo + @DeductionsBNo          
                            
select @curPension = Sum(Gross + Arrears),@Paye = sum(Tax)  from PensionPayroll                             
where SchemeNo = @SchemeNo and PayMonth = @PayMonth and PayYear = @payYear and (Gross + Arrears) > 0                            
                            
if @Attachments is null select @Attachments = 0                            
                            
if @Deductions is null select @Deductions = 0                            
                            
if @Paye is null select @Paye = 0                               
select @Deductions = @Deductions + @Paye + @Attachments + @DeductionsB                            
                            
/********************* New Entrants */                            
                   
Exec PayrollDecrease1 @SchemeNo,@PayMonth,@PayYear                            
Exec PayrollEntrants1 @SchemeNo,@PayMonth,@PayYear                            
Exec PayrollExits1 @SchemeNo,@PayMonth,@PayYear                            
Exec PayrollIncrease1 @SchemeNo,@PayMonth,@PayYear           
                           
Select @NewEntrantsNo = 0,@IncreaseNo = 0,@DecreaseNo = 0,@ExitsNo = 0          
                            
Select @NewEntrants = sum(Gross),@NewEntrantsNo = count(*) from ##Currentx          
If @NewEntrantsNo is null Select @NewEntrantsNo = 0          
                            
Select @Exits = sum(Gross),@ExitsNo = count(*) from ##PreviousE                            
If @ExitsNo is null Select @ExitsNo = 0          
                            
Select @Increase =  sum(Diff),@IncreaseNo = count(*) from ##Increase                            
If @IncreaseNo is null Select @IncreaseNo = 0          
                            
Select @Decrease = sum(Diff),@DecreaseNo = count(*) from ##Decrease                   
If @DecreaseNo is null Select @DecreaseNo = 0          
                  
Select @Decrease = @Decrease                           
                            
if @NewEntrants is null select @NewEntrants = 0                            
if @NewEntrantsB is null select @NewEntrantsB = 0                            
                            
if @Exits is null select @Exits = 0                            
if @Decrease is null select @Decrease = 0                            
if @Exitsb is null select @Exitsb = 0                            
if @Decreaseb is null select @Decreaseb = 0                       
if @Increase is null select @Increase = 0                            
if @IncreaseB is null select @IncreaseB = 0                            
                            
declare @xTotal float                            
                            
IF @PrevPension IS NULL select @PrevPension = 0                            
IF @PrevPensionB IS NULL select @PrevPensionB = 0                            
IF @NewEntrants IS NULL select @NewEntrants = 0                            
IF @Increase IS NULL select @Increase = 0                            
IF @Exits IS NULL select @Exits = 0                            
IF @Decrease IS NULL select @Decrease = 0                            
                            
select @xTotal =  (@PrevPension + @PrevPensionB + @NewEntrants + @Increase + @Arrears) - (@Exits  + @Decrease)                            
                            
insert Into ##ReconciliationAll(schemeName, PrevPension, CurPension, NewEntrants,Increase,Decrease, Exits,Total, Period, PrevPeriod, Suspension,                      
  Prevsuspension, Deductions,Net,PrevPensionNo,CurPensionNo,NewEntrantsNo,IncreaseNo,DecreaseNo,ExitsNo,PrevsuspensionNo,          
             SuspensionNo,DeductionsNo,Arrears)          
               Values (@SchemeName, @PrevPension + @PrevPensionB, @xTotaL, @NewEntrants + @NewEntrantsB,                             
                     @Increase + @IncreaseB, @Decrease + @DecreaseB, @Exits + @ExitsB,  @xTotal , @MonthName, @PrevMonth, @suspension + @suspensionb,                      
                @PrevsuspensionB + @Prevsuspension, @Deductions, @xTotal - (@suspension + @suspensionb + @Deductions + @PrevsuspensionB + @Prevsuspension),          
  @PrevPensionNo,@CurPensionNo,@NewEntrantsNo,@IncreaseNo,@DecreaseNo,@ExitsNo,@PrevsuspensionNo,          
             @SuspensionNo,@DeductionsNo,@Arrears)                            
                            
select * from ##ReconciliationAll
go

