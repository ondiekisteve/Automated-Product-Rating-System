











CREATE PROCEDURE Proc_Roll_Back_Interface
@Pending_Counter Int
--with Encryption
as
Delete from TBL_Pending_Posting where Pending_Counter = @Pending_Counter


go

