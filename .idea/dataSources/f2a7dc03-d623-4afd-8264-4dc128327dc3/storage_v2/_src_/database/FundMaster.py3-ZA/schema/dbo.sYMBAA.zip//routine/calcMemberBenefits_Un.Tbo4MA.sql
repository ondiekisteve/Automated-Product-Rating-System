CREATE PROCEDURE [dbo].[calcMemberBenefits_Un]              
@SCHEMENO Int,              
@MemberNo Int,              
@CurMonth int,              
@curyear int,              
@IntMode Int              
--with Encryption              
as              
declare @totEmp float              
declare @totEmpr float              
declare @totVol float              
declare @totSpecial float              
declare @CalculationMode int,@EmpInterest float,@EmprInterest float,@VolInterest float,@SpecInterest float,@hasBal bit,              
@Calc_Status smallInt,@DeferredAmt float,@DefInterest float              
            
select @DeferredAmt =0,@DefInterest =0            
begin Tran              
              
select @Calc_Status = 0 /* Like Year End */              
              
declare @funcResult int, @currYear int, @yearClosed bit, @retCode int, @AcctPeriod int, @PeriodtoUse int              
              
exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out              
              
Select @PeriodToUse = @AcctPeriod - 1              
              
select @CalculationMode = CalculationMode from Scheme where schemeCode = @schemeNo              
              
select @HasBal = 0               
              
if exists(select * from UnregisteredBalances where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @PeriodToUse) select @hasBal = 1 else select @hasBal = 0              
              
 if @CalculationMode = 1              
         exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output              
 else if @CalculationMode = 0              
          exec Proc_CalcMonthlyInterestSI_Un   @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output, @totSpecial output              
 else if @CalculationMode = 2              
         exec Proc_CalcMonthlyInterestAVG_Un @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output              
 else if @CalculationMode = 4              
         exec Proc_CalcMonthlyInterestAVGComp_Un 0,@schemeNo, @memberNo, @curMonth, @curYear, @hasBal,@IntMode, @totEmp output, @totEmpr output , @totVol output ,@totSpecial output,              
         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out,@DeferredAmt Out,@DefInterest out             
 else if @CalculationMode = 5              
         exec Proc_CalcMonthlyInterestAVGComp_SI_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,              
         @EmpInterest Out,@EmprInterest Out,@VolInterest Out,@SpecInterest Out              
 else if @CalculationMode =  6              
          exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output              
 else if @CalculationMode = 7              
        exec Proc_CalcMonthlyInterestSI_NonProUn @schemeNo, @memberNo, @curMonth, @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output , @totVol output ,@totSpecial output              
 else if @CalculationMode = 11              
         exec Proc_CalcMonthlyInterest_UnMonthDep @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output              
 else if @CalculationMode = 9              
         exec Proc_CalcMonthlyInterest_Un_Daily @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@Calc_Status,@totEmp output, @totEmpr output, @totVol output, @totSpecial output              
 else if @CalculationMode = 13             
         exec Proc_CalcMonthlyInterest_Daily_Mon_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@Calc_Status,@totEmp output, @totEmpr output, @totVol output, @totSpecial output,@DeferredAmt output              
else              
         exec Proc_CalcMonthlyInterest_Un @schemeNo, @memberNo, @CurMonth,  @curYear, @hasBal, @IntMode,@totEmp output, @totEmpr output, @totVol output, @totSpecial output              
               
if @EmpInterest is null select @EmpInterest = 0              
if @EmprInterest is null select @EmprInterest = 0              
if @VolInterest is null select @VolInterest = 0              
if @SpecInterest is null select @SpecInterest = 0             
if @DeferredAmt is null select @DeferredAmt = 0              
if @DefInterest is null select @DefInterest = 0               
              
    begin     
      if not Exists(select MemberNo from UnRegisteredBenefits where(SchemeNo = @schemeNo) and(MemberNo = @memberNo))                            
      insert into UnRegisteredBenefits              
      (SchemeNo, MemberNo, ExcessEmpCont, ExcessEmprCont, ExcessVolContr, ExcessSpecial, schemeYear,              
            EmpInt,EmprInt,VolInt,SpecInt,DeferredAmt,DefInterest)              
     values              
      (@schemeNo, @memberNo, @totEmp, @totEmpr, @totVol, @totSpecial, datepart(year,getdate()),              
            @EmpInterest,@EmprInterest,@VolInterest,@SpecInterest,@DeferredAmt,@DefInterest)              
       else              
           update UnRegisteredBenefits set ExcessEmpCont = @totEmp,              
                  ExcessEmprCont = @totEmpr, ExcessSpecial = @totSpecial,              
                  ExcessVolContr = @totVol,EmpInt = @EmpInterest,EmprInt  =@EmprInterest,              
                  VolInt =  @VolInterest,SpecInt = @SpecInterest,DeferredAmt = @DeferredAmt ,DefInterest =  @DefInterest             
           where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)              
          
       /* Added on 26/11/2008 */    
       Exec dbo.CalculateCorpTaxYearEnd @SchemeNo,@MemberNo,@CurMonth,@CurYear         
    end              
                   
     select @TotEmp = 0              
     select @totEmpr =0              
     select @totVol = 0              
     select @totSpecial = 0              
commit Tran
go

