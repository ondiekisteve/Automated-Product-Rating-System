CREATE VIEW [dbo].[ReceiptsRecList]        
--with Encryption        
as        
select r.schemeNo,r.Receipt,r.TransNo,r.ReceiptDate,r.Amount,r.Posted,r.ChequeNo,r.RecCounter,r.CreditAcc,  
r.BankCode,r.IncomeCode,b.BankName,i.IncomeDesc        
from ReceiptsRec r  
     Inner Join SchemeBankBranch b on r.schemeNo = b.schemeNo and r.BankCode = b.BankCode  
     Inner Join IncomeItems i on r.IncomeCode = i.IncomeCode
go

