





CREATE VIEW  dbo.InvestmentGridRet
--with encryption
AS
SELECT i.SchemeNo, i.InvCode, i.InvName, i.InvestClass, 
    i.initvalue, i.simCode, iv.investdesc AS investment, 
    ivd.investdesc AS investmentdetail,i.DateComm
FROM Investments i INNER JOIN
    investmenttypes iv ON 
    iv.investcode = i.investcode INNER JOIN
    InvestmentTypedetail ivd ON 
    ivd.investcode = i.investcode AND 
    ivd.investtypecode = i.investcodedetail
WHERE i.InvStatus = 1 and I.status = 0


go

