CREATE TRIGGER [dbo].[Trg_UpdateUnitStatus] ON [dbo].[Tenants] 
FOR INSERT
AS

declare @schemeNo int,@PropCode Int,@UnitNo Int

select @schemeNo = SchemeNo,@PropCode = PropertyCode,@UnitNo = UnitCode
from inserted

update Units set UnitStatus = 1
where schemeNo = @schemeNo and PropertyCode = @PropCode and UnitCode = @UnitNo
go

