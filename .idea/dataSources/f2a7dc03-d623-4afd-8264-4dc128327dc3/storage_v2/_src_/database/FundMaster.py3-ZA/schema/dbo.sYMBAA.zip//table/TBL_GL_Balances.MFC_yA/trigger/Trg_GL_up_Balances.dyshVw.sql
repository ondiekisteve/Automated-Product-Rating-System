CREATE TRIGGER [dbo].[Trg_GL_up_Balances] ON [dbo].[TBL_GL_Balances]     
FOR UPDATE,DELETE    
AS    
    
set nocount on    
    
declare @schemeCode int, @TransDate datetime, @CStatus smallint,@BalanceCode int,@BatchId int    
    
select @schemeCode = SchemeCode, @TransDate = PeriodEnding from deleted   
  
select @CStatus = PeriodClosed   
from AccountingPeriods   
where schemeNo = @schemeCode and EndDate = @TransDate  

 
if @CStatus >= 1          
begin          
  raiserror('You cannot update/delete! The Accounting Period for the Transaction has already been closed',16,1)          
  rollBack Tran        
end             
else    
    begin    
      begin tran        
            insert into TBL_GL_Balance_Batches(BatchDate,SchemeCode,PeriodEnding,UserName)        
                                   Values(GetDate(),@SchemeCode,@TransDate,user)        
       
        
      select @BatchId = Max(BatchId) from TBL_GL_Balance_Batches    
    
    
      Insert into TBL_GL_Balances_BCK (SchemeNo,AccountCode,PeriodEnding,DebitBalance,CreditBalance,FirstLevel,    
                                       Parent_Level_Code,Child_Level_Code,Parent_Level_Code1,Child_Level_Code1,SchemeCode,SponsorCode,    
                                       BalanceCode,SpotRate,CurrCode,tr_DebitBalance,tr_CreditBalance,BatchId)    
                  Select SchemeNo,AccountCode,PeriodEnding,DebitBalance,CreditBalance,FirstLevel,    
                                       Parent_Level_Code,Child_Level_Code,Parent_Level_Code1,Child_Level_Code1,SchemeCode,SponsorCode,    
                                       BalanceCode,SpotRate,CurrCode,tr_DebitBalance,tr_CreditBalance,@BatchId    
                  from deleted    
      commit tran     
   end
go

