CREATE PROCEDURE [dbo].[GetCreditsDirectPayment]  
@SCHEMENO Int,  
@PaymentNo int  
--with Encryption  
as  
  
if object_id('tempdb..#CreditDirectPayment') is null  
  
begin  
create table #CreditDirectPayment  
(  
 [glcode] [int] IDENTITY(1,1) NOT NULL Primary Key ,  
 [glDesc] [varchar](100) NOT NULL ,  
 [glCredit] [Decimal](12,2) not  NULL default 0.0,  
 [glTotal] [Decimal](12,2) null default 0.0,  
 [glMax][int] not null      
)   
   
end  
  
declare @Descr varchar(120),@Amount decimal(20,2),@YaConversion Varchar(25),@Chapaa decimal(20,2),  
@VAT decimal(20,2),@Withholding decimal(20,2),@DeductionMode smallInt  
  
Select @Descr = PaymentDesc,@VAT = Vat,@Withholding = Withholding,@DeductionMode  = DeductionMode   
from DirectPayment where SchemeNo = @schemeNo and PaymentNo = @PaymentNo  
  
if @VAT is NULL select @VAT = 0  
if @Withholding is NULL select @Withholding = 0  
if @DeductionMode is NULL select @DeductionMode = 0  
  
select @Amount = sum(InvoiceAmount) from DirectPaymentInvoice   
where SchemeNo = @schemeNo and PaymentNo = @PaymentNo  
  
/*  
      if @VAT > 0  
         BEGIN  
         select @YaConversion = cast(@VAT as Varchar(25))  
         Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out  
              select @VAT = @Chapaa  
  
            Insert Into #CreditDirectPayment (glDesc, glCredit,glMax)  
               Values ('V.A.T',@VAT, 0)   
         END  
 */    
      if @Withholding > 0  
         BEGIN  
         select @YaConversion = cast(@Withholding as Varchar(25))  
         Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out  
              select @Withholding = @Chapaa  
  
  
         Insert Into #CreditDirectPayment (glDesc, glCredit,glMax)  
               Values ('Withholding Tax',@Withholding, 0)   
         END  
  
  
  
select @YaConversion = cast(@Amount as Varchar(25))  
Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out  
              select @Amount = @Chapaa  
              select @Chapaa = 0  
  
               select @Amount = @Amount - @Withholding  
  
               Insert Into #CreditDirectPayment (glDesc, glCredit,glMax)  
               Values (@Descr,@Amount, 1)     
              
declare @Total decimal(20,2)  
select @Total = sum(glCredit) from #CreditDirectPayment  
  
update #CreditDirectPayment set glTotal = @Total  
  
select * from #CreditDirectPayment
go

