/*                                                                                            
MODIFICATIONS:                                                                                            
11/03/2004                                                                                            
                                                                                            
Added :                                                                                            
           Fields:                                                                                            
           PreparedBy,CheckedBy,AuthorisedBy                                                                                            
           Variables:                                                                                            
           @PreparedBy,@CheckedBy,@AuthorisedBy                                                                                            
           Code:                                                                                            
           select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                                      

  
    
      
           Insert these extra fields in the Temp Table                                                                                            
*/                                                                                            
                                                                                            
CREATE PROCEDURE [dbo].[RepCalculationSheet]                                                                                            
@SCHEMENO Int,                                                                                            
@memberNo int,                                                                                            
@Mode Int, /* 0 Normal Registered, 1 - Registered Combined, 2 - Projections, 3 - Post 90 Combined, 4 - Pre90 Combined,                                                          
                                   5 - Cummulative, 6 - Registered AVC */                                                                                            
@batch_id int,                                                                                            
@report_mode int,      
@Ben_Counter Int /* Used to Pick the actual Benefit in TBL_Benefit_DC */                                                                                            
--@PrintMode Int                                                                                            
--with Encryption                                                                                            
as                                                                                            
                                                                                            
set nocount on                                                                                            
                                                                                            
if object_id('tempdb..#Calculation') is null                                                                                            
                                                                                            
begin                                                                                            
create table #Calculation                                                                                            
(                                                                                            
    [Counter][Int] identity(1,1) Primary Key,                        
    [SchemeNo] [Int] NOT NULL ,                                                                     
    [MemberNo] [varchar](50) NOT NULL ,           
    MemberNoDesc varchar(100),                                                                                            
           [schemeName][varchar](100) not null,                                    
    [IDNumber][varchar](20) null,                                          
    [PayrollNo][varchar](20) null,                                                                                 
    [fullname][varchar](100) not null,                                                 
           [DJE][Datetime] null,                                                                                  
           [djpens][datetime] not null,                              
    [EmpOpeningBal] [Decimal](20,2) NULL ,                                                           
                [EmprOpeningBal][Decimal] (20,2) NULL,                                                                                             
    [EmpContributions] [Decimal] (20,2)  NULL ,                                 
                [EmprContributions] [Decimal] (20,2)  NULL ,                                                                 
                [EmpClosing][Decimal] (20,2) Not null,                                                                                       
                [EmprClosing][Decimal] (20,2) Not null,                                                                                            
                [interest] [Decimal] (20,2)  NULL ,                                                                                            
                [DateOfExit][datetime] not null,                                                                                            
    [curYear] [int] NULL ,                                                             
    [PastService] [Varchar](100) not NULL,                                                      
                [BenefitsDC] [Decimal] (20,2),                                                                                            
                  [Vesting][Decimal] (20,2)null,                                                                                            
   [TaxfreeLumpsum][Decimal] (20,2),                                                                                            
                [WithHoldingTax][Decimal] (20,2),                                                                                            
                [comments][varchar](200) null,                                                                        
                [empInt][Decimal] (20,2) not null,                                                                                            
                [emprInt][Decimal] (20,2) not null,                                                                                            
                [AmountPayable][Decimal] (20,2)  null,                                                                                 
                [TaxableAmount][Decimal] (20,2) not null,                                                                                            
                [Reason][Varchar](50) null,                                                                                    
                [EndDate][Datetime] NULL,                                                                                            
                [PreparedBy][varchar](100) NULL,                                                                                            
                [CheckedBy][varchar](100) NULL,                                                                              
                [AuthorisedBy][varchar](100) NULL,             
                [ClosingBalance][Decimal] (20,2) NULL,                                          
                [Bonus][Decimal] (20,2) NULL,                                       
                [TransferCBal][decimal](20,2) NULL,                                                                              
                [TransferOpBal][decimal](20,2) NULL,                                                                                        
                [TransferCont][decimal](20,2) NULL,                                         
                [TransferInt][decimal](20,2) NULL,                                              
                [TransferDesc][Varchar](20) NULL,                                           
                [AdditionDesc][Varchar](50) NULL,                                    
                [DoCalc][Datetime] NULL,                                                 
                [VestedCont][float] NULL,                           
                [AuditedBy][Varchar](100) NULL,                                                                                            
                [DateAudited][Datetime] NULL,                                                                                    
                [doBirth][Datetime] NULL,                                                                                            
                                                                       
                [TransferCBalE][decimal](20,2) NULL,                               
                [TransferOpBalE][decimal](20,2) NULL,                                                                                            
                [TransferContE][decimal](20,2) NULL,                                                                                            
                [TransferIntE][decimal](20,2) NULL,                                                                                            
                [LockedTransfer][decimal](20,2) NULL,                                                                                      
                [DatePrepared][Datetime] NULL,                                                                                            
                [DateChecked][Datetime] NULL,                                                                                            
                [DateAuthorised][Datetime] NULL,                                                              
                [LockedInTransfer][Decimal](20,2) NULL,                                                                                            
                [Loan][Decimal](20,2), /* Added on 10/5/2006 at 5.46 a.m to Cater for TZ Market */                                                                                            
                [LoanRepaid][Decimal](20,2),                                                                   
                [LoanBalance][Decimal](20,2),                                                                                            
                [OtherDeductions][Decimal](20,2),                                                   
                [NetBalance][Decimal](20,2),                                                                                            
                [Sponsor][Varchar](100),                                                                                        
                [ReportTitle][Varchar](100),                                                                                          
                [EmpTotal][decimal](20,2),                                                                            
                [EmprTotal][decimal](20,2),                                                                                          
                [EmpTax][decimal](20,2), 
                [EmprTax][decimal](20,2),                                                                                          
              [Deductions][Decimal](20,2) ,                                                                                            
                [PoolName][varchar](120)  null,                                    
                CurDay int,                                    
                CurMonth varchar(20),                                    
                CurYear1 int,                                
                ContPeriod varchar(100),                            
                DocRefNo varchar(100),        
                Salary float,        
                SalFactor float,        
                Gratuity float,        
                TotalBenefit float         
)                                                                                             
end                                                                                            
declare @fullname varchar(100),@schemeName varchar(100),@empopening Decimal(20,6),@emprOpening Decimal(20,6),                           
@empContribution Decimal(20,6),@emprContribution Decimal(20,6),@empClosing Decimal(20,6),@emprClosing Decimal(20,6),                                                              
@interest Decimal(20,6),@DateOfExit datetime,@pastService int,@BenefitsDC Decimal(20,6),@vesting Decimal(20,6),                                                                                            
@taxfreelumpsum Decimal(20,6),@withHoldingTax Decimal(20,6),@dje datetime,@djpens datetime,@curYear int,                                                                                            
@comments varchar(200),@VestedCont Decimal(20,6),@EmpInt Decimal(20,6),@Emprint Decimal(20,6),@GrandTotal Decimal(20,6)                                                                                    
,@TaxAmount Decimal(20,6),@Doexit datetime,@CurMonth int,@AcctPeriod int,  @eDate datetime, @sDate datetime, @DoCalc datetime, @sMonth int, @datePaid datetime                                                                
,@Year int, @Month int, @Days int,@Reason Varchar(50), @rExit Int,@EndDate Datetime,@taxType Int,@DesignCode Int,@Title varchar(20),                                                                                            
@PreparedBy varchar(100),@CheckedBy varchar(100),@AuthorisedBy varchar(100),@Bonus Decimal(20,6),@ClosingBalance Decimal(20,6),                                     
@NumDays Int,@NumMonths Int,@NumYears Int,@ServiceTime Varchar(100),@TransferCBal Decimal(20,6),                                                                                            
@TransferOpBal Decimal(20,6),@TransferInt Decimal(20,6),@TransferDesc varchar(20),                                                                                     
@AdditionDesc varchar(50),@DeductNSSF smallInt,@ConversionDate Datetime,@NSSF2Deduct float,@MwishoDate Datetime,                                                                                   
@mMonth Int,@mYear Int,@YaConversion varchar(25),@Chapaa Decimal(20,6),@Pre90 FLOAT,                                                                                            
@TransferCont Decimal(20,6),@TransferSeparate bit,@HasFrozen smallInt,@FrozenDate Datetime,                                                                                            
@OptionToUSe Int,@AuditedBy vARCHAR(100),@DateAudited Datetime,@ActiveStatus Int,@DoBirth Datetime,                                                                               
@BenefitMode Int,@ArEmpCont float,@ArEmprCont float,                                                                                    
@TransferCBalE Decimal(20,6),@TransferOpBalE Decimal(20,6),@TransferIntE Decimal(20,6),@TransferContE Decimal(20,6),                          
@LockedTransfer Decimal(20,6),@DatePrepared Datetime,@DateChecked Datetime,@DateAuthorised Datetime,                           
@LockedInTransfer Decimal(20,6),@IDNumber varchar(20),@PooledInvestment smallInt,@InvestmentScheme Int,@PoolName varchar(120),                              
/* TZ */                  @Loan float,@LoanRepaid float,@LoanBalance float,@NetBalance float,@SchemeMode smallInt,@Sponsor Varchar(100),                                          
@SponsorCode Int,@OtherDeductions float,@gepf int,@ReportTitle VARCHAR(100),@Zambia smallInt,                                                                            
@TaxRateDiff smallint,@TaxRet smallint,@TaxPension smallint,@TaxWith smallint,@TaxDeath smallint,@TaxMedical smallint,                    
@Employee float,@Employer float,@TaxEmployee float,@TaxEmployer float,@DeferredPaid smallInt,@TelPosta smallInt,@mukuba smallint,                                                      
@PayrollNo varchar(20),@TransType Int,@ExitReason Int,@MemberNoDesc varchar(100),@Mining smallint,                                          
@MembNoToUse varchar(50),@sStartDate varchar(20),@sEndDate varchar(20),@ContPeriod varchar(100),@DocRefNo varchar(100),                        
@EeRate float,@ErRate float,@QualifyPeriod int,@FundType Int,/* Added in Mauritius */ @EmpExpenses float,@EmprExpenses float,@Salary float,        
@SalFactor float,@Gratuity float,@PayGreater float,@TotalBenefit float,@OrigBen_Counter Int          
        
select @Salary = 0,@SalFactor=0,@Gratuity=0          
        
select @PayGreater = PayGreater,@SalFactor = SalaryFactor         
from ConfigDeathInService where schemeNo = @schemeNo           
if @PayGreater is null select @PayGreater = 0          
if @SalFactor is null select @SalFactor = 0                               
                                                                                                                                                                             
select @LockedTransfer = 0.0                                                                                     
                                                                                            
Select @BenefitMode = BenefitMode from DeathClaim where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                                            
                     
if @BenefitMode is null select @BenefitMode = 0                                                                                            
                                                                                            
select @HasFrozen = HasFrozen,@FrozenDate  = FrozenDate,@schemeMode = SchemeMode,@Gepf = GEPF,@Zambia = Zambia,                                                                                          
@TaxRateDiff=TaxRateDiff,@TaxRet=TaxRet,                                                                                          
@TaxPension=TaxPension,@TaxWith = TaxWith,@TaxDeath = TaxDeath ,@TaxMedical = TaxMedical,                                                                            
@PooledInvestment = PooledInvestment,@InvestmentScheme = InvestmentScheme                                                                                          
from Scheme where schemeCode = @schemeNo                                                                                            
                                                                      
select @TelPosta = TelPosta,@mukuba = mukuba,@Mining = Mining,@FundType = FundTypeCode from scheme where schemeCode = @schemeNo                                                             
                                                            
if @mukuba is null select @Mukuba = 0                                           
if @Mining is null select @Mining = 0                         
if @FundType is null select @FundType = 0                                         
                                          
if @Mining = 0                                          
   select @MemberNoDesc = 'Member Number'                                          
else                                          
   select @MemberNoDesc = 'Mine Number'                                                           
                  
if ((@Mukuba = 1) and (@Mode = 0)) select @Mode = 1                                                                     
                                                                       
if @PooledInvestment = 1                                                                    
select @PoolName = schemeNAME FROM Scheme where schemeCode = @InvestmentScheme                                                                                      
else if @PooledInvestment = 0                                                                                      
select @PoolName = ' '                                                                            
       
if @Ben_Counter is null select @Ben_Counter = 0       
      
select @OrigBen_Counter = @Ben_Counter      
                                                
if @HasFrozen is null select @HasFrozen = 0                                                                                            
IF @Gepf is null select @Gepf = 0                                                                                           
if @Zambia is null select @Zambia = 0                                        
                                                                                          
if @TaxRateDiff is null select @TaxRateDiff = 0                                                                                          
if @TaxRet is null select @TaxRet = 0             
if @TaxPension is null select @TaxPension = 0                                                   
                                                                                          
if @TaxWith is null select @TaxWith = 0                                        
if @TaxDeath is null select @TaxDeath = 0                                                                                          
if @TaxMedical is null select @TaxMedical = 0                           
                                                                                            
select @DeductNSSF = DeductNSSF,@ConversionDate= ConversionDate,                                                                                            
@TransferSeparate = TransferSeparate                                                                                
from ConfigWithdrawal where SchemeNo = @schemeNo                                                                                            
                                                                                            
if @DeductNSSF is null select @DeductNSSF = 0                                                                                            
if @TransferSeparate is null select @TransferSeparate = 0                                       
      
                                                  
select @ExitReason = ReasonforExit from Members where schemeNo = @schemeNo and MemberNo = @MemberNo      
                                                 
                                                  
/* Temporary solution for Eagle Africa - Death Claims - Pay AVC as a Lumpsum */                
/*                                                  
if ((@SchemeNo = 1334) and (@ExitReason = 1))                                            
   select @Mode = 6                
*/                                                                                             
                                                                                            
if @Report_Mode = 0                                                     
   declare MemberCsr Cursor for                                                                                         
   Select MemberNo,@Ben_Counter from Members where schemeNo = @schemeNo and MemberNo = @MemberNo                                                                      
else if @Report_Mode = 1                                                                                            
   declare MemberCsr Cursor for                           
   Select MemberNo,Ben_Counter from TBL_BATCH_MOVEMENTS_DET                                               
   where schemeNo = @schemeNo and batch_Id = @Batch_Id                                        
Open MemberCsr                                      
fetch from MemberCsr into @memberNo,@Ben_Counter                                                                                            
while @@fetch_Status = 0                                                        
begin       
                                                                                           
if @DeductNSSF = 1                                                                                            
   SELECT @NSSF2Deduct = sum(nssfe) from Contributionssummary where                                   
   SchemeNo = @schemeNo and MemberNo = @MemberNo and DatePaid <= @ConversionDate                                                                                            
                                                                                            
if @NSSF2Deduct is null select @NSSF2Deduct = 0.0                                                                                            
                                                                            
                                                                                            
if @DeductNSSF = 1                                                                                        
   select @AdditionDesc = 'Less: NSSF (Employer) at Conversion Date'                                                               
else                                                                                            
   select @AdditionDesc = 'Additional Benefit'                                                                          
                                                
select @TransferDesc = 'Trans Values'                                                                                            
                                                                                                                           
select @schemeName = schemeName from scheme where schemeCode = @schemeNo                                                                                            
                                                                                                                                                           
if @Mode = 0 /* Normal Registered */                                                                                            
begin                                             
declare GenCursor cursor for                                                                                            
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,(Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,                                                                                            
       m.IDNumber,b.calcYear, b.interestrate, b.empCBal + b.PreEmpCBal, b.emprCBal + B.PreEmprCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting, m.comments,                                                                                            
             (b.EmprCBal + b.PreEmprCBal)* (b.Vesting/100.0000),b.Bonus,                                                                                            
                         b.EmpTransferCBal,b.EmprTransferCBal + b.DeferredCBal,B.PreEmpCBal + B.PreEmprCBal,                                                                                            
                    m.ActiveStatus,m.DeferredPaid,m.PayrollNo,m.DocRefNo,b.TransType                                                                                            
    from Members m                                                                                            
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                              
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                                                                            
end                                               
else if @Mode = 1 /* Registered Combined */                                                                                            
begin                                                                         
declare GenCursor cursor for                                                                                            
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                  
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,m.IDNumber,                                                                                      
              b.calcYear, b.interestrate, b.empCBal + b.VolCBal + b.PreEmpCBal+ b.PreAVCCBal,                                                                                             
                         b.emprCBal + b.SpecialCBal + PreEmprCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting,                                                                                        
                         m.comments,(b.EmprCBal + b.SpecialCBal + b.PreEmprCBal)* (b.Vesting/100.000),                                   
                         b.Bonus,b.EmpTransferCBal,b.EmprTransferCBal + b.DeferredCBal,B.PreEmpCBal + B.PreEmprCBal + B.PreAVCCBal,                                                                                            
                         m.ActiveStatus,m.DeferredPaid,m.PayrollNo,m.DocRefNo,b.TransType                                                                                       
             from Members m                                                                                       
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                                                                                                                           

  
    
                     
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                
end                                                                                            
                                                                                            
else if @Mode = 2 /* Registered Combined Projections*/                                                                                            
begin                                                                                            
declare GenCursor cursor for                                                                                  
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.Projectdoexit,                                                                                             
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,m.IDNumber,                                                                                            
               b.calcYear, b.interestrate, b.empCBal + b.VolCBal + b.PreEmpCBal+ b.PreAVCCBal,                                                                                             
                         b.emprCBal + b.SpecialCBal + PreEmprCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting,                                                                                             
                         m.comments,(b.EmprCBal + b.SpecialCBal + b.PreEmprCBal)* (b.Vesting/100.00),                                                                                            
 b.Bonus,b.EmpTransferCBal,b.EmprTransferCBal+ b.DeferredCBal,B.PreEmpCBal + B.PreEmprCBal + B.PreAVCCBal,                                                                                            
                         m.ActiveStatus,m.DeferredPaid,m.PayrollNo,m.DocRefNo,b.TransType                                                              
             from Members m                                                                                          
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                                                                                                                            

  
    
                     
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                         
                                                                                                   
end                                                                                            
else if @Mode = 3 /* POST 90 - Combined */                                                                            
begin                                                                                            
declare GenCursor cursor for                                
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                                                                             
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,m.IDNumber,                                                               
               b.calcYear, b.interestrate, b.empCBal + b.VolCBal,                                                                                             
                         b.emprCBal + b.SpecialCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting,                                                                
          m.comments,(b.EmprCBal + b.SpecialCBal )* (b.Vesting/100.000),                                                                                            
                         b.Bonus,b.EmpTransferCBal,b.EmprTransferCBal+ b.DeferredCBal,0.0,                                                                                            
                         m.ActiveStatus,m.DeferredPaid,m.PayrollNo,m.DocRefNo,b.TransType                                    
             from Members m                                                                                            
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                                                            
                                                                                                                
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                                                                            
end                                                                                     
else if @Mode = 4 /* PRE 90 Combined */                              
begin                                                                       
declare GenCursor cursor for                                                                                            
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                                                                   
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,m.IDNumber,                                                                                            
               b.calcYear, b.interestrate, b.PreEmpCBal+ b.PreAVCCBal,                                                                                             
                         PreEmprCBal, 0.0, 0.0, b.vesting,    
                         m.comments,(b.PreEmprCBal)* (b.Vesting/100.000),b.Bonus,0,0,B.PreEmpCBal + B.PreEmprCBal + B.PreAVCCBal,                                                                              
                         m.ActiveStatus,m.DeferredPaid,m.PayrollNo,m.DocRefNo,b.TransType                                           
             from Members m                                                                                            
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                     
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                                                                            
end                                                           
else if @Mode = 5 /* Cummulative Combined */                                                                                            
begin                                                                                            
declare GenCursor cursor for                                                                              
              select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                           
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,m.IDNumber,                          
              b.calcYear, b.interestrate, b.empCBal + b.VolCBal + b.PreEmpCBal+ b.PreAVCCBal,                                                    
                         b.emprCBal + b.SpecialCBal + PreEmprCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting,                                                                                        
                     m.comments,(b.EmprCBal + b.SpecialCBal + b.PreEmprCBal)* (b.Vesting/100.000),                                                                                            
                         b.Bonus,b.EmpTransferCBal,b.EmprTransferCBal + b.DeferredCBal,B.PreEmpCBal + B.PreEmprCBal + B.PreAVCCBal,                                                                                            
                         m.ActiveStatus,m.DeferredPaid,m.PayrollNo,m.DocRefNo,b.TransType                                                                        
             from Members m                                                                                            
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                                                                                   
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                                                                            
end                                                     
else if @Mode = 6 /* Registered AVC */                                                    
begin                                                    
declare GenCursor cursor for                                                                                            
               select m.schemeNo, m.memberNo, m.dje,m.djpens,m.doexit,                                                                                              
               (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,m.IDNumber,                                                                                            
           b.calcYear, b.interestrate, b.VolCBal + b.PreAVCCBal,                              
                          b.SpecialCBal, b.withholdingTax, b.taxfreeLumpsum, b.vesting,                                                                                        
                     m.comments,(b.SpecialCBal)* (b.Vesting/100.000),                                                                                            
                         b.Bonus,0,0,B.PreAVCCBal,                                                                                            
                         m.ActiveStatus,m.DeferredPaid,m.PayrollNo,m.DocRefNo,b.TransType                                                                                           
             from Members m                                  
                 inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                                                                                                 
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo            
end                                                                           
open GenCursor                                                                                            
                                                                                            
fetch from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @fullname,@IDNumber,@curYear, @interest,                                                                                            
 @EmpClosing,@emprClosing,@withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont,@Bonus,@TransferCBal,                                            
 @TransferCBalE,@Pre90,@ActiveStatus,@DeferredPaid,@PayrollNo,@DocRefNo,@TransType                                                                  
                                                                                            
                                                                                            
while @@fetch_status =0                                                                                            
begin                                                 
                           
    if ((@Mode < 2) or (@Mode >= 5))                                                                                            
        Select @DoCALC = DOCalc,@Doexit = Doexit,@rExit=ReasonforExit,@DesignCode = DesignCode,@DoBirth = dob       
        from Members       
        where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                                      
     else                                                      
        Select @DoCALC = ProjectDOCalc,@Doexit = ProjectDoexit,@rExit=ProjectReason,@DesignCode = DesignCode,@DoBirth = dob       
        from Members       
        where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                         
        
          
     if (@rExit = 1) and (@PayGreater = 1)        
        begin        
          Exec Proc_Get_Latest_Sal @schemeNo,@MemberNo,@DoCALC,@Salary Out        
        
          select @Gratuity = @Salary * @SalFactor        
        end        
             
     /* New Deferment Rules */                      
     if (@Mode = 2)                        
        Exec Proc_Get_Defer_Rate @schemeNo,@DoCalc,@FundType,@EeRate out,@ErRate out,@QualifyPeriod Out                       
     else                      
        select @EeRate  = EeRate,@ErRate = ErRate from Benefits where schemeNo = @schemeNo and MemberNo = @MemberNo                      
                      
     if @EeRate is null                       
        Exec Proc_Get_Defer_Rate @schemeNo,@DoCalc,@FundType,@EeRate out,@ErRate out,@QualifyPeriod Out                      
                        
    if ((@Zambia = 1) and (@ActiveStatus = 6) and (@DeferredPaid = 0))                                                                                
        select @OptionToUse = 1                                                                                
     else                                                             
        begin                      
         if @ErRate = 100 /* Over 1 Yr But Less than 3  - Uhuru */                      
            select @OptionToUse  = 0                      
         else               
            Exec EmployerOption @schemeNo,@MemberNo,@OptionToUse Out /* PROCEDURE DBO.to Incorporate Budget changes 2005 */                       
        end                         
                             
                                                                        
   if @TransferCBal is null select @TransferCBal = 0                                                                    
   if @TransferCBalE is null select @TransferCBalE = 0                                                                    
                                                                                 
   if @taxfreeLumpsum is null select @taxfreeLumpsum = 0.0                                                  
                                                  
   if ((@Mode = 2) and (@TaxFreeLumpsum > 0) and (@EmpClosing > 0))                           
      begin                         
         if @OptionToUse = 1                        
            begin                        
               if @ErRate < 100                        
                  select @TaxFreeLumpsum = (((@ErRate/100.00) * @emprClosing) + @EmpClosing) /(@EmpClosing + @emprClosing) * @taxfreeLumpsum                         
               else                          
                  select @TaxFreeLumpsum = (@EmpClosing/(@EmpClosing + @emprClosing)) * @taxfreeLumpsum                          
            end                                                
                                                  
      end                                                  
                                                                                            
   Exec GetServiceTime @djpens,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out                                      
                                                                      
                        
   select @Employee = @EmpClosing +  @TransferCBal, @Employer = @emprClosing + @TransferCBalE                                                                                          
   IF @Mode = 4                                                                                            
      Select @taxfreeLumpsum = 0.0                                                                                            
                                                             
                             
                            
     if @Ben_Counter = 0                                                                                    
     select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy,                                                                                            
     @AuditedBy = AuditedBy,@DateAudited = DateAudited,                                                                                            
     @DatePrepared = DatePrepared,@DateChecked = DateChecked,@DateAuthorised  = DateAuthorised                                        
     from LumpAuthorization where SchemeNo = @schemeNo and MemberNo = @MemberNo      
     else      
     select @PreparedBy = PreparedBy,@CheckedBy = CheckedBy,@AuthorisedBy = AuthorisedBy,                                                                                            
     @AuditedBy = AuditedBy,@DateAudited = DateAudited,                                                                                            
     @DatePrepared = DatePrepared,@DateChecked = DateChecked,@DateAuthorised  = DateAuthorised                                        
     from TBL_Benefits_DC where SchemeNo = @schemeNo and MemberNo = @MemberNo and Ben_Counter = @Ben_Counter                                                                                             
                                                                  
                                                                       
    if @DesignCode is null select @DesignCode = 0                     
    if @DoCalc is null select @DoCalc = @DoExit                                                                  
                                                          
                          
    select @CurMonth = datepart(Month, @DoCalc)                                                         
    select @curYear = datepart(Year, @DoCalc)                                                                                       
                                                                                              exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out                                                                                 

  
         
                                                                                              
    select @EndDate = EndDate from SchemeYears where SchemeNo = @SchemeNo and AcctPeriod = (@AcctPeriod - 1)                                                                                             
    Select @eDate = EndDate,@sDate = StartDate from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod                                  
                                
    Exec DateToStr @eDate,@sEndDate Out                                
    Exec DateToStr @sDate,@sStartDate Out                                
                                
    select @ContPeriod = @sStartDate+' to '+@sEndDate                                
                                                                                               
                                                                                            
    Select @MwishoDate = @eDate                                             
                                                                                            
                                                                                            
     if @HasFrozen = 0                                     
        select @Pre90 = 0                                                                                            
     else if @HasFrozen = 1                                                                                            
        begin                                                                                            
           if @FrozenDate <= 'Dec 31,1990'                                                                                            
              Select @Pre90 = @Pre90                             
           else                                                                                            
          select @Pre90 = 0                                                                                            
       end                                                                   
                                                                             
     if @Bonus is null select @Bonus = 0                                               
                                                                                            
                                                                                    
     select @eDate = @DoExit                                                                                            
                                                                                            
      if @Mode = 0                                                 
         begin                                                                                                      
                Select @EmpOpening = (empCont + PreEmpCont) - EmpFees,                                       
                @EmprOpening = (EmprCont + PreEmprCont)-EmprFees,@TransferOpBal = Transfer, @TransferOpBalE = lockedIn + DeferredAmt                                          
                from MemberOpeningBalances                                                               
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                                                                             
                                                                                                 
                select @empContribution = sum(empcont),@emprContribution = sum(emprcont)                                                                                          
                from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo           
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                                                            
                                                                                            
                select @ArEmpCont = sum(Arempcont),@ArEmprCont = sum(Aremprcont)                                                                                              
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                          
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                   
                                                                                                            
                Select @TransferCont = sum(EmpTransfer),@TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                                                                            
                where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                             
                and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                                                                            
                                                                                     
                IF @TransferCont IS NULL select @TransferCont = 0                                                                                            
                IF @TransferContE IS NULL select @TransferContE = 0                                                                      
                                                                    
                if @EmpOpening is null select @EmpOpening = 0                                                                                            
                if @EmprOpening is null select @EmprOpening = 0                                                                      
                                                   
                if @ArEmpCont is null select @ArEmpCont = 0                                                                                            
                if @ArEmprCont is null select @ArEmprCont = 0                                                                                          
                                                
                if @empContribution is null select @empContribution = 0                                                                                            
                if @emprContribution is null select @emprContribution = 0                                      
                                                                    
                                                 
        end                                                                      
      else if @Mode = 1                                                                         
         begin                                                                             
                Select @EmpOpening = (empCont + EmpVolCont + PreEmpCont + PreAVC)-(Empfees + Volfees),                                                                                        
                @EmprOpening = (EmprCont + EmprVolCont + PreEmprCont) - (EmprFees + SpecFees)                                      
                ,@TransferOpBal = Transfer, @TransferOpBalE = LockedIn + DeferredAmt                                                                          
                from MemberOpeningBalances                                                                                             
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                                                               
                                                                            
                if (@GEPF = 1) AND (@RExit = 21)                                                                               
                   select @empContribution = sum(empcont + VolContr + ExcessEmpCont + ExcessVolContr),                        
                   @emprContribution = sum(emprcont + SpecialContr + ExcessEmprCont + ExcessSpecial)                                                                                              
                   from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                   and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                                                            
                else                                                                      
                   select @empContribution = sum(empcont + VolContr),@emprContribution = sum(emprcont + SpecialContr)                                                                                         
                   from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                   and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                                                                            
                                                                                            
                                                                                                            
                select @ArEmpCont = sum(Arempcont + ArVolContr),@ArEmprCont = sum(Aremprcont + ArSpecial)                                                     
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                                                            
                                                                                                  
                Select @TransferCont = sum(EmpTransfer),@TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                                        
                where SchemeNo = @schemeNo and MemberNo = @memberNo                     
                and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                                    
                                                                                            
                IF @TransferCont IS NULL select @TransferCont = 0                                                                                            
                IF @TransferContE IS NULL select @TransferContE = 0                                                                      
                                                                    
                if @EmpOpening is null select @EmpOpening = 0                                                                                       
                if @EmprOpening is null select @EmprOpening = 0                                                                     
                                                                    
                if @TransferOpBal is null select @TransferOpBal = 0                                                                   
                if @TransferOpBalE is null select @TransferOpBalE = 0                                                       
                                                                                    
       if @ArEmpCont is null select @ArEmpCont = 0                                                                                            
                if @ArEmprCont is null select @ArEmprCont = 0                                                     
                                                                                        
                if @empContribution is null select @empContribution = 0                                                                                            
                if @emprContribution is null select @emprContribution = 0                                
                           
        end                                                                                            
     else if ((@Mode = 2)  and (@ActiveStatus <> 6)) /* Projections */                                                                        
         begin                                                                                            
                 Select @EmpOpening = (empCont + EmpVolCont + PreEmpCont + PreAVC) - (EmpFees + VolFees),                                                                                             
                 @EmprOpening = (EmprCont + EmprVolCont + PreEmprCont) - (EmprFees + SpecFees),@TransferOpBal = Transfer, @TransferOpBalE = LockedIn + DeferredAmt                                                   
                 from MemberOpeningBalances                                                              
                 where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                                                                            
                                                                                                 
                 select @empContribution = sum(empcont + VolContr),@emprContribution = sum(emprcont + SpecialContr)                                                                                             
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                                                    
                                                                                            
                select @ArEmpCont = sum(Arempcont + ArVolContr),@ArEmprCont = sum(Aremprcont + ArSpecial)                     
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                                                            
                                                                                            
                if @ArEmpCont is null select @ArEmpCont = 0                                                                                            
                if @ArEmprCont is null select @ArEmprCont = 0                                                                         
                                                  
               Select @TransferCont = sum(EmpTransfer), @TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                                                                            
                 where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                 and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                                                                            
                                                          
       IF @TransferCont IS NULL select @TransferCont = 0                                                        
                IF @TransferContE IS NULL select @TransferContE = 0                                          
                                                                    
                if @EmpOpening is null select @EmpOpening = 0                                                                                            
                if @EmprOpening is null select @EmprOpening = 0                                  
                                                                                    
                if @ArEmpCont is null select @ArEmpCont = 0                         
                if @ArEmprCont is null select @ArEmprCont = 0                                                                                        
                                                                                        
                if @empContribution is null select @empContribution = 0                                                                                            
                if @emprContribution is null select @emprContribution = 0                                                                                           
                                                                                            
                                                                                                            
        end                                                                                            
     else if ((@Mode = 2)  and (@ActiveStatus = 6)) /* Projections for Deferred Members */                                                     
          begin                                                                                            
                                                                                            
                 select @EmpClosing = 0.0                                                                                            
                 Select @EmpOpening = 0.0,                                        
                 @EmprOpening = (EmprCont + EmprVolCont + PreEmprCont) - (EmprFees + SpecFees),                          
                 @TransferOpBal = Transfer, @TransferOpBalE =LockedIn + DeferredAmt                                                                                   
                 from MemberOpeningBalances 
                 where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                                                                            
                                          
                 select @empContribution = 0.0                                                                                             
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                        
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                                                                            
                                                               
                 select @emprContribution = sum(emprcont + SpecialContr)                                              
                 from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                         
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                                                                             
                 select @ArEmpCont = sum(Arempcont)                                                                    
                 from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                  
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                        
                                                                                            
                 select @ArEmprCont = sum(Aremprcont + ArSpecial)                                                                                             
                 from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                 and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                                               
                                                                        
                if @ArEmpCont is null select @ArEmpCont = 0                                  
                if @ArEmprCont is null select @ArEmprCont = 0                                                                                            
                                                                                            
                 Select @TransferCont = sum(EmpTransfer), @TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                                                                            
                 where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                 and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                                                                   
                                                                                            
                IF @TransferCont IS NULL select @TransferCont = 0                                              
                IF @TransferContE IS NULL select @TransferContE = 0                                                                      
                                                           
                if @EmpOpening is null select @EmpOpening = 0                                                                                            
                if @EmprOpening is null select @EmprOpening = 0                                                                      
                                                   
                if @ArEmpCont is null select @ArEmpCont = 0                                                                                            
                if @ArEmprCont is null select @ArEmprCont = 0                                                                                          
                                                                                        
              if @empContribution is null select @empContribution = 0                                 
                if @emprContribution is null select @emprContribution = 0                                                                                              
        end              
else if @Mode = 3 /* Combined Post 90 */                                                                                            
         begin                                                                                            
                Select @EmpOpening = empCont + EmpVolCont,                                                                     
                @EmprOpening = (EmprCont + EmprVolCont) - (EmprFees + SpecFees),@TransferOpBal = Transfer,                           
                @TransferOpBalE = LockedIn + DeferredAmt                                                                                            
                from MemberOpeningBalances                   
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                                                                            
                                                                                                 
                if (@GEPF = 1) AND (@RExit = 21)                                                                                            
                   select @empContribution = sum(empcont + VolContr + ExcessEmpCont + ExcessVolContr),                                                                                            
                   @emprContribution = sum(emprcont + SpecialContr + ExcessEmprCont + ExcessSpecial)                                        
                   from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                   
                   and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                                                 
                else                                                                                            
                   select @empContribution = sum(empcont + VolContr),@emprContribution = sum(emprcont + SpecialContr)                                                                                              
                  from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                       
                   and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0                                                                                            
                                                                                          
                                                                                          
                select @ArEmpCont = sum(Arempcont + ArVolContr),@ArEmprCont = sum(Aremprcont + ArSpecial)                                                                                              
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                     
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                               
                              
                                                                                                                  
                Select @TransferCont = sum(EmpTransfer),@TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                                                                            
                where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
             and AcctPeriod = @AcctPeriod and TransferDate >= @sDate and TransferDate <= @DoCalc                                                  
                                                                                    
         IF @TransferCont IS NULL select @TransferCont = 0                                                                                            
            IF @TransferContE IS NULL select @TransferContE = 0                                                                      
                                                                    
                if @EmpOpening is null select @EmpOpening = 0                                                                               
                if @EmprOpening is null select @EmprOpening = 0                                                                      
                                     
                if @ArEmpCont is null select @ArEmpCont = 0                       
                if @ArEmprCont is null select @ArEmprCont = 0                                                                                          
                                                                                        
                if @empContribution is null select @empContribution = 0                                                                                            
                if @emprContribution is null select @emprContribution = 0                                                                                           
        end                                                                                   
else if @Mode = 4 /* Pre 90 Combined */                                    begin                                                   
                Select @EmpOpening = PreEmpCont + PreAVC,                                                                                    
                @EmprOpening = PreEmprCont,@TransferOpBal = 0.0, @TransferOpBalE = 0.0                                                                                            
                from MemberOpeningBalances                                                                                             
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                                          
                                                                                                 
                IF @TransferCont IS NULL select @TransferCont = 0                                                       
                IF @TransferContE IS NULL select @TransferContE = 0                                                                      
                                                         
                if @EmpOpening is null select @EmpOpening = 0                                                                                            
                if @EmprOpening is null select @EmprOpening = 0                                                                      
                                                      
                if @ArEmpCont is null select @ArEmpCont = 0                                                                                            
                if @ArEmprCont is null select @ArEmprCont = 0            
                                                                                        
                if @empContribution is null select @empContribution = 0                                                                                            
                if @emprContribution is null select @emprContribution = 0                                                                 
        end                                                            
else if @Mode = 5 /*Cummulative Combined */                                                                                            
         begin                                                                                            
                Select @EmpOpening = 0,                                                                       
                @EmprOpening = 0,@TransferOpBal = 0.0, @TransferOpBalE = 0.0                                                                                          
                                                                                                 
                if (@GEPF = 1) AND (@RExit = 21)                                                                                            
                   select @empContribution = sum(empcont + VolContr + ExcessEmpCont + ExcessVolContr),                                                                                            
                   @emprContribution = sum(emprcont + SpecialContr + ExcessEmprCont + ExcessSpecial)                   
                   from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                   and DatePaid <= @DoCalc                                                                                            
                else                                                                          
                   select @empContribution = sum(empcont + VolContr),@emprContribution = sum(emprcont + SpecialContr)                                                                                              
                   from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo               
                   and DatePaid <= @DoCalc and Surplus = 0                                                                                            
                                                    
                                        
                select @ArEmpCont = sum(Arempcont + ArVolContr),@ArEmprCont = sum(Aremprcont + ArSpecial)                                                                                              
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                and DatePaid <= @DoCalc                                                                                            
                                                                                       
                Select @TransferCont = sum(EmpTransfer),@TransferContE = SUM(EmprTransfer + DeferredAmt) from MemberTransfer                                                                                            
                where SchemeNo = @schemeNo and MemberNo = @memberNo                                          
                and TransferDate <= @DoCalc                                                                                            
                                                                                            
                IF @TransferCont IS NULL select @TransferCont = 0                                                                                            
                IF @TransferContE IS NULL select @TransferContE = 0                            
                                   
                if @EmpOpening is null select @EmpOpening = 0                                                                       
                if @EmprOpening is null select @EmprOpening = 0                                                                     
                                                                    
                if @TransferOpBal is null select @TransferOpBal = 0                                                                                            
                if @TransferOpBalE is null select @TransferOpBalE = 0                                                              
                                                                                    
                if @ArEmpCont is null select @ArEmpCont = 0                                                     
                if @ArEmprCont is null select @ArEmprCont = 0                                                                                          
                                                                                        
                if @empContribution is null select @empContribution = 0                                                                                            
                if @emprContribution is null select @emprContribution = 0                                                                                        
                                                                                          
        end                                                     
else if @Mode = 6 /*Registered AVC */                                                             
         begin                                                                                            
                Select @EmpOpening = (EmpVolCont + PreAVC) - (VolFees),                                                                                      
                @EmprOpening = EmprVolCont - SpecFees,@TransferOpBal = 0, @TransferOpBalE = 0                                                                                            
                from MemberOpeningBalances                                                                                             
                where schemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                           
                                                                                         
                if (@GEPF = 1) AND (@RExit = 21)                                                                                            
                   select @empContribution = sum(VolContr + ExcessVolContr),                                    
                   @emprContribution = sum(SpecialContr + ExcessSpecial)                                                                                              
                   from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                   and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                         
                else                                                                                            
                   select @empContribution = sum(VolContr),@emprContribution = sum(SpecialContr)                                                                                              
                   from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                   and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc and Surplus = 0      
                                                                                            
                                                                                                            
                select @ArEmpCont = sum(ArVolContr),@ArEmprCont = sum(ArSpecial)                                                                                
                from ContributionArrears where SchemeNo = @schemeNo and MemberNo = @memberNo                                                                                             
                and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @DoCalc                                                        
                                                                                                  
                                           
                IF @TransferCont IS NULL select @TransferCont = 0                                                     
          IF @TransferContE IS NULL select @TransferContE = 0                                                                      
                      
                if @EmpOpening is null select @EmpOpening = 0                                                                                            
                if @EmprOpening is null select @EmprOpening = 0                                                                     
                                                                    
                if @TransferOpBal is null select @TransferOpBal = 0                                                                                            
                if @TransferOpBalE is null select @TransferOpBalE = 0                                                      
                                                                             
                if @ArEmpCont is null select @ArEmpCont = 0                                                                                            
                if @ArEmprCont is null select @ArEmprCont = 0                                             
                             
                if @empContribution is null select @empContribution = 0                                                                                            
                if @emprContribution is null select @emprContribution = 0                                                                     
                                                                                             
        end                                                                       
               
          
      /* Knock Off Expenses */          
      Exec Proc_Get_Expenses @schemeNo,@MemberNo,@DoCalc,@EmpExpenses out,@EmprExpenses out             
                                                                                       
      select @EmpContribution = @EmpContribution + @ArEmpCont,                                                      
             @EmprContribution = @EmprContribution + @ArEmprCont                                                                                          
                                                                                            
        if @TransferOpBal is null select @TransferOpBal = 0                                                                               
        if @TransferCont is null select @TransferCont = 0                                                                                            
        if @TransferContE is null select @TransferContE = 0                                                                                            
                                                                                            
        select @datepaid = max(datePaid)                                                                                                     
        from Contributionssummary where SchemeNo = @schemeNo and MemberNo = @memberNo                                                
                                                   
        and AcctPeriod = @AcctPeriod and DatePaid >= @sDate and DatePaid <= @MwishoDate and Surplus = 0                                                                                            
                                                                                                   
        if @emprContribution is null select @emprContribution = 0                                                                        
                                                                                              
        if @empContribution is null select @empContribution = 0                                                                            
                                                                                             
        if @empOpening is null select @empOpening = 0                                                                            
                                                                                          
        if @emprOpening is null select @emprOpening = 0                                                                                            
                                                                                                                    
        IF ((DatePart(Month,@dateofExit) = 2) and (@NumDays >= 28))                                                                                            
           select @NumMonths = @NumMonths + 1,@NumDays = @NumDays - 28                                                                                  
                                                                          
        if @NumMonths = 12                                                                             
           select @NumYears = @NumYears + 1,@NumMonths = 0                                                                                            
                                                       
        select @ServiceTime = cast(@NumYears as Varchar(2)) +' Years, '+ cast(@NumMonths as varchar(2))+'  months and '+cast(@NumDays as Varchar(2))+' days '                                                                                             
        select @PastService = (@NumYears * 12)+@NumMonths                                                                                            
                                                                                   
        select @Year = datePart(Year, @DateOfExit)                                                               
                            
        select @Month = datePart(Month, @DateOfExit)                                                                                            
                                                                                            
        exec getMonthDays @Year, @Month, @Days out                                                                                            
                         
        select @sMonth = @pastService % 12                                                                      
                                                                                                   
        select @EmpInt = @empClosing - (@EmpOpening + @EmpContribution)                                                                                            
        --IF @EmpInt < 1.00 SELECT @EmpInt = 0.0                                                                                 
                                                                                            
        select @EmprInt = @emprClosing - (@EmprOpening + @EmprContribution)                                                                                            
        --IF @EmpRInt < 1.00 SELECT @EmpRInt = 0.0                                                        
                                                                                                      
       if ((@Mode = 2)and (@ActiveStatus = 6))                                                                                            
          begin                                                                                            
               select @GrandTotal =  @EmpClosing  + @EmprClosing + @TransferCBal + @TransferCBalE                                                                                      
          end                                     
       else                                                                                            
        begin                                                                                            
         if @OptionToUse = 0                                                  
            begin                                                                    
             if (@Vesting  = 100.00 )                                       
           select @GrandTotal =  @EmpClosing  + @EmprClosing + @TransferCBal + @TransferCBalE,                                                            
               @LockedTransfer = @TransferCBalE                                                                                            
             else                                                 
               select @GrandTotal =  @EmpClosing + @VestedCont + @TransferCBal + (@TransferCBalE * (@Vesting/100.000)),                                                                                            
               @LockedTransfer = @TransferCBalE * (@Vesting/100.000)                                                                                            
           end                                                                                            
         else if @OptionToUse = 1                                
           begin                         
              begin                                                                                           
                if @ErRate < 100                        
                   select @GrandTotal =  @EmpClosing + @TransferCBal  +  ((@EmprClosing + @TransferCBalE) * (@ErRate/100.00)),                                                            
                   @LockedTransfer = @TransferCBalE * (@ErRate/100.00),@VestedCont = ((@EmprClosing) * (@ErRate/100.00))                        
                else                        
                   select @GrandTotal =  @EmpClosing + @TransferCBal, @VestedCont = 0,@LockedTransfer = 0                            
                        
              end                                                                        
      end                                                                                            
       else if @OptionToUse = 2                                                                                            
           begin                                                                 
             select @GrandTotal =  @EmpClosing + @VestedCont + @TransferCBal + (@TransferCBalE * (@Vesting/100.000)),                                                                              
             @LockedTransfer = @TransferCBalE * (@Vesting/100.000)                                                                                             
           end                                                                                          
  end                                                                                            
                                                                                                   
       if @TransferCBal is null select @TransferCBal = 0         
        
         
                                                                                            
       select @ClosingBalance = @GrandTotal          
        
       if ((@PayGreater = 1) and (@Gratuity > 0))         
          begin        
            if @Gratuity >  @ClosingBalance        
               select @ClosingBalance = @Gratuity        
          end                                  
                                                                                      
      if @DeductNSSF = 1                                                                             
         SELECT @Bonus = 0 - @NSSF2Deduct                                                                                            
                                                                                            
      select @GrandTotal = @GrandTotal + @Bonus                                                                                            
                                                                                             
      if @TransferOpBal is null select @TransferOpBal = 0             
      if @TransferOpBalE is null select @TransferOpBalE = 0                                                                               
                                                                                                  
      if @TransferCont is null select @TransferCont = 0                                                                                            
      if @TransferContE is null select @TransferContE = 0                            
                                                                                                  
      Select @TransferInt = @TransferCBal - (@TransferOpBal + @TransferCont)                                                                                      
      Select @TransferIntE = @TransferCBalE - (@TransferOpBalE + @TransferContE)                                                                                            
                                                
                                                    
      IF @TransferInt < 1.00 Select @TransferInt = 0.00                                                                                            
                                                                                            
                                                                                                  
     if @Mode = 4                                                                                            
        select @WithHoldingTax = 0,@TaxAmount = 0,@TaxFreeLumpsum = 0                                                                                            
     else                                                                                            
      begin                                                     
      if @rExit = 8 /* Transfers */                              
  begin                                                                
            select @TaxAmount = 0,@TaxFreeLumpsum = 0,@WithHoldingTax = 0                                                                                            
    end                                                                    
      else if @rExit = 1 /* Death in Service cases */                                                                              
         begin                                                                                 
            if @BenefitMode = 1/* Gratuity Only */                                                                                            
               Exec GetTaxFreeLumpsumD @schemeNo,@DoCalc,@TaxFreeLumpsum out                                                                                            
                                                                                            
              select  @TaxAmount = @GrandTotal - (@Pre90  + @TaxFreeLumpsum)                                                                                            
                                                                                            
              if @TaxAmount < 0 select @TaxAmount = 0                                                                                            
                                                                                            
              Exec GetTaxType @SchemeNo,@MemberNo,@TaxType Out                               
                                                                                    
              exec CalculateTax @SchemeNo,@TaxAmount,@DoCalc, @TaxType,@WithHoldingTax out                                                         
                                                                            
            if @BenefitMode = 2/* Insured */                                                                                            
               select @TaxAmount = 0,@TaxFreeLumpsum = 0,@WithHoldingTax = 0                                                                                            
         end                                                                                       
      else                                                             
         begin                                                                                            
              select  @TaxAmount = @GrandTotal - (@Pre90  + @TaxFreeLumpsum)                                                                                            
                                                                                            
              if @TaxAmount < 0 select @TaxAmount = 0                                                                                            
                                                                                            
              Exec GetTaxType @SchemeNo,@MemberNo,@TaxType Out                  
                                                                                      
              exec CalculateTax @SchemeNo,@TaxAmount,@DoCalc, @TaxType,@WithHoldingTax out                                                                                            
         end                                                                                            
     end                                      
                                                                                            
       select @Reason = ReasonDesc                                                                                             
       from ReasonforExit where ReasonCode = @rExit                               
                              
       if ((@rExit = 1) and (@ActiveStatus = 6))                              
           select @Reason = 'Death in Deferment'                                                                                            
                                                                                            
         if @DesignCode > 0               
          begin                                                                                            
          select @Title = Designation from Designation where DesignCode = @DesignCode                                                                                            
                                                                                            
          select @FullName = upper(@Title) +'  '+@FullName                                                             
          end                                                                                            
                                         
                                                                           
        /* rounding  Grand Total*/                                          
              select @YaConversion = cast(@GrandTotal as Varchar(25))                                                                  
    Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out                                                                                            
              select @GrandTotal = @Chapaa                                                                                            
              select @Chapaa = 0                                                                                            
                                                                                            
        /* rounding  Grand Total*/                
              select @YaConversion = cast(@WithholdingTax as Varchar(25))                                                       
              Exec RoundingYaFundMasterTax @SchemeNo,@YaConversion,@Chapaa out                                                                                            
              select @WithholdingTax = @Chapaa                                                                                            
             select @Chapaa = 0                                     
                                                                                            
        if @TaxAmount is null select @TaxAmount = 0                                                                                            
                                                                                            
        /* FOR TZ Market */                                                       
        /* TZ */                                                                                            
        if @SchemeMode = 1                                                                                            
           BEGIN                                                                                            
             SELECT @SponsorCode = SponsorCode from Members where schemeNo = @schemeNo and MemberNo = @MemberNo                                                      
                                                                                               
             select @Sponsor = SponsorName from Sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode                                                                                 
           END                                                                                            
        else                                                          
            select @Sponsor = ''                                                          
                                                   
        Exec Proc_Member_Loans_Details_AtDate @SCHEMENO,@MemberNo,@DoCALC,@Loan Out,@LoanRepaid Out,                                                                                        
        @LoanBalance Out,@OtherDeductions Out          
          
        select @LoanBalance = @LoanBalance + @EmpExpenses + @EmprExpenses                                                                                            
                                 
        if @Loan is null select  @Loan=0                                                   
        if @LoanRepaid is null select  @LoanRepaid=0                                                                                          
        if @LoanBalance is null select  @LoanBalance=0                                                                                          
        if @OtherDeductions is null select  @OtherDeductions=0                                                                                          
                                                                                                                           
        /* rounding  Loan Balance*/                                                    
              select @YaConversion = cast(@LoanBalance as Varchar(25))                                                                        
              Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out                                                                     
              select @LoanBalance = @Chapaa                                                                               
              select @Chapaa = 0                                                                                             
        if ((@GEPF = 1) AND (@RExit = 21))                                                                                 
           select @ReportTitle = 'TRANSFERS TO PSPF CALCULATION SHEET'                                
        else                                   
           select @ReportTitle = 'WITHDRAWAL BENEFIT CALCULATION SHEET'                                                                                            
                                                                                            
                                                                                            
        if @Mode = 3                                             
           select @ReportTitle = 'POST 90 BENEFIT CALCULATION SHEET'                                                                                            
        else if @Mode = 4                                           
           select @ReportTitle = 'PRE-90 BENEFIT CALCULATION SHEET'          
          
                                                                                                                                                                                             
/* Zambia Taxation */                                                                                          
if ((@Zambia = 1) and (@TaxRateDiff = 1))                                                                                          
begin                                              
                                                                                          
   if @rExit = 1                                                                                          
      begin                                                                                          
        if @TaxDeath = 1                                                                                          
           Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,@Employee,@Employer,@TaxEmployee Out,@TaxEmployer Out                                                                                          
      end                                                                                          
   else if @rExit > 1 and @rExit < 5                            
      begin                                                                                         
if @TaxRet = 1                                                                                          
           Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,@Employee,@Employer,@TaxEmployee Out,@TaxEmployer Out                                              
      end                                                                                          
   else if @rExit = 5          
      begin                                                                         
        if @TaxMedical = 1                                                                                          
           Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,@Employee,@Employer,@TaxEmployee Out,@TaxEmployer Out                                                                                          
                                                                                          
      end      
   else if @rExit > 5 and @rExit <> 8                                                                                          
      begin                                                    
         if @TaxWith = 1                                                                                          
           begin                                                                                          
           Exec  CalculateTax_Sep @SchemeNo,@MemberNo,@DoCalc,@Employee,@Employer,@TaxEmployee Out,@TaxEmployer Out                                         
                                                                                          
           select @TaxFreeLumpsum = 0.0                                             
                                                                      
           if @TransType = 50 -- Employee Only --                                            
              begin                                            
                                                          
              select @TaxEmployer = 0,@withHoldingTax = @TaxEmployee,@TaxAmount = @Employee,@GrandTotal = @Employee                                              
                                            
              update Benefits set TaxEmployer = 0,withholdingtax = @TaxEmployee                                          
              where schemeNo = @schemeno and Memberno = @MemberNo                                            
              end                                        
           else                                            
              begin                                            
                                                               
                                                                                           
                if ((@ActiveStatus = 6) and (@DeferredPaid = 0))                                                                                
                   select @TaxAmount = @Employee                                                                                
                else                                                              
                   select @TaxAmount = @Employee + @Employer                                             
                                            
             end                                                         
           end                                                                           
                               
      end                                                                                          
                                                                  
   if @TaxEmployee is null select @TaxEmployee = 0                                                                                      
   if @TaxEmployer is null select @TaxEmployer = 0                                                                                          
   if @TaxEmployee + @TaxEmployer = 0                                                                                          
   select @TaxFreeLumpsum = 0.0,@TaxAmount =0.0                                                             
                                                                                   
   if ((@ActiveStatus = 6) and (@DeferredPaid = 0))                                                                                
      select @WithHoldingTax = @TaxEmployee                                                                                  
   else                                  
      select @WithHoldingTax = @TaxEmployee + @TaxEmployer                                                                                          
end                                                                                          
else                                                                                          
begin                                                                
  if @WithHoldingTax > 0                                                                                          
     select @TaxEmployee = @WithHoldingTax/2.00,@TaxEmployer = @WithHoldingTax/2.00                                                                                          
end                                                                                      
                                                                            
  IF @TaxEmployer IS NULL select @TaxEmployer = 0.0                                  
  IF @TaxEmployee IS NULL select @TaxEmployee = 0.0                                             
                                            
                                                                                  
                                                                                        
  /*for GEPF */                                                  
   if ((@TransType = 49) and (@Mode = 6))                                   
      begin                                                  
        update Benefits set Deductions = @LoanBalance + @OtherDeductions,WithholdingTax = @WithholdingTax                                                    
        where schemeNo = @schemeNo and MemberNo = @MemberNo                                                   
                               
        Update DeathClaim set AmountofCover = @GrandTotal,Tax = @WithholdingTax where schemeNo = @schemeNo and MemberNo = @MemberNo                                                                                             
      end                                                  
   else                                                                                            
      update Benefits set Deductions = @LoanBalance + @OtherDeductions where schemeNo = @schemeNo and MemberNo = @MemberNo                 
                
  if ((@ExitReason = 1) and (@FundType <> 2))                
     Update DeathClaim set AmountofCover = @GrandTotal,Tax = @WithholdingTax where schemeNo = @schemeNo and MemberNo = @MemberNo                                                                    
                                                    
                                 
        if @Mining = 0                                          
           select @MembNoToUse = cast(@MemberNo as varchar(50))                                          
        else                                          
           select @MembNoToUse = @PayrollNo                                          
        
     /* No tax for wazees */                                          
     select @NumYears = 0,@NumMonths = 0,@NumDays=0                                          
                                          
     Exec GetServiceTime @dobirth,@doExit,@NumYears Out,@NumMonths Out,@NumDays out                                          
     if @NumYears >= 65                                          
        begin                                          
        select @withHoldingTax = 0,@TaxAmount = 0,@taxfreeLumpsum = 0                                          
                         
        update Benefits set withholdingTax = 0                                          
        where schemeNo = @schemeNo and memberNo = @memberNo                                          
                                          
        update UnRegisteredBenefits set withholdingTax = 0,cEmptax = 0,cEmprtax = 0,cVoltax= 0,cSpectax = 0                                          
        where schemeNo = @schemeNo and memberNo = @memberNo                                          
                                          
        update partialpayment set taxpaid = 0,OrigTax=0,RegTax = 0,UnRegTax = 0,taxPaidUn = 0                                          
        where schemeNo = @schemeNo and memberNo = @memberNo                                         
                                          
        end                                          
                                                                                       
        insert into #calculation (schemeNo, MemberNo, schemeName, fullname, dje, djpens, empopeningBal, emprOpeningBal,                                                                                            
                     empcontributions, emprContributions,empclosing, emprClosing,interest, dateofexit,                                                                                            
                     curYear, pastService, benefitsDC, TaxfreeLumpsum,withHoldingTax,Vesting, Comments, EmprInt, EmpInt, AmountPayable, TaxableAmount,                                                                                            
                     Reason,EndDate,PreparedBy,CheckedBy,AuthorisedBy,ClosingBalance,Bonus,TransferInt,TransferCBal,TransferOpBal,                                                                                            
                     TransferDesc,AdditionDesc,DoCalc,VestedCont,TransferCont,AuditedBy,DateAudited,DoBirth,                                                                                            
                     TransferIntE,TransferCBalE,TransferOpBalE,TransferContE,LockedTransfer,                                                                                     
                    DatePrepared,DateChecked,DateAuthorised,Loan,LoanRepaid,LoanBalance,NetBalance,Sponsor,OtherDeductions,           
                     ReportTitle,EmpTotal,EmprTotal,EmpTax,EmprTax,Deductions,IDNumber,PoolName,PayrollNo,                            
                     MemberNoDesc,ContPeriod,DocRefNo,Salary,SalFactor,Gratuity)                   
                                                                      
                                                                                            
         values(@schemeNo, @MembNoToUse,@schemeName, @fullname, @dje, @djpens, @empOpening, @emprOpening, @empcontribution, @emprContribution, @empclosing, @emprClosing,                                                                                 
                @interest, @dateofExit, @curYear, @ServiceTime, @GrandTotal, @taxfreeLumpsum, @withHoldingTax, @vesting, @comments, @EmprInt, @EmpInt,                                                                              
                @ClosingBalance - (@WithholdingTax + @LoanBalance + @OtherDeductions),@TaxAmount,                                                   
                @Reason,@EndDate,@PreparedBy,@CheckedBy,@AuthorisedBy,@ClosingBalance,@Bonus,@TransferInt,@TransferCBal,@TransferOpBal,                                                                                            
                @TransferDesc,@AdditionDesc,@DoCalc,@VestedCont,@TransferCont,@AuditedBy,@DateAudited,@DoBirth,                                                                     
                @TransferIntE,@TransferCBalE,@TransferOpBalE,@TransferContE,@LockedTransfer,                                                                                            
                @DatePrepared,@DateChecked,@DateAuthorised,@Loan,@LoanRepaid,@LoanBalance,@GrandTotal-(@LoanBalance + @OtherDeductions),@Sponsor,@OtherDeductions,                                                                                            

                @ReportTitle,@empclosing + @TransferCBal, @emprClosing + @LockedTransfer,@TaxEmployee,@TaxEmployer,@LoanBalance + @OtherDeductions,@IDNumber,@PoolName,                                             
                @PayrollNo,@MemberNoDesc,@ContPeriod,@DocRefNo,@Salary,@SalFactor,@Gratuity)                  
                  
        /* for the Britak Sun Interface */                  
        Update Benefits set WithBenefit = @GrandTotal,WithTax = @withHoldingTax            
        where schemeNo = @schemeNo and MemberNo = @MemberNo                                            
                                                                                            
                 
     if ((@OptionToUse = 1) and (@Zambia = 0) and (@Mode <> 2))                                                                                           
        Exec CalcPartialPayment  @schemeNo,@MemberNo                                                                                            
                                                                                            
     select @OptionToUse = 0,@EmpClosing = 0,@emprClosing=0,@withHoldingTax=0, @taxfreeLumpsum=0, @vesting=0,@VestedCont=0,@Bonus=0,@TransferCBal=0,                                                                                
              @TransferCBalE=0,@Pre90=0,@ActiveStatus=0,@TaxAmount = 0,@Loan=0,@LoanRepaid=0,@LoanBalance=0,@NetBalance=0,@Sponsor ='',@OtherDeductions = 0,                                                                                          
              @TaxEmployee=0,@TaxEmployer=0,@DeferredPaid = 0,@EmpOpening = 0, @EmprOpening = 0,@empContribution=0,@emprContribution=0,                                                                    
                       @ArEmpCont=0,@ArEmprCont=0,@TransferCont=0,@TransferContE=0,@PayrollNo='',@TransType = 0,                            
              @MembNoToUse='',@DocRefNo = '',@Salary=0,@SalFactor=0,@Gratuity=0                                                                                   
                                                                                            
     fetch next from GenCursor into @schemeNo, @memberNo, @dje, @djpens, @dateofExit, @fullname,@IDNumber,@curYear, @interest,                                                                                            
              @EmpClosing,@emprClosing,@withHoldingTax, @taxfreeLumpsum, @vesting, @comments, @VestedCont,@Bonus,@TransferCBal,                                                                                            
              @TransferCBalE,@Pre90,@ActiveStatus,@DeferredPaid,@PayrollNo,@DocRefNo,@TransType                                        
                                                                                              
end                                                                                            
                                                                                 
close GenCursor                                                                                            
deallocate GenCursor                                   
  SELECT @memberNo = 0,@Ben_Counter = 0                                                                       
  Fetch Next from MemberCsr into @MemberNo,@Ben_Counter                                                                                          
END                                                                                            
Close MemberCsr                                                 
Deallocate MemberCsr                                                                                            
select * from #calculation

go

