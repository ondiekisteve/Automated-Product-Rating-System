CREATE PROCEDURE [dbo].[GetDebitTaxOnArrears]
@SCHEMENO Int,
@DepCode int,
@DepType Int
--with Encryption
as

if object_id('tempdb..#DebitTaxOnArrears') is null

begin
create table #DebitTaxOnArrears
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[DrDesc] [varchar](100) NOT NULL ,
	[Debit] [Decimal](12,2) not  NULL default 0.0,
        [Total] [Decimal](12,2) null default 0.0 
) 

ALTER TABLE #DebitTaxOnArrears WITH NOCHECK ADD 

            
	CONSTRAINT [PK_DebitTaxOnArrears] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end


declare @Desc varchar(50),@Debit decimal(20,2),@YaConversion Varchar(25),@Chapaa decimal(20,2)

if @DepType < 3
Select @Desc = Upper(sName)+', '+fName+' '+Oname +' - Tax on Pension Arrears'
from Dependants
where SchemeNo = @SchemeNo and DependantCode = @DepCode
else
Select @Desc = Upper(sName)+', '+fName+' '+Onames +' - Tax on Pension Arrears'
from members
where SchemeNo = @SchemeNo and MemberNo = @DepCode

if @DepType = 1  	     
select @Debit = Tax from 
MemBeneficiary
where  SchemeNo = @schemeNo and DependantCode = @DepCode
else if  @DepType = 2
select @Debit = Tax from 
PenBeneficiary
where  SchemeNo = @schemeNo and DependantCode = @DepCode
else if  @DepType = 3
select @Debit = ArrTax from 
Pensioner
where  SchemeNo = @schemeNo and MemberNo = @DepCode		

select @YaConversion = cast(@Debit as Varchar(25))
                     Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
                     select @Debit = @Chapaa
                     select @Chapaa = 0
        				 
insert into #DebitTaxOnArrears (drDesc,Debit)
                 Values(@Desc,@Debit)

update #DebitTaxOnArrears set total = @Debit
              
select *  from #DebitTaxOnArrears
go

