/*
 14/04/2013
 
 Change to ensure the recomputation of Income due on resetting the floating rate takes care of acquisitions and disposals in the secondary market

*/

CREATE PROCEDURE [dbo].[Proc_Float_Rate]        
@SchemeNo Int,        
@SecurityNo Int,        
@DueCounter Int,          
@IntRate float,        
@InvMode Int        
--with Encryption        
as        
        
declare @xRate FLOAT,@FaceValue FLOAT,@NumDays float,@interestType smallint,@InvestCode int,  
@MedLevy FLOAT,@WithTax FLOAT,@MediLevy FLOAT,@WithiTax FLOAT,@Income FLOAT,@AcquireFace float,@DisposalFace float,@DateDue datetime         
        
select @xRate = cast(@IntRate as float)        


select @DateDue = DateDue from GovCommIncomeDue where DueCounter  = @DueCounter 
    
if @InvMode=0        
   select @FaceValue = NominalValue,@interestType = interestType,@InvestCode = 4 from GovernmentSecurities where SchemeNo = @SchemeNo and SecurityNo = @SecurityNo        
else if @InvMode = 1        
   select @FaceValue = NominalValue,@interestType = interestType,@InvestCode = 7 from CommercialPaper where SchemeNo = @SchemeNo and PaperNo = @SecurityNo      
  
/*
Sale and Acquisitions
*/

 select @AcquireFace = sum(FaceValue) from GovernmentAcquisition                                              
 where schemeNo = @schemeNo and SecurityNo = @SecurityNo  and TransDate <= @DateDue                                          
                                                                                         
 if @AcquireFace is null select @AcquireFace = 0                                            
                                                      
 select  @DisposalFace = sum(FaceValue) from SaleGovComm                                              
 where schemeNo = @schemeNo and PaperNo = @SecurityNo and TransDate <= @DateDue                                           
                                                                                          
 if @DisposalFace is null select @DisposalFace = 0                                              
                                                       
 select @FaceValue = (@FaceValue + @AcquireFace) - (@DisposalFace)      

select @MedLevy = Max(MedicalLevy),@WithTax = Max(WithholdingTax) from TBL_Invest_TaxRates                                          
where schemeNo = @schemeNo and InvestCode = @InvestCode 
                    
if @MedLevy is null select @MedLevy = 0                                          
if @WithTax is null select @WithTax = 0 

if @DateDue >= 'Jan 1,2013'
   select @MedLevy = 0 
   
if @InvestCode  = 7
   select @WithTax =  0      
    
IF @interestType IS NULL select @interestType = 0    
if @interestType = 1    
begin        
select @NumDays = cast(NumDays as Float) from GovCommIncomeDue where DueCounter = @DueCounter + 1    
    
update TBL_GOV_COMM_FloatRate set InterestRate = @xRate       
where SchemeNo = @schemeNo and DueCounter_FK = @DueCounter + 1    
    
update TBL_GOV_COMM_FloatRate set RateUpdated = 1       
where SchemeNo = @schemeNo and DueCounter_FK <= @DueCounter   
  
select @Income = (@FaceValue * (@xRate/100.0000)) * (@NumDays/365.000)   
  
if @MedLevy > 0                      
   select @MediLevy = (@MedLevy/100.00)* @Income                      
else                      
   select @MediLevy = 0.0                      
               
if @WithTax > 0                      
   select @WithiTax = (@WithTax/100.00)* @Income                      
else                      
   select @WithiTax = 0.00       
         
UPDATE GovCommIncomeDue set Income = @Income,MedLevy = @MediLevy,WithTax = @WithiTax        
Where DueCounter = @DueCounter + 1    
  
    
UPDATE GovCommIncomeDue set RateUpdated = 1 Where DueCounter <= @DueCounter     
end
go

