CREATE PROCEDURE [dbo].[GetDebitRefundAttach]
@SCHEMENO Int,
@PayCode int
--with Encryption
as

if object_id('tempdb..#DebitAttach') is null

begin
create table #DebitAttach
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[DrDesc] [varchar](100) NOT NULL ,
	[Debit] [Decimal](12,2) not  NULL default 0.0,
        [Total] [Decimal](12,2) null default 0.0 
) 

ALTER TABLE #DebitAttach WITH NOCHECK ADD 

            
	CONSTRAINT [PK_DebitAttach] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end

declare @Desc varchar(100),@Amount decimal(20,2),@AttacheeNo int,@MemberNo Int,@FullName varchar(100),
@PayMonth Int,@PayYear Int,@MonthName varchar(30),@YaConversion Varchar(25),@Chapaa decimal(20,2)

Select @AttacheeNo = AttacheeNo,@MemberNo = MemberNo,
@PayMonth = PayMonth,@PayYear= PayYear 
from AttachmentPayroll where SchemeNo = @schemeNo and AttachCode = @PayCode

Exec GetMonthName @PayMonth,@MonthName Out

select @MonthName = @MonthName +', '+cast(@PayYear as varchar(4))

Select @Desc = Upper(sName)+', '+fName +' '+Onames from Members where
SchemeNo = @schemeNo and MemberNo = @MemberNo

Select @Desc = 'Court Attachment Refund for' + @Desc +' - '+@MonthName


        select @Amount = sum(Attachment) from AttachmentPayroll
        where schemeNo = @SchemeNo and AttachCode = @PayCode  and Refund = 1
        
        select @YaConversion = cast(@Amount as Varchar(25))
                     Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
                     select @Amount = @Chapaa
                     select @Chapaa = 0
               
        Insert Into #DebitAttach (drDesc,Debit,Total)
                          Values (@Desc,@Amount,@Amount)			
        
       
select * from #DebitAttach
go

