CREATE PROCEDURE [dbo].[Proc_Unit_Default_Operations] /* Proc_Unit_Default_Operations 1325,'Apr 1,2012','Apr 30,2012' */
@schemeNo Int,
@StartDate datetime,
@EndDate datetime
--with Encryption
as

declare @PeriodClosed smallint

select @PeriodClosed = PeriodClosed from AccountingPeriods where SchemeNo = @schemeNo and EndDate  = @EndDate

Update AccountingPeriods set PeriodClosed  = 0 where SchemeNo = @schemeNo and EndDate  = @EndDate 

Update CashBook set Buy_Sell_Units = 0
where SchemeCode = @schemeNo 
and ChequeDate  >= @StartDate and ChequeDate  <= @EndDate
and Tran_Status = 0 and Posted = 1 and Buy_Sell_Units is null
and BankCode in (select BankCode from SchemeBankBranch where SchemeNo = @schemeNo and Operational  = 1)

Update CashBook set bought_sold_units = 0
where SchemeCode = @schemeNo 
and ChequeDate  >= @StartDate and ChequeDate  <= @EndDate
and Tran_Status = 0 and Posted = 1 and bought_sold_units is null
and BankCode in (select BankCode from SchemeBankBranch where SchemeNo = @schemeNo and Operational  = 1)

/* Transactions to Participate*/
update CashBook set Buy_Sell_Units = 1 where SchemeCode = @schemeNo 
and ChequeDate  >= @StartDate and ChequeDate  <= @EndDate
and Tran_Status = 0 and Posted = 1 and bought_sold_units = 0
and BankCode in (select BankCode from SchemeBankBranch where SchemeNo = @schemeNo and Operational  = 1)
and CashTransNo in ( select CashTransNo from schemeGeneralLedger where schemeCode = @schemeNo
and AccountCode in (2035,2095,1760,4000,4002,4004,4006,6000,6002,6004,6006,6008) and
GLDate >= @StartDate and GLDate <= @EndDate and Tran_Status = 0 and Posted = 1)

Update AccountingPeriods set PeriodClosed  = @PeriodClosed where SchemeNo = @schemeNo and EndDate  = @EndDate
go

