CREATE TRIGGER [dbo].[T_InvestValue_Loans] ON [dbo].[TBL_Loans]   
FOR Insert
AS  
  
declare @SchemeNo Varchar(15),@MortgageNo Int,@BankAcc varchar(30),@username varchar(30)
  
select @schemeNo = schemeNo,@MortgageNo = MortgageNo,@BankAcc = BankAcc from Inserted  
  
select @UserName = user


Exec Proc_Auto_Insert_InvPosting @schemeNo,@MortgageNo,9,210,@MortgageNo,1,@UserName

if @BankAcc is null select @BankAcc ='0'

if @BankAcc <> '0'
begin
if not Exists(select AccountCode from schemeBankBranch where schemeNo = @schemeNo and AccountCode = @BankAcc)
  begin
      raiserror('The Bank account specified has not been set up under the Scheme Bankers in Scheme set up',16,1)
      return
  end
end
go

