CREATE PROCEDURE [dbo].[RepCalculationSheetDB]                                                                
@SCHEMENO Int,                                                                
@memberNo int,                                                                
@Mode Int,                                                                
@batch_id int,                                                                
@report_mode int                                                                
--with Encryption                                                                
as                                                                
                                                                 
set nocount on                                                                
                                                                
if object_id('tempdb..#Calculation') is null                                                                
                                                                
begin                                                                
create table #Calculation                                                                
(                MembCounter Int identity(1,1) Primary Key,                                                
                [SchemeNo] Int null ,                                                                
                [MemberNo] [int] null ,                                                                
                [schemeName][varchar](100) null,                                                                
                [IDnumber][varchar](20) null,                                                        
                [fullname][varchar](100) null,                                                                
                [Sex][varchar](10) null,                                                                
                [Dob][datetime] null,                                                                
                [DJE][Datetime] null,                                                                
                [djpens][datetime] null,                                                                
                [AgeDesc][varchar](50) null,                                                                
                [DateOfExit][datetime] null,                                                                
                [curYear] [int] NULL,                                                                
                [Salary][float] null,                                                                
                [CalcService][int] null,                                                                
                [pastservice][float] null,                                                                
                [comm][float] null,                                                                
                [ServiceTime][varchar](100) null,                                                                
                [PensionFactor][float] null,                                                                
                [Benefits] [float]  NULL ,                                                                
                [BenefitsBC][float] null,                                                                
                [lumpsum] [float]  NULL ,                                                                
                [ResidualPension] [float]  NULL,                                                                
                [TaxfreeLumpsum][float] null,                                                                
                [WithHoldingTax][float] null,                                                                
                [Reason][varchar](25) null,                                                                
                [ReducedPension][float] null,                                   
                [AmountPayable][float] null,                                                           
                [ActFactors][float] null,                                                                
                [TaxableAmount][float]  null,                                                                
                [CalcYears][float] null,                                                                
                [AdjustFactor][float] null,                                                                
                [Adjustment][float] null,                                                                
                [MaxLumpsum][float] null,                                                                
                [LumpFactor][float] null,                                                          
                [CommFactor][float] null,                                            
                [Greater][varchar](3) null,                             
                [CashNotAdjusted][float] null,                                                                
                [Grade][Varchar](40) null,                                                                
                [preparedby][varchar](60) null,                                                                
                [DatePrepared][smalldatetime] null,                                                     
                [CheckedBy][varchar](60) null,                                                                
                [DateChecked][smalldatetime] null,                                                                
                [AuthorisedBy][varchar](60) null,                                                                
                [DateAuthorised][smalldatetime] null,                                      
                [AuditedBy][varchar](60) null,                                                                
                [DateAudited][smalldatetime] null,                                                              
                [BreakInService][Varchar](50),                                                                
                [DoCalc][Datetime],                                                              
                [Vesting][float],                                                                
                [Employee][float],                                                           
                [Deferred][float],                                                                
                [GrandTotal][float],                                                   
                CommFactorRet Decimal(12,6),                                                                
                AccumDeferred decimal(20,2),                                                     
                AccumFactor Decimal(12,6),                                                                
                LumpsumRet decimal(20,2),                                                                
                AnnPension decimal(20,2),                                                                
                LumpRemain Int,                                                              
                EmployeR float,                                                         
                empOpen float,                                                              
                emprOpen float,                                                              
                empCont float,                                                              
                emprCont float,                                                              
                empInt float,                                                              
                emprInt float,                                                              
                DCBenefit float,                                     
                GrandBenefit float,                                                    
  TransferFactor1  decimal(20,4),                                                           
  TransferFactor2  decimal(20,4),                                                    
  GrossRefund decimal(20,4),                                                  
  TransferPension decimal(20,4),                                                    
  TotalTransferOut decimal(20,4),                           
  commutedlumpsum decimal(20,4),                                                    
  Deferredlumpsum decimal(20,4),                                                    
  mukuba int,                                    
  SponsorName varchar(100),                            
  WhichBenefit decimal(20,4),                  
CreditServiceDesc varchar(100))                                                             
                                                                                                                      
end                                                                
                                                                
                       
                                                                
declare @fullname varchar(100)                                                                
declare @schemeName varchar(100)                             
declare @DateOfExit datetime                                                                
declare @pastService float                                                                
declare @Benefits float                                                     
declare @lumpsum float                                                                
declare @ResidualPension float                                                                
declare @comm  float                                                                
declare @PensionFactor float                                                                
declare @taxfreelumpsum float                                                                
declare @withHoldingTax float                                                                
declare @dje datetime                                                  
declare @djpens datetime                                                                
declare @curYear int                                                                
declare @Salary float                                                                
declare @ContrMonth int                                                                
declare @ServiceTime varchar(100)                                                                
declare @dob datetime                                                                
declare @dbMode int                                                                
declare @CalcService float                                 
declare @sex varchar(10)                                                                
declare @Reason varchar(25)                                                                
declare @AgeDesc varchar(50)                                                                
declare @Years int                                                                
declare @ReducedPension float,@IDnumber varchar(20)                                                               
declare @AmountPayable float,@CheckNo int                                                                
declare @CalcYears float, @Greater varchar(3), @Cash float, @Grade                                                                 
varchar(40)                                             
declare @Service int, @TempService int, @AddedServ int, @LumpFactor                                                                 
float, @MaxLumpsum float, @CommFactor float,                                                                
@TaxType Int,@AdjustCash Bit,@JuuFactor float,                                                                 
@LinearInterpolationD bit,@LinearInterpolationC bit,@TotalMonths                                                                 
Int,@NumYears Int,@NumMonths Int,@NumDays Int,                                      
@TotalDays Int,@MaDays Int,@BreakInService Varchar(50),@MaxTaxFree                                                                 
float,@Past Int,@Miezi Int,@HalfMonths Int,@doCalc Datetime,@TelPosta smallInt,                                            
@EMployee float,@Deferred float,@GrandTotal float,@GrandBenefit float                                                                
                                                                
declare @MembSex char(1), @ExitReason int, @AdjustFactor float,                                                                 
@Adjustment float,@HalfDays int,@FullDays int,@commutedlumpsum decimal(20,4)                                                                 
                                   declare @PreparedBy varchar(60), @DatePrepared smalldatetime,                                                                 
@CheckedBy  varchar(60), @dateChecked varchar(60), @AuthorisedBy varchar(60),                                                                 
@DateAuthorised smalldatetime,@AccumFactor Decimal(12,6),@AccumDeferred decimal(20,2),                                                                
@CommFactorRet Decimal(12,6),@LumpsumRet decimal(20,2),@AnnPension decimal(20,2),@TransDate Datetime,                                                              
@EmployeR float,@empOpen float,@emprOpen float,@empCont decimal(20,2),@emprCont decimal(20,2),@empInt float,@emprInt float,                                                              
@AcctPeriod Int,@OptionToUse smallInt,@DCBenefit float,@TransferFactor1 decimal(20,4),@TransferFactor2 decimal(20,4),                                                                
@GrossRefund decimal(20,4),@TransferPension decimal(20,4),@mukuba int,@TransType Int,@TaxAmount float,@CalcTaxFree float,                                    
@SponsorCode Int,@SponsorName varchar(120),@schemeMode smallint,@AuditedBy varchar(50),@DateAudited datetime,                                
@Nsis smallint,@Excargo smallint,@Percent_Lumpsum float,@xBenefit float,@PayGreater smallint,                            
@WhichBenefit decimal(20,4),@CreditService int,@CreditDays int,            
@CreditServiceDesc varchar(150),@kpc smallint,@StatusCode smallint,@DateClosed datetime,      
@FundType int,@EeRate float,@ErRate float,@QualifyPeriod int                        
                                
Exec Proc_Get_Credit_Service @schemeNo,@MemberNo,@CreditService out,@CreditDays out                    
                      
select @CreditServiceDesc = cast(@CreditService as varchar(4))+' months  and '+cast(@CreditDays as varchar(2))+' days '                                                                           
                                                                                                    
select @CalcTaxFree = 0                                      
                                                                
if @Report_Mode = 0                                                                
   declare MemberCsr Cursor for                                                                
   Select MemberNo from Members where schemeNo = @schemeNo and MemberNo = @MemberNo                                                                
else if @Report_Mode = 1                                                                
   declare MemberCsr Cursor for                                                                
   Select MemberNo from TBL_BATCH_MOVEMENTS_DET                                                                
   where schemeNo = @schemeNo and batch_Id = @Batch_Id                                                                
                                     
Open MemberCsr                                                                
fetch from MemberCsr into @memberNo                                                                
while @@fetch_Status = 0                                                                
begin                                                 
if @Mode = 0                                                                
select @Membsex = sex , @ExitReason = ReasonforExit, @Grade = Grade,@doCalc = DoCalc,@Excargo = Excargo                                                                
   from Members where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                
else if @Mode = 1                                                                
   select @Membsex = sex , @ExitReason =ProjectReason, @Grade = Grade ,@doCalc = ProjectDoCalc,@Excargo = Excargo                                                                
   from Members where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                
                                                                
                                
if @Excargo is null select @Excargo = 0                                
                                                                
select @curYear = max(ContrYear) from contributionssummary where                                                          
SchemeNo = @schemeNo and memberNo = @memberNo                                                                
select @ContrMonth  = Max(ContrMonth)  from contributionssummary where                                                       
SchemeNo = @schemeNo and memberNo = @memberNo and ContrYear =                                                  
@CurYear                                                                
                                                                
select @schemeName = schemeName,@TelPosta = TelPosta,@mukuba = mukuba,@dbMode = dbMode,@schemeMode = SchemeMode,                                
@nsis = nsis,@kpc = kpc,@StatusCode = StatusCode,@DateClosed = dateclosed,@FundType = FundTypeCode                                     
from scheme where schemeCode = @schemeNo                                     
                                                               
                                                                                        
if @TelPosta is null select @TelPosta = 0                                     
if @schemeMode is null select @schemeMode = 0                                
if @nsis is null select @nsis = 0            
if @kpc is null select @kpc = 0       
if @FundType is null select @FundType = 1                                                  
                                                                
/* Withdrawals */                                                                
Select @AdjustCash = AdjustCash,@LinearInterpolationD =                                                                 
LinearInterpolationD,                                                                
@LinearInterpolationC = LinearInterpolationC,@PayGreater = PayGreater                                                                 
from ConfigWithdrawal where SchemeNo = @schemeNo                                                                
                                                                
IF @AdjustCash is null select @AdjustCash = 0                            
if @PayGreater is null select @PayGreater = 0                                                                
                                                     
if @Mode = 0                                                               
   declare GenCursor cursor for                                                                
   select m.schemeNo, m.memberNo, m.checkNo, m.dje,m.djpens,m.doExit,m.docalc,                                                                  
 m.dob, case m.Sex when 'M' then 'Male' when 'F' then 'Female' end,                                                       
   (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames))                                                                 
   as fullname,m.IDnumber,b.calcYear,  b.emprcbal, b.withholdingTax,                                                      
   b.taxfreeLumpsum, r.ReasonDesc,b.EmpCBal + VolCBal + PreAvc + PreEmpCBal + EmpTransferCBal,                                                              
   b.EmprCBal + specialCBal + PreEmprCBal + EmprTransferCBal,b.TransType                                                                 
   from Members m                                                                
        inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                        
        inner join ReasonforExit r on m.reasonforexit = r.ReasonCode                                                                
   where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                                                
else if @Mode = 1 /* Projections */                                                                
     declare GenCursor cursor for                                                                
     select m.schemeNo, m.memberNo, m.checkNo,                                                                 
     m.dje,m.djpens,m.ProjectdoExit,m.Projectdocalc, m.dob, case m.Sex when 'M' then 'Male' when 'F' then 'Female'                                                                 
     end,(Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,m.IDnumber,                                                                
     b.calcYear,  b.emprcbal, b.withholdingTax, b.taxfreeLumpsum, r.ReasonDesc,                                                                
     b.EmpCBal + VolCBal + PreAvc + PreEmpCBal + EmpTransferCBal,                                                              
     b.EmprCBal + specialCBal + PreEmprCBal + EmprTransferCBal,b.TransType                                                               
    from Members m                                                                
    inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                                  
    inner join ReasonforExit r on  @ExitReason = r.ReasonCode                                                                
where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                                                
                                                                            
open GenCursor                                                   
                                                                
fetch from GenCursor into @schemeNo, @memberNo, @checkNo, @dje,                             
@djpens, @dateofExit,@DoCalc, @dob, @sex,  @fullname,@IDnumber,  @curYear,                                                                
                                   @lumpsum,@withHoldingTax,                                                                 
@taxfreeLumpsum, @Reason,@Employee,@Employer,@TransType                                                               
                                                                
while @@fetch_status =0                                                                
begin       
      
  /* New Deferment Rules */          
  if (@Mode = 1) -- projections            
     Exec Proc_Get_Defer_Rate @schemeNo,@DoCalc,@FundType,@EeRate out,@ErRate out,@QualifyPeriod Out           
  else          
     select @EeRate  = EeRate,@ErRate = ErRate from Benefits where schemeNo = @schemeNo and MemberNo = @MemberNo   
               
 if @EeRate is null           
     Exec Proc_Get_Defer_Rate @schemeNo,@DoCalc,@FundType,@EeRate out,@ErRate out,@QualifyPeriod Out  
       
  if @Employee is null select @Employee = 0         
  if @Employer is null select @Employer = 0        
                                                              
  if @TransType is null  select @TransType = 0          
          
  if @TransType = 0           
     select @TransType = TransType from ConfigWithDrawal where schemeNo = @schemeNo                                                
                                                                
  select @AcctPeriod = AcctPeriod from schemeYears where schemeNo = @schemeNo                                                        
  and StartDate <= @dOcalc and EndDate >= @dOcalc                                                              
                                                              
  select @empOpen = EmpCont + EmpVolCont + PreEmpCont + PreAvc + Transfer,                                                              
         @emprOpen = EmprCont + EmprVolCont + PreEmprCont + LockedIn                                                              
  from MemberOpeningBalances where schemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1                                                     
                                                              
  if @empOpen is null select @empOpen = 0                                                              
  if @emprOpen is null select @emprOpen = 0                                                              
                                                              
  Exec DBO.Proc_ShowCont  @SCHEMENO, @MemberNo,@DoCalc,@EmpCont output,@EmprCont output                          
                                                              
  Exec DBO.EmployerOption @SCHEMENO,@MemberNo,@OptionToUse Out                                                              
             
                                                           
  if @OptionToUse = 1                                                              
     select @DCBenefit = @Employee                                                              
  else                                                              
     select @DCBenefit = @Employee + @Employer                             
              
            
                          
  if @NSIS = 1 select @DCBenefit = @EmpCont             
  if @kpc = 1 select @DCBenefit = @Employee + @Employer          
          
  if @dcBenefit is null select @dcBenefit = 0            
                                                          
  Exec GetLumpsumFactor @SchemeNo,@doCalc,@LumpFactor out       
      
  /* New Deferment Rules */      
  if @ErRate = 66.67      
     select @LumpFactor = 3      
  else if @ErRate = 50      
     select @LumpFactor = 2      
                                                      
  Exec CalcCommutation @SchemeNo,@MemberNo,@doCalc,@CommFactor out                                             
  Exec GetPensionCFactor @SchemeNo,@MemberNo,@djpens,@doCalc,@PensionFactor out                         
                                                                
  select @MaxLumpsum = MaxLumpPay,@Percent_Lumpsum = Percent_Lumpsum                              
  from Pension_Setup where schemeNo = @schemeNo                                  
                                
  if @Percent_Lumpsum is null select @Percent_Lumpsum = 100.00                                                              
                                                                
  select @salary = CAPenSal,@sponsorCode = SponsorCode,@Excargo = Excargo from Members where SchemeNo = @schemeNo                                                                 
  and memberNo = @memberNo                                    
                                    
  if @SchemeMode = 1                                    
     select @SponsorName = SponsorName from Sponsor where SponsorCode = @sponsorCode  and SchemeNo = @SchemeNo                                    
  else                                    
     select @SponsorName =' '                                         
                                                                
  Exec GetTemporaryService @SchemeNo, @MemberNo,@djpens,                                                                 
@dje,@Tempservice out,@HalfMonths Out,@HalfDays out                                                                
  Exec AddPastService @dateofExit,@djpens,@AddedServ out                                                                
                                                                   
  if @TelPosta = 0           
     begin            
     if ((@StatusCode = 3) and (@dateofExit > @dateClosed))           
        Exec GetServiceTime @djpens,@dateClosed,@NumYears out,@NumMonths Out,@NumDays Out          
     else                                                   
        Exec GetServiceTime @djpens,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out          
          
     end                                                         
  else if @TelPosta = 1                                                                
     Exec GetServiceTime_TelPosta @schemeNo,@MemberNo,@djpens,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out                         
                                                                  
  select @Past =@NumYears                                                                
                            
  select @MaDays = @NumDays                                                                
                                                                
  if @dbMode = 0  /* Months In service */                                                                
        begin                                                                
         select @NumYears = @NumYears + @Tempservice                                     
         select @NumMonths = @NumMonths + @HalfMonths                                                                
                                                                
         IF @NumMonths >= 12                                                                
            SELECT @NumMonths = @NumMonths - 12,@NumYears = @NumYears + 1                                                                
                                                                
         select @PastService = (@NumYears * 12.000) + @NumMonths                                                                
                                                                
         if @HalfDays + @NumDays >= 30                                                                 
           begin                                                                
                 select @AddedServ = 1                                                                
           end                                                                
         else select @AddedServ = 0                                                                
                                                                
         if @HalfDays + @NumDays >= 30                                                                
            select @NumDays = (@HalfDays + @NumDays) - 30                                                                
         else                                                                
            select @NumDays = @HalfDays + @NumDays                                                                
                                                                
         select @NumMonths = @NumMonths + @AddedServ                                                                
                                                                
         select @PastService = @PastService  + cast(@AddedServ as float)                  
                                                    
       select @CalcService = @PastService                                                                
         select @CalcYears = @PastService                    
                                                                
         select @Miezi = cast(@PastService as Integer)                                                                
                                                                
       end                                                                
       else if @dbMode = 1  /* Complete Years in Service */                                                                
       begin                                                                
            select @PastService = @NumYears + @TempService                                      
  select @CalcYears = @PastService                                                 
            select @CalcService = @PastService                                                                
       end                                                                
       else if @dbMode = 2  /* Complete Years in Service Plus Months in Service */                                                                
       begin                                                                
                                                                       
       select @NumYears = @NumYears + @TempService                                                                
       select @NumMonths = @NumMonths + @HalfMonths                                                                
                                                                
       if @HalfDays + @NumDays >= 30 select @AddedServ = 1                                                              
       else                                                                
       select @AddedServ = 0                                                                
                                                                
       select @NumMonths = @AddedServ + @NumMonths                                                                
                                                                
       select @PastService = @NumYears + @NumMonths/12.0000                                  
                                                                
       select @CalcYears = @PastService                                                                
       select @CalcService = @PastService                                                                
                                                                       
       end                                                                
                                                                
      select @serviceTime = cast(@NumYears as varchar(2)) + ' years ' + cast(@NumMonths as varchar(2)) + ' months and '+cast(@NumDays as                                                                 
      Varchar(2))+' Days ' +'  ( i.e  '+cast(((@NumYears * 12)+ @NumMonths) as                                                                 
      Varchar(5))+'  Months )'                                                                 
                                                                        
        select @NumYears = 0,@NumMonths = 0,@NumDays = 0                                                                
                                                                
        Exec GetServiceTime @dob,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out                                                                
        declare @aFactor float,@aYears Int,@aMonths Int,@aDays Int                                                                
                                                                
        select @Years = @NumYears,@aMonths = @NumMonths,@aYears = @NumYears,@aDays = @NumDays                                                                
                                                                
         if @MembSex = 'M'                                                                
           begin                     
                  Exec CalcDeferredFactors @SchemeNo,@MemberNo,@DateofExit,@aFactor out                                                                
                  Exec CalcCashAdjustmentFactors @SchemeNo,@MemberNo,@DateOfExit,@AdjustFactor out                                                                
          end                                                                
        Else                                                                
          begin                                                                
                  Exec CalcDeferredFactors @SchemeNo,@MemberNo,@DateofExit,@aFactor out                                                                
                  Exec CalcCashAdjustmentFactors @SchemeNo,@MemberNo,@DateofExit,@AdjustFactor out                                         
        end                                                         
                                                                 
  /* Interpolate for Deferred Pension Factors*/                                                                
  if @LinearInterpolationD = 0                                                            
     select @JuuFactor = 0.0                                                                
  else if @LinearInterpolationD = 1                                                                
  begin                                                                
   if @MembSex = 'M'           
      select @JuuFactor = MFactor from DeferredPensionFactorsM where                                                           
(Age = @Years + 1) and (SchemeNo = @schemeNo)                                                                
  Else                                
      select @JuuFactor = FDFactor from DeferredPensionFactorsF where                                                         
(Age = @Years + 1) and (SchemeNo = @schemeNo)                                   
  end                                                                
                                                                
  if @aMonths > 0                                                                 
     select @aFactor = @aFactor                                                                 
                                                                
  select @JuuFactor = 0                                                                
                                                                
  /* Interpolate for Cash adjustment Factors */                                                                
  if @LinearInterpolationC = 0                                                                
     select @JuuFactor = 0.0                               
  else if @LinearInterpolationC = 1                                                              
  begin                                                                
   if @MembSex = 'M'                                                                
      select @JuuFactor = MFactor from CashAdjustmentM where (Age =                                                             
@Years + 1) and (SchemeNo = @schemeNo)                                                                
  Else                                                                
      select @JuuFactor = FFactor from CashAdjustmentF where (Age =                                                                 
@Years + 1) and (SchemeNo = @schemeNo)                                                                
  end                                                                
                                                                
  if @AMonths > 0                                                    
     select @AdjustFactor = @AdjustFactor                                                                 
                                                                        
  select @AgeDesc = cast(@aYears as varchar(2)) + ' years ' + cast(@aMonths as varchar(2)) + ' months and '+ cast(@aDays as varchar(2))+ ' days'                                                               
                                                
     select @Comm = 1                                                                
     select @commFactor = 1                                                                
                                                                
     declare @xMonths int                                                                
     declare @yMonths float                                                                
     declare @xYears int                                                  
                                                                
                                                                     
    Exec CalcNonPensionable @schemeNo,@MemberNo,@TotalMonths out,@TotalDays Out                                                                
if @TelPosta = 0                                         
  begin                           
    if @TotalMonths > 0                                                                
       begin                                                                
       if @MaDays < @TotalDays                                                                
          select @CalcYears = @CalcYears - 1                                                                
                                                                
          select @CalcYears = @CalcYears - @TotalMonths                                                                
                                                                          
          select @BreakInService = Cast(@TotalMonths as Varchar(2))+' Months and '+cast(@TotalDays as Varchar(2))+' days'                                                                
                                                                
          /* Reduced Pensionable service */                                                            
          select @PastService = @CalcYears                                                                
       end                                                                
    else if ((@TotalMonths = 0) and (@TotalDays > 0))                                                                
       begin                                                                
          if @MaDays < @TotalDays                                                                
             select @CalcYears = @CalcYears - 1                                                                
                                                                
          select @BreakInService = cast(@TotalDays as Varchar(2)) + '  Days'                                             
       end                                                                
    else                                                                
       select @BreakInService = cast(@TotalDays as Varchar(2)) + '  Days'                                                                
 end                                                                
else if @TelPosta = 1                                                                
  begin                                                                
    select @BreakInService = cast(@TotalDays as Varchar(5)) + ' Days'                                                                
  end                                                                
                                                                
  select @Benefits = (1.000000000/@PensionFactor) * @Salary * @CalcYears                                                               
                                                            
  select @ReducedPension =  @Benefits * @aFactor                                                                
                                                                      
                                                                
   select @xBenefit = @ReducedPension * @CommFactor                                                                
                                                                
     Select @Cash = @xBenefit                                  
                                                                     
     -- Adjustment                                                                
     if (@exitReason = 5) or (@exitReason = 6) or ((@exitReason >= 8)                                                                 
         and (@exitReason <= 20))                                                                
      begin                                                                
          declare @Adjust float, @AdjustValue float                                                                
                                                                
          if @AdjustCash = 0                        
             select @AdjustValue = 0                                                                
          else               begin                                                                
                exec AdjustCashEquivalent @SchemeNo,@Benefits, @Adjust out                                                                
                                                                
                Select @AdjustValue = @Adjust * @AdjustFactor                                                                
                                                                
                IF @AdjustValue is null select @AdjustValue = 0                                                                
   end                                                                
                                                                
          Select @ReducedPension = @ReducedPension - @AdjustValue                                                                
                                         
         if @AdjustValue > 0 select @Greater = 'Yes' else select @Greater = 'No'                                                           
     end                                                                
                          
       /*                                                          
       if (@ReducedPension * @Comm) > @Employee                                                              
            Select @Deferred = (@ReducedPension * @Comm) - @Employee                                                                
       else                                                                
            Select @Deferred = 0.0                                                           
       */                                                         
                             
                                                 
       if (@ReducedPension * @Comm) > @dcBenefit                                                    
            Select @Deferred = @EmployeR                                                                
       else                                                                
            Select @Deferred = @EmployeR                                                                
       /*                                                                  
       if (@ReducedPension * @Comm) > @dcBenefit                                                              
          select @GrandBenefit = (@ReducedPension * @Comm)                                                             
       else                                                              
          select @GrandBenefit = @dcBenefit                                                              
       */                                                          
                                                      
      if @AdjustValue is null select @AdjustValue = 0                                       
                                      
      /*Calculate the TaxFreeLumpsum*/        
      Exec GetTaxFreeLumpsum @schemeNo,@doCalc,@MaxTaxFree out                                                                
                                                                    
          if @Past >= 10                                                                
              begin                                                             
                   select @CalcTaxFree = @MaxTaxFree * 10                                                                
              end                                                                
          else                                                                
              begin                                                                
                  select @CalcTaxFree = ((@MaxTaxFree)*(@Past))                                                                
              end                 
                
      select @EmpCont = @dcBenefit   
  
      if @ErRate = 50   
         select @CalcTaxFree  = @CalcTaxFree * (@ErRate/100.000)         
                
      /*End Calculation of the TaxFreeLumpsum*/                
       if ((@ReducedPension * @Comm) + @AdjustValue + 1) >= @dcBenefit                                                   
          begin        
                                 
             if ((@TransType = 22)  or ((@TransType >= 42)  and (@TransType <= 45))) and (@ExitReason <> 18)                                               
                select @GrandBenefit = (@ReducedPension * @Comm)                                           
             else if ((@TransType = 22)  or ((@TransType >= 42)  and (@TransType <= 45))) and (@ExitReason = 18)                                      
                begin                                               
                select @GrandBenefit = @ReducedPension * @Comm,@TaxFreeLumpsum = @CalcTaxFree                                      
                end                                      
             else if @TransType = 21                                      
                begin                                      
          select @GrandBenefit = @ReducedPension * @Comm,@TaxFreeLumpsum = @CalcTaxFree                                       
                end                                      
             else if @TransType = 46                                      
                begin                                      
                select @GrandBenefit = @ReducedPension * @Comm,@TaxFreeLumpsum = @CalcTaxFree                                       
                end                       
             else if @TransType = 43                                      
                begin                                      
                select @GrandBenefit = @ReducedPension * @Comm,@TaxFreeLumpsum = @CalcTaxFree                     
                end        
             else        
               begin                                               
                select @GrandBenefit = (@ReducedPension * @Comm),@TaxFreeLumpsum = @CalcTaxFree        
               end           
                        
               select @taxfreeLumpsum = (1.000/@LumpFactor) * @taxfreeLumpsum        
        
               if @nsis = 1 select @TransType = 43                                  
         end                                                       
      else                                                  
          begin                                                    
             select @GrandBenefit = @dcBenefit,@TaxFreeLumpsum = @CalcTaxFree                                                 
          end           
                                   
      select @GrandTotal = @GrandBenefit           
                                              
      /* Fix for KPC */                              
      if @ExitReason <> 18                 
         begin                
            if @TransType = 51                 
               select @CommutedLumpsum = @GrandBenefit,@LumpFactor = 1                 
            else                                 
               begin        
                  select @CommutedLumpsum = (1.000/@LumpFactor) * @GrandBenefit         
               end                
         end                                                 
      else                                                  
         select @CommutedLumpsum = @GrandBenefit,@LumpFactor = 1                             
                            
                                      
      if @commutedlumpsum > 0                                  
          select @TaxAmount = @commutedlumpsum - @taxfreeLumpsum                                   
      else                                  
          select @TaxAmount = @GrandBenefit - @taxfreeLumpsum                                                                
                                                              
       if @TaxAmount < 0 select @TaxAmount = 0                                                                
                                                                
       Exec GetTaxType @SchemeNo,@MemberNo,@TaxType Out                                                                
                                                 
       exec  CalculateTax @SchemeNo,@TaxAmount,@doCalc,@TaxType,@WithHoldingTax out                                      
                 
                                  
       if @commutedlumpsum > 0                                  
          select @AmountPayable = @commutedlumpsum - @WithHoldingTax                                    
       else                                                       
          select @AmountPayable = @GrandBenefit - @WithHoldingTax                                                                
                           
       select @PreparedBy = PreparedBy, @DatePrepared = DatePrepared,                                                                 
       @CheckedBy = CheckedBy, @DateChecked = DateChecked,                                                                 
       @AuthorisedBy = AuthorisedBy, @DateAuthorised =                                                                 
       DateAuthorised,@AuditedBy = AuditedBy, @DateAudited =                                                                 
       DateAudited from LumpAuthorization                                                                
       where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                
                                                                
       --Exec Proc_Calc_AccumDeferred @SchemeNo,@MemberNo,@Deferred,@AccumFactor out,@AccumDeferred out,@CommFactorRet out,@LumpsumRet out,@AnnPension out                                                                
                                                            
IF @WithHoldingTax IS null select @WithHoldingTax = 0                                                         
/*MUKUBA tRANSFER OUT*/                                                       
if @mukuba = 1                                                    
begin                                                    
select @TransferFactor1 = Factor1,@TransferFactor2 = Factor2 from TransferOutFactors where age = @aYears                                                    
if @TransferFactor1 is null                                                     
raiserror('Factor1 for age %s is not specified',@aYears,16,1)                                     
if @TransferFactor2 is null                                                     
raiserror('Factor2 for age %s is not specified',@aYears,16,1)                                                     
                                                    
select @grossrefund = @Employee * @TransferFactor1                           
                                         
select @TransferPension = @benefits * @TransferFactor2                                                    
                                        
Update benefits set transferrefund = @grossrefund, TransferPension = @TransferPension where schemeno = @schemeno and memberno = @memberno                                                 
end                                                 
--else                                                
                                        
/*END MUKUBA tRANSFER OUT*/                         
                        
if ((@nsis = 1) and (@TransType = 51))                        
    begin                        
        update Benefits set TransType = @TransType,CashEquivalent = @GrandBenefit,                        
        CashCommLumpsum = @CommutedLumpsum,cashTax = @WithHoldingTax                         
        where schemeNo = @schemeNo and MemberNo = @MemberNo                         
    end                         
else if ((@nsis = 1) and (@TransType = 43))                        
    begin                        
        update Benefits set TransType = @TransType,CashTax = @WithHoldingTax,                    
        TaxFreeLumpsum = @TaxFreeLumpsum,                        
        WithholdingTax = @WithholdingTax                                           
        where schemeNo = @schemeNo and MemberNo = @MemberNo                         
    end                         
else                        
    begin                                     
        Update Benefits set CashTax = @WithHoldingTax,TaxFreeLumpsum = @TaxFreeLumpsum,                        
        WithholdingTax = @WithholdingTax,CashCommLumpsum = @commutedlumpsum                                     
        where schemeNo = @schemeNo and MemberNo = @MemberNo  
  
        if @ErRate = 50  
           Update PartialPayment set AmountPaid = @commutedlumpsum,RegDeferred = @commutedlumpsum                                                           
           where schemeNo = @schemeNo and MemberNo = @MemberNo  
                                                              
    end        
                                                             
insert into #calculation (schemeNo, MemberNo, schemeName,                                                                 
fullname, dje, djpens,dateofexit,curYear, salary, pastservice, serviceTime,                                                                 
dob, comm, CalcService,Benefits, BenefitsBC, lumpsum,                                                   
ResidualPension,TaxfreeLumpsum,withHoldingTax, pensionfactor, sex,                                                                 
Reason, ageDesc, ReducedPension, AmountPayable, ActFactors,                                                          
TaxableAmount, CalcYears, AdjustFactor, Adjustment, MaxLumpsum, LumpFactor, CommFactor, Greater,                
CashNotAdjusted, Grade,preparedBy, DatePrepared,                            
CheckedBy, DateChecked, AuthorisedBy, DateAuthorised,BreakInService,doCalc,Employee,Deferred,GrandTotal,                                                                
AccumFactor,AccumDeferred,CommFactorRet,LumpsumRet,AnnPension,LumpRemain,                                                              
EmpOpen,EmprOpen,EmpCont,EmprCont,Employer,EmpInt,EmprInt,DCBenefit,GrandBenefit,IDnumber,TransferFactor1,                                                               
TransferFactor2,GrossRefund,TransferPension, TotalTransferOut,Mukuba,commutedlumpsum,Deferredlumpsum,                                    
SponsorName,AuditedBy,DateAudited,CreditServiceDesc)                                                                
values(@schemeNo, @CheckNo,@schemeName, @fullname, @dje,                                                                 
@djpens,@dateofExit, @curYear, @salary, @pastService, @ServiceTime, @dob,                                                                 
@commFactor, @CalcYears,@ReducedPension * @Comm, @Benefits, @lumpsum,                                  
@lumpsum, @taxfreeLumpsum , @withHoldingTax, @Pensionfactor, @sex, @Reason,                                                                 
@AgeDesc, @ReducedPension, @AmountPayable,@aFactor, @TaxAmount, @CalcYears, @AdjustFactor,                                                                 
@AdjustValue, @MaxLumpsum, @LumpFactor, @CommFactor, @Greater, @Cash,                                                                 
@Grade,@preparedBy, @DatePrepared, @CheckedBy,                                                                 
@DateChecked, @AuthorisedBy, @DateAuthorised,@BreakInService,@doCalc,@Employee,@Deferred,@GrandTotal,                                        
@AccumFactor,@AccumDeferred,@CommFactorRet,@LumpsumRet,@AnnPension,@LumpFactor - 1,                                                              
@EmpOpen,@EmprOpen,@EmpCont,@EmprCont,@Employer,@Employee - (@EmpOpen + @EmpCont),@Employer - (@EmprOpen + @EmprCont),                                             
@DCBenefit,@GrandBenefit,@IDnumber,@TransferFactor1,@TransferFactor2,@GrossRefund,@TransferPension,                                                    
@GrossRefund+@TransferPension,@mukuba,@commutedlumpsum,@GrandBenefit - @commutedlumpsum,                                    
@SponsorName,@AuditedBy,@DateAudited,@CreditServiceDesc)                                                                
                                                                
select @memberNo = 0, @checkNo=0, @sex='', @fullname='',                                                                
@lumpsum=0,@withHoldingTax=0, @taxfreeLumpsum=0, @reason='',@Employee=0,                                                                
@AccumFactor=0,@AccumDeferred=0,@CommFactorRet=0,@LumpsumRet=0,@AnnPension=0,@Employer = 0,                                                              
@EmpOpen=0,@EmprOpen=0,@EmpCont=0,@EmprCont=0,@TransferFactor1 =0.0,@TransferFactor2 = 0.0,                                                    
@GrossRefund = 0.0 ,@TransferPension =0.0,@TransType=0,@SponsorName ='',@SponsorCode = 0                                                    
                                     
fetch next from GenCursor into @schemeNo, @memberNo, @checkNo,                                                                 
@dje, @djpens, @dateofExit,@DoCalc, @dob,  @sex, @fullname,@IDnumber,  @curYear,                                                                
@lumpsum,@withHoldingTax, @taxfreeLumpsum, @reason,@Employee,@Employer,@TransType                                                               
                            
end                                                                
                                                                
close GenCursor                                                                
deallocate GenCursor                                                          
  Fetch next from MemberCsr into @MemberNo                                                     
END                                                                
cLOSE MemberCsr                                                                
Deallocate MemberCsr                                                                
                                                                
select * from #calculation order by MemberNo
go

