/* Last Modified on 27/4/2005 AT AFFS*/

---tested and Verified  --- Last Modified 09 December 2004
CREATE PROCEDURE [dbo].[RepPersonalBarclays]
@SCHEMENO Int,
@curMonth int,
@CurYear int,
@CertType Int,
@rangestart int,
@rangeend int
--with Encryption
as

set nocount on

if object_id('tempdb..#MemberCertificate') is null

begin
create table #MemberCertificate
(
             [MembNo][Int] identity(1,1),     
	     [SchemeNo] [varchar] (15) NOT NULL ,
             [MemberNo] [int] NOT NULL ,
             [Fullname] [varchar](100) NOT NULL ,
             [curYear][int] not null, 
             [SumAssured] [float]  NULL ,
             [EmpOpBal] [float]not  NULL ,
             [EmprOpBal][float] not null,
             [Empcont][float] not null,
             [EmprCont] [float]  not null ,
             [EmpVolCont][float] null,
             [EmprVolCont][float]  null,
             [EmpInt][float]  NULL ,
             [EmprInt][float]  null,
	     [ClosingBal] [float]  NULL,
             [EmpCBal][float]  null,
             [EmprCBal][float]  null,
             [EmpTransfer][float] not null,
             [EmprTransfer][float] not null,
             [SchemeName][varchar](100) not null,
             [RetirementAge][int] not null,
             [EndingPeriod] [varchar](25) null,
             [StartDate][Datetime],
             [PayrollNo][varchar](20),
             [Dob][Varchar](20),
             [djpens][Varchar](20),
             [Dje][Varchar](20),
             [CurrentAge][Varchar](4),
             [AnnualSalary][float],
             [PreparedBy][varchar](100),
             [ExpectRet][Datetime],
             [PayPoint][Varchar](50),
             [Signatory][Varchar](50),
             [SignatoryTitle][Varchar](50),
             [Period][Varchar](30),
             [SummaryDesc][Varchar](400),
             [EndDate][Datetime],
             [TakeOnEmp][float],
             [TakeOnEmpr][float],
             [MinStartDate][Datetime],
             [OpenDesc][Varchar](400),
             [Comments][Varchar](200),
             [Signing][Varchar](200),
             [SchemeDesc][Varchar](100),
             [JoiningDesc][Varchar](100),
             [SAdmin][Varchar](100),
             [AdminAddress] [Varchar](100),
             [AdminTown] [Varchar](100),
             [AdminDivision] [Varchar](100)
           
) 

ALTER TABLE #MemberCertificate WITH NOCHECK ADD             
	CONSTRAINT [PK_MemberCertReg] PRIMARY KEY  NONCLUSTERED 
	(
		[SchemeNo],
                [MemberNo],
                [MembNo]      
	) 
end

declare @memberNo int
declare @fullname varchar(100)
declare @AnnualSalary float
declare @EmpOpBal float
declare @EmprOpBal float
declare @EmpCont float
declare @EmprCont float
declare @EmpVolCont float
declare @EmprVolCont float
declare @EmpCBal float
declare @EmprCBal float
declare @EmpInt float
declare @EmprInt float
declare @ClosingBal float
declare @AmtCov int
declare @MemberClass varchar(3)
declare @schemeName varchar(100)
declare @RetAge int
declare @EmpTransfer float, @EmprTransfer float
declare @DeathCover Varchar(3)
declare @SumAssured float
declare @MaxYear int
declare @curPeriod varchar(30)
declare @AcctPeriod int, @PeriodToUse int,@StartDate datetime,@PayrollNo varchar(30),@Dob Datetime,@djpens datetime,
@CurrentAge Int,@PreparedBy varchar(100),@ExpectRet Datetime,@LastDate Datetime,@EndDate Datetime,
@PayPoint Varchar(50),@Signatory Varchar(50),@SignatoryTitle Varchar(50),@Period Varchar(30),@SummaryDesc Varchar(400),
@MinAcctPeriod Int,@TakeOnEmp float,@TakeOnEmpr float,@MinStartDate Datetime,@OpenDesc Varchar(400),@ConvertedDate varchar(15),
@Comments Varchar(200),@Signing Varchar(200),@SchemeDesc Varchar(100),@JoiningDesc Varchar(100),@dje Datetime,
@Admin Varchar(100),@AdminAddress Varchar(100),@AdminTown Varchar(100),@AdminDivision Varchar(100),
@DJEConvertedDate Varchar(20),@DOBConvertedDate Varchar(20),@showDob bit,@showDje bit,@ShowPayrollNo Bit,
@showDJPENS bit,@DJPENSconvertedDate Varchar(20),@AgeToStr Varchar(4),@ActiveStatus smallInt,@DoCalc Datetime

select @showDob = showDob,@showDje = showDje,@ShowPayrollNo = ShowPayrollNo,@showDJPENS = showDJPENS
from ConfigYearEnd where SchemeNo = @schemeNo

if @showDob is null select @showDob = 1
if @showDje is null select @showDje = 1
if @ShowPayrollNo is null select @ShowPayrollNo = 1
if @showDJPENS is null select @showDJPENS = 1

select @Admin = ConsultantName,@AdminAddress = Address,@AdminTown = Town,@AdminDivision = AdminDivision
from Scheme_Consultants where SchemeNo = @SchemeNo and ConsultantType = 'Administrator'

if @AdminDivision is null select @AdminDivision = 'Benefit Administration Services'

select @SchemeDesc = 'Name of Scheme',@JoiningDesc = 'Date of Joining Scheme'
Select @MinAcctPeriod = Min(AcctPeriod) from MemberOpeningBalances where SchemeNo = @schemeNo

Select @MinStartDate = EndDate + 1 from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @MinAcctPeriod

select @Signatory  = 'Approved By',@SignatoryTitle = 'Fund Secretary'

/*
@SummaryDesc = 'N.B. The total amount shown above includes interest as provided for in the TDR of the fund (i.e 10% for the Balance B/F and 5% on the current Years'' contributions. The amount due to a member on withdrawal is not neccesarily the sum shown 






above but is subject to the Trust deed and rules of the Fund.'
*/

select @SummaryDesc = 'Note : Subject to the Rules relating to termination of employment, entitlement to a percentage of the Employer''s Contribution will be subject to the Vesting Scales in the Scheme.'

select @SummaryDesc = 'Note : That your entitlement to the Employers'' contribution is dependent on the vesting scale of the scheme.'


Exec DateToStr @MinStartDate,@ConvertedDate Out

select @OpenDesc = 'N.B. '+@ConvertedDate +' Opening Balances apply to members who were contributing then. Nil opening balances apply to members who were refunded their contributions and those recruited after '+ @ConvertedDate

select @Comments = 'Issued in duplicate - copy to be noted and returned to the Fund secretary',
@Signing = 'Sign :_____________________________________                            Date :________________________'

exec GetAccountingPeriodInAYear @schemeNo, @CurMonth, @curYear, @AcctPeriod out

select @PreparedBy = '_________________________________ Fund Manager '--Upper(sName)+', '+fName+' '+Oname from users where UserName = user

Select @PeriodToUse = @AcctPeriod- 1
select @StartDate = StartDate,@EndDate = EndDate from schemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod

select @Period = cast(@StartDate as Varchar(14)) + ' -  '+cast(@EndDate as Varchar(14))

exec GetEndingPeriod @curMonth, @curPeriod out

Exec GetLastDate @CurMonth,@CurYear,@LastDate Out

select @curPeriod = @curPeriod +' '+ cast(@CurYear as varchar(4))

Select @schemeName  = schemeName +' .', @DeathCover = deathCover from Scheme where schemeCode = @schemeNo

declare CertCsr cursor for 
select distinct b.schemeNo, b.memberNo,
(upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.MemberClass,
m.PayrollNo,m.CapenSal,m.dob,m.djpens,m.dje,e.ExpectRet,m.Dept,
m.ActiveStatus,m.DoCalc
from Benefits b inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo and 
                         ((m.ReasonForExit = 0)  or ((m.ReasonforExit > 0) and (m.DoCalc > @EndDate))
                         or ((m.ReasonforExit > 0) and (m.DoCalc <= @EndDate) and (m.ActiveStatus = 6)))
                        inner Join ExpectRet e on b.SchemeNo = e.schemeNo and b.memberNo = e.memberNo
where b.SchemeNo = @schemeNo and b.memberno between @rangestart and @rangeend
order by b.memberNo

Open CertCsr

fetch from CertCsr into @schemeNo, @MemberNo, @fullname, @memberClass,@PayrollNo,@AnnualSalary,@dob,@djpens,@dje,@ExpectRet,
@Paypoint,@ActiveStatus,@DoCalc

while @@fetch_status = 0
begin

Exec DateToStr @dje,@djeConvertedDate Out
Exec DateToStr @dob,@dobConvertedDate Out
Exec DateToStr @djpens,@djpensConvertedDate Out

if @CertType = 0 /* Registered */
begin
select @empOpBal = (empCont + empVolCont), @EmprOpBal = (emprCont + emprVolCont) 
from MemberOpeningBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @PeriodToUse

if @empOpBal is null select @empOpBal = 0
if @emprOpBal is null select @emprOpBal = 0
select @CurrentAge = Datediff(Month,@Dob,@Lastdate)/12

exec RepMemberCertificateContributions @schemeNo, @MemberNo, @curMonth, @curYear,@EmpCont out, @EmprCont out, @EmpVolCont out, @EmprVolCont out

select @EmpCBal = EmpCont + VolContr, @EmprcBal = EmprCont + SpecialContr
from Benefits where SchemeNo = @schemeNo and MemberNo = @MemberNo 

exec RepMemberCertificateTransfer @schemeNo, @MemberNo, @AcctPeriod, @EmpTransfer out,@EmprTransfer out

if @ActiveStatus = 6 and @DoCalc <= @EndDate
   select @empOpBal = 0.0,@EmpTransfer = 0.0,@EmpCBal=0.0,@EmpCont = 0.0,@EmpVolCont = 0.0
end
else if @CertType = 1 /* Frozen Balances */
begin
select @empOpBal = (PreEmpCont + PreAvc), @EmprOpBal = (PreEmprCont) 
from MemberOpeningBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @PeriodToUse

if @empOpBal is null select @empOpBal = 0
if @emprOpBal is null select @emprOpBal = 0

select @CurrentAge = Datediff(Month,@Dob,@Lastdate)/12

exec RepMemberCertificateContributions @schemeNo, @MemberNo, @curMonth, @curYear,
@EmpCont out, @EmprCont out, @EmpVolCont out, @EmprVolCont out

Select @EmpCont = 0,@EmprCont = 0,@EmpVolCont = 0,@EmprVolCont = 0

select @EmpCBal = PreEmpCont + PreAVC, @EmprcBal = PreEmprCont
from Benefits where SchemeNo = @schemeNo and MemberNo = @MemberNo

if @ActiveStatus = 6 and @DoCalc <= @EndDate
   select @empOpBal = 0.0,@EmpTransfer = 0.0,@EmpCBal=0.0,@EmpCont = 0.0,@EmpVolCont = 0.0

end

if @EmpTransfer is null select @EmpTransfer = 0
if @EmprTransfer is null select @EmprTransfer = 0

select  @AmtCov = amtCov from AmountOfCover where SchemeNo = @schemeNo and ClassId = @MemberClass

if @AmtCov is null select @AmtCov = 0

Select @RetAge = MRetAge from RetirementAges where SchemeNo = @schemeNo and ClassId = @MemberClass

IF @empVolcont Is null select @empVolcont = 0
if @EmpTransfer is null select @EmpTransfer = 0

if ((@empCBal  is null) or (@empCBal = 0))

   begin
          select @empCBal = 0
         
          select @EmpInt = 0   
   end
else
  select @EmpInt = (@empCBal - (@empcont + @empVolcont + @empopBal + @EmpTransfer ))

if (@emprCBal  is null) or (@emprCBal = 0)
   begin
          select @emprCBal = 0
   end
else
          select @EmprInt =  (@emprCBal - (@emprcont + @emprVolcont + @empropBal + @EmprTransfer ))

select @SumAssured = @AnnualSalary*@amtCov

if @DeathCover = 'No' select @SumAssured = 0

Select @TakeOnEmp = EmpCont + PreEmpCont + PreAvc + EmpVolCont,@TakeOnEmpr = EmprCont + PreEmprCont + EmprVolCont
from MemberOpeningBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @MinAcctPeriod

if @TakeOnEmp is null select @TakeOnEmp = 0
if @TakeOnEmpr is null select @TakeOnEmpr = 0

if @ShowDje = 0
   select @DJEConvertedDate = '  '

if @ShowDob = 0
   begin
   select @DOBConvertedDate = '  '
   select @AgeToStr = '  '
   end
else
  select @AgeToStr = Cast (@CurrentAge as Varchar(4))

if @ShowPayrollNo = 0
   select @PayrollNo = '  '

if @ShowDJPENS = 0
   select @DJPENSConvertedDate = '  '

insert into #MemberCertificate (schemeNo, MemberNo, fullname, curYear, SumAssured, EmpOpBal, EmprOpBal, EmpCont, EmprCont, 
   EmpVolCont, EmprVolCont, EmpInt,EmprInt, ClosingBal,
   SchemeName, RetirementAge, EmpCBal, EmprCBal, EmpTransfer, EmprTransfer, EndingPeriod,
   PayrollNo,AnnualSalary,dob,djpens,CurrentAge,PreparedBy,StartDate,ExpectRet,Paypoint,Period,Signatory,SignatoryTitle,
   SummaryDesc,EndDate,TakeOnEmp,TakeOnEmpr,MinStartDate,OpenDesc,Comments,Signing,dje,SchemeDesc,JoiningDesc,
   SAdmin,AdminAddress,AdminTown,AdminDivision)

                values(@schemeNo, @Memberno, @fullname, @curYear, @SumAssured, @EmpOpBal, @EmprOpBal, @EmpCont, @EmprCont, @EmpVolCont, @EmprVolCont, 
                           @EmpInt , @EmprInt,  @empCBal + @emprCBal, @SchemeName,

                   @RetAge, @EmpCBal, @EmprCBal, @EmpTransfer, @EmprTransfer, @curPeriod,
                              @PayrollNo,@AnnualSalary,@dobConvertedDate,@djpensConvertedDate,@AgeToStr,@PreparedBy,@StartDate,@ExpectRet,
                      @Paypoint,@Period,@Signatory,@SignatoryTitle,@SummaryDesc,@EndDate,@TakeOnEmp,@TakeOnEmpr,@MinStartDate,@OpenDesc,
                      @Comments,@Signing,@djeConvertedDate,@SchemeDesc,@JoiningDesc,
                      @Admin,@AdminAddress,@AdminTown,@AdminDivision)


select @EmpOpBal = 0
select @EmprOpBal = 0
select @EmpInt = 0
select @EmprInt = 0,@Paypoint = ' ',@TakeOnEmpr=0,@TakeOnEmp=0,
@EmpOpBal = 0, @EmprOpBal=0, @EmpCont=0, @EmprCont=0, @EmpVolCont=0, @EmprVolCont=0, 
@EmpInt=0 , @EmprInt=0,@EmpCBal=0, @EmprCBal=0, @EmpTransfer=0, @EmprTransfer=0,@ActiveStatus = 0

fetch next from CertCsr into @schemeNo, @MemberNo, @fullname, @MemberClass,@PayrollNo,@AnnualSalary,@dob,@djpens,@dje,@ExpectRet,
                             @Paypoint,@ActiveStatus,@DoCalc

end

close certCsr
Deallocate CertCsr


select * from #MemberCertificate where ClosingBal > 0 order by MemberNo
go

