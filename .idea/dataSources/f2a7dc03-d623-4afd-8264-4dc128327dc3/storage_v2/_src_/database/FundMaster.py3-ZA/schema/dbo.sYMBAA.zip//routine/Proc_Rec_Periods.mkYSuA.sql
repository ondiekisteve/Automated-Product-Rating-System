CREATE PROCEDURE [dbo].[Proc_Rec_Periods]      
@schemeNo int,      
@StartDate Datetime,      
@EndDate Datetime,      
@InvestCode Int,      
@Status Int      
--with Encryption      
as     

declare @BondValuation smallint,@CommValuation smallint

select @BondValuation = BondValuation,@CommValuation = CommValuation
from scheme where schemeCode = @schemeNo 


    
if @InvestCode < 20    
begin     
if @Status = 0      
select Distinct TransDate,SchemeNo,Status,case status      
       when 0 then 'Not Certified'      
       when 1 then 'Certified'      
       when 2 then 'Authorised'      
       when 3 then 'Posted' end as RecStatus,InvestCode      
from TBL_Invest_Receivable      
where SchemeNo = @schemeNo and TransDate >= @StartDate and TransDate <= @EndDate      
and InvestCode = @InvestCode and Status < 3      
order by TransDate      
else if @Status = 1      
select Distinct TransDate,SchemeNo,Status,case status      
       when 0 then 'Not Certified'      
       when 1 then 'Certified'      
       when 2 then 'Authorised'      
       when 3 then 'Posted' end as RecStatus,InvestCode      
from TBL_Invest_Receivable      
where SchemeNo = @schemeNo and TransDate >= @StartDate and TransDate <= @EndDate      
and InvestCode = @InvestCode and Status = 3      
order by TransDate      
end    
else if @InvestCode >= 20    
begin 
    if ((@InvestCode = 20) and (@BondValuation = 2)) /* Ammortised Cost */
       begin
           if @Status = 0        
             select distinct EndDate as TransDate,SchemeNo,Status,case status      
             when 0 then 'Not Certified'      
             when 1 then 'Certified'      
             when 2 then 'Authorised'      
             when 3 then 'Posted' end as RecStatus,InvestCode     
             from GovCommMarketValue      
             where SchemeNo = @schemeNo and EndDate >= @StartDate and EndDate <= @EndDate    
             and Status < 3  and InvestCode = 4     
             order by EndDate     
         else if @Status = 1        
            select distinct EndDate as TransDate,SchemeNo,Status,case status      
             when 0 then 'Not Certified'      
             when 1 then 'Certified'      
             when 2 then 'Authorised'      
             when 3 then 'Posted' end as RecStatus,InvestCode     
             from GovCommMarketValue      
             where SchemeNo = @schemeNo and EndDate >= @StartDate and EndDate <= @EndDate    
             and Status = 3  and InvestCode = 4     
             order by EndDate
       end
    else
       begin   
          if @Status = 0        
             select distinct ValuationDate as TransDate,SchemeNo,Status,case status      
             when 0 then 'Not Certified'      
             when 1 then 'Certified'      
             when 2 then 'Authorised'      
             when 3 then 'Posted' end as RecStatus,@Investcode as InvestCode     
             from TBL_Bond_Valuation_Rates      
             where SchemeNo = @schemeNo and ValuationDate >= @StartDate and ValuationDate <= @EndDate    
             and Status < 3      
             order by ValuationDate     
         else if @Status = 1        
            select distinct ValuationDate as TransDate,SchemeNo,Status,case status      
            when 0 then 'Not Certified'      
            when 1 then 'Certified'      
            when 2 then 'Authorised'      
            when 3 then 'Posted' end as RecStatus,@Investcode as InvestCode     
            from TBL_Bond_Valuation_Rates      
            where SchemeNo = @schemeNo and ValuationDate >= @StartDate and ValuationDate <= @EndDate    
            and Status = 3      
            order by ValuationDate 
       end    
end
go

