CREATE VIEW [dbo].[v_Contributions]
AS
  SELECT SchemeNo,
         MemberNo,
         AcctPeriod,
         datePaid,
         EmpCont                                      AS EE,
         EmprCont                                     AS ER,
         VolContr                                     AS AVC,
         SpecialContr                                 AS AVCER,
         ContrMonth,
         ContrYear,
         ExcessEmpCont                                AS EE_Un,
         ExcessEmprCont                               AS ER_Un,
         ExcessVolContr                               AS AVC_Un,
         ExcessSpecial                                AS AVCER_Un,
         dbo.Fn_acctperiod_year(SchemeNo, AcctPeriod) AS SchemeYear,
         'Normal'                                     AS ContType
  FROM   ContributionsSummary
  UNION
  SELECT SchemeNo,
         MemberNo,
         AcctPeriod,
         datePaid,
         ArEmpCont                                    AS EE,
         ArEmprCont                                   AS ER,
         ArVolContr                                   AS AVC,
         ArSpecial                                    AS AVCER,
         ContrMonth,
         ContrYear,
         ArEmpCont_Un                                 AS EE_Un,
         ArEmprCont_Un                                AS ER_Un,
         0                                            AS AVC_Un,
         0                                            AS AVCER_Un,
         dbo.Fn_acctperiod_year(SchemeNo, AcctPeriod) AS SchemeYear,
         'Arrears'                                    AS ContType
  FROM   ContributionArrears
  UNION
  SELECT SchemeNo,
         MemberNo,
         AcctPeriod,
         TransferDate                                 AS datePaid,
         EmpTransfer                                  AS EE,
         EmprTransfer                                 AS ER,
         AVCTransfer                                  AS AVC,
         AVCERTransfer                                AS AVCER,
         Datepart(month, TransferDate)                AS ContrMonth,
         Datepart(Year, TransferDate)                 AS ContrYear,
         0                                            AS EE_Un,
         0                                            AS ER_Un,
         0                                            AS AVC_Un,
         0                                            AS AVCER_Un,
         dbo.Fn_acctperiod_year(SchemeNo, AcctPeriod) AS SchemeYear,
         'Transfers'                                  AS ContType
  FROM   MemberTransfer
  UNION
  SELECT SchemeNo,
         MemberNo,
         AcctPeriod,
         TransferDate                                 AS datePaid,
         0                                            AS EE,
         0                                            AS ER,
         0                                            AS AVC,
         0                                            AS AVCER,
         Datepart(month, TransferDate)                AS ContrMonth,
         Datepart(Year, TransferDate)                 AS ContrYear,
         EmpTransfer                                  AS EE_Un,
         EmprTransfer                                 AS ER_Un,
         AVCTransfer                                  AS AVC_Un,
         AVCERTransfer                                AS AVCER_Un,
         dbo.Fn_acctperiod_year(SchemeNo, AcctPeriod) AS SchemeYear,
         'Transfers'                                  AS ContType
  FROM   MemberTransferUn

go

