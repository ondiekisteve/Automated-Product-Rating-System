CREATE PROCEDURE [dbo].[InsertMemBeneficiary]                                    
@SCHEMENO Int,                                    
@MemberNo int,                                    
@DepCode int,                                    
@Pension float,                                    
@PenNo1 Varchar(15)                                    
--with Encryption                                    
as                                    
                                    
declare @DoDeath datetime,@sName varchar(50),@PenNo Varchar(15),@BenPenReduce Bit,@FullRate Int,@HalfRate Int,                                    
@Guarantee Int,@DoBirth datetime,@doClaim datetime,@Minor smallint,@NumYears int,@NumMonths int,@NumDays Int,                                
@Disabled smallint,@ChildMaxAge int,@DepType Int,@Mukuba smallint,@DecDepCode Int,@DecMonPension decimal(20,2),                          
@EndDate datetime,@HalfDate datetime,@penStartDate datetime,@User varchar(50),@DateCaptured datetime,                    
@cmonth int,@cYear int,@ChangeDate datetime,@stop int,@HasGuardian int,@Guardian int,@Arrears float,@BenLifeGuarantee smallint,    
@ChildLifeGuarantee smallint,@AccountName varchar(155)                          
                            
select @User = user,@DateCaptured = getdate()                    
                    
select @cMonth  = datepart(month,@DateCaptured),@cYear = datepart(Year,@DateCaptured)                        
                        
Exec GetFirstDate @cMonth,@cYear,@ChangeDate out                      
                          
                              
select @Mukuba = Mukuba from scheme where schemeCode = @schemeNo                              
if @Mukuba is null select @Mukuba = 0                                   
                                
select @ChildMaxAge = ChildMaxAge from Pension_setup                                    
where SchemeNo = @schemeNo                                 
                                
if @ChildMaxAge is null select @ChildMaxAge = 18                                   
                                    
Select @BenPenReduce = BenPenReduce,@FullRate = FullRate,@HalfRate = HalfRate,    
       @BenLifeGuarantee = BenLifeGuarantee,@ChildLifeGuarantee = ChildLifeGuarantee from ConfigDeathInservice                                    
where SchemeNo = @schemeNo                                    
    
if @BenLifeGuarantee is null select @BenLifeGuarantee = 1    
if @ChildLifeGuarantee is null select @ChildLifeGuarantee = 0    
                                    
if @BenPenReduce is null                                     
   begin                                    
       select @BenPenReduce = 0                                    
       select @FullRate = 5                                    
       Select @HalfRate = 0                                    
   end                                    
/*                                    
if @DoDeath <= 'Oct 01,2001'                                    
   select @FullRate = 3,@HalfRate = 7                                    
                                    
select @Guarantee = @FullRate + @HalfRate                                    
                                    
if @DoDeath > 'Oct 01,2001'                                    
   Select @HalfRate = @FullRate                                 
*/                                   
                                
select @Guarantee = @FullRate + @HalfRate                                   
                                    
select @sName = Sname,@DoBirth = doB,@doClaim = ClaimDate,@Disabled = Disabled,@DepType = DependantType,      
@DecDepCode = DecDepCode,@HasGuardian = HasGuardian,@Guardian = Guardian,@AccountName = Sname +', '+fname+' '+Oname                                  
from Dependants                                 
where SchemeNo = @SchemeNo and MemberNo = @MemberNo and DependantCode = @DepCode   
  
update Dependants set AccountName = @AccountName   
where SchemeNo = @SchemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                                 
            
select @DecDepCode = 0            
                                
if @Disabled is null select @Disabled = 0                            
if @DecDepCode is null select @DecDepCode = 0      
if @HasGuardian is null select @HasGuardian = 0        
if @Guardian is null select @Guardian = 0                       
                      
select @PenStartDate = @doClaim + 1                                
                                
Exec GetServiceTime @DoBirth,@doClaim,@NumYears Out,@NumMonths Out,@NumDays Out                                  
                            
if @DecDepCode = 0                                
   select @DoDeath = DateofDeath from DeathClaim where SchemeNo = @schemeNo and MemberNo = @MemberNo                            
else                             
   select @DoDeath = DoDeath from BenDeathClaim where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DecDepCode                                 
                              
select @doDeath = DateAdd(Day,1,@DoDeath)                          
                          
    
if @DepType <= 2 /* Spouse */    
   begin     
       if @BenLifeGuarantee = 0 /* Spouse Pension Not guaranteed for Life - pension end after the guaranteed period (fullrate) */    
          begin    
             select @EndDate = DateAdd(Year, @fullRate,@doDeath),@HalfDate = DateAdd(Year,@fullRate,@doDeath)    
          end    
       else    
          select @EndDate = 'Dec 31,9999'    
   end    
else if @DepType >= 3 and @DepType <= 4 /* Child Pension */    
   begin    
       if @ChildLifeGuarantee = 0 /* Child Pension Not guaranteed for Life - pension end after attaining the maximum age to receive pension */    
          begin    
              select @EndDate = DateAdd(Year, @ChildMaxAge,@DoBirth),@HalfDate = DateAdd(Year, @ChildMaxAge,@DoBirth)    
          end    
       else    
          select @EndDate = 'Dec 31,9999'    
   end     
else  /* Other Dependant Types - pension end after the guaranteed period (fullrate) */       
   begin    
      select @EndDate = DateAdd(Year, @fullRate,@doDeath),@HalfDate = DateAdd(Year,@fullRate,@doDeath)    
   end    
    
if @enddate is null /* pension end after the guaranteed period (fullrate) */    
    begin    
       select @EndDate = DateAdd(Year, @fullRate,@doDeath),@HalfDate = DateAdd(Year,@fullRate,@doDeath)    
    end    
    
                     
if @disabled = 1 /* for Beneficiaries with Disability  - Pension paid for Life */                              
   select @EndDate = 'Dec 31,9999'       
     
                             
if @SchemeNo = 1005                                 
exec GetPenNo @schemeNo,@sName,2,@PenNo out                              
else if @Mukuba = 1                              
   begin                              
   exec GetPenNo @schemeNo,@sName,2,@PenNo out                               
   /*                           
   if ((@DepType >= 3) and (@DepType <= 4))                              
      select @PenNo = 'C'+@PenNo                              
   else                              
      select @PenNo = 'S'+@PenNo                              
   */                           
   end        
else        
   select @penNo = @penno1                                   
                  
                                          
if Exists(Select DependantCode from MemBeneficiary where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode)                                    
      begin                   
                  
      Select @Stop = Stop,@Arrears = Arrears from MemBeneficiary                   
      where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode       
      
           
      if @Arrears is null select @Arrears = 0      
      
      if ((@Arrears > 0) and (@HasGuardian = 1) and (@Guardian > 0))      
         begin      
           update MemBeneficiary set Arrears = Arrears + @Arrears      
           where schemeNo = @schemeNo and memberNo = @MemberNo and Dependantcode = @Guardian      
         end                                   
                        
      if @Stop = -1                  
        begin                        
         if @DecDepCode = 0                            
            Update MemBeneficiary  set MonPension = @Pension, StartDate = @DoDeath, EndDate = @EndDate,                                    
            HalfRateDate = @HalfDate,PenNo = @penno                              
            where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                             
         else                            
            Update MemBeneficiary  set DecMonPension = @Pension,PenNo = @penno                                  
            where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                   
        end         
     else                  
        begin                        
         if @DecDepCode = 0                            
            Update MemBeneficiary  set MonPension = @Pension, StartDate = @DoDeath, EndDate = @EndDate,                                    
            HalfRateDate = @HalfDate,PenNo = @penno                                     
            where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                             
         else                            
            Update MemBeneficiary  set DecMonPension = @Pension,PenNo = @penno                                  
            where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode                   
        end         
        
                              
      end                                  
else                        
    Begin                             
         if @DecDepCode = 0                            
             select @DecMonPension = 0                            
         else                            
             select @DecMonPension = @Pension--,@pension = 0                            
                                   
         if @schemeNo = 1005                                    
                 begin                                    
                      insert into MemBeneficiary(SchemeNo, MemberNo, DependantCode, MonPension, StartDate, EndDate, PenNo,                             
                                                 PayType,PayPoint,Paycode,HalfRateDate,DecMonPension,DecArrears,Stop,AccountName)                                    
                      Values(@SchemeNo, @MemberNo, @DepCode, @Pension, @DoDeath, @EndDate,                            
                             @penNo, 4, '1005', 1,@HalfDate,@DecMonPension,0,-1,@AccountName)                      
                      
                      
                      Delete from TBL_Payroll_Changes where schemeNo = @schemeNo and MemberNo = @MemberNo                           
                      and DepCode = @DepCode and ChangeType = 1                            
                            
                      Insert into TBL_Payroll_Changes(schemeNo,MemberNo,DepCode,PenOrBen,MonPension,Bank,Branch,AccountNo,                                        
                                          finBank,FinBranch,FinAccountNo,Paypoint,PaypointBranch,PenFrequency,                                        
                                          FreqstartDate,PayType,Approved,ChangeType,CapturedBy,DateCaptured,ChangeDate)                                        
                      Values(@SchemeNo,@MemberNo,@DepCode,1,@Pension,0,0,'0',0,0,'',                                        
                                         0,0,1,@PenStartDate,4,0,1,@User,@DateCaptured,@ChangeDate)                                     
                 end                               
         else if @Mukuba = 1                                    
                 begin                                    
     insert into MemBeneficiary(SchemeNo, MemberNo, DependantCode, MonPension, StartDate,                             
     EndDate, PenNo, PayType,PayPoint,Paycode,HalfRateDate,                      
                                                 DecMonPension,DecArrears,Stop,AccountName)                                    
                      Values(@SchemeNo, @MemberNo, @DepCode, @Pension, @DoDeath, @EndDate,@penNo, 4, '0',                             
                     1,@HalfDate,@DecMonPension,0,-1,@AccountName)                       
                      
                                            
                      Delete from TBL_Payroll_Changes where schemeNo = @schemeNo and MemberNo = @MemberNo                           
                      and DepCode = @DepCode and ChangeType = 1                            
                            
                      Insert into TBL_Payroll_Changes(schemeNo,MemberNo,DepCode,PenOrBen,MonPension,Bank,Branch,AccountNo,                                        
                                          finBank,FinBranch,FinAccountNo,Paypoint,PaypointBranch,PenFrequency,                                       
                                          FreqstartDate,PayType,Approved,ChangeType,CapturedBy,DateCaptured,ChangeDate)                                        
                      Values(@SchemeNo,@MemberNo,@DepCode,1,@Pension,0,0,'0',0,0,'',                                        
                                         0,0,1,@PenStartDate,1,0,1,@User,@DateCaptured,@ChangeDate)                                    
                 end                                    
         else                                    
                 begin                
                                                       
                     Select @PenNo = @PenNo1                                    
                                    
                     insert into MemBeneficiary(SchemeNo, MemberNo, DependantCode, MonPension, StartDate,                             
                                                  EndDate, PenNo,HalfRateDate,DecMonPension,DecArrears,Stop,AccountName)                                    
                     Values(@SchemeNo, @MemberNo, @DepCode, @Pension, @DoDeath, @EndDate,                            
                             @PenNo,@HalfDate,@DecMonPension,0,-1,@AccountName)                       
                      
                     Delete from TBL_Payroll_Changes where schemeNo = @schemeNo and MemberNo = @MemberNo                           
                      and DepCode = @DepCode and ChangeType = 1                            
                            
                     Insert into TBL_Payroll_Changes(schemeNo,MemberNo,DepCode,PenOrBen,MonPension,Bank,Branch,AccountNo,                                        
                                          finBank,FinBranch,FinAccountNo,Paypoint,PaypointBranch,PenFrequency,                                        
                                          FreqstartDate,PayType,Approved,ChangeType,CapturedBy,DateCaptured,ChangeDate)                                        
                     Values(@SchemeNo,@MemberNo,@DepCode,1,@Pension,0,0,'0',0,0,'',                                        
                                         0,0,1,@PenStartDate,4,0,1,@User,@DateCaptured,@ChangeDate)                                     
                 end                                    
    end
go

