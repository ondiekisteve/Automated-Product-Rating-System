CREATE TRIGGER [dbo].[AuditOpeningBalancesUpdate] on [dbo].[memberOpeningBalances] 
--with Encryption
for update
as 

declare @SchemeNo varchar(15),@MemberNo Int,@SchemeYear Int,
@SchemeMonth Int,@SqlStr varchar(1000),@PrimaryKey varchar(50),
@oEmpCont decimal(20,2),@oEmprCont decimal(20,2),@oEmpVolCont decimal(20,2),@oEmprVolCont decimal(20,2),@oAcctPeriod Int,
@EmpCont decimal(20,2),@EmprCont decimal(20,2),@EmpVolCont decimal(20,2),@EmprVolCont decimal(20,2),@AcctPeriod Int,
@PreEmpCont decimal(20,2),@PreEmprCont decimal(20,2),@PreAvc decimal(20,2),@Transfer decimal(20,2),
@oPreEmpCont decimal(20,2),@oPreEmprCont decimal(20,2),@oPreAvc decimal(20,2),@oTransfer decimal(20,2)

select @SchemeNo = schemeNo,@MemberNo = MemberNo,@SchemeMonth = schemeMonth,@schemeYear = schemeYear,
@oEmpCont = EmpCont,@oEmprCont = EmprCont,@oEmpVolCont = EmpVolCont,@oEmprVolCont = EmprVolCont,
@oAcctPeriod = AcctPeriod,
@oPreEmpCont  = PreEmpCont,@oPreEmprCont  = PreEmprCont,@oPreAvc = PreAvc,@oTransfer  = Transfer from deleted

select @PrimaryKey = @SchemeNo +' - ' + cast(@MemberNo as varchar(15)) +' - ' + cast(@SchemeMonth as varchar(15)) +' - ' + cast(@schemeYear as varchar(15))

select 
@EmpCont = EmpCont,@EmprCont = EmprCont,@EmpVolCont = EmpVolCont,@EmprVolCont = EmprVolCont,
@AcctPeriod = AcctPeriod,
@PreEmpCont  = PreEmpCont,@PreEmprCont  = PreEmprCont,@PreAvc = PreAvc,@Transfer  = Transfer from Inserted

if @EmpCont <> @oEmpCont
begin

select @SqlStr = ('update MemberOpeningBalances set EmpCont = ''' + cast(@OEmpCont as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','EmpCont',@OEmpCont,@EmpCont,@PrimaryKey,getdate(),user,'Employee Balance',@SqlStr)

end

if @EmprCont <> @oEmprCont
begin

select @SqlStr = ('update MemberOpeningBalances set EmprCont = ''' + cast(@OEmprCont as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','EmprCont',@OEmprCont,@EmprCont,@PrimaryKey,getdate(),user,'Employer Balance',@SqlStr)

end

if @EmpVolCont <> @oEmpVolCont
begin

select @SqlStr = ('update MemberOpeningBalances set EmpVolCont = ''' + cast(@OEmpVolCont as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','EmpVolCont',@OEmpVolCont,@EmpVolCont,@PrimaryKey,getdate(),user,'AVC Balance',@SqlStr)

end

if @EmpRVolCont <> @oEmpRVolCont
begin

select @SqlStr = ('update MemberOpeningBalances set EmpRVolCont = ''' + cast(@OEmpRVolCont as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','EmpRVolCont',@OEmpRVolCont,@EmpRVolCont,@PrimaryKey,getdate(),user,'AVC (Employer) Balance',@SqlStr)

end

if @AcctPeriod <> @oAcctPeriod
begin

select @SqlStr = ('update MemberOpeningBalances set AcctPeriod = ''' + cast(@OAcctPeriod as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','AcctPeriod',@OAcctPeriod,@AcctPeriod,@PrimaryKey,getdate(),user,'Accounting Period',@SqlStr)

end



if @PreEmpCont <> @oPreEmpCont
begin

select @SqlStr = ('update MemberOpeningBalances set PreEmpCont = ''' + cast(@oPreEmpCont as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','PreEmpCont',@OPreEmpCont,@PreEmpCont,@PrimaryKey,getdate(),user,'Employee Frozen Balance',@SqlStr)

end


if @PreEmprCont <> @oPreEmprCont
begin

select @SqlStr = ('update MemberOpeningBalances set PreEmprCont = ''' + cast(@oPreEmpCont as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','PreEmprCont',@OPreEmprCont,@PreEmprCont,@PrimaryKey,getdate(),user,'Employer Frozen Balance',@SqlStr)

end

if @PreAvc <> @oPreAvc
begin

select @SqlStr = ('update MemberOpeningBalances set PreAvc = ''' + cast(@oPreAvc as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','PreAvc',@OPreAvc,@PreAvc,@PrimaryKey,getdate(),user,'AVC Frozen Balance',@SqlStr)

end

if @TransFER <> @oTransfer
begin

select @SqlStr = ('update MemberOpeningBalances set Transfer = ''' + cast(@oTransfer as varchar(15)) + '''  where SchemeNo = ' + cast(@SchemeNo as varchar(15)) + ' and MemberNo = ' + cast(@MemberNo as varchar(15)) + ' and schemeMonth = ' + cast(@schemeMonth as varchar(15)) + ' and schemeYear = ' + cast(@schemeYear as varchar(15)))
insert into Audit_Details
(TableName,FieldName,OldValue,NewValue,PrimaryKey,TransDate,UserName,FieldDesc,ReverseQuery)
values
('Member Opening Balances','Transfer',@OTransfer,@Transfer,@PrimaryKey,getdate(),user,'Transfer Balance',@SqlStr)

end
go

