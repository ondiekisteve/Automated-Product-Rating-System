--select * from Benefits where schemeNo = 1247 and MemberNo = 356

CREATE PROCEDURE [dbo].[Proc_Sort_Benefits]
@SCHEMENO Int,
@StartDate Datetime,
@EndDate Datetime
as

declare @totEmpCont float,
@totEmprCont float,
@totVolContr float,
@totSpecialContr float,
@EmpInterest float,
@EmprInterest floAT,
@VolInterest float,
@SpecInterest float,@MemberNo Int,@CalcMonth Int,@CalcYear Int,
@DoCalc Datetime

select @CalcMonth = DatePart(Month,@StartDate)
select @CalcYear = DatePart(Year,@StartDate)

declare BenCsr Cursor for
select MemberNo,DoCalc from Members
where schemeNo = @schemeNo and reasonforExit > 0
and DoCalc >= @StartDate and DoCalc <= @EndDate

open BenCsr
fetch from BenCsr Into @MemberNo,@DoCalc
while @@fetch_Status = 0
begin
    /* Registered */
   Exec Proc_CalcMonthlyInterestAVGCOMP 0,@schemeNo,@MemberNo,@CalcMonth,@CalcYear,1,0,
   @totEmpCont output,
   @totEmprCont output,
   @totVolContr output,
   @totSpecialContr output,
   @EmpInterest Output,
   @EmprInterest Output,
   @VolInterest Output,
   @SpecInterest Output

   update Benefits Set EmpCBal = @totEmpCont,EmprCBal = @totEmprCont,VolCBal = @totVolContr,
   EmpInt = @EmpInterest,EmprInt = @EmprInterest,VolInt =  @VolInterest
   where schemeNo = @schemeNo and MemberNo = @MemberNo

   select @totEmpCont  =0,@totEmprCont = 0,@totVolContr = 0,@totSpecialContr=0,
   @EmpInterest=0,@EmprInterest=0,@VolInterest =0,@SpecInterest =0
   
   /* Un Registered */
   if Exists (Select * from UnRegisteredBenefits where schemeNo = @schemeNo and MemberNo = @MemberNo)
   begin
      Exec Proc_CalcMonthlyInterestAVGCOMP_UN 0,@schemeNo,@MemberNo,@CalcMonth,@CalcYear,1,0,
      @totEmpCont output,
      @totEmprCont output,
      @totVolContr output,
      @totSpecialContr output,
      @EmpInterest Output,
      @EmprInterest Output,
      @VolInterest Output,
      @SpecInterest Output

      update UnRegisteredBenefits Set EEmpCBal = @totEmpCont,EEmprCBal = @totEmprCont,eVolCBal = @totVolContr,
      EmpInt = @EmpInterest,EmprInt = @EmprInterest,VolInt =  @VolInterest,
      EmpTax = @EmpInterest *.30,@EmprInterest = @EmprInterest * .30
      where schemeNo = @schemeNo and MemberNo = @MemberNo
   end

   Exec Proc_Calculate_Fees_To_Reserve @schemeNo,@MemberNo,@DoCalc

   Exec Proc_Calculate_Forfeitures_To_Reserve @schemeNo,@MemberNo,@DoCalc

   select @totEmpCont  =0,@totEmprCont = 0,@totVolContr = 0,@totSpecialContr=0,
   @EmpInterest=0,@EmprInterest=0,@VolInterest =0,@SpecInterest =0,@MemberNo = 0,
   @DoCalc = GetDate()

  fetch next from BenCsr Into @MemberNo,@DoCalc
end
Close BenCsr
Deallocate BenCsr
go

