CREATE PROCEDURE [dbo].[RepDBAllYears]
@schemeNo varchar(15)
--with Encryption
as
select d.schemeNo, d.ContrYear, d.EmprCont,
       s.SchemeName, m.MonthName
from dbContribution d
    inner Join scheme s on d.schemeNo = s.schemeCode
    inner Join MonthTable m on d.ContrMonth = m.MonthNumber
where d.SchemeNo = @schemeNo 
order by d.ContrYear,d.ContrMonth
go

