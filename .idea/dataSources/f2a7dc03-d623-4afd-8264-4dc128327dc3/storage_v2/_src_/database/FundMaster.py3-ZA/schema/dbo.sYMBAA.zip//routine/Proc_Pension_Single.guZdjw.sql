CREATE PROCEDURE [dbo].[Proc_Pension_Single]
@SchemeNo Int,
@MemberNo Int,
@PayMonth Int,
@PayYear Int
--with Encryption
as

if object_id('tempdb..#tt_Pension_Single') is null

begin
create table #tt_Pension_Single
(
        [PenCounter][Int] identity(1,1),
	[schemeNo] [int],
	[MemberNo] [Int],
        [PayMonth][Int],
        [PayYear][Int],
        [MonthName][varchar](30),
        [Gross][Decimal](12,2),
        [Tax][Decimal](12,2),
        [Arrears][Decimal](12,2),
        [Net][Decimal](12,2),
        [Paypoint][varchar](200),
        [Hold][Int],
        [MonthSuspended][varchar](30),
        [SuspenseReason][varchar](150),
        [ChequeReturned][Int],
        [DateReturned][Datetime],
        [ReturnReason][varchar](150),
        [ChequeNo][Varchar](20)  
) 

ALTER TABLE #tt_Pension_Single WITH NOCHECK ADD 

            
	CONSTRAINT [PK_#tt_Pension_Single] PRIMARY KEY  NONCLUSTERED 
	(
	  [PenCounter]      
	) 
end

declare @Gross Decimal(20,6),@Arrears Decimal(20,6),@Tax Decimal(20,6),
@MonthName varchar(30),@Paypoint varchar(200),@bank int,@branch int,@AcctNo varchar(20),
@BankName varchar(200),@BranchName varchar(100),@PayType int,@Hold Int,@StopMonth Int,@StopYear Int,
@StopReason Int,@StopDesc varchar(100),@MonthSuspended  varchar(30),@DateReturned Datetime,
@ReturnReason varchar(150),@ChequeNo Varchar(20)

Declare PenCsr Cursor for
Select p.Gross,p.Tax,p.PayMonth,p.PayYear,p.Bank,p.Branch,p.AcctNo,p.Hold
from PensionPayroll p
where p.schemeNo = @schemeNo and p.MemberNo = @MemberNo and p.PayType = 1
and P.PayMonth = @PayMonth and p.PayYear = @PayYear

open PenCsr
Fetch from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo,@Hold
while @@fetch_Status = 0
begin
  if @Hold is null select @Hold = 0

  IF @Hold = 1
     begin
     select @StopYear = Max(StopYear) from PensionStoppage
     where schemeNo = @schemeNo and MemberNo = @MemberNo
     and StopYear <= @PayYear

     select @StopMonth = Max(StopMonth) from PensionStoppage
     where schemeNo = @schemeNo and MemberNo = @MemberNo
     and StopYear = @StopYear


     select @StopReason = StoppageType from PensionStoppage
     where schemeNo = @schemeNo and MemberNo = @MemberNo
     and StopYear = @StopYear and StopMonth = @StopMonth

     select @StopDesc = Description from Pension_Stop_setup
     where StopCode = @StopReason

     Exec GetMonthName @StopMonth,@MonthSuspended Out

     select @MonthSuspended = @MonthSuspended +', '+cast(@StopYear as varchar(4))

     end
 else
     select @MonthSuspended='',@StopDesc=''
 
 select @DateReturned = ReturnDate, @ReturnReason = Reason,@ChequeNo = ChequeNo from UnclaimedCheques where schemeNo = @schemeNo and MemberNo = @MemberNo
 and PayMonth = @PayMonth and PayYear = @PayYear


  Exec GetMonthName @PayMonth,@MonthName Out

  select @BankName = BankName from Bank_setup where BankCode = @Bank
  select @BranchName = BranchName from Bank_Branch where BankCode = @Bank
  and BranchCode = @branch

  Insert Into #tt_Pension_Single(schemeNo,MemberNo,PayMonth,PayYear,MonthName,Gross,Tax,Arrears,Net,Paypoint,Hold,
                                 MonthSuspended,SuspenseReason,ChequeReturned,DateReturned,
                                 ReturnReason,ChequeNo)
                  Values(@schemeNo,@MemberNo,@PayMonth,@PayYear,@MonthName+', '+cast(@PayYear as varchar(4)),
                         @Gross,@Tax,0.0,@Gross - @Tax,@BankName+' - '+@BranchName+' - '+@AcctNo,@Hold,
                         @MonthSuspended,@StopDesc,0,@DateReturned,@ReturnReason,@ChequeNo)

  select @Gross=0,@Tax=0,@PayMonth=0,@PayYear=0,@Bank=0,@Branch=0,@AcctNo='',@BankName ='',
         @BranchName='',@Hold = 0
  Fetch next from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo,@Hold
end
Close PenCsr
Deallocate PenCsr

/* Financial Institutions */
Declare PenCsr Cursor for
Select p.Gross,p.Tax,p.PayMonth,p.PayYear,p.FinCode,p.FinBrCode,p.FinAcctNo
from PensionPayroll p
where p.schemeNo = @schemeNo and p.MemberNo = @MemberNo and p.PayType = 2
and P.PayMonth = @PayMonth and p.PayYear = @PayYear

open PenCsr
Fetch from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
while @@fetch_Status = 0
begin
  Exec GetMonthName @PayMonth,@MonthName Out

  select @BankName = FinName from FinInstitutions where FinCode = @Bank
  select @BranchName = FinBrName from FinInstitutionsBranch where FinCode = @Bank
  and FinBrCode = @branch
if @Tax is null select @Tax =0.0
if @Gross is null select @Gross =0.0

  Insert Into #tt_Pension_Single(schemeNo,MemberNo,PayMonth,PayYear,MonthName,Gross,Tax,Arrears,Net,Paypoint)
                  Values(@schemeNo,@MemberNo,@PayMonth,@PayYear,@MonthName+', '+cast(@PayYear as varchar(4)),
                         @Gross,@Tax,0.0,@Gross - @Tax,@BankName+' - '+@BranchName+' - '+@AcctNo)

  select @Gross=0,@Tax=0,@PayMonth=0,@PayYear=0,@Bank=0,@Branch=0,@AcctNo=' ',@BankName =' ',
         @BranchName=' '
  Fetch next from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
end
Close PenCsr
Deallocate PenCsr

/* Direct Payments */
Declare PenCsr Cursor for
Select p.Gross,p.Tax,p.PayMonth,p.PayYear,p.FinCode,p.FinBrCode,p.FinAcctNo
from PensionPayroll p
where p.schemeNo = @schemeNo and p.MemberNo = @MemberNo and p.PayType = 3
and P.PayMonth = @PayMonth and p.PayYear = @PayYear

open PenCsr
Fetch from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
while @@fetch_Status = 0
begin
  Exec GetMonthName @PayMonth,@MonthName Out

  select @BranchName = Address +'   '+TownAddress from Members where schemeNo = @schemeNo and MemberNo = @MemberNo

if @Tax is null select @Tax =0.0
if @Gross is null select @Gross =0.0

  Insert Into #tt_Pension_Single(schemeNo,MemberNo,PayMonth,PayYear,MonthName,Gross,Tax,Arrears,Net,Paypoint)
                  Values(@schemeNo,@MemberNo,@PayMonth,@PayYear,@MonthName+', '+cast(@PayYear as varchar(4)),
                         @Gross,@Tax,0.0,@Gross - @Tax,@BranchName)

  select @Gross=0,@Tax=0,@PayMonth=0,@PayYear=0,@Bank=0,@Branch=0,@AcctNo=' ',@BankName =' ',
         @BranchName=' '
  Fetch next from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
end
Close PenCsr
Deallocate PenCsr

/* Paypoints */
Declare PenCsr Cursor for
Select p.Gross,p.Tax,p.PayMonth,p.PayYear,p.Paypoint,p.PayCode,p.FinAcctNo
from PensionPayroll p
where p.schemeNo = @schemeNo and p.MemberNo = @MemberNo and p.PayType = 4
and P.PayMonth = @PayMonth and p.PayYear = @PayYear

open PenCsr
Fetch from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
while @@fetch_Status = 0
begin
  Exec GetMonthName @PayMonth,@MonthName Out

  select @BankName = PaypointName from Paypoints where PaypointCode = @Bank
  select @BranchName = BranchName from PaypointsBranch where PaypointCode = @Bank
  and BranchCode = @branch
if @Tax is null select @Tax =0.0
if @Gross is null select @Gross =0.0

  Insert Into #tt_Pension_Single(schemeNo,MemberNo,PayMonth,PayYear,MonthName,Gross,Tax,Arrears,Net,Paypoint)
                  Values(@schemeNo,@MemberNo,@PayMonth,@PayYear,@MonthName+', '+cast(@PayYear as varchar(4)),
                         @Gross,@Tax,0.0,@Gross - @Tax,@BankName+' - '+@BranchName)

  select @Gross=0,@Tax=0,@PayMonth=0,@PayYear=0,@Bank=0,@Branch=0,@AcctNo=' ',@BankName =' ',
         @BranchName=' '
  Fetch next from PenCsr into @Gross,@Tax,@PayMonth,@PayYear,@Bank,@Branch,@AcctNo
end
Close PenCsr
Deallocate PenCsr

select * from #tt_Pension_Single order by PayYear,PayMonth
go

