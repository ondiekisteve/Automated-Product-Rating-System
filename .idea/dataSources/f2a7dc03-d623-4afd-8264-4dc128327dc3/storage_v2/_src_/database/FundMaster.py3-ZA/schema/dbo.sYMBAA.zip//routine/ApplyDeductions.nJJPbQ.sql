CREATE PROCEDURE [dbo].[ApplyDeductions]  
@SCHEMENO Int,  
@PayMonth int,  
@PayYear int,
@Proc_Mode Int /* 0 - Pensioner, 1 - Dependants */  
--with Encryption  
as  
  
declare @MemberNo int,@DepCode Int,@Deduction Decimal(20,6)  

if @Proc_Mode = 0 /* Pensioners */ 
begin  
declare Acsr cursor for  
Select MemberNo,sum(Amount)  
from MemberDeductionsPayment  
where SchemeNo = @schemeNo and DeductMonth = @PayMonth and DeductYear = @PayYear 
and DependantCode = 0 
group by MemberNo  
  
Open acsr   
fetch from acsr into @MemberNo,@Deduction  
  
while @@Fetch_Status =0  
begin  
   if @Deduction is null select @Deduction = 0  
  
   update PensionPayroll set Net = Net - @Deduction   
   where SchemeNo = @schemeNo and MemberNo = @MemberNo   
   and PayMonth = @PayMonth and PayYear = @PayYear  
   Select @Deduction = 0  
  
   select @Deduction = 0  
  
   fetch from acsr into @MemberNo,@Deduction  
end  
Close Acsr  
Deallocate acsr  
  
Select @Deduction = 0  
  
declare Acsr cursor for  
Select MemberNo,sum(Attachment)  
from AttachmentPayroll  
where SchemeNo = @schemeNo and Paymonth = @PayMonth and PayYear = @PayYear  
group by MemberNo  
  
Open acsr   
fetch from acsr into @MemberNo,@Deduction  
  
while @@Fetch_Status =0  
begin  
  
   if @Deduction is null select @Deduction = 0  
  
   update PensionPayroll set Net = Net - @Deduction   
   where SchemeNo = @schemeNo and MemberNo = @MemberNo   
   and PayMonth = @PayMonth and PayYear = @PayYear  
  
   Select @Deduction = 0  
  
   fetch from acsr into @MemberNo,@Deduction  
end  
Close Acsr  
Deallocate acsr
end
else if @Proc_Mode = 1 /* Dependants */ 
begin  
declare Acsr cursor for  
Select MemberNo,DependantCode,sum(Amount)  
from MemberDeductionsPayment  
where SchemeNo = @schemeNo and DeductMonth = @PayMonth and DeductYear = @PayYear 
and DependantCode > 0 
group by MemberNo,DependantCode  
  
Open acsr   
fetch from acsr into @MemberNo,@DepCode,@Deduction  
  
while @@Fetch_Status =0  
begin  
   if @Deduction is null select @Deduction = 0  
  
   update PensionPayrollBen set Net = Net - @Deduction   
   where SchemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode   
   and PayMonth = @PayMonth and PayYear = @PayYear  
   Select @Deduction = 0  
  
   select @Deduction = 0,@MemberNo=0,@DepCode=0  
  
   fetch from acsr into @MemberNo,@DepCode,@Deduction  
end  
Close Acsr  
Deallocate acsr   
end
go

