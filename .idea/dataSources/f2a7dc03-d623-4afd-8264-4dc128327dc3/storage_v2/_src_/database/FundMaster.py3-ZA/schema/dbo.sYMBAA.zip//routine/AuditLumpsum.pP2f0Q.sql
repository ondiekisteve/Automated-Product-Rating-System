CREATE PROCEDURE [dbo].[AuditLumpsum]
@SCHEMENO Int,
@MemberNo int,
@username varchar(60)
--with Encryption
as

update LumpAuthorization set AuditedBy = @username, DateAudited = Getdate(), Audited = 1
where SchemeNo = @schemeNo and MemberNo =  @MemberNo
go

