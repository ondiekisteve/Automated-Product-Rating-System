/* Calculate Pensioner Deductions from Monthly Payroll */    
CREATE PROCEDURE [dbo].[DeductionsPayroll]    
@SCHEMENO Int,    
@PayMonth int,    
@PayYear int,  
@Proc_Mode int /* 0 - Pensioners , 1 - Dependants */    
--with Encryption    
as    
    
declare @MemberNo int, @Net Decimal(20,6), @Deduct int, @DeductAmt Decimal(20,6), @Instal Int, @Amt Decimal(20,6),    
@TotalDeduct Decimal(20,6), @AmtPaid Decimal(20,6), @DeductMode int,@Stopped int, @StopDate datetime,@sDate datetime,    
@YaConversion varchar(25),@Chapaa Decimal(20,6),@DependantCode int,@DatePaid datetime 

Exec GetFirstDate @PayMonth,@PayYear,@DatePaid out   
  
if @Proc_Mode = 0 /* Pensioner Deductions */   
begin    
if not Exists (Select DeductCode from MemberDeductionsPayment   
               where SchemeNo = @SchemeNo and DeductMonth = @PayMonth and DeductYear = @PayYear and DependantCode = 0)    
begin    
  
select @TotalDeduct = 0    
select @Amt = 0    
    
declare DeductCsr Cursor for    
select d.MemberNo, d.DeductCode, d.Deduction, d.Instalments, d.DeductMode,d.StopDate    
from MemberDeductions  d    
        inner Join Pensioner p on d.schemeNo = p.schemeNo and d.MemberNo = p.MemberNo and p.Alive = 1    
where d.SchemeNo = @SchemeNo and d.Stopped = 0    
order by d.MemberNo, d.DeductCode    
    
    
Open DeductCsr    
    
fetch from DeductCsr into @MemberNo, @Deduct, @DeductAmt, @Instal, @DeductMode,@StopDate    
    
while @@fetch_Status = 0    
begin    
          Exec getFirstDate @PayMonth,@PayYear,@sDate out    
            
          if @sDate <= @stopDate    
             begin    
    
          if @DeductMode = 0    
             begin    
                 select @Amt = @DeductAmt/@Instal    
                   /* rounding  gross*/    
                 select @YaConversion = cast(@Amt as Varchar(25))    
                 Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out    
                 select @Amt = @Chapaa    
                 select @Chapaa = 0,@YaConversion ='0'     
              
                  insert into MemberDeductionsPayment (SchemeNo, MemberNo, DependantCode, DeductCode, DatePaid, Amount, DeductMonth, DeductYear)    
                  Values(@SchemeNo, @MemberNo, 0, @Deduct, @DatePaid, @Amt, @PayMonth, @PayYear)    
              
                  select @TotalDeduct = @Amt    
              
                  select @Amt = 0.0    
                         
              
                  select @AmtPaid = 0    
             end    
         else    
             begin    
                        
                  select @Amt = @DeductAmt    
                  select @TotalDeduct = @Amt    
    
                   /* rounding  gross*/    
                 select @YaConversion = cast(@Amt as Varchar(25))    
                 Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out    
                 select @Amt = @Chapaa    
                 select @Chapaa = 0,@YaConversion ='0'     
    
                  insert into MemberDeductionsPayment (SchemeNo, MemberNo, DependantCode, DeductCode, DatePaid, Amount, DeductMonth, DeductYear)    
                  Values(@SchemeNo, @MemberNo, 0, @Deduct, @DatePaid, @Amt, @PayMonth, @PayYear)      
             end    
             
          Select @TotalDeduct = 0      
               
            end      
          fetch next from DeductCsr into @MemberNo, @Deduct, @DeductAmt, @Instal, @DeductMode,@StopDate    
     end    
Close DeductCsr    
Deallocate DeductCsr    
end    
  
end  
else if @Proc_Mode = 1 /* Dependants Deductions */   
begin    
if not Exists (Select DeductCode from MemberDeductionsPayment   
               where SchemeNo = @SchemeNo and DeductMonth = @PayMonth and DeductYear = @PayYear and DependantCode > 0)    
begin    
    
select @TotalDeduct = 0    
select @Amt = 0    
    
declare DeductCsr Cursor for    
select d.MemberNo, d.DependantCode, d.DeductCode, d.Deduction, d.Instalments, d.DeductMode,d.StopDate    
from MemberDeductions  d    
        inner Join Dependants p on d.schemeNo = p.schemeNo and d.MemberNo = p.MemberNo   
        and d.DependantCode = p.DependantCode and p.Alive = 1    
where d.SchemeNo = @SchemeNo and d.Stopped = 0    
order by d.MemberNo, d.DeductCode    
    
    
Open DeductCsr    
    
fetch from DeductCsr into @MemberNo, @DependantCode,@Deduct, @DeductAmt, @Instal, @DeductMode,@StopDate    
    
while @@fetch_Status = 0    
begin    
          Exec getFirstDate @PayMonth,@PayYear,@sDate out    
            
          if @sDate <= @stopDate    
             begin    
    
          if @DeductMode = 0    
             begin    
                 select @Amt = @DeductAmt/@Instal    
                   /* rounding  gross*/    
                 select @YaConversion = cast(@Amt as Varchar(25))    
                 Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out    
                 select @Amt = @Chapaa    
                 select @Chapaa = 0,@YaConversion ='0'     
              
                  insert into MemberDeductionsPayment (SchemeNo, MemberNo, DependantCode, DeductCode, DatePaid, Amount, DeductMonth, DeductYear)    
                  Values(@SchemeNo, @MemberNo, @DependantCode, @Deduct, @DatePaid, @Amt, @PayMonth, @PayYear)    
              
                  select @TotalDeduct = @Amt    
              
                  select @Amt = 0.0    
                         
              
                  select @AmtPaid = 0    
             end    
         else    
             begin    
                        
                  select @Amt = @DeductAmt    
                  select @TotalDeduct = @Amt    
    
                   /* rounding  gross*/    
                 select @YaConversion = cast(@Amt as Varchar(25))    
                 Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out    
                 select @Amt = @Chapaa    
                 select @Chapaa = 0,@YaConversion ='0'     
    
                  insert into MemberDeductionsPayment (SchemeNo, MemberNo, DependantCode, DeductCode, DatePaid, Amount, DeductMonth, DeductYear)    
                  Values(@SchemeNo, @MemberNo, @DependantCode, @Deduct, @DatePaid, @Amt, @PayMonth, @PayYear)      
             end    
             
             Select @TotalDeduct = 0,@DependantCode = 0,@MemberNo=0,@Deduct=0, @DeductAmt=0, @Instal=0, @DeductMode=0      
               
            end      
          fetch next from DeductCsr into @MemberNo, @DependantCode,@Deduct, @DeductAmt, @Instal, @DeductMode,@StopDate    
     end    
Close DeductCsr    
Deallocate DeductCsr    
end    
  
end
go

