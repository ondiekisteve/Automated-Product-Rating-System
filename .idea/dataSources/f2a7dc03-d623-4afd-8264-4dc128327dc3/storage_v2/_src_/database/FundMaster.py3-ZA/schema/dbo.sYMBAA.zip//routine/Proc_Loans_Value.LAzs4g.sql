CREATE PROCEDURE [dbo].[Proc_Loans_Value]                                                              
@SchemeNo Int,                                                              
@MortgageNo Int,                                                      
@TransMode Int,/* 0 - as at date, 1 - Cut dates */                                                      
@TransDate datetime,                                                      
@AsAtDate datetime,                                                      
@CapRepaid float Out,                                                      
@InterestDue float out,                                                      
@CapitalDue float out,                                                      
@CarryValue float Out,                                                    
@PeriodDesc varchar(255) Out                                                      
--with Encryption                                                              
as                                                              
declare @Loan float,@StartDate datetime,                                                              
@InterestRate float,@MatDate datetime,@IntCalcMode Int,                                                              
@YaKwanza datetime,@YaMwisho datetime,@NoofDays int,@Interest float,                                                       
@DaysInYearMode smallint,@NumDays int,@DaysInaYear float,                                                      
@InterestType int,@NumMonths Int,@Counter Int,@MaDays Int,                                                      
/* Capital Repayment  - if variable @CapRepayment (will be only for the first Instalment) */                                                       
@CapRepayment decimal(20,6),@MaxCap datetime,@MaxInt datetime,@MaxCapCode Int,@MaxIntCode Int,                                                    
@MaxCapCodeT Int,@MaxIntCodeT Int,@InterestDueT float,@CapitalDueT float,                                                    
@IntRate float,@MaxStart datetime,@InterestPaid float,@CapitalPaid float,@Aflife smallint,@CapStartDate datetime,@NumDays1 int,@InterestRate1 float,                        
@MwanzoDate datetime,@PartTransDate datetime,@PcntRedeem float,@Refinance smallint,@ExpectDays int,@Mwanzo datetime,          
@Mwisho datetime,@Adjustment float,@Partial float,@FromSecond smallint,@SecondDate datetime,@DirtyPrice float,  
@whichMonth int,@whichYear int,@whichDate datetime,@PrevMaxInt datetime  
  
  
select @whichMonth = DATEPART(month,@TransDate),@whichYear = DATEPART(year,@transDate)  
  
Exec GetFirstDate @whichMonth,@whichYear, @whichDate out                   
                    
if @TransMode = 1                    
   begin   
     
   if @TransDate = @whichDate                   
      select @ExpectDays = dateDiff(Day,@TransDate,@AsAtDate) + 1   
   else  
      select @ExpectDays = dateDiff(Day,@TransDate,@AsAtDate)  
                         
   select @Mwanzo = @TransDate,@Mwisho = @AsAtDate                     
   end           
          
/* Debit/Credit Notes and Adjustments */                                                                        
   Exec Proc_Inv_DrCr_Notes_Sum @SchemeNo,@MortgageNo,@AsAtDate,@Adjustment out         
   if @Adjustment > 0        
           select @Adjustment = 0            
                   
   select @Partial = sum(Amount) from TBL_Partial_Redemption where SchemeNo = @SchemeNo and InvCode = @MortgageNo          
   and TransDate <= @AsAtDate                    
                    
   if @Partial is null select @Partial = 0           
   if @Adjustment is null select @Adjustment = 0                            
                      
Select @PartTransDate = TransDate,@Refinance = Refinance                       
from TBL_Partial_Redemption                       
where schemeno = @schemeNo and InvCode = @MortgageNo and Refinance = 1                       
                        
if @Refinance is null select @Refinance = 0                        
                   
select @MwanzoDate = @TransDate                                 
                                  
select @Aflife = Aflife from scheme where schemeCode = @schemeNo                                   
                                  
if @Aflife is null select @Aflife = 0                                          
                                          
if @TransDate = @AsAtDate                                          
   select @TransDate = @TransDate - 1                                                      
                                                     
                                                            
select @Loan = Loan,@StartDate = IntStartDate,@CapStartDate = CapStartDate,                           
@MatDate = MaturityDate,@IntCalcMode=IntCalcMode,@InterestRate = InterestRate,                                                        
@DaysInYearMode = DaysInYearMode,@CapRepayment = CapRepayment,    
@FromSecond = FromSecond,@SecondDate = SecondDate,@DirtyPrice = DirtyPrice                                                      
from TBL_Loans where SchemeNo = @schemeNo and MortgageNo = @MortgageNo                                                      
                                                      
if @DaysInYearMode = 0                                                      
   select @DaysInaYear  = 365.000                               
else if @DaysInYearMode = 1                                                      
   select @DaysInaYear  = 364.000                                                      
else                                                      
   select @DaysInaYear  = 360.000                        
                                        
if @StartDate > @TransDate  /* where the start of the Intervaluation period is before the date of Investment */                                        
   select @TransDate = @StartDate                             
                                                    
/* Capital Repayment Due */                                                    
if @TransMode = 0                                                    
begin                                                      
select @MaxCap = max(dateDue),@MaxCapCode = max(PayCode) from TBL_Loans_Cap_Repay                                                               
where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @AsAtDate                                                      
                            
if @MaxCap is null select @MaxCap = @CapStartDate,@MaxCapCode = 0                                                     
                                                    
if @MaxCapCode > 0                                                     
   select @CapRepayment = AmountDue,@Yamwisho = dateDue from TBL_Loans_Cap_Repay                                                               
   where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxCapCode + 1                                                     
else                                                    
   select @Yamwisho = min(dateDue) from TBL_Loans_Cap_Repay                                                               
   where schemeNo = @schemeNo and MortgageNo = @MortgageNo                                                    
                                                   
   select @NumDays = datediff(day,@MaxCap,@AsAtDate)                               
                              
if @NumDays < 0                              
   select @NumDays = 0   
     
if @NumDays is null select @NumDays = 0                                                    
                                                    
select @PeriodDesc = 'Cap '+cast(@NumDays as varchar(4))+' days'                                                    
                                                    
if @NumDays > 0                                                    
   select @CapitalDue = @CapRepayment * (cast(@NumDays as float)/cast((datediff(day,@MaxCap,@Yamwisho)) as float))                                                    
else                                                    
   select @CapitalDue = 0                                   
                                  
if @aflife = 1                                  
 select @CapitalDue = 0                                                    
                                                    
select @NumDays = 0                                                    
                                                    
/* Interest Calculation */                             
if @TransMode = 0 /* As at Date */                            
Begin   
                                                   
    select @MaxInt = max(dateDue),@MaxIntCode = max(PayCode),@maxStart = max(startDate)             
    from TBL_Loans_Interest                                                       
    where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @AsAtDate    
      
    select @PrevMaxInt = max(dateDue)            
    from TBL_Loans_Interest                                                       
    where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue < @AsAtDate          
                                              
    if @MaxInt is null  
       begin             
       select @MaxInt = @StartDate,@MaxIntCode = 0  
       end   
      
                                                                                                     
    if @MaxInt = @AsAtDate  
       begin    
         
       if ((@PrevMaxInt is not null) and (@maxStart is not null) and (@PrevMaxInt < @maxStart))  
           select @NumDays = datediff(day,@maxStart,@AsAtDate) + 1  
       else                                       
           select @NumDays = datediff(day,@maxStart,@AsAtDate)
      
       /* Added on 15/05/2013 */ 
       select @InterestRate = InterestRate from TBL_Loans_Interest                             
       where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxIntCode        
       end                                               
    else                            
      begin            
       select @NumDays = datediff(day,@MaxInt,@AsAtDate)                             
                            
       select @InterestRate = InterestRate from TBL_Loans_Interest                             
       where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxIntCode + 1 
                                                   
     end                             
end                            
else                            
    Begin                                                                
      select @MaxInt = max(dateDue),@MaxIntCode = max(PayCode),@maxStart = max(startDate) from TBL_Loans_Interest                                                       
      where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @AsAtDate   
        
      select @PrevMaxInt = max(dateDue)            
      from TBL_Loans_Interest                                                       
      where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue < @AsAtDate                                                  
                        
        
        
                                                 
      if @MaxInt is null     
         begin    
            select @MaxInt = @StartDate,@MaxIntCode = 0     
         end    
          
      if ((@FromSecond = 1) and (@SecondDate > @MaxInt))    
         select @MaxInt = @SecondDate                                                          
                                                      
      if @MaxInt = @AsAtDate                                                
         select @NumDays = datediff(day,@maxStart,@AsAtDate) + 1                                                
      else     
        begin    
           if @MaxInt < @AsAtDate                                                   
              select @NumDays = datediff(day,@MaxInt,@AsAtDate)     
           else    
              select @NumDays  = 0    
        end                        
                            
     print ('*************************1************************')                              
end                            
                             
                                                                                 
/* Capital Repaid */                                                     
select @CapRepaid = sum(AmountDue) from TBL_Loans_Cap_Repay                                                               
where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue < @AsAtDate                                                     
if @CapRepaid is null select @CapRepaid = 0.0          
          
/* Debit/Credit Notes */                                                                        
 Exec Proc_Inv_DrCr_Notes_Sum @SchemeNo,@MortgageNo,@AsAtDate,@Adjustment out           
                   
 select @Partial = sum(Amount) from TBL_Partial_Redemption where SchemeNo = @SchemeNo and InvCode = @MortgageNo          
 and transdate <= @AsAtDate                    
                    
 if @Partial is null select @Partial = 0           
 if @Adjustment is null select @Adjustment = 0         
        
          
 if @MortgageNo = 282 /* Fix */        
    select @CapRepaid = (@CapRepaid + @Partial) - @Adjustment                  
                  
                                                                                          
if @NumDays > 0                                                 
 begin                                                      
  if @IntCalcMode = 0                       
     select @InterestDue = (@Loan * (@InterestRate/100.000)) * ((cast(@NumDays as float))/@DaysInaYear)                                                      
  else if @IntCalcMode = 1                                                      
     select @InterestDue = ((@Loan - @CapRepaid) * (@InterestRate/100.000)) * ((cast(@NumDays as float))/@DaysInaYear)                                                    
                            
  print @CapRepaid    
  print @NumDays                
  print ('*****************a******************')                   
                                                
  select @IntRate = cast(@InterestRate as float)                                              
                                                            
  if @maxIntCode > 0                                               
     select @InterestPaid = amountpaid * spotrate from TBL_Loans_Interest                                               
     where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @maxIntCode                                               
     and datepaid <= @AsAtDate                                               
  else                                              
     select @InterestPaid = 0.0                             
                            
  /*                                              
  if @InterestPaid > @InterestDue                                            
     begin                            
                                           
     select @InterestPaid = @InterestDue                                
                                            
     update TBL_Loans_Interest set AmountPaid = @InterestPaid                                               
     where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @maxIntCode                                                 
     end                             
                                                                       
  select @InterestDue = @InterestDue - @InterestPaid                             
  */                            
     
   if @NumDays is null select @NumDays = 0  
                                                     
    select @PeriodDesc = @PeriodDesc + ', Int. '+cast(@NumDays as varchar(4))+' days-'+cast(@IntRate as varchar(20))+'%'                                                     
 end                                                      
else                                                     
  select @InterestDue = 0.0                                                      
end                                                
else if @TransMode = 1 /* Between Cut dates */                                                    
begin                                                     
   /* Capital Repayment */                                                    
   select @MaxCap = max(dateDue),@MaxCapCode = max(PayCode) from TBL_Loans_Cap_Repay                                                               
   where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @AsAtDate                                     
                                                     
                                                      
   if @MaxCap is null select @MaxCap = @StartDate,@MaxCapCode = 0                                                     
                                                    
   select @MaxCapCodeT = min(PayCode) from TBL_Loans_Cap_Repay                                                               
   where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue >= @TransDate                                     
                                                   
                                                       
   /* Interest Calculation */                                               
   select @MaxInt = max(dateDue),@MaxIntCode = max(PayCode),@maxStart = max(startDate) from TBL_Loans_Interest                                                       
   where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @AsAtDate                                                      
                        
   if @MaxInt is null     
         begin    
            select @MaxInt = @StartDate,@MaxIntCode = 0     
         end    
     
      if ((@FromSecond = 1) and (@SecondDate > @MaxInt))    
         select @MaxInt = @SecondDate                                                          
      
                                                      
   select @MaxIntCodeT = min(PayCode) from TBL_Loans_Interest                        
   where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue >= @TransDate                 
                
                                                
   if @MaxIntCode = @MaxIntCodeT /*TransDate before datedue and AsatDate after datedue*/                                                    
      begin                            
        print ('*************************2************************')                                     
        /* Calculate Interest before */                                      
        select @InterestRate = InterestRate from TBL_Loans_Interest                                                       
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxIntCodeT                                                    
                                                           
       select @NumDays = 0  
         
                                                   
       if @TransDate = @whichDate                                               
          select @NumDays = datediff(day,@TransDate,@MaxInt) + 1   
       else  
          select @NumDays = datediff(day,@TransDate,@MaxInt)  
                                
       select @NumDays1 = @NumDays,@InterestRate1 = @InterestRate                        
                                              
       /* Capital Repaid */          
        select @CapRepaid = 0                                                      
        select @CapRepaid = sum(AmountDue) from TBL_Loans_Cap_Repay                                                               
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @TransDate              
        if @CapRepaid is null select @CapRepaid = 0.0           
          
                  
       /* Debit/Credit Notes */                                                                        
        Exec Proc_Inv_DrCr_Notes_Sum @SchemeNo,@MortgageNo,@AsAtDate,@Adjustment out           
                   
        select @Partial = sum(Amount) from TBL_Partial_Redemption where SchemeNo = @SchemeNo and InvCode = @MortgageNo          
        and transdate <= @AsAtDate                    
                    
        if @Partial is null select @Partial = 0           
        if @Adjustment is null select @Adjustment = 0         
        
          
        if @MortgageNo = 282 /* Fix */        
           select @CapRepaid = (@CapRepaid + @Partial) - @Adjustment                                                        
                                                    
        if @NumDays > 0                                                      
           begin                                                      
             if @IntCalcMode = 0                                                      
                select @InterestDueT = (@Loan * (@InterestRate/100.000)) * ((cast(@NumDays as float))/@DaysInaYear)                                                      
             else if @IntCalcMode = 1                                                      
                select @InterestDueT = ((@Loan - @CapRepaid) * (@InterestRate/100.000)) * ((cast(@NumDays as float))/@DaysInaYear)                                                      
         end                                                      
        else select @InterestDueT = 0.0                                                       
                                                            
        select @InterestRate = 0                    
                
        print ('*****************b******************')                                                   
                                                    
        /* Calculate Interest after */                                                    
        select @InterestRate = InterestRate from TBL_Loans_Interest                                                       
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxIntCodeT + 1                                                    
                                                           
        select @NumDays = 0                                                    
                                                    
        select @NumDays = datediff(day,@MaxInt,@AsAtDate)   
                                                                
        /* Capital Repaid */           
        select @CapRepaid = 0                                                     
        select @CapRepaid = sum(AmountDue) from TBL_Loans_Cap_Repay                                                  
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @TransDate                                                      
        if @CapRepaid is null select @CapRepaid = 0.0           
                  
                          
       /* Debit/Credit Notes */                                       
        Exec Proc_Inv_DrCr_Notes_Sum @SchemeNo,@MortgageNo,@AsAtDate,@Adjustment out           
                   
        select @Partial = sum(Amount) from TBL_Partial_Redemption where SchemeNo = @SchemeNo and InvCode = @MortgageNo          
        and transdate <= @AsAtDate                    
                    
        if @Partial is null select @Partial = 0           
        if @Adjustment is null select @Adjustment = 0          
        
         
        if @MortgageNo = 282 /* Fix */         
           select @CapRepaid = (@CapRepaid + @Partial) - @Adjustment                        
                                
        print ('*****************c******************')  
                                                                                                    
        if @NumDays > 0                                                      
           begin                                                      
             if @IntCalcMode = 0                                                      
                select @InterestDue = (@Loan * (@InterestRate/100.000)) * ((cast(@NumDays as float))/@DaysInaYear)                                                      
             else if @IntCalcMode = 1                                                                
                select @InterestDue = ((@Loan - @CapRepaid) * (@InterestRate/100.000)) * ((cast(@NumDays as float))/@DaysInaYear)                                 
           end                                                      
        else select @InterestDue = 0.0                                                    
                                                    
        select @InterestDue = @InterestDue + @InterestDueT                          
          
        if @NumDays1 is null select @NumDays1  = 0  
        if @NumDays is null select @NumDays = 0  
                        
        select @PeriodDesc = cast(@NumDays1 as varchar(4))+' days at-'+cast(@InterestRate1 as varchar(20))+'% and '+cast(@NumDays as varchar(4))+' days at -'+cast(@InterestRate as varchar(20))+'%'                                         
                                                
      end                                                      
    else if @MaxIntCode < @MaxIntCodeT /*TransDate and AsatDate within the same period*/                                                    
      begin                           
        print ('*************************3************************')                                     
        /* Calculate Interest before */                                                    
        select @InterestRate = InterestRate from TBL_Loans_Interest                                                       
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxIntCodeT                                                    
                                                           
        select @NumDays = 0                                                    
                              
        if @Refinance = 1                      
           begin                      
              if ((@TransDate <= @PartTransDate) and (@AsAtDate >= @PartTransDate))                      
                 select @NumDays = datediff(day,@TransDate,@PartTransDate) + 1                      
              else                      
                 select @NumDays = datediff(day,@TransDate,@AsAtDate) + 1                      
           end                      
        else                                            
           begin                    
                select @NumDays = datediff(day,@TransDate,@AsAtDate)     
                    
                                    
                    
                if @TransMode = 1                    
                   begin                    
                     if ((@ExpectDays > @NumDays) and ((@TransDate = @Mwanzo) and (@AsAtDate = @Mwisho)))                    
                        select @NumDays = @ExpectDays                     
                    
                   end                    
                    
                PRINT @NumDays                    
                PRINT ('*********************************************************')                    
           end                          
                        
       /* Capital Repaid */            
        select @CapRepaid = 0                                                    
        select @CapRepaid = sum(AmountDue) from TBL_Loans_Cap_Repay                                                         
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and datedue <= @TransDate                 
                                                       
                                                     
        if @CapRepaid is null select @CapRepaid = 0.0          
                               
       /* Debit/Credit Notes */                                                                        
        Exec Proc_Inv_DrCr_Notes_Sum @SchemeNo,@MortgageNo,@AsAtDate,@Adjustment out         
         
        
        select @Partial = sum(Amount) from TBL_Partial_Redemption where SchemeNo = @SchemeNo and InvCode = @MortgageNo          
        and transdate <= @AsAtDate                    
                    
        if @Partial is null select @Partial = 0           
        if @Adjustment is null select @Adjustment = 0         
           
        if @MortgageNo = 282 /* Fix */        
           select @CapRepaid = (@CapRepaid + @Partial) - @Adjustment                        
                  
        print @TransDate                
        print @CapRepaid                  
        print ('*****************d******************')                                                     
                                                    
        if @NumDays > 0                                                  
           begin                                                      
           if @IntCalcMode = 0                          
    begin                                                     
                select @InterestDue = (@Loan * (@InterestRate/100.000)) * ((cast(@NumDays as float))/@DaysInaYear)                          
                end                                                      
             else if @IntCalcMode = 1                           
                begin                                                      
                select @InterestDue = ((@Loan - @CapRepaid) * (@InterestRate/100.000)) * ((cast(@NumDays as float))/@DaysInaYear)                          
                end                                                      
           end                            
        else select @InterestDue = 0.0   
          
        if @NumDays is null select @NumDays = 0                           
                          
        select @PeriodDesc = cast(@NumDays as varchar(4))+' days-'+cast(@InterestRate as varchar(20))+'%'                       
                      
        print @PeriodDesc                      
        print ('******************************************************************************************')                          
                                                     
      end                                                      
                                               
   /* Capital Repayment Due */                                                    
   if @MaxCapCode = @MaxCapCodeT /*TransDate before datedue and AsatDate after datedue*/                                                    
      begin                                
       /* Calculate Capital before */                                                    
        select @CapRepayment = AmountDue,@YaKwanza = StartDate from TBL_Loans_Cap_Repay                                                       
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxCapCodeT                                                    
                                                           
        select @NumDays = 0                                                    
                                                    
        select @NumDays = datediff(day,@TransDate,@MaxCap)                           
              
        if datediff(day,@YaKwanza,@MaxCap) > 0                                             
           select @CapitalDueT = @CapRepayment * (cast(@NumDays as float)/cast(datediff(day,@YaKwanza,@MaxCap) as float))      
      
                   
        select @CapRepayment = 0                      
                                                  
        /* Calculate Capital after */                                                    
        select @CapRepayment = AmountDue,@Yamwisho = DateDue from TBL_Loans_Cap_Repay                                                       
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxCapCodeT + 1                   
                  
                                                 
        select @NumDays = 0                             
        select @NumDays = datediff(day,@MaxCap,@AsAtDate) + 1                                                     
                                                    
                                                      
        select @CapitalDue = @CapRepayment * (cast(@NumDays as float)/cast(datediff(day,@MaxCap,@Yamwisho) as float))                                                      
        if @CapitalDue is null select @CapitalDue = 0                                                    
        if @CapitalDueT is null select @CapitalDueT = 0                                                    
                                                    
        select @CapitalDue = @CapitalDue + @CapitalDueT                           
                                  
        if @aflife = 1                        
           select @CapitalDue = 0                                                      
      end                                                      
    else if @MaxCapCode < @MaxCapCodeT /*TransDate and AsatDate within the same period*/                                                    
      begin                                                   
        /* Calculate Capital before */                                                    
        select @CapRepayment = AmountDue,@YaKwanza = StartDate,@Yamwisho = datedue from TBL_Loans_Cap_Repay                                    
        where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PayCode = @MaxCapCodeT                                                    
                                                           
        select @NumDays = 0                                          
                                                    
        if ((@FromSecond = 1) and (@SecondDate > @TransDate) and (@SecondDate < @AsAtDate))    
           select @NumDays = datediff(day,@SecondDate,@AsAtDate)     
        else    
           select @NumDays = datediff(day,@TransDate,@AsAtDate)     
                                                                
      
     /*     
       select @MaxInt = @SecondDate      
                                                            
      if @MaxInt = @AsAtDate                                                
         select @NumDays = datediff(day,@maxStart,@AsAtDate) + 1                                                
      else     
        begin    
           if @MaxInt < @AsAtDate                                                   
              select @NumDays = datediff(day,@MaxInt,@AsAtDate)     
           else    
              select @NumDays  = 0    
        end                                                                 
   */                                                    
                                                                      
        select @CapitalDue = @CapRepayment * (cast(@NumDays as float)/cast(datediff(day,@YaKwanza,@Yamwisho) as float))                                                      
                                                            
        select @CapRepayment = 0                                   
                                  
        if @aflife = 1                                  
           select @CapitalDue = 0                                                       
      end                                          
                                     
  select @NumDays = datediff(day,@TransDate,@AsAtDate)                           
                          
  if @PeriodDesc is null                                        
     select @PeriodDesc = cast(@NumDays as varchar(4))+' days-'+cast(@InterestRate as varchar(20))+'%'                                                     
end                                                    
                                                       
if @InterestDue is null select @InterestDue = 0.0                                                     
if @CapRepaid is null select @CapRepaid = 0.0                  
if @CapitalDue is null select @CapitalDue = 0.0                           
                          
select @CarryValue = (@Loan - @CapRepaid) + @InterestDue
go

