CREATE PROCEDURE [dbo].[Proc_Loans_Int_Receivable]                        
@SchemeNo Int,                        
@MortgageNo Int                        
--with Encryption                        
as                        
declare @Loan decimal(20,6),@StartDate datetime,@MonInstal Decimal(20,6),@PayFreq Int,                        
@InterestRate decimal(9,6),@MatDate datetime,@IntCalcMode Int,                        
@YaKwanza datetime,@YaMwisho datetime,@NoofDays int,@Interest float,                 
@DaysInYearMode smallint,@NumDays int,@DaysInaYear int,                
@InterestType int,@NumMonths Int,@Counter Int,@MaDays Int,                
                
/* Capital Repayment  - if variable @CapRepayment (will be only for the first Instalment) */                 
@CapRepFixedVar smallint,@CapRepayment decimal(20,6),@CapRepFreqFixedVar smallint,                
@CapRepFreq smallint,@CapRepStartDate datetime,@CapRepaid decimal(20,6),@CapStartDate datetime,@IkoInt smallint,      
@DueDatesImported smallint                       
                        
select @IkoInt = 0            
                        
select @Loan = Loan,@StartDate = IntStartDate,@PayFreq = IntPayFreq,                        
@MatDate = MaturityDate,@IntCalcMode=IntCalcMode,@InterestRate = InterestRate,@InterestType = InterestType,                  
@DaysInYearMode = DaysInYearMode,                
@CapRepFixedVar = CapRepFixedVar,@CapRepayment = CapRepayment,@CapRepFreqFixedVar = CapRepFreqFixedVar,                
@CapRepFreq = CapRepFreq,@CapStartDate = CapStartDate,@DueDatesImported = DueDatesImported                
from TBL_Loans where SchemeNo = @schemeNo and MortgageNo = @MortgageNo       
      
if @DueDatesImported is null select @DueDatesImported = 0     
                        
select @Counter = 0       
      
if @DueDatesImported = 0      
begin                 
                
delete from TBL_Loans_Cap_Repay                         
where schemeNo = @schemeNo and MortgageNo = @MortgageNo and CapPosted = 0                
          
if @InterestType = 0          
   delete from TBL_Loans_Interest                 
    where schemeNo = @schemeNo and MortgageNo = @MortgageNo and InterestPosted = 0            
                
if (select count(*) from TBL_Loans_Interest where schemeNo = @schemeNo and MortgageNo = @MortgageNo) <= 2            
   begin            
    select @IkoInt = 0            
            
    delete from TBL_Loans_Interest                 
    where schemeNo = @schemeNo and MortgageNo = @MortgageNo and InterestPosted = 0             
   end            
else            
   select @IkoInt = 1            
                
                    
/* Capital Repayment                 
                     a) Fixed Capital Repayment , fixed frequency                 
                     b) Variable Capital Repayment, fixed Frequency                 
                     c) Variable Capital Repayment, variable frequency                
*/                
  if @DaysInYearMode = 0 /* Use Months */                 
     begin                  
      if @CapRepFreq = 1                  
         select @NumDays = 30,@NumMonths = 1                  
      else if @CapRepFreq = 2                  
         select @NumDays = 91,@NumMonths = 3                  
      else if @CapRepFreq = 3                  
         select @NumDays = 182,@NumMonths = 6                  
      else if @CapRepFreq = 4                  
         select @NumDays = 365,@NumMonths = 12                    
                  
      select @DaysInaYear = 365                  
   end    
else if @DaysInYearMode = 1 /* Use Months */                 
     begin                  
      if @CapRepFreq = 1                  
         select @NumDays = 30,@NumMonths = 1                  
      else if @CapRepFreq = 2                  
         select @NumDays = 91,@NumMonths = 3                  
      else if @CapRepFreq = 3                  
         select @NumDays = 182,@NumMonths = 6                  
      else if @CapRepFreq = 4               
         select @NumDays = 364,@NumMonths = 12                  
                  
      select @DaysInaYear = 364                  
   end                   
else                  
   begin                  
      if @CapRepFreq = 1                  
         select @NumDays = 30,@NumMonths = 1                  
      else if @CapRepFreq = 2                  
         select @NumDays = 90,@NumMonths = 3                    
      else if @CapRepFreq = 3                  
         select @NumDays = 180,@NumMonths = 6                   
      else if @CapRepFreq = 4                  
         select @NumDays = 360,@NumMonths = 12                   
                  
      select @DaysInaYear = 360                  
   end
      
-- a) Fixed Capital Repayment , fixed frequency - (Insert repayment for all the periods)                 
if ((@CapRepFixedVar = 0) and (@CapRepFreqFixedVar = 0))             
begin                
                
select @Yakwanza = @CapStartDate                 
                             
select @Yamwisho = dateAdd(Day,@NumDays,@Yakwanza)-1                
                  
While @Yamwisho <= @MatDate                        
  begin                             
                             
   insert into TBL_Loans_Cap_Repay(schemeNo,MortgageNo,StartDate,DateDue,AmountDue,DatePaid,AmountPaid,SpotRate,                
                                   Posted,CapReSet,CapPosted)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,@CapRepayment,@YaMwisho,0,1.0000,0,                
                                   1,0)                                     
                   
   select @Yakwanza = @Yamwisho + 1                
                
   select @Yamwisho = dateAdd(Day,@NumDays,@Yakwanza) - 1
      
   if @DaysInYearMode = 0 and @NumDays  = 182
         select @NumDays = 183
   else if @DaysInYearMode = 0 and @NumDays  = 183                       
         select @NumDays = 182                    
                       
  end                 
end                  
-- b) Variable Capital Repayment , fixed frequency (Only Insert repayment for the first Instalment)                
else if ((@CapRepFixedVar = 1) and (@CapRepFreqFixedVar = 0))                
begin                
  select @Yakwanza = @CapStartDate                 
                
                
  select @Yamwisho = dateAdd(Day,@NumDays,@Yakwanza)              
                  
  While @Yamwisho <= @MatDate                        
  begin                             
                   
   if @Counter = 0                          
      insert into TBL_Loans_Cap_Repay(schemeNo,MortgageNo,StartDate,DateDue,AmountDue,DatePaid,AmountPaid,SpotRate,                
                                      Posted,CapReSet,CapPosted)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,@CapRepayment,@YaMwisho,0,1.0000,0,1,0)                
   else                
      insert into TBL_Loans_Cap_Repay(schemeNo,MortgageNo,StartDate,DateDue,AmountDue,DatePaid,AmountPaid,SpotRate,Posted,                
                                      CapReSet,CapPosted)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,0,@YaMwisho,0,1.0000,0,0,0)                                     
                   
   select @Yakwanza = @Yamwisho + 1 
               
   select @Yamwisho = dateAdd(Day,@NumDays,@Yakwanza) - 1
      
   if @DaysInYearMode = 0 and @NumDays  = 182
         select @NumDays = 183
   else if @DaysInYearMode = 0 and @NumDays  = 183                       
         select @NumDays = 182                
                
  select @Counter = @Counter + 1                  
  end                 
end    
  /* c) Variable Capital Repayment , Variable frequency (Only Insert repayment for the first Instalment)                
        Only enter the first and the second with Zero repayment amount                
  */                
else if ((@CapRepFixedVar = 1) and (@CapRepFreqFixedVar = 1))                
begin                
  select @Yakwanza = @CapStartDate                 
                         
  select @Yamwisho = dateAdd(Day,@NumDays,@Yakwanza)                    
                       
 insert into TBL_Loans_Cap_Repay(schemeNo,MortgageNo,StartDate,DateDue,AmountDue,DatePaid,AmountPaid,SpotRate,                
                                 Posted,CapReSet,CapPosted)                        
                           Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,@CapRepayment,@YaMwisho,0,1.0000,0,                
                                  1,0)                
                
   select @Yakwanza = @Yamwisho + 1 
               
   select @Yamwisho = dateAdd(Day,@NumDays,@Yakwanza) - 1
      
   if @DaysInYearMode = 0 and @NumDays  = 182
         select @NumDays = 183
   else if @DaysInYearMode = 0 and @NumDays  = 183                       
         select @NumDays = 182                     
                
  insert into TBL_Loans_Cap_Repay(schemeNo,MortgageNo,StartDate,DateDue,AmountDue,DatePaid,AmountPaid,SpotRate,                
                                  Posted,CapReSet,CapPosted)                        
                           Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,0,@YaMwisho,0,1.0000,0,0,0)                 
end                    
                        
                
select @NumDays = 0,@NumMonths = 0                
/* Interest on the Loan                 
                     a) Interest rates - Fixed, Floating                 
                     b) Interest Calculation Mode - Fixed, Reducing Balance                 
                                     
*/                
  if @DaysInYearMode = 0 /* Use Months */                 
     begin                  
      if @PayFreq = 1                  
         select @NumDays = 30,@NumMonths = 1                  
      else if @PayFreq = 2                  
         select @NumDays = 91,@NumMonths = 3                  
      else if @PayFreq = 3                  
         select @NumDays = 182,@NumMonths = 6                  
      else if @PayFreq = 4                  
         select @NumDays = 365,@NumMonths = 12                  
                  
      select @DaysInaYear = 365                  
   end   
 else if @DaysInYearMode = 1 /* Use Months */                 
     begin                  
      if @PayFreq = 1                  
         select @NumDays = 30,@NumMonths = 1                  
      else if @PayFreq = 2                  
         select @NumDays = 91,@NumMonths = 3                  
      else if @PayFreq = 3                  
         select @NumDays = 182,@NumMonths = 6                  
      else if @PayFreq = 4                  
         select @NumDays = 364,@NumMonths = 12                  
                  
      select @DaysInaYear = 364                 
   end                             
  else                  
   begin                  
      if @PayFreq = 1                  
         select @NumDays = 30,@NumMonths = 1                  
     else if @PayFreq = 2                  
         select @NumDays = 90,@NumMonths = 3                    
      else if @PayFreq = 3                  
         select @NumDays = 180,@NumMonths = 6                   
      else if @PayFreq = 4                  
         select @NumDays = 360,@NumMonths = 12                   
                  
      select @DaysInaYear = 360                  
   end                
                       
--@IntCalcMode 0 - Fixed, 1 - Reducing Balance, @InterestType - 0 - fixed, 1 - floating                
                
if ((@IntCalcMode = 0) and (@InterestType = 0)) -- Calc mode (Fixed), Interest rate (fixed)                 
begin                
   select @Yakwanza = @StartDate                 
                            
   select @Yamwisho = dateAdd(Day,@NumDays,@StartDate)                      
                  
   While @Yamwisho <= @MatDate                        
   begin                             
      select @CapRepayment = ((@InterestRate/100.00) * @Loan) * (cast(@NumDays as float)/cast(@DaysInaYear as float))               
                  
      if @IkoInt = 0                 
         insert into TBL_Loans_Interest(schemeNo,MortgageNo,StartDate,DateDue,InterestDue,InterestRate,DatePaid,AmountPaid,SpotRate,                
                                     DocRefNo,Posted,RateSet,InterestPosted)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,@CapRepayment,@InterestRate, @YaMwisho,0,1.0000,'',0,                
                                   1,0)                                     
                   
      select @YaKwanza = @Yamwisho + 1                
                     
      if @DaysInYearMode = 0 and @NumDays  = 182
         select @NumDays = 183
      else if @DaysInYearMode = 0 and @NumDays  = 183                       
         select @NumDays = 182
         
      select @Yamwisho = dateAdd(Day,@NumDays,@YaKwanza) - 1 
                        
      select @CapRepayment = 0                 
  end                 
end                
else if ((@IntCalcMode = 0) and (@InterestType = 1)) -- Calc mode (Fixed), Interest rate (floating)                 
begin                
      select @Yakwanza = @StartDate                 
                    
      select @Yamwisho = dateAdd(Day,@NumDays,@StartDate)                
                                       
      select @CapRepayment = ((@InterestRate/100.00) * @Loan) * (cast(@NumDays as float)/cast(@DaysInaYear as float))  
                  
      if @IkoInt = 0                  
      insert into TBL_Loans_Interest(schemeNo,MortgageNo,StartDate,DateDue,InterestDue,InterestRate,DatePaid,AmountPaid,                
                                     SpotRate,DocRefNo,Posted,RateSet,InterestPosted)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,@CapRepayment,@InterestRate, @YaMwisho,0,1.0000,'',0,                
                                   1,0)                                     
                   
      select @YaKwanza = @Yamwisho + 1                
                
      if @DaysInYearMode = 0 and @NumDays  = 182
         select @NumDays = 183
      else if @DaysInYearMode = 0 and @NumDays  = 183                       
         select @NumDays = 182
         
      select @Yamwisho = dateAdd(Day,@NumDays,@YaKwanza) - 1
                            
      select @CapRepayment = 0                 
                
      select @CapRepayment = ((@InterestRate/100.00) * @Loan) * (cast(@NumDays as float)/cast(@DaysInaYear as float))  
                   
      if @IkoInt = 0                 
      insert into TBL_Loans_Interest(schemeNo,MortgageNo,StartDate,DateDue,InterestDue,InterestRate,DatePaid,AmountPaid,                
                                     SpotRate,DocRefNo,Posted,RateSet,InterestPosted)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,0.0,0.0, @YaMwisho,0,1.0000,'',0,0,0)                                     
                
end                
else if ((@IntCalcMode = 1) and (@InterestType = 0)) -- Calc mode (reducing), Interest rate (fixed)                 
begin                
    select @Yakwanza = @StartDate                 
                
   select @Yamwisho = dateAdd(Day,@NumDays,@StartDate)               
                  
   While @Yamwisho <= @MatDate                        
   begin                
      select @CapRepaid = sum(AmountDue) from TBL_Loans_Cap_Repay                         
      where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @Yakwanza                
                
      if @CapRepaid is null select @CapRepaid = 0                
                       
      select @CapRepayment = ((@InterestRate/100.00) * @Loan) * (cast(@NumDays as float)/cast(@DaysInaYear as float))  
                   
      if @IkoInt = 0                 
      insert into TBL_Loans_Interest(schemeNo,MortgageNo,StartDate,DateDue,InterestDue,InterestRate,DatePaid,AmountPaid,SpotRate,                
                                     DocRefNo,Posted,RateSet,InterestPosted,CapRepaidDue)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,@CapRepayment,@InterestRate, @YaMwisho,0,1.0000,'',0,                
                                   1,0,@CapRepaid)                                     
                   
      select @YaKwanza = @Yamwisho + 1                
                              
      if @DaysInYearMode = 0 and @NumDays  = 182
         select @NumDays = 183
      else if @DaysInYearMode = 0 and @NumDays  = 183                       
         select @NumDays = 182
         
      select @Yamwisho = dateAdd(Day,@NumDays,@YaKwanza) - 1
                            
      select @CapRepayment = 0,@CapRepaid = 0                 
  end                 
end                
else if ((@IntCalcMode = 1) and (@InterestType = 1)) -- Calc mode (reducing), Interest rate (floating)                 
begin                
      select @Yakwanza = @StartDate                 
                        
      select @Yamwisho = dateAdd(Day,@NumDays,@StartDate)                
                  
      select @CapRepaid = sum(AmountDue) from TBL_Loans_Cap_Repay                         
      where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @Yakwanza                
                
     if @CapRepaid is null select @CapRepaid = 0                
                       
     select @CapRepayment = ((@InterestRate/100.00) * @Loan) * (cast(@NumDays as float)/cast(@DaysInaYear as float))  
                   
      if @IkoInt = 0                         
      insert into TBL_Loans_Interest(schemeNo,MortgageNo,StartDate,DateDue,InterestDue,InterestRate,DatePaid,AmountPaid,                
                                     SpotRate,DocRefNo,Posted,RateSet,InterestPosted,CapRepaidDue)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,@CapRepayment,@InterestRate, @YaMwisho,0,1.0000,'',0,                
                                   1,0,@CapRepaid)                                     
                   
      select @YaKwanza = @Yamwisho + 1                
                      
      if @DaysInYearMode = 0 and @NumDays  = 182
         select @NumDays = 183
      else if @DaysInYearMode = 0 and @NumDays  = 183                       
         select @NumDays = 182
         
      select @Yamwisho = dateAdd(Day,@NumDays,@YaKwanza) - 1 
                          
      select @CapRepayment = 0,@CapRepaid = 0                 
                
      select @CapRepaid = sum(AmountDue) from TBL_Loans_Cap_Repay                         
      where schemeNo = @schemeNo and MortgageNo = @MortgageNo and dateDue <= @Yakwanza                
                
      if @CapRepaid is null select @CapRepaid = 0 
      
      select @CapRepayment = ((@InterestRate/100.00) * (@Loan - @CapRepaid)) * (cast(@NumDays as float)/cast(@DaysInaYear as float))                 
                                  
      if @IkoInt = 0                          
      insert into TBL_Loans_Interest(schemeNo,MortgageNo,StartDate,DateDue,InterestDue,InterestRate,DatePaid,AmountPaid,                
                                     SpotRate,DocRefNo,Posted,RateSet,InterestPosted,CapRepaidDue)                        
                            Values(@schemeNo,@MortgageNo,@Yakwanza,@YaMwisho,0.0,0.0, @YaMwisho,0,1.0000,'',0,0,0,@CapRepaid)                 
end                  
                  
end
go

