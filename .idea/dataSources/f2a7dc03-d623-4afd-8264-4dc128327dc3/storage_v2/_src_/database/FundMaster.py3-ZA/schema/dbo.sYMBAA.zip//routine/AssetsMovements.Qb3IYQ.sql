CREATE PROCEDURE [dbo].[AssetsMovements]    
@SCHEMENO Int,    
@StartDate Datetime,    
@EndDate Datetime,    
@RepMode int    
--with Encryption    
as    
    
if object_id('tempdb..#AssetReg') is null    
    
begin    
create table #AssetReg    
(    
 [AssetNo] [int] NOT NULL ,    
 [AssetClass] [int] NOT NULL ,    
 [SchemeName] [varchar](120) not  NULL,    
        [AssetName] [varchar](80),    
        [AssetDesc][varchar](80),    
        [AssetCost][float],    
        [AssetDate][Datetime],    
        [CurrValue][float],    
        [Percentage][float],    
        [StartDate][Datetime],    
        [EndDate][Datetime]        
)     
    
ALTER TABLE #AssetReg WITH NOCHECK ADD      
                
 CONSTRAINT [PK_AssetReg] PRIMARY KEY  NONCLUSTERED     
 (    
   [AssetNo],    
          [AssetClass]          
 )     
end    
    
    
declare @AssetNo int,@AssetClass int,@SchemeName varchar(120),    
        @AssetName Varchar(80),@AssetDesc varchar(80),@AssetCost float,@AssetDate Datetime,    
        @CurrValue float,@Percentage float    
    
if @RepMode = 0    
begin    
declare Acsr cursor for    
Select a.AssetNo,a.AssetClass,s.SchemeName, a.AssetName,a.AssetDesc,a.OriginalCost,a.AssetDate    
from Assets a    
     inner join scheme s on a.schemeNo = s.SchemeCode    
where a.SchemeNo = @schemeNo and a.AssetDate >= @StartDate and a.AssetDate <= @EndDate    
          
open acsr    
    
fetch from acsr into @AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate    
    
while @@fetch_Status = 0    
begin    
   if Exists(Select * from Depreciation where SchemeNo = @SchemeNo and PropertyCode = @AssetNo)    
      begin    
           Select @CurrValue = Value from Depreciation    
           where SchemeNo = @SchemeNo and PropertyCode = @AssetNo and     
           PayCode = (Select Max(PayCode) from Depreciation where SchemeNo = @schemeNo and PropertyCode = @AssetNo)     
      end    
   else    
      select @CurrValue = @AssetCost    
    
    
   if @CurrValue < @AssetCost    
      Select @Percentage = ((@AssetCost - @CurrValue)/@AssetCost)*100.00000000    
   else if @CurrValue > @AssetCost    
      Select @Percentage = ((@CurrValue - @AssetCost)/@AssetCost)*100.0000000    
   else    
      Select @Percentage = 0.0    
    
   insert into #AssetReg (AssetNo,AssetClass,SchemeName, AssetName,AssetDesc,AssetCost,AssetDate,CurrValue,Percentage,    
                          StartDate,EndDate)    
               Values(@AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate,@CurrValue,@Percentage,    
                      @StartDate,@EndDate)      
    
     Select @CurrValue = 0    
    
   fetch next from acsr into @AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate    
end    
Close Acsr    
Deallocate Acsr    
    
end    
    
else IF @RepMode = 1   
begin    
declare Acsr cursor for    
Select a.AssetNo,a.AssetClass,s.SchemeName, a.AssetName,a.AssetDesc,a.OriginalCost,a.AssetDate    
from Assets a    
     inner join scheme s on a.schemeNo = s.SchemeCode    
where a.SchemeNo = @schemeNo and a.DateRetired >= @StartDate and a.DateRetired <= @EndDate    
      and a.Retired = 1    
    
open acsr    
    
fetch from acsr into @AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate    
    
while @@fetch_Status = 0    
begin    
   if Exists(Select * from Depreciation where SchemeNo = @SchemeNo and PropertyCode = @AssetNo)    
      begin    
           Select @CurrValue = Value from Depreciation    
           where SchemeNo = @SchemeNo and PropertyCode = @AssetNo and     
           PayCode = (Select Max(PayCode) from Depreciation where SchemeNo = @schemeNo and PropertyCode = @AssetNo)     
      end    
   else    
      select @CurrValue = @AssetCost    
    
    
   if @CurrValue < @AssetCost    

      Select @Percentage = ((@AssetCost - @CurrValue)/@AssetCost)*100.00000000    
   else if @CurrValue > @AssetCost    
      Select @Percentage = ((@CurrValue - @AssetCost)/@AssetCost)*100.0000000    
   else    
      Select @Percentage = 0.0    
    
   insert into #AssetReg (AssetNo,AssetClass,SchemeName, AssetName,AssetDesc,AssetCost,AssetDate,CurrValue,Percentage,    
                          StartDate,EndDate)    
               Values(@AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate,@CurrValue,@Percentage,    
                      @StartDate,@EndDate)      
    
     Select @CurrValue = 0    
    
   fetch next from acsr into @AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate    
end    
Close Acsr    
Deallocate Acsr    
    
end   
else if @RepMode = 2 /* All Assets */  
begin   
declare Acsr cursor for    
Select a.AssetNo,a.AssetClass,s.SchemeName, a.AssetName,a.AssetDesc,a.OriginalCost,a.AssetDate    
from Assets a    
     inner join scheme s on a.schemeNo = s.SchemeCode    
where a.SchemeNo = @schemeNo    
          
open acsr    
    
fetch from acsr into @AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate    
    
while @@fetch_Status = 0    
begin    
   if Exists(Select * from Depreciation where SchemeNo = @SchemeNo and PropertyCode = @AssetNo)    
      begin    
           Select @CurrValue = Value from Depreciation    
           where SchemeNo = @SchemeNo and PropertyCode = @AssetNo and     
           PayCode = (Select Max(PayCode) from Depreciation where SchemeNo = @schemeNo and PropertyCode = @AssetNo)     
      end    
   else    
      select @CurrValue = @AssetCost    
    
    
   if @CurrValue < @AssetCost    
      Select @Percentage = ((@AssetCost - @CurrValue)/@AssetCost)*100.00000000    
   else if @CurrValue > @AssetCost    
      Select @Percentage = ((@CurrValue - @AssetCost)/@AssetCost)*100.0000000    
   else    
      Select @Percentage = 0.0    
    
   insert into #AssetReg (AssetNo,AssetClass,SchemeName, AssetName,AssetDesc,AssetCost,AssetDate,CurrValue,Percentage,    
                          StartDate,EndDate)    
               Values(@AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate,@CurrValue,@Percentage,    
                      @StartDate,@EndDate)      
    
     Select @CurrValue = 0    
    
   fetch next from acsr into @AssetNo,@AssetClass,@SchemeName, @AssetName,@AssetDesc,@AssetCost,@AssetDate    
end    
Close Acsr    
Deallocate Acsr    
    
end    
  
    
    
Select * from #AssetReg
go

