CREATE FUNCTION [dbo].[fn_BCK_Exception](@SCHEMENO Int,@AcctPeriod Integer)                         
returns @tbl_var table(                       
                       SchemeNo int,      
                       MemberNo Int,             
                       FullName varchar(100),      
                       CBalance float,      
                       fBalance float,      
                       Diff float,  
                       rGroup Int,  
                       rGroupDesc varchar(100),
                       EndDate datetime                     
                       )                        
as                         
begin      
    
  declare @BatchId int,@EndDate datetime  
  
  select @BatchId = max(BatchId) from RegBalances where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod

  select @EndDate = EndDate from schemeYears where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod 
  
  /* Existing in Both */  
  Insert into @tbl_var  
  select @schemeNo,m.memberNo,m.sname+', '+m.fname+' '+m.Onames as FullName,  
       (c.EmpCont + c.EmprCont + c.EmpVolCont + c.EmprVolCont + c.PreEmpCont + c.PreEmprCont +   
        c.preAvc + c.Transfer + c.LockedIn + c.DeferredAmt) as cBalance,  
       (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
        r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt) as fBalance,  
       round((c.EmpCont + c.EmprCont + c.EmpVolCont + c.EmprVolCont + c.PreEmpCont + c.PreEmprCont +   
        c.preAvc + c.Transfer + c.LockedIn + c.DeferredAmt) -  
       (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
        r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt),0) as Diff,0,'DIFFERENCE IN BALANCES',@EndDate       
  from MemberOpeningBalances c  
     inner join Members m on c.schemeNo = m.schemeNo and c.MemberNo = m.MemberNo  
     inner Join RegBalances r on c.schemeNo = r.schemeNo and c.MemberNo = r.MemberNo and r.BatchId = @BatchId  
  where c.schemeNo = @schemeNo and c.AcctPeriod = @AcctPeriod  
  AND ABS((c.EmpCont + c.EmprCont + c.EmpVolCont + c.EmprVolCont + c.PreEmpCont + c.PreEmprCont +   
        c.preAvc + c.Transfer + c.LockedIn + c.DeferredAmt) -  
       (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
        r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt)) > 1  
  
  /* In Backup but missing in Balances */  
  Insert into @tbl_var  
  select @schemeNo,m.memberNo,m.sname+', '+m.fname+' '+m.Onames as FullName,  
         0 as cBalance,  
         (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
         r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt) as fBalance,  
         0 -  
         (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
         r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt) as Diff,1,'IN SNAPSHOT BUT MISSING IN CURRENT BALANCES',@EndDate        
  from RegBalances R  
     inner join Members m on r.schemeNo = m.schemeNo and r.MemberNo = m.MemberNo    
  where R.schemeNo = @schemeNo and R.AcctPeriod = @AcctPeriod and r.BatchId = @BatchId   
  and r.memberNo not in (select MemberNo from memberOpeningBalances where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod)  
  and (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
         r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt) > 0  
  
  /* In Balances but missing in Back up */  
  Insert into @tbl_var  
  select @schemeNo,m.memberNo,m.sname+', '+m.fname+' '+m.Onames as FullName,  
         (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
         r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt) as cBalance, 0 as fBalance,  
         (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
         r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt) as Diff,1,'IN BALANCES BUT MISSING IN LATEST SNAPSHOT',@EndDate        
  from MemberOpeningBalances R  
     inner join Members m on r.schemeNo = m.schemeNo and r.MemberNo = m.MemberNo    
  where R.schemeNo = @schemeNo and R.AcctPeriod = @AcctPeriod   
  and r.memberNo not in (select MemberNo from RegBalances where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod and BatchId = @BatchId)  
  and (r.EmpCont + r.EmprCont + r.EmpVolCont + r.EmprVolCont + r.PreEmpCont + r.PreEmprCont +   
         r.preAvc + r.Transfer + r.LockedIn + r.DeferredAmt) > 0  
  
  
 return                        
end
go

