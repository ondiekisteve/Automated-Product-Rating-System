CREATE FUNCTION [dbo].[fn_Memb_Last_Date]( @schemeNo int , @MemberNo Int)
returns DATETIME
as

begin

    declare @datepaid datetime
	select @datepaid = Max(datepaid) from contributionssummary where schemeNo = @schemeNo and MemberNo = @MemberNo

	if @datepaid is null select @datepaid = GETDATE()

    RETURN (@datepaid)
end
go

