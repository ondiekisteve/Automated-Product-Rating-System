CREATE PROCEDURE [dbo].[Proc_Fortunate]      
@schemeNo int,      
@BatchNo int,   
@Part varchar(255),   
@TransMode int /* 0 - Display, 1 - Update */      
as      
      
if object_id('tempdb..#Fortunate') is null           
begin                                           
  create table #Fortunate                                            
  (                                        
    CashTrans Int Identity(1,1) Primary Key,                                                                              
    BatchNo Int,          
    Debit float,          
    Credit float,          
    Particulars varchar(255),    
    TransType int,    
    Amount float,    
    Asset_Class int,     
    Unit_Cat int        
  )          
end       
      
declare @CashTransNo int,@Debit float,@Credit float,@FirstLevel int,@Asset_Class int,@Unit_Cat int,      
        @Inv_Class_Desc varchar(100),@Particulars varchar(255),@fLevelDesc varchar(20),@Amount float,    
        @TransType int      
      
declare fCsr cursor for      
select t.BatchNo,t.CashTransNo,t.Debit,t.Credit,t.FirstLevel,t.Asset_Class,t.Unit_Cat,      
       case t.Firstlevel when 1  then 'ASSETS'      
                         when 2  then 'LIABILITIES'      
                         when 3  then 'INCOME'      
                         when 4  then 'EXPENDITURE' end as fLevelDesc,i.Rep_Inv_Class_Desc      
from ##Unit_Trans t       
     inner join fn_Rep_Inv_Class() i on t.Asset_Class = i.Rep_Inv_Class       
where t.BatchNo = @BatchNo       
order by t.BatchNo,t.FirstLevel,t.Asset_Class,t.Unit_Cat      
      
open fCsr      
fetch from fCsr into @BatchNo,@CashTransNo,@Debit,@Credit,@FirstLevel,@Asset_Class,@Unit_Cat,@fLevelDesc,@Inv_Class_Desc      
while @@fetch_status = 0      
begin     
     select @TransType = 0, @Amount = 0      
         if @CashTransNo = 0      
            begin      
               if @Unit_Cat = 1   /* Price Movement */      
                  begin      
                     if @FirstLevel = 3      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'GAIN IN UNIT PRICE  - '+@Inv_Class_Desc,@Amount = @Credit       
                           else if @Debit > 0      
                              select @Particulars = 'LOSS IN UNIT PRICE  - '+@Inv_Class_Desc,@Amount = @Debit      
                        end      
                     else if @FirstLevel = 4      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'GAIN IN UNIT PRICE  - '+@Inv_Class_Desc,@Amount = @Credit       
                           else if @Debit > 0      
                              select @Particulars = 'LOSS IN UNIT PRICE  - '+@Inv_Class_Desc,@Amount = @Debit       
                        end      
                  end      
               else if @Unit_Cat = 2 /* Purchases/Sales */      
                  begin      
                     print('hakuna ujanja bado')      
                  end      
               else if @Unit_Cat = 3 /* Clearing Account */      
                  begin      
                     if @FirstLevel = 1      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'PAYABLE - '+@Inv_Class_Desc,@Amount = @Credit,@TransType = 3      
                           else if @Debit > 0      
                              select @Particulars = 'RECEIVABLE  - '+@Inv_Class_Desc,@Amount = @Debit,@TransType = 2      
                        end      
                     else if @FirstLevel = 2      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'PAYABLE  - '+@Inv_Class_Desc,@Amount = @Credit,@TransType = 3      
                           else if @Debit > 0      
                              select @Particulars = 'RECEIVABLE - '+@Inv_Class_Desc,@Amount = @Debit,@TransType = 2      
             end      
                     else if @FirstLevel = 3      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'RECEIVABLE - '+@Inv_Class_Desc,@Amount = @Credit,@TransType = 2      
                           else if @Debit > 0      
                              select @Particulars = 'PAYABLE - '+@Inv_Class_Desc,@Amount = @Debit,@TransType = 3      
                        end      
                     else if @FirstLevel = 4      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'RECEIVABLE  - '+@Inv_Class_Desc,@Amount = @Credit,@TransType = 2      
                           else if @Debit > 0      
                              select @Particulars = 'PAYABLE - '+@Inv_Class_Desc,@Amount = @Debit,@TransType = 3      
                        end      
                  end      
            end      
         else if @CashTransNo > 0 /* Cash */     
            begin      
               if @Unit_Cat = 1 /* Price Movement */      
                  begin      
                     if @FirstLevel = 1      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Sell units in - '+@Inv_Class_Desc+' and buy units in Cash',    
                              @Amount = @Credit,@TransType = 1      
                           else if @Debit > 0      
                              select @Particulars = 'Buy units in - '+@Inv_Class_Desc+' and Sell units in Cash',    
                              @Amount = @Debit,@TransType = 0      
                        end      
                     else if @FirstLevel = 2      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Sell units in - '+@Inv_Class_Desc+' and buy units in Cash',    
                              @Amount = @Credit,@TransType = 1       
                           else if @Debit > 0      
                              select @Particulars = 'Reduce Liability in - '+@Inv_Class_Desc+' and Sell units in Cash',    
                              @Amount = @Debit,@TransType = 5      
                        end      
                    else if @FirstLevel = 3      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Buy units in - '+@Inv_Class_Desc,    
                              @Amount = @Credit,@TransType = 0,@Asset_Class = 8        
                           else if @Debit > 0      
                              select @Particulars = 'Sell units in - '+@Inv_Class_Desc,    
                              @Amount = @Debit,@TransType = 1,@Asset_Class = 8       
                        end      
                     else if @FirstLevel = 4      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Buy units in - '+@Inv_Class_Desc,    
                              @Amount = @Credit,@TransType = 0,@Asset_Class = 8        
                           else if @Debit > 0      
                              select @Particulars = 'Sell units in - '+@Inv_Class_Desc,    
                              @Amount = @Debit,@TransType = 1,@Asset_Class = 8       
                        end      
                  end      
              else if @Unit_Cat = 2  /* Buy/Sell Units */      
                  begin      
                     if @FirstLevel = 1      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Sell units in - '+@Inv_Class_Desc+' and buy units in Cash',    
                              @Amount = @Credit,@TransType = 1      
                           else if @Debit > 0      
                              select @Particulars = 'Buy units in - '+@Inv_Class_Desc+' and Sell units in Cash',    
                        @Amount = @Debit,@TransType = 0      
                        end      
                     else if @FirstLevel = 2      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Sell units in - '+@Inv_Class_Desc+' and buy units in Cash',    
                              @Amount = @Credit,@TransType = 1      
                           else if @Debit > 0      
                              select @Particulars = 'Reduce Liability in - '+@Inv_Class_Desc+' and Sell units in Cash',    
                              @Amount = @Debit,@TransType = 0      
                        end      
                    else if @FirstLevel = 3      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Buy units in - '+@Inv_Class_Desc,    
                              @Amount = @Credit,@TransType = 0,@Asset_Class = 8       
                           else if @Debit > 0      
                              select @Particulars = 'Sell units in - '+@Inv_Class_Desc,    
                              @Amount = @Debit,@TransType = 1,@Asset_Class = 8       
                        end      
                     else if @FirstLevel = 4      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Buy units in - '+@Inv_Class_Desc,    
                              @Amount = @Credit,@TransType = 0,@Asset_Class = 8        
                           else if @Debit > 0      
                              select @Particulars = 'Sell units in - '+@Inv_Class_Desc,    
                              @Amount = @Debit,@TransType = 1,@Asset_Class = 8        
                        end      
                  end      
              else if @Unit_Cat = 3 /* Clearing Account */      
                  begin      
                     if @FirstLevel = 1      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Reduce Receivable in - '+@Inv_Class_Desc+' and buy units in Cash',    
                              @Amount = @Credit,@TransType = 4      
                           else if @Debit > 0      
                              select @Particulars = 'Reduce Liability in - '+@Inv_Class_Desc+' and Sell units in Cash',    
                              @Amount = @Debit,@TransType = 5      
                        end      
                     else if @FirstLevel = 2      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Reduce Receivable in - '+@Inv_Class_Desc+' and buy units in Cash',    
                              @Amount = @Credit,@TransType = 4      
                           else if @Debit > 0      
                              select @Particulars = 'Reduce Liability in - '+@Inv_Class_Desc+' and Sell units in Cash',    
                              @Amount = @Debit,@TransType = 5       
                        end      
                    else if @FirstLevel = 3      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Buy units in cash',    
                              @Amount = @Credit,@TransType = 0,@Asset_Class = 8      
                           else if @Debit > 0      
                              select @Particulars = 'Sell units in Cash',    
                              @Amount = @Debit,@TransType = 1,@Asset_Class = 8      
                        end      
                     else if @FirstLevel = 4      
                        begin      
                           if @Credit > 0      
                              select @Particulars = 'Buy units in Cash',@Amount = @Credit,@TransType = 0,@Asset_Class = 8       
                           else if @Debit > 0      
                              select @Particulars = 'Sell units in Cash',@Amount = @Debit,@TransType = 1,@Asset_Class = 8       
                        end      
                  end      
            end      
      
   Insert into #Fortunate(BatchNo,Debit,Credit,Particulars,TransType,Amount,Asset_Class,Unit_Cat)                                            
                   Values(@BatchNo,@Debit,@Credit,@Particulars,@TransType,@Amount,@Asset_Class,@Unit_Cat)      
     
   if ((@Unit_Cat <> 1) and (@TransMode = 1))  
      begin   
         insert into TBL_Unitization_Amt(SchemeNo,BatchNo,Particulars,Amount,Asset_Class,TransType)  
                             Values(@SchemeNo,@BatchNo,@Part,@Amount,@Asset_Class,@TransType)  
      end  
  
   select @BatchNo=0,@CashTransNo=0,@Debit=0,@Credit=0,@FirstLevel=0,@Asset_Class=0,@Unit_Cat=0,@Inv_Class_Desc ='',@fLevelDesc='',      
          @Particulars = '',@TransType = 0,@Amount = 0      
   fetch next from fCsr into @BatchNo,@CashTransNo,@Debit,@Credit,@FirstLevel,@Asset_Class,@Unit_Cat,@fLevelDesc,@Inv_Class_Desc      
end      
close fCsr      
deallocate fCsr      
  
if @TransMode = 0      
   select * from #Fortunate
go

