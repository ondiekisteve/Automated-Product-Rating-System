CREATE PROCEDURE [dbo].[addInvestCode]            
@SCHEMENO Int,          
@SimCode varchar(20),          
@InvestCode Int,          
@InvestCodeDetail Int,          
@InvName varchar(120),          
@Description varchar(255),              
@InvestNo Int,  
@Rep_Inv_Class Int,  
@Rep_Inv_Class_Det Int            
--with Encryption            
as            
            
declare @InvCode int          
          
If Exists (select InvCode from Investments 
           where schemeNo = @schemeNo and ((@InvestCode <> 2)  and (@InvestCode <> 4) and (@InvestCode <> 7)) and Ltrim(rtrim(InvName)) = Ltrim(rtrim(@InvName)))          
begin          
  Raiserror('%s already exists, Please enter another Investment name',16,1,@InvName)          
  Rollback Tran          
  Select @InvCode = 0          
  Select @InvCode as Investcode          
end          
else          
begin             
Select @InvCode = Max(InvCode) from Investments where SchemeNo = @schemeNo          
if @InvCode is null select @InvCode = 0          
Select @InvCode = @InvCode + 1         
        
if ((@InvestCode = 1) or (@InvestCode = 9) or (@InvestCode = 10) or (@InvestCode = 12))        
  begin        
   select @InvestNo = 0        
 end        
else if (@InvestCode = 5)      
  begin        
    select @Description = 'Term deposits in '+ InvestName from TBL_Invest_Names where InvestNo = @InvestNo        
 end       
else if (@InvestCode = 8)      
 begin      
    select @Description = 'Call/Cash deposits in '+ InvestName from TBL_Invest_Names where InvestNo = @InvestNo      
 end      
else      
 begin      
    select @InvName = InvestName from TBL_Invest_Names where InvestNo = @InvestNo       
 end       
        
           
Insert Into Investments(InvCode,SchemeNo,SimCode,InvestCode,InvestCodeDetail,InvName,Description,InitValue,DateComm,          
                        InvStatus,RebateComm,Posted,InvestNo,Rep_Inv_Class,Rep_Inv_Class_Det)          
             Values(@InvCode,@SchemeNo,@SimCode,@InvestCode,@InvestCodeDetail,ltrim(rtrim(@InvName)),@Description,          
                    0.0,GetDate(),0,0,0,@InvestNo,@Rep_Inv_Class,@Rep_Inv_Class_Det)          
            
Select @InvCode as Investcode           
end
go

