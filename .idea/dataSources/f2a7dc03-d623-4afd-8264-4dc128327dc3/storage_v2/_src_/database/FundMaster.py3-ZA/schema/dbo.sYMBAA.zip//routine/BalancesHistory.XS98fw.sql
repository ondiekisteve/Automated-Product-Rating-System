CREATE PROCEDURE [dbo].[Balanceshistory] @SCHEMENO    INT,
                                         @RangeStart  INT,
                                         @RangeEnd    INT,
                                         @certdate    DATETIME,
                                         @SponsorCode INT,
                                         @YearEnd     INT /* 0 - Provisional Rate, 1 - Declared Rate, 2 - Purchase Price */
AS
    IF Object_id('tempdb..#History') IS NULL
      BEGIN
          CREATE TABLE #History
            (
               [glcode]        [INT] IDENTITY(1, 1) PRIMARY KEY,
               [schemeName]    [VARCHAR](100) NOT NULL,
               [MemberNo]      [INT] NOT NULL,
               [FullName]      [VARCHAR](100),
               [SchemeYear]    [INT] NULL,
               [EmpOp]         [FLOAT],
               [EmpCont]       [FLOAT],
               [EmpTransfer]   [FLOAT],
               [EmpInt]        [FLOAT],
               [EmpClose]      [FLOAT],
               [EmprOp]        [FLOAT],
               [EmprCont]      [FLOAT],
               [EmprTransfer]  [FLOAT],
               [EmprInt]       [FLOAT],
               [EmprClose]     [FLOAT],
               [ClosingBal]    [FLOAT],
               [AsDate]        [DATETIME],
               [Sponsor]       [VARCHAR](120),
               [PayrollNo]     [VARCHAR](20),
               [IDnumber]      [VARCHAR](20),
               [PoolName]      [VARCHAR](120),
               [DoCalc]        [DATETIME],
               PurchasePrice   FLOAT,
               InterestRate    FLOAT,
               interestRateBal FLOAT,
               EndDate         DATETIME,
               InitialPurchase FLOAT,
               InitialDate     DATETIME,
               Additional      FLOAT,
               InitInterest    FLOAT,
               EndInterest     FLOAT,
               AcctPeriod      INT
            )
      END

    DECLARE @schemeName         VARCHAR(100),
            @FullName           VARCHAR(100),
            @SchemeYear         INT,
            @EmpOp              FLOAT,
            @EmpCont            FLOAT,
            @PayrollNo          VARCHAR(20),
            @IDnumber           VARCHAR(20),
            @EmpInt             FLOAT,
            @EmpClose           FLOAT,
            @EmprOp             FLOAT,
            @EmprCont           FLOAT,
            @EmprInt            FLOAT,
            @EmprClose          FLOAT,
            @ClosingBal         FLOAT,
            @LastPeriod         INT,
            @MaxPeriod          INT,
            @MinYear            INT,
            @MaxYear            INT,
            @AnzaPeriod         INT,
            @EmpTransfer        FLOAT,
            @EmprTransfer       FLOAT,
            @LastAcct           INT,
            @calculationMode    INT,
            @EndDate            DATETIME,
            @ArEmpCont          FLOAT,
            @ArEmprCont         FLOAT,
            @IntRate            FLOAT,
            @Mwaka              INT,
            @NumYears           INT,
            @NumMonths          INT,
            @NumDays            INT,
            @StartDate          DATETIME,
            @IntRateBal         FLOAT,
            @EmpOpUn            FLOAT,
            @EmprOpUn           FLOAT,
            @EmpContUn          FLOAT,
            @EmprContUn         FLOAT,
            @ArEmpContUn        FLOAT,
            @ArEmprContUn       FLOAT,
            @EmpTransferUn      FLOAT,
            @EmprTransferUn     FLOAT,
            @EmprCloseUn        FLOAT,
            @EmpCloseUn         FLOAT,
            @Sponsor            VARCHAR(120),
            @MemberNo           INT,
            @SchemeMode         INT,
            @PooledInvestment   SMALLINT,
            @InvestmentScheme   INT,
            @PoolName           VARCHAR(120),
            @ArrearsMaxYear     INT,
            @ArrearsMinYear     INT,
            @ArrearsLastPeriod  INT,
            @TransferMaxYear    INT,
            @TransferMinYear    INT,
            @TransferLastPeriod INT,
            @DoCalc             DATETIME,
            @PurchasePrice      FLOAT,
            @AcctPeriod         INT,
            @InterestRate       FLOAT,
            @OrigLastAcct       INT,
            @count              INT,
            @InitialPurchase    FLOAT,
            @InitialDate        DATETIME,
            @Additional         FLOAT,
            @MinCount           INT,
            @MaxCount           INT,
            @InitInterest       FLOAT,
            @AnzaDate           DATETIME,
            @MwishoDate         DATETIME,
            @AmountPaid         FLOAT,
            @hasBal             INT,
            @totEmp             FLOAT,
            @totEmpr            FLOAT,
            @totVol             FLOAT,
            @totSpecial         FLOAT,
            @totEmpUn           FLOAT,
            @totEmprUn          FLOAT,
            @totVolUn           FLOAT,
            @totSpecialUn       FLOAT,
            @mwezi              INT,
            @CertDate1          DATETIME,
            @interestRateBal    FLOAT,
            @eeRate             FLOAT,
            @ErRate             FLOAT

    SELECT @count = 0

    SELECT @schemeName = schemeNAME,
           @calculationMode = calculationMode,
           @SchemeMode = SchemeMode,
           @PooledInvestment = PooledInvestment,
           @InvestmentScheme = InvestmentScheme
    FROM   Scheme
    WHERE  schemeCode = @schemeNo

    IF @SchemeMode IS NULL
      SELECT @SchemeMode = 0

    IF @YearEnd < 2
      BEGIN
          IF @SchemeMode = 1
            SELECT @Sponsor = SponsorName
            FROM   sponsor
            WHERE  schemeNo = @schemeNo
                   AND SponsorCode = @SponsorCode
          ELSE IF @SchemeMode = 0
            SELECT @Sponsor = ' '

          IF @PooledInvestment = 1
            SELECT @PoolName = schemeNAME
            FROM   Scheme
            WHERE  schemeCode = @InvestmentScheme
          ELSE IF @PooledInvestment = 0
            SELECT @PoolName = ' '

          IF @SchemeMode IS NULL
            SELECT @SchemeMode = 0

          IF @RangeStart <> @RangeEnd
            BEGIN
                IF @SchemeMode = 0
                  DECLARE MembCsr CURSOR FOR
                    SELECT MemberNo
                    FROM   Members
                    WHERE  schemeNo = @schemeNo
                           AND MemberNo >= @RangeStart
                           AND MemberNo <= @RangeEnd
                           AND ( ( ReasonForExit = 0 )
                                  OR ( ( ReasonForExit > 0 )
                                       AND ( ActiveStatus = 6 )
                                       AND ( DeferredPaid = 0 ) )
                                  OR ( ( ReasonForExit > 0 )
                                       AND ( ActiveStatus = 7 ) ) )
                    ORDER  BY MemberNo
                ELSE
                  DECLARE MembCsr CURSOR FOR
                    SELECT MemberNo
                    FROM   Members
                    WHERE  schemeNo = @schemeNo
                           AND MemberNo >= @RangeStart
                           AND MemberNo <= @RangeEnd
                           AND ( ( ReasonForExit = 0 )
                                  OR ( ( ReasonForExit > 0 )
                                       AND ( ActiveStatus = 6 )
                                       AND ( DeferredPaid = 0 ) )
                                  OR ( ( ReasonForExit > 0 )
                                       AND ( ActiveStatus = 7 ) ) )
                           AND SponsorCode = @SponsorCode
                    ORDER  BY memberNo
            END
          ELSE IF @RangeStart = @RangeEnd
            BEGIN
                IF @SchemeMode = 0
                  DECLARE MembCsr CURSOR FOR
                    SELECT MemberNo
                    FROM   Members
                    WHERE  schemeNo = @schemeNo
                           AND MemberNo >= @RangeStart
                           AND MemberNo <= @RangeEnd
                    ORDER  BY memberNo
                ELSE
                  DECLARE MembCsr CURSOR FOR
                    SELECT MemberNo
                    FROM   Members
                    WHERE  schemeNo = @schemeNo
                           AND MemberNo >= @RangeStart
                           AND MemberNo <= @RangeEnd
                    ORDER  BY memberNo
            END

          OPEN MembCsr

          FETCH FROM MembCsr INTO @MemberNo

          WHILE @@FETCH_STATUS = 0
            BEGIN
                SELECT @LastAcct = AcctPeriod
                FROM   schemeYears
                WHERE  schemeNo = @schemeNo
                       AND StartDate <= @certdate
                       AND EndDate >= @certdate

                SELECT @EndDate = EndDate,
                       @StartDate = StartDate
                FROM   schemeYears
                WHERE  schemeNo = @schemeNo
                       AND AcctPeriod = @LastAcct

                IF @certdate < @EndDate
                  SELECT @LastAcct = @LastAcct - 1

                SELECT @LastPeriod = Min(AcctPeriod)
                FROM   MemberOpeningBalances
                WHERE  SchemeNo = @schemeNo
                       AND MemberNo = @MemberNo

                SELECT @MaxPeriod = Max(AcctPeriod)
                FROM   MemberOpeningBalances
                WHERE  SchemeNo = @schemeNo
                       AND MemberNo = @MemberNo
                       AND AcctPeriod <= @LastAcct

                SELECT @fullName = Upper(sName) + ', ' + fName + ' ' + Onames,
                       @Payrollno = PayrollNo,
                       @IDNumber = IDNumber
                FROM   Members
                WHERE  SchemeNo = @schemeNo
                       AND MemberNo = @MemberNo

                SELECT @MinYear = Min(ContrYear),
                       @MaxYear = Max(ContrYear),
                       @LastPeriod = Min(AcctPeriod)
                FROM   Contributionssummary
                WHERE  SchemeNo = @schemeNo
                       AND MemberNo = @MemberNo

                IF @MinYear IS NULL
                  SELECT @MinYear = 0

                IF @MaxYear IS NULL
                  SELECT @MaxYear = 0

                IF @LastPeriod IS NULL
                  SELECT @LastPeriod = -1

                SELECT @ArrearsMinYear = Min(ContrYear),
                       @ArrearsMaxYear = Max(ContrYear),
                       @ArrearsLastPeriod = Min(AcctPeriod)
                FROM   ContributionArrears
                WHERE  SchemeNo = @schemeNo
                       AND MemberNo = @MemberNo

                SELECT @TransferMinYear = Min(Datepart(Year, TransferDate)),
                       @TransferMaxYear = Max(Datepart(Year, TransferDate)),
                       @TransferLastPeriod = Min(AcctPeriod)
                FROM   MemberTransfer
                WHERE  SchemeNo = @schemeNo
                       AND MemberNo = @MemberNo

                IF @ArrearsMinYear IS NULL
                  SELECT @ArrearsMinYear = 0

                IF @ArrearsMaxYear IS NULL
                  SELECT @ArrearsMaxYear = 0

                IF @ArrearsLastPeriod IS NULL
                  SELECT @ArrearsLastPeriod = -1

                IF @TransferMinYear IS NULL
                  SELECT @TransferMinYear = 0

                IF @TransferMaxYear IS NULL
                  SELECT @TransferMaxYear = 0

                IF @TransferLastPeriod IS NULL
                  SELECT @TransferLastPeriod = -1

                IF @ArrearsMinYear < @MinYear
                    OR @MinYear = 0
                  SELECT @MinYear = @ArrearsMinYear
                ELSE IF @TransferMinYear < @MinYear
                    OR @MinYear = 0
                  SELECT @MinYear = @TransferMinYear

                IF @ArrearsMaxYear < @MaxYear
                    OR @MaxYear = 0
                  SELECT @MaxYear = @ArrearsMaxYear
                ELSE IF @TransferMaxYear < @MaxYear
                    OR @MaxYear = 0
                  SELECT @MaxYear = @TransferMaxYear

                IF @ArrearsLastPeriod < @LastPeriod
                    OR @LastPeriod = -1
                  SELECT @LastPeriod = @ArrearsLastPeriod
                ELSE IF @TransferLastPeriod < @LastPeriod
                    OR @LastPeriod = -1
                  SELECT @LastPeriod = @TransferLastPeriod

                SELECT @AnzaPeriod = Min(AcctPeriod)
                FROM   MemberOpeningBalances
                WHERE  SchemeNo = @schemeNo
                       AND MemberNo = @MemberNo

                SELECT @LastPeriod = @AnzaPeriod

                WHILE @LastPeriod <= @MaxPeriod
                  BEGIN
                      SELECT @MinYear = Datepart(Year, EndDate),
                             @AnzaDate = StartDate,
                             @MwishoDate = EndDate
                      FROM   schemeYears
                      WHERE  schemeNo = @schemeNo
                             AND AcctPeriod = @LastPeriod

                      SELECT @schemeYear = @MinYear

                      SELECT @EmpOp = EmpCont + EmpVolCont + Transfer,
                             @EmprOp = EmprCont + EmprVolCont + LockedIn + Deferred
                      FROM   MemberOpeningBalances
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod - 1

                      SELECT @EmpOpUn = ( ExcessEmp + ExcessVolContr ) - ( EmpTax + VolTax ),
                             @EmprOpUn = ( ExcessEmpr + ExcessSpecial ) - ( EmprTax + SpecTax )
                      FROM   unregisteredBalances
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod - 1

                      IF @EmpOpUn IS NULL
                        SELECT @EmpOpUn = 0

                      IF @EmprOpUn IS NULL
                        SELECT @EmprOpUn = 0

                      IF @EmpOp IS NULL
                        SELECT @EmpOp = 0

                      IF @EmprOp IS NULL
                        SELECT @EmprOp = 0

                      SELECT @EmpCont = Sum(EmpCont + VolContr),
                             @EmprCont = Sum(EmprCont + SpecialContr)
                      FROM   Contributionssummary
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod
                             AND DatePaid <= @CertDate

                      SELECT @EmpContUn = Sum(ExcessEmpCont + ExcessVolContr),
                             @EmprContUn = Sum(ExcessEmprCont + ExcessSpecial)
                      FROM   UnregisteredContributionssummary
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod
                             AND DatePaid <= @CertDate

                      IF @EmpCont IS NULL
                        SELECT @EmpCont = 0

                      IF @EmprCont IS NULL
                        SELECT @EmprCont = 0

                      IF @EmpContUn IS NULL
                        SELECT @EmpContUn = 0

                      IF @EmprContUn IS NULL
                        SELECT @EmprContUn = 0

                      SELECT @ArEmpCont = Sum(ArEmpCont + ArVolContr),
                             @ArEmprCont = Sum(ArEmprCont + ArSpecial)
                      FROM   ContributionArrears
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod
                             AND DatePaid <= @CertDate

                      IF @ArEmpCont IS NULL
                        SELECT @ArEmpCont = 0

                      IF @ArEmprCont IS NULL
                        SELECT @ArEmprCont = 0

                      SELECT @EmpTransfer = Sum(EmpTransfer),
                             @EmprTransfer = Sum(EmprTransfer + DeferredAmt)
                      FROM   MemberTransfer
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod
                             AND TransferDate <= @CertDate

                      IF @EmpTransfer IS NULL
                        SELECT @EmpTransfer = 0

                      IF @EmprTransfer IS NULL
                        SELECT @EmprTransfer = 0

                      SELECT @EmpTransferUn = Sum(EmpTransfer),
                             @EmprTransferUn = Sum(EmprTransfer + DeferredAmt)
                      FROM   MemberTransferUn
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod
                             AND TransferDate <= @CertDate

                      IF @EmpTransferUn IS NULL
                        SELECT @EmpTransferUn = 0

                      IF @EmprTransferUn IS NULL
                        SELECT @EmprTransferUn = 0

                      SELECT @EmpClose = EmpCont + EmpVolCont + Transfer,
                             @EmprClose = EmprCont + EmprVolCont + LockedIn + Deferred
                      FROM   MemberOpeningBalances
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod

                      SELECT @EmpCloseUn = ( ExcessEmp + ExcessVolContr ) - ( EmpTax + VolTax ),
                             @EmprCloseUn = ( ExcessEmpr + ExcessSpecial ) - ( EmprTax + SpecTax )
                      FROM   UnRegisteredBalances
                      WHERE  SchemeNo = @schemeNo
                             AND MemberNo = @MemberNo
                             AND AcctPeriod = @LastPeriod

                      IF @EmprCloseUn IS NULL
                        SELECT @EmprCloseUn = 0

                      IF @EmpCloseUn IS NULL
                        SELECT @EmpCloseUn = 0

                      IF @ArEmpContUn IS NULL
                        SELECT @ArEmpContUn = 0

                      IF @ArEmprContUn IS NULL
                        SELECT @ArEmprContUn = 0

                      SELECT @AmountPaid = Sum(AmountPaid) + Sum(AmountpaidUn),
                             @EERate = Sum(EERate),
                             @ErRate = Sum(ErRate)
                      FROM   PartialPayment
                      WHERE  SchemeNo = @SCHEMENO
                             AND MemberNo = @MemberNo
                             AND DatePaid >= @AnzaDate
                             AND DatePaid <= @MwishoDate
                             AND DatePaid <= @certdate

                      IF @AmountPaid IS NULL
                        SELECT @AmountPaid = 0

                      IF @EERate IS NULL
                        SELECT @EERate = 0

                      IF @ErRate IS NULL
                        SELECT @ErRate = 0

                      IF ( @EmpClose + @EmpCloseUn ) > 0
                        SELECT @EmpInt = ( @EmpClose + @EmpCloseUn ) - ( @EmpOp + @EmpCont + @EmpTransfer + @ArEmpCont
                                                                         + @EmpOpUn + @EmpContUn + @EmpTransferUn )
                      ELSE
                        SELECT @EmpInt = 0--@AmountPaid

                      IF ( @EmprClose + @EmprCloseUn ) >= (( @EmprOp + @EmprCont + @EmprTransfer + @ArEmprCont
                                                            + @EmprOpUn + @EmprContUn + @EmprTransferUn ))
                        SELECT @EmprInt = ( @EmprClose + @EmprCloseUn ) - ( @EmprOp + @EmprCont + @EmprTransfer + @ArEmprCont
                                                                            + @EmprOpUn + @EmprContUn + @EmprTransferUn )
                      ELSE
                        SELECT @EmprInt = ( @EmprClose + @EmprCloseUn ) - ( ( @EmprOp + @EmprCont + @EmprTransfer + @ArEmprCont
                                                                              + @EmprOpUn + @EmprContUn + @EmprTransferUn ) / 2.000 )

                      SELECT @interestRateBal = interestRateBal,
                             @interestRate = interestRate
                      FROM   Interestrates
                      WHERE  schemeNo = @schemeNo
                             AND AcctPeriod = @LastPeriod

                      IF @interestRateBal IS NULL
                        SELECT @interestRateBal = 0

                      IF @interestRate IS NULL
                        SELECT @interestRate = 0

                      INSERT INTO #History
                                  (schemeName,
                                   MemberNo,
                                   FullName,
                                   SchemeYear,
                                   EmpOp,
                                   EmpCont,
                                   EmpInt,
                                   EmpClose,
                                   EmprOp,
                                   EmprCont,
                                   EmprInt,
                                   EmprClose,
                                   ClosingBal,
                                   EmpTransfer,
                                   EmprTransfer,
                                   PayrollNo,
                                   Idnumber,
                                   PoolName,
                                   interestRateBal,
                                   interestRate,
                                   AcctPeriod)
                      VALUES      (@schemeName,
                                   @MemberNo,
                                   @FullName,
                                   @SchemeYear,
                                   @EmpOp + @EmpOpUn,
                                   @EmpCont + @ArEmpCont + @EmpContUn + @ArEmpContUn,
                                   @EmpInt,
                                   @EmpClose + @EmpCloseUn,
                                   @EmprOp + @EmprOpUn,
                                   @EmprCont + @ArEmprCont + @EmprContUn,
                                   @EmprInt,
                                   @EmprClose + @EmprCloseUn,
                                   @EmprClose + @EmpClose + @EmprCloseUn
                                   + @EmpCloseUn,
                                   @EmpTransfer + @EmpTransferUn,
                                   @EmprTransfer + @EmprTransferUn,
                                   @PayrollNo,
                                   @IDnumber,
                                   @PoolName,
                                   @interestRateBal,
                                   @interestRate,
                                   @LastPeriod)

                      SELECT @EmpOp = 0,
                             @EmpOpUn = 0,
                             @EmpCont = 0,
                             @ArEmpCont = 0,
                             @EmpContUn = 0,
                             @ArEmpContUn = 0,
                             @EmpInt = 0,
                             @EmpClose = 0,
                             @EmpCloseUn = 0,
                             @EmprOp = 0,
                             @EmprOpUn = 0,
                             @EmprCont = 0,
                             @ArEmprCont = 0,
                             @EmprContUn = 0,
                             @EmprInt = 0,
                             @EmprClose = 0,
                             @EmprCloseUn = 0,
                             @EmprClose = 0,
                             @EmpClose = 0,
                             @EmprCloseUn = 0,
                             @EmpCloseUn = 0,
                             @EmpTransfer = 0,
                             @EmpTransferUn = 0,
                             @EmprTransfer = 0,
                             @EmprTransferUn = 0,
                             @AmountPaid = 0,
                             @interestRateBal = 0,
                             @interestRate = 0,
                             @EERate = 0,
                             @ErRate = 0

                      SELECT @LastPeriod = @LastPeriod + 1,
                             @MinYear = @MinYear + 1
                  END

                SELECT @LastAcct = 0

                IF @CalculationMode = 0 /* Simple Interest Pro-rata */
                  BEGIN
                      IF --(                                                                
                      ( @CertDate <> @EndDate )
                        --and(not Exists (select memberNo from #History where MemberNo = @memberNo and SchemeYear = DatePart(Year,@CertDate))))                                                                               
                        BEGIN
                            SELECT @Mwaka = Datepart(Year, @CertDate),
                                   @mwezi = Datepart(MONTH, @CertDate)

                            SELECT @LastAcct = AcctPeriod,
                                   @AnzaDate = StartDate,
                                   @MwishoDate = EndDate
                            FROM   schemeYears
                            WHERE  schemeNo = @schemeNo
                                   AND StartDate <= @CertDate
                                   AND EndDate >= @CertDate

                            EXEC Getlastdate
                              @mwezi,
                              @Mwaka,
                              @CertDate1 out

                            EXEC Getservicetime
                              @StartDate,
                              @CertDate1,
                              @NumYears Out,
                              @NumMonths Out,
                              @NumDays Out

                            SELECT @IntRate = ProvRate,
                                   @IntRateBal = ProvRateBal
                            FROM   InterestRates
                            WHERE  schemeNo = @schemeNo
                                   AND AcctPeriod = @LastAcct

                            IF @IntRate IS NULL
                              SELECT @IntRate = 0

                            IF @IntRateBal IS NULL
                              SELECT @IntRateBal = 0

                            --select @NumMonths = @NumMonths+1        
                            SELECT @EmpOp = EmpCont + EmpVolCont + Transfer,
                                   @EmprOp = EmprCont + EmprVolCont + LockedIn + Deferred
                            FROM   MemberOpeningBalances
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastAcct - 1

                            SELECT @EmpOpUn = ( ExcessEmp + ExcessVolContr ) - ( EmpTax + VolTax ),
                                   @EmprOpUn = ( ExcessEmpr + ExcessSpecial ) - ( EmprTax + SpecTax )
                            FROM   unregisteredBalances
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastAcct - 1

                            IF @EmpOp IS NULL
                              SELECT @EmpOp = 0

                            IF @EmprOp IS NULL
                              SELECT @EmprOp = 0

                            IF @EmpOpUn IS NULL
                              SELECT @EmpOpUn = 0

                            IF @EmprOpUn IS NULL
                              SELECT @EmprOpUn = 0

                            SELECT @EmpCont = Sum(EmpCont + VolContr),
                                   @EmprCont = Sum(EmprCont + SpecialContr)
                            FROM   Contributionssummary
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastAcct
                                   AND DatePaid <= @CertDate

                            SELECT @EmpContUn = Sum(ExcessEmpCont + ExcessVolContr),
                                   @EmprContUn = Sum(ExcessEmprCont + ExcessSpecial)
                            FROM   UnregisteredContributionssummary
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastAcct
                                   AND DatePaid <= @CertDate

                            IF @EmpCont IS NULL
                              SELECT @EmpCont = 0

                            IF @EmprCont IS NULL
                              SELECT @EmprCont = 0

                            IF @EmpContUn IS NULL
                              SELECT @EmpContUn = 0

                            IF @EmprContUn IS NULL
                              SELECT @EmprContUn = 0

                            SELECT @ArEmpCont = Sum(ArEmpCont + ArVolContr),
                                   @ArEmprCont = Sum(ArEmprCont + ArSpecial)
                            FROM   ContributionArrears
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastAcct
                                   AND DatePaid <= @CertDate

                            IF @ArEmpCont IS NULL
                              SELECT @ArEmpCont = 0

                            IF @ArEmprCont IS NULL
                              SELECT @ArEmprCont = 0

                            SELECT @EmpTransfer = Sum(EmpTransfer),
                                   @EmprTransfer = Sum(EmprTransfer)
                            FROM   MemberTransfer
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastAcct
                                   AND TransferDate <= @CertDate

                            IF @EmpTransfer IS NULL
                              SELECT @EmpTransfer = 0

                            IF @EmprTransfer IS NULL
                              SELECT @EmprTransfer = 0

                            SELECT @EmpTransferUn = Sum(EmpTransfer),
                                   @EmprTransferUn = Sum(EmprTransfer)
                            FROM   MemberTransferUn
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastAcct
                                   AND TransferDate <= @CertDate

                            IF @EmpTransferUn IS NULL
                              SELECT @EmpTransferUn = 0

                            IF @EmprTransferUn IS NULL
                              SELECT @EmprTransferUn = 0

                            SELECT @EmpClose = EmpCont + EmpVolCont + Transfer,
                                   @EmprClose = EmprCont + EmprVolCont + LockedIn + Deferred
                            FROM   MemberOpeningBalances
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastPeriod

                            SELECT @EmpCloseUn = ( ExcessEmp + ExcessVolContr ) - ( EmpTax + VolTax ),
                                   @EmprCloseUn = ( ExcessEmpr + ExcessSpecial ) - ( EmprTax + SpecTax )
                            FROM   UnRegisteredBalances
                            WHERE  SchemeNo = @schemeNo
                                   AND MemberNo = @MemberNo
                                   AND AcctPeriod = @LastPeriod

                            IF @EmprCloseUn IS NULL
                              SELECT @EmprCloseUn = 0

                            IF @EmpCloseUn IS NULL
                              SELECT @EmpCloseUn = 0

                            IF @EmprClose IS NULL
                              SELECT @EmprClose = 0

                            IF @EmpClose IS NULL
                              SELECT @EmpClose = 0

                            IF @ArEmpContUn IS NULL
                              SELECT @ArEmpContUn = 0

                            IF @ArEmprContUn IS NULL
                              SELECT @ArEmprContUn = 0

                            SELECT @AmountPaid = Sum(AmountPaid) + Sum(AmountpaidUn)
                            FROM   PartialPayment
                            WHERE  SchemeNo = @SCHEMENO
                                   AND MemberNo = @MemberNo
                                   AND DatePaid >= @StartDate
                                   AND DatePaid <= @EndDate
                                   AND DatePaid <= @certdate

                            IF @AmountPaid IS NULL
                              SELECT @AmountPaid = 0

                            SELECT @EmpInt = ( ( ( @EmpCont + @EmpTransfer + @ArEmpCont + @EmpContUn
                                                   + @EmpTransferUn + @ArEmpContUn ) * ( @IntRate / 100.00 ) ) * @NumMonths / 12.00 ) + ( ( ( @EmpOp + @EmpOpUn ) * ( @IntRateBal / 100.00 ) ) * @NumMonths / 12.00 )

                            SELECT @EmprInt = ( ( ( @EmprCont + @EmprTransfer + @ArEmprCont
                                                    + @EmprContUn + @EmprTransferUn + @ArEmprContUn ) * ( @IntRate / 100.00 ) ) * @NumMonths / 12.00 ) + ( ( ( @EmprOp + @EmprOpUn - @AmountPaid ) * ( @IntRateBal / 100.00 ) ) * @NumMonths / 12.00 )

                            SELECT @EmpClose = ( @EmpOp + @EmpCont + @EmpTransfer + @ArEmpCont
                                                 + @EmpOpUn + @EmpContUn + @EmpTransferUn ) + @EmpInt,
                                   @EmprClose = ( @EmprOp + @EmprCont + @EmprTransfer + @ArEmprCont
                                                  + @EmprOpUn + @EmprContUn + @EmprTransferUn ) + @EmprInt

                            IF EXISTS(SELECT MemberNo
                                      FROM   memberOpeningBalances
                                      WHERE  SchemeNo = @SCHEMENO
                                             AND MemberNo = @MemberNo
                                             AND AcctPeriod = @LastAcct - 1)
                              SELECT @hasBal = 1
                            ELSE
                              SELECT @hasBal = 0

                            EXEC Proc_calcmonthlyinterestsi
                              @schemeNo,
                              @memberNo,
                              @mwezi,
                              @Mwaka,
                              @hasBal,
                              0,
                              @totEmp output,
                              @totEmpr output,
                              @totVol output,
                              @totSpecial output

                            EXEC Proc_calcmonthlyinterestsi_un
                              @schemeNo,
                              @memberNo,
                              @mwezi,
                              @Mwaka,
                              @hasBal,
                              0,
                              @totEmpUn output,
                              @totEmprUn output,
                              @totVolUn output,
                              @totSpecialUn output

                            SELECT @EmpClose = @totEmp + @totEmpUn + @totVol + @totVolUn,
                                   @EmprClose = @totEmpr + @totEmprUn + @totSpecial
                                                + @totSpecialUn

                            SELECT @EmpInt = @EmpClose - ( @EmpCont + @EmpTransfer + @ArEmpCont + @EmpContUn
                                                           + @EmpTransferUn + @ArEmpContUn + @EmpOp + @EmpOpUn ),
                                   @EmprInt = @EmprClose - ( @EmprCont + @EmprTransfer + @ArEmprCont
                                                             + @EmprContUn + @EmprTransferUn + @ArEmprContUn
                                                             + @EmprOp + @EmprOpUn )

                            SELECT @interestRateBal = ProvRateBal,
                                   @interestRate = ProvRate
                            FROM   Interestrates
                            WHERE  schemeNo = @schemeNo
                                   AND AcctPeriod = @LastAcct

                            IF @interestRateBal IS NULL
                              SELECT @interestRateBal = 0

                            IF @interestRate IS NULL
                              SELECT @interestRate = 0

                            IF NOT EXISTS (SELECT memberNo
                                           FROM   #History
                                           WHERE  MemberNo = @memberNo
                                                  AND SchemeYear = Datepart(Year, @EndDate))
                              BEGIN
                                  SELECT @Mwaka = Datepart(Year, @EndDate)

                                  INSERT INTO #History
                                              (schemeName,
                                               MemberNo,
                                               FullName,
                                               SchemeYear,
                                               EmpOp,
                                               EmpCont,
                                               EmpInt,
                                               EmpClose,
                                               EmprOp,
                                               EmprCont,
                                               EmprInt,
                                               EmprClose,
                                               ClosingBal,
                                               EmpTransfer,
                                               EmprTransfer,
                                               PayrollNo,
                                               IDnumber,
                                               PoolName,
                                               interestRate,
                                               interestRateBal,
                                               AcctPeriod)
                                  VALUES      (@schemeName,
                                               @MemberNo,
                                               @FullName,
                                               @Mwaka,
                                               @EmpOp + @EmpOpUn,
                                               @EmpCont + @ArEmpCont + @EmpContUn,
                                               @EmpInt,
                                               @EmpClose,-- + @EmpCloseUn,  
                                               @EmprOp + @EmprOpUn,
                                               @EmprCont + @ArEmprCont + @EmprContUn,
                                               @EmprInt,
                                               @EmprClose,-- + @EmprCloseUn,  
                                               @EmprClose + @EmpClose,-- + @EmprCloseUn  
                                               -- + @EmpCloseUn,  
                                               @EmpTransfer + @EmpTransferUn,
                                               @EmprTransfer + @EmprTransferUn,
                                               @PayrollNo,
                                               @IDNumber,
                                               @PoolName,
                                               @interestRate,
                                               @interestRateBal,
                                               @LastAcct)
                              END

                            SELECT @EmpOp = 0,
                                   @EmpOpUn = 0,
                                   @EmpCont = 0,
                                   @ArEmpCont = 0,
                                   @EmpContUn = 0,
                                   @ArEmpContUn = 0,
                                   @EmpInt = 0,
                                   @EmpClose = 0,
                                   @EmpCloseUn = 0,
                                   @EmprOp = 0,
                                   @EmprOpUn = 0,
                                   @EmprCont = 0,
                                   @ArEmprCont = 0,
                                   @EmprContUn = 0,
                                   @EmprInt = 0,
                                   @EmprClose = 0,
                                   @EmprCloseUn = 0,
                                   @EmprClose = 0,
                                   @EmpClose = 0,
                                   @EmprCloseUn = 0,
                                   @EmpCloseUn = 0,
                                   @EmpTransfer = 0,
                                   @EmpTransferUn = 0,
                                   @EmprTransfer = 0,
                                   @EmprTransferUn = 0,
                                   @AmountPaid = 0,
                                   @interestRate = 0,
                                   @interestRateBal = 0
                        END
                  END

                SELECT @MemberNo = 0,
                       @LastPeriod = 0,
                       @MaxPeriod = 0,
                       @MinYear = 0,
                       @MaxYear = 0,
                       @AnzaPeriod = 0

                FETCH next FROM MembCsr INTO @MemberNo
            END

          CLOSE MembCsr

          DEALLOCATE MembCsr

          UPDATE #History
          SET    AsDate = @CertDate,
                 Sponsor = @Sponsor
      END
    ELSE IF @YearEnd >= 2 /* Purchase Price Balances */
      BEGIN
          SELECT @fullName = Upper(sName) + ', ' + fName + ' ' + Onames,
                 @Payrollno = PayrollNo,
                 @IDNumber = IDNumber,
                 @DoCalc = DoCalc
          FROM   Members
          WHERE  SchemeNo = @schemeNo
                 AND MemberNo = @RangeEnd

          SELECT @PurchasePrice = PurchasePrice
          FROM   Benefits
          WHERE  SchemeNo = @schemeNo
                 AND MemberNo = @RangeEnd
                 AND PurchasePrice > 0

          SELECT @LastPeriod = AcctPeriod
          FROM   SchemeYears
          WHERE  SchemeNo = @schemeNo
                 AND StartDate <= @DoCalc
                 AND EndDate >= @DoCalc

          SELECT @MaxPeriod = AcctPeriod,
                 @EndDate = EndDate
          FROM   SchemeYears
          WHERE  SchemeNo = @schemeNo
                 AND StartDate <= @CertDate
                 AND EndDate >= @CertDate

          IF @LastPeriod = @MaxPeriod /* Within the same Year */
            BEGIN
                EXEC DBO.[Proc_calc_purchase_interest_daily]
                  @schemeNo,
                  @RangeEnd,
                  @CertDate,
                  0,
                  @EmpClose output,
                  @AcctPeriod Out

                EXEC Proc_get_int_rate
                  @schemeNo,
                  @EndDate,
                  0,
                  @InterestRate Out

                INSERT INTO #History
                            (schemeName,
                             MemberNo,
                             FullName,
                             EndDate,
                             PurchasePrice,
                             DoCalc,
                             InterestRate,
                             EmpOp,
                             EmpInt,
                             ClosingBal,
                             PayrollNo,
                             IDnumber,
                             PoolName,
                             AsDate)
                VALUES      (@schemeName,
                             @RangeEnd,
                             @FullName,
                             @CertDate,
                             @PurchasePrice,
                             @DoCalc,
                             @InterestRate,
                             @PurchasePrice,
                             @EmpClose - @PurchasePrice,
                             @EmpClose,
                             @PayrollNo,
                             @IDNumber,
                             @PoolName,
                             @CertDate)
            END
          ELSE IF @LastPeriod < @MaxPeriod
            BEGIN
                SELECT @EmpOp = @PurchasePrice

                DECLARE CertCsr CURSOR FOR
                  SELECT AcctPeriod,
                         EndDate
                  FROM   schemeYears
                  WHERE  schemeNo = @schemeNo
                         AND AcctPeriod >= @LastPeriod
                         AND AcctPeriod <= @MaxPeriod

                OPEN CertCsr

                FETCH FROM CertCsr INTO @LastAcct, @EndDate

                WHILE @@FETCH_STATUS = 0
                  BEGIN
                      IF @CertDate < @EndDate
                        BEGIN
                            EXEC Proc_get_int_rate
                              @schemeNo,
                              @EndDate,
                              0,
                              @InterestRate Out

                            EXEC DBO.[Proc_calc_purchase_interest_daily]
                              @schemeNo,
                              @RangeEnd,
                              @CertDate,
                              0,
                              @EmpClose output,
                              @AcctPeriod Out

                            INSERT INTO #History
                                        (schemeName,
                                         MemberNo,
                                         FullName,
                                         EndDate,
                                         PurchasePrice,
                                         DoCalc,
                                         InterestRate,
                                         EmpOp,
                                         EmpInt,
                                         ClosingBal,
                                         PayrollNo,
                                         IDnumber,
                                         PoolName,
                                         AsDate)
                            VALUES      (@schemeName,
                                         @RangeEnd,
                                         @FullName,
                                         @CertDate,
                                         @PurchasePrice,
                                         @DoCalc,
                                         @InterestRate,
                                         @EmpOp,
                                         @EmpClose - @EmpOp,
                                         @EmpClose,
                                         @PayrollNo,
                                         @IDNumber,
                                         @PoolName,
                                         @CertDate)
                        END
                      ELSE
                        BEGIN
                            EXEC Proc_get_int_rate
                              @schemeNo,
                              @EndDate,
                              1,
                              @InterestRate Out

                            EXEC DBO.[Proc_calc_purchase_interest_daily]
                              @schemeNo,
                              @RangeEnd,
                              @EndDate,
                              1,
                              @EmpClose output,
                              @AcctPeriod Out

                            INSERT INTO #History
                                        (schemeName,
                                         MemberNo,
                                         FullName,
                                         EndDate,
                                         PurchasePrice,
                                         DoCalc,
                                         InterestRate,
                                         EmpOp,
                                         EmpInt,
                                         ClosingBal,
                                         PayrollNo,
                                         IDnumber,
                                         PoolName,
                                         AsDate)
                            VALUES      (@schemeName,
                                         @RangeEnd,
                                         @FullName,
                                         @EndDate,
                                         @PurchasePrice,
                                         @DoCalc,
                                         @InterestRate,
                                         @EmpOp,
                                         @EmpClose - @EmpOp,
                                         @EmpClose,
                                         @PayrollNo,
                                         @IDNumber,
                                         @PoolName,
                                         @CertDate)
                        END

                      SELECT @LastAcct = 0,
                             @EmpOp = @EmpClose,
                             @InterestRate = 0

                      FETCH next FROM CertCsr INTO @LastAcct, @EndDate
                  END

                CLOSE CertCsr

                DEALLOCATE CertCsr

                IF @YearEnd >= 3 /* Purchase Price Payment */
                  BEGIN
                      EXEC DBO.[Proc_calc_purchase_interest_daily]
                        @schemeNo,
                        @RangeEnd,
                        @CertDate,
                        0,
                        @EmpClose output,
                        @AcctPeriod Out

                      EXEC Proc_get_int_rate
                        @schemeNo,
                        @EndDate,
                        0,
                        @InterestRate Out

                      /* Post to TBL_Benefits_DC */
                      IF EXISTS (SELECT MemberNo
                                 FROM   tbl_Benefits_dc
                                 WHERE  schemeNo = @schemeNo
                                        AND MemberNo = @MemberNo
                                        AND DoCalc = @CertDate
                                        AND Trans_Categ = 6
                                        AND Posted <= 1)
                        UPDATE tbl_Benefits_dc
                        SET    InterestRate = @InterestRate,
                               AmountPayable = @EmpClose
                        WHERE  schemeNo = @schemeNo
                               AND MemberNo = @RangeEnd
                               AND DoCalc = @CertDate
                               AND Trans_Categ = 6
                               AND Posted <= 1
                      ELSE
                        BEGIN
                            SELECT @MinCount = Min(Ben_Counter)
                            FROM   tbl_Benefits_dc
                            WHERE  schemeNo = @schemeNo
                                   AND MemberNo = @RangeEnd
                                   AND Trans_Categ = 6

                            DELETE FROM tbl_Benefits_dc
                            WHERE  schemeNo = @schemeNo
                                   AND MemberNo = @RangeEnd
                                   AND Trans_Categ = 6
                                   AND Ben_Counter > @MinCount

                            INSERT INTO tbl_benefits_dc
                                        (Batch_Id,
                                         SchemeNo,
                                         MemberNo,
                                         ExitReason,
                                         Registered,
                                         DoExit,
                                         DoCalc,
                                         InterestRate,
                                         EE_Ben,
                                         ER_Ben,
                                         AVC_Ben,
                                         AVCER_Ben,
                                         EE_Transfer,
                                         ER_Transfer,
                                         Pre_EE,
                                         Pre_ER,
                                         Pre_AVC,
                                         Def_Ben,
                                         EE_Ben_Tax,
                                         ER_Ben_Tax,
                                         TaxFreeLumpsum,
                                         TaxFree_Portion,
                                         Vesting,
                                         TransType,
                                         EeRate,
                                         ErRate,
                                         OptionToUse,
                                         Posted,
                                         AmountTaxable,
                                         ActiveStatus,
                                         AmountPayable,
                                         TaxPayable,
                                         Trans_Categ)
                            VALUES      (0,
                                         @schemeNo,
                                         @RangeEnd,
                                         0,
                                         0,
                                         @CertDate,
                                         @CertDate,
                                         @InterestRate,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         0,
                                         100,
                                         100,
                                         0,
                                         100,
                                         100,
                                         0,
                                         0,
                                         0,
                                         0,
                                         @EmpClose,
                                         0,
                                         6)
                        END

                      IF @YearEnd = 4 /* Additional Surrender Value */
                        BEGIN
                            SELECT @MinCount = Min(Ben_Counter),
                                   @MaxCount = Max(Ben_Counter)
                            FROM   tbl_Benefits_dc
                            WHERE  schemeNo = @schemeNo
                                   AND MemberNo = @RangeEnd
                                   AND Trans_Categ = 6

                            SELECT @InitialPurchase = AmountPayable,
                                   @InitialDate = DoCalc,
                                   @InitInterest = InterestRate
                            FROM   tbl_Benefits_dc
                            WHERE  Ben_Counter = @MinCount

                            SELECT @Additional = @EmpClose - @InitialPurchase

                            UPDATE tbl_Benefits_dc
                            SET    AmountPayable = @Additional
                            WHERE  Ben_Counter = @MaxCount

                            UPDATE #History
                            SET    InitialPurchase = @InitialPurchase,
                                   InitialDate = @InitialDate,
                                   Additional = @Additional,
                                   InitInterest = @InitInterest,
                                   EndInterest = @InterestRate
                        END
                  END
            END
      END

    SELECT *
    FROM   #History
    WHERE  ClosingBal > 0
    ORDER  BY MemberNo,
              SchemeYear
go

