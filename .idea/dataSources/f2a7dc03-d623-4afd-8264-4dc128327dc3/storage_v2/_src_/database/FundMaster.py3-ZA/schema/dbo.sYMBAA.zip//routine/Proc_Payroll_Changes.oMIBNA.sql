CREATE PROCEDURE [dbo].[Proc_Payroll_Changes]    
@ChangeCounter Int,            
@schemeNo Int,            
@MemberNo Int,            
@DepCode Int,            
@PenOrBen Int,            
@MonPension float,            
@PayType Int,            
@Bank Int,            
@Branch Int,            
@AccountNo varchar(20),            
@finBank Int,            
@finBranch Int,            
@finAccountNo varchar(20),            
@PayPoint Int,            
@PaypointBranch Int,            
@PenFrequency Int,            
@FreqStartDate Datetime,            
@PayMonth Int,            
@PayYear Int,    
@FirstName varchar(100),    
@OtherNames varchar(100),    
@SurName varchar(100),    
@AddEdit Int /* 0 - Add, 1 - Edit, 2- Delete */                  
as            
            
declare @ChangeDate Datetime,@user varchar(50),@datecaptured datetime,@dPayType smallint        
        
if @PayType is null select @PayType = 0        
        
if ((@PayType = 0) and (@DepCode = 0))        
   begin        
      select @dPayType = PayType         
      from Pensioner         
      where schemeNo = @schemeNo and MemberNo = @MemberNo        
        
      select @PayType = @dPayType        
   end   
else if ((@PayType = 0) and (@DepCode > 0))        
   begin        
      select @dPayType = PayType         
      from memBeneficiary         
      where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode        
        
      if @dPayType is null select @dPayType = 0  
  
      if @dPayType = 0   
         begin  
           select @dPayType = PayType         
           from PenBeneficiary         
           where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DepCode        
         end  
      else  
         select @PayType = @dPayType        
   end         
        
select @user = user,@datecaptured = getdate()           
            
Exec GetFirstDate @PayMonth,@PayYear,@ChangeDate Out            
    
if @AddEdit = 0    
   begin            
      Delete from TBL_Payroll_Changes WHERE schemeNo = @schemeNo and MemberNo = @MemberNo and DepCode = @DepCode         
      and ChangeType = 0           
            
      INSERT INTO TBL_Payroll_Changes(SchemeNo,MemberNo,DepCode,PenOrBen,MonPension,Bank,Branch,AccountNo,FinBank,FinBranch,            
                                 FinAccountNo,Paypoint,PaypointBranch,PenFrequency,FreqStartDate,ChangeDate,PayType,        
                                ChangeType,capturedBy,DateCaptured,FirstName,OtherNames,SurName)            
                        Values(@schemeNo,@MemberNo,@DepCode,@PenOrBen,@MonPension,@Bank,@Branch,@AccountNo,@finBank,            
                               @FinBranch,@finAccountNo,@Paypoint,@PaypointBranch,@PenFrequency,@FreqStartDate,            
                               @ChangeDate,@PayType,0,@user,@DateCaptured,@FirstName,@OtherNames,@SurName)    
   end     
else if @AddEdit = 1    
   begin    
     Update TBL_Payroll_Changes set MonPension = @MonPension,Bank = @Bank,Branch = @Branch,AccountNo = @AccountNo,    
                                    FinBank = @finBank,FinBranch = @FinBranch,FinAccountNo = @finAccountNo,    
                                    Paypoint = @Paypoint,PaypointBranch = @PaypointBranch,PayType = @PayType,    
                                    FirstName = @FirstName,OtherNames = @OtherNames,SurName = @SurName     
                                where ChangeCounter = @ChangeCounter      
        
   end    
else if @AddEdit = 2    
   begin    
     Delete from TBL_Payroll_Changes where ChangeCounter = @ChangeCounter    
   end
go

