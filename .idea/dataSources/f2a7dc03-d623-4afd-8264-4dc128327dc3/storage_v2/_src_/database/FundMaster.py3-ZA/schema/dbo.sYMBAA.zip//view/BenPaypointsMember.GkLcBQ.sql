CREATE VIEW [dbo].[BenPaypointsMember]
--with encryption
AS
SELECT pa.PaypointName, p.schemeNo, p.MemberNo, 
    p.DependantCode
FROM MemBeneficiary p INNER JOIN
    PayPoints pa ON p.PayPoint = pa.PaypointCode
go

