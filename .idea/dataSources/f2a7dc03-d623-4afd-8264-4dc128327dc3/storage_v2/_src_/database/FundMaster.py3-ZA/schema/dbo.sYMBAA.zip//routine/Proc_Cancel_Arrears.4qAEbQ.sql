CREATE PROCEDURE [dbo].[Proc_Cancel_Arrears]
@schemeNo Int,
@ContrMonth Int,
@ContrYear Int,
@DatePaid Datetime
--with Encryption
as
Delete from ContributionArrears where schemeNo = @schemeNo and ContrMonth = @ContrMonth
and ContrYear = @ContrYear and DatePaid = @DatePaid
go

