CREATE PROCEDURE [dbo].[repFinancial]  
@SCHEMENO Int,  
@paymonth int,  
@payyear int,  
@bank varchar (15)  
--with Encryption  
as  
  
if object_id('tempdb..#PenPayroll') is null  
  
begin  
create table #PenPayrollBank  
(  
   
 [SchemeNo] int NOT NULL ,  
        [MemberNo] [Int] NOT NULL ,  
        [IDNumber] [Varchar](20),  
        [FullName] [Varchar](100),  
        [MembSex] [Varchar](8),  
        [Gross] [float],  
        [Net] [float],  
        [Tax] [float],  
        [PayMonth] [Int],  
        [PayYear] [Int],  
        [finAcctNo] [varchar](30),  
        [PenStatus] [Varchar](10),  
        [PenNo] [Varchar](20) not null,  
        [MonthName] [Varchar](20),  
        [finName] [Varchar](100),  
        [finBrName] [Varchar](100),  
        [Town] [Varchar](100),  
        [finBrCountry] [Varchar](100),  
        [Arrears][Decimal](12,2)  
)   
  
ALTER TABLE #PenPayrollBank WITH NOCHECK ADD   
  
              
 CONSTRAINT [PK_#PenPayrollBank] PRIMARY KEY  NONCLUSTERED   
 (  
   [MemberNo],[penNo]        
 )   
end  
  
Declare @PenNo Varchar(20),@Pension Decimal(20,6),@PayArrearsWithPayroll smallInt,  
@MaxYear Int,@MaxMonth Int,@StartDate Datetime  
  
Exec GetFirstDate @PayMonth,@PayYear,@StartDate Out  
  
Select @PayArrearsWithPayroll = PayArrearsWithPayroll from scheme where schemeCode = @SchemeNo  
  
if @PayArrearsWithPayroll is null select @PayArrearsWithPayroll =  0  
  
/* Pensioners */  
  
Insert Into #PenPayrollBank  
select  
m.SchemeNo,  
m.MemberNo,  
m.IDNumber,  
UPPER(m.Sname) + ' , ' + (m.fname) + '  ' + (m.onames) as FullName,  
case m.Sex  
  when 'M' then 'Male'  
  when 'F' then 'Female'  
else  
  'Unknown'  
end as MembSex, p.gross + p.avcPension + p.BankComm, p.net + p.avcPension + p.BankComm,p.tax,p.paymonth,p.payyear,p.FinAcctNo,  
case p.hold  
     when 1 then 'Active'  
     when 0 then 'Suspended'  
else  
     'unknown'  
end as penStatus,p.penNo, mo.monthname, b.finName , br.finBrName, br.FinBrAddress +'  '+ br.finBrtown as town, br.finBrCountry,  
0.0  
  
from members m, pensionpayroll p, monthtable mo, FinInstitutions b, FinInstitutionsBranch br  
  
where  
          ((m.SchemeNo = p.schemeNo)  and  (m.memberno= p.memberno))   
           and ((m.SchemeNo = p.schemeNo)  and  (m.memberno= p.memberno))   
          and  (p.paymonth=mo.monthnumber)  
          and ((p.finCode = b.finCode) and (p.finBrCode = br.finBrCode) and (b.FinCode = br.finCode)) and  
          (m.SchemeNo = @SchemeNo)   
          and p.payyear=@payyear   
          and p.paymonth=@paymonth  
          and p.finCode = @bank  
order by b.finName , br.finBrName,m.MemberNo  
  
  
/* Beneficiaries */  
  
Insert Into #PenPayrollBank  
select  
m.SchemeNo,  
m.DependantCode,  
m.DependantCode,  
UPPER(m.Sname) + ' , ' + (m.fname) + '  ' + (m.oname) as FullName,  
case m.Sex  
  when 'M' then 'Male'  
  when 'F' then 'Female'  
else  
  'Unknown'  
end as MembSex, p.gross + p.avcPension + p.BankComm, p.net + p.avcPension + p.BankComm,p.tax,p.paymonth,p.payyear,p.FinBrAccountNo,  
case p.hold  
     when 1 then 'Active'  
     when 0 then 'Suspended'  
else  
     'unknown'  
end as penStatus,p.penNo, mo.monthname, b.finName , br.finBrName, br.FinBrAddress +'  '+ br.finBrtown as town, br.finBrCountry,  
0.0  
  
from Dependants m, pensionpayrollBen p, monthtable mo, FinInstitutions b, FinInstitutionsBranch br  
  
where  
          ((m.SchemeNo = p.schemeNo)  and  (m.DependantCode= p.DependantCode))   
          and  (p.paymonth=mo.monthnumber)  
          and ((p.finCode = b.finCode) and (p.finBrCode = br.finBrCode) and (b.FinCode = br.finCode)) and  
          (m.SchemeNo = @SchemeNo)   
          and p.payyear=@payyear   
          and p.paymonth=@paymonth  
          and p.finCode = @bank  
order by b.finName , br.finBrName,m.MemberNo  
  
  
Declare Acsr Cursor for  
Select PenNo,Pension from PensionArrears  
where SchemeNo = @schemeNo and PayMonth = @PayMonth and PayYear = @PayYear  
open acsr  
fetch from acsr into @PenNo,@Pension  
while @@fetch_Status = 0  
begin  
   update #PenPayrollBank set Net = Net + @Pension  
   where SchemeNo = @schemeNo and PenNo = @PenNo  
  
   select @Pension = 0,@PenNo = ' '  
  
  
  
  
   fetch next from acsr into @PenNo,@Pension  
end  
Close Acsr  
Deallocate Acsr  
  
/* For Schemes that Pay Beneficiary Arrears in Monthly Pension within the Payroll */  
  
if @PayArrearsWithPayroll = 1  
begin  
  if @PayMonth = 1  
     select @MaxYear = @PayYear - 1,@MaxMonth = 12  
  else  
     select @MaxYear = @PayYear,@MaxMonth = @PayMonth - 1  
  
   /* Beneficiaries of Deceased Members */  
   Declare Acsr Cursor for  
   Select m.PenNo,m.Arrears from MemBeneficiary M  
          inner Join Dependants d on m.schemeNo = d.schemeNo   
          and m.MemberNo = d.MemberNo and m.DependantCode = d.DependantCode  
           and DatePart(Month,d.ClaimDate) = @MaxMonth and DatePart(Year,d.ClaimDate) = @MaxYear  
   where M.SchemeNo = @schemeNo  
   open acsr  
   fetch from acsr into @PenNo,@Pension  
   while @@fetch_Status = 0  
   begin  
       update #PenPayrollBank set Net = Net + @Pension,Arrears = @Pension  
       where PenNo = @PenNo  
  
       select @Pension = 0,@PenNo = ' '  
  
       fetch next from acsr into @PenNo,@Pension  
   end  
   Close Acsr  
   Deallocate Acsr  
  
   /* Beneficiaries of Deceased Pensioners */  
   Declare Acsr Cursor for  
   Select m.PenNo,m.Arrears from PenBeneficiary M  
          inner Join Dependants d on m.schemeNo = d.schemeNo   
          and m.MemberNo = d.MemberNo and m.DependantCode = d.DependantCode  
           and DatePart(Month,d.ClaimDate) = @MaxMonth and DatePart(Year,d.ClaimDate) = @MaxYear  
   where M.SchemeNo = @schemeNo  
   open acsr  
   fetch from acsr into @PenNo,@Pension  
   while @@fetch_Status = 0  
   begin  
       update #PenPayrollBank set Net = Net + @Pension,Arrears = @Pension  
       where PenNo = @PenNo  
  
       select @Pension = 0,@PenNo = ' '  
  
       fetch next from acsr into @PenNo,@Pension  
   end  
   Close Acsr  
   Deallocate Acsr  
end  
  
/* Arrears Due to Returned Cheques that are to be Re-Issued */  
   Declare Acsr Cursor for  
   select PenNo,Amount from UnclaimedCheques  
   where SchemeNo = @schemeNo and Reversed = 1 and Suspend = 0  
   and SuspendDate = @StartDate  
  
   open acsr  
   fetch from acsr into @PenNo,@Pension  
   while @@fetch_Status = 0  
   begin  
       update #PenPayrollBank set Net = Net + @Pension,Arrears = Arrears + @Pension  
       where PenNo = @PenNo  
  
       select @Pension = 0,@PenNo = ' '  
  
       fetch next from acsr into @PenNo,@Pension  
   end  
   Close Acsr  
   Deallocate Acsr  
  
Select * from #PenPayrollBank Order By finBrName,FullName
go

