CREATE PROCEDURE [dbo].[Proc_Set_AmountPayable]
@SchemeNo Int,
@MemberNo Int,
@Trans_Categ Int /* Used to Determine AmountPayable */
--with Encryption
as
-- select Ben_Counter,ee_Ben + Er_Ben,AmountPayable,TaxPayable,Trans_Categ from TBL_Benefits_DC where MemberNo = 100715 order by Ben_Counter

-- update TBL_Benefits_DC set Trans_Categ = 2 where Ben_Counter = 21538

-- Proc_Set_AmountPayable 1307,100699,1

declare @Ben_Counter Int,@Trans_Categ_C int,@EeRate float,@ErRate float,
@AmountPayable float,@TaxPayable float,@Employee float,@Employer float,
@EmployeeTax float,@EmployerTax float,
@DoCalc datetime,@DoExit datetime,@Reason int,@AmountPayablePrev float,@TaxPayablePrev float,@Ben_CounterPrev Int

select @AmountPayable = 0,@TaxPayable = 0

select @Ben_Counter = Max(Ben_Counter) from TBL_Benefits_DC
Where SCHEMENO = @SCHEMENO AND MemberNo = @MemberNo

if @Ben_Counter is null select @Ben_Counter = 0

select @Trans_Categ_C = Trans_Categ,@EeRate = EeRate,
@ErRate = ErRate,
@Employee = EE_Ben + AVC_Ben + EE_Transfer + Pre_EE + Pre_AVC,
@Employer = ER_Ben + AVCER_Ben + ER_Transfer + Pre_Er + Def_Ben,
@EmployeeTax = EE_Ben_Tax,
@EmployerTax = ER_Ben_Tax,
@DoCalc  = DoCalc,@DoExit = DoExit,@Reason = ExitReason,
@AmountPayablePrev = AmountPayable,@TaxPayablePrev = TaxPayable
from TBL_Benefits_DC
where Ben_Counter = @Ben_Counter

if @Trans_Categ = 3 /* Additional Surrender Value */
   begin

   select @Ben_CounterPrev = Max(Ben_Counter) from TBL_Benefits_DC
   Where SCHEMENO = @SCHEMENO AND MemberNo = @MemberNo and Ben_Counter < @Ben_Counter

   if @Ben_CounterPrev is null select @Ben_CounterPrev = 0

   select @AmountPayablePrev = AmountPayable,@TaxPayablePrev = TaxPayable
   from TBL_Benefits_DC
   where Ben_Counter = @Ben_CounterPrev

   end
IF @EeRate is null select @EeRate = 0
if @ErRate is null select @ErRate = 0
if @Employee is null select @Employee = 0
if @Employer is null select @Employer = 0
if @EmployeeTax is null select @EmployeeTax = 0
if @EmployerTax is null select @EmployerTax =0
if @Trans_Categ_C is null select @Trans_Categ_C = 0
if @AmountPayablePrev is null select @AmountPayablePrev =0
if @TaxPayablePrev is null select @TaxPayablePrev = 0


if @Trans_Categ <> @Trans_Categ_C /* Changing Amount Payable */
begin
   if @Trans_Categ_C = 0 and @Trans_Categ = 1 /* Defer Employer Portion */
      begin
        if @ErRate > 0
           select @AmountPayable = @Employee + (@Employer * (@ErRate/100.00)),            
                  @TaxPayable = @EmployeeTax + (@EmployerTax * (@ErRate/100.00))
        else
           select @AmountPayable = @Employee,            
                  @TaxPayable = @EmployeeTax

         /* Set Status to Deferred */
         update Members set ActiveStatus = 6,CloseAccount = 0,DeferredPaid = 0,                                                    
         InitialDoCalc = @DoCalc,InitialDoExit = @DoExit,InitialReason = @Reason                                                     
         where SchemeNo = @schemeNo and MemberNo = @MemberNo 
      end 
  else if @Trans_Categ_C = 0 and @Trans_Categ = 3 /* Additional Surrender Value (All Benefits) */
      begin
         select @AmountPayable = @Employee + @Employer,            
                @TaxPayable = @EmployeeTax + @EmployerTax
       
         select @AmountPayable = @AmountPayable - @AmountPayablePrev,
                @TaxPayable = @TaxPayable - @TaxPayablePrev
      end 
  else if @Trans_Categ_C = 1 and @Trans_Categ = 3 /* Additional Surrender Value (Deferred Employee) */
      begin
        if @ErRate > 0
           select @AmountPayable = @Employee + (@Employer * (@ErRate/100.00)),            
                  @TaxPayable = @EmployeeTax + (@EmployerTax * (@ErRate/100.00))
        else
           select @AmountPayable = @Employee,            
                  @TaxPayable = @EmployeeTax

        select @AmountPayable = @AmountPayable - @AmountPayablePrev,
                @TaxPayable = @TaxPayable - @TaxPayablePrev
      end 
  else if @Trans_Categ_C = 2 and @Trans_Categ = 3 /* Additional Surrender Value (Deferred Employer) */
      begin
        select @AmountPayable = @Employee + @Employer,            
                @TaxPayable = @EmployeeTax + @EmployerTax
       
         select @AmountPayable = @AmountPayable - @AmountPayablePrev,
                @TaxPayable = @TaxPayable - @TaxPayablePrev
      end 
  else if @Trans_Categ_C = 0 and @Trans_Categ = 5 /* Commute Lumpsum on Retirement */
      begin 
          Exec CommuteLumpsum @SCHEMENO,@MemberNo
      end        

  if @AmountPayable > 0
     update TBL_Benefits_DC set AmountPayable = @AmountPayable,TaxPayable = @TaxPayable,
     Trans_Categ = @Trans_Categ
     where Ben_Counter = @Ben_Counter
  else
     update TBL_Benefits_DC set Trans_Categ = @Trans_Categ
     where Ben_Counter = @Ben_Counter
 end
else
 begin
    update TBL_Benefits_DC set Trans_Categ = @Trans_Categ
    where Ben_Counter = @Ben_Counter
 end
go

