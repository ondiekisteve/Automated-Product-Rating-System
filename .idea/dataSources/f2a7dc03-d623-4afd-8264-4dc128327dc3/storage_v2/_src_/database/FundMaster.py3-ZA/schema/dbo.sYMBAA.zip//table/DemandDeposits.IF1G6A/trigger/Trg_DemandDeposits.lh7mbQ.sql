CREATE TRIGGER [dbo].[Trg_DemandDeposits] ON [dbo].[DemandDeposits] 
FOR INSERT
AS

declare @SchemeNo Int,@DepositNo Int,@UserName varchar(60),@BankAcc varchar(30),@CustodyAccount Int

select @UserName = user

select @schemeNo = SchemeNo,@DepositNo = DepositNo,@BankAcc = BankAcc,
@CustodyAccount = CustodyAccount from Inserted

Exec Proc_Auto_Insert_InvPosting @schemeNo ,@DepositNo,8,160,@DepositNo,1,@UserName


if @BankAcc is null select @BankAcc ='0'

if @BankAcc <> '0'
begin
if not Exists(select AccountCode from schemeBankBranch where schemeNo = @schemeNo and AccountCode = @BankAcc)
  begin
      raiserror('The Bank account specified has not been set up under the Scheme Bankers in Scheme set up',16,1)
      return
  end
end
go

