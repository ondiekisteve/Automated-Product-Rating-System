CREATE PROCEDURE [dbo].[AuthorizeLumpsum]        
@SCHEMENO Int,        
@MemberNo Int,      
@username varchar(60)        
--with Encryption        
as        
        
update LumpAuthorization set AuthorisedBy = @username, DateAuthorised = Getdate(), Authorised = 1        
where SchemeNo = @schemeNo and MemberNo =  @MemberNo
go

