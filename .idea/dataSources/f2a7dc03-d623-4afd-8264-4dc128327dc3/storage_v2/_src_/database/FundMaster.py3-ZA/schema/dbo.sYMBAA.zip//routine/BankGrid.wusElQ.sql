CREATE PROCEDURE [dbo].[BankGrid]
@SCHEMENO Int
--with Encryption
as

select bankcode, bankname
from schemeBanks
where SchemeNo = @schemeNo
go

