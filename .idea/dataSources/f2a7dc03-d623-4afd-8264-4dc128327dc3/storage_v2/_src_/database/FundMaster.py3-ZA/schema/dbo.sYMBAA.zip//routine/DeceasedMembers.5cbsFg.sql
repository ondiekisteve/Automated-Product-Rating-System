CREATE PROCEDURE [dbo].[DeceasedMembers]          
@SCHEMENO Int          
--with Encryption          
as          
DECLARE @GEPF SmallInt,          
   @PooledInvestment smallInt,@SchemeCode Int,            
   @PoolName varchar(120),@FundType varchar(2)        
          
select @PoolName = schemeName,@GEPF = GEPF,@PooledInvestment = PooledInvestment,@FundType = FundType            
   from scheme where schemeCode = @schemeNo      
      
      
if @FundType = 'PF'            
BEGIN            
Declare DeceasedMembersCsr cursor for            
select schemeCode from Scheme            
where PooledInvestment = 1 and InvestmentScheme = @schemeNo          
            
Open DeceasedMembersCsr            
Fetch from DeceasedMembersCsr into @schemeCode            
while @@fetch_Status = 0            
begin      
        
if @GEPF = 0        
Select s.SchemeCode,s.SchemeName, a.MemberNo,a.IDNumber,a.PayrollNo,upper(a.sName)+', '+Upper(a.fName)+' '+upper(a.Onames) as FullName,          
b.DateofDeath,c.DeathType,b.CauseofDeath,b.CertificateNo,b.AmountofCover,dateDiff(Year,a.Dob,a.doExit) as Age,          
Upper(d.sName)+' '+d.fName+' '+d.Oname as Dependant, b.MonPension,' ' AS SponsorName,@PoolName as PoolName          
from DeathClaim b          
     inner Join Members a on b.schemeNo  = a.schemeNo and b.MemberNo = a.MemberNo          
     inner Join DeathTypes c on b.DeathType = c.DeathCode          
     inner Join Scheme s on b.SchemeNo = s.SchemeCode          
     inner Join Dependants d on  b.schemeNo  = d.schemeNo and b.MemberNo = d.MemberNo and d.PcntBenefit > 0          
where b.SchemeNo = @schemeCode and dateDiff(Year,a.Dob,a.doExit) < 54          
order by s.SchemeCode,b.DateofDeath          
else if @GEPF = 1        
Select s.SchemeCode,s.SchemeName, a.MemberNo,a.IDNumber,a.PayrollNo,upper(a.sName)+', '+Upper(a.fName)+' '+upper(a.Onames) as FullName,          
b.DateofDeath,c.DeathType,b.CauseofDeath,b.CertificateNo,b.AmountofCover,dateDiff(Year,a.Dob,a.doExit) as Age,          
Upper(d.sName)+' '+d.fName+' '+d.Oname as Dependant, b.MonPension,' ' AS SponsorName,@PoolName as PoolName          
from DeathClaim b          
     inner Join Members a on b.schemeNo  = a.schemeNo and b.MemberNo = a.MemberNo          
     inner Join DeathTypes c on b.DeathType = c.DeathCode          
     inner Join Scheme s on b.SchemeNo = s.SchemeCode          
     inner Join Dependants d on  b.schemeNo  = d.schemeNo and b.MemberNo = d.MemberNo and d.PcntBenefit > 0          
where b.SchemeNo = @schemeCode        
order by s.SchemeCode,b.DateofDeath          
          
select @schemeCode=0            
Fetch next from DeceasedMembersCsr into @schemeCode            
end            
Close DeceasedMembersCsr            
Deallocate DeceasedMembersCsr        
            
END        
            
Else if @FundType <> 'PF'        
            
BEGIN            
select @PoolName = ''          
      
if @GEPF = 0        
Select s.SchemeCode,s.SchemeName, a.MemberNo,a.IDNumber,a.PayrollNo,upper(a.sName)+', '+Upper(a.fName)+' '+upper(a.Onames) as FullName,          
b.DateofDeath,c.DeathType,b.CauseofDeath,b.CertificateNo,b.AmountofCover,dateDiff(Year,a.Dob,a.doExit) as Age,          
Upper(d.sName)+' '+d.fName+' '+d.Oname as Dependant, b.MonPension,' ' AS SponsorName,' ' as PoolName          
from DeathClaim b          
     inner Join Members a on b.schemeNo  = a.schemeNo and b.MemberNo = a.MemberNo          
     inner Join DeathTypes c on b.DeathType = c.DeathCode          
     inner Join Scheme s on b.SchemeNo = s.SchemeCode          
     inner Join Dependants d on  b.schemeNo  = d.schemeNo and b.MemberNo = d.MemberNo and d.PcntBenefit > 0          
where b.SchemeNo = @SchemeNo and dateDiff(Year,a.Dob,a.doExit) < 54          
order by s.SchemeCode,b.DateofDeath          
else if @GEPF = 1        
Select s.SchemeCode,s.SchemeName, a.MemberNo,a.IDNumber,a.PayrollNo,upper(a.sName)+', '+Upper(a.fName)+' '+upper(a.Onames) as FullName,          
b.DateofDeath,c.DeathType,b.CauseofDeath,b.CertificateNo,b.AmountofCover,dateDiff(Year,a.Dob,a.doExit) as Age,          
Upper(d.sName)+' '+d.fName+' '+d.Oname as Dependant, b.MonPension,' ' AS SponsorName,' ' as PoolName          
from DeathClaim b          
     inner Join Members a on b.schemeNo  = a.schemeNo and b.MemberNo = a.MemberNo          
     inner Join DeathTypes c on b.DeathType = c.DeathCode          
     inner Join Scheme s on b.SchemeNo = s.SchemeCode          
 inner Join Dependants d on  b.schemeNo  = d.schemeNo and b.MemberNo = d.MemberNo and d.PcntBenefit > 0          
where b.SchemeNo = @SchemeNo        
order by s.SchemeCode,b.DateofDeath             
      
END
go

