CREATE VIEW [dbo].[FeesInvoices]    
--with encryption    
AS    
SELECT s.SchemeCode, s.SchemeName + ',' AS SchemeName,     
    s.Address + ',' AS Address,     
    s.Town + '  ' + s.Country + ',' AS Town, s.Telephone, s.Email,     
    f.InvoiceNo, f.Amount,f.WithholdingTax,f.Vat,f.Amount + f.WithholdingTax + f.Vat as Total,    
    f.InvoiceDate, f.Feescode, f.Description, f.Paycode,    
    c.ConsultantName,c.Address as cAddress,c.Building as cBuilding,c.Town as cTown,c.Phone as CPhone,  
    c.Fax as cFax,c.email as cemail    
FROM feesInvoice f     
     INNER JOIN Scheme s  ON f.SchemeNo = s.SchemeCode    
     inner join FeesSetup fs on f.feescode = fs.feescode    
     Inner Join Scheme_Consultants c on f.SchemeNo = c.SchemeNo and c.ConsultantType = 'Administrator'
go

