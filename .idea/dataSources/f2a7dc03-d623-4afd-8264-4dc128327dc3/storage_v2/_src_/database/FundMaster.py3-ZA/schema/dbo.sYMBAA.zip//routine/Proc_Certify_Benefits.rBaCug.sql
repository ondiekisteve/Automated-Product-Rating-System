CREATE PROCEDURE [dbo].[Proc_Certify_Benefits]                           
@Ben_Counter Int,    
@dcDb int,                
@Proc_Mode Int,/* 1- Certify, 2- Authorize,3-Audit */                    
@username varchar(60)                      
--with Encryption                      
as                      
                      
declare @Posted int,@User_No int,@User varchar(100),                
@MemberNo Int,@SchemeNo Int,@DependantCode Int,@ExitReason Int,@DoCalc datetime,@DoExit datetime                
                      
select @User = user     
                
if @User_No is null select @User_No = 0                      
                                          
if @Proc_Mode = 1 /* Certify for Payment */                
  BEGIN                                 
        update LumpAuthorization set CheckedBy = @username, DateChecked = Getdate(), Checked = 1                      
        where SchemeNo = @schemeNo and MemberNo =  @MemberNo                 
            
        if @dcDb = 0 
           begin       
           Update TBL_Benefits_DC set Posted = @Proc_Mode,CheckedBy = @username, DateChecked = Getdate()           
           where Ben_Counter = @Ben_Counter and Posted = @Proc_Mode-1
           
           select @ExitReason = Exitreason,@DoCalc= DoCalc,@DoExit=DoExit from TBL_Benefits_DC where Ben_Counter = @Ben_Counter
           
           Update TBL_Benefits_DB set Posted = @Proc_Mode,CheckedBy = @username, DateChecked = Getdate()           
           where Ben_Counter = (Select Max(Ben_Counter) from TBL_Benefits_DB Where SchemeNo = @SchemeNo and MemberNo = @MemberNo 
           and ExitReason = @ExitReason and DoCalc = @DoCalc and DOExit = @DoExit) 
           and Posted = @Proc_Mode-1
           end    
        else
           begin       
		   Update TBL_Benefits_DB set Posted = @Proc_Mode,CheckedBy = @username, DateChecked = Getdate()           
		   where Ben_Counter = @Ben_Counter and Posted = @Proc_Mode-1 
		   
		   select @ExitReason = Exitreason,@DoCalc= DoCalc,@DoExit=DoExit from TBL_Benefits_DB where Ben_Counter = @Ben_Counter
           
           Update TBL_Benefits_DC set Posted = @Proc_Mode,CheckedBy = @username, DateChecked = Getdate()           
           where Ben_Counter = (Select Max(Ben_Counter) from TBL_Benefits_DC Where SchemeNo = @SchemeNo and MemberNo = @MemberNo 
           and ExitReason = @ExitReason and DoCalc = @DoCalc and DOExit = @DoExit) 
           and Posted = @Proc_Mode-1
           end                                  
END                   
else if @Proc_Mode = 2 /* Authorise for Payment */                
  BEGIN                   
       update LumpAuthorization set AuthorisedBy = @username, DateAuthorised = Getdate(), Authorised = 1                      
       where SchemeNo = @schemeNo and MemberNo =  @MemberNo                 
           
       if @dcDb = 0 
          BEGIN          
			 Update TBL_Benefits_DC set Posted = @Proc_Mode,AuthorisedBy = @username, DateAuthorised = Getdate()           
			 where Ben_Counter = @Ben_Counter and Posted = @Proc_Mode-1
			 
			 select @ExitReason = Exitreason,@DoCalc= DoCalc,@DoExit=DoExit from TBL_Benefits_DC where Ben_Counter = @Ben_Counter
           
		   Update TBL_Benefits_DB set Posted = @Proc_Mode,AuthorisedBy = @username, DateAuthorised = Getdate()           
		   where Ben_Counter = (Select Max(Ben_Counter) from TBL_Benefits_DB Where SchemeNo = @SchemeNo and MemberNo = @MemberNo 
		   and ExitReason = @ExitReason and DoCalc = @DoCalc and DOExit = @DoExit) 
		   and Posted = @Proc_Mode-1
          END       
       else  
          BEGIN    
			 Update TBL_Benefits_DB set Posted = @Proc_Mode,AuthorisedBy = @username, DateAuthorised = Getdate()           
			 where Ben_Counter = @Ben_Counter and Posted = @Proc_Mode-1 
			 
			 select @ExitReason = Exitreason,@DoCalc= DoCalc,@DoExit=DoExit from TBL_Benefits_DB where Ben_Counter = @Ben_Counter
           
           Update TBL_Benefits_DC set Posted = @Proc_Mode,AuthorisedBy = @username, DateAuthorised = Getdate()           
           where Ben_Counter = (Select Max(Ben_Counter) from TBL_Benefits_DC Where SchemeNo = @SchemeNo and MemberNo = @MemberNo 
           and ExitReason = @ExitReason and DoCalc = @DoCalc and DOExit = @DoExit) 
           and Posted = @Proc_Mode-1
          END                                
 END   
 else if @Proc_Mode = 3 /* Authorise for Payment */                
 BEGIN                   
       update LumpAuthorization set AuthorisedBy = @username, DateAuthorised = Getdate(), Authorised = 1                      
       where SchemeNo = @schemeNo and MemberNo =  @MemberNo                 
           
       if @dcDb = 0
       BEGIN           
		   Update TBL_Benefits_DC set Posted = @Proc_Mode,AuditedBy = @username, DateAudited  = Getdate()           
		   where Ben_Counter = @Ben_Counter and Posted = @Proc_Mode-1
		   
		   select @ExitReason = Exitreason,@DoCalc= DoCalc,@DoExit=DoExit from TBL_Benefits_DC where Ben_Counter = @Ben_Counter
           
		   Update TBL_Benefits_DB set Posted = @Proc_Mode,AuditedBy = @username, DateAudited = Getdate()           
		   where Ben_Counter = (Select Max(Ben_Counter) from TBL_Benefits_DB Where SchemeNo = @SchemeNo and MemberNo = @MemberNo 
		   and ExitReason = @ExitReason and DoCalc = @DoCalc and DOExit = @DoExit) 
		   and Posted = @Proc_Mode-1
       END      
       else  
       BEGIN    
		   Update TBL_Benefits_DB set Posted = @Proc_Mode,AuditedBy = @username, DateAudited  = Getdate()           
		   where Ben_Counter = @Ben_Counter and Posted = @Proc_Mode-1 
		   
		   select @ExitReason = Exitreason,@DoCalc= DoCalc,@DoExit=DoExit from TBL_Benefits_DB where Ben_Counter = @Ben_Counter
           
           Update TBL_Benefits_DC set Posted = @Proc_Mode,AuditedBy = @username, DateAudited = Getdate()           
           where Ben_Counter = (Select Max(Ben_Counter) from TBL_Benefits_DC Where SchemeNo = @SchemeNo and MemberNo = @MemberNo 
           and ExitReason = @ExitReason and DoCalc = @DoCalc and DOExit = @DoExit) 
           and Posted = @Proc_Mode-1 
       END                              
 END
go

