CREATE PROCEDURE [dbo].[GetAccrualFactorSplit]
@SCHEMENO Int,
@MemberNo Int,
@NonPensionableYears int out,
@NonPensionableMonths int out,
@NonAccrual float out,
@PensionableYears int out,
@PensionableMonths int out,
@Accrual float out
--With Encryption
as
declare @dje Datetime,@djpens Datetime,@DoExit Datetime,
@NumYears Int,@NumMonths Int,@NumDays Int,@AccrualCutOff Datetime,
@CutOffOrService bit

select @AccrualCutOff = AccrualCutOff,@CutOffOrService = CutOffOrService
from ConfigRetirement where SchemeNo = @schemeNo

if @CutOffOrService is null select @CutOffOrService = 1

if @CutOffOrService = 0 /* Based on a Cutoff Date */
begin
   Select @NonAccrual = PensionFactor from PensionFactor
   where SchemeNo = @schemeNo and EndDate <= @AccrualCutOff

   Select @Accrual = PensionFactor from PensionFactor
   where SchemeNo = @schemeNo
   and EndDate >= @AccrualCutOff

   select @dje = dje,@djpens = djpens,@DoExit = DoExit from Members
   where SchemeNo = @schemeNo and MemberNo = @MemberNo

   if @AccrualCutOff > @djpens
      Exec GetServiceTime @djpens,@AccrualCutOff,@NumYears out,@NumMonths Out,@NumDays Out

   select @NonPensionableYears = @NumYears, @NonPensionableMonths = @NumMonths

   select @NumYears = 0,@NumMonths = 0,@NumDays = 0

   Exec GetServiceTime @AccrualCutOff,@doExit,@NumYears out,@NumMonths Out,@NumDays Out

   select @PensionableYears = @NumYears, @PensionableMonths = @NumMonths

end
else
begin
Select @NonAccrual = NonPensionable,@Accrual = Pensionable
from PensionFactorDates
where SchemeNo = @schemeNo

select @dje = dje,@djpens = djpens,@DoExit = DoExit from Members
where SchemeNo = @schemeNo and MemberNo = @MemberNo

Exec GetServiceTime @dje,@djpens,@NumYears out,@NumMonths Out,@NumDays Out

select @NonPensionableYears = @NumYears, @NonPensionableMonths = @NumMonths

select @NumYears = 0,@NumMonths = 0,@NumDays = 0

Exec GetServiceTime @djpens,@doExit,@NumYears out,@NumMonths Out,@NumDays Out

select @PensionableYears = @NumYears, @PensionableMonths = @NumMonths
end
go

