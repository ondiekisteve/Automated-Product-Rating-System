CREATE PROCEDURE [dbo].[ShowBanks]
@Bankcode varchar(15),
@BranchCode varchar(15)
--with Encryption
as

Select b.BankName,br.BankCode, br.BranchCode,br.BranchName
from Bank_Branch br
     inner Join BankSetup b on br.BankCode = b.BankCode
where br.BankCode = @BankCode and br.BranchCode = @BranchCode
go

