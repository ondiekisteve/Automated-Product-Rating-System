CREATE TRIGGER [dbo].[Trg_Invest_Names] ON [dbo].[TBL_Invest_Names] 
FOR UPDATE 
AS

declare @InvName varchar(100),@InvestNo Int,@InvestCode Int

select @InvName = InvestName,@InvestNo = InvestNo,@InvestCode = InvestCode from Inserted

if ((@InvestCode = 5) or (@InvestCode = 7) or (@InvestCode = 8))
  select @InvestCode = @InvestCode
else
   update Investments set InvName = @InvName where InvestNo = @InvestNo
go

