CREATE PROCEDURE [dbo].[PostBatchArrears]
@SCHEMENO Int,
@RevDate datetime
--with Encryption
as
Update Pen_Revise Set BatchArrPaid = 1
where SchemeNo = @schemeNo and RevDate = @RevDate

Update Pen_Revise_Ben Set BatchArrPaid = 1
where SchemeNo = @schemeNo and RevDate = @RevDate
go

