CREATE VIEW [dbo].[PostBalances]              
--with Encryption              
as              
select distinct r.LeaseNo,u.UnitNo,r.SchemeNo,r.PropertyCode,r.UnitCode,r.TenantCode,r.Balance,  
       r.Prepayment,r.BalanceDate,t.TenantName,              
       p.CurrencyType as BaseCurrency,r.DepositRefund as Deposit,((r.DepositRefund + r.Prepayment)- r.Balance) as Refund              
from RentPostBalance r              
     inner Join Property p on r.schemeNo = p.schemeNo and r.PropertyCode = p.PropertyCode              
     inner Join Tenants t on r.schemeNo = t.schemeNo and r.PropertyCode = t.PropertyCode              
                             and r.TenantCode = t.TenantCode       
     inner Join Units U on r.schemeNo = U.schemeNo and r.PropertyCode = U.PropertyCode              
                             and r.UnitCode = U.UnitCode
     inner join Leases l on r.schemeNo = l.schemeNo and r.PropertyCode = l.PropertyCode              
                             and r.LeaseNo = l.LeaseNo and l.LeaseCancelled = 1
go

