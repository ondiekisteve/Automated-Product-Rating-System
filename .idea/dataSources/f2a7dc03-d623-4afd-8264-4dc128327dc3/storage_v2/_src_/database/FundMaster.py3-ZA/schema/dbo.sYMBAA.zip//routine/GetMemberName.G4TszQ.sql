CREATE PROCEDURE [dbo].[GetMemberName]  
@SCHEMENO Int,  
@memberNo int  
--with Encryption  
as  
  
declare @fullname varchar(100)  
  
select @fullname = UPPER(Sname) +',  '+fname+' '+onames from members  
where SchemeNo = @schemeNo and MemberNo  = @memberNo  
  
select @fullname as FullName
go

