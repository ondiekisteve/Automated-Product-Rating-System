CREATE PROCEDURE [dbo].[Proc_Reminders] /* Proc_Reminders 1 */
@WhichOne Int /* 0 - Receipts , 1 - Claims */ 
as

if @WhichOne = 0
begin
if object_id('tempdb..#Reminders') is null                                                     
begin                            
create table #Reminders                            
(                            
        [PenCode][Integer] identity (1,1) Primary Key not null,                            
        [SchemeNo] [Int],
        [SchemeName][varchar](120),
        [DateReceived][datetime],
        [Particulars][varchar](120),
        [Receipt][float],
        [ReceiptNo][varchar](30),
        [PreparedBy][varchar](120),
        [DatePrepared][datetime],
        [TransType][varchar](200)                           
                                                            
)                             
                                             
end                    

/* Receipts Not posted to the Cashbook */
Insert into #Reminders (SchemeNo,SchemeName,DateReceived,Particulars,Receipt,ReceiptNo,PreparedBy,
                        DatePrepared,TransType)       
select SchemeNo,Payee,DateReceived,Particulars,Receipt,ReceiptNo,
Preparedby,DatePosted,upper('Receipts Not posted to the Cashbook') 
from TBL_FundAdministration where Posted <> 2 and TransDate >= 'Apr 1,2012'
order by DateReceived

/* Receipts posted to the Cashbook  but not tied to any batch */
Insert into #Reminders (SchemeNo,SchemeName,DateReceived,Particulars,Receipt,ReceiptNo,PreparedBy,
                        DatePrepared,TransType) 
select SchemeNo,Payee,DateReceived,Particulars,Receipt,ReceiptNo,
Preparedby,DatePosted,upper('Receipts posted to the Cashbook  but not tied to any batch')
from TBL_FundAdministration where Posted = 2 and M_Level_Posted = 0
and TransDate >= 'Apr 1,2012'
 order by DateReceived
end
else if @WhichOne  = 1
begin

if object_id('tempdb..#Reminders1') is null                                                     
begin                            
create table #Reminders1                            
(                            
        [PenCode][Integer] identity (1,1) Primary Key not null,                            
        [SchemeNo] [Int],
        [SchemeName][varchar](120),
        [MemberName][varchar](120),
        [DoCalc][datetime],
        [ExitReason][varchar](120),
        [GrossBenefit][float],
        [PreparedBy][varchar](120),
        [DatePrepared][datetime],
        [TransType][varchar](200)                           
                                                            
)                             
                                             
end       
 
/* Claims */
/* 1. Exits that have not been processed */
Insert into #Reminders1 (SchemeNo,SchemeName,MemberName,DoCalc,ExitReason,GrossBenefit,PreparedBy,DatePrepared,
                        TransType)                       
select m.schemeNo,s.SchemeName,m.sname+', '+m.fname+' '+m.onames,m.docalc,r.reasondesc,0,'',getdate(),
upper('Exits that have not been processed')
from Members m
     inner join Scheme s on m.SchemeNo = s.SchemeCode
     inner join ReasonForExit r on m.ReasonforExit = r.ReasonCode
where m.ReasonForExit > 0 and m.ActiveStatus <> 6 and m.docalc >= 'Apr 1,2012' and m.MemberNo not in (select MemberNo from TBL_Benefits_DC ) 

/* 1. Processed Exits that have not been Certified */
Insert into #Reminders1 (SchemeNo,SchemeName,MemberName,DoCalc,ExitReason,GrossBenefit,PreparedBy,DatePrepared,
                        TransType)                       
select m.schemeNo,s.SchemeName,m.sname+', '+m.fname+' '+m.onames,t.docalc,r.reasondesc,t.amountPayable,t.preparedBy,
t.dateprepared,upper('Processed Exits that have not been Certified')
from TBL_Benefits_DC t
     inner join Scheme s on t.SchemeNo = s.SchemeCode
     inner join Members m on t.SchemeNo = m.SchemeNo and t.MemberNo = m.membernO
     inner join ReasonForExit r on t.ExitReason = r.ReasonCode 
WHERE t.docalc >= 'Apr 1,2012' and t.Posted = 0 
order by t.DatePrepared

/* 1. Processed Exits that have been Certified but not authorised */
Insert into #Reminders1 (SchemeNo,SchemeName,MemberName,DoCalc,ExitReason,GrossBenefit,PreparedBy,DatePrepared,
                        TransType)                       
select m.schemeNo,s.SchemeName,m.sname+', '+m.fname+' '+m.onames,t.docalc,r.reasondesc,t.amountPayable,t.preparedBy,
t.dateprepared,upper('Processed Exits that have been Certified but not authorised')
from TBL_Benefits_DC t
     inner join Scheme s on t.SchemeNo = s.SchemeCode
     inner join Members m on t.SchemeNo = m.SchemeNo and t.MemberNo = m.membernO
     inner join ReasonForExit r on t.ExitReason = r.ReasonCode 
WHERE t.docalc >= 'Apr 1,2012' and t.Posted = 1 
order by t.DatePrepared

/* 1. Processed Exits that have been Certified, authorised but not Posted */
Insert into #Reminders1 (SchemeNo,SchemeName,MemberName,DoCalc,ExitReason,GrossBenefit,PreparedBy,DatePrepared,
                        TransType)                       
select m.schemeNo,s.SchemeName,m.sname+', '+m.fname+' '+m.onames,t.docalc,r.reasondesc,t.amountPayable,t.preparedBy,
t.dateprepared,upper('Processed Exits that have been Certified, authorised but not Posted')
from TBL_Benefits_DC t
     inner join Scheme s on t.SchemeNo = s.SchemeCode
     inner join Members m on t.SchemeNo = m.SchemeNo and t.MemberNo = m.membernO
     inner join ReasonForExit r on t.ExitReason = r.ReasonCode 
WHERE t.docalc >= 'Apr 1,2012' and t.Posted = 2
order by t.DatePrepared

end

if @WhichOne  = 0
   select * from #Reminders order by TransType,DatePrepared
else
   select * from #Reminders1 order by TransType,DatePrepared
go

