CREATE FUNCTION [dbo].[fn_Rn_Rebasing](@Amount decimal(30,8),@Rounder int)                  
/*@Rounder = 0 usual two decimal places, 1 - four decimal places, 2 - rounding up, 3 - No rounding, 4 - round up without rebasing */                    
returns float                   
as                    
begin                    
declare @AmountStr varchar(100),@wholepart bigInt,@DecPart BigInt,@lenWhole int,@LenDec Int,                  
@DecPartStr varchar(30),@WholePartStr varchar(30),@NewAmount decimal(30,6),@RebaseFactor float,  
@BelowZero smallint,@NumZeros Int                   
                 
select @RebaseFactor = 1000.000,@NumZeros = 0                 
                
if @Amount < 0                
   begin                
   select @BelowZero = 1                
   select @Amount = ABS(@Amount)                
   end                
else                
   select @BelowZero = 0                  
                  
IF @Amount <> 0         
   begin         
      if @Rounder < 4                
         select @Amount = @Amount/@RebaseFactor               
   end                 
ELSE                
   select @NewAmount = 0                  
                  
if @Amount <> 0                  
   select @AmountStr = cast(@Amount as varchar(30))                  
else                  
   select @AmountStr = '0'                    
          
if @rounder = 3 /* No rounding */                 
   select @NewAmount = @Amount                   
if @rounder = 0  /* rounding to two decimal places */                
   select @NewAmount = round(@Amount,2)                  
else if @Rounder = 1  /* Rounding to four decimal places */                
   select @NewAmount = round(@Amount,4)                     
else if ((@Rounder = 2) or (@Rounder = 4)) /* Rounding upwards */                  
   BEGIN                  
    if patIndex('%.%',@AmountStr) > 0                  
       begin                  
   select @wholepart = cast(Left(@AmountStr,patIndex('%.%',@AmountStr) - 1) as BigInt)                  
                    
   select @WholePartStr = CAST(@wholepart as varchar(30))                 
                  
   select @lenWhole = LEN(@AmountStr)                  
   select @LenDec = @lenWhole - (LEN(@WholePartStr) + 1)                
                      
   select @DecPartStr = right(@AmountStr,@LenDec)                  
   select @DecPart = CAST(@DecPartStr as bigInt)     
       
   if LEFT(@DecPartStr,1) = 9 and RIGHT(LEFT(@DecPartStr,2),1) = 9 and RIGHT(LEFT(@DecPartStr,3),1) in (1,2,3,4,5,6,7,8,9)     
   /* Decipal part has a .99 something */    
    BEGIN     
       if @BelowZero = 0    
          begin    
    select @wholepart = @wholepart + 1    
    select @WholePartStr = CAST(@wholepart as varchar(30))    
    select @DecPartStr = '00'    
    end    
       else     
          begin    
     select @wholepart = @wholepart - 1    
     select @WholePartStr = CAST(@wholepart as varchar(30))    
     select @DecPartStr = '00'    
    end     
    END     
   else    
       BEGIN   
          /* Check if there are leading Zeros  in the Decimal Part */    
          if LEFT(@DecPartStr,1) = '0' and RIGHT(LEFT(@DecPartStr,2),1) = '0'   
             select @NumZeros = 2  
          else if LEFT(@DecPartStr,1) = '0' and RIGHT(LEFT(@DecPartStr,2),1) in (1,2,3,4,5,6,7,8,9)  
             select @NumZeros = 1  
                        
     if RIGHT(LEFT(@DecPartStr,3),1) in(1,2,3,4,5,6,7,8,9)      
     BEGIN   
       if @NumZeros = 0 /* No Leading Zeros in the decimal Part */   
          BEGIN    
      if @BelowZero = 0                
      select @DecPartStr = cast((LEFT(@DecPart,2) + 1) as varchar(30))       
      else      
      select @DecPartStr = cast((LEFT(@DecPart,2) - 1) as varchar(30))   
       END   
    else if @NumZeros = 1 /* One leading Zeros the decimal Part */   
          BEGIN    
      if @BelowZero = 0   
         begin  
             if LEFT(@DecPart,1) = 9 /* Second digit in decimal part is 9 */   
                select @DecPartStr = '10'  
             else           
                select @DecPartStr = '0' + cast((LEFT(@DecPart,1) + 1) as varchar(30))   
         end      
      else  
         begin               
              select @DecPartStr = '0' + cast((LEFT(@DecPart,1) - 1) as varchar(30))  
              -- select @DecPartStr = cast((LEFT(@DecPart,2) - 1) as varchar(30))  
         end   
       END   
    else if @NumZeros = 2 /* two leading Zeros the decimal Part */   
          BEGIN    
      if @BelowZero = 0   
         begin  
            select @DecPartStr = '01'  
         end      
      else  
         begin               
            select @DecPartStr = '00'   
         end   
       END           
     END                              
     else 
     BEGIN 
        if RIGHT(LEFT(@DecPartStr,3),1) in(0) 
           BEGIN
              if @NumZeros = 1
                 begin
					select @DecPartStr = '0' + cast((LEFT(@DecPart,1)) as varchar(30)) 
                 end
              else if @NumZeros = 2
                 begin
					select @DecPartStr = '00' 
                 end
              else
                 select @DecPartStr = cast((LEFT(@DecPart,2)) as varchar(30))   
           END
        else                     
           select @DecPartStr = cast((LEFT(@DecPart,2)) as varchar(30)) 
     END    
          
     END                     
                          
     select @NewAmount  = cast((@wholepartStr+'.'+@DecPartStr)as float)                  
        end                   
     else                  
        select @NewAmount = @Amount                 
   END                
                   
   if @BelowZero  = 1                 
     select @NewAmount  = 0 - @NewAmount                   
                     
 RETURN(@newAmount)                    
end
go

