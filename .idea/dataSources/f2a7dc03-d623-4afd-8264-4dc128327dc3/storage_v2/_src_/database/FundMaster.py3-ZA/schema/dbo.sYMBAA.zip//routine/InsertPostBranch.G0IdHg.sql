CREATE PROCEDURE [dbo].[InsertPostBranch]
@townCode int,
@PostCode varchar(15),
@PostOffice varchar(50)
--with Encryption
as

declare @PostaCode Int
Select @PostaCode = Max(PostaCode) from PostBranch
                    where TownCode = @TownCode

if @PostaCode is Null
Select @PostaCode = 0

Select @PostaCode = @PostaCode + 1

if Exists(Select * from PostBranch where TownCode = @TownCode and PostOffice = @PostOffice)
   begin
     raiserror('% already Exists',16,1,@PostOffice)
     return
   end
else
   Insert Into PostBranch (PostOffice,PostCode,TownCode,PostaCode)
            Values(@PostOffice,@PostCode,@TownCode,@PostaCode)
go

