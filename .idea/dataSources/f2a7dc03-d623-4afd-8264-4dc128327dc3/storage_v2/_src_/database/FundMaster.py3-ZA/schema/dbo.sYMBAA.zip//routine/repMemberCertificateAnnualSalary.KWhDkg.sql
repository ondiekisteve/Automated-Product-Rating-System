CREATE PROCEDURE [dbo].[repMemberCertificateAnnualSalary]
@SCHEMENO Int,
@memberNo int,
@currYear int,
@annualSalary float output
--with Encryption
as

select @annualSalary = CAPenSal from Members where SchemeNo = @schemeNo and memberNo = @memberNo
go

