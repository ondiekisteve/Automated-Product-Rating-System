CREATE FUNCTION [dbo].[fn_ListMembers]
                 ( @SCHEMENO Int)
RETURNS table
AS
RETURN (
        SELECT schemeNo,MemberNo, SName,fName,Onames
        FROM Members
        WHERE schemeNo = @SchemeNo
       )
go

