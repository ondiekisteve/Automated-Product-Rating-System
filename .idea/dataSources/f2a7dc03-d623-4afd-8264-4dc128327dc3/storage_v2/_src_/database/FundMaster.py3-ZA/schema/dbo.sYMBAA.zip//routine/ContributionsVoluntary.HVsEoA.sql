CREATE PROCEDURE [dbo].[ContributionsVoluntary]
@SchemeNo varchar(15),
@curYear int
--with Encryption
as

if object_id('tempdb..##GeneralUnReg') is null

begin
create table ##GeneralUnReg
(
	[MemberNo] [int] NOT NULL ,
	[fullname] [varchar](100) NOT NULL ,
	[EmpOpening] [float] NULL,
        [EmprOpening] [Float] null,
        [EmpCont][float] null,
        [EmprCont] [float] null,
        [Total][float] null,
        [SchemeName][varchar](120),
        [Period][varchar](30)    
) 

ALTER TABLE ##GeneralUnReg WITH NOCHECK ADD 

            
	CONSTRAINT [PK_GeneralUnReg] PRIMARY KEY  NONCLUSTERED 
	(
          
	  [MemberNo]      
	) 
end

Delete from ##GeneralUnReg 

declare @MemberNo int,@fullName varchar(100),@EmpOpen float,@EmprOpen float,@EmpOpen1 float,@Empropen1 float,
@Empcont float,@EmprCont float,@Total float,@SchemeName varchar(120),
@EndDate Datetime,@AcctPeriod int,@StartMonth int,@RepDesc varchar(25)

Select @EndDate = EndDate from schemeYears where schemeNo = @SchemeNo and 
DatePart(Year, EndDate) = @CurYear

Select @StartMonth = DatePart(Month,@EndDate)

if @StartMonth = 12 Select @RepDesc = '31st December,'
else if @StartMonth = 6 select @RepDesc = '30th June,'

Exec GetAccountingPeriodInAYear @SchemeNo,@StartMonth,@CurYear,@AcctPeriod out

Select @SchemeName = SchemeName from scheme where schemeCode = @SchemeNo

Declare Acsr cursor for
Select m.MemberNo, Upper(m.sname)+', '+m.fname+' '+m.Onames as FullName,
sum(c.ExcessVolContr + c.VolContr) as EmployeeCont,
sum(c.ExcessSpecial + c.SpecialContr) as EmprCont
from Members m
     inner Join Contributionssummary c on 
           m.SchemeNo = c.SchemeNo and m.MemberNo= c.MemberNo and c.AcctPeriod = @AcctPeriod
where m.SchemeNo = @SchemeNo and m.ReasonforExit = 0
Group by m.MemberNo,m.sname,m.fname,m.onames


Open Acsr

fetch from Acsr into @MemberNo,@fullname,@EmpCont,@EmprCont

While @@fetch_Status = 0
begin
   if (@Empcont > 0) or (@EmprCont > 0)
      begin
      
      Select @EmpOpen = ExcessVolContr, @EmprOpen = ExcessSpecial
      from UnregisteredBalances
      where SchemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1

      if @EmpOpen is null select @EmpOpen = 0
      if @EmprOpen is null select @EmprOpen = 0
      
      Select @EmpOpen1 = EmpVolCont, @EmprOpen1 = EmprVolcont
      from MemberOpeningBalances
      where SchemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1

      if @EmpOpen1 is null select @EmpOpen1 = 0
      if @EmprOpen1 is null select @EmprOpen1 = 0
   
      Select @EmpOpen = @EmpOpen + @EmpOpen1
      Select @EmprOpen = @EmprOpen + @EmprOpen1

   Insert into ##GeneralUnReg (MemberNo,fullname,Empcont,EmprCont, EmpOpening,EmprOpening, total, Period, SchemeName)
               Values(@MemberNo,@fullname,@Empcont,@EmprCont,@EmpOpen,@EmprOpen, @Empcont+@EmprCont+@EmpOpen+@EmprOpen,
                      @RepDesc+' '+cast(@curYear as varchar(4)),@SchemeName)

   Select @EmpOpen = 0
   Select @EmprOPEN = 0
   Select @EmpOpen1 = 0
   Select @EmprOPEN1 = 0
   
    end
   fetch from Acsr into @MemberNo,@fullname,@EmpCont,@EmprCont
end
Close Acsr
Deallocate Acsr

Select * from ##GeneralUnReg order by MemberNo
go

