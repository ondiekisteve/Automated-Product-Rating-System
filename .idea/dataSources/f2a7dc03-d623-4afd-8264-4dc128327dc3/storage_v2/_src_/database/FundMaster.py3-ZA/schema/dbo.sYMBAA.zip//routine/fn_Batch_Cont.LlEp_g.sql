CREATE FUNCTION [dbo].[fn_Batch_Cont]( @schemeNo int , @MemberNo Int , @BatchId Int)
returns int
as
begin
    declare @Contr float

    select @Contr = (EmpCont + EmprCont + VolContr + SpecialContr)
    from BatchEntry where schemeNo = @schemeNo and MemberNo = @MemberNo and BatchId = @BatchId
    
    RETURN (@Contr)
end
go

