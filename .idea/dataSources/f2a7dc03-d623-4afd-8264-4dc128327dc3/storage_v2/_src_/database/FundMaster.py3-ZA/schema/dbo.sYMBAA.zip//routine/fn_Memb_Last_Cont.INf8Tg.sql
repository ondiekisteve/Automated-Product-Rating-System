CREATE FUNCTION [dbo].[Fn_memb_last_cont](@schemeNo INT,
                                          @MemberNo INT)
returns FLOAT
AS
  BEGIN
      DECLARE @Contr    FLOAT,
              @datepaid DATETIME

      SELECT @datepaid = Max(datepaid)
      FROM   contributionssummary
      WHERE  schemeNo = @schemeNo
             AND MemberNo = @MemberNo

      SELECT @Contr = ( EmpCont + EmprCont + VolContr + SpecialContr)
      FROM   contributionssummary
      WHERE  schemeNo = @schemeNo
             AND MemberNo = @MemberNo
             AND datepaid = @datepaid

      IF @Contr IS NULL
        SELECT @Contr = 0

      RETURN ( @Contr )
  END
go

