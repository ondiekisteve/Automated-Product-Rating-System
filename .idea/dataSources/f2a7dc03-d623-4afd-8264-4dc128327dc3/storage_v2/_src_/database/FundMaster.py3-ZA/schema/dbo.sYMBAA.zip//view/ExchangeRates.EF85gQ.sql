CREATE VIEW [dbo].[ExchangeRates]    
--with encryption    
as    
    
Select r.ExchangeDate, r.ExchangeRate,R.TransCurrCode as CurrencyCode,
       r.SchemeNo,c.CurrencyDesc     
from CurrencyRates r    
     inner Join CurrencyType c on r.TransCurrCode = c.CurrCode
go

