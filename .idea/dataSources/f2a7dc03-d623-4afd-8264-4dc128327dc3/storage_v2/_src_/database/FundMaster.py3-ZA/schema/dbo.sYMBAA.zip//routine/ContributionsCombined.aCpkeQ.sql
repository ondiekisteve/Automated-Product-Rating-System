CREATE PROCEDURE [dbo].[ContributionsCombined]
@SCHEMENO Int,
@CurYear int
--with Encryption
as

if object_id('tempdb..##General') is null

begin
create table ##General
(
	[MemberNo] [int] NOT NULL ,
	[fullname] [varchar](100) NOT NULL ,
	[EmpOpening] [float] NULL,
        [EmprOpening] [Float] null,
        [EmpOpeningUn] [float] NULL,
        [EmprOpeningUn] [Float] null,
        [EmpCont][float] null,
        [EmprCont] [float] null,
        [EmpContUn][float] null,
        [EmprContUn] [float] null,
        [Total][float] null,
        [Period][varchar](30) null,
        [SchemeName][varchar](100)    
) 

ALTER TABLE ##General WITH NOCHECK ADD 

            
	CONSTRAINT [PK_General] PRIMARY KEY  NONCLUSTERED 
	(
          
	  [MemberNo]      
	) 
end

Delete from ##General 

declare @MemberNo int,@fullName varchar(100),@EmpOpen float,@EmprOpen float,@EmpOpen1 float,@EmprOpen1 float,
@Empcont float,@EmprCont float,@Total float, @SchemeName varchar(120),
@EndDate Datetime,@AcctPeriod int,@StartMonth int,@RepDesc varchar(25),
@EmpcontUn float,@EmprContUn float

Select @EndDate = EndDate from schemeYears where schemeNo = @SchemeNo and 
DatePart(Year, EndDate) = @CurYear

Select @StartMonth = DatePart(Month,@EndDate)

Exec DateToStr @EndDate,@RepDesc Out

Exec GetAccountingPeriodInAYear @SchemeNo,@StartMonth,@CurYear,@AcctPeriod out

Select @SchemeName = SchemeName from scheme where SchemeCode  = @SchemeNo

Declare Acsr cursor for
Select m.MemberNo, Upper(m.sname)+', '+m.fname+' '+m.Onames as FullName,
sum(c.EmpCont + c.Volcontr) as EmployeeCont,sum(c.EmprCont + c.SpecialContr) as EmployerCont,
sum(c.ExcessEmpCont +  c.ExcessVolContr), sum(c.ExcessEmprCont + c.ExcessSpecial)
from Members m
     inner Join Contributionssummary c on 
           m.SchemeNo = c.SchemeNo and m.MemberNo= c.MemberNo 
           and c.AcctPeriod = @AcctPeriod
where m.SchemeNo = @SchemeNo and m.ReasonforExit = 0
Group by m.MemberNo,m.sname,m.fname,m.onames


Open Acsr

fetch from Acsr into @MemberNo,@fullname,@EmpCont,@EmprCont,@EmpContUn,@EmprContUn

While @@fetch_Status = 0
begin
   Select @EmpOpen = EmpCont + EmpVolCont+PreEmpCont + PreAvc + Transfer, @EmprOpen = EmprCont + EmprVolcont + PreEmprCont 
   from MemberOpeningBalances
   where SchemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1

   if @EmpOpen is null select @EmpOpen = 0
   if @EmprOpen is null select @EmprOpen = 0
   
   
   Select @EmpOpen1 = ExcessEmp + ExcessVolContr,
   @EmprOpen1 = ExcessEmpr + ExcessSpecial
   from UnregisteredBalances
   where SchemeNo = @SchemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod - 1

   if @EmpOpen1 is null select @EmpOpen1 = 0
   if @EmprOpen1 is null select @EmprOpen1 = 0

 
   Insert into ##General (MemberNo,fullname,Empcont,EmprCont, EmpOpenING,EmprOpening, total,
                          SchemeName, Period,EmpcontUn,EmprContUn, EmpOpenINGUn,EmprOpeningUn)
               Values(@MemberNo,@fullname,@Empcont,@EmprCont,@EmpOpen,@EmprOpen,
                      @EmpCont + @EmprCont + @EmpOpen + @EmprOpen + @EmpContUn + @EmprContUn + @EmpOpen1 + @EmprOpen1,
                      @SchemeName, @RepDesc,
                      @EmpcontUn,@EmprContUn,@EmpOpen1,@EmprOpen1)

   Select @EmpOpen = 0
   Select @EmprOPEN = 0
   Select @EmpOpen1 = 0
   Select @EmprOPEN1 = 0,@EmpContUn = 0,@EmprContUn=0
   fetch from Acsr into @MemberNo,@fullname,@EmpCont,@EmprCont,@EmpContUn,@EmprContUn
end
Close Acsr
Deallocate Acsr

Select * from ##General order by MemberNo
go

