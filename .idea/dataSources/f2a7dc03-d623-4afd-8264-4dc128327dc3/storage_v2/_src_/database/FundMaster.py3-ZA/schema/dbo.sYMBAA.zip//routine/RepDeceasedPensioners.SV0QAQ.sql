CREATE PROCEDURE [dbo].[RepDeceasedPensioners]    
@SCHEMENO Int,    
@StartDate Datetime,    
@EndDate Datetime    
--with Encryption    
as    
    
Select p.PenNo,p.MonPension,pd.DoDeath ,pd.Cause,m.IDNumber,m.PayrollNo,    
       m.CheckNo, upper(m.sName)+', '+m.fName+' '+m.Onames as FullName,m.DoExit,    
       s.SchemeName, datediff(Year,m.dob,pd.doDeath) as AgeatDeath,    
       datediff(Month,m.DoExit,pd.DoDeath) as PensionYears,    
       ' ' AS SponsorName,@StartDate as StartDate,@EndDate as EndDate    
from PenDeathClaim pd    
     inner Join Pensioner p on pd.schemeNo = p.SchemeNo and pd.MemberNo = p.MemberNo    
     inner Join Members m on pd.schemeNo = m.SchemeNo and pd.MemberNo = m.MemberNo    
     inner Join Scheme s on pd.schemeNo = s.SchemeCode    
where pd.SchemeNo = @SchemeNo and pd.DoDeath >= @StartDate and pd.DoDeath <= @EndDate
go

