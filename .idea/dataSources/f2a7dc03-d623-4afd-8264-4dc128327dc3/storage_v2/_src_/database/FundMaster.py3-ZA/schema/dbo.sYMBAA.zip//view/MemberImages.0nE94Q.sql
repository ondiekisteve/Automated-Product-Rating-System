CREATE VIEW [dbo].[MemberImages] 
--with encryption
as
Select a.*, b.ImageDescription
from ImageMembers a
     inner Join Images b on a.ImageCode = b.ImageCode
           and a.ImageNo = b.ImageNo
go

