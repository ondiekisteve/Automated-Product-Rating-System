CREATE PROCEDURE [dbo].[calcBenefits_Surplus_Indiv]
@SCHEMENO Int,
@MemberNo Int,
@RefundDate Datetime,
@IntMode Int

--with Encryption
as

declare @useBalances bit,
@totEmpCont float,
@totEmprCont float,@ProcessDate datetime,
@AcctPeriod int, @PeriodToUse int,
@StartDate Datetime,@EndDate Datetime,
@CalculationMode Int,@HasBal int,
@CurMonth Int,@CurYear Int,@MinAcctPeriod Int,@MaxAcctPeriod Int,@YearClosed Int,
@EmpContributions float

select @MinAcctPeriod = Min(AcctPeriod),@EmpContributions = sum(EmpCont) 
from Contributionssummary where schemeNo = @schemeNo and MemberNo = @MemberNo and 
Surplus = 1

if @EmpContributions is null select @EmpContributions = 0

Select @MaxAcctPeriod = AcctPeriod from schemeYears where schemeNo = @schemeNo and StartDate <= @RefundDate
and EndDate >= @RefundDate

begin tran

select @CalculationMode = CalculationMode 
from ConfigYearEnd where SchemeNo = @schemeNo

if @MinAcctPeriod <> @MaxAcctPeriod
begin
   while @MinAcctPeriod <= @MaxAcctPeriod - 1
   begin
     
    Select @StartDate = StartDate,@EndDate = EndDate,@ProcessDate = EndDate ,@YearClosed = YearClosed
    from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @MinAcctPeriod

    select @CurMonth = DatePart(Month,@ProcessDate),@CurYear = DatePart(Year,@ProcessDate)

    Select @PeriodToUse = @MinAcctPeriod - 1

    if exists(select * from memberOpeningBalances 
            where SchemeNo = @schemeNo and memberNo = @memberNo 
            and AcctPeriod = @PeriodToUse and (EmpSurplus + EmprSurplus) > 0) select @hasBal = 1
    else select @hasBal = 0

   if @CalculationMode = 12
     begin
       Exec Proc_CalcMonthlyInterestSI_GEPF_Surplus @schemeNo,@memberNo,@ProcessDate,
            @hasbal,@IntMode,@totEmpCont output,@totEmprCont output

       if @YearClosed = 1
          update SchemeYears set YearClosed = 0 where schemeNo = @schemeNo and AcctPeriod = @MinAcctPeriod

       if not Exists(select * from MemberOpeningBalances where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)
                     and AcctPeriod = @MinAcctPeriod)         
              insert into  MemberOpeningBalances
                   (SchemeNo, MemberNo, AcctPeriod,SchemeYear,SchemeMonth,EmpSurplus, EmprSurplus)
              values
                   (@schemeNo, @memberNo, @MinAcctPeriod,@CurYear,@CurMonth,@totEmpCont, @totEmprCont)
         else
              update MemberOpeningBalances set EmpSurplus = @totEmpCont, EmprSurplus = @totEmprCont
              where(SchemeNo = @schemeNo) and(MemberNo = @memberNo) and AcctPeriod = @MinAcctPeriod

       if @YearClosed = 1
          update SchemeYears set YearClosed = 1 where schemeNo = @schemeNo and AcctPeriod = @MinAcctPeriod

       select @totEmpCont = 0,@totEmprCont = 0
     end

    select @MinAcctPeriod = @MinAcctPeriod + 1
  end

  /* Calculate Interest for the Refund Year */
  if @CalculationMode = 12
     begin
       Exec Proc_CalcMonthlyInterestSI_GEPF_Surplus @schemeNo,@memberNo,@RefundDate,
            1,@IntMode,@totEmpCont output,@totEmprCont output

       if not Exists(select * from SurplusRefund where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)
                     and AcctPeriod = @MaxAcctPeriod)         
              insert into  SurplusRefund
                   (SchemeNo, MemberNo, AcctPeriod,DateRefund,Amount,Posted,EmpRefund, EmprRefund,EmpContributions)
              values
                   (@schemeNo, @memberNo, @MaxAcctPeriod,@RefundDate,@totEmpCont + @totEmprCont,0,@totEmpCont, @totEmprCont,
                    @EmpContributions)
         else
              update SurplusRefund set EmpRefund = @totEmpCont, EmprRefund = @totEmprCont,
              Amount = @totEmpCont + @totEmprCont,EmpContributions = @EmpContributions
              where(SchemeNo = @schemeNo) and(MemberNo = @memberNo) and AcctPeriod = @MaxAcctPeriod

       select @totEmpCont = 0,@totEmprCont = 0

     end


end

else if @MinAcctPeriod = @MaxAcctPeriod
begin
/* Calculate Interest for the Refund Year */
  if @CalculationMode = 12
     begin
       Exec Proc_CalcMonthlyInterestSI_GEPF_Surplus @schemeNo,@memberNo,@RefundDate,
            0,@IntMode,@totEmpCont output,@totEmprCont output

       if not Exists(select * from SurplusRefund where(SchemeNo = @schemeNo) and(MemberNo = @memberNo)
                     and AcctPeriod = @MaxAcctPeriod)         
              insert into  SurplusRefund
                   (SchemeNo, MemberNo, AcctPeriod,DateRefund,Amount,Posted,EmpRefund, EmprRefund,EmpContributions)
              values
                   (@schemeNo, @memberNo, @MaxAcctPeriod,@RefundDate,@totEmpCont + @totEmprCont,0,@totEmpCont, @totEmprCont,
                    @EmpContributions)
         else
              update SurplusRefund set EmpRefund = @totEmpCont, EmprRefund = @totEmprCont,
              Amount = @totEmpCont + @totEmprCont,EmpContributions = @EmpContributions
              where(SchemeNo = @schemeNo) and(MemberNo = @memberNo) and AcctPeriod = @MaxAcctPeriod

       select @totEmpCont = 0,@totEmprCont = 0
     end
end

commit tran
go

