CREATE PROCEDURE [dbo].[Proc_LoanRepayment]
@SCHEMENO Int,
@MortgageNo Int,
@PaymentDate Datetime,
@AmountPaid float,
@ChequeNo Varchar(20),
@ReceiptNo Varchar(20),
@AddEdit Int
as

if @AddEdit = 0
Insert Into MortgageRepayment (schemeNo,MortgageNo,PaymentDate,AmountPaid,ChequeNo,ReceiptNo)
                    Values(@SchemeNo,@MortgageNo,@PaymentDate,@AmountPaid,@ChequeNo,@ReceiptNo)

else
update MortgageRepayment set AmountPaid = @AmountPaid,ChequeNo = @ChequeNo,ReceiptNo = @ReceiptNo
where schemeNo = @schemeNo and MortgageNo = @MortgageNo and PaymentDate = @PaymentDate
go

