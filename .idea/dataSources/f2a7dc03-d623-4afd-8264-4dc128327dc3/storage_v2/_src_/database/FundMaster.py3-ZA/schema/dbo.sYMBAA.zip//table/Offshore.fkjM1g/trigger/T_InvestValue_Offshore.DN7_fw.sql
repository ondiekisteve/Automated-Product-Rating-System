CREATE TRIGGER [dbo].[T_InvestValue_Offshore] ON [dbo].[Offshore] 
FOR UPDATE
AS

declare @SchemeNo Varchar(15),@SecurityNo Int,@AmountInvested Decimal(20,2),@DateInvested Datetime,
@RebateComm Decimal(20,2),@MarketValue decimal(20,2),@BankAcc varchar(30),@TiedToGl smallint

select @schemeNo = schemeNo,@SecurityNo = OffshoreNo,@AmountInvested = UnitsBought * CostPerUnit,@RebateComm = RebateComm,
@DateInvested = DateInvested,@MarketValue = MarketValue,@BankAcc = BankAcc from Inserted


Exec Proc_Update_Tied @schemeNo,@SecurityNo,@TiedToGl out

if @TiedToGl > 1 select @TiedToGl = 1

if @MarketValue is null select @MarketValue = 0

if @MarketValue = 0
   select @MarketValue = @AmountInvested

update Investments set InitValue = @AmountInvested,DateComm =  @DateInvested,RebateComm = @RebateComm,MarketValue = @MarketValue
where schemeNo = @schemeNo and InvCode = @SecurityNo

update offshore set TiedToGl = @TiedToGl
where schemeNo = @schemeNo and OffshoreNo = @SecurityNo


if @BankAcc is null select @BankAcc ='0'

if @BankAcc <> '0'
begin
if not Exists(select AccountCode from schemeBankBranch where schemeNo = @schemeNo and AccountCode = @BankAcc)
  begin
      raiserror('The Bank account specified has not been set up under the Scheme Bankers in Scheme set up',16,1)
      return
  end
end
go

