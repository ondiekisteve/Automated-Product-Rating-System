CREATE PROCEDURE [dbo].[RepDeathCalculationSheetDB]                                      
@SCHEMENO Int,                                      
@memberNo int                                      
--with Encryption                                      
as                                      
                                      
set nocount on                                      
                                      
if object_id('tempdb..#Calculation') is null                                      
                                      
begin                                      
create table #Calculation                                      
(          [SchemeNo] [Int] NOT NULL ,                                      
           [MemberNo] [int] NOT NULL ,                                      
           [schemeName][varchar](100) not null,                                      
           [fullname][varchar](100) not null,                                      
           [Sex][varchar](10) not null,                                      
           [Dob][datetime] not null,                                      
           [DJE][Datetime] null,                                      
           [djpens][datetime] not null,                                      
           [AgeDesc][varchar](50) not null,                                      
           [DateOfExit][datetime] not null,                                      
           [curYear] [int] NOT NULL,                                      
           [Salary][float] not null,                                      
           [CalcService][int] not null,                                      
           [pastservice][float] not null,                                      
           [comm][float] null,                                      
           [ServiceTime][varchar](100) not null,                                      
           [PensionFactor][float] not null,                                      
           [Benefits] [float]  NULL ,                                      
           [BenefitsBC][float] not null,                                      
           [lumpsum] [float]  NULL ,                                      
           [TaxfreeLumpsum][float] not null,                                      
           [WithHoldingTax][float] default 0,                                      
           [Reason][varchar](25) not null,                                      
           [ReducedPension][float] not null,                                      
           [AmountPayable][float] default 0.0,                                      
           [ActFactors][float] default 0.0,                                      
           [TaxableAmount][float]  null,                                      
           [CalcYears][float] not null,                                      
           [DeathBenefit][float] default 0.0,                                      
           [DeathFactor][float] default 0.0,                                      
           [DesigNation][Varchar](50) null,                                      
           [MonPension][float] not null ,                                      
           [preparedby][varchar](60) null,                                      
           [DatePrepared][smalldatetime] null,                                      
           [CheckedBy][varchar](60) null,                                      
           [DateChecked][smalldatetime] null,                                      
           [AuthorisedBy][varchar](60) null,                                      
           [DateAuthorised][smalldatetime] null,                                
           [Auditedby][varchar](60) null,                                      
           [DateAudited][smalldatetime] null,                                      
           [LumpFactor][Int],                                      
           [RemFactor][Int],                                      
           [Additional][float],      
           [PensionMpya][float],                                      
           [BreakInService][Varchar](50),                                      
           [DeathSalary][float],                                      
       [AVC][float],                                      
           [DeathBenefit1][float],          
           [BenPensionable][smallInt],                                      
           [ReducedPeriod][Integer],                         
           [doCalc][Datetime],                                      
           [Contributions][float],                     
           [RealGratuity][float],                                
           [SponsorName][varchar](100),                              
           [IncFactor][float],                              
           [OldBenefits][float],                      
           [OldBenefits1][float],                            
           [MaxCont][datetime],                          
           [Increament][float],              
           [SpousePension][float],              
           [DepWithSpouse][float],              
           [DepWithoutSpouse][float],            
           [CreditService][Int],            
           [DGok][datetime],        
           [CreditServiceDesc][varchar](150)                                      
                                                        
)                              
                                      
ALTER TABLE #Calculation WITH NOCHECK ADD                                        
                                                  
 CONSTRAINT [PK_Calculation] PRIMARY KEY  NONCLUSTERED                                       
 (                                      
  [SchemeNo],                                      
  [memberNo]                                            
)                                       
end                                      
                                      
                                      
declare @fullname varchar(100)                                      
declare @schemeName varchar(100)                                      
declare @DateOfExit datetime                                    
declare @pastService float                                      
declare @Benefits float                                      
declare @lumpsum float                                      
declare @ResidualPension float                                      
declare @comm  float                                      
declare @PensionFactor float                                      
declare @taxfreelumpsum float                                      
declare @withHoldingTax float                                      
declare @dje datetime                                      
declare @djpens datetime                                     
declare @curYear int                                      
declare @Salary float                                      
declare @ContrMonth int                                      
declare @ServiceTime varchar(100)                                      
declare @dob datetime                                      
declare @dbMode int                                      
declare @CalcService float                                      
declare @sex varchar(10)                                      
declare @Reason varchar(25)                                      
declare @AgeDesc varchar(50)                                      
declare @Years int                                      
declare @ReducedPension float                                      
declare @AmountPayable float                                      
declare @CalcYears float,@checkNo int,@MaxService int,@AmtCov Int                                      
declare @Service int, @Designation varchar(50), @dTemp datetime, @TempService int, @AddedServ int,@HalfDays int,@FullDays int,                                      
@GratPeriod Int,@DesignCode int,@Title varchar(20),@BenReduce Bit,@SalaryFactorUn float,@RemFactor Int,@AddCode Int,                       
@AddRate float,@TotalMonths Int,@SalaryDiff Int,@dSalaryMode Int,@MaxDate Datetime,@DeathSalary float,@NumYears Int,                                      
@NumMonths Int,@NumDays Int,@TotalDays int,@MaDays Int,@BreakInService Varchar(50),                                      
@AVC float,@DeathBenefit1 float,@BenPensionable bit,@HalfMonths Int,@Miezi Int,@BenefitMode smallInt,@DoCalc Datetime,                                      
@MaYears Int,@TelPosta smallInt,@DoExit Datetime,@prospect SmallInt,@ProService int,@Contributions float,                                    
@RealGratuity float,@TransType Int,@Auditedby varchar(60),@DateAudited smalldatetime,@SponsorName varchar(100),                                
@SponsorCode Int,@SchemeMode smallint,@ActiveStatus smallint,@mukuba smallint,@MaxCont datetime,@Additional float,                              
@IncFactor float,@OldBenefits float,@Increament float,@OldBenefits1 float,@SpousePension float,              
@DepWithSpouse float,@DepWithoutSpouse float,@CreditService int,@DGok datetime,@AddedMonth INT,        
@CreditServiceDesc varchar(150),@CreditDays int,@limit int,@nsis smallint                                     
                                      
declare @MembSex char(1), @theFactor float, @ExitReason int, @LFactor int, @RPension float, @DeathBenefit float, @DeathFactor float,@SalaryFactor float                                      
declare @PreparedBy varchar(60), @DatePrepared smalldatetime, @CheckedBy  varchar(60), @dateChecked varchar(60), 
@AuthorisedBy varchar(60), @DateAuthorised smalldatetime,@DCDB smallint,@Ben_Counter Int                                      
            
/* for NSIS */                                
Exec Proc_Get_Credit_Service @schemeNo,@MemberNo,@CreditService out,@CreditDays out        
        
select @AddedMonth = 0        
        
select @CreditServiceDesc = cast(@CreditService as varchar(4))+' months  and '+cast(@CreditDays as varchar(2))+' days '                                                               
             
                                    
select @RealGratuity = 0.0                                    
                  
Select @prospect = AddProspective from ConfigDeathInService                                        
where SchemeNo = @schemeNo                                      
                                      
if (@Prospect = 1)                                      
begin                                      
   Exec GetProspectiveService @SchemeNo,@MemberNo,@ProService out                                      
                                             
   if @ProService is null select @Proservice = 0                                       
end                                      
                                      
Select @SalaryFactor = SalaryFactor,@GratPeriod = GratPeriod,@BenReduce = Reduced,                                      
@SalaryFactorUn = SalaryFactorUn,@BenPensionable = BenPensionable,@BenefitMode = BenefitMode                        
from ConfigDeathInService where SchemeNo = @schemeNo                                      
                                      
if @BenefitMode is null select @BenefitMode = 0                                      
if @SalaryFactor is null select @SalaryFactor = 3                                      
if @GratPeriod is null select @GratPeriod = 5                                      
if @BenPensionable is null select @BenPensionable = 0                                      
                                      
Select @dSalaryMode = dSalaryMode,@SalaryDiff = SalaryDiff from ConfigSalary                                      
where SchemeNo = @schemeNo                                      
                                      
if @SalaryDiff is null select @SalaryDiff = 0                                      
                                      
select @Membsex = sex , @ExitReason = ReasonforExit, @Designation = Grade , @dTemp = dje,                                      
@DesignCode = DesignCode,@djpens = djpens,@DoCalc = DoCalc,@SponsorCode = SponsorCode,                              
@ActiveStatus = ActiveStatus,@DeathSalary = CapenSalD,@DGok = DGok,@DCDB = DCDB from Members where SchemeNo = @schemeNo and MemberNo = @MemberNo                                      
                                      
if @DesignCode is null select @DesignCode = 0 
if @DCDB is null select @DCDB = 0 

if @DCDB = 0
   BEGIN
   select @Ben_Counter = Max(Ben_Counter) from TBL_Benefits_DC where SchemeNo = @SCHEMENO and MemberNo = @memberNo
   
   select @PreparedBy = PreparedBy, @DatePrepared = DatePrepared, @CheckedBy = CheckedBy, @DateChecked = DateChecked,                                  
                  @AuthorisedBy = AuthorisedBy, @DateAuthorised = DateAuthorised,                                
                  @Auditedby = AuditedBy,@DateAudited = DateAudited from TBL_Benefits_DC                                      
   where SchemeNo = @schemeNo and MemberNo = @MemberNo and Ben_Counter = @Ben_Counter  
   END
else
   BEGIN
   select @Ben_Counter = Max(Ben_Counter) from TBL_Benefits_DB where SchemeNo = @SCHEMENO and MemberNo = @memberNo 
   
   select @PreparedBy = PreparedBy, @DatePrepared = DatePrepared, @CheckedBy = CheckedBy, @DateChecked = DateChecked,                                  
                  @AuthorisedBy = AuthorisedBy, @DateAuthorised = DateAuthorised,                                
                  @Auditedby = AuditedBy,@DateAudited = DateAudited from TBL_Benefits_DB                                      
   where SchemeNo = @schemeNo and MemberNo = @MemberNo and Ben_Counter = @Ben_Counter 
   END  
                                                                 
if @SchemeMode = 0                                
   select @SponsorName = ''            
else                                
   select @SponsorName = SponsorName from Sponsor                                
   where SchemeNo = @schemeNo and SponsorCode = @SponsorCode                                    
                                      
select @curYear = max(ContrYear) from contributionssummary where SchemeNo = @schemeNo and memberNo = @memberNo                                      
select @ContrMonth  = Max(ContrMonth)  from contributionssummary where SchemeNo = @schemeNo and memberNo = @memberNo and ContrYear = @CurYear                                      
                                      
select @schemeName = schemeName,@dbMode = dbMode,@TelPosta = TelPosta,@SchemeMode = SchemeMode,                      
@Mukuba = Mukuba,@nsis = nsis from scheme where schemeCode = @schemeNo                                      
if @TelPosta is null select @TelPosta = 0                               
if @Mukuba is null select @Mukuba = 0    
if @nsis is null select @nsis = 0    
    
if @nsis = 0    
   select @Limit = 30    
else    
   select @Limit = 16                              
                                     
select @LFactor = LFactor, @MaxService = MaxService from Pension_SetUp where SchemeNo = @schemeNo                            
                                
if @SchemeMode is null select @SchemeMode = 0                                      
                                      
declare GenCursor cursor for                                      
              select m.schemeNo, m.memberNo, m.checkNo, m.dje,m.djpens,m.doexit,  m.dob, case m.Sex when 'M' then 'Male' when 'F' then 'Female' end,                                       
 (Upper(m.sname) + ' , '+ (m.fname) + '   '+(m.onames)) as fullname,                                      
               b.calcYear, b.taxfreeLumpsum, r.ReasonDesc,b.AddCode,b.VolCBal + b.PreAvcCBal,                          
               b.TransType                                      
             from Members m                                      
                       inner join Benefits b on m.schemeNo = b.schemeNO and m.memberNo = b.memberNo                                      
                       inner join ReasonforExit r on m.reasonforexit = r.ReasonCode                                      
            where m.SchemeNo = @schemeNo and m.memberNo = @memberNo                                      
                                                   
open GenCursor                                       
                                      
fetch from GenCursor into @schemeNo, @memberNo, @checkNo, @dje, @djpens, @dateofExit, @dob, @sex,  @fullname,  @curYear,                                      
                          @taxfreeLumpsum, @Reason,@AddCode,@Avc,@TransType                                      
                                      
while @@fetch_status =0                                      
begin                                      
    if @Avc is null select @Avc = 0                                      
                                 
    Exec GetPensionCFactor @SchemeNo,@MemberNo,@djpens,@dateofExit,@PensionFactor out                                      
                                      
    if @AddCode is null select @AddCode = 0                                      
                                      
    select @salary = CAPenSal,@DeathSalary= CAPenSald from Members where SchemeNo = @schemeNo and memberNo = @memberNo                                      
                                                                                     
      Exec GetTemporaryService @SchemeNo, @MemberNo,@djpens, @dje,@Tempservice out,@HalfMonths Out,@HalfDays out                                      
      Exec AddPastService @dateofExit,@djpens,@AddedServ out                                      
                                           
     if ((@TelPosta = 0) and (@Mukuba = 0))                                     
        Exec GetServiceTime @djpens,@dateofExit,@NumYears out,@NumMonths out,@NumDays Out                                      
     else if ((@TelPosta = 1) and (@Mukuba = 0))                                     
        Exec GetServiceTime_TelPosta @schemeNo,@MemberNo,@djpens,@dateofExit,@NumYears out,@NumMonths out,@NumDays Out                                  
                              
     else if ((@TelPosta = 0) and (@Mukuba = 1) and (@ActiveStatus < 8))                     
        Exec GetServiceTime_Mukuba @djpens,@dateofExit,@NumYears out,@NumMonths out,@NumDays Out                               
     else if ((@TelPosta = 0) and (@Mukuba = 1) and (@ActiveStatus >= 8))                               
        begin                              
        Exec Proc_Get_MaxCont @schemeNo,@MemberNo,@MaxCont out                               
                              
        Exec GetServiceTime_Mukuba @djpens,@MaxCont,@NumYears out,@NumMonths out,@NumDays Out                              
        end                                  
                              
                                 
     select @MaYears = @NumYears                                      
                                      
     select @MaDays = @NumDays                                       
                                      
      if @MaYears >=  @GratPeriod                                      
           Select @DeathFactor = @SalaryFactor                                      
      else                                      
           Select @DeathFactor = @SalaryFactorUn                                      
                                   
      if @mukuba = 1                                                                  
      begin                                                                                                    
        Select @Additional = 0                                                            
        exec calcavcpension_mukuba @schemeno,@memberno,@Additional out                          
                          
        if (@ActiveStatus >= 8)                                
            Exec Proc_Pension_Increase @schemeNo,@MaxCont,@ActiveStatus,@IncFactor Out                           
        else                          
            Exec Proc_Pension_Increase @schemeNo,@dateofExit,@ActiveStatus,@IncFactor Out                                                                   
      end                               
                                     
      /* DC */                                    
      if @TransType = 10                                    
         select @DeathBenefit = 0                                
      else if @TransType = 11                                    
         Select @DeathBenefit = @DeathSalary * @DeathFactor                                    
      else if @TransType = 12                                    
         Select @DeathBenefit = @DeathSalary * @DeathFactor                                    
      else if @TransType = 13                                    
         Select @DeathBenefit = @DeathSalary * @DeathFactor                                    
 else if @TransType = 14                                    
         Select @DeathBenefit = 0.0                                    
      /* DB */                                       
      else if @TransType = 33                                    
         select @DeathBenefit = 0                                    
      else if @TransType = 34                                    
         Select @DeathBenefit = @DeathSalary * @DeathFactor                                    
      else if @TransType = 35                                    
         Select @DeathBenefit = @DeathSalary * @DeathFactor                                    
      else if @TransType = 36                                    
 Select @DeathBenefit = @DeathSalary * @DeathFactor                                    
      else if @TransType = 37                                    
         Select @DeathBenefit = @DeathSalary * @DeathFactor                                    
      else if @TransType = 38                                    
         Select @DeathBenefit = @DeathSalary * @DeathFactor                                    
                     
                                          
      if @DeathBenefit is null select @DeathBenefit = 0                                    
                                    
      if @DeathBenefit = 0 select @DeathFactor = 0                                      
                                    
      select @RealGratuity  = @DeathBenefit                                      
                                             
  /* Code Added */                                      
        select @DeathBenefit1 = @DeathBenefit                         
                                       
        select @DeathBenefit = @DeathBenefit1 + @avc                                      
                                      
       /* Code Added */                                   
      if @dbMode = 0  /* Months In service */                                      
        begin                                      
         select @NumYears = @NumYears + @Tempservice                                      
         select @NumMonths = @NumMonths + @HalfMonths                                      
                                      
         IF @NumMonths >= 12                                      
            select @NumMonths = @NumMonths - 12,@NumYears = @NumYears + 1                              
                                      
         select @PastService = (@NumYears * 12.000) + @NumMonths                                      
                                      
         IF @TelPosta = 0                                      
        begin                                      
         if @HalfDays + @NumDays >= 30                                       
            begin                                      
                 select @AddedServ = 1                                      
            end                                      
         else select @AddedServ = 0                                      
                                      
         if @HalfDays + @NumDays >= 30                                      
            select @NumDays = (@HalfDays + @NumDays) - 30                                      
         else                                      
            select @NumDays = @HalfDays + @NumDays                                      
         end                                      
         else if @TelPosta = 1                                      
           select @AddedServ = 0                                      
                                      
         select @NumMonths = @NumMonths + @AddedServ                                      
                                      
         select @PastService = @PastService  + cast(@AddedServ as float)              
                                      
         select @CalcService = @PastService                                     
         select @CalcYears = @PastService                                      
                                      
         select @Miezi = cast(@PastService as Integer)                                      
                                      
       end                                      
       else if @dbMode = 1  /* Complete Years in Service */                                      
       begin                                      
            select @PastService = @NumYears + @TempService                                      
    select @CalcYears = @PastService                                      
            select @CalcService = @PastService                               
       end                                      
       else if @dbMode = 2  /* Complete Years in Service Plus Months in Service */                                      
       begin                                      
                                             
       select @NumYears = @NumYears + @TempService                                      
       select @NumMonths = @NumMonths + @HalfMonths                                      
                                      
       if @HalfDays + @NumDays >= 30 select @AddedServ = 1                                      
       else                                      
       select @AddedServ = 0                                 
                            
       select @NumMonths = @AddedServ + @NumMonths                                      
                                      
       select @PastService = @NumYears + @NumMonths/12.0000                                      
                                      
       select @CalcYears = @PastService                                      
       select @CalcService = @PastService                                      
                                             
   end                                                                 
        select @MaxService = @MaxService * 12            
                                                
        if @pastService > @MaxService                          
            begin                                      
                select @PastService = @MaxService                                      
                Select @CalcYears = @MaxService                                      
            end                                      
                                      
       select @serviceTime = cast(@NumYears as varchar(2)) + ' years,  ' + cast(@NumMonths as varchar(2)) + ' months and '+cast(@NumDays as Varchar(2)) + '  days'                                      
               
       if @CreditDays  >= @limit      
           select @AddedMonth = 1   
         
       if @NumDays >= @Limit  
           select @AddedMonth = @AddedMonth + 1  
             
                                       
       select @NumYears = 0,@NumMonths = 0,@NumDays = 0                                      
                                      
       Exec GetServiceTime @dob,@dateofExit,@NumYears out,@NumMonths Out,@NumDays Out                                      
       select @Years = @NumYears                                      
                                               
        declare @aMonths as int, @aYears as int                                      
    select @aYears = @NumYears,@aMonths = @NumMonths                                      
                                             
       select @AgeDesc = cast(@aYears as varchar(2)) + ' years ' + cast(@aMonths as varchar(2)) + ' months'                                      
        declare @aFactor float                                      
                                              
      declare @xMonths int                                      
      declare @yMonths float                                      
      declare @xYears int                        
    /*                                  
      if @dbMode = 1                                      
       begin                                      
         select @xMonths = @PastService %12                                      
         select @xYears = (@PastService - (@PastService % 12)) / 12                                      
                                      
         select @xYears = cast(@xYears as float)                                      
         select @yMonths = @xMonths/12.000000000000                                      
                                      
         select @CalcYears = @xYears + @yMonths                                      
      end                               
    */                                   
    Exec CalcNonPensionable @schemeNo,@MemberNo,@TotalMonths out,@TotalDays Out                                      
                                      
  if @TelPosta = 0                                      
  begin                                      
    if @TotalMonths > 0                                      
       begin                                      
       if @MaDays < @TotalDays                                      
          select @CalcYears = @CalcYears - 1                                      
                                      
          select @CalcYears = @CalcYears - @TotalMonths                                      
                                              
          select @BreakInService = Cast(@TotalMonths as Varchar(2))+' and '+cast(@TotalDays as Varchar(2))+' days'                                      
                                      
          /* Reduced Pensionable Service */                                      
          select @PastService = @CalcYears                         
       end                                      
    else if ((@TotalMonths = 0) and (@TotalDays > 0))                                      
       begin                                      
          if @MaDays < @TotalDays                                      
             select @CalcYears = @CalcYears - 1                                      
                                      
          select @BreakInService = cast(@TotalDays as Varchar(2)) + '  Days'                                      
       end                                      
    else                                      
      select @BreakInService = cast(@TotalDays as Varchar(2)) + '  Days'                                      
  end                                      
 else                    
    select @BreakInService = cast(@TotalDays as Varchar(2)) + '  Days'                                      
                                      
    if @proservice is null select @proservice = 0                                      
                                      
    if @Prospect = 1                                      
      select @calcYears = @calcYears + @proservice                                      
                                      
    select @Pastservice = (@calcYears + @CreditService + @AddedMonth)                                         
                                      
    select @Benefits = (1.0000000000/ @PensionFactor) * @salary * (@calcYears + @CreditService + @AddedMonth)                                       
                                  
    select @OldBenefits = @Benefits                           
                          
    if @IncFactor is null select @IncFactor = 0                          
                            
                              
    if @Additional is null select @Additional = 0                                 
                              
    select @Benefits= @Benefits + @Additional                      
                      
    select @OldBenefits1  = @Benefits                         
                        
    if @IncFactor > 0                        
       select @Increament  = (@Benefits * (@IncFactor/100.00))                         
 else                              
       select @Increament = 0                        
                        
    select @Benefits = @Benefits + @Increament                         
                              
      if @BenReduce = 0                                       
         begin                                      
         select @ReducedPension =  @Benefits,@RemFactor = @lfactor                                      
      end                                      
      else                                      
         begin                                      
         select @ReducedPension =  @Benefits * (@LFactor -1.0000000000)/@LFactor                                      
         select @RemFactor = @lFactor - 1                                      
         end                                      
      select @AFactor = (@LFactor - 1.0000000000)/ @LFactor                                      
                                      
      select @Lumpsum = @DeathBenefit                 
                                      
      Exec GetDeathConts @schemeNo,@MemberNo,@Contributions Out,@BenefitMode Out                                      
                                      
     select @Lumpsum = @Lumpsum + @Contributions                                      
                                      
      declare @TaxAmount float,@taxType Int                                      
                                      
      if @BenefitMode = 0 /* Death Gratuity plus pension */                                      
begin                                      
         select @TaxAmount = @Lumpsum - @taxfreeLumpsum                                      
                                            
         if @TaxAmount < 0 select @TaxAmount = 0                                      
                                      
         Exec  GetTaxType @SchemeNo, @MemberNo,@TaxType out                                      
                                      
     exec  CalculateTax @SchemeNo,@TaxAmount,@dateofExit, @TaxType, @WithHoldingTax out                                      
                                            
         select @AmountPayable = @Lumpsum - @WithHoldingTax                                      
       end                                      
     else if @BenefitMode = 1 /* Death Gratuity Only */                                  
       begin                                      
                                       
         Exec GetTaxFreeLumpsumD @schemeNo,@DoCalc,@TaxfreeLumpsum out                                      
                                      
         select @TaxAmount = @Lumpsum - @taxfreeLumpsum                                      
                                   
         if @TaxAmount < 0 select @TaxAmount = 0                                      
                                      
         Exec  GetTaxType @SchemeNo, @MemberNo,@TaxType out                                      
                            
         exec  CalculateTax @SchemeNo,@TaxAmount,@dateofExit, @TaxType, @WithHoldingTax out                                      
                                            
         select @AmountPayable = @Lumpsum - @WithHoldingTax                                      
       end                                      
     else if @BenefitMode = 2 /* Insured */                                      
       begin                                      
          select @TaxAmount = 0,@WithHoldingTax = 0                                      
                                      
          select @AmountPayable = @Lumpsum - @WithHoldingTax                                      
       end                                      
                    
       if @DesignCode > 0                                      
          begin                                      
          select @Title = Designation from Designation where DesignCode = @DesignCode                                      
                   
          select @FullName = upper(@Title) +'  '+@FullName                                      
          end                                      
                                      
  /* NSIS  Monthly pension for Dependants */              
              
  select @SpousePension = (@Reducedpension/12.0000000000)/2.000,@DepWithSpouse  = (@Reducedpension/12.0000000000) * (6.25/100.00),              
         @DepWithoutSpouse = (@Reducedpension/12.0000000000) * (12.50/100.00)                                                             
                                        
                                      
 insert into #calculation (schemeNo, MemberNo, schemeName, fullname, dje, djpens,                                      
   dateofexit,curYear, salary, pastservice, serviceTime, dob,                                      
   comm, CalcService,Benefits, BenefitsBC, lumpsum,                                      
   TaxfreeLumpsum,withHoldingTax, pensionfactor,                                      
   sex, Reason, ageDesc, ReducedPension, AmountPayable,                             
   ActFactors,TaxableAmount, CalcYears, DeathBenefit,DeathFactor, Designation,                                      
   MonPension, preparedBy, DatePrepared, CheckedBy, DateChecked, AuthorisedBy, DateAuthorised,                                      
   LumpFactor,RemFactor,BreakInService,DeathSalary,DeathBenefit1,AVC,BenPensionable,DoCalc,                                      
   Contributions,RealGratuity,Auditedby,DateAudited,SponsorName,Additional,IncFactor,OldBenefits,MaxCont,Increament,                      
   OldBenefits1,SpousePension,DepWithSpouse,DepWithoutSpouse,CreditService,DGok,CreditServiceDesc)                                      
                                                    
      values(@schemeNo, @CheckNo,@schemeName, @fullname, @dTemp, @djpens,@dateofExit,                                       
                @curYear, @salary, @pastService, @ServiceTime, @dob, @comm, @CalcYears,                                      
                @Benefits, @ReducedPension, @lumpsum,  @taxfreeLumpsum ,                                      
   @withHoldingTax, @Pensionfactor, @sex, @Reason, @AgeDesc, @ReducedPension,            
                @AmountPayable,@aFactor, @TaxAmount, @CalcYears, @DeathBenefit, @DeathFactor, @Designation,                                      
                @Reducedpension/12.0000000000, @preparedBy, @DatePrepared, @CheckedBy, @DateChecked, @AuthorisedBy, @DateAuthorised                                      
                ,@LFactor,@RemFactor,@BreakInService,@DeathSalary,@DeathBenefit1,@AVC,@BenPensionable,@DoCalc,                                      
                @Contributions,@RealGratuity,@Auditedby,@DateAudited,@SponsorName,@Additional,@IncFactor,@OldBenefits,                        
                @MaxCont,@Increament,@OldBenefits1,@SpousePension,@DepWithSpouse,@DepWithoutSpouse,        
                @CreditService,@DGok,@CreditServiceDesc)                                      
                   
                                      
                                          
     fetch next from GenCursor into @schemeNo, @memberNo, @checkNo, @dje, @djpens, @dateofExit, @dob,  @sex, @fullname,  @curYear,                                      
  @taxfreeLumpsum,@reason,@AddCode,@Avc,@TransType                                         
end                                       
close GenCursor                                      
deallocate GenCursor                                      
                                    
                                    
if ((@TransType >= 37) and (@TransType <= 38))                                   
   UPDATE Benefits set WithholdingTax = @WithholdingTax where SchemeNo = @schemeNo and MemberNo = @MemberNo                                     
                                    
UPDATE DeathClaim set AmountOfCover = @RealGratuity,MonPension =  @Reducedpension/12.0000000000 where SchemeNo = @schemeNo and MemberNo = @MemberNo                                      
                                      
select * from #calculation
go

