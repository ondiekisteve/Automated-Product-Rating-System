CREATE PROCEDURE [dbo].[GetFundColumns]
--with Encryption
as

declare @TableName varchar(50),@TableId int,@Column varchar(30),
        @xType int,@DataType varchar(30)

declare acsr cursor
for Select TableName,TableId
from tblDataDictionary

open acsr

fetch from acsr into @TableName,@TableId

while @@fetch_Status =0
begin
    declare bcsr cursor for
    Select Name,xType from
    SysColumns where id = @TableId
    
    open bcsr

    fetch from bcsr into @Column,@xType

    while @@fetch_Status = 0
    
    begin
       Select @DataType = Name from SysTypes where xType = @xType

       insert into fldDataDictionary (TableName,FieldName,DataType)
                     Values(@TableName,@Column,@DataType)

       fetch next from bcsr into @Column,@xType
    end
    close bcsr
    Deallocate bcsr

   fetch next from acsr into @TableName,@TableId
end
Close Acsr
Deallocate Acsr
go

