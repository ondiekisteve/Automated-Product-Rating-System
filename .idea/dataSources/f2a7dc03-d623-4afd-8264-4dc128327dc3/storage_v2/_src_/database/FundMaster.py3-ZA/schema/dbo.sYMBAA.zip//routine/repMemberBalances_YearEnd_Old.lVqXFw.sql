CREATE PROCEDURE [dbo].[repMemberBalances_YearEnd_Old]                                                              
@SCHEMENO Int,                                                
@Proc_Date datetime,                                                                                  
@RepMode Int,                                                            
@SponsorCode Int,                                                
@ProvOrYearEnd int /* 0 - Provisional, 1 - Year End */                                                                
 --with Encryption                                                                  
as                                                                  
               
SET NOCOUNT ON              
                                                                 
if object_id('tempdb..#benCalcComb') is null                                                                  
  create table #benCalcComb                                                                  
  (                                                              
    EmpCode Int Identity(1,1) Primary Key,                                                              
    schemeNo varchar (15) NOT NULL ,                                                                  
    schemeName varchar (100) not null,                                                                  
    memberNo int NOT NULL ,                                                                  
    PayrollNo Varchar(20),                                             
    IDNumber varchar(20),                                                                 
    fullName varchar (100) not null,                                                                   
    cEmpBal float null default 0.0,                                                                  
    cEmprBal float null default 0.0,                                                                  
    empOpening float null default 0.0,                                                                  
    emprOpening float null default 0.0,                                                                  
    empCont float null default 0.0,                                                                  
    emprCont float null default 0.0,                                                                  
    empInt float null default 0.0,                                                                  
    emprInt float null default 0.0,                                                                  
    grandTotal float null default 0.0,                                                                  
    calcYear Int null,                                                                  
    calcMonth Varchar (15) null ,                                                                  
    endingPeriod Varchar (30) null,                                                                  
    EmpTransfer float,                                                                  
    EmprTransfer float,                                                                  
    ReportDesc Varchar(50),                                                                
    Dob Datetime,                                                                
    Dje Datetime,                                                                
    djpens Datetime,                  
    DoExit Datetime,                    
    Gender varchar(1),                                                               
    AStatus int,                                                                
    LoanBalance float,                                                                
    SponsorName varchar(100),                                                                
    NetBalance float,                                                                  
    PoolName varchar (120) null,                                                  
    InterestRate decimal(9,5),                                   
    Dept varchar(50),                                        
   Grouper varchar(50),                
    AmountPaid float                        
  )                                                                   
                                                  
declare @schemeName varchar(100),@memberNo int, @fullName varchar(100) , @cEmpBal float,                                                                  
@cEmprBal float, @empOpening float, @emprOpening float, @empCont float, @emprCont float, @empInt float,                                           
@emprInt float, @empVol float, @grandTotal float, @Transfer float, @monthName varchar(15),@schemeYear int,                                                                  
 @curPeriod varchar(30), @EmprVol float, @xcEmpBal float, @xcEmprBal float,                                                                  
@xempOpening float, @xemprOpening float,                                                  
@xEmpCont float, @xEmprCont float, @xEmpVol float, @xEmprVol float,@EmpTransfer float,@EmprTransfer float,                                                                  
@MwishoDate Datetime,@BalanceofInt smallInt,@StartDate Datetime,@EndDate Datetime,@PayrollNo varchar(20),                                                                  
@calcMonth int,@calcYear int,@ReportDesc vARCHAR(50),@DoCalc Datetime,@ActiveStatus Int,                                     
@empAdminFees float,@emprAdminFees float,@empAdminFees_Un float,@emprAdminFees_Un float,                                                       
@EmpFeesOpen float,@EmprFeesOpen float,@EmpFeesOpen_Un float,@EmprFeesOpen_Un float,                                                                 
@EmpInt_Un float,@EmprInt_Un float,@VolInt_Un float,@SpecInt_Un float,@ShowInterest float,                                                                  
@EmpInt_Op float,@EmprInt_Op float,@VolInt_Op float,@SpecInt_Op float,                                                                  
@DistrEmp float,@DistrEmpr float,@DistrAVC float,@DistrSpec float, @AStatus int,                                                           
@DistrEmpC float,@DistrEmprC float,@DistrAVCC float,                                                                
@Dob datetime,@dje datetime,@djpens datetime,@PooledInvestment smallInt,@InvestmentScheme Int,@PoolName varchar(120),                                                                 
@DistrSpecC float /* Reserve Distribution */,@LoanBalance Decimal(20,6),@SponsorName varchar(100),                                                                
@SchemeMode smallInt,@DisplayMode smallInt,@CompanyID iNT,                                                            
@EmpFees_Op float,@EmprFees_Op float,@EmpFees_Un_Op float,@EmprFees_Un_Op float,                                                            
                                                       
@DistrEmpUn float,@DistrEmprUn float,@DistrAVCUn float,@DistrSpecUn float,                                                                
@DistrEmpCUn float,@DistrEmprCUn float,@DistrAVCCUn float,@DistrSpecCUn float,@InitSponsorCode int,                                                  
@InterestRate decimal(9,5),@Dept varchar(50),@idNumber varchar(20),@AcctPeriod Int,@Zambia smallint,@Mining smallint,@Gender varchar(1),                  
@DoExit datetime,@Grouper varchar(50)                                                           
                                            
if @RepMode < 10                                            
begin                                            
select @AcctPeriod  = AcctPeriod                                                 
from SchemeYears                                                 
where schemeNo = @schemeNo and StartDate <= @Proc_Date and EndDate >= @Proc_Date                                                
                                                                  
Select @StartDate = StartDate,@EndDate = @Proc_Date                                                   
from SchemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod                                                                  
                                                
Select @BalanceofInt = CalcBalanceofInterest from ConfigYearEnd where SchemeNo = @schemeNo                                                                  
if @BalanceofInt is null select @BalanceofInt = 0                                                     
                                                    
select @InitSponsorCode = @SponsorCode                                                  
                                                                  
Select @CalcYear = DatePart(Year,@EndDate),@CalcMonth = DatePart(Month,@EndDate)                                                     
                                                
select @Astatus =0                                                                
Exec GetLastDate @CalcMonth,@CalcYear,@MwishoDate out                                                
EXEC Proc_Get_Int_Rate @schemeNo,@MwishoDate,@ProvOrYearEnd,@InterestRate Out                                                   
                       
if @InterestRate is null  select @InterestRate = 0                                                  
                                                                      
                                                                  
select @schemeYear = @CalcYear                                                                  
select @monthName = monthName from monthTable where monthNumber = @calcMonth                                                                  
select @schemeName = schemeName,@ShowInterest = ShowInterest,@SchemeMode = SchemeMode,                                                                
@DisplayMode = DisplayMode,@PooledInvestment = PooledInvestment,@InvestmentScheme = InvestmentScheme,@Zambia = Zambia,@Mining = Mining                                                          
from Scheme where schemeCode = @schemeNo                                                                  
                                          
if @Zambia is null select @Zambia = 0                      
if @Mining is null select @Mining = 0       
      
/* SET SHOWInterest */      
select @ShowInterest = @ProvOrYearEnd  
SELECT @ShowInterest = 0                                         
                                      
if @PooledInvestment = 1                                                                      
select @PoolName = schemeNAME FROM Scheme where schemeCode = @InvestmentScheme                                  
else if @PooledInvestment = 0                                                                      
select @PoolName = ' '                                                          
                                                                  
if @ShowInterest is null select @ShowInterest  = 0                                                                 
if @SchemeMode is null select @SchemeMode = 0                                                                  
if @DisplayMode is null select @DisplayMode = 0                                                                
                                                                  
exec GetEndingPeriod @calcMonth, @curPeriod out                                                                  
select @curPeriod = @curPeriod +' '+ cast(@CalcYear as varchar(4))                                                                  
exec GetAccountingPeriodInAYear @schemeNo, @CalcMonth, @calcYear, @AcctPeriod out                                                                  
                                                            
if @SponsorCode = 0                                                           
begin                                                               
IF @RepMode = 2                                   
   BEGIN                                                                                                                                        
        declare benCsr cursor for                                                                   
        select distinct b.schemeNo, b.memberNo, b.EmpVolCont + b.PreAvc as empCont, b.EmprVolCont as EmprCont,                                                                  
        (b.EmpVolCont + b.PreAvc + b.EmprVolCont) as TotalBalance,                                                                  
        (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,m.ActiveStatus,                                                                  
        b.EmpFees + b.VolFees,b.EmprFees + b.SpecFees,b.EmpInt,b.EmprInt,b.VolInt,b.SpecInt,b.LoanBalance,                                          
        m.Dob,m.dje,m.djpens,m.doexit,m.SponsorCode,M.CompanyID,M.Dept,m.idNumber,m.sex                                                                
        from MemberOpeningBalances b inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo           
        and m.ReasonforExit >= 0                        
        where b.SchemeNo = @schemeNo and b.AcctPeriod = @AcctPeriod AND b.ProvOrFinal = @ProvOrYearEnd                                                                 
        order by b.memberNo                                                                                                
    END                                                              
ELSE                                                              
    BEGIN                                                                                            
         declare benCsr cursor for                                                                   
         select distinct b.schemeNo, b.memberNo, b.empCont + b.EmpVolCont + b.PreEmpCont + b.Transfer + b.PreAvc as empCont,                                                      
         b.emprCont + b.EmprVolCont + b.PreEmprCont + b.LockedIn + b.DeferredAmt as EmprCont,                                                                  
        (b.empCont + b.EmpVolCont + b.PreEmpCont + b.Transfer + b.PreAvc + b.emprCont + b.EmprVolCont + b.PreEmprCont + b.LockedIn + b.DeferredAmt) as TotalBalance,                                                                  
        (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,m.ActiveStatus,                                                                  
         b.EmpFees + b.VolFees,b.EmprFees + b.SpecFees,b.EmpInt,b.EmprInt + b.DefInterest,b.VolInt,b.SpecInt,b.LoanBalance,                                                                
         m.Dob,m.dje,m.djpens,m.doexit,m.SponsorCode,M.CompanyID,M.Dept,m.idNumber,m.sex                                                                 
         from MemberOpeningBalances b inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo 
         and m.ReasonforExit >= 0               
         where b.SchemeNo = @schemeNo and b.AcctPeriod = @AcctPeriod AND b.ProvOrFinal = @ProvOrYearEnd                                                                 
         order by b.memberNo                                                                                                
END                                       
end                                                            
else if @SponsorCode > 0                                                            
begin                                                               
IF @RepMode = 2                                                              
   BEGIN                                                                                                                                               
        declare benCsr cursor for                                                                   
        select distinct b.schemeNo, b.memberNo, b.EmpVolCont + b.PreAvc as empCont, b.EmprVolCont as EmprCont,                                                        
        (b.EmpVolCont + b.PreAvc + b.EmprVolCont) as TotalBalance,                                                                  
        (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,m.ActiveStatus,                                                                  
        b.EmpFees + b.VolFees,b.EmprFees + b.SpecFees,b.EmpInt,b.EmprInt,b.VolInt,b.SpecInt,b.LoanBalance,                                                                
        m.Dob,m.dje,m.djpens,m.doexit,m.SponsorCode,M.CompanyID,M.Dept,m.idNumber,m.sex                                                               
        from MemberOpeningBalances b inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo 
        and m.ReasonforExit >= 0 and m.SponsorCode = @SponsorCode                                                                   
        where b.SchemeNo = @schemeNo and b.AcctPeriod = @AcctPeriod and b.provOrFinal = @ProvOrYearEnd                                                                 
        order by b.memberNo                                                                                               
    END                           
ELSE                                                    
    BEGIN                                                                                                                         
        declare benCsr cursor for                                                                   
        select distinct b.schemeNo, b.memberNo, b.empCont + b.EmpVolCont + b.PreEmpCont + b.Transfer + b.PreAvc as empCont,                                                      
         b.emprCont + b.EmprVolCont + b.PreEmprCont + b.LockedIn + b.DeferredAmt as EmprCont,                                                                  
        (b.empCont + b.EmpVolCont + b.PreEmpCont + b.Transfer + b.PreAvc + b.emprCont + b.EmprVolCont + b.PreEmprCont + b.LockedIn + b.DeferredAmt) as TotalBalance,                                                                  
        (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,m.ActiveStatus,                                                                  
         b.EmpFees + b.VolFees,b.EmprFees + b.SpecFees,b.EmpInt,b.EmprInt + b.DefInterest,b.VolInt,b.SpecInt,b.LoanBalance,                                                                
         m.Dob,m.dje,m.djpens,m.doexit,m.SponsorCode,M.CompanyID,M.Dept,m.idNumber,m.sex                                                                  
         from MemberOpeningBalances b inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo and m.SponsorCode = @SponsorCode           
         and m.ReasonforExit >= 0                                                                   
         where b.SchemeNo = @schemeNo and b.AcctPeriod = @AcctPeriod and b.provOrFinal = @ProvOrYearEnd                                    
         order by b.memberNo                                                                                               
    END               
end                                                            
                                                                            
open benCsr                                                                  
fetch from benCsr into @schemeNo, @MemberNo, @cEmpBal, @cEmprBal, @GrandTotal, @fullname,@PayrollNo,@DoCalc,@ActiveStatus,                                                                  
@empAdminFees,@emprAdminFees,@EmpInt_Op,@EmprInt_Op,@VolInt_Op,@SpecInt_Op,@LoanBalance,@Dob,@dje,@djpens,@doexit,@SponsorCode,                                                                
@CompanyID,@Dept,@idNumber,@Gender                                                                    
while @@fetch_status = 0                                                         
begin                                        
                                          
  /* Distributed Reserve */                                           
  select @DistrEmp = EmpCont , @DistrEmpr = EmprCont,@DistrAVC = AVC,@DistrSpec = AVCER,                                                                             
  @DistrEmpUn = EmpCont_Un , @DistrEmprUn = EmprCont_Un,@DistrAVCUn = AVC_Un,@DistrSpecUn = AVCER_Un                  
  from memb_reservefund_distr                                           
  where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @acctPeriod - 1                                                             
                                                                   
                   
  select @DistrEmpC = EmpCont , @DistrEmprC = EmprCont,@DistrAVCC = AVC,@DistrSpecC = AVCER,                          
  @DistrEmpCUn = EmpCont_Un , @DistrEmprCUn = EmprCont_Un,@DistrAVCCUn = AVC_Un,@DistrSpecCUn = AVCER_Un                                                                 
  from memb_reservefund_distr   where SchemeNo = @schemeNo and memberNo = @memberNo and AcctPeriod = @acctPeriod                                                                  
                                                                 
  IF @DistrEmp is null select @DistrEmp = 0                                                                  
  IF @DistrEmpr is null select @DistrEmpr = 0                                                                  
  IF @DistrAVC is null select @DistrAVC = 0                                                                   
  IF @DistrSpec is null select @DistrSpec = 0                                                                  
                                                                  
  IF @DistrEmpC is null select @DistrEmpC = 0                                                                  
  IF @DistrEmprC is null select @DistrEmprC = 0                                                   
  IF @DistrAVCC is null select @DistrAVCC = 0                                                                  
  IF @DistrSpecC is null select @DistrSpecC = 0                                                             
                                                            
  IF @DistrEmpUn is null select @DistrEmpUn = 0                                                                  
  IF @DistrEmprUn is null select @DistrEmprUn = 0                                                                  
  IF @DistrAVCUn is null select @DistrAVCUn = 0                                                                  
  IF @DistrSpecUn is null select @DistrSpecUn = 0                                                                  
                                                         
  IF @DistrEmpCUn is null select @DistrEmpCUn = 0                                                           
  IF @DistrEmprCUn is null select @DistrEmprCUn = 0                                                                  
  IF @DistrAVCCUn is null select @DistrAVCCUn = 0                                                           
  IF @DistrSpecCUn is null select @DistrSpecCUn = 0                                         
                                                                 
  if @empAdminFees is null select @empAdminFees = 0                                                                  
  if @emprAdminFees is null select @emprAdminFees = 0                                                                  
  if @EmpInt_Op is null select @EmpInt_Op = 0                                                                  
  if @EmprInt_Op is null select @EmprInt_Op =0                                                                  
  if @VolInt_Op is null select @VolInt_Op =0                                                        
  if @SpecInt_Op is null select @SpecInt_Op = 0                                                                 
  if @LoanBalance is null select @LoanBalance = 0.0                                                 
                   
  select @AStatus = activestatus from members where schemeno=@schemeno and memberno=@memberno                            
  if @grandTotal is null select @grandTotal = 0                                                            
                                                                            
  if @RepMode = 1                                                                  
     begin                                                
      /* Balances */                      
      select @xcEmpBal = (ExcessEmp + ExcessVolContr) -(EmpTax + VolTax),                                                                   
      @xcEmprBal = (ExcessEmpr + ExcessSpecial + DeferredAmt) - (EmprTax + SpecTax + DefTax),                                                                  
      @empAdminFees_Un  = EmpFees_Un + VolFees_Un,@emprAdminFees_Un = EmprFees_Un + SpecFees_Un,               
      @EmpInt_Un = EmpInt,@EmprInt_Un=EmprInt + DefInterest,@VolInt_Un=VolInt,@SpecInt_Un=SpecInt                                                                  
      from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                  
      and AcctPeriod = @AcctPeriod and provOrFinal = @ProvOrYearEnd                                                                 
                                                                 
      if @empAdminFees_Un is null select @empAdminFees_Un = 0                                                                  
      if @emprAdminFees_Un is null select @emprAdminFees_Un = 0                                        
      if @EmpInt_Un is null select @EmpInt_Un = 0                                                                  
      if @EmprInt_Un is null select @EmprInt_Un =0                                                                  
      if @VolInt_Un is null select @VolInt_Un =0                                                                  
      if @SpecInt_Un is null select @SpecInt_Un = 0                                                                  
                                                                  
      select @ReportDesc = 'COMBINED'                                                                  
  end                                                                
  Else if @RepMode = 2                                                                  
  begin                                                 
                     /* Balances */                                                                 
         select @xcEmpBal = (ExcessVolContr) -(VolTax),                                                                   
         @xcEmprBal = (ExcessSpecial) - (SpecTax),                                      
         @empAdminFees_Un  = VolFees_Un,@emprAdminFees_Un = SpecFees_Un,                                                                  
         @EmpInt_Un = 0.0,@EmprInt_Un=0.0,@VolInt_Un=VolInt,@SpecInt_Un=SpecInt                                                                  
         from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                  
         and AcctPeriod = @AcctPeriod and provOrFinal = @ProvOrYearEnd                                                                 
                                                                  
      if @empAdminFees_Un is null select @empAdminFees_Un = 0                                                                  
      if @emprAdminFees_Un is null select @emprAdminFees_Un = 0              
      if @EmpInt_Un is null select @EmpInt_Un = 0                                                                  
      if @EmprInt_Un is null select @EmprInt_Un =0                                                                  
      if @VolInt_Un is null select @VolInt_Un =0                                                  
      if @SpecInt_Un is null select @SpecInt_Un = 0                                                                  
                        
      select @ReportDesc = 'AVC ONLY'                                                                  
  end                                                                  
  else if @RepMode = 0                                                                  
  begin                                                                  
     select @ReportDesc = 'TAX EXEMPT',@EmpInt_Un = 0,@EmprInt_Un=0,@VolInt_Un=0,@SpecInt_Un=0                                                                  
  end                                                                  
                                                                   
  if @xcEmpBal is null select @xcEmpBal = 0                                                                  
  if @xcEmprBal is null select @xcEmprBal = 0                                                                  
                                                                  
  select @EmpInt_Op = @EmpInt_Op + @EmpInt_Un,@EmprInt_Op = @EmprInt_Op + @EmprInt_Un,                                                                  
         @VolInt_Op = @VolInt_Op + @VolInt_Un,@SpecInt_Op = @SpecInt_Op + @SpecInt_Un                                                                  
                                    
  Select @cEmpBal = @cEmpBal + @xcEmpBal                                                               
  Select @cEmprBal = @cEmprBal + @xcEmprBal                                                                 
  Select @grandTotal = @grandTotal + @xcEmpBal + @xcEmprBal                                         
                             
                                                                
  if @RepMode = 2                                                              
     select @empOpening = empvolcont + PreAvc,                                                                   
     @emprOpening = EmprVolcont,                                                                  
     @EmpFeesOpen = VolFees,@EmprFeesOpen = SpecFees                                                                  
     from memberOpeningBalances where SchemeNo = @schemeNo                                                                   
     and memberNo = @memberNo and acctPeriod = @acctPeriod - 1 and ProvOrFinal = 1                                                                 
  else                                                
     select @empOpening = empCont + empvolcont + PreEmpCont + Transfer + PreAvc,                                                                   
     @emprOpening = emprCont + EmprVolcont + PreEmprCont + LockedIn + DeferredAmt,                                                   
     @EmpFeesOpen = EmpFees + VolFees,@EmprFeesOpen = EmprFees + SpecFees                                                                  
     from memberOpeningBalances where SchemeNo = @schemeNo                                                                   
     and memberNo = @memberNo and acctPeriod = @acctPeriod - 1 and ProvOrFinal = 1                                                                
                                         
  if @EmpFeesOpen is null select @EmpFeesOpen = 0                                                                  
  if @EmprFeesOpen is null select @EmprFeesOpen = 0                                                                  
                                                                  
  /* Knock off the admin Fees from the Registered Opening Balances */                                            
  select @empOpening = (@empOpening + @DistrEmp + @DistrAVC)- @EmpFeesOpen,                                                                  
  @emprOpening= (@emprOpening + @DistrEmpr + @DistrSpec ) - @EmprFeesOpen                                                                  
                                                                  
  if @RepMode = 1                                                                  
  begin       
  select @xempOpening = (ExcessEmp + ExcessVolContr) -(EmpTax + VolTax),                                                                   
     @xemprOpening = (ExcessEmpr + ExcessSpecial) -(EmprTax + SpecTax),                                                                  
         @EmpFeesOpen_Un = EmpFees_Un + VolFees_Un,@EmprFeesOpen_Un = EmprFees_Un + SpecFees_Un                                    
         from UnRegisteredBalances where SchemeNo = @schemeNo                  
         and memberNo = @memberNo and acctPeriod = @acctPeriod - 1 and ProvOrFinal = 1                                                                  
                                    
        if @EmpFeesOpen_Un is null select @EmpFeesOpen_Un = 0                                                                  
        if @EmprFeesOpen_Un is null select @EmprFeesOpen_Un = 0                                                            
                                                            
                                                                   
                                                       
        /* Knock off the admin Fees from the UnRegistered Opening Balances */                                   
        select @xempOpening = (@xempOpening + @DistrEmpUn + @DistrAVCUn) - @EmpFeesOpen_Un,                                                            
        @xemprOpening= (@xemprOpening + @DistrEmprUn + @DistrSpecUn) - @EmprFeesOpen_Un                                                               
  end                                
                                                                
  Exec RepMemberCertificateContributions @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @EmpCont out,                                                                   
  @EmprCont out, @EmpVol out, @EmprVol out                                                            
                                                              
  if @RepMode = 2                                                              
     begin                                                               
       Exec RepMemberCertificateContributions @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @EmpCont out,                                                                   
       @EmprCont out, @EmpVol out, @EmprVol out                                                               
                                                                     
       select @EmprCont = 0.0,@EmpCont = 0.0                                                              
     end                                                                
                                                              
  if @RepMode = 1                                                                  
  begin                                         
  Exec RepMemberCertificateContributions_Un @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @xEmpCont out,                                                       
    @xEmprCont out, @xEmpVol out, @xEmprVol out                                                                  
  end                                                              
  else if @RepMode = 2                                                                  
  begin                                                                  
  Exec RepMemberCertificateContributions_Un @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @xEmpCont out,                                                                   
    @xEmprCont out, @xEmpVol out, @xEmprVol out                                                              
                                                              
    select @xEmpCont = 0.0,@xEmprCont = 0.0                                                                   
  end                                                                 
                                                              
                                                  
                                                                
  if @emprOpening is null select @emprOpening = 0                                                   
                                                                 
  if @RepMode < 2                                                               
     exec RepMemberCertificateTransfer @schemeNo, @MemberNo, @AcctPeriod, @EmpTransfer out,@EmprTransfer out                                                                  
                                if @empOpening is null select @empOpening = 0                                                                  
  if @emprOpening is null select @emprOpening = 0                                                               
  if @empCont is null select @empcont = 0                                                                  
  if @emprCont is null select @emprCont = 0                                                                  
  if @xempOpening is null select @xempOpening = 0        
  if @xemprOpening is null select @xemprOpening = 0                                                                  
  if @xempCont is null select @xempcont = 0                                                                  
  if @xemprCont is null select @xemprCont = 0                                                                  
  if @xEmpVol is null select @xEmpVol = 0                                                                  
  if @xEmprVol is null select @xEmprVol = 0                                                                  
  if @EmpVol is null select @EmpVol = 0                                                                  
  if @EmprVol is null select @EmprVol = 0                                                               
  if @Transfer is null select @Transfer = 0                                                                  
                                                                  
  Select @empOpening = @empOpening + @xempOpening                                                                  
  Select @emprOpening = @emprOpening + @xemprOpening                                                                  
                            
  Select @empCont = @empCont + @xempCont + @xEmpVol + @EmpVol                                                                   
  Select @emprCont = @emprCont + @xemprCont + @xEmprVol + @EmprVol    
  
  SELECT @ShowInterest = 0 /* FOR AFLIFE */                                                                 
                                                                  
  if @ShowInterest = 0                                                                  
     select @empInt = @cEmpBal - (@empOpening + @empCont + @EmpTransfer)                                                                  
  else if @ShowInterest = 1                                                                  
     select @empInt = @EmpInt_Op + @VolInt_Op                                     
                                    
  if @cEmpBal < 0                                    
     select @empInt = @cEmpBal - (@empOpening + @empCont + @EmpTransfer)                                      
                                                                 
  if @empInt is null select @empInt = 0                                                                  
  if @emprOpening is null select @emprOpening = 0                                                                  
                                                                  
  if @ShowInterest = 0                                                            
     select @emprInt = @cEmprBal - (@emprOpening + @emprCont + @EmprTransfer)                                                                  
  else if @ShowInterest = 1                                                                  
     select @emprInt = @EmprInt_Op + @SpecInt_Op                                    
                                   
  if @cEmprBal < 0                                    
     select @emprInt = @cEmprBal - (@emprOpening + @emprCont + @EmprTransfer)                                       
                                                             
  if @emprInt is null select @empInt = 0                                                                  
                                                              
                                                              
                                                                
  if @PayrollNo is null select @PayrollNo = @MemberNo                                                                  
                                             
                                                                  
  IF @RepMode = 1                                                                  
    select @cEmpBal = @cEmpBal - (@empAdminFees + @empAdminFees_Un),                                     
    @cEmprBal = @cEmprBal - (@emprAdminFees + @emprAdminFees_Un),                                                            
    @GrandTotal = @GrandTotal - (@empAdminFees + @emprAdminFees + @emprAdminFees_Un + @empAdminFees_Un)                                                                   
  else                                                                  
     select @cEmpBal = @cEmpBal - @empAdminFees,@cEmprBal = @cEmprBal - @emprAdminFees,                        
     @GrandTotal = @GrandTotal - (@empAdminFees + @emprAdminFees)                                                     
                                                              
  if @RepMode = 0            
     Select @cEmpBal = @cEmpBal + @DistrEmpC + @DistrAVCC,                                                             
     @cEmprBal = @cEmprBal + @DistrEmprC + @DistrSpecC,                                                            
     @GrandTotal = @GrandTotal + @DistrEmpC + @DistrAVCC + @DistrEmprC + @DistrSpecC                                                            
  else IF @RepMode = 1                                                                
     Select @cEmpBal = @cEmpBal + @DistrEmpC + @DistrAVCC + @DistrEmpCUn + @DistrAVCCUn,                                                             
     @cEmprBal = @cEmprBal + @DistrEmprC + @DistrSpecC + @DistrEmprCUn + @DistrSpecCUn,                                                            
     @GrandTotal = @GrandTotal + @DistrEmpC + @DistrAVCC + @DistrEmpCUn + @DistrAVCCUn +                                                            
     @DistrEmprC + @DistrSpecC + @DistrEmprCUn + @DistrSpecCUn                                                             
  else if @RepMode = 2                                                            
     Select @cEmpBal = @cEmpBal + @DistrAVCC + @DistrAVCCUn,                                                             
     @cEmprBal = @cEmprBal + @DistrSpecC + @DistrSpecCUn,                                                            
     @GrandTotal = @GrandTotal + @DistrAVCC + @DistrAVCCUn + @DistrSpecC + @DistrSpecCUn                                                 
                                                                   
   /*                                             
   if @DisplayMode = 0                                                                
    select @PayrollNo = cast(@MemberNo as Varchar(20))                                                 
   else if @DisplayMode = 1                                                                
    select @PayrollNo = @PayrollNo            
   else if @DisplayMode = 2                                                    
    select @PayrollNo = @idNumber                                                  
   else                                                 
    select @PayrollNo = cast(@MemberNo as Varchar(20))                                             
  */                                               
                                                                  
                                                             
 IF @cEmpBal = 0                                                            
   Select @EmpOpening = 0,@empCont = 0,@EmpTransfer=0,@EmpInt = 0                                                            
                                                                 
  if @schemeMode = 0                                                                
   begin                                                                
     select @SponsorName = CompanyName from SchemeCompanies where schemeNo = @schemeNo and CompanyId = @CompanyId                                                              
                                                                
     --if (@cEmprBal + @cEmpBal) <> 0                                                                  
       --begin                                                                  
        /*if ((@DoCalc < @EndDate) and (@ActiveStatus =  6))              
           BEGIN              
                       
           insert into #benCalcComb (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening,                                                                  
              empCont,emprCont, empInt, emprInt,grandTotal, CalcYear, CalcMonth, EndingPeriod,PayrollNo,                                                                  
                           EmpTransfer,EmprTransfer,ReportDesc,Astatus,Dob,dje,djpens,doexit,LoanBalance,SponsorName,PoolName,                                                  
              InterestRate,Dept,IDNumber,Gender,Grouper)                                                                  
            values (@schemeNo, @schemeName, @memberNo,@fullName, 0.0, @cEmprBal, 0.0, @EmprOpening,                                                                           0.0, @EmprCont, 0.0, @EmprInt, @cEmprBal, @CalcYear, @MonthName,     
              @CurPeriod,@PayrollNo,                                                                  
          @EmpTransfer,@EmprTransfer,@ReportDesc,@Astatus,@Dob,@dje,@djpens,@doexit,@LoanBalance,@SponsorName,@PoolName,                                                  
          @InterestRate,@Dept,@IDNumber,@Gender,'DEFERRED')               
           END                                       
        else*/                                                         
          insert into #benCalcComb (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening,                                                                  
             empCont,emprCont, empInt, emprInt,grandTotal, CalcYear, CalcMonth, EndingPeriod,PayrollNo,                                                               
             EmpTransfer,EmprTransfer,ReportDesc,Astatus,Dob,dje,djpens,doexit,LoanBalance,NetBalance,                                                  
                           SponsorName,PoolName,InterestRate,Dept,IDNumber,Gender,Grouper)                                                                  
           values (@schemeNo, @schemeName, @memberNo,@fullName, @cEmpBal, @cEmprBal, @EmpOpening, @EmprOpening,                                                                  
               @empCont+ @EmpTransfer, @EmprCont + @EmprTransfer, @EmpInt, @EmprInt, @GrandTotal, @CalcYear, @MonthName, @CurPeriod,@PayrollNo,                                                                  
          @EmpTransfer,@EmprTransfer,@ReportDesc,@Astatus,@Dob,@dje,@djpens,@doexit,@LoanBalance,@GrandTotal - @LoanBalance,                                                  
          @SponsorName,@PoolName,@InterestRate,@Dept,@IDNumber,@Gender,'ACTIVE')                                                                  
      --end                                                          
   end                                                                 
 else if @schemeMode = 1                                                                
   begin                                                                
     select @SponsorName = sponsorName from sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode                                                                
                                                                
     if (@cEmprBal + @cEmpBal) <> 0                                                                       begin                                                                  
        if ((@DoCalc <= @EndDate) and (@ActiveStatus =  6))                                                                
          insert into #benCalcComb (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening,                                            
                                            empCont,emprCont, empInt, emprInt,grandTotal, CalcYear, CalcMonth, EndingPeriod,PayrollNo,                                                                  
                           EmpTransfer,EmprTransfer,ReportDesc,Astatus,Dob,dje,djpens,doexit,LoanBalance,SponsorName,                                                  
                           NetBalance,PoolName,InterestRate,Dept,IDNumber,Gender,Grouper)                                                                  
            values (@schemeNo, @schemeName, @memberNo,@fullName, 0.0, @cEmprBal, 0.0, @EmprOpening,                                                                  
               0.0, @EmprCont, 0.0, @EmprInt, @cEmprBal, @CalcYear, @MonthName, @CurPeriod,@PayrollNo,                                                                  
          @EmpTransfer,@EmprTransfer,@ReportDesc,@Astatus,@Dob,@dje,@djpens,@doexit,@LoanBalance,@SponsorName,                                                  
          @cEmprBal - @LoanBalance,@PoolName,@InterestRate,@Dept,@IDNumber,@Gender,'DEFERRED')                                                                  
        else                                                                  
          insert into #benCalcComb (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening,                                                             
                    empCont,emprCont, empInt, emprInt,grandTotal, CalcYear, CalcMonth, EndingPeriod,PayrollNo,                                                                  
                           EmpTransfer,EmprTransfer,ReportDesc,Astatus,Dob,dje,djpens,doexit,LoanBalance,SponsorName,NetBalance,                                                  
                           PoolName,InterestRate,Dept,IDNumber,Gender,Grouper)                           
           values (@schemeNo, @schemeName, @memberNo,@fullName, @cEmpBal, @cEmprBal, @EmpOpening, @EmprOpening,                 
                                                                             
               @empCont+ @EmpTransfer, @EmprCont + @EmprTransfer, @EmpInt, @EmprInt, @GrandTotal, @CalcYear, @MonthName, @CurPeriod,@PayrollNo,                                                                  
          @EmpTransfer,@EmprTransfer,@ReportDesc,@Astatus,@Dob,@dje,@djpens,@doexit,@LoanBalance,@SponsorName,                                                  
          @GrandTotal - @LoanBalance,@PoolName,@InterestRate,@Dept,@IDNumber,@Gender,'ACTIVE')                                                                  
      end                                                                 
   end                                                                
                                         
                                                                      
  select @MemberNo=0, @cEmpBal=0, @cEmprBal=0, @GrandTotal=0, @fullname='',@PayrollNo='',@ActiveStatus=0,                                                                  
  @empAdminFees=0,@emprAdminFees=0,@EmpInt_Op=0,@EmprInt_Op=0,@VolInt_Op=0,@SpecInt_Op=0,@LoanBalance=0,@SponsorCode=0,                                                                
  @CompanyID=0,@AStatus =0,@xcEmpBal=0,@xcEmprBal=0,@empAdminFees_Un=0,@emprAdminFees_Un=0,@EmpInt_Un=0,                                             
  @EmprInt_Un=0,@VolInt_Un=0,@SpecInt_Un=0,@empOpening=0,@emprOpening=0,@EmpFeesOpen=0,                                                            
  @EmprFeesOpen=0,@DistrEmp=0,@DistrEmpr=0,@DistrAVC=0,@DistrSpec=0,@xempOpening=0,@xemprOpening=0,                           
  @EmpFeesOpen_Un=0, @EmprFeesOpen_Un=0,@EmpCont =0,@EmprCont =0,@EmpVol = 0, @EmprVol = 0,                                                            
  @xEmpCont = 0,@xEmprCont = 0,@xEmpVol = 0,@xEmprVol = 0,@EmpTransfer =0,@EmprTransfer =0,                                                            
  @empInt =0,@emprInt=0,                                                            
                                                            
  @DistrEmpUn =0,@DistrEmprUn =0,@DistrAVCUn =0,@DistrSpecUn =0,@DistrEmpCUn =0,@DistrEmprCUn =0,@DistrAVCCUn =0,@DistrSpecCUn =0,                                                         
  @DistrEmp =0,@DistrEmpr =0,@DistrAVC =0,@DistrSpec =0,@DistrEmpC =0,@DistrEmprC =0,@DistrAVCC =0,                                                            
  @DistrEmpC =0, @DistrAVCC=0,@DistrEmpCUn=0,@DistrAVCCUn=0,@DistrEmprC=0,@DistrSpecC=0,@DistrEmprCUn=0,@DistrSpecCUn=0,@Dept='',@idNumber = '',@Gender = ''                                        
                                                               
  fetch next from benCsr into @schemeNo, @memberNo, @cEmpBal, @cEmprBal, @grandTotal, @fullName,@PayrollNo,@DoCalc,@ActiveStatus,@empAdminFees,@emprAdminFees,                                                                  
                              @EmpInt_Op,@EmprInt_Op,@VolInt_Op,@SpecInt_Op,@LoanBalance,@Dob,@dje,@djpens,@doexit,@SponsorCode,@CompanyID,@Dept,@idNumber,@Gender                                                                  
end                                                                  
                                                                  
close benCsr                                                                  
deallocate benCsr                                                                    
                                      
                                      
                                                    
select @SponsorCode = @InitSponsorCode                                         
                                                               
/* DEFERRED BENEFIT */                                                                        
if @SponsorCode = 0                                                            
begin                                                                    
if @RepMode = 2                                                              
begin                                                                                                                          
 declare benCsr cursor for                                                               
 select distinct b.schemeNo, b.memberNo, b.EmpVolCont + b.PreAvc as empCont, b.EmprVolCont  as EmprCont,                                                                  
 (b.EmpVolCont + b.PreAvc + b.EmprVolCont) as TotalBalance,                                                   
 (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,m.ActiveStatus,                                                                  
 b.VolFees,b.SpecFees,0.0,0.0,b.VolInt,b.SpecInt,                                                      
 m.Dob,m.dje,m.djpens,m.doexit,m.SponsorCode,M.CompanyID,M.Dept,M.idNumber,m.sex                                                                 
 from MemberOpeningBalances b inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo and                                                                  
 m.ActiveStatus = 6 and ((m.ReasonForExit > 0) AND (m.DoCalc < @EndDate))                                           
 where b.SchemeNo = @schemeNo and b.AcctPeriod = @AcctPeriod  and b.ProvOrFinal = @ProvOrYearEnd                                                                 
 order by b.memberNo                                                                                                
end                                                              
else                              
begin                                                                                                                           
 declare benCsr cursor for                                                                   
 select distinct b.schemeNo, b.memberNo, b.empCont + b.EmpVolCont + b.PreEmpCont + b.Transfer + b.PreAvc as empCont,                                                      
 b.emprCont + b.EmprVolCont + b.PreEmprCont + b.LockedIn + b.DeferredAmt as EmprCont,                                                                  
 (b.empCont + b.EmpVolCont + b.PreEmpCont + b.Transfer + b.PreAvc + b.emprCont + b.EmprVolCont + b.PreEmprCont + b.LockedIn + b.DeferredAmt) as TotalBalance,                              
 (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,m.ActiveStatus,                                                                  
 b.EmpFees + b.VolFees,b.EmprFees + b.SpecFees,b.EmpInt,b.EmprInt,b.VolInt,b.SpecInt,                                                                
 m.Dob,m.dje,m.djpens,m.doexit,m.SponsorCode,M.CompanyID,M.Dept,M.idNumber,m.sex                                                                
 from MemberOpeningBalances b                                                             
 inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo and m.ActiveStatus = 6                                                             
 and ((m.ReasonForExit > 0) AND (m.DoCalc < @EndDate))                             
 where b.SchemeNo = @schemeNo and b.AcctPeriod = @AcctPeriod and b.ProvOrFinal = @ProvOrYearEnd                                                                 
 order by b.memberNo                                                                                              
end                    
open benCsr                                                                  
fetch from benCsr into @schemeNo, @MemberNo, @cEmpBal, @cEmprBal, @GrandTotal, @fullname,@PayrollNo,@DoCalc,@ActiveStatus,@empAdminFees,@emprAdminFees,                                                                  
    @EmpInt_Op,@EmprInt_Op,@VolInt_Op,@SpecInt_Op,@Dob,@dje,@djpens,@doexit,@SponsorCode,@CompanyID,@Dept,@idNumber,@Gender                                                                 
                                         
while @@fetch_status = 0                                                                  
begin 
  /* Test */
  print('********************************************************************************************************************')
  print @cEmpBal + @cEmprBal
  print @MemberNo
  print('********************************************************************************************************************')                                        
                                        
  /* Distributed Reserve */                                                                                     
  select @DistrEmp = EmpCont , @DistrEmpr = EmprCont,                                                                  
  @DistrAVC = AVC,                                                                   
  @DistrSpec = AVCER,@DistrEmpUn = EmpCont_Un , @DistrEmprUn = EmprCont_Un,                                                                  
  @DistrAVCUn = AVC_Un,                                                                   
  @DistrSpecUn = AVCER_Un                                                                 
  from memb_reservefund_distr   where SchemeNo = @schemeNo                                                                   
  and memberNo = @memberNo                                                                  
  and AcctPeriod = @acctPeriod - 1                                                                  
                                                                  
  select @DistrEmpC = EmpCont , @DistrEmprC = EmprCont,                                                        
  @DistrAVCC = AVC,                                                                  
  @DistrSpecC = AVCER,@DistrEmpCUn = EmpCont_Un , @DistrEmprCUn = EmprCont_Un,                                                                  
  @DistrAVCCUn = AVC_Un,                                                                   
  @DistrSpecCUn = AVCER_Un                                  
  from memb_reservefund_distr   where SchemeNo = @schemeNo                                                                   
  and memberNo = @memberNo                                                                  
  and AcctPeriod = @acctPeriod                                                                  
                                                                 
  IF @DistrEmp is null select @DistrEmp = 0                                                                  
  IF @DistrEmpr is null select @DistrEmpr = 0                                                                  
  IF @DistrAVC is null select @DistrAVC = 0                                                                  
  IF @DistrSpec is null select @DistrSpec = 0                                                                  
                                                                  
  IF @DistrEmpC is null select @DistrEmpC = 0                                                                  
  IF @DistrEmprC is null select @DistrEmprC = 0                                                                  
  IF @DistrAVCC is null select @DistrAVCC = 0                                                                  
  IF @DistrSpecC is null select @DistrSpecC = 0                                                            
                                                            
  IF @DistrEmpUn is null select @DistrEmpUn = 0                                                               
  IF @DistrEmprUn is null select @DistrEmprUn = 0                                              
  IF @DistrAVCUn is null select @DistrAVCUn = 0                                                                  
  IF @DistrSpecUn is null select @DistrSpecUn = 0                                                                  
                                                                  
  IF @DistrEmpCUn is null select @DistrEmpCUn = 0                                                                  
  IF @DistrEmprCUn is null select @DistrEmprCUn = 0                                                                  
  IF @DistrAVCCUn is null select @DistrAVCCUn = 0                                   
  IF @DistrSpecCUn is null select @DistrSpecCUn = 0                                              
                                                                                
  if @grandTotal is null select @grandTotal = 0                                                                  
  if @LoanBalance is null select @LoanBalance = 0.0                                                                
                                                                  
  if @EmpInt_Op is null select @EmpInt_Op = 0                                                                  
  if @EmprInt_Op is null select @EmprInt_Op =0                                                                  
  if @VolInt_Op is null select @VolInt_Op =0                                                                  
  if @SpecInt_Op is null select @SpecInt_Op = 0                                                       
                                                                   
  if @RepMode = 1                                                                  
  begin                                                 
                                                                      
         select @xcEmpBal = (ExcessEmp + ExcessVolContr) -(EmpTax + VolTax),                               
             @xcEmprBal = (ExcessEmpr + ExcessSpecial + DeferredAmt) - (EmprTax + SpecTax + defTax),                                              
             @empAdminFees_Un  = EmpFees_Un + VolFees_Un,@emprAdminFees_Un = EmprFees_Un + SpecFees_Un,                                                                  
             @EmpInt_Un = EmpInt,@EmprInt_Un=EmprInt + DefInterest,@VolInt_Un=VolInt,@SpecInt_Un=SpecInt                                                                  
         from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo                              
         and AcctPeriod = @AcctPeriod and ProvOrFinal = @ProvOrYearEnd                                                
                                                         
      if @empAdminFees_Un is null select @empAdminFees_Un = 0                                                                  
      if @emprAdminFees_Un is null select @emprAdminFees_Un = 0                                                                  
      if @EmpInt_Un is null select @EmpInt_Un = 0                                                                  
      if @EmprInt_Un is null select @EmprInt_Un =0                                                                  
      if @VolInt_Un is null select @VolInt_Un =0                                                                  
      if @SpecInt_Un is null select @SpecInt_Un = 0                                                                     
      select @ReportDesc = 'COMBINED'                                                      
  end                                                                  
  else if @RepMode = 0                                                                  
  begin                                                                  
   select @ReportDesc = 'TAX EXEMPT',@EmpInt_Un = 0,@EmprInt_Un=0,@VolInt_Un=0,@SpecInt_Un=0                                                                  
  end                                                               
  else if @RepMode = 2 /* AVC ONLY */                                                                 
  begin                                                  
                                                     
       select @xcEmpBal = (ExcessVolContr) - (VolTax),                                                                  
       @xcEmprBal = (ExcessSpecial) - (SpecTax),                                                                  
       @EmpInt_Un = 0.0,@EmprInt_Un=0.0,@VolInt_Un=VolInt,@SpecInt_Un=SpecInt                                                                  
       from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo                          
       and AcctPeriod = @AcctPeriod and ProvOrFinal = @ProvOrYearEnd                                                
                                                           
      select @ReportDesc = 'AVC ONLY'                                                                  
  end                                                                     
                                                                  
if @xcEmpBal is null select @xcEmpBal = 0                                                                  
  if @xcEmprBal is null select @xcEmprBal = 0                                                                  
                                                                  
  select @EmpInt_Op = @EmpInt_Op + @EmpInt_Un,@EmprInt_Op = @EmprInt_Op + @EmprInt_Un,                                               
         @VolInt_Op = @VolInt_Op + @VolInt_Un,@SpecInt_Op = @SpecInt_Op + @SpecInt_Un                                                                  
                                                                  
                                                                  
  Select @cEmpBal = @cEmpBal + @xcEmpBal                                                               
  Select @cEmprBal = @cEmprBal + @xcEmprBal                                                                 
  Select @grandTotal = @grandTotal + @xcEmpBal + @xcEmprBal                                         
                                                         
  if @RepMode = 2                                                              
     select @empOpening = empvolcont + PreAvc,                                
     @emprOpening = EmprVolcont,                                                                  
     @EmpFeesOpen = VolFees,@EmprFeesOpen = SpecFees                                                                  
     from memberOpeningBalances where SchemeNo = @schemeNo                                              
     and memberNo = @memberNo and acctPeriod = @acctPeriod - 1 and ProvOrFinal = 1                                                                 
  else                                                               
  select @empOpening = empCont + empvolcont + PreEmpCont + Transfer + PreAvc,                                             
         @emprOpening = emprCont + EmprVolcont + PreEmprCont + LockedIn + deferredAmt,                                                                  
         @EmpFeesOpen = EmpFees + VolFees,@EmprFeesOpen = EmprFees + SpecFees                                                                  
  from memberOpeningBalances where SchemeNo = @schemeNo                                                                   
  and memberNo = @memberNo and acctPeriod = @acctPeriod - 1  and ProvOrFinal = 1                                                                 
                                                                                       
  if @EmpFeesOpen is null select @EmpFeesOpen = 0                                                                  
  if @EmprFeesOpen is null select @EmprFeesOpen = 0                                                                  
                                                                  
  /* Knock off the admin Fees from the Registered Opening Balances */                                                                  
  select @empOpening = (@empOpening + @DistrEmp + @DistrAVC)- @EmpFeesOpen,                                                                  
  @emprOpening= (@emprOpening + @DistrEmpr + @DistrSpec )- @EmprFeesOpen                                                                 
                                                            
  if @RepMode = 1                                                                  
  begin                                                                  
  select @xempOpening = (ExcessEmp + ExcessVolContr) -(EmpTax + VolTax),                                                                   
         @xemprOpening = (ExcessEmpr + ExcessSpecial + DeferredAmt) -(EmprTax + SpecTax + deftax),                       
         @EmpFeesOpen_Un = EmpFees_Un + VolFees_Un,@EmprFeesOpen_Un = EmprFees_Un + SpecFees_Un                                                                  
  from UnRegisteredBalances where SchemeNo = @schemeNo                                                                   
  and memberNo = @memberNo and acctPeriod = @acctPeriod - 1 and ProvOrFinal = 1                                                                
                                                                  
  if @EmpFeesOpen_Un is null select @EmpFeesOpen_Un = 0                                                                  
  if @EmprFeesOpen_Un is null select @EmprFeesOpen_Un = 0                                                 
                                                         
  /* Knock off the admin Fees from the UnRegistered Opening Balances */                                                                  
  select @xempOpening = (@xempOpening + @DistrEmpUn + @DistrAVCUn) - @EmpFeesOpen_Un,                                                            
  @xemprOpening= (@xemprOpening + @DistrEmprUn + @DistrSpecUn) - @EmprFeesOpen_Un                                           
  end                                                                  
                                                              
                                                                                                  
  Exec RepMemberCertificateContributions @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @EmpCont out,                                                                   
  @EmprCont out, @EmpVol out, @EmprVol out                                                                 
                                                              
  if @RepMode = 2                                                              
  begin                                                                
     Exec RepMemberCertificateContributions @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @EmpCont out,                                                                   
     @EmprCont out, @EmpVol out, @EmprVol out                                                
                                                              
     select @EmpCont = 0.0,@EmprCont = 0.0                                                              
  end                                       
                                                                  
  if @RepMode = 1                                                                  
  begin                                                                  
  Exec RepMemberCertificateContributions_Un @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @xEmpCont out,                                                                   
    @xEmprCont out, @xEmpVol out, @xEmprVol out                                                                  
  end              
  else if @RepMode = 2                                                                  
  begin                                                                  
  Exec RepMemberCertificateContributions_Un @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @xEmpCont out,                                                                   
    @xEmprCont out, @xEmpVol out, @xEmprVol out                                                              
                                                              
    select @xEmpCont = 0.0,@xEmprCont = 0.0                                                                  
  end                                             
                                                                  
  if @emprOpening is null select @emprOpening = 0                                                                  
                                                                
  if @RepMode < 2                                
    exec RepMemberCertificateTransfer @schemeNo, @MemberNo, @AcctPeriod, @EmpTransfer out,@EmprTransfer out                                                                  
                                                                  
  if @empOpening is null select @empOpening = 0                                                                  
  if @emprOpening is null select @emprOpening = 0                                                                  
  if @empCont is null select @empcont = 0                                                                  
  if @emprCont is null select @emprCont = 0                                                                  
  if @xempOpening is null select @xempOpening = 0                                                              
  if @xemprOpening is null select @xemprOpening = 0                                       
  if @xempCont is null select @xempcont = 0                                                                  
  if @xemprCont is null select @xemprCont = 0                                                                  
 if @xEmpVol is null select @xEmpVol = 0                                                                  
  if @xEmprVol is null select @xEmprVol = 0                                                                  
  if @EmpVol is null select @EmpVol = 0                                                                  
  if @EmprVol is null select @EmprVol = 0                                                                  
  if @Transfer is null select @Transfer = 0                                                                  
                                    
  Select @empOpening = @empOpening + @xempOpening                                                                  
  Select @emprOpening = @emprOpening + @xemprOpening                                                                   
                                                                  
  Select @empCont = @empCont + @xempCont + @xEmpVol + @EmpVol                                    
  Select @emprCont = @emprCont + @xemprCont + @xEmprVol + @EmprVol                                                                   
                                                                  
  if @ShowInterest = 0                                                                  
     select @empInt = @cEmpBal - (@empOpening + @empCont + @EmpTransfer)                                 
 else if @ShowInterest = 1                                                                  
     select @empInt = @EmpInt_Op + @VolInt_Op                                                                  
                                                                  
  if @empInt is null select @empInt = 0                                                                  
  if @emprOpening is null select @emprOpening = 0                                                                  
                                                               
  if @ShowInterest = 0                                                                  
 select @emprInt = @cEmprBal - (@emprOpening + @emprCont + @EmprTransfer)                                                                  
  else if @ShowInterest = 1                                                                  
     select @emprInt = @EmprInt_Op + @SpecInt_Op         
                                                                  
  if @PayrollNo is null select @PayrollNo = @MemberNo                                                                  
                                                                  
  IF @RepMode = 1                                                                  
    select @cEmpBal = @cEmpBal - (@empAdminFees + @empAdminFees_Un),@cEmprBal = @cEmprBal - (@emprAdminFees + @emprAdminFees_Un),@GrandTotal = @GrandTotal - (@empAdminFees + @emprAdminFees + @emprAdminFees_Un + @empAdminFees_Un)                          
  
    
      
        
          
            
                               
  else                                                                  
     select @cEmpBal = @cEmpBal - @empAdminFees,@cEmprBal = @cEmprBal - @emprAdminFees,                                                            
     @GrandTotal = @GrandTotal - (@empAdminFees + @emprAdminFees)                                                                   
                                                                  
                                                                    
  if @RepMode = 0                                                            
     Select @cEmpBal = @cEmpBal + @DistrEmpC + @DistrAVCC,              
     @cEmprBal = @cEmprBal + @DistrEmprC + @DistrSpecC,                                                            
 @GrandTotal = @GrandTotal + @DistrEmpC + @DistrAVCC + @DistrEmprC + @DistrSpecC                                                            
  else IF @RepMode = 1                           
     Select @cEmpBal = @cEmpBal + @DistrEmpC + @DistrAVCC + @DistrEmpCUn + @DistrAVCCUn,                                                             
     @cEmprBal = @cEmprBal + @DistrEmprC + @DistrSpecC + @DistrEmprCUn + @DistrSpecCUn,                                                            
 @GrandTotal = @GrandTotal + @DistrEmpC + @DistrAVCC + @DistrEmpCUn + @DistrAVCCUn +                                                            
     @DistrEmprC + @DistrSpecC + @DistrEmprCUn + @DistrSpecCUn                                                             
  else if @RepMode = 2                                         
     Select @cEmpBal = @cEmpBal + @DistrAVCC + @DistrAVCCUn,                                                             
     @cEmprBal = @cEmprBal + @DistrSpecC + @DistrSpecCUn,                                               
     @GrandTotal = @GrandTotal + @DistrAVCC + @DistrAVCCUn + @DistrSpecC + @DistrSpecCUn                                                                                                            
  if @zambia = 0                                          
     begin                                                 
       if @DisplayMode = 0                                                                
          select @PayrollNo = cast(@MemberNo as Varchar(20))                                                 
       else if @DisplayMode = 1                                                                
          select @PayrollNo = @PayrollNo                                                
       else if @DisplayMode = 2                                                                
          select @PayrollNo = @idNumber                                                  
       else                                                 
          select @PayrollNo = cast(@MemberNo as Varchar(20))                                          
     end                                                             
                                            
                                                            
  IF @cEmpBal = 0                                                            
    Select @EmpOpening = 0,@empCont = 0,@EmpTransfer=0,@EmpInt = 0                                                            
              IF NOT Exists (Select * from #benCalcComb where schemeNo = @schemeNo and MemberNo = @MemberNo)                                                                  
    begin              
     PRINT @MEMBERNO              
     PRINT ('*****************************************************************************************************')                                                                  
     if (@cEmprBal + @cEmpBal) <> 0                                                                  
       begin                                                            
         if @schemeMode = 1                                                                 
           begin                                                                
           select @SponsorName = SponsorName from Sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode                                                                                                          
           insert into #benCalcComb (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening,                                                                  
                                            empCont,emprCont, empInt, emprInt,grandTotal, CalcYear, CalcMonth, EndingPeriod,PayrollNo,                                                                  
                           EmpTransfer,EmprTransfer,ReportDesc,Dob,dje,djpens,doexit,LoanBalance,SponsorName,PoolName,                                                
          InterestRate,Dept,IDNumber,Gender,Grouper)                                
           values (@schemeNo, @schemeName, @memberNo,@fullName, 0.0, @cEmprBal, 0.0, @EmprOpening,                                                                  
               0.0, @EmprCont + @EmprTransfer, 0.0, @EmprInt, @cEmprBal, @CalcYear, @MonthName, @CurPeriod,@PayrollNo,                                                                  
           @EmpTransfer,@EmprTransfer,@ReportDesc,@Dob,@dje,@djpens,@doexit,@LoanBalance,@SponsorName,@PoolName,@InterestRate,                              
           @Dept,@IDNumber,@Gender,'DEFERRED')                                                                
           end                                                                 
         else                                                          
          begin                                                             
                                                                        
           select @SponsorName = CompanyName from SchemeCompanies where schemeNo = @schemeNo and CompanyId = @CompanyId                                                                
                                                                
           insert into #benCalcComb (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening,        
                           empCont,emprCont, empInt, emprInt,grandTotal, CalcYear, CalcMonth, EndingPeriod,PayrollNo,                                                                  
                           EmpTransfer,EmprTransfer,ReportDesc,Dob,dje,djpens,doexit,LoanBalance,SponsorName,PoolName,                                                
                           InterestRate,Dept,IDNumber,Gender,Grouper)                                          
           values (@schemeNo, @schemeName, @memberNo,@fullName, 0.0, @cEmprBal, 0.0, @EmprOpening,                                                                  
               0.0, @EmprCont + @EmprTransfer, 0.0, @EmprInt, @cEmprBal, @CalcYear, @MonthName, @CurPeriod,@PayrollNo,                                                          
           @EmpTransfer,@EmprTransfer,@ReportDesc,@Dob,@dje,@djpens,@doexit,@LoanBalance,@SponsorName,@PoolName,@InterestRate,                                                
           @Dept,@IDNumber,@Gender,'DEFERRED')                                                                 
                                                                
         end                                                                  
       end                                                                  
    end                                                                  
                                                                    
               
  select @MemberNo=0, @cEmpBal=0, @cEmprBal=0, @GrandTotal=0, @fullname='',@PayrollNo='',@ActiveStatus=0,                                                                  
  @empAdminFees=0,@emprAdminFees=0,@EmpInt_Op=0,@EmprInt_Op=0,@VolInt_Op=0,@SpecInt_Op=0,@LoanBalance=0,@SponsorCode=0,                                                                
  @CompanyID=0,@AStatus =0,@xcEmpBal=0,@xcEmprBal=0,@empAdminFees_Un=0,@emprAdminFees_Un=0,@EmpInt_Un=0,                                                            
  @EmprInt_Un=0,@VolInt_Un=0,@SpecInt_Un=0,@empOpening=0,@emprOpening=0,@EmpFeesOpen=0,                                                            
  @EmprFeesOpen=0,@DistrEmp=0,@DistrEmpr=0,@DistrAVC=0,@DistrSpec=0,@xempOpening=0,@xemprOpening=0,                                                            
  @EmpFeesOpen_Un=0, @EmprFeesOpen_Un=0,@EmpCont =0,@EmprCont =0,@EmpVol = 0, @EmprVol = 0,                                                            
  @xEmpCont = 0,@xEmprCont = 0,@xEmpVol = 0,@xEmprVol = 0,@EmpTransfer =0,@EmprTransfer =0,                                                            
  @empInt =0,@emprInt=0,@DistrEmpUn =0,@DistrEmprUn =0,@DistrAVCUn =0,@DistrSpecUn =0,@DistrEmpCUn =0,@DistrEmprCUn =0,@DistrAVCCUn =0,@DistrSpecCUn =0,                                                            
  @DistrEmp =0,@DistrEmpr =0,@DistrAVC =0,@DistrSpec =0,@DistrEmpC =0,@DistrEmprC =0,@DistrAVCC =0,                                                            
  @DistrEmpC =0, @DistrAVCC=0,@DistrEmpCUn=0,@DistrAVCCUn=0,@DistrEmprC=0,@DistrSpecC=0,@DistrEmprCUn=0,@DistrSpecCUn=0,                                                
  @Dept='',@idNumber='',@Gender =''                                                                 
                                                                  
  fetch next from benCsr into @schemeNo, @memberNo, @cEmpBal, @cEmprBal, @grandTotal, @fullName,@PayrollNo,@DoCalc,@ActiveStatus,@empAdminFees,@emprAdminFees,                                                                  
  @EmpInt_Op,@EmprInt_Op,@VolInt_Op,@SpecInt_Op,@Dob,@dje,@djpens,@doexit,@SponsorCode,@CompanyID,@Dept,@idNumber,@Gender                                                                
end                                                                  
                                                                  
close benCsr                                   
deallocate benCsr                                                                    
update #benCalcComb set Astatus =6 where Astatus is null       
                                         
end /* SponsorCode = 0 */                                            
if @SponsorCode > 0                                                
begin                                                                    
if @RepMode = 2                                                              
begin                                                              
                                                                             
 declare benCsr cursor for                                                                   
 select distinct b.schemeNo, b.memberNo, b.EmpVolCont + b.PreAvc as empCont, b.EmprVolCont  as EmprCont,                                                                  
 (b.EmpVolCont + b.PreAvc + b.EmprVolCont) as TotalBalance,                                                   
 (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,m.ActiveStatus,                                                                  
 b.VolFees,b.SpecFees,0.0,0.0,b.VolInt,b.SpecInt,                                                                
 m.Dob,m.dje,m.djpens,m.doexit,m.SponsorCode,M.CompanyID,M.Dept,M.idNumber                                                                 
 from MemberOpeningBalances b inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo and                                                                  
 m.ActiveStatus = 6 and                                             
 ((m.ReasonForExit > 0) AND (m.DoCalc < @EndDate)) and m.sponsorCode = @SponsorCode                                                                   
 where b.SchemeNo = @schemeNo and b.AcctPeriod = @AcctPeriod and b.ProvOrFinal = @ProvOrYearEnd                                                                  
 order by b.memberNo                                                                                                
end                                                              
else                                                              
begin                                                                                                  
 declare benCsr cursor for                                                                   
 select distinct b.schemeNo, b.memberNo, b.empCont + b.EmpVolCont + b.PreEmpCont + b.Transfer + b.PreAvc as empCont,                                                      
 b.emprCont + b.EmprVolCont + b.PreEmprCont + b.LockedIn + b.DeferredAmt as EmprCont,                                                                  
 (b.empCont + b.EmpVolCont + b.PreEmpCont + b.Transfer + b.PreAvc + b.emprCont + b.EmprVolCont + b.PreEmprCont + b.LockedIn + b.DeferredAmt) as TotalBalance,                                                                  
 (upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname,m.PayrollNo,M.DoCalc,m.ActiveStatus,                                                                  
 b.EmpFees + b.VolFees,b.EmprFees + b.SpecFees,b.EmpInt,b.EmprInt,b.VolInt,b.SpecInt,                                                    
 m.Dob,m.dje,m.djpens,m.doexit,m.SponsorCode,M.CompanyID,M.Dept,M.idNumber                                                                 
 from MemberOpeningBalances b                                                             
 inner join Members m on b.SchemeNo = m.schemeNo and b.memberNo = m.memberNo and m.ActiveStatus = 6                                                             
 and ((m.ReasonForExit > 0) AND (m.DoCalc < @EndDate)) and m.sponsorCode = @SponsorCode                                                                  
 where b.SchemeNo = @schemeNo and b.AcctPeriod = @AcctPeriod and b.ProvOrFinal = @ProvOrYearEnd                                                                 
 order by b.memberNo                                                                                               
end                                                                                                   
open benCsr                          
fetch from benCsr into @schemeNo, @MemberNo, @cEmpBal, @cEmprBal, @GrandTotal, @fullname,@PayrollNo,@DoCalc,@ActiveStatus,@empAdminFees,@emprAdminFees,                                                                  
                       @EmpInt_Op,@EmprInt_Op,@VolInt_Op,@SpecInt_Op,@Dob,@dje,@djpens,@doexit,@SponsorCode,@CompanyID,@Dept,@idNumber                                   
                                                                  
while @@fetch_status = 0                                                                  
begin                                         
                                        
  /* Distributed Reserve */                                                                                     
  select @DistrEmp = EmpCont , @DistrEmpr = EmprCont,                                                                  
  @DistrAVC = AVC,                                                                   
  @DistrSpec = AVCER,@DistrEmpUn = EmpCont_Un , @DistrEmprUn = EmprCont_Un,                                                                  
  @DistrAVCUn = AVC_Un,                                                              
  @DistrSpecUn = AVCER_Un                                                                 
  from memb_reservefund_distr   where SchemeNo = @schemeNo                                                                   
  and memberNo = @memberNo                                             
  and AcctPeriod = @acctPeriod - 1                                                                  
                                                  
  select @DistrEmpC = EmpCont , @DistrEmprC = EmprCont,                                                                  
  @DistrAVCC = AVC,                                                                  
  @DistrSpecC = AVCER,@DistrEmpCUn = EmpCont_Un , @DistrEmprCUn = EmprCont_Un,                                                                  
  @DistrAVCCUn = AVC_Un,                                       
  @DistrSpecCUn = AVCER_Un                                                                 
  from memb_reservefund_distr   where SchemeNo = @schemeNo                                                                   
  and memberNo = @memberNo                                                                  
  and AcctPeriod = @acctPeriod                                         
                                                                
  IF @DistrEmp is null select @DistrEmp = 0                              
  IF @DistrEmpr is null select @DistrEmpr = 0                                                                  
  IF @DistrAVC is null select @DistrAVC = 0                                                                  
  IF @DistrSpec is null select @DistrSpec = 0                                                                  
                                                       
  IF @DistrEmpC is null select @DistrEmpC = 0                                                                  
  IF @DistrEmprC is null select @DistrEmprC = 0                                                                  
  IF @DistrAVCC is null select @DistrAVCC = 0                                                                  
  IF @DistrSpecC is null select @DistrSpecC = 0                                                            
                                                            
  IF @DistrEmpUn is null select @DistrEmpUn = 0                                                                  
  IF @DistrEmprUn is null select @DistrEmprUn = 0                                                            
  IF @DistrAVCUn is null select @DistrAVCUn = 0                                                                  
  IF @DistrSpecUn is null select @DistrSpecUn = 0                                                                  
                                                                  
  IF @DistrEmpCUn is null select @DistrEmpCUn = 0                                  
  IF @DistrEmprCUn is null select @DistrEmprCUn = 0                                                                  
  IF @DistrAVCCUn is null select @DistrAVCCUn = 0                                                                  
  IF @DistrSpecCUn is null select @DistrSpecCUn = 0                                          
                                                                                
  if @grandTotal is null select @grandTotal = 0                                                                  
  if @LoanBalance is null select @LoanBalance = 0.0                                                                
                                                                  
  if @EmpInt_Op is null select @EmpInt_Op = 0                                                   
  if @EmprInt_Op is null select @EmprInt_Op =0                                                                  
  if @VolInt_Op is null select @VolInt_Op =0                                                                  
  if @SpecInt_Op is null select @SpecInt_Op = 0                                                                  
                                                                 
  if @RepMode = 1                                                                  
  begin                                            
                                                                    
         select @xcEmpBal = (ExcessEmp + ExcessVolContr) -(EmpTax + VolTax),                                                                   
             @xcEmprBal = (ExcessEmpr + ExcessSpecial + DeferredAmt) - (EmprTax + SpecTax + defTax),                                                                  
         @empAdminFees_Un  = EmpFees_Un + VolFees_Un,@emprAdminFees_Un = EmprFees_Un + SpecFees_Un,                                                                  
         @EmpInt_Un = EmpInt,@EmprInt_Un=EmprInt + DefInterest,@VolInt_Un=VolInt,@SpecInt_Un=SpecInt                                                                  
         from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                                  
         and AcctPeriod = @AcctPeriod and ProvOrFinal = @ProvOrYearEnd                                                
                                 
      if @empAdminFees_Un is null select @empAdminFees_Un = 0                                                                  
      if @emprAdminFees_Un is null select @emprAdminFees_Un = 0                                                                  
      if @EmpInt_Un is null select @EmpInt_Un = 0                                                                  
      if @EmprInt_Un is null select @EmprInt_Un =0                                                                  
      if @VolInt_Un is null select @VolInt_Un =0                                                                  
      if @SpecInt_Un is null select @SpecInt_Un = 0                                                                     
      select @ReportDesc = 'COMBINED'                                                 
  end                                                                  
  else if @RepMode = 0                     
  begin                                                                  
   select @ReportDesc = 'TAX EXEMPT',@EmpInt_Un = 0,@EmprInt_Un=0,@VolInt_Un=0,@SpecInt_Un=0                                                                  
  end                                      
  else if @RepMode = 2 /* AVC ONLY */                                                                 
  begin                                                  
                                                     
       select @xcEmpBal = (ExcessVolContr) - (VolTax),                                                                  
       @xcEmprBal = (ExcessSpecial) - (SpecTax),                                                                  
       @EmpInt_Un = 0.0,@EmprInt_Un=0.0,@VolInt_Un=VolInt,@SpecInt_Un=SpecInt                                                                  
       from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo                                                 
       and AcctPeriod = @AcctPeriod and ProvOrFinal = @ProvOrYearEnd                                                
                                                           
    select @ReportDesc = 'AVC ONLY'                                                                  
  end                                
                                               
  if @xcEmpBal is null select @xcEmpBal = 0                                                                  
  if @xcEmprBal is null select @xcEmprBal = 0                                                                  
                                                                  
  select @EmpInt_Op = @EmpInt_Op + @EmpInt_Un,@EmprInt_Op = @EmprInt_Op + @EmprInt_Un,                                         
         @VolInt_Op = @VolInt_Op + @VolInt_Un,@SpecInt_Op = @SpecInt_Op + @SpecInt_Un                                                                  
                                                                  
                                                                  
  Select @cEmpBal = @cEmpBal + @xcEmpBal                                                               
  Select @cEmprBal = @cEmprBal + @xcEmprBal                                                                 
  Select @grandTotal = @grandTotal + @xcEmpBal + @xcEmprBal                                         
                                                 
                                                                
  if @RepMode = 2               
     select @empOpening = empvolcont + PreAvc,                                                                   
     @emprOpening = EmprVolcont,                                                                  
     @EmpFeesOpen = VolFees,@EmprFeesOpen = SpecFees                                                                  
     from memberOpeningBalances where SchemeNo = @schemeNo                                                                   
     and memberNo = @memberNo and acctPeriod = @acctPeriod - 1 and ProvOrFinal = 1                                                                
  else                                                               
  select @empOpening = empCont + empvolcont + PreEmpCont + Transfer + PreAvc,                                                                   
         @emprOpening = emprCont + EmprVolcont + PreEmprCont + LockedIn + deferredAmt,                                                                  
         @EmpFeesOpen = EmpFees + VolFees,@EmprFeesOpen = EmprFees + SpecFees                                                                  
  from memberOpeningBalances where SchemeNo = @schemeNo                                                                   
  and memberNo = @memberNo and acctPeriod = @acctPeriod - 1 and ProvOrFinal = 1                                                                  
                               
  if @EmpFeesOpen is null select @EmpFeesOpen = 0                                                                  
  if @EmprFeesOpen is null select @EmprFeesOpen = 0                                                                  
                     
  /* Knock off the admin Fees from the Registered Opening Balances */                                                                  
  select @empOpening = (@empOpening + @DistrEmp + @DistrAVC)- @EmpFeesOpen,                                         
  @emprOpening= (@emprOpening + @DistrEmpr + @DistrSpec )- @EmprFeesOpen                                                                 
                                                            
  if @RepMode = 1                                                                  
  begin                                                                  
  select @xempOpening = (ExcessEmp + ExcessVolContr) -(EmpTax + VolTax),                                           
         @xemprOpening = (ExcessEmpr + ExcessSpecial + DeferredAmt) -(EmprTax + SpecTax + deftax),                                                                  
         @EmpFeesOpen_Un = EmpFees_Un + VolFees_Un,@EmprFeesOpen_Un = EmprFees_Un + SpecFees_Un                                                                  
  from UnRegisteredBalances where SchemeNo = @schemeNo                                    
  and memberNo = @memberNo and acctPeriod = @acctPeriod - 1 and ProvOrFinal = 1                                                                 
                                                                  
  if @EmpFeesOpen_Un is null select @EmpFeesOpen_Un = 0                                                       
  if @EmprFeesOpen_Un is null select @EmprFeesOpen_Un = 0                                        
                           
  /* Knock off the admin Fees from the UnRegistered Opening Balances */                                                                  
  select @xempOpening = (@xempOpening + @DistrEmpUn + @DistrAVCUn) - @EmpFeesOpen_Un,                                                            
  @xemprOpening= (@xemprOpening + @DistrEmprUn + @DistrSpecUn) - @EmprFeesOpen_Un                                                                  
  end                                                                  
                                                              
                                                          
                                                                
  Exec RepMemberCertificateContributions @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @EmpCont out,                                                                   
  @EmprCont out, @EmpVol out, @EmprVol out                                                                 
                                                              
  if @RepMode = 2                                                              
  begin                                                                
     Exec RepMemberCertificateContributions @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @EmpCont out,                                                                   
     @EmprCont out, @EmpVol out, @EmprVol out                                                              
                           
     select @EmpCont = 0.0,@EmprCont = 0.0                                                              
  end                                                               
                                                                  
  if @RepMode = 1                                                                  
  begin                                                                  
  Exec RepMemberCertificateContributions_Un @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @xEmpCont out,                                                                   
    @xEmprCont out, @xEmpVol out, @xEmprVol out                                                                  
  end                                                                 
  else if @RepMode = 2                                                   
  begin                                                                  
  Exec RepMemberCertificateContributions_Un @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @xEmpCont out,                                                                   
    @xEmprCont out, @xEmpVol out, @xEmprVol out                                               
                                                         
    select @xEmpCont = 0.0,@xEmprCont = 0.0                                                                  
  end                                                                
                                                                  
  if @emprOpening is null select @emprOpening = 0                                                                  
                                                                
  if @RepMode < 2                                      
    exec RepMemberCertificateTransfer @schemeNo, @MemberNo, @AcctPeriod, @EmpTransfer out,@EmprTransfer out                                                      
                                                                  
  if @empOpening is null select @empOpening = 0                                              
  if @emprOpening is null select @emprOpening = 0                                                                  
  if @empCont is null select @empcont = 0                                                                  
  if @emprCont is null select @emprCont = 0                                                                  
  if @xempOpening is null select @xempOpening = 0                                                                  
  if @xemprOpening is null select @xemprOpening = 0                                                                  
  if @xempCont is null select @xempcont = 0                                              
  if @xemprCont is null select @xemprCont = 0                                                                  
 if @xEmpVol is null select @xEmpVol = 0                                                                  
  if @xEmprVol is null select @xEmprVol = 0                                                                  
  if @EmpVol is null select @EmpVol = 0                                                                  
  if @EmprVol is null select @EmprVol = 0                                          
  if @Transfer is null select @Transfer = 0                                                                  
                                                        
  Select @empOpening = @empOpening + @xempOpening                                                                  
  Select @emprOpening = @emprOpening + @xemprOpening                                                     
                                                                  
  Select @empCont = @empCont + @xempCont + @xEmpVol + @EmpVol                                                                   
  Select @emprCont = @emprCont + @xemprCont + @xEmprVol + @EmprVol                                                                   
                                                                  
  if @ShowInterest = 0                                                                  
     select @empInt = @cEmpBal - (@empOpening + @empCont + @EmpTransfer)                                                                  
  else if @ShowInterest = 1                                                                  
     select @empInt = @EmpInt_Op + @VolInt_Op                                               
                                                                  
  if @empInt is null select @empInt = 0                                                                  
  if @emprOpening is null select @emprOpening = 0                                                                  
                                                                  
  if @ShowInterest = 0                                                                  
 select @emprInt = @cEmprBal - (@emprOpening + @emprCont + @EmprTransfer)                                                                  
  else if @ShowInterest = 1                                                                  
     select @emprInt = @EmprInt_Op + @SpecInt_Op                 
                                                                  
  if @PayrollNo is null select @PayrollNo = @MemberNo                                                                  
                                 
  IF @RepMode = 1                                                                
    select @cEmpBal = @cEmpBal - (@empAdminFees + @empAdminFees_Un),@cEmprBal = @cEmprBal - (@emprAdminFees + @emprAdminFees_Un),@GrandTotal = @GrandTotal - (@empAdminFees + @emprAdminFees + @emprAdminFees_Un + @empAdminFees_Un)                                                       
  else                                                           
     select @cEmpBal = @cEmpBal - @empAdminFees,@cEmprBal = @cEmprBal - @emprAdminFees,                                                            
     @GrandTotal = @GrandTotal - (@empAdminFees + @emprAdminFees)                                                                   
                                                                  
                                                                    
   if @RepMode = 0                                                            
     Select @cEmpBal = @cEmpBal + @DistrEmpC + @DistrAVCC,                                                             
     @cEmprBal = @cEmprBal + @DistrEmprC + @DistrSpecC,                                                            
     @GrandTotal = @GrandTotal + @DistrEmpC + @DistrAVCC + @DistrEmprC + @DistrSpecC                                                            
  else IF @RepMode = 1                                                        
     Select @cEmpBal = @cEmpBal + @DistrEmpC + @DistrAVCC + @DistrEmpCUn + @DistrAVCCUn,                                                             
     @cEmprBal = @cEmprBal + @DistrEmprC + @DistrSpecC + @DistrEmprCUn + @DistrSpecCUn,                                                            
     @GrandTotal = @GrandTotal + @DistrEmpC + @DistrAVCC + @DistrEmpCUn + @DistrAVCCUn +                                                            
     @DistrEmprC + @DistrSpecC + @DistrEmprCUn + @DistrSpecCUn                                                             
  else if @RepMode = 2                                                            
     Select @cEmpBal = @cEmpBal + @DistrAVCC + @DistrAVCCUn,                                                             
     @cEmprBal = @cEmprBal + @DistrSpecC + @DistrSpecCUn,                                                            
     @GrandTotal = @GrandTotal + @DistrAVCC + @DistrAVCCUn + @DistrSpecC + @DistrSpecCUn                                                             
                                                        
                                
  if @zambia = 0                                          
     begin                           
       if @DisplayMode = 0                                                                
  select @PayrollNo = cast(@MemberNo as Varchar(20))                                                 
       else if @DisplayMode = 1                                                                
          select @PayrollNo = @PayrollNo                                                
       else if @DisplayMode = 2                                                                
          select @PayrollNo = @idNumber                                                  
       else                                                 
          select @PayrollNo = cast(@MemberNo as Varchar(20))                                          
     end                                                             
                                            
                                                            
  IF @cEmpBal = 0                                                            
    Select @EmpOpening = 0,@empCont = 0,@EmpTransfer=0,@EmpInt = 0                                                            
              IF NOT Exists (Select * from #benCalcComb where schemeNo = @schemeNo and MemberNo = @MemberNo)                                                                  
    begin                                                                  
     if (@cEmprBal + @cEmpBal) <> 0                                                              
       begin                                                                 
         if @schemeMode = 1                                            
           begin                                                         
           select @SponsorName = SponsorName from Sponsor where schemeNo = @schemeNo and SponsorCode = @SponsorCode                      
                                                                 
           insert into #benCalcComb (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening,                                                                  
               empCont,emprCont, empInt, emprInt,grandTotal, CalcYear, CalcMonth, EndingPeriod,PayrollNo,                                                                  
                           EmpTransfer,EmprTransfer,ReportDesc,Dob,dje,djpens,doexit,LoanBalance,SponsorName,PoolName,                                                
                           InterestRate,Dept,IDNumber,Grouper)                                                                  
           values (@schemeNo, @schemeName, @memberNo,@fullName, 0.0, @cEmprBal, 0.0, @EmprOpening,                                                                  
               0.0, @EmprCont + @EmprTransfer, 0.0, @EmprInt, @cEmprBal, @CalcYear, @MonthName, @CurPeriod,@PayrollNo,                                                                  
           @EmpTransfer,@EmprTransfer,@ReportDesc,@Dob,@dje,@djpens,@doexit,@LoanBalance,@SponsorName,@PoolName,@InterestRate,                                                
           @Dept,@IDNumber,'DEFERRED')                                                                
           end                                                                 
         else                                                     
          begin                                                             
                                                                        
           select @SponsorName = CompanyName from SchemeCompanies where schemeNo = @schemeNo and CompanyId = @CompanyId                                                                
                                                                
           insert into #benCalcComb (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal, empOpening, emprOpening,                                           
                                            empCont,emprCont, empInt, emprInt,grandTotal, CalcYear, CalcMonth, EndingPeriod,PayrollNo,                                                                  
                           EmpTransfer,EmprTransfer,ReportDesc,Dob,dje,djpens,doexit,LoanBalance,SponsorName,PoolName,                                                
                           InterestRate,Dept,IDNumber,Grouper)                                                                  
           values (@schemeNo, @schemeName, @memberNo,@fullName, 0.0, @cEmprBal, 0.0, @EmprOpening,                                                                  
               0.0, @EmprCont + @EmprTransfer, 0.0, @EmprInt, @cEmprBal, @CalcYear, @MonthName, @CurPeriod,@PayrollNo,                                                                  
           @EmpTransfer,@EmprTransfer,@ReportDesc,@Dob,@dje,@djpens,@doexit,@LoanBalance,@SponsorName,@PoolName,@InterestRate,                                                
           @Dept,@IDNumber,'DEFERRED')                                                                 
                                                                
         end                                                    
       end                                                                  
    end                                                                                                                                    
  select @MemberNo=0, @cEmpBal=0, @cEmprBal=0, @GrandTotal=0, @fullname='',@PayrollNo='',@ActiveStatus=0,                                                                  
  @empAdminFees=0,@emprAdminFees=0,@EmpInt_Op=0,@EmprInt_Op=0,@VolInt_Op=0,@SpecInt_Op=0,@LoanBalance=0,@SponsorCode=0,                                                                
  @CompanyID=0,@AStatus =0,@xcEmpBal=0,@xcEmprBal=0,@empAdminFees_Un=0,@emprAdminFees_Un=0,@EmpInt_Un=0,                                                         
  @EmprInt_Un=0,@VolInt_Un=0,@SpecInt_Un=0,@empOpening=0,@emprOpening=0,@EmpFeesOpen=0,                                                            
  @EmprFeesOpen=0,@DistrEmp=0,@DistrEmpr=0,@DistrAVC=0,@DistrSpec=0,@xempOpening=0,@xemprOpening=0,                                                       
  @EmpFeesOpen_Un=0, @EmprFeesOpen_Un=0,@EmpCont =0,@EmprCont =0,@EmpVol = 0, @EmprVol = 0,                                                            
  @xEmpCont = 0,@xEmprCont = 0,@xEmpVol = 0,@xEmprVol = 0,@EmpTransfer =0,@EmprTransfer =0,                                                            
  @empInt =0,@emprInt=0,@DistrEmpUn =0,@DistrEmprUn =0,@DistrAVCUn =0,@DistrSpecUn =0,@DistrEmpCUn =0,@DistrEmprCUn =0,@DistrAVCCUn =0,@DistrSpecCUn =0,                                                            
  @DistrEmp =0,@DistrEmpr =0,@DistrAVC =0,@DistrSpec =0,@DistrEmpC =0,@DistrEmprC =0,@DistrAVCC =0,                                                            
  @DistrEmpC =0, @DistrAVCC=0,@DistrEmpCUn=0,@DistrAVCCUn=0,@DistrEmprC=0,@DistrSpecC=0,@DistrEmprCUn=0,@DistrSpecCUn=0,                                                
  @Dept='',@idNumber=''                                                                 
                                                                  
  fetch next from benCsr into @schemeNo, @memberNo, @cEmpBal, @cEmprBal, @grandTotal, @fullName,@PayrollNo,@DoCalc,@ActiveStatus,@empAdminFees,@emprAdminFees,                                                                  
  @EmpInt_Op,@EmprInt_Op,@VolInt_Op,@SpecInt_Op,@Dob,@dje,@djpens,@doexit,@SponsorCode,@CompanyID,@Dept,@idNumber                                                                
end                                                                  
                                                                  
close benCsr                                                                  
deallocate benCsr                                                                    
update #benCalcComb set Astatus = 6 where Astatus is null                         
end /* SponsorCode > 0 */                                                                
/* END DEFERRED BENEFIT */                                                                  
                     
/*get dates, active status*/                                
                            
                            
/*                            
select * from memberOpeningBalances where schemeNo = 1307 and SchemeYear = 2009                            
and memberNo not in                            
(select MemberNo from #benCalcComb where grandtotal <> 0)                         
*/ 

select sum(cEmpBal + cEmprBal) from #benCalcComb 
select sum(EmpCont + EmpVolCont + EmprCont + EmprVolCont + Transfer + LockedIn) from MemberOpeningBalances
where schemenO = @SchemeNo and ProvOrFinal = 0

/*                          
if @Mining = 0                           
   select * from #benCalcComb where grandtotal <> 0 order by Astatus,MemberNo                       
else                      
   select * from #benCalcComb where grandtotal <> 0 order by Astatus,SponsorName,MemberNo 
*/                                                            
end                                           
else if @RepMode = 10                                          
begin                                          
    Exec  [dbo].[repMemberBalances_Deleted] @SCHEMENO,@Proc_Date                                           
end


             
              
SET NOCOUNT OFF
go

