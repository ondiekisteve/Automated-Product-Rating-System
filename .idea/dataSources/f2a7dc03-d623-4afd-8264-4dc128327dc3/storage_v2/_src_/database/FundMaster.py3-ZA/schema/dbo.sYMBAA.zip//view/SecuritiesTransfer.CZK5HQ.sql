CREATE VIEW [dbo].[SecuritiesTransfer]
as
Select i.SchemeNo,i.TransferFrom,i.TransferDate,i.MarketValue,i.Cost,i.NoOfUnits,i.PcntTransfer,
       i.fundManager,im.ManagerName
from InvestmentsTransfer i
     inner Join InvestmentManagers im on i.schemeNo = im.SchemeNo and i.FundManager = im.simCode
go

