CREATE FUNCTION [dbo].[fn_Share_Split](@SCHEMENO Int,@EquityNo Int)
RETURNS table
AS
RETURN (
        select *,sharesHeld * splitRatio as NoOfShares,
        (sharesHeld * splitRatio)* PricePerShare as MarketValue
        from TBL_Equity_Split where schemeNo = @schemeNo and EquityNo = @EquityNo
       )
go

