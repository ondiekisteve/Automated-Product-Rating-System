/*            
   Modifications            
   Added Original Cost            
*/            
CREATE PROCEDURE [dbo].[DefineAsset]            
@SCHEMENO Int,            
@AssetNo Int,            
@AssetName varchar(100),            
@AssetDesc varchar(100),            
@AssetCost float,            
@AssetDate Datetime,            
@AssetRefNo Varchar(50),            
@OriginalCost float,            
@AddEdit Int,            
@WorkInProgress Int,          
@ClassCode Int,           
@SerialNo varchar(20),        
@ChequeNo varchar(20),    
@InvoiceNo varchar(20),        
@CreditorCode integer,
@AccumDep float         
--with Encryption            
as            
  
          
            
if @AddEdit = 0            
   begin            
       select @AssetNo = Max(AssetNo) from Assets where SchemeNo = @SchemeNo            
            
       if @AssetNo is null select @AssetNo = 0            
            
        Select @AssetNo = @AssetNo + 1            
            
            
      if not Exists (Select * from Assets where AssetRefNo = @AssetRefNo and SchemeNo = @schemeNo)            
         begin            
               
         insert into Assets (schemeNo,AssetNo,AssetClass,AssetMode,AssetName,AssetDesc,AssetCost,AssetDate,            
                             Posted,PostedToGl,OriginalCost,AssetRefNo,WorkInProgress,ClassCode)            
              Values(@schemeNo,@AssetNo,1,0,@AssetName,@AssetDesc,@AssetCost,@AssetDate,1,0,@OriginalCost,@AssetRefNo,            
                     @WorkInProgress,@ClassCode) 

         if @AccumDep > 0
            insert into Depreciation(schemeNo,PropertyCode,ValueDate,Factor,Value, DepType,DepValue,AssetClass,DepCode,Posted,PostedToGl)              
                           Values(@SchemeNo,@AssetNo,@AssetDate,0,@AccumDep,0,@AccumDep,@ClassCode,0,1,1)
        end  
                  
    end            
else if @AddEdit = 1            
    begin            
        update Assets set AssetName = @AssetName,AssetDesc = @AssetDesc,AssetCost = @AssetCost,            
                          AssetDate = @AssetDate,OriginalCost = @OriginalCost,AssetRefNo = @AssetRefNo,            
                          WorkInProgress = @WorkInProgress,ClassCode = @ClassCode       
                                      
        where schemeNo = @schemeNo and AssetNo = @AssetNo            
            
    end
go

