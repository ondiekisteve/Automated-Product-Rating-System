CREATE FUNCTION [dbo].[fn_Rep_Inv_Class]()
returns @tbl_var table(Rep_Inv_Class int not null primary key,
                       Rep_Inv_Class_Desc varchar(100) not null unique
                       )
as
 begin
  insert into @tbl_var values(1, 'Property Fund')
  insert into @tbl_var values(2, 'Local Equity Fund')
  insert into @tbl_var values(4, 'Local Bond Fund')
  insert into @tbl_var values(5, 'Local Fixed Interest Fund')
  insert into @tbl_var values(10, 'Offshore Fixed Interest Fund')
  insert into @tbl_var values(11, 'Offshore Equity Fund')
  insert into @tbl_var values(8, 'Cash Fund')
  return
 end
go

