CREATE PROCEDURE [dbo].[actualExits]
--with Encryption
as
select * from ReasonForExit
where (ReasonCode > 1) and (ReasonCode <> 7)
ORDER BY ReasonDesc
go

