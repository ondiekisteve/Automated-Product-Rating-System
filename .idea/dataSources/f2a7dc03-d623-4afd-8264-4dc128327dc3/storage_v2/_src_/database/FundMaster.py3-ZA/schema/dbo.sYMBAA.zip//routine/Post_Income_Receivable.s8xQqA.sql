CREATE PROCEDURE [dbo].[Post_Income_Receivable]                                                                                     
@schemeNo int,                                         
@InvestCode int,                                                                               
@TransDate Datetime,                                                                                      
@TransMode Int, /* 1 - Certify,2-Authorize,3-Post,4-Rollback */                                        
@UserName varchar(60)                                                                                      
--with Encryption                                                                                      
as                                                                                      
                                                                                   
Declare @Withholding float,@Medical float,@WithholdingTax float,@MedicalLevy float,                                                            
@CreditAcc Varchar(30),@DebitAcc varchar(30),@PayMonth Int,@PayYear Int,@MaxTransNo Int,@Tax float,@BatchNo Int,                                                          
@MedLevyDebitAcc varchar(30),@TaxCreditAcc varchar(30),@WithTaxDebitAcc varchar(30),@CStatus smallInt,@CurrCode Int,                                                  
@MedLevyCreditAcc varchar(30),@AccruedDisc Decimal(20,6),@sDate varchar(20),@Income Decimal(20,6),@BondName varchar(200),                                        
@dCurrCode int,@CurrRate decimal(20,6),@SecType int,@DrDiscAcc varchar(30),@CrDiscAcc varchar(30),@CapRepayment float,                        
@InvName varchar(120),@IncomePrev Decimal(20,6),@WithholdingPrev float,                  
@MedicalPrev float,@AccruedDiscPrev Decimal(20,6),@CapRepaymentPrev float,@InvCode Int                                     
                                      
select @SecType = 0                                       
                                        
Exec DateToStr @TransDate,@sDate out                                                    
                                        
if Exists (select SCHEMENO from TBL_INVEST_RECEIVABLE where SchemeNo = @schemeNo and InvestCode = @InvestCode                                        
and TransDate = @TransDate and Status = 4)                                        
BEGIN                                        
   raiserror('The Income receivable as at %s has already been posted to the General Ledger',16,1,@sDate)                                        
   return                                        
END                                        
else                                        
BEGIN                                        
                                                    
select @dCurrCode = CurrCode from Scheme where schemeCode = @schemeNo                                                        
                                                    
Exec Proc_Check_Periods @schemeNo,@TransDate,@CStatus Out                                                        
                                                        
if @CStatus = 1                                                        
begin                                                        
  raiserror('The Accounting Period for the Transaction does not Exist',16,1)                                                        
  return                                                      
end                                                        
else if @CStatus = 2                                                        
begin                                                        
  raiserror('The Accounting Period for the Transaction has already been closed',16,1)                                                        
  return                                                        
end                                                        
else if @CStatus = 3                                                        
begin                                               
  raiserror('The Fiscal Year for the Transaction has already been closed',16,1)                                                        
  return                                                     
end            
else                                                        
begin                        
                                        
  if @TransMode = 1                                         
     begin                                        
       Update TBL_INVEST_RECEIVABLE set Status = @TransMode where SchemeNo = @schemeNo and InvestCode = @InvestCode                                        
       and TransDate = @TransDate                                
     end                                        
  else if @TransMode = 2                                        
     begin                                    
       Update TBL_INVEST_RECEIVABLE set Status = @TransMode where SchemeNo = @schemeNo and InvestCode = @InvestCode                                        
       and TransDate = @TransDate                                        
     end                                        
  else if @TransMode = 3                                        
     begin                              
        select @TaxCreditAcc = TaxCreditAcc,@MedLevyCreditAcc = MedLevyCreditAcc                               
        from Pension_Setup where schemeNo = @schemeNo                              
                                     
        select @MedLevyDebitAcc = MedLevyAcc,@WithTaxDebitAcc= WithTaxAcc                                                  
        from TBL_Invest_TaxRates where schemeNo = @schemeNo and InvestCode = @InvestCode                              
                                                          
        select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeNo                                       
                                                            
        if @BatchNo is null select @BatchNo = 0                                                            
        select @BatchNo = @BatchNo + 1                                                              
                                                              
        select @PayMonth = DatePart(Month,@TransDate),@PayYear = DatePart(Year,@TransDate)                                      
                                
                                                              
        select @MaxTransNo = Max(glTransNo) from SchemeGeneralLedger where schemeCode = @schemeNo                                         
        if @MaxTransNo is null select @MaxTransNo = 0                                                              
        select @MaxTransNo = @MaxTransNo + 1                                        
                                                                
                                                                                                                                               
if @InvestCode = 4  /* Treasury Bills and Bonds */                                                                   
   begin                                                                                                   
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.ExRate,t.CapRepayment,p.CreditAcc,p.DebitAcc,@dCurrCode,                                      
    p.SecurityType,p.AccDiscountAcc,p.DiscountAcc                                                             
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join GovernmentSecurities p on t.schemeNo = p.schemeNo and t.invCode = p.SecurityNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                                                     
   end                                                          
else if @InvestCode = 7  /* Commercial Paper */                                                                   
   begin                                           
    Declare PostCsr Cursor for select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.Exrate,t.CapRepayment,p.CreditAcc,p.DebitAcc,p.CurrCode,            
    0,'',''                                                              
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join CommercialPaper p on t.schemeNo = p.schemeNo and t.invCode = p.PaperNo                                            
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                                        
  end                                                                          
else if @InvestCode = 5 /* Cash and Deposits */                                                                 
  begin                                                        
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.Exrate,t.CapRepayment,p.CreditAcc,p.DebitAcc,p.CurrCode,                                      
    0,'',''                                                              
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join CashDeposits p on t.schemeNo = p.schemeNo and t.invCode = p.DepositNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                         
  end                            
else if @InvestCode = 9  /* Long Term Loans */                                                                   
   begin                                                                                                   
    Declare PostCsr Cursor for                                                         
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.ExRate,t.CapRepayment,p.InterestAcc,p.InterestRecAcc,p.CurrCode,                                      
    0,p.CapRepayRecAcc,p.CapRepayProvAcc                                                             
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join TBL_LOANS p on t.schemeNo = p.schemeNo and t.invCode = p.MortgageNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                                                                                     
   end                       
else if @InvestCode = 2 /* Preferential Shares */                                                                  
  begin                                                        
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.Exrate,t.CapRepayment,p.CreditAcc,p.DebitAcc,p.CurrCode,                                      
    0,'',''                                                              
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                            
        inner join Equity p on t.schemeNo = p.schemeNo and t.invCode = p.EquityNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                         
  end       
else if @InvestCode = 12 /* Endowments - Premium Ammortization */                                               
  begin                                                        
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.Exrate,t.CapRepayment,      
    p.AssetAcc,p.PremiumAcc,p.CurrCode,                                      
    0,'',''                                                              
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join TBL_Endowments p on t.schemeNo = p.schemeNo and t.invCode = p.OffshoreNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                         
  end                                                                 
                                                              
Open PostCsr                                                              
Fetch from PostCsr Into @BondName,@InvCode,@Income,@Withholding,@Medical,@AccruedDisc,@CurrRate,@CapRepayment,      
                        @CreditAcc,@DebitAcc,@CurrCode,                                      
                        @SecType,@DrDiscAcc,@CrDiscAcc                                                              
while @@fetch_Status = 0                                  
begin                  
         
   if @InvestCode  = 4  
      begin  
          if len(ltrim(rtrim(@DrDiscAcc))) = 0  
             select @DrDiscAcc = AssetAcc from GovernmentSecurities where SchemeNo = @schemeNo and SecurityNo = @InvCode    
      end  
                  
   /* RollOver Non-Functional Currency denominated accruals for prior periods */         
        
   /*                 
   if @CurrCode <> @dCurrCode                  
      begin                  
         Exec Post_Income_Rollback_USD @schemeNo,@InvCode,@InvestCode,@TransDate,                  
                                       @IncomePrev out,@WithholdingPrev out,                  
                                       @MedicalPrev out,@AccruedDiscPrev out,                  
      @CapRepaymentPrev out                        
      end                  
   else                  
      begin        
   */                  
        select @IncomePrev = 0,@WithholdingPrev=0,                  
               @MedicalPrev = 0,@AccruedDiscPrev=0,                  
               @CapRepaymentPrev = 0                  
    --  end                  
                    
   IF @CapRepayment is null select @CapRepayment = 0                    
                  
   select @Income = @Income + @IncomePrev,@Withholding= @Withholding + @WithholdingPrev,                  
          @Medical = @Medical + @Medicalprev,@CapRepayment = @CapRepayment + @CapRepaymentPrev                  
                  
   /* Update TBL_INVEST_RECEIVABLE with total accrued Income for prior periods*/                  
   Update TBL_INVEST_RECEIVABLE set IncomePrev = @Income,WithholdingPrev = @Withholding,                  
   MedicalPrev = @Medical,CapRepaymentPrev = @CapRepayment                   
   where SchemeNo = @schemeNo and InvestCode = @InvestCode                                        
   and TransDate = @TransDate and InvCode = @InvCode                  
                          
   select @InvName = @BondName                        
                                           
   Exec Proc_Get_Forex_Rate @schemeNo,@CurrCode,@TransDate,@CurrRate Out                   
                                         
                                                                  
   select @Tax = @Medical + @Withholding                                                  
         
   if @InvestCode = 12      
      select @BondName = 'Endowment Premium Ammortisation for '+ @InvName      
   else                                                           
      select @BondName = 'Accrued Interest for '+ @InvName                                                              
                                    
   Exec PostLedgerCredits_RecPay @SchemeNo,@CreditAcc,0,@Income,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
   @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                
                                                            
   Exec PostLedgerDebits_RecPay @SchemeNo,@DebitAcc,0,@Income,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
   @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                                               
                                               
   IF @Tax > 0                                                          
   BEGIN                                                           
   IF @Medical > 0                                                   
      begin                                                    
      Exec PostLedgerCredits_RecPay @SchemeNo,@MedLevyCreditAcc,0,@Medical,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
      @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                                   
                                                        
      Exec PostLedgerDebits_RecPay @SchemeNo,@MedLevyDebitAcc,0,@Medical,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
      @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                            
      end                                  
                                                              
   IF @Withholding > 0                                                   
      begin                  
      Exec PostLedgerCredits_RecPay @SchemeNo,@TaxCreditAcc,0,@Withholding,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
      @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                                   
                                         
      Exec PostLedgerDebits_RecPay @SchemeNo,@WithTaxDebitAcc,0,@Withholding,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
      @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                                    
      end                                                          
   END                                  
                                      
                                      
   if ((@InvestCode = 4) and (@SecType = 28))                                      
      begin                                      
         if @AccruedDisc <> 0                                      
            begin                                      
                                     
              Exec PostLedgerCredits_RecPay @SchemeNo,@CrDiscAcc,0,@AccruedDisc,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
              @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                                   
                                                                  
              Exec PostLedgerDebits_RecPay @SchemeNo,@DrDiscAcc,0,@AccruedDisc,@PayMonth,@PayYear,@BondName,0,@TransDate,          
              @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                                    
                                      
            end                                      
      end                           
                          
   if ((@InvestCode = 9) and (@CapRepayment > 0))                          
      begin                           
                          
        select @BondName = 'Accrued Capital Repayment for '+ @InvName                                                   
                                                          
        Exec PostLedgerCredits_RecPay @SchemeNo,@CrDiscAcc,0,@CapRepayment,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
        @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                                
                                                              
        Exec PostLedgerDebits_RecPay @SchemeNo,@DrDiscAcc,0,@CapRepayment,@PayMonth,@PayYear,@BondName,0,@TransDate,                                                                
        @MaxTransNo,@BatchNo,@CurrCode,@CurrRate,0,1000,@InvestCode                          
      end                                     
                                                                                
   select @BondName='',@Income=0,@Withholding=0,@Medical=0,@MaxTransNo = @MaxTransNo + 1,@CreditAcc='',@DebitAcc='',                                                              
   @Tax = 0,@CurrCode=0,@AccruedDisc=0,@CurrRate = 1.0000,@SecType=0,@DrDiscAcc='',@CrDiscAcc='',@InvCode = 0                                        
                                                              
   Fetch next from PostCsr Into @BondName,@InvCode,@Income,@Withholding,@Medical,@AccruedDisc,@CurrRate,@CapRepayment,@CreditAcc,@DebitAcc,@CurrCode,                                      
                                @SecType,@DrDiscAcc,@CrDiscAcc                                                               
end                                                              
Close PostCsr                                                              
Deallocate PostCsr                                                                       
                                        
                                        
   Update TBL_INVEST_RECEIVABLE set Status = @TransMode,PostedBy = @UserName,DatePosted = getDate() where SchemeNo = @schemeNo and InvestCode = @InvestCode                                        
   and TransDate = @TransDate                   
                                        
end                                        
else if @TransMode = 4 /* Rollback Transaction */                     
begin                                        
                     
   if @InvestCode = 4  /* Treasury Bills and Bonds */                                                                   
   begin                         
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.ExRate,t.CapRepayment,p.CreditAcc,p.DebitAcc,@dCurrCode,                                      
    p.SecurityType,p.AccDiscountAcc,p.DiscountAcc                                                             
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join GovernmentSecurities p on t.schemeNo = p.schemeNo and t.invCode = p.SecurityNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                                                     
   end                              
else if @InvestCode = 7  /* Commercial Paper */        
   begin                                                                                                                 
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.Exrate,t.CapRepayment,p.CreditAcc,p.DebitAcc,p.CurrCode,                                      
    0,'',''                                                              
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join CommercialPaper p on t.schemeNo = p.schemeNo and t.invCode = p.PaperNo                                            
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                                        
  end                                                                          
else if @InvestCode = 5 /* Cash and Deposits */                                                                 
  begin                                       
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.Exrate,t.CapRepayment,p.CreditAcc,p.DebitAcc,p.CurrCode,                                      
    0,'',''                                                              
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join CashDeposits p on t.schemeNo = p.schemeNo and t.invCode = p.DepositNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                         
  end                            
else if @InvestCode = 9  /* Long Term Loans */                                                                   
   begin                                                                                                   
    Declare PostCsr Cursor for                                                         
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.ExRate,t.CapRepayment,p.InterestAcc,p.InterestRecAcc,p.CurrCode,                                      
    0,p.CapRepayRecAcc,p.AssetAcc                                                             
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
    inner join TBL_LOANS p on t.schemeNo = p.schemeNo and t.invCode = p.MortgageNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                                                                                     
   end                       
else if @InvestCode = 2 /* Preferential Shares */                                        
  begin                                                        
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.Exrate,t.CapRepayment,p.CreditAcc,p.DebitAcc,p.CurrCode,                                      
    0,'',''                                                              
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join Equity p on t.schemeNo = p.schemeNo and t.invCode = p.EquityNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                         
  end      
else if @InvestCode = 12 /* Endowments - Premium Ammortization */                                                                  
  begin                                                        
    Declare PostCsr Cursor for                                                                                     
    select i.InvName,t.InvCode,t.Income,t.WithTax,t.MedLevy,t.Discount,t.Exrate,t.CapRepayment,      
    p.AssetAcc,p.PremiumAcc,p.CurrCode,                                      
    0,'',''                                                              
    from TBL_INVEST_RECEIVABLE t                                        
        inner join Investments i on t.schemeNo = i.schemeNo and t.invCode = i.invCode                                        
        inner join TBL_Endowments p on t.schemeNo = p.schemeNo and t.invCode = p.OffshoreNo                                        
    where t.schemeNo = @schemeNo and t.InvestCode = @InvestCode and t.TransDate = @TransDate                                         
  end                                                                 
                                                              
Open PostCsr                
Fetch from PostCsr Into @BondName,@InvCode,@Income,@Withholding,@Medical,@AccruedDisc,@CurrRate,@CapRepayment,@CreditAcc,@DebitAcc,@CurrCode,                                      
                        @SecType,@DrDiscAcc,@CrDiscAcc                                                              
while @@fetch_Status = 0                                                              
begin                         
   select @InvName = @BondName                        
                 
   if ((@InvestCode = 9) and (@CapRepayment > 0))              
      begin              
      select @BondName = 'Accrued Capital Repayment for '+ @InvName              
              
      select @BatchNo = Max(Batchno) from schemeGeneralLedger              
      where schemeCode = @schemeNo and glDate = @TransDate and Description = @BondName and AccountCode = @CrDiscAcc              
              
      end               
   else               
     begin              
      if @InvestCode = 12      
         select @BondName = 'Endowment Premium Ammortisation for '+ @InvName      
      else                                                           
         select @BondName = 'Accrued Interest for '+ @InvName                
                                       
      select @BatchNo = Max(Batchno) from schemeGeneralLedger              
      where schemeCode = @schemeNo and glDate = @TransDate and Description = @BondName and AccountCode = @CreditAcc               
              
    end              
              
   if @BatchNo is null select @BatchNo = 0              
              
   if @BatchNo > 0              
      begin              
         Update schemeGeneralLedger set Tran_Status  = -1             
         where schemeCode = @schemeNo and glDate = @TransDate and BatchNo = @BatchNo               
      end                                                              
                                                                                      
   select @BondName='',@Income=0,@Withholding=0,@Medical=0,@MaxTransNo = @MaxTransNo + 1,@CreditAcc='',@DebitAcc='',                                                              
   @Tax = 0,@CurrCode=0,@AccruedDisc=0,@CurrRate = 1.0000,@SecType=0,@DrDiscAcc='',@CrDiscAcc='',@InvCode = 0                                        
                                                              
   Fetch next from PostCsr Into @BondName,@InvCode,@Income,@Withholding,@Medical,@AccruedDisc,@CurrRate,@CapRepayment,@CreditAcc,@DebitAcc,@CurrCode,                                      
                                @SecType,@DrDiscAcc,@CrDiscAcc                                                               
end                    
Close PostCsr                                                              
Deallocate PostCsr              
                                
   Delete from TBL_INVEST_RECEIVABLE where SchemeNo = @schemeNo and InvestCode = @InvestCode                                        
   and TransDate = @TransDate                                            
end                                      
end                                                        
END
go

