CREATE PROCEDURE [dbo].[GetDebitTaxOnLumpsums]
@SCHEMENO Int,
@MemberNo int,
@DepType Int
--with Encryption
as

if object_id('tempdb..#DebitTaxOnLumpsums') is null

begin
create table #DebitTaxOnLumpsums
(
	[glcode] [int] IDENTITY(1,1) NOT NULL ,
	[DrDesc] [varchar](100) NOT NULL ,
	[Debit] [Decimal](12,2) not  NULL default 0.0,
        [Total] [Decimal](12,2) null default 0.0 
) 

ALTER TABLE #DebitTaxOnLumpsums WITH NOCHECK ADD 

            
	CONSTRAINT [PK_DebitTaxOnLumpsums] PRIMARY KEY  NONCLUSTERED 
	(
	  [glcode]      
	) 
end


declare @Desc varchar(50),@Debit decimal(20,2),@YaConversion Varchar(25),@Chapaa decimal(20,2)

if @DepType = 1
   begin  	     
      select @Debit = withholdingTax from 
      Benefits
      where  SchemeNo = @schemeNo and MemberNo = @MemberNo

      Select @Desc = Upper(sName)+', '+fName+' '+Onames +' - Tax on Withdrawal Benefit'
      from Members
      where SchemeNo = @SchemeNo and MemberNo = @MemberNo
   end
else if @DepType = 2
   begin
      select @Debit = wTaxPd from 
      Pensioner
      where  SchemeNo = @schemeNo and MemberNo = @MemberNo

      Select @Desc = Upper(sName)+', '+fName+' '+Onames +' - Tax on Retirement Benefit'
      from Members
      where SchemeNo = @SchemeNo and MemberNo = @MemberNo
   end
else if @DepType = 3
   begin
      select @Debit = withholdingTax from 
      Benefits
      where  SchemeNo = @schemeNo and MemberNo = @MemberNo

      Select @Desc = Upper(sName)+', '+fName+' '+Onames +' - Tax on Death Gratuity'
      from Members
      where SchemeNo = @SchemeNo and MemberNo = @MemberNo

   end

select @YaConversion = cast(@Debit as Varchar(25))
                     Exec RoundingYaFundMaster @SchemeNo,@YaConversion,@Chapaa out
                     select @Debit = @Chapaa
                     select @Chapaa = 0
      				 
insert into #DebitTaxOnLumpsums (drDesc,Debit)
                 Values(@Desc,@Debit)

update #DebitTaxOnLumpsums set total = @Debit
              
select *  from #DebitTaxOnLumpsums
go

