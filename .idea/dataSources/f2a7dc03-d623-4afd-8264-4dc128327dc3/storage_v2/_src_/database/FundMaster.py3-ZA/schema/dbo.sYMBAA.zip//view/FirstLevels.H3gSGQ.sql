CREATE VIEW [dbo].[FirstLevels]
as
Select LevelCode,LevelDesc from Levels
go

