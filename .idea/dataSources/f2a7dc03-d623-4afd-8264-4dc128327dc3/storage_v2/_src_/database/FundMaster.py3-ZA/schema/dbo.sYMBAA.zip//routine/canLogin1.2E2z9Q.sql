CREATE PROCEDURE [dbo].[canLogin1]
--with Encryption
as

declare @thisMinute int
declare @grpName Varchar(120)
declare @userName Varchar(120)

select @thisMinute = (datepart(hh, getdate()) * 60) + datepart(mi, getdate())
select @userName = user


exec getUserGroup @userName, @grpName out

select distinct groupName from disallowedTimes
where (groupName = @grpName) and ((disStart <= @thisMinute) and (disEnd >= @thisMinute))
go

