CREATE FUNCTION [dbo].[fn_Rep_Inv_Class_Det]()  
returns @tbl_var table(DetCode int identity(1,1) primary key,
                       Rep_Inv_Class int not null,  
                       Rep_Inv_Class_Det int not null,  
                       Rep_Inv_Class_Det_Desc varchar(100) not null  
                       )  
as  
 begin  
  insert into @tbl_var values(1, 1,'Residential')  
  insert into @tbl_var values(1, 2,'Commercial')  
  insert into @tbl_var values(1, 3,'Agricultural')  
  insert into @tbl_var values(1, 4,'Undeveloped Land') 
  
  insert into @tbl_var values(2, 1,'Listed Equity')  
  insert into @tbl_var values(2, 2,'Private Equity')  
  insert into @tbl_var values(2, 3,'Quoted Equity')  
  insert into @tbl_var values(2, 4,'Collective Investment Schemes')  
  
  insert into @tbl_var values(4, 1,'Government Bonds')  
  insert into @tbl_var values(4, 2,'Corporate Bonds')  
  insert into @tbl_var values(4, 3,'Long Term Loans')  
 
  insert into @tbl_var values(5, 1,'Fixed Term Deposits')  
  insert into @tbl_var values(5, 2,'Repos') 
  insert into @tbl_var values(5, 3,'Negotiable Certificate of Deposits')  
  insert into @tbl_var values(5, 4,'Commercial Paper')  
  insert into @tbl_var values(5, 5,'Treasury Bills')  
    
  insert into @tbl_var values(8, 1,'Cash')  
  insert into @tbl_var values(8, 2,'Call Deposits') 

  insert into @tbl_var values(11, 1,'Listed Equity')  
  insert into @tbl_var values(11, 2,'Collective Investment Schemes') 

  insert into @tbl_var values(10, 1,'Collective Investment Schemes')  
  insert into @tbl_var values(10, 2,'Bank Deposits') 
  insert into @tbl_var values(10, 3,'Offshore Government Bonds')  
  insert into @tbl_var values(10, 4,'Offshore Treasury Bills') 
  insert into @tbl_var values(10, 5,'Endowments') 
 
  return  
 end
go

