CREATE PROCEDURE [dbo].[InsertPostTown]
@Posta varchar(50)
--with Encryption
as

declare @PostCode int

Select @PostCode = Max(PostCode) from Posta

Select @PostCode = @PostCode + 1

if Exists(Select * from Posta where PostOffice = @Posta)
   begin
      raiserror('%s already Exists',16,1,@Posta)
      return
   end
else
 Insert Into Posta(PostCode,PostOffice)
            Values(@PostCode,@Posta)
go

