CREATE Procedure Rep_BTF_Balances /* Rep_BTF_Balances 1222,'Dec 31,2013' */    
@schemeNo Int,    
@Proc_Date datetime    
--with Encryption    
as    
declare @AcctPeriod Int,@StartDate datetime,@fullname varchar(120),@Balance float,    
@schemeCode Int,@MemberNo int,@DepCode Int,@OpenBal float,@Payments float,@Interest float    
    
if object_id('tempdb..#BTF_Balances') is null                                                                                  
                                                                                  
begin                                                                                  
create table #BTF_Balances                                                                                  
(       [glCode][Int] identity (1,1) Primary Key,                                                                                  
        [SchemeNo][Int],    
        [MemberNo][Int],    
        [DepCode][Int],    
        [FullName][varchar](120),    
        [StartDate][datetime],    
        [OpenBal][float],    
        [Payments][float],    
        [Interest][float],    
        [ClosingBal][float],  
        [Proc_Date][Datetime]                                             
                                                                                                                                                             
)                                                                                   
end     
    
    
declare dcsr cursor for      
select p.SchemeNo,p.MemberNo, p.DependantCode,p.Balance,d.sname+', '+d.fname+' '+oname as fullname       
from TBL_BTF_Balances p      
     inner join Dependants d on p.SchemeNo = d.SchemeNo  and p.MemberNo = d.MemberNo       
     and p.DependantCode = d.DependantCode and d.PayLumpInBTF = 1      
where p.AcctPeriod = dbo.fn_AcctPeriod(p.SchemeNo,@Proc_Date)    
       
Open dcsr      
fetch from dcsr into @SchemeCode,@MemberNo,@DepCode,@Balance,@fullName     
while @@FETCH_STATUS  = 0      
begin    
   select @AcctPeriod = AcctPeriod,@StartDate = StartDate     
   from schemeYears     
   where schemeNo = @SchemeCode and startDate <= @Proc_Date    
   and endDate >= @Proc_Date    
       
   if Exists(select DependantCode from TBL_BTF_Balances where SchemeNo = @SchemeCode     
             and MemberNo = @MemberNo and DependantCode = @DepCode and AcctPeriod  = @AcctPeriod - 1)    
      begin    
      select @OpenBal = Balance from TBL_BTF_Balances where SchemeNo = @SchemeCode     
             and MemberNo = @MemberNo and DependantCode = @DepCode and AcctPeriod  = @AcctPeriod - 1     
                 
      end           
   ELSE    
      begin    
      select @OpenBal = Amount from DependantPayment where SchemeNo = @SchemeCode     
             and MemberNo = @MemberNo and DependantCode = @DepCode    
                 
      select @StartDate = DoCalc from DeathClaim where SchemeNo = @schemeCode and MemberNo = @MemberNo           
                 
      end    
          
      select @Payments = sum(Amount) from DependantPaymentDet where SchemeNo = @SchemeCode     
             and MemberNo = @MemberNo and DependantCode = @DepCode and DatePaid >= @StartDate and DatePaid <= @Proc_Date    
                 
      if @OpenBal is null select @OpenBal = 0    
      if @Payments is null select @Payments = 0    
          
      select @Interest = @Balance - (@OpenBal - @Payments)           
                   
      Insert into #BTF_Balances(SchemeNo,MemberNo,DepCode,FullName,StartDate,OpenBal,Payments,Interest,ClosingBal,Proc_Date)    
                       Values(@SchemeCode,@MemberNo,@DepCode,@fullname,@StartDate,@OpenBal,@Payments,@Interest,@Balance,@Proc_Date)    
     
    
   select @SchemeCode=0,@MemberNo=0,@DepCode=0,@Balance=0,@fullName=''      
   fetch next from dcsr into @SchemeCode,@MemberNo,@DepCode,@Balance,@fullName      
end      
close dcsr      
deallocate dcsr    
    
select * from #BTF_Balances order by DepCode

go

