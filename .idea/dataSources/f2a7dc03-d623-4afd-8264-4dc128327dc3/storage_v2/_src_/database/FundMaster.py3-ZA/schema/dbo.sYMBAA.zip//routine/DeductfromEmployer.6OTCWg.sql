CREATE PROCEDURE [dbo].[DeductfromEmployer]
@SCHEMENO Int,
@curMonth int,
@curYear int
--with Encryption
as

if object_id('tempdb..#Deduct') is null


begin
create table #Deduct
(
	[SchemeNo] [varchar] (15) NOT NULL ,
	[MemberNo] [int] NOT NULL ,
	[Empr] [float] NOT NULL ,
	[ExEmpr] [float] NULL, 
        [Deduct] [float]  NULL,
        [NewEmpr][float] null,
        [NewExEmpr][float] null, 
        [Distr][float] null,
        [Contr][float] null
                  
) 

ALTER TABLE #Deduct WITH NOCHECK ADD 

            
	CONSTRAINT [PK_Deduct] PRIMARY KEY  NONCLUSTERED 
	(
		[SchemeNo],
		[MemberNo]      
	) 
end

declare @MemberNo int
declare @Empr float
declare @ExEmpr float
declare @Deduct float
declare @DistrAmount float
Declare @TotEmpr float
Declare @Contr float
Declare @NewEmpr float
declare @NewExEmpr float
Declare @TempCont float
Declare @Special float
declare @ExSpecial float

exec DistributeDeductions @schemeNo, @curMonth, @CurYear, @DistrAmount out
exec GetTotalEmployerContributions @schemeNo, @curMonth, @CurYear, @Contr out


declare ContCsr cursor for
select MemberNo, EmprCont, ExcessEmprcont, SpecialContr , ExcessSPecial
from contributionssummary where schemeNo = @SchemeNo and contrMonth = @curMonth and ContrYear = @CurYear
  and EmprCont > 0
order by MemberNo

Open ContCsr

Fetch from contCsr into @MemberNo, @Empr, @ExEmpr,@Special, @Exspecial

while @@fetch_status = 0
begin
   Select @TotEmpr = 0

   Select @TotEmpr = @Empr + @ExEmpr +@Special + @ExSpecial

   Select @Deduct = (@TotEmpr/@Contr) * @DistrAmount
   
   if @ExEmpr > 0
      begin
          if @ExEmpr > @Deduct
             begin
                Select @NewExEmpr = @ExEmpr - @Deduct
                Select @NewEmpr = @Empr
             end
          else
             begin
                Select @NewExEmpr = 0
                Select @TempCont = @Deduct - @ExEmpr
                Select @NewEmpr = @Empr - @TempCont
             end
      end
   else
      Begin
         Select @NewEmpr = @Empr - @Deduct
         Select @NewExEmpr = 0
      end

   select @MemberNo

   insert into #Deduct (schemeNo, MemberNo, Empr, ExEmpr, Distr, Contr, Deduct,NewEmpr, NewExEmpr)
                values(@schemeNo, @MemberNo, @Empr, @ExEmpr, @DistrAmount, @Contr, @Deduct, @NewEmpr, @NewExEmpr)
   
  
 
   Update Contributionssummary set EmprCont = @NewEmpr, ExcessEmprCont = @NewExEmpr
   where SchemeNo = @schemeNo and MemberNo = @MemberNo and ContrMonth = @CurMonth 
   and ContrYear = @CurYear
   
   Update UnRegisteredContributionssummary set ExcessEmprCont = @NewExEmpr
   where SchemeNo = @schemeNo and MemberNo = @MemberNo and ContrMonth = @CurMonth 
   and ContrYear = @CurYear

   Select @NewEmpr =0
   Select @TempCont =0
   Select @NewExEmpr = 0
   Select @Deduct = 0
   Select @Special = 0
   Select @ExSpecial = 0
Fetch next from contCsr into @MemberNo, @Empr, @ExEmpr,@Special, @Exspecial
end

Close ContCsr
Deallocate ContCsr

select @Deduct = sum(deduct) from #Deduct
--select @Deduct
Select * from #Deduct
go

