CREATE PROCEDURE [dbo].[GetMaxBankDate]
@SCHEMENO Int,
@BankCode varchar(15)
--with Encryption
as
select Max(TransDate) as BankDate from BankStatement where
SchemeNo = @schemeNo and BankCode = @BankCode
go

