








CREATE VIEW dbo.ViewPeriods
--with encryption
AS
SELECT DISTINCT period, insurecode
FROM annuityrates


go

