CREATE TRIGGER [dbo].[Trg_Invest_Curr_Reval] ON [dbo].[TBL_Invest_Curr_Reval] 
FOR INSERT
AS

declare @SchemeNo Int,@InvCode Int,@PayCode Int,@UserName varchar(60),@TransMode smallInt

select @UserName = user

select @schemeNo = SchemeNo,@PayCode = PayCode,@InvCode = InvCode,@TransMode = TransMode from Inserted

if @TransMode = 11 /* Offshore */
    Exec Proc_Auto_Insert_InvPosting @schemeNo,@InvCode,@TransMode,174,@PayCode,2,@UserName
else if @TransMode = 10 /* Offshore */
    Exec Proc_Auto_Insert_InvPosting @schemeNo,@InvCode,@TransMode,184,@PayCode,2,@UserName
else if @TransMode = 9 /* Loans */
    Exec Proc_Auto_Insert_InvPosting @schemeNo,@InvCode,@TransMode,216,@PayCode,2,@UserName
else if @TransMode = 12 /* Endowments */
    Exec Proc_Auto_Insert_InvPosting @schemeNo,@InvCode,@TransMode,226,@PayCode,2,@UserName
else if @TransMode = 5 /*Term deposits */
    Exec Proc_Auto_Insert_InvPosting @schemeNo,@InvCode,@TransMode,154,@PayCode,2,@UserName
else if @TransMode = 8 /* Demand Deposits */
    Exec Proc_Auto_Insert_InvPosting @schemeNo,@InvCode,@TransMode,166,@PayCode,2,@UserName
else if @TransMode = 7 /* Commercial Paper */
    Exec Proc_Auto_Insert_InvPosting @schemeNo,@InvCode,@TransMode,144,@PayCode,2,@UserName
else if @TransMode = 2 /* Preferential Shares */
    Exec Proc_Auto_Insert_InvPosting @schemeNo,@InvCode,@TransMode,128,@PayCode,2,@UserName
go

