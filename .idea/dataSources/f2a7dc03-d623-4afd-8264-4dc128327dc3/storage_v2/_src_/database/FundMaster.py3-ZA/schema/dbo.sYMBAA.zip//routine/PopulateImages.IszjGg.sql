CREATE PROCEDURE [dbo].[PopulateImages]
@SCHEMENO Int,
@AttachmentNo Int,
@PageNo Int
--with Encryption
as

Select Attachment from
AttachmentPages
where SchemeNo = @schemeNo
and AttachmentNo = @AttachmentNo
and PageNo = @PageNo
go

