CREATE PROCEDURE [dbo].[Proc_Del_Beneficiary]
@SCHEMENO Int,
@MemberNo Int,
@DependantCode Int

as

if Exists(Select * from MEMBeneficiary where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DependantCode)
   begin
     Delete from PensionPayrollBen where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DependantCode

     Delete from MemBeneficiary where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DependantCode

     Delete from Dependants where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DependantCode
   end
else if Exists(Select * from PenBeneficiary where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DependantCode)
   begin
     Delete from PensionPayrollBen where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DependantCode

     Delete from PenBeneficiary where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DependantCode

     Delete from Dependants where schemeNo = @schemeNo and MemberNo = @MemberNo and DependantCode = @DependantCode
   end
go

