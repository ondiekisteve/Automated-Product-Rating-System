CREATE FUNCTION [dbo].[fn_Company_Type] ()            
returns @tbl_var table(CompTypeId int primary key,              
                       CompanyType varchar(100)        
                       )              
as              
 begin              
          
  insert into @tbl_var(CompTypeId,CompanyType)        
              Values(0,'Public Listed Company')       
        
  insert into @tbl_var(CompTypeId,CompanyType)        
              Values(1,'Public Non-Listed Company')       
          
  insert into @tbl_var(CompTypeId,CompanyType)        
              Values(2,'Private Company') 

  insert into @tbl_var(CompTypeId,CompanyType)        
              Values(3,'Regulated Financial Institution')      
         
  return   
        
 end
go

