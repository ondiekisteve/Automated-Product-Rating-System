CREATE PROCEDURE [dbo].[Proc_Fees_Update]  
@schemeNo Int,  
@Mwaka Int  
as  
  
declare @Description varchar(200),@FullName varchar(100),@SponsorCode Int,@DeferredPaid smallInt,@MemberNo Int,  
@CalcDate datetime,@EmpFees float,@EmprFees float,@VolFees float,@SpecialFees float,@EmpFees_Un float,            
       @EmprFees_Un float,@VolFees_Un float,@SpecialFees_Un float,@SDate datetime,@eDate datetime,  
@AdminFees float,@InitDescription varchar(200),@SchemeMode int,@AcctPeriod int,@YearClosed smallInt  
  
select @SchemeMode = SchemeMode from scheme where schemeCode = @schemeNo  
if @SchemeMode is null select @SchemeMode = 0  
  
Exec GetFirstDate 1,@Mwaka,@sDate out  
Exec GetLastDate 12,@Mwaka,@eDate out

select @AcctPeriod = AcctPeriod,@YearClosed = YearClosed from schemeyears 
where schemeNo = @schemeNo and Startdate <= @sdate and EndDate >= @sDATE 

UPDATE SchemeYears set YearClosed = 0 where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod
  
declare xCsr cursor for   
select MemberNo,InitialDoCalc from Members  
where schemeNo = @schemeNo and ActiveStatus = 6  
and InitialDocalc >= @sDate and InitialDoCalc <= @eDate  
  
open xcsr  
fetch from xcsr into @MemberNo,@CalcDate  
while @@fetch_status = 0  
begin  
    select @Description = 'Administration Fees for ',@FullName = Upper(sName)+', '+fName+' '+Onames,  
    @InitDescription = 'Administration Fees for '+Upper(sName)+', '+fName+' '+Onames,  
    @SponsorCode = SponsorCode              
    from Members where SchemeNo = @SchemeNo and MemberNo = @memberNo  
  
    if @SchemeMode  = 0 select @SponsorCode = 0   
  
  
    Exec Proc_Calculate_Fees @schemeNo,@MemberNo,@CalcDate,            
       @EmpFees Out,@EmprFees Out,@VolFees Out,@SpecialFees Out,@EmpFees_Un Out,            
       @EmprFees_Un Out,@VolFees_Un Out,@SpecialFees_Un Out  
  
        
    select @AdminFees = @EmpFees + @VolFees,@Description = 'Administration fees for Employee for '+@fullName    
              
              
   if @AdminFees > 0              
      BEGIN    
        Delete from Surplus where SurplusDate = @CalcDate and SurplusDesc = @InitDescription              
        AND SchemeNo = @schemeNo  
            
        Delete from Surplus where SurplusDate = @CalcDate and SurplusDesc = @Description              
        AND SchemeNo = @schemeNo  
  
                        
        Exec InsertSurplus @SchemeNo,@CalcDate,@Description,@AdminFees,0,0,0,0,0,1,@SponsorCode              
                 
      END              
              
      select @AdminFees = 0              
             
      select @AdminFees = @EmpFees_Un + @VolFees_Un,@Description = 'Administration fees for Employee for '+@fullName    
                   
           
    if @AdminFees > 0              
       begin   
         Delete from Surplus_UnReg where SurplusDate = @CalcDate and SurplusDesc = @InitDescription              
         AND SchemeNo = @schemeNo  
             
         Delete from Surplus_UnReg where SurplusDate = @CalcDate and SurplusDesc = @Description              
         AND SchemeNo = @schemeNo              
              
         Exec InsertSurplus @SchemeNo,@CalcDate,@Description,@AdminFees,0,0,0,0,1,1,@SponsorCode              
       end    
  
   select @MemberNo=0,@CalcDate=getdate(),@Description = '',@FullName = '',@AdminFees = 0,  
   @EmpFees =0,@EmprFees =0,@VolFees =0,@SpecialFees=0,@EmpFees_Un =0,            
       @EmprFees_Un =0,@VolFees_Un =0,@SpecialFees_Un=0  
   fetch next from xcsr into @MemberNo,@CalcDate  
end  
Close xcsr  
Deallocate xCsr    
  
/* Deferred Employer */   
  
declare xCsr cursor for   
select MemberNo,DoCalc from Members  
where schemeNo = @schemeNo and ActiveStatus = 6 and DeferredPaid = 1  
and Docalc >= @sDate and DoCalc <= @eDate  
  
open xcsr  
fetch from xcsr into @MemberNo,@CalcDate  
while @@fetch_status = 0  
begin  
    select @Description = 'Administration Fees for ',@FullName = Upper(sName)+', '+fName+' '+Onames,  
    @InitDescription = 'Administration Fees for '+Upper(sName)+', '+fName+' '+Onames,  
    @SponsorCode = SponsorCode              
    from Members where SchemeNo = @SchemeNo and MemberNo = @memberNo  
  
    if @SchemeMode  = 0 select @SponsorCode = 0   
  
    Exec Proc_Calculate_Fees @schemeNo,@MemberNo,@CalcDate,            
       @EmpFees Out,@EmprFees Out,@VolFees Out,@SpecialFees Out,@EmpFees_Un Out,            
       @EmprFees_Un Out,@VolFees_Un Out,@SpecialFees_Un Out  
  
        
    select @AdminFees = @EmprFees + @SpecialFees,@Description = 'Administration fees for Employer for '+@fullName    
              
              
   if @AdminFees > 0              
      BEGIN    
        Delete from Surplus where SurplusDate = @CalcDate and SurplusDesc = @InitDescription              
        AND SchemeNo = @schemeNo  
            
        Delete from Surplus where SurplusDate = @CalcDate and SurplusDesc = @Description              
        AND SchemeNo = @schemeNo  
  
                        
        Exec InsertSurplus @SchemeNo,@CalcDate,@Description,@AdminFees,0,0,0,0,0,1,@SponsorCode              
                 
      END              
              
      select @AdminFees = 0              
             
      select @AdminFees = @EmprFees_Un + @SpecialFees_Un,@Description = 'Administration fees for Employer for '+@fullName    
                   
           
    if @AdminFees > 0              
       begin   
         Delete from Surplus_UnReg where SurplusDate = @CalcDate and SurplusDesc = @InitDescription              
         AND SchemeNo = @schemeNo  
             
         Delete from Surplus_UnReg where SurplusDate = @CalcDate and SurplusDesc = @Description              
         AND SchemeNo = @schemeNo              
              
         Exec InsertSurplus @SchemeNo,@CalcDate,@Description,@AdminFees,0,0,0,0,1,1,@SponsorCode              
       end    
  
   select @MemberNo=0,@CalcDate=getdate(),@Description = '',@FullName = '',@AdminFees = 0,  
   @EmpFees =0,@EmprFees =0,@VolFees =0,@SpecialFees=0,@EmpFees_Un =0,            
       @EmprFees_Un =0,@VolFees_Un =0,@SpecialFees_Un=0  
   fetch next from xcsr into @MemberNo,@CalcDate  
end  
Close xcsr  
Deallocate xCsr 

if @YearClosed = 1
   UPDATE SchemeYears set YearClosed = 1 where schemeNo = @schemeNo and AcctPeriod = @AcctPeriod
go

