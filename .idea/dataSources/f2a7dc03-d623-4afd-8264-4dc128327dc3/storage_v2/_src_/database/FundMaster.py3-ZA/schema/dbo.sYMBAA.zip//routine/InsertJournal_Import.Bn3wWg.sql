CREATE PROCEDURE [dbo].[InsertJournal_Import]            
@SCHEMENO Int,            
@Narration varchar(255),            
@TransDate Datetime,          
@UserName varchar(100),  
@TransMode int,/* 0 - Insert, 1 - Check if Credits and Debits Balance */  
@JournalNo Int    
          
--with Encryption            
as            
declare @AcctPeriod int,@GSchemeNo Int,@BatchNo int,@Debit decimal(20,6),@Credit decimal(20,6),@diff decimal(20,6)         
  
if @TransMode = 0  
begin       
Exec Proc_Parent_Scheme @GSchemeNo Out        
         
select @AcctPeriod = AcctPeriod from AccountingPeriods where SchemeNo = @schemeNo         
and StartDate <= @TransDate and EndDate >= @TransDate     
    
select @BatchNo = Max(BatchNo) from SchemeGeneralLedger where schemeCode = @schemeNo                     
if @BatchNo is null select @BatchNo = 0              
select @BatchNo = @BatchNo + 1           
            
insert Into Journals (schemeNo, JournalDate, Narration, AcctPeriod, Posted,PreparedBy,DatePrepared,SchemeCode)            
            Values (@GSchemeNo, @TransDate, @Narration, @AcctPeriod, 0,@UserName,GetDate(),@schemeNo)            
            
select Max(JournalNo) as JournalNo,@BatchNo as BatchNo from Journals where SchemeCode = @schemeNo   
end  
else if @TransMode = 1  
begin  
  select @Debit = sum(Debit),@Credit = sum(credit) from SchemeGeneralLedger  
  where schemeCode = @schemeNo and JournalNo = @JournalNo  
  
  if @Debit <> @Credit  
  begin  
     if @Debit > @Credit  
        select @diff = @Debit - @Credit  
     else  
        select @diff = @Credit - @Debit   
  
     if @diff > 1  
        begin  
          raiserror('The debits and credits for the journal for %s are not balancing!, the transaction will be cancelled',16,1,@Narration)  
            
          Update SchemeGeneralLedger set Tran_status = -1 where schemeCode = @schemeNo and JournalNo = @JournalNo  
  
          Update Journals set Tran_status = -1 where schemeCode = @schemeNo and JournalNo = @JournalNo  
        end  
  end   
  
  select @JournalNo as JournalNo,0 as BatchNo  
end
go

