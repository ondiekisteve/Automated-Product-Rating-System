CREATE PROCEDURE [dbo].[Proc_List_Units_Bought]          
@schemeNo Int,          
@ChildSchemeNo Int,          
@UnitType Int          
--with Encryption          
as          
          
select TransNo,TransDate,Amount,NoOfUnits,Amount/NoOfUnits as PricePerUnit,Particulars,BatchNo,'U' as WhichTrans          
from Unit_Buy_Sale_History where schemeNo = @schemeNo          
and ChildSchemeNo = @ChildSchemeNo and UnitType = @UnitType          
and TransType = 0
UNION
select CashTransNo,TransDate,Amount,NoOfUnits,Amount/NoOfUnits as PricePerUnit,Particulars,BatchNo,'C' as WhichTrans          
from TBL_Units_Cash_Account where schemeNo = @schemeNo          
and ChildSchemeNo = @ChildSchemeNo and UnitType = @UnitType          
and TransType = 0 
Order by TransDate
go

