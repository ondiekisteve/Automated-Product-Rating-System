CREATE PROCEDURE [dbo].[PensionStoppageLetter]
@SCHEMENO Int,
@StopMonth int,
@StopYear int
--with Encryption
as

if object_id('tempdb..#PensionStoppage') is null

begin
create table #PensionStoppage
(
	[SchemeNo] [varchar] (15) NOT NULL ,
            [PenCode] [int] IDENTITY(1,1) NOT NULL ,
	[Sponsor] [Varchar] (100) NOT NULL ,
	[SponsorAddress] [Varchar](50) NOT NULL,
	[SponsorTown] [Varchar](50) not NULL, 
             [SponsorCountry] [Varchar](50)not NULL,
             [SponsorPhone][varchar](40),
             [SponsorFax][varchar](40),
             [SponsorEmail][varchar](60),
	[BenName] [varchar] (100) NULL ,
	[BenAddress] [Varchar](50) NULL,
             [BenTown] [varchar] (50) NULL ,
             [BenCountry] [Varchar](50) NULL,
             [BenPension][Float] not null,
             [BenStopMonth][Varchar](30) not null, 
             [StopDate][datetime] not null,
             [Administrator][Varchar](120) not null ,
             [PenNo][varchar](20),
             [Period][varchar](30),
             [startdate][Datetime]            
)       

ALTER TABLE #PensionStoppage WITH NOCHECK ADD 

            
	CONSTRAINT [PK_#PensionStoppage] PRIMARY KEY  NONCLUSTERED 
	(
	   [SchemeNo],
           [PenCode]
		    
	) 
end

Declare @Sponsor Varchar(100),@SAddress Varchar(50),@STown varchar(50), @SCountry varchar(30),
        @BenName varchar(60), @BenAddress varchar(20),@Admin varchar(120),
        @BenTown varchar(30), @BenCountry varchar(30), @BenPension float, @BenStopMonth varchar(30),
        @MonthsPaid int, @SYear int, @SMonth int, @tDate datetime, @EndDate datetime, @EndMonth int, @EndYear Int, @MonthName varchar(15),
        @phone varchar(40),@fax varchar(40),@email varchar(60),@PenNo varchar(20),@Period varchar(30),@StartDate datetime

Select @Admin = ConsultantName from Scheme_Consultants where SchemeNo = @SchemeNo and ConsultantType = 'Administrator'

select @sYear = Max(PayYear) from PensionPayrollBen where SchemeNo = @SchemeNo
select @sMonth = Max(PayMonth) from PensionPayrollBen where SchemeNo = @schemeNo and PayYear = @SYear
Exec getFirstDay @SMonth,@sYear, @tDate out

Exec GetMonthName @StopMonth,@Period out

Select @Period = @Period +',  '+ cast(@StopYear as varchar(4))

select  @Sponsor = SchemeName, @SAddress = Address, @sTown = Town, @ScOuntry = Country ,@phone  = Telephone, @fax= fax, @email = email
from Scheme
where schemeCode = @SchemeNo   

declare BenCsr Cursor for

       select Upper(D.SName)+', '+d.FName+' '+d.OName, d.Address, p.PostOffice, d.Country, m.MonPension,m.PenNo, 
              m.EndDate, m.Startdate
       from Dependants d
            Inner Join MemBeneficiary m on d.SchemeNo = m.SchemeNo and d.MemberNo = m.MemberNo
    and d.DependantCode = m.DependantCode and datePart(Month, m.EndDate) = @StopMonth and datepart(Year, m.EndDate) = @StopYear
            Inner Join Posta p on d.town = p.PostCode
    
       where m.SchemeNo = @SchemeNo 
       order By m.MemberNo
Open BenCsr
Fetch from BenCsr into @BenName, @BenAddress, @BenTown, @BenCountry, @BenPension,@PenNo, @EndDate,@StartDate

while @@fetch_Status = 0
begin
   
    Select @EndMonth  = DatePart(Month,@EndDate)
    Select @EndYear = DatePart(Year, @EndDate)
    
    Exec GetMonthName @EndMonth,@MonthName out
    
    Select @BenStopMonth = @MonthName +', '+cast(@EndYear as Varchar(4))
    
    Insert into #PensionStoppage(SchemeNo, Sponsor, SponsorAddress, SponsorTown, SponsorCountry,
  BenName, BenAddress, BenTown, BenCountry, BenPension,BenStopMonth,
  Administrator, stopDate, SponsorPhone,SponsorFax, SponsorEmail,penNo,Period,Startdate)
       
                          Values(@SchemeNo,@Sponsor, @SAddress, @sTown, @ScOuntry,
  @BenName, @BenAddress, @BenTown, @BenCountry, @BenPension, @BenStopMonth,
   @admin, @EndDate,@phone,@fax,@email,@PenNo,@Period,@StartDate)
                
    Fetch next from BenCsr into @BenName, @BenAddress, @BenTown, @BenCountry, @BenPension,@PenNo, @EndDate,@StartDate
end
Close BenCsr
Deallocate BenCsr


declare BenCsr Cursor for

        select Upper(D.SName)+', '+d.FName+' '+d.OName, d.Address, p.PostOffice, d.Country, m.MonPension,m.PenNo, 
              m.EndDate, m.Startdate
       from Dependants d
            Inner Join PenBeneficiary m on d.SchemeNo = m.SchemeNo and d.MemberNo = m.MemberNo
    and d.DependantCode = m.DependantCode and datePart(Month, m.EndDate) = @StopMonth and datepart(Year, m.EndDate) = @StopYear
            Inner Join Posta p on d.town = p.PostCode
    
       where m.SchemeNo = @SchemeNo 
       order By m.MemberNo
Open BenCsr
Fetch from BenCsr into @BenName, @BenAddress, @BenTown, @BenCountry, @BenPension,@PenNo, @EndDate,@StartDate

while @@fetch_Status = 0
begin
   
    Select @EndMonth  = DatePart(Month,@EndDate)
    Select @EndYear = DatePart(Year, @EndDate)
    
    Exec GetMonthName @EndMonth,@MonthName out
    
    Select @BenStopMonth = @MonthName +', '+cast(@EndYear as Varchar(4))
    
    Insert into #PensionStoppage(SchemeNo, Sponsor, SponsorAddress, SponsorTown, SponsorCountry,
  BenName, BenAddress, BenTown, BenCountry, BenPension,BenStopMonth,
  Administrator, stopDate, SponsorPhone,SponsorFax, SponsorEmail,penNo,Period,Startdate)
       
                          Values(@SchemeNo,@Sponsor, @SAddress, @sTown, @ScOuntry,
  @BenName, @BenAddress, @BenTown, @BenCountry, @BenPension, @BenStopMonth,
   @admin, @EndDate,@phone,@fax,@email,@PenNo,@Period,@StartDate)
                
    Fetch next from BenCsr into @BenName, @BenAddress, @BenTown, @BenCountry, @BenPension,@PenNo, @EndDate,@StartDate
end
Close BenCsr
Deallocate BenCsr

Select * from #PensionStoppage
go

