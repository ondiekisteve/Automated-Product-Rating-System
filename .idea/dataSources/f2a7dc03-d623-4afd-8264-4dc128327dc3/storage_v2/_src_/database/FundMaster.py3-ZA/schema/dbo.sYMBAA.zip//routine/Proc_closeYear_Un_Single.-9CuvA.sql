--> CHECKED AND VERIFIED ON 22ND JANUARY 2002 by the SysTech Development Team    
/*    
This PROCEDURE DBO.is used to close the current scheme year and enter opening balances    
for the current year into the opening balances table    
*/      
CREATE PROCEDURE [dbo].[Proc_closeYear_Un_Single]    
@SCHEMENO Int,    
@MemberNo Int,    
@StartDate Datetime,    
@EndDate datetime    
--with Encryption    
as    
    
set nocount on    
    
declare @EmpCont float,@EmprCont float,@Special float,    
@AVC float,@yearClosed bit,@SoftClosed Bit, @AcctPeriod int,    
@BalanceOfInt SmallInt,@EmpTax float,@EmprTax float,@VolTax float,@SpecTax float,    
@Calc_Admin_Fees Int,@EmpInt float,@EmprInt float,@VolInt float,@SpecInt float,    
@EmpFeesReg float,@EmprFeesReg float,@EmpFeesUnReg float,@EmprFeesUnReg float,  
@DeferredAmt float,@DefInterest float,@UserName varchar(50)

select @UserName = user     
       
Select @BalanceofInt = CalcBalanceofInterest,@Calc_Admin_Fees = Calc_Admin_Fees     
from ConfigYearEnd where SchemeNo = @schemeNo    
    
if @BalanceofInt is null select @BalanceofInt = 0    
if @Calc_Admin_Fees is null select @Calc_Admin_Fees = 0    
    
Select @AcctPeriod = AcctPeriod      
from schemeYears     
where SchemeNo = @schemeNo and StartDate = @StartDate and EndDate = @EndDate    
    
begin tran    
   select @EmpCont = ExcessEmpCont,@EmprCont = ExcessEmprCont,    
          @Avc = ExcessVolContr,@Special =  ExcessSpecial,    
          @EmpTax = EmpTax,@EmprTax = EmprTax,@VolTax  = VolTax,@SpecTax = SpecTax,    
          @EmpInt = EmpInt,@EmprInt = EmprInt,@VolInt = VolInt,@SpecInt = SpecInt,  
          @DeferredAmt  = DeferredAmt,@DefInterest = DefInterest from    
          UnRegisteredBenefits where SchemeNo = @schemeNo and MemberNo = @MemberNo    
    
         if @EmpCont is null select  @EmpCont = 0    
         if @EmprCont is null select @EmprCont =  0    
         if @Avc is null select @Avc = 0    
         if @Special is null select @Special = 0    
         if @EmpTax is null select  @EmpTax = 0    
         if @EmprTax is null select @EmprTax =  0    
         if @VolTax is null select @VolTax = 0    
         if @SpecTax is null select @SpecTax = 0    
         if @EmpInt is null select @EmpInt = 0    
         if @EmprInt is null select @EmprInt = 0    
         if @VolInt is null select  @VolInt = 0    
         if @SpecInt is null select @SpecInt = 0    
         if @DeferredAmt is null select  @DeferredAmt = 0    
         if @DefInterest is null select @DefInterest = 0    
    
  if @Calc_Admin_Fees = 1    
     Exec Proc_Calculate_Member_Fees_Split @schemeNo,@MemberNo,@EndDate,@EmpFeesReg Out,@EmprFeesReg Out,    
        @EmpFeesUnReg Out,@EmprFeesUnReg Out    
  else    
     select @EmpFeesReg  = 0,@EmprFeesReg = 0,@EmpFeesUnReg = 0,@EmprFeesUnReg=0    
    
  if not Exists(select * from UnRegisteredBalances where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod)    
     BEGIN    
     Insert Into UnRegisteredBalances    
    (schemeNo,MemberNo,SchemeYear,SchemeMonth,AcctPeriod,    
     ExcessEmp,ExcessEmpr,ExcessVolContR,ExcessSpecial,    
     EmpTax,EmprTax,VolTax,SpecTax,EmpInt,EmprInt,VolInt,SpecInt,EmpFees_Un,EmprFees_Un,  
     DeferredAmt,DefInterest,DefTax,ProvOrFinal,UserName,TransDate)    
    Values    
    (@schemeNo,@MemberNo,DatePart(Year,@EndDate),DatePart(Month,@EndDate),@AcctPeriod,    
    @EmpCont,@EmprCont,@Avc,@Special,@EmpTax,@EmprTax,@VolTax,@SpecTax,    
    @EmpInt,@EmprInt,@VolInt,@SpecInt,@EmpFeesUnReg,@EmprFeesUnReg,@DeferredAmt,@DefInterest,  
    @DefInterest * 0.30,1,@UserName,GetDate())    
    END    
  else    
    BEGIN    
    update UnRegisteredBalances set    
    ExcessEmp = @EmpCont,ExcessEmpr = @EmprCont,ExcessVolContR = @Avc,ExcessSpecial = @Special,    
    EmpTax = @EmpTax, EmprTax = @EmprTax, VolTax = @VolTax, SpecTax=@SpecTax,    
    EmpInt = @EmpInt,EmprInt = @EmprInt,VolInt = @VolInt,SpecInt = @SpecInt,    
    EmpFees_Un = @EmpFeesUnReg,EmprFees_Un = @EmprFeesUnReg,DeferredAmt = @DeferredAmt,DefInterest = @DefInterest,  
    DefTax = @DefInterest * 0.30        where SchemeNo = @schemeNo and MemberNo = @MemberNo and AcctPeriod = @AcctPeriod    
    END    
       
commit tran
go

