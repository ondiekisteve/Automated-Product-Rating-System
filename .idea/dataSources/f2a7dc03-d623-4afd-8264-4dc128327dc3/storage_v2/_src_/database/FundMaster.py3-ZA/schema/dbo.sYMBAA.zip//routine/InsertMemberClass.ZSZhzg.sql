CREATE PROCEDURE [dbo].[InsertMemberClass]

@SCHEMENO Int,
@classId varchar(3),
@ClassDesc varchar(50)
--with Encryption
as

declare @hasClass varchar(3)

select @hasClass = has_Classes from scheme where schemeCode = @schemeNo

if @hasClass = 'No' 
   begin
        
      if (select count(*) from MemberClasses where SchemeNo = @schemeNo) >= 1
         begin
               raiserror('Please You cannot add a new Members Class !!,  the scheme does not  have Member Classes', 16,1)
               return
         end
        
     else
          begin 
              insert Into MemberClasses (schemeNo, ClassId, ClassDesc)
              values (@schemeNo, @classId, @classDesc)
        end
   end
else
  begin
          insert Into MemberClasses (schemeNo, ClassId, ClassDesc)
          values (@schemeNo, @classId, @classDesc)
 end
go

