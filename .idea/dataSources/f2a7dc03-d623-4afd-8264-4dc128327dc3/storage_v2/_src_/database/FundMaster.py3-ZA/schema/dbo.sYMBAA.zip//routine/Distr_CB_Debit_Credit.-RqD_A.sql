CREATE PROCEDURE [dbo].[Distr_CB_Debit_Credit]                 
@SCHEMENO Int,                  
@CashTransNo_FK Int,        
@CashTransNo Int,        
@CashbookNo int,       
@BankCode Int,       
@DrCr Int,/*0 - Debit, 1 - Credit */  
@TransType int, /* 0 - Unitization, 1 - Inter-Company */       
@Amount float                
--with Encryption                  
as                  
                    
if @TransType = 0  
begin                 
if @DrCr = 0      
   BEGIN        
   insert into CashBook (schemeNo, BankCode, VoucherNo, CashMonth, CashYear, Transdate,ChequeDate, Description,                   
                       Debit, Credit, Balance, AcctPeriod,IncomeCode,CashTransNo,ChequeNo,          
                       BalanceType,VoucherInc,                  
                       ImprestNo,SchemeCode,CurrCode,SpotRate,CashTransNo_FK,Posted)                  
   select schemeNo, @BankCode, VoucherNo, CashMonth, CashYear, Transdate, ChequeDate,Description,                   
                       @Amount, 0, @Amount, AcctPeriod,IncomeCode,@CashTransNo,ChequeNo,          
                       BalanceType,VoucherInc,                  
                       ImprestNo,@SCHEMENO,CurrCode,SpotRate,@CashTransNo_FK,Posted       
   from Cashbook where CashbookNo = @CashbookNo       
  END        
else        
  BEGIN      
   insert into CashBook (schemeNo, BankCode, VoucherNo, CashMonth, CashYear, Transdate,ChequeDate, Description,                   
                       Debit, Credit, Balance, AcctPeriod,ExpenditureCode,CashTransNo,ChequeNo,          
                       BalanceType,VoucherInc, ImprestNo,SchemeCode,CurrCode,SpotRate,CashTransNo_FK,Posted)                  
   select schemeNo, @BankCode, VoucherNo, CashMonth, CashYear, Transdate, ChequeDate,Description,                   
                       0,@Amount,@Amount, AcctPeriod,ExpenditureCode,@CashTransNo,ChequeNo,          
                       BalanceType,VoucherInc,ImprestNo,@SCHEMENO,CurrCode,SpotRate,@CashTransNo_FK,Posted        
   from Cashbook where CashbookNo = @CashbookNo       
 END   
end  
else  
begin                 
if @DrCr = 0      
   BEGIN        
   insert into CashBook (schemeNo, BankCode, VoucherNo, CashMonth, CashYear, Transdate,ChequeDate, Description,                   
                       Debit, Credit, Balance, AcctPeriod,IncomeCode,CashTransNo,ChequeNo,          
                       BalanceType,VoucherInc,                  
                       ImprestNo,SchemeCode,CurrCode,SpotRate,IntCompCode_fk,Posted)                  
   select schemeNo, @BankCode, VoucherNo, CashMonth, CashYear, Transdate, ChequeDate,Description,                   
                       @Amount, 0, @Amount, AcctPeriod,IncomeCode,@CashTransNo,ChequeNo,          
                       BalanceType,VoucherInc,                  
                       ImprestNo,@SCHEMENO,CurrCode,SpotRate,@CashTransNo_FK,Posted       
   from Cashbook where CashbookNo = @CashbookNo       
  END        
else        
  BEGIN      
   insert into CashBook (schemeNo, BankCode, VoucherNo, CashMonth, CashYear, Transdate,ChequeDate, Description,                   
                       Debit, Credit, Balance, AcctPeriod,ExpenditureCode,CashTransNo,ChequeNo,          
                       BalanceType,VoucherInc, ImprestNo,SchemeCode,CurrCode,SpotRate,IntCompCode_fk,Posted)                  
   select schemeNo, @BankCode, VoucherNo, CashMonth, CashYear, Transdate, ChequeDate,Description,                   
                       0,@Amount,@Amount, AcctPeriod,ExpenditureCode,@CashTransNo,ChequeNo,          
                       BalanceType,VoucherInc,ImprestNo,@SCHEMENO,CurrCode,SpotRate,@CashTransNo_FK,Posted        
   from Cashbook where CashbookNo = @CashbookNo       
 END   
end
go

