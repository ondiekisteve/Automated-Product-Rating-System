CREATE VIEW [dbo].[Creditors]
--with Encryption
as
Select schemeNo,VoucherNo,TransactionDate,Description,CreditAmt,PayBank,CreditAcct
from PaymentVoucher
where ChequeWritten = 0
go

