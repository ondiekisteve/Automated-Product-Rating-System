/*
alter table TBL_Benefits_DC add PurchasePriceInt float default 0
go
update TBL_Benefits_DC set PurchasePriceInt = 0
*/
CREATE FUNCTION [dbo].[fn_PurchasePanel](@SCHEMENO Int,@StartDate Datetime,@EndDate Datetime,@Posted Int)                    
returns @tbl_var table(SchemeNo Int,                    
                       MemberNo Int,                  
                       PayrollNo varchar(30),                  
                       IdNumber varchar(20),                    
                       doCalc datetime,              
                       FullName varchar(120),              
                       Benefit float,              
                       CommLumpsum float,              
                       PurchasePrice float,      
                       PurchTrivial float,        
                       TransType Int,  
                       Ben_Counter int,
                       PurchInterest float                   
                       )                    
as                    
 begin 
 
      IF @Posted = 0       
			  Insert into @tbl_var Select m.schemeNo,m.MemberNo,m.PayrollNo,m.IDNumber,M.DoCalc,m.sName+', '+m.fName+' '+m.Onames as FullName,                  
			  b.Ee_Ben + b.Er_Ben + b.Avc_Ben + b.avcER_Ben + b.EE_Transfer + b.ER_Transfer + b.Pre_EE + b.Pre_Er + b.Pre_Avc + b.Def_Ben as Benefit,                  
			  b.CommLumpsum,b.PurchasePrice,      
			  bn.PurchTrivial,b.TransType,b.Ben_Counter,b.AmountPayable - b.PurchasePrice                
			  from Members m                  
			  inner Join Benefits bn on m.SchemeNo = bn.SchemeNo and m.MemberNo = bn.MemberNo 
			  and bn.TrivialPension =  0 
		        
			  inner Join TBL_Benefits_DC b on m.SchemeNo = b.SchemeNo and m.MemberNo = b.MemberNo                 
			  AND (b.Ee_Ben + Er_Ben + Avc_Ben + avcER_Ben + EE_Transfer + ER_Transfer + Pre_EE + Pre_Er + Pre_Avc + Def_Ben) > 0 
			  and b.Posted < 3                
			  inner Join Scheme s on m.SchemeNo = s.SchemeCode and s.FundTypeCode <> 2                 
			  AND s.Fund_Cat <> 2                  
			  where m.ReasonforExit >= 2 and M.ReasonforExit <= 5 --and m.ActiveStatus <> 6           
			  and m.DoCalc >= @StartDate and m.DoCalc <= @EndDate AND M.SchemeNo = @schemeNo  
      else IF @Posted = 1      
			  Insert into @tbl_var Select m.schemeNo,m.MemberNo,m.PayrollNo,m.IDNumber,M.DoCalc,m.sName+', '+m.fName+' '+m.Onames as FullName,                  
			  b.Ee_Ben + b.Er_Ben + b.Avc_Ben + b.avcER_Ben + b.EE_Transfer + b.ER_Transfer + b.Pre_EE + b.Pre_Er + b.Pre_Avc + b.Def_Ben as Benefit,                  
			  b.CommLumpsum,b.PurchasePrice,      
			  bn.PurchTrivial,b.TransType,b.Ben_Counter,b.AmountPayable - b.PurchasePrice                
			  from Members m                  
			  inner Join Benefits bn on m.SchemeNo = bn.SchemeNo and m.MemberNo = bn.MemberNo 
			  and bn.TrivialPension =  0 
		        
			  inner Join TBL_Benefits_DC b on m.SchemeNo = b.SchemeNo and m.MemberNo = b.MemberNo                 
			  AND (b.Ee_Ben + Er_Ben + Avc_Ben + avcER_Ben + EE_Transfer + ER_Transfer + Pre_EE + Pre_Er + Pre_Avc + Def_Ben) > 0 
			  and b.Posted = 3                
			  inner Join Scheme s on m.SchemeNo = s.SchemeCode and s.FundTypeCode <> 2                 
			  AND s.Fund_Cat <> 2                  
			  where m.ReasonforExit >= 2 and M.ReasonforExit <= 5 --and m.ActiveStatus <> 6         
			  and m.DoCalc >= @StartDate and m.DoCalc <= @EndDate AND M.SchemeNo = @schemeNo  			               
              
 return                    
 end
go

