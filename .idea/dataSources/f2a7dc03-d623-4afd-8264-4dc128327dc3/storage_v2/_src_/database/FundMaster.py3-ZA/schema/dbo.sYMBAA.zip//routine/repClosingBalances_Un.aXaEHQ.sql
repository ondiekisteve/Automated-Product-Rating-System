CREATE PROCEDURE [dbo].[repClosingBalances_Un]
@schemeNo varchar(15),
@AcctPeriod int
--with Encryption
as
if object_id('tempdb..##ClosingBalUn') is null
  create table ##ClosingBalUn
  (
    schemeNo varchar (15) NOT NULL ,
    schemeName varchar (100) not null,
    memberNo int NOT NULL ,
    fullName varchar (100) not null, 
    cEmpBal float not null,
    cEmprBal float not null,
    empOpening float null,
    emprOpening float null,
    empCont float null,
    emprCont float null,
    empInt float null,
    emprInt float null,
    grandTotal float not null,
    endingPeriod Varchar (30) null,
    Exits float null,
    Total float null
    constraint pk_ClosingBalUn primary key (schemeNo, memberNo)
  ) 

declare @schemeName varchar(100)
declare @memberNo int
declare @fullName varchar(100) 
declare @cEmpBal float
declare @cEmprBal float,@cVolBal float
declare @empOpening float
declare @emprOpening float,@VolOpening float
declare @empCont float
declare @emprCont float
declare @empInt float
declare @emprInt float
declare @empVol float, @VolInt float
declare @grandTotal float
declare @Transfer float
declare @monthName varchar(15)
declare @schemeYear int
declare @curPeriod varchar(30), @EmprVol float,@MinYear int,@CalcMonth int,@CalcYear int,@SpecOpening float

Delete from ##ClosingBalUn

Select @CalcMonth = DatePart(Month,EndDate),@CalcYear = datepart(Year, EndDate) from schemeYears where schemeNo like @schemeNo
and AcctPeriod = @AcctPeriod

select @monthName = monthName from monthTable where monthNumber = @calcMonth
select @schemeName = schemeName from Scheme where schemeCode like @schemeNo

exec GetEndingPeriod @calcMonth, @curPeriod out
select @curPeriod = @curPeriod +' '+ cast(@CalcYear as varchar(4))

declare benCsr cursor for 
select b.schemeNo, b.memberNo, (b.ExcessEmp + b.ExcessVolContr), 
           (b.ExcessEmpr  + b.ExcessSpecial), 
(b.ExcessEmp + b.ExcessEmpr + b.ExcessVolContr + b.ExcessSpecial) as TotalBalance,
(upper(m.sname) + ', ' + m.fname +' '+m.onames) as fullname 
from UnregisteredBalances b 
     inner join Members m on b.schemeNo like m.schemeNo and b.memberNo = m.memberNo
where b.schemeNo like @schemeNo and AcctPeriod = @AcctPeriod
AND (b.ExcessEmp + b.ExcessEmpr + b.ExcessVolContr + b.ExcessSpecial) > 0
order by b.memberNo

open benCsr
fetch from benCsr into @schemeNo, @MemberNo, @cEmpBal, @cEmprBal,@GrandTotal, @fullname

while @@fetch_status = 0
begin

           if @grandTotal is null select @grandTotal = 0

            select @empOpening = (ExcessEmp + ExcessVolContr) - (EmpTax + VolTax), 
                      @emprOpening = (ExcessEmpr + ExcessSpecial) - (EmprTax + SpecTax) 
            from UnregisteredBalances where schemeNo like @schemeNo and memberNo = @memberNo and acctPeriod = @acctPeriod - 1

            Exec RepMemberCertificateContributions_Un @SchemeNo, @MemberNo, @CalcMonth,@calcYear, @EmpCont out, 
            @EmprCont out, @EmpVol out, @EmprVol out

            if @empOpening is null select @empOpening = 0
            if @emprOpening is null select @emprOpening = 0
            if @empCont is null select @empcont = 0
            if @emprCont is null select @emprCont = 0
            if @empVol is null select @empVol = 0

             Select @EmpCont = @EmpCont + @EmpVol
             select @empInt = @cEmpBal - (@empOpening + @empCont)
              if @empInt is null select @empInt = 0

            Select @EmprCont = @EmprCont + @EmprVol
            select @emprInt = @cEmprBal - (@emprOpening + @emprCont)
             if @emprInt is null select @empInt = 0
 
  insert into ##ClosingBalUn (schemeNo, schemeName, memberNo, fullName, cEmpBal, cEmprBal,empOpening, emprOpening, 
                              empCont,emprCont, empInt, emprInt,grandTotal,EndingPeriod,Exits,Total)
  values (@schemeNo, @schemeName, @memberNo,@fullName, @cEmpBal, @cEmprBal,@EmpOpening, @EmprOpening,

                             @empCont,@EmprCont, @EmpInt, @EmprInt, @GrandTotal, @CurPeriod,0,@GrandTotal)
    
  select @empOpening = 0, @emprOpening = 0, @empCont = 0, @emprCont = 0, @Transfer = 0, @cEmpBal = 0, @cEmprBal = 0

 fetch next from bencsr into @schemeNo, @MemberNo, @cEmpBal, @cEmprBal,@GrandTotal, @fullname
end

close benCsr
deallocate benCsr 

Select * from ##ClosingBalUn WHERE grandTotal > 0 order by MemberNo
go

