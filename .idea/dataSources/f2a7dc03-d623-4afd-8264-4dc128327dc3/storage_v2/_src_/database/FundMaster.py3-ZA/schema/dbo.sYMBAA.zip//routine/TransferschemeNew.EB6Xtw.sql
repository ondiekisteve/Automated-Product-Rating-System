CREATE PROCEDURE [dbo].[TransferschemeNew]
@schemeNo varchar(15),
@curYear int,
@curMonth int,
@rate float,
@Balance float,
@Amount float
--with Encryption
as

if (select count(*) from schemeTransfers where schemeNo like @schemeNo) > 0
begin
    raiserror('An entry already Exists',16,1)
    return

end
else
insert into SchemeTransfers (schemeNo, curYear, CurMonth, rate, amount, balance)
                                  values(@schemeNo, @curYear, @curMonth, @rate, @amount, @Balance )
go

