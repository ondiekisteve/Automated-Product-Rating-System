CREATE PROCEDURE [dbo].[WeightedDailyOtherYearsUn]        
@schemeno int,        
@StartDate datetime,        
@EndDate datetime,        
@startMonth int,        
@EndMonth int,        
@BalanceofInt smallInt,        
@StartYear int,        
@EndYear int,        
@AcctPeriod int        
as        
declare @MemberNo int ,@DatePaid datetime,@EmpCont float,@EmprCont float,@VolContr float,@SpecialContr float,        
 @DoCalc  datetime,@Reason int,@weight float,@Yakwanza Int        
        
/* Initialize StartMonth */        
        
select @Yakwanza = @StartMonth        
        
while @StartMonth < = 12          
    begin          
          
    Declare Acsr Cursor for          
    select c.MemberNo,c.DatePaid,c.ExcessEmpCont,c.ExcessEmprCont,c.ExcessVolContr,c.ExcessSpecial,          
    m.DoCalc,m.ReasonforExit          
    from UnRegisteredContributionssummary c          
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and           
        ((m.ReasonForExit = 0)          
        or          
        (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))          
        And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))          
    where c.SchemeNo = @schemeNo and datepart(Month,c.datepaid) = @StartMonth   
    and datepart(Year,c.datepaid) = @StartYear          
    and c.AcctPeriod = @AcctPeriod          
         
    open acsr          
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    while @@fetch_Status = 0          
    begin          
        if @EmpCont is null select @EmpCont = 0          
        if @EmprCont is null select @EmprCont = 0          
        if @VolContr is null select @VolContr = 0          
        if @SpecialContr is null select @SpecialContr = 0          
          
        select @Weight = 0.0          
          
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000          
          
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,          
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)          
            Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,          
      @EmpCont * @Weight,@EmprCont * @Weight,          
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)          
          
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0           
          
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    end          
    Close Acsr          
    Deallocate Acsr

    /* Transfer Values picked here */                                                                     
   Declare Acsr Cursor for                                    
   select c.MemberNo,c.TransferDate,c.EmpTransfer,c.EmprTransfer + c.deferredAmt,c.AVCTransfer,c.avcerTransfer,                                    
   m.DoCalc,m.ReasonforExit                                    
   from MemberTransferUn c                                     
          inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
     ((m.ReasonForExit = 0)                                    
         or                                    
     (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))                                    
         And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))                                    
       where c.SchemeNo = @schemeNo and DatePart(Month,c.TransferDate) = @StartMonth                                   
       and DatePart(Year,c.TransferDate) = @StartYear                                    
       and c.AcctPeriod = @AcctPeriod                                  
                                   
                                        
    open acsr                                    
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                                    
    while @@fetch_Status = 0                                    
    begin                                    
        if @EmpCont is null select @EmpCont = 0                                    
        if @EmprCont is null select @EmprCont = 0                                    
        if @VolContr is null select @VolContr = 0                                    
        if @SpecialContr is null select @SpecialContr = 0                                                  
        select @Weight = 0.0                                    
                                    
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                                    
                                  
                                                             
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                                    
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)                                    
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                                    
        (@EmpCont) * @Weight,(@EmprCont) * @Weight,                                    
       @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)                                    
                                    
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0
                                    
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                                   
    end -- for Acsr                                    
    Close Acsr                                    
    Deallocate Acsr                               
    /* End Transfer Values */ 
          
    select @StartMonth = @StartMonth + 1          
    end          
          
    /* Contributions in the following Year */          
          
    select @StartMonth = 1          
          
    while @StartMonth < = @EndMonth          
    begin          
         
    Declare Acsr Cursor for          
    select c.MemberNo,c.DatePaid,c.ExcessEmpCont,c.ExcessEmprCont,c.ExcessVolContr,c.ExcessSpecial,          
    m.DoCalc,m.ReasonforExit          
    from UnRegisteredContributionssummary c          
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and           
        ((m.ReasonForExit = 0)          
        or          
        (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))          
        And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))          
    where c.SchemeNo = @schemeNo and datepart(Month,c.datepaid) = @StartMonth and datepart(Year,c.datepaid) = @EndYear          
    and c.AcctPeriod = @AcctPeriod          
          
    open acsr          
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    while @@fetch_Status = 0          
    begin          
        if @EmpCont is null select @EmpCont = 0          
        if @EmprCont is null select @EmprCont = 0          
       if @VolContr is null select @VolContr = 0           
        if @SpecialContr is null select @SpecialContr = 0          
          
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000          
          
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,          
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)          
        Values(@SchemeNo,@MemberNo,@EndYear,@StartMonth,@DatePaid,          
      @EmpCont * @Weight,@EmprCont * @Weight,          
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)          
          
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0             
          
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    end          
    Close Acsr          
    Deallocate Acsr 

        /* Transfer Values picked here */                                                                     
   Declare Acsr Cursor for                                    
   select c.MemberNo,c.TransferDate,c.EmpTransfer,c.EmprTransfer + c.deferredAmt,c.AVCTransfer,c.avcerTransfer,                                    
   m.DoCalc,m.ReasonforExit                                    
   from MemberTransferUn c                                     
          inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
     ((m.ReasonForExit = 0)                                    
         or                                    
     (m.ReasonforExit > 0 and m.DoCalc >= @EndDate))                                    
         And ((M.ActiveStatus <> 3) and (M.ActiveStatus <> 6))                                    
       where c.SchemeNo = @schemeNo and DatePart(Month,c.TransferDate) = @StartMonth                                   
       and DatePart(Year,c.TransferDate) = @StartYear                                    
       and c.AcctPeriod = @AcctPeriod                                  
                                   
                                        
    open acsr                                    
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                                    
    while @@fetch_Status = 0                                    
    begin                                    
        if @EmpCont is null select @EmpCont = 0                                    
        if @EmprCont is null select @EmprCont = 0                                    
        if @VolContr is null select @VolContr = 0                                    
        if @SpecialContr is null select @SpecialContr = 0                                                  
        select @Weight = 0.0                                    
                                    
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                                    
                                  
                                                             
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                                    
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)                                    
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                                    
        (@EmpCont) * @Weight,(@EmprCont) * @Weight,                                    
       @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)                                    
                                    
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0
                                    
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                                   
    end -- for Acsr                                    
    Close Acsr                                    
    Deallocate Acsr                               
    /* End Transfer Values */
         
    select @StartMonth = @StartMonth + 1          
    end         
        
/* DEFERRED MEMBERS WITH DEFERRED BENEFITS FOR EXITS AFTER YEAR END */          
          
    select @StartDate = StartDate,@EndDate = EndDate from schemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod          
          
    Select @StartMonth = DatePart(Month,@StartDate),@StartYear = DatePart(Year,@StartDate)          
          
    Select @EndMonth = DatePart(Month,@EndDate),@EndYear = DatePart(Year,@EndDate)          
          
while @StartMonth < = 12          
    begin          
         
    Declare Acsr Cursor for          
    select c.MemberNo,c.DatePaid,c.ExcessEmpCont,c.ExcessEmprCont,c.ExcessVolContr,c.ExcessSpecial,          
    m.DoCalc,m.ReasonforExit          
    from UnRegisteredContributionssummary c          
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                    
         and (M.ActiveStatus = 6)                   
    where c.SchemeNo = @schemeNo and datepart(Month,c.datepaid) = @StartMonth and datepart(Year,c.datepaid) = @StartYear          
    and c.AcctPeriod = @AcctPeriod          
              
    open acsr          
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    while @@fetch_Status = 0          
    begin          
        if @EmpCont is null select @EmpCont = 0          
        if @EmprCont is null select @EmprCont = 0          
       if @VolContr is null select @VolContr = 0          
        if @SpecialContr is null select @SpecialContr = 0          
          
        select @Weight = 0.0          
          
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000          
          
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,          
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)          
      
            Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,          
      @EmpCont * @Weight,@EmprCont * @Weight,          
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)          
          
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0           
          
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    end          
    Close Acsr          
    Deallocate Acsr  

    /* Transfer Values */  
    Declare Acsr Cursor for                      
    select c.MemberNo,c.TransferDate,c.EmpTransfer,c.EmprTransfer + c.deferredAmt,c.AVCTransfer,c.avcerTransfer,                                    
    m.DoCalc,m.ReasonforExit                                    
    from MemberTransferUn c                     
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                    
         and (M.ActiveStatus = 6)            
    where c.SchemeNo = @schemeNo and datepart(Month,c.TransferDate) = @StartMonth and datepart(Year,c.TransferDate) = @StartYear                      
    and c.AcctPeriod = @AcctPeriod                    
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
                            
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        @EmpCont * @Weight,@EmprCont * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0                        
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end                      
    Close Acsr                      
    Deallocate Acsr        
        
    select @StartMonth = @StartMonth + 1          
    end          
          
    /* Contributions in the following Year */          
          
    select @StartMonth = 1          
          
    while @StartMonth < = @EndMonth          
    begin          
              
    Declare Acsr Cursor for          
    select c.MemberNo,c.DatePaid,c.ExcessEmpCont,c.ExcessEmprCont,c.ExcessVolContr,c.ExcessSpecial,          
    m.DoCalc,m.ReasonforExit          
    from UnRegisteredContributionssummary c          
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and           
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                    
         and (M.ActiveStatus = 6)                  
    where c.SchemeNo = @schemeNo and datepart(Month,c.datepaid) = @StartMonth and datepart(Year,c.datepaid) = @EndYear          
    and c.AcctPeriod = @AcctPeriod          
             
    open acsr          
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    while @@fetch_Status = 0          
    begin          
        if @EmpCont is null select @EmpCont = 0          
        if @EmprCont is null select @EmprCont = 0          
        if @VolContr is null select @VolContr = 0           
        if @SpecialContr is null select @SpecialContr = 0          
          
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000          
          
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,          
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)          
        Values(@SchemeNo,@MemberNo,@EndYear,@StartMonth,@DatePaid,          
      @EmpCont * @Weight,@EmprCont * @Weight,          
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)          
          
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0             
          
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    end          
    Close Acsr          
    Deallocate Acsr 

    /* Transfer Values */  
    Declare Acsr Cursor for                      
    select c.MemberNo,c.TransferDate,c.EmpTransfer,c.EmprTransfer + c.deferredAmt,c.AVCTransfer,c.avcerTransfer,                                    
    m.DoCalc,m.ReasonforExit                                    
    from MemberTransferUn c                     
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonforExit > 0 and m.DoCalc > @EndDate and m.InitialDoCalc > @EndDate)                                    
         and (M.ActiveStatus = 6)            
    where c.SchemeNo = @schemeNo and datepart(Month,c.TransferDate) = @StartMonth and datepart(Year,c.TransferDate) = @StartYear                      
    and c.AcctPeriod = @AcctPeriod                    
                          
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
                            
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0                      
                      
        select @Weight = 0.0                      
                      
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        @EmpCont * @Weight,@EmprCont * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0                        
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end                      
    Close Acsr                      
    Deallocate Acsr        
         
    select @StartMonth = @StartMonth + 1          
    end          
        
/* FOR MEMBERS WITH DEFERRED BENEFITS WITHIN THE YEAR */          
          
select @StartDate = StartDate,@EndDate = EndDate       
from schemeYears where SchemeNo = @schemeNo and AcctPeriod = @AcctPeriod          
          
Select @StartMonth = DatePart(Month,@StartDate),@StartYear = DatePart(Year,@StartDate)          
          
Select @EndMonth = DatePart(Month,@EndDate),@EndYear = DatePart(Year,@EndDate)          
          
while @StartMonth < = 12          
    begin          
         
    Declare Acsr Cursor for          
    select c.MemberNo,c.DatePaid,0.0,c.ExcessEmprCont,0.0,c.ExcessSpecial,          
    m.DoCalc,m.ReasonforExit          
    from UnRegisteredContributionssummary c          
         inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((m.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))                                   
    where c.SchemeNo = @schemeNo and datepart(Month,c.datepaid) = @StartMonth and datepart(Year,c.datepaid) = @StartYear          
    and c.AcctPeriod = @AcctPeriod          
      
    open acsr          
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    while @@fetch_Status = 0          
    begin          
        if @EmpCont is null select @EmpCont = 0          
        if @EmprCont is null select @EmprCont = 0          
        if @VolContr is null select @VolContr = 0          
        if @SpecialContr is null select @SpecialContr = 0          
          
                
        if @EmpCont is null select @EmpCont = 0          
        if @EmprCont is null select @EmprCont = 0          
        
       if @VolContr is null select @VolContr = 0          
        if @SpecialContr is null select @SpecialContr = 0          
          
        select @Weight = 0.0,@EmpCont = 0,@VolContr = 0          
          
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000          
          
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,          
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)          
            Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,          
      @EmpCont * @Weight,@EmprCont * @Weight,          
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)          
          
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0           
          
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    end          
    Close Acsr          
    Deallocate Acsr 

    /* Transfer Values */  
    Declare Acsr Cursor for                      
    select c.MemberNo,c.TransferDate,0.0,c.EmprTransfer + c.deferredAmt,0,c.avcerTransfer,                     
    m.DoCalc,m.ReasonforExit                      
    from MemberTransferUn c                      
       inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((m.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))                             
    where c.SchemeNo = @schemeNo and datepart(month,c.TransferDate) = @StartMonth and datepart(year,c.TransferDate) = @StartYear                      
    and c.AcctPeriod = @AcctPeriod                      
                                        
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0      
      
        select @EmpCont = 0,@VolContr = 0                        
                      
        select @Weight = 0.0                      
                  
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        @EmpCont * @Weight,@EmprCont * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0                        
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end                       
    Close Acsr                      
    Deallocate Acsr 
         
    select @StartMonth = @StartMonth + 1          
    end          
          
    /* Contributions in the following Year */          
          
    select @StartMonth = 1          
          
    while @StartMonth < = @EndMonth          
    begin          
         
    Declare Acsr Cursor for          
    select c.MemberNo,c.DatePaid,0.0,c.ExcessEmprCont,0.0,c.ExcessSpecial,          
    m.DoCalc,m.ReasonforExit          
    from UnRegisteredContributionssummary c          
        inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((m.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))                             
    where c.SchemeNo = @schemeNo and datepart(Month,c.datepaid) = @StartMonth and datepart(Year,c.datepaid) = @EndYear          
    and c.AcctPeriod = @AcctPeriod          
             
              
    open acsr          
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    while @@fetch_Status = 0          
    begin          
        if @EmpCont is null select @EmpCont = 0          
        if @EmprCont is null select @EmprCont = 0          
        if @VolContr is null select @VolContr = 0          
        if @SpecialContr is null select @SpecialContr = 0,@Weight = 0.0,@EmpCont = 0,@VolContr = 0      
      
                 
          
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000          
          
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,          
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)          
        Values(@SchemeNo,@MemberNo,@EndYear,@StartMonth,@DatePaid,          
      @EmpCont * @Weight,@EmprCont * @Weight,          
      @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)          
          
    select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0             
          
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason          
    end          
    Close Acsr          
    Deallocate Acsr 

    /* Transfer Values */  
    Declare Acsr Cursor for                      
    select c.MemberNo,c.TransferDate,0.0,c.EmprTransfer + c.deferredAmt,0,c.avcerTransfer,                     
    m.DoCalc,m.ReasonforExit                      
    from MemberTransferUn c                      
       inner join Members m on c.SchemeNo = m.schemeNo and c.memberNo = m.memberNo and                                     
        (m.ReasonForExit > 0) AND                    
        (((m.ActiveStatus = 6) AND (M.DoCalc > @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate))  
        OR  
        ((M.ActiveStatus = 6) and (M.DeferredPaid = 0) AND (M.DoCalc < @EndDate) and (m.initialdocalc <= @EndDate) and (M.initialdocalc >= @StartDate)))                             
    where c.SchemeNo = @schemeNo and datepart(month,c.TransferDate) = @StartMonth and datepart(year,c.TransferDate) = @StartYear                      
    and c.AcctPeriod = @AcctPeriod                      
                                        
    open acsr                      
    fetch from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    while @@fetch_Status = 0                      
    begin                      
        if @EmpCont is null select @EmpCont = 0                      
        if @EmprCont is null select @EmprCont = 0                      
        if @VolContr is null select @VolContr = 0                      
        if @SpecialContr is null select @SpecialContr = 0      
      
        select @EmpCont = 0,@VolContr = 0                        
                      
        select @Weight = 0.0                      
                  
        select @Weight = Datediff(Day,@DatePaid,@EndDate)/365.0000                      
                      
        Insert Into ##ContSummaryWeightedUn (schemeNo,MemberNo,ContrYear,ContrMonth,DatePaid,                      
         EmpCont,EmprCont,VolContr,SpecialContr,AcctPeriod)                      
        Values(@SchemeNo,@MemberNo,@StartYear,@StartMonth,@DatePaid,                      
        @EmpCont * @Weight,@EmprCont * @Weight,                      
        @VolContr * @Weight,@SpecialContr * @Weight,@AcctPeriod)                      
                      
        select @EmpCont =0,@EmprCont=0,@VolContr=0,@SpecialContr=0,@Reason = 0,@Weight = 0.0                        
                      
    fetch next from acsr into @MemberNo,@DatePaid,@EmpCont,@EmprCont,@VolContr,@SpecialContr,@DoCalc,@Reason                      
    end                       
    Close Acsr                      
    Deallocate Acsr 
         
    select @StartMonth = @StartMonth + 1          
    end
go

