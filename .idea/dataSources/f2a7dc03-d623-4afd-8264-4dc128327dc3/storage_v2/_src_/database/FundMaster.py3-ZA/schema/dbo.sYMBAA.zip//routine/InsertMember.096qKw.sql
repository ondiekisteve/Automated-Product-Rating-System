CREATE PROCEDURE [dbo].[InsertMember]
@SCHEMENO Int
--with Encryption
as
declare @memberNo int



declare mcsr cursor for 
select schemeNo, MemberNo from Membersk where SchemeNo = @schemeNo

order by memberNo

Open mcsr

fetch from mcsr into @schemeNo, @memberNo

while @@fetch_status = 0
begin
     insert into Members select * from membersk Where SchemeNo = @schemeNo and MemberNo = @memberNo

     fetch next from mcsr into @schemeNo, @memberNo
end

close mCsr
deallocate mCsr
go

