CREATE PROCEDURE [dbo].[Proc_Get_New_Price]                      
@schemeNo Int,                      
@UnitType Int,                      
@TransDate Datetime,  
@NewPrice decimal(20,6) out                      
--with Encryption                      
as                      
                      
declare @ChangeValue decimal(20,6),@UnitsBought decimal(20,6),@UnitsSold Decimal(20,6),@NoofUnits Decimal(20,6),                      
@PricePerUnit decimal(20,6),@TotalValue Decimal(20,6),@PrevDate Datetime                      
                      
select @PrevDate = @TransDate - 1                      
                      
Exec Proc_Get_NoofUnits @SCHEMENO,@UnitType,@PrevDate,0,0,@UnitsBought Out,@UnitsSold Out                      
                      
Exec Proc_GetUnitValue @SCHEMENO,@UnitType,@PrevDate,1,@PricePerUnit Out                 
                
if ((@PricePerUnit is null) or (@PricePerUnit = 0.0000))                
   begin                
      select @PrevDate = Max(TransDate) from Unit_Buy_Sale_Price                 
      where schemeNo = @schemeNo and UnitType = @UnitType and TransDate < @TransDate                
                
      Exec Proc_GetUnitValue @SCHEMENO,@UnitType,@PrevDate,1,@PricePerUnit Out                 
   end                
select @NoofUnits = @UnitsBought - @UnitsSold             
                     
if @UnitType = 1 /* Equities */                     
   Exec Proc_Sum_Equity_Value @schemeNo,@TransDate,@ChangeValue Out                       
else if @UnitType = 2 /* Government Bonds */                        
   Exec Proc_Sum_GovComm_Value @schemeNo,0,@TransDate,@ChangeValue Out                        
else if @UnitType = 3 /* Property */                     
   Exec Proc_Sum_Property_Value @schemeNo,@TransDate,@ChangeValue Out                               
else if @UnitType = 4 /* Fixed Income */                     
   Exec Proc_Sum_GovComm_Value @schemeNo,2,@TransDate,@ChangeValue Out                  
else if @UnitType = 5 /* Corporate Bonds */                      
   Exec Proc_Sum_GovComm_Value @schemeNo,1,@TransDate,@ChangeValue Out            
else if @UnitType = 6 /* Offshore */                      
   Exec Proc_Sum_Offshore_Value @schemeNo,@TransDate,@ChangeValue Out                     
                      
if @ChangeValue is null select @ChangeValue = 0.0                      
                      
select @TotalValue = @NoofUnits * @PricePerUnit        
        
IF @TotalValue IS NULL SELECT @TotalValue = 0                       
                      
select @NewPrice = (@TotalValue +  @ChangeValue)/@NoOfUnits
go

