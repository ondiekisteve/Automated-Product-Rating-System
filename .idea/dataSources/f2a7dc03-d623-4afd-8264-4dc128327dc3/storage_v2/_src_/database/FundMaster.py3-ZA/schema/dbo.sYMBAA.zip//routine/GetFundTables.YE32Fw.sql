CREATE PROCEDURE [dbo].[GetFundTables]
--with Encryption
as
Select Name as TableName, id as TableId
from SysObjects
where xType ='U'
And Left(Name,1) <> '_' and Right(Name,5) <> '_Arch'
order by Name
go

