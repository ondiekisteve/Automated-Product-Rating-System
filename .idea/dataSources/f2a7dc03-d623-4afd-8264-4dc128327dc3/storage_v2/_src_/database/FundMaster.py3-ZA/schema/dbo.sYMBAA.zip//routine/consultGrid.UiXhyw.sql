CREATE PROCEDURE [dbo].[consultGrid]
@SCHEMENO Int
--with Encryption
as
select ConsultantCode, SchemeNo, ConsultantName, ContactName, DOApmt, ConsultantType
from Scheme_Consultants
where SchemeNo = @SchemeNo and CurrentT = 1
go

