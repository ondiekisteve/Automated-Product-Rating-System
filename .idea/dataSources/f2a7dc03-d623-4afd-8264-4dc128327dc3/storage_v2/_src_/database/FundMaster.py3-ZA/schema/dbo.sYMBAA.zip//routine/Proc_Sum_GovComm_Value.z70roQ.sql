CREATE PROCEDURE [dbo].[Proc_Sum_GovComm_Value]                          
@schemeNo Int,                          
@GovComm Int,/* 4 - Local Bond Fund, 5 - Local Fixed Interest */                          
@AsAtDate Datetime,                        
@ChangeInValue Decimal(20,6) Out                         
--with Encryption                          
as                          
                                                
declare @WithholdingTax decimal(20,6),@MedicalLevy decimal(20,6),@CapRepayment decimal(20,6)
                                                                 
select @ChangeInValue = sum((Income + Discount) * ExRate),@WithholdingTax = sum(WithTax * ExRate),
@MedicalLevy = sum(MedLevy*ExRate),@CapRepayment = sum(CapRepayment * ExRate)                       
from TBL_INVEST_RECEIVABLE                                                                                                                         
where schemeNo = @schemeNo and TransDate = @AsAtDate and Rep_Inv_Class = @GovComm              
                                            
if @ChangeInValue is null select @ChangeInValue = 0.0 
if @WithholdingTax is null select @WithholdingTax = 0.0 
if @MedicalLevy is null select @MedicalLevy = 0.0 
if @CapRepayment is null select @CapRepayment = 0.0
go

