create procedure Proc_UPDATE_AVCER_BAL_UNREG3 is

  V_Member_id NUMBER(19);
  V_CB_ID NUMBER(19);
  V_CB_NEWAVCBAL NUMBER(19,6);
  V_CB_NEWTOTBAL NUMBER(19,6);




  cursor cont_kengen1 is

    select ID FROM MEMBERS where id in (select MEMBER_ID from CLOSING_BALANCES);

  begin
    open cont_kengen1;
    loop
      fetch cont_kengen1 into v_Member_ID;

      exit when cont_kengen1%notfound;


      if (v_Member_ID > 0) then
        BEGIN
          INSERT INTO CB_AVCER_UPDATE_UNREG (CB_ID,AVC_BAL,TOT)
            with cache as (
                select
                  b.id,
                  -----erLag---
                  LAG(sum(ER_BAL), 1, 0) OVER (ORDER BY sum(a.ID)) tot,
                  LAG(sum(AVCER_BAL), 1, 0) OVER (ORDER BY sum(a.ID)) avcCbLag,
                  -----erLag
                  max(to_date) AS_AT,
                  TO_CHAR(SYSDATE, 'MM-DD-YYYY') as current_date,
                  TO_CHAR(a.TO_DATE, 'YYYY') as year
                from closing_balances b
                  inner join accounting_periods a on a.id = b.ap_id --and m.id = b.member_id and m.scheme_id = :scheme_id  and b.ap_id =:ap_id
                where b.member_id = V_Member_id and status='UNREGISTERED'
                group by b.id,to_date
                order by a.TO_DATE) select id,avcCbLag,tot
                                    from cache;
          COMMIT;
        END;
      END IF;

      commit;
    end loop;
    close cont_kengen1;
  end;






/

