create trigger TBL_BTF_BALANCES_BALCOUNT_TRIG
  before insert or update
  on TBL_BTF_BALANCES
  for each row
  DECLARE 
v_newVal NUMBER(12) := 0;
v_incval NUMBER(12) := 0;
BEGIN
  IF INSERTING AND :new.BalCounter IS NULL THEN
    SELECT  TBL_BTF_Balances_BalCounte_SEQ.NEXTVAL INTO v_newVal FROM DUAL;
    -- If this is the first time this table have been inserted into (sequence == 1)
    IF v_newVal = 1 THEN 
      --get the max indentity value from the table
      SELECT NVL(max(BalCounter),0) INTO v_newVal FROM TBL_BTF_Balances;
      v_newVal := v_newVal + 1;
      --set the sequence to that value
      LOOP
           EXIT WHEN v_incval>=v_newVal;
           SELECT TBL_BTF_Balances_BalCounte_SEQ.nextval INTO v_incval FROM dual;
      END LOOP;
    END IF;
   -- assign the value from the sequence to emulate the identity column
   :new.BalCounter := v_newVal;
  END IF;
END;



/

