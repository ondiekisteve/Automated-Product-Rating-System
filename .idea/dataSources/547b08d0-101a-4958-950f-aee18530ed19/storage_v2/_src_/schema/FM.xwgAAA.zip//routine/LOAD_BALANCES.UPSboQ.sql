create procedure Load_Balances is
v_MEMBER_NO             NUMBER(10);        
v_SCHEME_ID             NUMBER(10);        
v_ID                    NUMBER(19);        
v_EE_CONTR              NUMBER (19,4);          
v_ER_CONTR              NUMBER (19,4);            
v_AVC_BAL               NUMBER (19,4);            
v_AVCER_BAL             NUMBER (19,4);            
v_EE_BAL                NUMBER (19,4);            
v_ER_BAL                NUMBER (19,4);            
v_DEFICIT_BAL           NUMBER  (19,4);           
v_MEMBER_ID             NUMBER(19);        
v_PRE_EMPLOYEE_BAL      NUMBER (19,4);            
v_PRE_EMPLOYER_BAL      NUMBER (19,4);            
v_TRANSFER              NUMBER (19,4);            
v_LOCKED_IN             NUMBER (19,4);            
v_UNLOCK_DATE           DATE;              
v_EE_INTR               NUMBER (19,4);             
v_ER_INTR               NUMBER (19,4);            
v_AVC_INTR              NUMBER (19,4);            
v_AVCER_INTR            NUMBER (19,4);           
v_AP_ID                 NUMBER(19);       
v_STATUS                VARCHAR2(50); 
v_EE_FEES               NUMBER (19,4);             
v_ER_FEES               NUMBER (19,4);             
v_EE_TAX                NUMBER (19,4);            
v_ER_TAX                NUMBER (19,4);            
v_AVC_TAX               NUMBER (19,4);            
v_AVCER_TAX             NUMBER (19,4);            
v_TRANSFER_EE           NUMBER (19,4);            
v_TRANSFER_ER           NUMBER (19,4);            
v_TRANSDATE             DATE; 
v_count number(19);
v_AUTO_ID number(19);

--SELECT COUNT(*) FROM CLOSING_BALANCES;
--select count(*) from etl_contributions_1;

--DELETE FROM CLOSING_BALANCES;

--COMMIT;

cursor cont_kengen1 is 
select MEMBER_NO,        
SCHEME_ID,              
EE_CONTR,            
ER_CONTR,           
AVC_BAL,           
AVCER_BAL,           
EE_BAL,          
ER_BAL,            
DEFICIT_BAL,                   
PRE_EMPLOYEE_BAL,           
PRE_EMPLOYER_BAL,           
TRANSFER,           
LOCKED_IN,           
UNLOCK_DATE,             
EE_INTR,            
ER_INTR,           
AVC_INTR,           
AVCER_INTR,                   
STATUS,
EE_FEES,         
ER_FEES,           
EE_TAX,           
ER_TAX,            
AVC_TAX,            
AVCER_TAX,            
TRANSFER_EE,           
TRANSFER_ER,           
TRANSDATE,
AUTO_ID
from ETL_BALANCES
---WHERE MEMBER_NO IN (SELECT MEMBER_NO FROM MEMBERS)
--and Member_No > 1416172
ORDER BY SCHEME_ID,MEMBER_NO,TRANSDATE; 

begin
  open cont_kengen1;
  loop
    fetch cont_kengen1 into v_MEMBER_NO, v_SCHEME_ID, v_EE_CONTR,v_ER_CONTR,v_AVC_BAL,v_AVCER_BAL,v_EE_BAL,v_ER_BAL,v_DEFICIT_BAL,v_PRE_EMPLOYEE_BAL,          
                            v_PRE_EMPLOYER_BAL,v_TRANSFER,v_LOCKED_IN,v_UNLOCK_DATE,v_EE_INTR,v_ER_INTR,v_AVC_INTR,v_AVCER_INTR,v_STATUS, v_EE_FEES,             
                            v_ER_FEES,v_EE_TAX,v_ER_TAX,v_AVC_TAX,v_AVCER_TAX,v_TRANSFER_EE,v_TRANSFER_ER,v_TRANSDATE,v_AUTO_ID;

    exit when cont_kengen1%notfound;

    ---select * from closing_balances;

    select MIN(ID) into v_MEMBER_ID from Members where scheme_id = v_SCHEME_ID and Member_No = v_MEMBER_NO;

    select MIN(ID) into v_AP_ID FROM ACCOUNTING_PERIODS 
    WHERE scheme_Id = v_SCHEME_ID and v_TRANSDATE >= FROM_DATE 
    AND  v_TRANSDATE <= TO_DATE AND PERIOD_TYPE = 'FISCAL_YEAR';

    if v_AP_ID is null then
       v_AP_ID := 0;
    end if;

    if v_MEMBER_ID is null then
       v_MEMBER_ID :=0;
    end if;


    if ((v_MEMBER_ID > 0) and (v_AP_ID > 0)) then
       BEGIN
           /*
           dbms_output.put_line('scheme Number '|| v_SCHEME_ID);
           dbms_output.put_line('Member ID '|| v_MEMBER_ID);
           dbms_output.put_line('Member NO '|| v_MEMBER_NO);
           dbms_output.put_line('Accounting Period '|| v_AP_ID);
           */


           Insert into CLOSING_BALANCES (ID,MEMBER_ID, EE_CONTR,ER_CONTR,AVC_BAL,AVCER_BAL,EE_BAL,ER_BAL,DEFICIT_BAL,PRE_EMPLOYEE_BAL,PRE_EMPLOYER_BAL,TRANSFER,
                                         LOCKED_IN,EE_INTR,ER_INTR,AVC_INTR,AVCER_INTR,STATUS,EE_FEES,ER_FEES,EE_TAX,ER_TAX,
                                         TRANSFER_EE,TRANSFER_ER,AP_ID,ASAT,NSSF_TRANSFER_BALINTR)
                                values (hibernate_sequence.nextval,v_Member_ID,
                                        v_EE_CONTR,v_ER_CONTR,v_AVC_BAL,v_AVCER_BAL,v_EE_BAL,v_ER_BAL,v_DEFICIT_BAL,v_PRE_EMPLOYEE_BAL,v_PRE_EMPLOYER_BAL,
                                        v_TRANSFER,v_LOCKED_IN,v_EE_INTR,v_ER_INTR,v_AVC_INTR,v_AVCER_INTR,v_STATUS,v_EE_FEES,v_ER_FEES,
                                        v_EE_TAX,v_ER_TAX,v_TRANSFER_EE,v_TRANSFER_ER,v_AP_ID,v_TRANSDATE,v_AUTO_ID);
       END;
    END IF;

    commit;

  end loop;
  close cont_kengen1;
end;

/

