create procedure Proc_Load_ETL_Beneficiaries_0 is
V_Scheme_ID NUMBER(19);
V_Member_ID Number(19);
V_CELL_PHONE VARCHAR2(50);
V_EMAIL VARCHAR2(50);
V_POSTAL_ADDRESS VARCHAR2(100);
V_DOB DATE;
V_FIRSTNAME VARCHAR2(100);
V_LUMPSUM_ENTITLEMENT NUMBER(19,6);
V_SURNAME VARCHAR2(100);
V_ID NUMBER(19);
V_ONAME VARCHAR2(100);
V_DOapmt DATE;
V_SEX VARCHAR2(10);
V_RELATION VARCHAR2(50);

cursor cont_kengen1 is 

SELECT m.Scheme_id, m.id,c.DependantCode,c.DOB,
  c.CELL_PHONE,c.EMAIL,c.ADDRESS,c.FIRSTNAME,c.LUMPSUM,
  c.SURNAME,c.othernames, c.DATEOFAPPOINTMENT, c.sex, c.relation
from ETL_Beneficiaries_1 c
  left outer join Members m on m.member_no = c.MEMBER_NO and m.SCHEME_ID=c.SCHEME_ID
where c.SCHEME_ID=m.SCHEME_ID and c.MEMBER_NO=m.MEMBER_NO order by DEPENDANTCODE;

begin
  open cont_kengen1;
  loop

    fetch cont_kengen1 into V_Scheme_ID,V_Member_ID,V_ID,V_DOB,V_CELL_PHONE,V_EMAIL,V_POSTAL_ADDRESS,V_FIRSTNAME,V_LUMPSUM_ENTITLEMENT,
       V_SURNAME,V_ONAME,V_DOapmt, V_SEX,V_RELATION; 

    exit when cont_kengen1%notfound;


    /*
    dbms_output.put_line(' CONT ID '|| V_Cont_ID);
    dbms_output.put_line(' ACCOUNTING PERIOD ID '|| v_accountingperiod_id);
    dbms_output.put_line(' DATE PAID '|| v_date_paid);
	*/


           Insert into Beneficiaries(ID,MEMBER_ID,DOB,CELL_PHONE,EMAIL,POSTAL_ADDRESS,FIRSTNAME,LUMPSUM_ENTITLEMENT,
                                     SURNAME,OTHERNAMES, DATE_OF_APPOINTMENT, GENDER, RELATIONSHIP )
               values(hibernate_sequence.nextval,V_Member_ID,V_DOB,V_CELL_PHONE,V_EMAIL,V_POSTAL_ADDRESS,V_FIRSTNAME,V_LUMPSUM_ENTITLEMENT,
                                     V_SURNAME,V_ONAME, V_DOapmt,V_SEX,V_RELATION);

    commit;
  end loop;
  close cont_kengen1;
end;

/

