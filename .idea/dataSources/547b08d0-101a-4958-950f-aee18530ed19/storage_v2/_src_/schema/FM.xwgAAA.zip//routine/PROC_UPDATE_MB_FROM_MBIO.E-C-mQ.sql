create procedure proc_update_mb_from_MBIO is
  v_MID number(19);
  v_DOB DATE;
  v_FIRSTNAME varchar2(200);
  v_OTHER_NAMES varchar2(200);
  v_SURNAME varchar2(200);
  v_GENDER varchar2(10);
  v_PIN varchar2(30);
  v_ID_NO varchar2(30);
  v_mbio_id NUMBER(19);
  v_POSTAL_ADD varchar2(200);
  v_EMAIL varchar2(200);
  v_ROAD varchar2(200);
  v_CELLPHONE varchar2(200);
  v_TITLE varchar2(200);
  v_MSTATUS varchar2(200);
  v_ID_TYPE varchar2(200);


  cursor cont_kengen1 is
    SELECT ID,DOB,FIRSTNAME,OTHER_NAMES,SURNAME,GENDER,PIN,ID_NO,POSTAL_ADDRESS, EMAIL,ROAD,CELL_PHONE,TITLE,MARTL_STATUS,ID_TYPE
    FROM MEMBERS;

  begin
    open cont_kengen1;
    loop
      fetch cont_kengen1 into v_MID,v_DOB,v_FIRSTNAME,v_OTHER_NAMES,v_SURNAME,v_GENDER,v_PIN,v_ID_NO,v_POSTAL_ADD,v_EMAIL,v_ROAD,
    v_CELLPHONE,v_TITLE,v_MSTATUS,v_ID_TYPE;

      exit when cont_kengen1%notfound;

      SELECT HIBERNATE_SEQUENCE.nextval INTO v_mbio_id FROM DUAL;

      insert into  MEMBERS_BIOS (ID,DOB,FIRSTNAME,OTHER_NAMES,SURNAME,GENDER,PIN,ID_NO, POSTAL_ADDRESS,EMAIL,ROAD,
      CELL_PHONE,TITLE,MARTL_STATUS,ID_TYPE) VALUES (
        v_mbio_id,v_DOB,v_FIRSTNAME,v_OTHER_NAMES,v_SURNAME,v_GENDER,v_PIN,v_ID_NO,v_POSTAL_ADD,v_EMAIL,v_ROAD,
        v_CELLPHONE,v_TITLE,v_MSTATUS,v_ID_TYPE
      );
      COMMIT;

      UPDATE  MEMBERS SET MEMBERBIO_ID=v_mbio_id WHERE ID=v_MID;
      COMMIT;
       

    end loop;
    close cont_kengen1;
  end;

/

