create procedure Proc_UPDATE_AVCER_UNREG_VALUES is

  V_Member_id NUMBER(19);
  V_CB_ID NUMBER(19);
  V_CB_NEWAVCBAL NUMBER(19,6);
  V_CB_NEWEEBAL NUMBER(19,6);

  cursor cont_kengen1 is

      select CB_ID,AVC_BAL,TOT FROM CB_AVCER_UPDATE_UNREG ORDER BY CB_ID ASC ;

  begin
    open cont_kengen1;
    loop
      fetch cont_kengen1 into V_CB_ID,V_CB_NEWAVCBAL,V_CB_NEWEEBAL;

      exit when cont_kengen1%notfound;


      if (V_CB_ID > 0) then
        BEGIN
          UPDATE CLOSING_BALANCES cb SET cb.ER_BAL=V_CB_NEWEEBAL,cb.AVCER_BAL=V_CB_NEWAVCBAL WHERE cb.ID=V_CB_ID;
          COMMIT;
        END;
      END IF;

      commit;
    end loop;
    close cont_kengen1;
  end;
/

